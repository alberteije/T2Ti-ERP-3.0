// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $ChequesTable extends Cheques with TableInfo<$ChequesTable, Cheque> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ChequesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTalonarioChequeMeta = const VerificationMeta(
    'idTalonarioCheque',
  );
  @override
  late final GeneratedColumn<int> idTalonarioCheque = GeneratedColumn<int>(
    'id_talonario_cheque',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
    'numero',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _statusChequeMeta = const VerificationMeta(
    'statusCheque',
  );
  @override
  late final GeneratedColumn<String> statusCheque = GeneratedColumn<String>(
    'status_cheque',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataStatusMeta = const VerificationMeta(
    'dataStatus',
  );
  @override
  late final GeneratedColumn<DateTime> dataStatus = GeneratedColumn<DateTime>(
    'data_status',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idTalonarioCheque,
    numero,
    statusCheque,
    dataStatus,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cheque';
  @override
  VerificationContext validateIntegrity(
    Insertable<Cheque> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_talonario_cheque')) {
      context.handle(
        _idTalonarioChequeMeta,
        idTalonarioCheque.isAcceptableOrUnknown(
          data['id_talonario_cheque']!,
          _idTalonarioChequeMeta,
        ),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('status_cheque')) {
      context.handle(
        _statusChequeMeta,
        statusCheque.isAcceptableOrUnknown(
          data['status_cheque']!,
          _statusChequeMeta,
        ),
      );
    }
    if (data.containsKey('data_status')) {
      context.handle(
        _dataStatusMeta,
        dataStatus.isAcceptableOrUnknown(data['data_status']!, _dataStatusMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cheque map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cheque(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idTalonarioCheque: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_talonario_cheque'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}numero'],
      ),
      statusCheque: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status_cheque'],
      ),
      dataStatus: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_status'],
      ),
    );
  }

  @override
  $ChequesTable createAlias(String alias) {
    return $ChequesTable(attachedDatabase, alias);
  }
}

class Cheque extends DataClass implements Insertable<Cheque> {
  final int? id;
  final int? idTalonarioCheque;
  final int? numero;
  final String? statusCheque;
  final DateTime? dataStatus;
  const Cheque({
    this.id,
    this.idTalonarioCheque,
    this.numero,
    this.statusCheque,
    this.dataStatus,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTalonarioCheque != null) {
      map['id_talonario_cheque'] = Variable<int>(idTalonarioCheque);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || statusCheque != null) {
      map['status_cheque'] = Variable<String>(statusCheque);
    }
    if (!nullToAbsent || dataStatus != null) {
      map['data_status'] = Variable<DateTime>(dataStatus);
    }
    return map;
  }

  factory Cheque.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cheque(
      id: serializer.fromJson<int?>(json['id']),
      idTalonarioCheque: serializer.fromJson<int?>(json['idTalonarioCheque']),
      numero: serializer.fromJson<int?>(json['numero']),
      statusCheque: serializer.fromJson<String?>(json['statusCheque']),
      dataStatus: serializer.fromJson<DateTime?>(json['dataStatus']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTalonarioCheque': serializer.toJson<int?>(idTalonarioCheque),
      'numero': serializer.toJson<int?>(numero),
      'statusCheque': serializer.toJson<String?>(statusCheque),
      'dataStatus': serializer.toJson<DateTime?>(dataStatus),
    };
  }

  Cheque copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idTalonarioCheque = const Value.absent(),
    Value<int?> numero = const Value.absent(),
    Value<String?> statusCheque = const Value.absent(),
    Value<DateTime?> dataStatus = const Value.absent(),
  }) => Cheque(
    id: id.present ? id.value : this.id,
    idTalonarioCheque:
        idTalonarioCheque.present
            ? idTalonarioCheque.value
            : this.idTalonarioCheque,
    numero: numero.present ? numero.value : this.numero,
    statusCheque: statusCheque.present ? statusCheque.value : this.statusCheque,
    dataStatus: dataStatus.present ? dataStatus.value : this.dataStatus,
  );
  Cheque copyWithCompanion(ChequesCompanion data) {
    return Cheque(
      id: data.id.present ? data.id.value : this.id,
      idTalonarioCheque:
          data.idTalonarioCheque.present
              ? data.idTalonarioCheque.value
              : this.idTalonarioCheque,
      numero: data.numero.present ? data.numero.value : this.numero,
      statusCheque:
          data.statusCheque.present
              ? data.statusCheque.value
              : this.statusCheque,
      dataStatus:
          data.dataStatus.present ? data.dataStatus.value : this.dataStatus,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Cheque(')
          ..write('id: $id, ')
          ..write('idTalonarioCheque: $idTalonarioCheque, ')
          ..write('numero: $numero, ')
          ..write('statusCheque: $statusCheque, ')
          ..write('dataStatus: $dataStatus')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idTalonarioCheque, numero, statusCheque, dataStatus);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cheque &&
          other.id == this.id &&
          other.idTalonarioCheque == this.idTalonarioCheque &&
          other.numero == this.numero &&
          other.statusCheque == this.statusCheque &&
          other.dataStatus == this.dataStatus);
}

class ChequesCompanion extends UpdateCompanion<Cheque> {
  final Value<int?> id;
  final Value<int?> idTalonarioCheque;
  final Value<int?> numero;
  final Value<String?> statusCheque;
  final Value<DateTime?> dataStatus;
  const ChequesCompanion({
    this.id = const Value.absent(),
    this.idTalonarioCheque = const Value.absent(),
    this.numero = const Value.absent(),
    this.statusCheque = const Value.absent(),
    this.dataStatus = const Value.absent(),
  });
  ChequesCompanion.insert({
    this.id = const Value.absent(),
    this.idTalonarioCheque = const Value.absent(),
    this.numero = const Value.absent(),
    this.statusCheque = const Value.absent(),
    this.dataStatus = const Value.absent(),
  });
  static Insertable<Cheque> custom({
    Expression<int>? id,
    Expression<int>? idTalonarioCheque,
    Expression<int>? numero,
    Expression<String>? statusCheque,
    Expression<DateTime>? dataStatus,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTalonarioCheque != null) 'id_talonario_cheque': idTalonarioCheque,
      if (numero != null) 'numero': numero,
      if (statusCheque != null) 'status_cheque': statusCheque,
      if (dataStatus != null) 'data_status': dataStatus,
    });
  }

  ChequesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idTalonarioCheque,
    Value<int?>? numero,
    Value<String?>? statusCheque,
    Value<DateTime?>? dataStatus,
  }) {
    return ChequesCompanion(
      id: id ?? this.id,
      idTalonarioCheque: idTalonarioCheque ?? this.idTalonarioCheque,
      numero: numero ?? this.numero,
      statusCheque: statusCheque ?? this.statusCheque,
      dataStatus: dataStatus ?? this.dataStatus,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTalonarioCheque.present) {
      map['id_talonario_cheque'] = Variable<int>(idTalonarioCheque.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (statusCheque.present) {
      map['status_cheque'] = Variable<String>(statusCheque.value);
    }
    if (dataStatus.present) {
      map['data_status'] = Variable<DateTime>(dataStatus.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ChequesCompanion(')
          ..write('id: $id, ')
          ..write('idTalonarioCheque: $idTalonarioCheque, ')
          ..write('numero: $numero, ')
          ..write('statusCheque: $statusCheque, ')
          ..write('dataStatus: $dataStatus')
          ..write(')'))
        .toString();
  }
}

class $FinParcelaPagarsTable extends FinParcelaPagars
    with TableInfo<$FinParcelaPagarsTable, FinParcelaPagar> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinParcelaPagarsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinLancamentoPagarMeta =
      const VerificationMeta('idFinLancamentoPagar');
  @override
  late final GeneratedColumn<int> idFinLancamentoPagar = GeneratedColumn<int>(
    'id_fin_lancamento_pagar',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinChequeEmitidoMeta =
      const VerificationMeta('idFinChequeEmitido');
  @override
  late final GeneratedColumn<int> idFinChequeEmitido = GeneratedColumn<int>(
    'id_fin_cheque_emitido',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinStatusParcelaMeta =
      const VerificationMeta('idFinStatusParcela');
  @override
  late final GeneratedColumn<int> idFinStatusParcela = GeneratedColumn<int>(
    'id_fin_status_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinTipoPagamentoMeta =
      const VerificationMeta('idFinTipoPagamento');
  @override
  late final GeneratedColumn<int> idFinTipoPagamento = GeneratedColumn<int>(
    'id_fin_tipo_pagamento',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroParcelaMeta = const VerificationMeta(
    'numeroParcela',
  );
  @override
  late final GeneratedColumn<int> numeroParcela = GeneratedColumn<int>(
    'numero_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataVencimentoMeta = const VerificationMeta(
    'dataVencimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>(
        'data_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataPagamentoMeta = const VerificationMeta(
    'dataPagamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataPagamento =
      GeneratedColumn<DateTime>(
        'data_pagamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _descontoAteMeta = const VerificationMeta(
    'descontoAte',
  );
  @override
  late final GeneratedColumn<DateTime> descontoAte = GeneratedColumn<DateTime>(
    'desconto_ate',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaJuroMeta = const VerificationMeta(
    'taxaJuro',
  );
  @override
  late final GeneratedColumn<double> taxaJuro = GeneratedColumn<double>(
    'taxa_juro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaMultaMeta = const VerificationMeta(
    'taxaMulta',
  );
  @override
  late final GeneratedColumn<double> taxaMulta = GeneratedColumn<double>(
    'taxa_multa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaDescontoMeta = const VerificationMeta(
    'taxaDesconto',
  );
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
    'taxa_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorJuroMeta = const VerificationMeta(
    'valorJuro',
  );
  @override
  late final GeneratedColumn<double> valorJuro = GeneratedColumn<double>(
    'valor_juro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMultaMeta = const VerificationMeta(
    'valorMulta',
  );
  @override
  late final GeneratedColumn<double> valorMulta = GeneratedColumn<double>(
    'valor_multa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorDescontoMeta = const VerificationMeta(
    'valorDesconto',
  );
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
    'valor_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorPagoMeta = const VerificationMeta(
    'valorPago',
  );
  @override
  late final GeneratedColumn<double> valorPago = GeneratedColumn<double>(
    'valor_pago',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _historicoMeta = const VerificationMeta(
    'historico',
  );
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
    'historico',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idFinLancamentoPagar,
    idFinChequeEmitido,
    idFinStatusParcela,
    idFinTipoPagamento,
    numeroParcela,
    dataEmissao,
    dataVencimento,
    dataPagamento,
    descontoAte,
    valor,
    taxaJuro,
    taxaMulta,
    taxaDesconto,
    valorJuro,
    valorMulta,
    valorDesconto,
    valorPago,
    historico,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_parcela_pagar';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinParcelaPagar> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_fin_lancamento_pagar')) {
      context.handle(
        _idFinLancamentoPagarMeta,
        idFinLancamentoPagar.isAcceptableOrUnknown(
          data['id_fin_lancamento_pagar']!,
          _idFinLancamentoPagarMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_cheque_emitido')) {
      context.handle(
        _idFinChequeEmitidoMeta,
        idFinChequeEmitido.isAcceptableOrUnknown(
          data['id_fin_cheque_emitido']!,
          _idFinChequeEmitidoMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_status_parcela')) {
      context.handle(
        _idFinStatusParcelaMeta,
        idFinStatusParcela.isAcceptableOrUnknown(
          data['id_fin_status_parcela']!,
          _idFinStatusParcelaMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_tipo_pagamento')) {
      context.handle(
        _idFinTipoPagamentoMeta,
        idFinTipoPagamento.isAcceptableOrUnknown(
          data['id_fin_tipo_pagamento']!,
          _idFinTipoPagamentoMeta,
        ),
      );
    }
    if (data.containsKey('numero_parcela')) {
      context.handle(
        _numeroParcelaMeta,
        numeroParcela.isAcceptableOrUnknown(
          data['numero_parcela']!,
          _numeroParcelaMeta,
        ),
      );
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
        _dataVencimentoMeta,
        dataVencimento.isAcceptableOrUnknown(
          data['data_vencimento']!,
          _dataVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('data_pagamento')) {
      context.handle(
        _dataPagamentoMeta,
        dataPagamento.isAcceptableOrUnknown(
          data['data_pagamento']!,
          _dataPagamentoMeta,
        ),
      );
    }
    if (data.containsKey('desconto_ate')) {
      context.handle(
        _descontoAteMeta,
        descontoAte.isAcceptableOrUnknown(
          data['desconto_ate']!,
          _descontoAteMeta,
        ),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('taxa_juro')) {
      context.handle(
        _taxaJuroMeta,
        taxaJuro.isAcceptableOrUnknown(data['taxa_juro']!, _taxaJuroMeta),
      );
    }
    if (data.containsKey('taxa_multa')) {
      context.handle(
        _taxaMultaMeta,
        taxaMulta.isAcceptableOrUnknown(data['taxa_multa']!, _taxaMultaMeta),
      );
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
        _taxaDescontoMeta,
        taxaDesconto.isAcceptableOrUnknown(
          data['taxa_desconto']!,
          _taxaDescontoMeta,
        ),
      );
    }
    if (data.containsKey('valor_juro')) {
      context.handle(
        _valorJuroMeta,
        valorJuro.isAcceptableOrUnknown(data['valor_juro']!, _valorJuroMeta),
      );
    }
    if (data.containsKey('valor_multa')) {
      context.handle(
        _valorMultaMeta,
        valorMulta.isAcceptableOrUnknown(data['valor_multa']!, _valorMultaMeta),
      );
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
        _valorDescontoMeta,
        valorDesconto.isAcceptableOrUnknown(
          data['valor_desconto']!,
          _valorDescontoMeta,
        ),
      );
    }
    if (data.containsKey('valor_pago')) {
      context.handle(
        _valorPagoMeta,
        valorPago.isAcceptableOrUnknown(data['valor_pago']!, _valorPagoMeta),
      );
    }
    if (data.containsKey('historico')) {
      context.handle(
        _historicoMeta,
        historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinParcelaPagar map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinParcelaPagar(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idFinLancamentoPagar: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_lancamento_pagar'],
      ),
      idFinChequeEmitido: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_cheque_emitido'],
      ),
      idFinStatusParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_status_parcela'],
      ),
      idFinTipoPagamento: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_tipo_pagamento'],
      ),
      numeroParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}numero_parcela'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      dataVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_vencimento'],
      ),
      dataPagamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_pagamento'],
      ),
      descontoAte: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desconto_ate'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      taxaJuro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_juro'],
      ),
      taxaMulta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_multa'],
      ),
      taxaDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_desconto'],
      ),
      valorJuro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_juro'],
      ),
      valorMulta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_multa'],
      ),
      valorDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_desconto'],
      ),
      valorPago: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_pago'],
      ),
      historico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}historico'],
      ),
    );
  }

  @override
  $FinParcelaPagarsTable createAlias(String alias) {
    return $FinParcelaPagarsTable(attachedDatabase, alias);
  }
}

class FinParcelaPagar extends DataClass implements Insertable<FinParcelaPagar> {
  final int? id;
  final int? idFinLancamentoPagar;
  final int? idFinChequeEmitido;
  final int? idFinStatusParcela;
  final int? idFinTipoPagamento;
  final int? numeroParcela;
  final DateTime? dataEmissao;
  final DateTime? dataVencimento;
  final DateTime? dataPagamento;
  final DateTime? descontoAte;
  final double? valor;
  final double? taxaJuro;
  final double? taxaMulta;
  final double? taxaDesconto;
  final double? valorJuro;
  final double? valorMulta;
  final double? valorDesconto;
  final double? valorPago;
  final String? historico;
  const FinParcelaPagar({
    this.id,
    this.idFinLancamentoPagar,
    this.idFinChequeEmitido,
    this.idFinStatusParcela,
    this.idFinTipoPagamento,
    this.numeroParcela,
    this.dataEmissao,
    this.dataVencimento,
    this.dataPagamento,
    this.descontoAte,
    this.valor,
    this.taxaJuro,
    this.taxaMulta,
    this.taxaDesconto,
    this.valorJuro,
    this.valorMulta,
    this.valorDesconto,
    this.valorPago,
    this.historico,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFinLancamentoPagar != null) {
      map['id_fin_lancamento_pagar'] = Variable<int>(idFinLancamentoPagar);
    }
    if (!nullToAbsent || idFinChequeEmitido != null) {
      map['id_fin_cheque_emitido'] = Variable<int>(idFinChequeEmitido);
    }
    if (!nullToAbsent || idFinStatusParcela != null) {
      map['id_fin_status_parcela'] = Variable<int>(idFinStatusParcela);
    }
    if (!nullToAbsent || idFinTipoPagamento != null) {
      map['id_fin_tipo_pagamento'] = Variable<int>(idFinTipoPagamento);
    }
    if (!nullToAbsent || numeroParcela != null) {
      map['numero_parcela'] = Variable<int>(numeroParcela);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataPagamento != null) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento);
    }
    if (!nullToAbsent || descontoAte != null) {
      map['desconto_ate'] = Variable<DateTime>(descontoAte);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || taxaJuro != null) {
      map['taxa_juro'] = Variable<double>(taxaJuro);
    }
    if (!nullToAbsent || taxaMulta != null) {
      map['taxa_multa'] = Variable<double>(taxaMulta);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorJuro != null) {
      map['valor_juro'] = Variable<double>(valorJuro);
    }
    if (!nullToAbsent || valorMulta != null) {
      map['valor_multa'] = Variable<double>(valorMulta);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorPago != null) {
      map['valor_pago'] = Variable<double>(valorPago);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory FinParcelaPagar.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinParcelaPagar(
      id: serializer.fromJson<int?>(json['id']),
      idFinLancamentoPagar: serializer.fromJson<int?>(
        json['idFinLancamentoPagar'],
      ),
      idFinChequeEmitido: serializer.fromJson<int?>(json['idFinChequeEmitido']),
      idFinStatusParcela: serializer.fromJson<int?>(json['idFinStatusParcela']),
      idFinTipoPagamento: serializer.fromJson<int?>(json['idFinTipoPagamento']),
      numeroParcela: serializer.fromJson<int?>(json['numeroParcela']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataPagamento: serializer.fromJson<DateTime?>(json['dataPagamento']),
      descontoAte: serializer.fromJson<DateTime?>(json['descontoAte']),
      valor: serializer.fromJson<double?>(json['valor']),
      taxaJuro: serializer.fromJson<double?>(json['taxaJuro']),
      taxaMulta: serializer.fromJson<double?>(json['taxaMulta']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorJuro: serializer.fromJson<double?>(json['valorJuro']),
      valorMulta: serializer.fromJson<double?>(json['valorMulta']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorPago: serializer.fromJson<double?>(json['valorPago']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFinLancamentoPagar': serializer.toJson<int?>(idFinLancamentoPagar),
      'idFinChequeEmitido': serializer.toJson<int?>(idFinChequeEmitido),
      'idFinStatusParcela': serializer.toJson<int?>(idFinStatusParcela),
      'idFinTipoPagamento': serializer.toJson<int?>(idFinTipoPagamento),
      'numeroParcela': serializer.toJson<int?>(numeroParcela),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataPagamento': serializer.toJson<DateTime?>(dataPagamento),
      'descontoAte': serializer.toJson<DateTime?>(descontoAte),
      'valor': serializer.toJson<double?>(valor),
      'taxaJuro': serializer.toJson<double?>(taxaJuro),
      'taxaMulta': serializer.toJson<double?>(taxaMulta),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorJuro': serializer.toJson<double?>(valorJuro),
      'valorMulta': serializer.toJson<double?>(valorMulta),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorPago': serializer.toJson<double?>(valorPago),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  FinParcelaPagar copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idFinLancamentoPagar = const Value.absent(),
    Value<int?> idFinChequeEmitido = const Value.absent(),
    Value<int?> idFinStatusParcela = const Value.absent(),
    Value<int?> idFinTipoPagamento = const Value.absent(),
    Value<int?> numeroParcela = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> dataVencimento = const Value.absent(),
    Value<DateTime?> dataPagamento = const Value.absent(),
    Value<DateTime?> descontoAte = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<double?> taxaJuro = const Value.absent(),
    Value<double?> taxaMulta = const Value.absent(),
    Value<double?> taxaDesconto = const Value.absent(),
    Value<double?> valorJuro = const Value.absent(),
    Value<double?> valorMulta = const Value.absent(),
    Value<double?> valorDesconto = const Value.absent(),
    Value<double?> valorPago = const Value.absent(),
    Value<String?> historico = const Value.absent(),
  }) => FinParcelaPagar(
    id: id.present ? id.value : this.id,
    idFinLancamentoPagar:
        idFinLancamentoPagar.present
            ? idFinLancamentoPagar.value
            : this.idFinLancamentoPagar,
    idFinChequeEmitido:
        idFinChequeEmitido.present
            ? idFinChequeEmitido.value
            : this.idFinChequeEmitido,
    idFinStatusParcela:
        idFinStatusParcela.present
            ? idFinStatusParcela.value
            : this.idFinStatusParcela,
    idFinTipoPagamento:
        idFinTipoPagamento.present
            ? idFinTipoPagamento.value
            : this.idFinTipoPagamento,
    numeroParcela:
        numeroParcela.present ? numeroParcela.value : this.numeroParcela,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    dataVencimento:
        dataVencimento.present ? dataVencimento.value : this.dataVencimento,
    dataPagamento:
        dataPagamento.present ? dataPagamento.value : this.dataPagamento,
    descontoAte: descontoAte.present ? descontoAte.value : this.descontoAte,
    valor: valor.present ? valor.value : this.valor,
    taxaJuro: taxaJuro.present ? taxaJuro.value : this.taxaJuro,
    taxaMulta: taxaMulta.present ? taxaMulta.value : this.taxaMulta,
    taxaDesconto: taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
    valorJuro: valorJuro.present ? valorJuro.value : this.valorJuro,
    valorMulta: valorMulta.present ? valorMulta.value : this.valorMulta,
    valorDesconto:
        valorDesconto.present ? valorDesconto.value : this.valorDesconto,
    valorPago: valorPago.present ? valorPago.value : this.valorPago,
    historico: historico.present ? historico.value : this.historico,
  );
  FinParcelaPagar copyWithCompanion(FinParcelaPagarsCompanion data) {
    return FinParcelaPagar(
      id: data.id.present ? data.id.value : this.id,
      idFinLancamentoPagar:
          data.idFinLancamentoPagar.present
              ? data.idFinLancamentoPagar.value
              : this.idFinLancamentoPagar,
      idFinChequeEmitido:
          data.idFinChequeEmitido.present
              ? data.idFinChequeEmitido.value
              : this.idFinChequeEmitido,
      idFinStatusParcela:
          data.idFinStatusParcela.present
              ? data.idFinStatusParcela.value
              : this.idFinStatusParcela,
      idFinTipoPagamento:
          data.idFinTipoPagamento.present
              ? data.idFinTipoPagamento.value
              : this.idFinTipoPagamento,
      numeroParcela:
          data.numeroParcela.present
              ? data.numeroParcela.value
              : this.numeroParcela,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      dataVencimento:
          data.dataVencimento.present
              ? data.dataVencimento.value
              : this.dataVencimento,
      dataPagamento:
          data.dataPagamento.present
              ? data.dataPagamento.value
              : this.dataPagamento,
      descontoAte:
          data.descontoAte.present ? data.descontoAte.value : this.descontoAte,
      valor: data.valor.present ? data.valor.value : this.valor,
      taxaJuro: data.taxaJuro.present ? data.taxaJuro.value : this.taxaJuro,
      taxaMulta: data.taxaMulta.present ? data.taxaMulta.value : this.taxaMulta,
      taxaDesconto:
          data.taxaDesconto.present
              ? data.taxaDesconto.value
              : this.taxaDesconto,
      valorJuro: data.valorJuro.present ? data.valorJuro.value : this.valorJuro,
      valorMulta:
          data.valorMulta.present ? data.valorMulta.value : this.valorMulta,
      valorDesconto:
          data.valorDesconto.present
              ? data.valorDesconto.value
              : this.valorDesconto,
      valorPago: data.valorPago.present ? data.valorPago.value : this.valorPago,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinParcelaPagar(')
          ..write('id: $id, ')
          ..write('idFinLancamentoPagar: $idFinLancamentoPagar, ')
          ..write('idFinChequeEmitido: $idFinChequeEmitido, ')
          ..write('idFinStatusParcela: $idFinStatusParcela, ')
          ..write('idFinTipoPagamento: $idFinTipoPagamento, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('descontoAte: $descontoAte, ')
          ..write('valor: $valor, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorJuro: $valorJuro, ')
          ..write('valorMulta: $valorMulta, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorPago: $valorPago, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idFinLancamentoPagar,
    idFinChequeEmitido,
    idFinStatusParcela,
    idFinTipoPagamento,
    numeroParcela,
    dataEmissao,
    dataVencimento,
    dataPagamento,
    descontoAte,
    valor,
    taxaJuro,
    taxaMulta,
    taxaDesconto,
    valorJuro,
    valorMulta,
    valorDesconto,
    valorPago,
    historico,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinParcelaPagar &&
          other.id == this.id &&
          other.idFinLancamentoPagar == this.idFinLancamentoPagar &&
          other.idFinChequeEmitido == this.idFinChequeEmitido &&
          other.idFinStatusParcela == this.idFinStatusParcela &&
          other.idFinTipoPagamento == this.idFinTipoPagamento &&
          other.numeroParcela == this.numeroParcela &&
          other.dataEmissao == this.dataEmissao &&
          other.dataVencimento == this.dataVencimento &&
          other.dataPagamento == this.dataPagamento &&
          other.descontoAte == this.descontoAte &&
          other.valor == this.valor &&
          other.taxaJuro == this.taxaJuro &&
          other.taxaMulta == this.taxaMulta &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorJuro == this.valorJuro &&
          other.valorMulta == this.valorMulta &&
          other.valorDesconto == this.valorDesconto &&
          other.valorPago == this.valorPago &&
          other.historico == this.historico);
}

class FinParcelaPagarsCompanion extends UpdateCompanion<FinParcelaPagar> {
  final Value<int?> id;
  final Value<int?> idFinLancamentoPagar;
  final Value<int?> idFinChequeEmitido;
  final Value<int?> idFinStatusParcela;
  final Value<int?> idFinTipoPagamento;
  final Value<int?> numeroParcela;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataPagamento;
  final Value<DateTime?> descontoAte;
  final Value<double?> valor;
  final Value<double?> taxaJuro;
  final Value<double?> taxaMulta;
  final Value<double?> taxaDesconto;
  final Value<double?> valorJuro;
  final Value<double?> valorMulta;
  final Value<double?> valorDesconto;
  final Value<double?> valorPago;
  final Value<String?> historico;
  const FinParcelaPagarsCompanion({
    this.id = const Value.absent(),
    this.idFinLancamentoPagar = const Value.absent(),
    this.idFinChequeEmitido = const Value.absent(),
    this.idFinStatusParcela = const Value.absent(),
    this.idFinTipoPagamento = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.descontoAte = const Value.absent(),
    this.valor = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorJuro = const Value.absent(),
    this.valorMulta = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorPago = const Value.absent(),
    this.historico = const Value.absent(),
  });
  FinParcelaPagarsCompanion.insert({
    this.id = const Value.absent(),
    this.idFinLancamentoPagar = const Value.absent(),
    this.idFinChequeEmitido = const Value.absent(),
    this.idFinStatusParcela = const Value.absent(),
    this.idFinTipoPagamento = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.descontoAte = const Value.absent(),
    this.valor = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorJuro = const Value.absent(),
    this.valorMulta = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorPago = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<FinParcelaPagar> custom({
    Expression<int>? id,
    Expression<int>? idFinLancamentoPagar,
    Expression<int>? idFinChequeEmitido,
    Expression<int>? idFinStatusParcela,
    Expression<int>? idFinTipoPagamento,
    Expression<int>? numeroParcela,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataPagamento,
    Expression<DateTime>? descontoAte,
    Expression<double>? valor,
    Expression<double>? taxaJuro,
    Expression<double>? taxaMulta,
    Expression<double>? taxaDesconto,
    Expression<double>? valorJuro,
    Expression<double>? valorMulta,
    Expression<double>? valorDesconto,
    Expression<double>? valorPago,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFinLancamentoPagar != null)
        'id_fin_lancamento_pagar': idFinLancamentoPagar,
      if (idFinChequeEmitido != null)
        'id_fin_cheque_emitido': idFinChequeEmitido,
      if (idFinStatusParcela != null)
        'id_fin_status_parcela': idFinStatusParcela,
      if (idFinTipoPagamento != null)
        'id_fin_tipo_pagamento': idFinTipoPagamento,
      if (numeroParcela != null) 'numero_parcela': numeroParcela,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataPagamento != null) 'data_pagamento': dataPagamento,
      if (descontoAte != null) 'desconto_ate': descontoAte,
      if (valor != null) 'valor': valor,
      if (taxaJuro != null) 'taxa_juro': taxaJuro,
      if (taxaMulta != null) 'taxa_multa': taxaMulta,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorJuro != null) 'valor_juro': valorJuro,
      if (valorMulta != null) 'valor_multa': valorMulta,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorPago != null) 'valor_pago': valorPago,
      if (historico != null) 'historico': historico,
    });
  }

  FinParcelaPagarsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idFinLancamentoPagar,
    Value<int?>? idFinChequeEmitido,
    Value<int?>? idFinStatusParcela,
    Value<int?>? idFinTipoPagamento,
    Value<int?>? numeroParcela,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? dataVencimento,
    Value<DateTime?>? dataPagamento,
    Value<DateTime?>? descontoAte,
    Value<double?>? valor,
    Value<double?>? taxaJuro,
    Value<double?>? taxaMulta,
    Value<double?>? taxaDesconto,
    Value<double?>? valorJuro,
    Value<double?>? valorMulta,
    Value<double?>? valorDesconto,
    Value<double?>? valorPago,
    Value<String?>? historico,
  }) {
    return FinParcelaPagarsCompanion(
      id: id ?? this.id,
      idFinLancamentoPagar: idFinLancamentoPagar ?? this.idFinLancamentoPagar,
      idFinChequeEmitido: idFinChequeEmitido ?? this.idFinChequeEmitido,
      idFinStatusParcela: idFinStatusParcela ?? this.idFinStatusParcela,
      idFinTipoPagamento: idFinTipoPagamento ?? this.idFinTipoPagamento,
      numeroParcela: numeroParcela ?? this.numeroParcela,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataPagamento: dataPagamento ?? this.dataPagamento,
      descontoAte: descontoAte ?? this.descontoAte,
      valor: valor ?? this.valor,
      taxaJuro: taxaJuro ?? this.taxaJuro,
      taxaMulta: taxaMulta ?? this.taxaMulta,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorJuro: valorJuro ?? this.valorJuro,
      valorMulta: valorMulta ?? this.valorMulta,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorPago: valorPago ?? this.valorPago,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFinLancamentoPagar.present) {
      map['id_fin_lancamento_pagar'] = Variable<int>(
        idFinLancamentoPagar.value,
      );
    }
    if (idFinChequeEmitido.present) {
      map['id_fin_cheque_emitido'] = Variable<int>(idFinChequeEmitido.value);
    }
    if (idFinStatusParcela.present) {
      map['id_fin_status_parcela'] = Variable<int>(idFinStatusParcela.value);
    }
    if (idFinTipoPagamento.present) {
      map['id_fin_tipo_pagamento'] = Variable<int>(idFinTipoPagamento.value);
    }
    if (numeroParcela.present) {
      map['numero_parcela'] = Variable<int>(numeroParcela.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataPagamento.present) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento.value);
    }
    if (descontoAte.present) {
      map['desconto_ate'] = Variable<DateTime>(descontoAte.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (taxaJuro.present) {
      map['taxa_juro'] = Variable<double>(taxaJuro.value);
    }
    if (taxaMulta.present) {
      map['taxa_multa'] = Variable<double>(taxaMulta.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorJuro.present) {
      map['valor_juro'] = Variable<double>(valorJuro.value);
    }
    if (valorMulta.present) {
      map['valor_multa'] = Variable<double>(valorMulta.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorPago.present) {
      map['valor_pago'] = Variable<double>(valorPago.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinParcelaPagarsCompanion(')
          ..write('id: $id, ')
          ..write('idFinLancamentoPagar: $idFinLancamentoPagar, ')
          ..write('idFinChequeEmitido: $idFinChequeEmitido, ')
          ..write('idFinStatusParcela: $idFinStatusParcela, ')
          ..write('idFinTipoPagamento: $idFinTipoPagamento, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('descontoAte: $descontoAte, ')
          ..write('valor: $valor, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorJuro: $valorJuro, ')
          ..write('valorMulta: $valorMulta, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorPago: $valorPago, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $FinParcelaRecebersTable extends FinParcelaRecebers
    with TableInfo<$FinParcelaRecebersTable, FinParcelaReceber> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinParcelaRecebersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinLancamentoReceberMeta =
      const VerificationMeta('idFinLancamentoReceber');
  @override
  late final GeneratedColumn<int> idFinLancamentoReceber = GeneratedColumn<int>(
    'id_fin_lancamento_receber',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinChequeRecebidoMeta =
      const VerificationMeta('idFinChequeRecebido');
  @override
  late final GeneratedColumn<int> idFinChequeRecebido = GeneratedColumn<int>(
    'id_fin_cheque_recebido',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinStatusParcelaMeta =
      const VerificationMeta('idFinStatusParcela');
  @override
  late final GeneratedColumn<int> idFinStatusParcela = GeneratedColumn<int>(
    'id_fin_status_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinTipoRecebimentoMeta =
      const VerificationMeta('idFinTipoRecebimento');
  @override
  late final GeneratedColumn<int> idFinTipoRecebimento = GeneratedColumn<int>(
    'id_fin_tipo_recebimento',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroParcelaMeta = const VerificationMeta(
    'numeroParcela',
  );
  @override
  late final GeneratedColumn<int> numeroParcela = GeneratedColumn<int>(
    'numero_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataVencimentoMeta = const VerificationMeta(
    'dataVencimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>(
        'data_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataRecebimentoMeta = const VerificationMeta(
    'dataRecebimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataRecebimento =
      GeneratedColumn<DateTime>(
        'data_recebimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _descontoAteMeta = const VerificationMeta(
    'descontoAte',
  );
  @override
  late final GeneratedColumn<DateTime> descontoAte = GeneratedColumn<DateTime>(
    'desconto_ate',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaJuroMeta = const VerificationMeta(
    'taxaJuro',
  );
  @override
  late final GeneratedColumn<double> taxaJuro = GeneratedColumn<double>(
    'taxa_juro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaMultaMeta = const VerificationMeta(
    'taxaMulta',
  );
  @override
  late final GeneratedColumn<double> taxaMulta = GeneratedColumn<double>(
    'taxa_multa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaDescontoMeta = const VerificationMeta(
    'taxaDesconto',
  );
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
    'taxa_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorJuroMeta = const VerificationMeta(
    'valorJuro',
  );
  @override
  late final GeneratedColumn<double> valorJuro = GeneratedColumn<double>(
    'valor_juro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMultaMeta = const VerificationMeta(
    'valorMulta',
  );
  @override
  late final GeneratedColumn<double> valorMulta = GeneratedColumn<double>(
    'valor_multa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorDescontoMeta = const VerificationMeta(
    'valorDesconto',
  );
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
    'valor_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emitiuBoletoMeta = const VerificationMeta(
    'emitiuBoleto',
  );
  @override
  late final GeneratedColumn<String> emitiuBoleto = GeneratedColumn<String>(
    'emitiu_boleto',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _boletoNossoNumeroMeta = const VerificationMeta(
    'boletoNossoNumero',
  );
  @override
  late final GeneratedColumn<String> boletoNossoNumero =
      GeneratedColumn<String>(
        'boleto_nosso_numero',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 50,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _valorRecebidoMeta = const VerificationMeta(
    'valorRecebido',
  );
  @override
  late final GeneratedColumn<double> valorRecebido = GeneratedColumn<double>(
    'valor_recebido',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _historicoMeta = const VerificationMeta(
    'historico',
  );
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
    'historico',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idFinLancamentoReceber,
    idFinChequeRecebido,
    idFinStatusParcela,
    idFinTipoRecebimento,
    numeroParcela,
    dataEmissao,
    dataVencimento,
    dataRecebimento,
    descontoAte,
    valor,
    taxaJuro,
    taxaMulta,
    taxaDesconto,
    valorJuro,
    valorMulta,
    valorDesconto,
    emitiuBoleto,
    boletoNossoNumero,
    valorRecebido,
    historico,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_parcela_receber';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinParcelaReceber> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_fin_lancamento_receber')) {
      context.handle(
        _idFinLancamentoReceberMeta,
        idFinLancamentoReceber.isAcceptableOrUnknown(
          data['id_fin_lancamento_receber']!,
          _idFinLancamentoReceberMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_cheque_recebido')) {
      context.handle(
        _idFinChequeRecebidoMeta,
        idFinChequeRecebido.isAcceptableOrUnknown(
          data['id_fin_cheque_recebido']!,
          _idFinChequeRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_status_parcela')) {
      context.handle(
        _idFinStatusParcelaMeta,
        idFinStatusParcela.isAcceptableOrUnknown(
          data['id_fin_status_parcela']!,
          _idFinStatusParcelaMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_tipo_recebimento')) {
      context.handle(
        _idFinTipoRecebimentoMeta,
        idFinTipoRecebimento.isAcceptableOrUnknown(
          data['id_fin_tipo_recebimento']!,
          _idFinTipoRecebimentoMeta,
        ),
      );
    }
    if (data.containsKey('numero_parcela')) {
      context.handle(
        _numeroParcelaMeta,
        numeroParcela.isAcceptableOrUnknown(
          data['numero_parcela']!,
          _numeroParcelaMeta,
        ),
      );
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
        _dataVencimentoMeta,
        dataVencimento.isAcceptableOrUnknown(
          data['data_vencimento']!,
          _dataVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('data_recebimento')) {
      context.handle(
        _dataRecebimentoMeta,
        dataRecebimento.isAcceptableOrUnknown(
          data['data_recebimento']!,
          _dataRecebimentoMeta,
        ),
      );
    }
    if (data.containsKey('desconto_ate')) {
      context.handle(
        _descontoAteMeta,
        descontoAte.isAcceptableOrUnknown(
          data['desconto_ate']!,
          _descontoAteMeta,
        ),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('taxa_juro')) {
      context.handle(
        _taxaJuroMeta,
        taxaJuro.isAcceptableOrUnknown(data['taxa_juro']!, _taxaJuroMeta),
      );
    }
    if (data.containsKey('taxa_multa')) {
      context.handle(
        _taxaMultaMeta,
        taxaMulta.isAcceptableOrUnknown(data['taxa_multa']!, _taxaMultaMeta),
      );
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
        _taxaDescontoMeta,
        taxaDesconto.isAcceptableOrUnknown(
          data['taxa_desconto']!,
          _taxaDescontoMeta,
        ),
      );
    }
    if (data.containsKey('valor_juro')) {
      context.handle(
        _valorJuroMeta,
        valorJuro.isAcceptableOrUnknown(data['valor_juro']!, _valorJuroMeta),
      );
    }
    if (data.containsKey('valor_multa')) {
      context.handle(
        _valorMultaMeta,
        valorMulta.isAcceptableOrUnknown(data['valor_multa']!, _valorMultaMeta),
      );
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
        _valorDescontoMeta,
        valorDesconto.isAcceptableOrUnknown(
          data['valor_desconto']!,
          _valorDescontoMeta,
        ),
      );
    }
    if (data.containsKey('emitiu_boleto')) {
      context.handle(
        _emitiuBoletoMeta,
        emitiuBoleto.isAcceptableOrUnknown(
          data['emitiu_boleto']!,
          _emitiuBoletoMeta,
        ),
      );
    }
    if (data.containsKey('boleto_nosso_numero')) {
      context.handle(
        _boletoNossoNumeroMeta,
        boletoNossoNumero.isAcceptableOrUnknown(
          data['boleto_nosso_numero']!,
          _boletoNossoNumeroMeta,
        ),
      );
    }
    if (data.containsKey('valor_recebido')) {
      context.handle(
        _valorRecebidoMeta,
        valorRecebido.isAcceptableOrUnknown(
          data['valor_recebido']!,
          _valorRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('historico')) {
      context.handle(
        _historicoMeta,
        historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinParcelaReceber map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinParcelaReceber(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idFinLancamentoReceber: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_lancamento_receber'],
      ),
      idFinChequeRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_cheque_recebido'],
      ),
      idFinStatusParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_status_parcela'],
      ),
      idFinTipoRecebimento: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_tipo_recebimento'],
      ),
      numeroParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}numero_parcela'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      dataVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_vencimento'],
      ),
      dataRecebimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_recebimento'],
      ),
      descontoAte: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desconto_ate'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      taxaJuro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_juro'],
      ),
      taxaMulta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_multa'],
      ),
      taxaDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_desconto'],
      ),
      valorJuro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_juro'],
      ),
      valorMulta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_multa'],
      ),
      valorDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_desconto'],
      ),
      emitiuBoleto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}emitiu_boleto'],
      ),
      boletoNossoNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}boleto_nosso_numero'],
      ),
      valorRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_recebido'],
      ),
      historico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}historico'],
      ),
    );
  }

  @override
  $FinParcelaRecebersTable createAlias(String alias) {
    return $FinParcelaRecebersTable(attachedDatabase, alias);
  }
}

class FinParcelaReceber extends DataClass
    implements Insertable<FinParcelaReceber> {
  final int? id;
  final int? idFinLancamentoReceber;
  final int? idFinChequeRecebido;
  final int? idFinStatusParcela;
  final int? idFinTipoRecebimento;
  final int? numeroParcela;
  final DateTime? dataEmissao;
  final DateTime? dataVencimento;
  final DateTime? dataRecebimento;
  final DateTime? descontoAte;
  final double? valor;
  final double? taxaJuro;
  final double? taxaMulta;
  final double? taxaDesconto;
  final double? valorJuro;
  final double? valorMulta;
  final double? valorDesconto;
  final String? emitiuBoleto;
  final String? boletoNossoNumero;
  final double? valorRecebido;
  final String? historico;
  const FinParcelaReceber({
    this.id,
    this.idFinLancamentoReceber,
    this.idFinChequeRecebido,
    this.idFinStatusParcela,
    this.idFinTipoRecebimento,
    this.numeroParcela,
    this.dataEmissao,
    this.dataVencimento,
    this.dataRecebimento,
    this.descontoAte,
    this.valor,
    this.taxaJuro,
    this.taxaMulta,
    this.taxaDesconto,
    this.valorJuro,
    this.valorMulta,
    this.valorDesconto,
    this.emitiuBoleto,
    this.boletoNossoNumero,
    this.valorRecebido,
    this.historico,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFinLancamentoReceber != null) {
      map['id_fin_lancamento_receber'] = Variable<int>(idFinLancamentoReceber);
    }
    if (!nullToAbsent || idFinChequeRecebido != null) {
      map['id_fin_cheque_recebido'] = Variable<int>(idFinChequeRecebido);
    }
    if (!nullToAbsent || idFinStatusParcela != null) {
      map['id_fin_status_parcela'] = Variable<int>(idFinStatusParcela);
    }
    if (!nullToAbsent || idFinTipoRecebimento != null) {
      map['id_fin_tipo_recebimento'] = Variable<int>(idFinTipoRecebimento);
    }
    if (!nullToAbsent || numeroParcela != null) {
      map['numero_parcela'] = Variable<int>(numeroParcela);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataRecebimento != null) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento);
    }
    if (!nullToAbsent || descontoAte != null) {
      map['desconto_ate'] = Variable<DateTime>(descontoAte);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || taxaJuro != null) {
      map['taxa_juro'] = Variable<double>(taxaJuro);
    }
    if (!nullToAbsent || taxaMulta != null) {
      map['taxa_multa'] = Variable<double>(taxaMulta);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorJuro != null) {
      map['valor_juro'] = Variable<double>(valorJuro);
    }
    if (!nullToAbsent || valorMulta != null) {
      map['valor_multa'] = Variable<double>(valorMulta);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || emitiuBoleto != null) {
      map['emitiu_boleto'] = Variable<String>(emitiuBoleto);
    }
    if (!nullToAbsent || boletoNossoNumero != null) {
      map['boleto_nosso_numero'] = Variable<String>(boletoNossoNumero);
    }
    if (!nullToAbsent || valorRecebido != null) {
      map['valor_recebido'] = Variable<double>(valorRecebido);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory FinParcelaReceber.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinParcelaReceber(
      id: serializer.fromJson<int?>(json['id']),
      idFinLancamentoReceber: serializer.fromJson<int?>(
        json['idFinLancamentoReceber'],
      ),
      idFinChequeRecebido: serializer.fromJson<int?>(
        json['idFinChequeRecebido'],
      ),
      idFinStatusParcela: serializer.fromJson<int?>(json['idFinStatusParcela']),
      idFinTipoRecebimento: serializer.fromJson<int?>(
        json['idFinTipoRecebimento'],
      ),
      numeroParcela: serializer.fromJson<int?>(json['numeroParcela']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataRecebimento: serializer.fromJson<DateTime?>(json['dataRecebimento']),
      descontoAte: serializer.fromJson<DateTime?>(json['descontoAte']),
      valor: serializer.fromJson<double?>(json['valor']),
      taxaJuro: serializer.fromJson<double?>(json['taxaJuro']),
      taxaMulta: serializer.fromJson<double?>(json['taxaMulta']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorJuro: serializer.fromJson<double?>(json['valorJuro']),
      valorMulta: serializer.fromJson<double?>(json['valorMulta']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      emitiuBoleto: serializer.fromJson<String?>(json['emitiuBoleto']),
      boletoNossoNumero: serializer.fromJson<String?>(
        json['boletoNossoNumero'],
      ),
      valorRecebido: serializer.fromJson<double?>(json['valorRecebido']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFinLancamentoReceber': serializer.toJson<int?>(idFinLancamentoReceber),
      'idFinChequeRecebido': serializer.toJson<int?>(idFinChequeRecebido),
      'idFinStatusParcela': serializer.toJson<int?>(idFinStatusParcela),
      'idFinTipoRecebimento': serializer.toJson<int?>(idFinTipoRecebimento),
      'numeroParcela': serializer.toJson<int?>(numeroParcela),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataRecebimento': serializer.toJson<DateTime?>(dataRecebimento),
      'descontoAte': serializer.toJson<DateTime?>(descontoAte),
      'valor': serializer.toJson<double?>(valor),
      'taxaJuro': serializer.toJson<double?>(taxaJuro),
      'taxaMulta': serializer.toJson<double?>(taxaMulta),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorJuro': serializer.toJson<double?>(valorJuro),
      'valorMulta': serializer.toJson<double?>(valorMulta),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'emitiuBoleto': serializer.toJson<String?>(emitiuBoleto),
      'boletoNossoNumero': serializer.toJson<String?>(boletoNossoNumero),
      'valorRecebido': serializer.toJson<double?>(valorRecebido),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  FinParcelaReceber copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idFinLancamentoReceber = const Value.absent(),
    Value<int?> idFinChequeRecebido = const Value.absent(),
    Value<int?> idFinStatusParcela = const Value.absent(),
    Value<int?> idFinTipoRecebimento = const Value.absent(),
    Value<int?> numeroParcela = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> dataVencimento = const Value.absent(),
    Value<DateTime?> dataRecebimento = const Value.absent(),
    Value<DateTime?> descontoAte = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<double?> taxaJuro = const Value.absent(),
    Value<double?> taxaMulta = const Value.absent(),
    Value<double?> taxaDesconto = const Value.absent(),
    Value<double?> valorJuro = const Value.absent(),
    Value<double?> valorMulta = const Value.absent(),
    Value<double?> valorDesconto = const Value.absent(),
    Value<String?> emitiuBoleto = const Value.absent(),
    Value<String?> boletoNossoNumero = const Value.absent(),
    Value<double?> valorRecebido = const Value.absent(),
    Value<String?> historico = const Value.absent(),
  }) => FinParcelaReceber(
    id: id.present ? id.value : this.id,
    idFinLancamentoReceber:
        idFinLancamentoReceber.present
            ? idFinLancamentoReceber.value
            : this.idFinLancamentoReceber,
    idFinChequeRecebido:
        idFinChequeRecebido.present
            ? idFinChequeRecebido.value
            : this.idFinChequeRecebido,
    idFinStatusParcela:
        idFinStatusParcela.present
            ? idFinStatusParcela.value
            : this.idFinStatusParcela,
    idFinTipoRecebimento:
        idFinTipoRecebimento.present
            ? idFinTipoRecebimento.value
            : this.idFinTipoRecebimento,
    numeroParcela:
        numeroParcela.present ? numeroParcela.value : this.numeroParcela,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    dataVencimento:
        dataVencimento.present ? dataVencimento.value : this.dataVencimento,
    dataRecebimento:
        dataRecebimento.present ? dataRecebimento.value : this.dataRecebimento,
    descontoAte: descontoAte.present ? descontoAte.value : this.descontoAte,
    valor: valor.present ? valor.value : this.valor,
    taxaJuro: taxaJuro.present ? taxaJuro.value : this.taxaJuro,
    taxaMulta: taxaMulta.present ? taxaMulta.value : this.taxaMulta,
    taxaDesconto: taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
    valorJuro: valorJuro.present ? valorJuro.value : this.valorJuro,
    valorMulta: valorMulta.present ? valorMulta.value : this.valorMulta,
    valorDesconto:
        valorDesconto.present ? valorDesconto.value : this.valorDesconto,
    emitiuBoleto: emitiuBoleto.present ? emitiuBoleto.value : this.emitiuBoleto,
    boletoNossoNumero:
        boletoNossoNumero.present
            ? boletoNossoNumero.value
            : this.boletoNossoNumero,
    valorRecebido:
        valorRecebido.present ? valorRecebido.value : this.valorRecebido,
    historico: historico.present ? historico.value : this.historico,
  );
  FinParcelaReceber copyWithCompanion(FinParcelaRecebersCompanion data) {
    return FinParcelaReceber(
      id: data.id.present ? data.id.value : this.id,
      idFinLancamentoReceber:
          data.idFinLancamentoReceber.present
              ? data.idFinLancamentoReceber.value
              : this.idFinLancamentoReceber,
      idFinChequeRecebido:
          data.idFinChequeRecebido.present
              ? data.idFinChequeRecebido.value
              : this.idFinChequeRecebido,
      idFinStatusParcela:
          data.idFinStatusParcela.present
              ? data.idFinStatusParcela.value
              : this.idFinStatusParcela,
      idFinTipoRecebimento:
          data.idFinTipoRecebimento.present
              ? data.idFinTipoRecebimento.value
              : this.idFinTipoRecebimento,
      numeroParcela:
          data.numeroParcela.present
              ? data.numeroParcela.value
              : this.numeroParcela,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      dataVencimento:
          data.dataVencimento.present
              ? data.dataVencimento.value
              : this.dataVencimento,
      dataRecebimento:
          data.dataRecebimento.present
              ? data.dataRecebimento.value
              : this.dataRecebimento,
      descontoAte:
          data.descontoAte.present ? data.descontoAte.value : this.descontoAte,
      valor: data.valor.present ? data.valor.value : this.valor,
      taxaJuro: data.taxaJuro.present ? data.taxaJuro.value : this.taxaJuro,
      taxaMulta: data.taxaMulta.present ? data.taxaMulta.value : this.taxaMulta,
      taxaDesconto:
          data.taxaDesconto.present
              ? data.taxaDesconto.value
              : this.taxaDesconto,
      valorJuro: data.valorJuro.present ? data.valorJuro.value : this.valorJuro,
      valorMulta:
          data.valorMulta.present ? data.valorMulta.value : this.valorMulta,
      valorDesconto:
          data.valorDesconto.present
              ? data.valorDesconto.value
              : this.valorDesconto,
      emitiuBoleto:
          data.emitiuBoleto.present
              ? data.emitiuBoleto.value
              : this.emitiuBoleto,
      boletoNossoNumero:
          data.boletoNossoNumero.present
              ? data.boletoNossoNumero.value
              : this.boletoNossoNumero,
      valorRecebido:
          data.valorRecebido.present
              ? data.valorRecebido.value
              : this.valorRecebido,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinParcelaReceber(')
          ..write('id: $id, ')
          ..write('idFinLancamentoReceber: $idFinLancamentoReceber, ')
          ..write('idFinChequeRecebido: $idFinChequeRecebido, ')
          ..write('idFinStatusParcela: $idFinStatusParcela, ')
          ..write('idFinTipoRecebimento: $idFinTipoRecebimento, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('descontoAte: $descontoAte, ')
          ..write('valor: $valor, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorJuro: $valorJuro, ')
          ..write('valorMulta: $valorMulta, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('emitiuBoleto: $emitiuBoleto, ')
          ..write('boletoNossoNumero: $boletoNossoNumero, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    idFinLancamentoReceber,
    idFinChequeRecebido,
    idFinStatusParcela,
    idFinTipoRecebimento,
    numeroParcela,
    dataEmissao,
    dataVencimento,
    dataRecebimento,
    descontoAte,
    valor,
    taxaJuro,
    taxaMulta,
    taxaDesconto,
    valorJuro,
    valorMulta,
    valorDesconto,
    emitiuBoleto,
    boletoNossoNumero,
    valorRecebido,
    historico,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinParcelaReceber &&
          other.id == this.id &&
          other.idFinLancamentoReceber == this.idFinLancamentoReceber &&
          other.idFinChequeRecebido == this.idFinChequeRecebido &&
          other.idFinStatusParcela == this.idFinStatusParcela &&
          other.idFinTipoRecebimento == this.idFinTipoRecebimento &&
          other.numeroParcela == this.numeroParcela &&
          other.dataEmissao == this.dataEmissao &&
          other.dataVencimento == this.dataVencimento &&
          other.dataRecebimento == this.dataRecebimento &&
          other.descontoAte == this.descontoAte &&
          other.valor == this.valor &&
          other.taxaJuro == this.taxaJuro &&
          other.taxaMulta == this.taxaMulta &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorJuro == this.valorJuro &&
          other.valorMulta == this.valorMulta &&
          other.valorDesconto == this.valorDesconto &&
          other.emitiuBoleto == this.emitiuBoleto &&
          other.boletoNossoNumero == this.boletoNossoNumero &&
          other.valorRecebido == this.valorRecebido &&
          other.historico == this.historico);
}

class FinParcelaRecebersCompanion extends UpdateCompanion<FinParcelaReceber> {
  final Value<int?> id;
  final Value<int?> idFinLancamentoReceber;
  final Value<int?> idFinChequeRecebido;
  final Value<int?> idFinStatusParcela;
  final Value<int?> idFinTipoRecebimento;
  final Value<int?> numeroParcela;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataRecebimento;
  final Value<DateTime?> descontoAte;
  final Value<double?> valor;
  final Value<double?> taxaJuro;
  final Value<double?> taxaMulta;
  final Value<double?> taxaDesconto;
  final Value<double?> valorJuro;
  final Value<double?> valorMulta;
  final Value<double?> valorDesconto;
  final Value<String?> emitiuBoleto;
  final Value<String?> boletoNossoNumero;
  final Value<double?> valorRecebido;
  final Value<String?> historico;
  const FinParcelaRecebersCompanion({
    this.id = const Value.absent(),
    this.idFinLancamentoReceber = const Value.absent(),
    this.idFinChequeRecebido = const Value.absent(),
    this.idFinStatusParcela = const Value.absent(),
    this.idFinTipoRecebimento = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.descontoAte = const Value.absent(),
    this.valor = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorJuro = const Value.absent(),
    this.valorMulta = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.emitiuBoleto = const Value.absent(),
    this.boletoNossoNumero = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.historico = const Value.absent(),
  });
  FinParcelaRecebersCompanion.insert({
    this.id = const Value.absent(),
    this.idFinLancamentoReceber = const Value.absent(),
    this.idFinChequeRecebido = const Value.absent(),
    this.idFinStatusParcela = const Value.absent(),
    this.idFinTipoRecebimento = const Value.absent(),
    this.numeroParcela = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.descontoAte = const Value.absent(),
    this.valor = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorJuro = const Value.absent(),
    this.valorMulta = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.emitiuBoleto = const Value.absent(),
    this.boletoNossoNumero = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<FinParcelaReceber> custom({
    Expression<int>? id,
    Expression<int>? idFinLancamentoReceber,
    Expression<int>? idFinChequeRecebido,
    Expression<int>? idFinStatusParcela,
    Expression<int>? idFinTipoRecebimento,
    Expression<int>? numeroParcela,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataRecebimento,
    Expression<DateTime>? descontoAte,
    Expression<double>? valor,
    Expression<double>? taxaJuro,
    Expression<double>? taxaMulta,
    Expression<double>? taxaDesconto,
    Expression<double>? valorJuro,
    Expression<double>? valorMulta,
    Expression<double>? valorDesconto,
    Expression<String>? emitiuBoleto,
    Expression<String>? boletoNossoNumero,
    Expression<double>? valorRecebido,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFinLancamentoReceber != null)
        'id_fin_lancamento_receber': idFinLancamentoReceber,
      if (idFinChequeRecebido != null)
        'id_fin_cheque_recebido': idFinChequeRecebido,
      if (idFinStatusParcela != null)
        'id_fin_status_parcela': idFinStatusParcela,
      if (idFinTipoRecebimento != null)
        'id_fin_tipo_recebimento': idFinTipoRecebimento,
      if (numeroParcela != null) 'numero_parcela': numeroParcela,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataRecebimento != null) 'data_recebimento': dataRecebimento,
      if (descontoAte != null) 'desconto_ate': descontoAte,
      if (valor != null) 'valor': valor,
      if (taxaJuro != null) 'taxa_juro': taxaJuro,
      if (taxaMulta != null) 'taxa_multa': taxaMulta,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorJuro != null) 'valor_juro': valorJuro,
      if (valorMulta != null) 'valor_multa': valorMulta,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (emitiuBoleto != null) 'emitiu_boleto': emitiuBoleto,
      if (boletoNossoNumero != null) 'boleto_nosso_numero': boletoNossoNumero,
      if (valorRecebido != null) 'valor_recebido': valorRecebido,
      if (historico != null) 'historico': historico,
    });
  }

  FinParcelaRecebersCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idFinLancamentoReceber,
    Value<int?>? idFinChequeRecebido,
    Value<int?>? idFinStatusParcela,
    Value<int?>? idFinTipoRecebimento,
    Value<int?>? numeroParcela,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? dataVencimento,
    Value<DateTime?>? dataRecebimento,
    Value<DateTime?>? descontoAte,
    Value<double?>? valor,
    Value<double?>? taxaJuro,
    Value<double?>? taxaMulta,
    Value<double?>? taxaDesconto,
    Value<double?>? valorJuro,
    Value<double?>? valorMulta,
    Value<double?>? valorDesconto,
    Value<String?>? emitiuBoleto,
    Value<String?>? boletoNossoNumero,
    Value<double?>? valorRecebido,
    Value<String?>? historico,
  }) {
    return FinParcelaRecebersCompanion(
      id: id ?? this.id,
      idFinLancamentoReceber:
          idFinLancamentoReceber ?? this.idFinLancamentoReceber,
      idFinChequeRecebido: idFinChequeRecebido ?? this.idFinChequeRecebido,
      idFinStatusParcela: idFinStatusParcela ?? this.idFinStatusParcela,
      idFinTipoRecebimento: idFinTipoRecebimento ?? this.idFinTipoRecebimento,
      numeroParcela: numeroParcela ?? this.numeroParcela,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataRecebimento: dataRecebimento ?? this.dataRecebimento,
      descontoAte: descontoAte ?? this.descontoAte,
      valor: valor ?? this.valor,
      taxaJuro: taxaJuro ?? this.taxaJuro,
      taxaMulta: taxaMulta ?? this.taxaMulta,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorJuro: valorJuro ?? this.valorJuro,
      valorMulta: valorMulta ?? this.valorMulta,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      emitiuBoleto: emitiuBoleto ?? this.emitiuBoleto,
      boletoNossoNumero: boletoNossoNumero ?? this.boletoNossoNumero,
      valorRecebido: valorRecebido ?? this.valorRecebido,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFinLancamentoReceber.present) {
      map['id_fin_lancamento_receber'] = Variable<int>(
        idFinLancamentoReceber.value,
      );
    }
    if (idFinChequeRecebido.present) {
      map['id_fin_cheque_recebido'] = Variable<int>(idFinChequeRecebido.value);
    }
    if (idFinStatusParcela.present) {
      map['id_fin_status_parcela'] = Variable<int>(idFinStatusParcela.value);
    }
    if (idFinTipoRecebimento.present) {
      map['id_fin_tipo_recebimento'] = Variable<int>(
        idFinTipoRecebimento.value,
      );
    }
    if (numeroParcela.present) {
      map['numero_parcela'] = Variable<int>(numeroParcela.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataRecebimento.present) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento.value);
    }
    if (descontoAte.present) {
      map['desconto_ate'] = Variable<DateTime>(descontoAte.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (taxaJuro.present) {
      map['taxa_juro'] = Variable<double>(taxaJuro.value);
    }
    if (taxaMulta.present) {
      map['taxa_multa'] = Variable<double>(taxaMulta.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorJuro.present) {
      map['valor_juro'] = Variable<double>(valorJuro.value);
    }
    if (valorMulta.present) {
      map['valor_multa'] = Variable<double>(valorMulta.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (emitiuBoleto.present) {
      map['emitiu_boleto'] = Variable<String>(emitiuBoleto.value);
    }
    if (boletoNossoNumero.present) {
      map['boleto_nosso_numero'] = Variable<String>(boletoNossoNumero.value);
    }
    if (valorRecebido.present) {
      map['valor_recebido'] = Variable<double>(valorRecebido.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinParcelaRecebersCompanion(')
          ..write('id: $id, ')
          ..write('idFinLancamentoReceber: $idFinLancamentoReceber, ')
          ..write('idFinChequeRecebido: $idFinChequeRecebido, ')
          ..write('idFinStatusParcela: $idFinStatusParcela, ')
          ..write('idFinTipoRecebimento: $idFinTipoRecebimento, ')
          ..write('numeroParcela: $numeroParcela, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('descontoAte: $descontoAte, ')
          ..write('valor: $valor, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorJuro: $valorJuro, ')
          ..write('valorMulta: $valorMulta, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('emitiuBoleto: $emitiuBoleto, ')
          ..write('boletoNossoNumero: $boletoNossoNumero, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $TalonarioChequesTable extends TalonarioCheques
    with TableInfo<$TalonarioChequesTable, TalonarioCheque> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TalonarioChequesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _talaoMeta = const VerificationMeta('talao');
  @override
  late final GeneratedColumn<String> talao = GeneratedColumn<String>(
    'talao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
    'numero',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _statusTalaoMeta = const VerificationMeta(
    'statusTalao',
  );
  @override
  late final GeneratedColumn<String> statusTalao = GeneratedColumn<String>(
    'status_talao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    talao,
    numero,
    statusTalao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'talonario_cheque';
  @override
  VerificationContext validateIntegrity(
    Insertable<TalonarioCheque> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('talao')) {
      context.handle(
        _talaoMeta,
        talao.isAcceptableOrUnknown(data['talao']!, _talaoMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('status_talao')) {
      context.handle(
        _statusTalaoMeta,
        statusTalao.isAcceptableOrUnknown(
          data['status_talao']!,
          _statusTalaoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TalonarioCheque map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TalonarioCheque(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      talao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}talao'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}numero'],
      ),
      statusTalao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status_talao'],
      ),
    );
  }

  @override
  $TalonarioChequesTable createAlias(String alias) {
    return $TalonarioChequesTable(attachedDatabase, alias);
  }
}

class TalonarioCheque extends DataClass implements Insertable<TalonarioCheque> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? talao;
  final int? numero;
  final String? statusTalao;
  const TalonarioCheque({
    this.id,
    this.idBancoContaCaixa,
    this.talao,
    this.numero,
    this.statusTalao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || talao != null) {
      map['talao'] = Variable<String>(talao);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || statusTalao != null) {
      map['status_talao'] = Variable<String>(statusTalao);
    }
    return map;
  }

  factory TalonarioCheque.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TalonarioCheque(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      talao: serializer.fromJson<String?>(json['talao']),
      numero: serializer.fromJson<int?>(json['numero']),
      statusTalao: serializer.fromJson<String?>(json['statusTalao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'talao': serializer.toJson<String?>(talao),
      'numero': serializer.toJson<int?>(numero),
      'statusTalao': serializer.toJson<String?>(statusTalao),
    };
  }

  TalonarioCheque copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> talao = const Value.absent(),
    Value<int?> numero = const Value.absent(),
    Value<String?> statusTalao = const Value.absent(),
  }) => TalonarioCheque(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    talao: talao.present ? talao.value : this.talao,
    numero: numero.present ? numero.value : this.numero,
    statusTalao: statusTalao.present ? statusTalao.value : this.statusTalao,
  );
  TalonarioCheque copyWithCompanion(TalonarioChequesCompanion data) {
    return TalonarioCheque(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      talao: data.talao.present ? data.talao.value : this.talao,
      numero: data.numero.present ? data.numero.value : this.numero,
      statusTalao:
          data.statusTalao.present ? data.statusTalao.value : this.statusTalao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TalonarioCheque(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('talao: $talao, ')
          ..write('numero: $numero, ')
          ..write('statusTalao: $statusTalao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idBancoContaCaixa, talao, numero, statusTalao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TalonarioCheque &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.talao == this.talao &&
          other.numero == this.numero &&
          other.statusTalao == this.statusTalao);
}

class TalonarioChequesCompanion extends UpdateCompanion<TalonarioCheque> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> talao;
  final Value<int?> numero;
  final Value<String?> statusTalao;
  const TalonarioChequesCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.talao = const Value.absent(),
    this.numero = const Value.absent(),
    this.statusTalao = const Value.absent(),
  });
  TalonarioChequesCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.talao = const Value.absent(),
    this.numero = const Value.absent(),
    this.statusTalao = const Value.absent(),
  });
  static Insertable<TalonarioCheque> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? talao,
    Expression<int>? numero,
    Expression<String>? statusTalao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (talao != null) 'talao': talao,
      if (numero != null) 'numero': numero,
      if (statusTalao != null) 'status_talao': statusTalao,
    });
  }

  TalonarioChequesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? talao,
    Value<int?>? numero,
    Value<String?>? statusTalao,
  }) {
    return TalonarioChequesCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      talao: talao ?? this.talao,
      numero: numero ?? this.numero,
      statusTalao: statusTalao ?? this.statusTalao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (talao.present) {
      map['talao'] = Variable<String>(talao.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (statusTalao.present) {
      map['status_talao'] = Variable<String>(statusTalao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TalonarioChequesCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('talao: $talao, ')
          ..write('numero: $numero, ')
          ..write('statusTalao: $statusTalao')
          ..write(')'))
        .toString();
  }
}

class $FinLancamentoPagarsTable extends FinLancamentoPagars
    with TableInfo<$FinLancamentoPagarsTable, FinLancamentoPagar> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinLancamentoPagarsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _imagemDocumentoMeta = const VerificationMeta(
    'imagemDocumento',
  );
  @override
  late final GeneratedColumn<String> imagemDocumento = GeneratedColumn<String>(
    'imagem_documento',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFornecedorMeta = const VerificationMeta(
    'idFornecedor',
  );
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
    'id_fornecedor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinDocumentoOrigemMeta =
      const VerificationMeta('idFinDocumentoOrigem');
  @override
  late final GeneratedColumn<int> idFinDocumentoOrigem = GeneratedColumn<int>(
    'id_fin_documento_origem',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinNaturezaFinanceiraMeta =
      const VerificationMeta('idFinNaturezaFinanceira');
  @override
  late final GeneratedColumn<int> idFinNaturezaFinanceira =
      GeneratedColumn<int>(
        'id_fin_natureza_financeira',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _quantidadeParcelaMeta = const VerificationMeta(
    'quantidadeParcela',
  );
  @override
  late final GeneratedColumn<int> quantidadeParcela = GeneratedColumn<int>(
    'quantidade_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorAPagarMeta = const VerificationMeta(
    'valorAPagar',
  );
  @override
  late final GeneratedColumn<double> valorAPagar = GeneratedColumn<double>(
    'valor_a_pagar',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataLancamentoMeta = const VerificationMeta(
    'dataLancamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>(
        'data_lancamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _numeroDocumentoMeta = const VerificationMeta(
    'numeroDocumento',
  );
  @override
  late final GeneratedColumn<String> numeroDocumento = GeneratedColumn<String>(
    'numero_documento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _primeiroVencimentoMeta =
      const VerificationMeta('primeiroVencimento');
  @override
  late final GeneratedColumn<DateTime> primeiroVencimento =
      GeneratedColumn<DateTime>(
        'primeiro_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _intervaloEntreParcelasMeta =
      const VerificationMeta('intervaloEntreParcelas');
  @override
  late final GeneratedColumn<int> intervaloEntreParcelas = GeneratedColumn<int>(
    'intervalo_entre_parcelas',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _diaFixoMeta = const VerificationMeta(
    'diaFixo',
  );
  @override
  late final GeneratedColumn<String> diaFixo = GeneratedColumn<String>(
    'dia_fixo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    imagemDocumento,
    idFornecedor,
    idBancoContaCaixa,
    idFinDocumentoOrigem,
    idFinNaturezaFinanceira,
    quantidadeParcela,
    valorAPagar,
    dataLancamento,
    numeroDocumento,
    primeiroVencimento,
    intervaloEntreParcelas,
    diaFixo,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_lancamento_pagar';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinLancamentoPagar> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('imagem_documento')) {
      context.handle(
        _imagemDocumentoMeta,
        imagemDocumento.isAcceptableOrUnknown(
          data['imagem_documento']!,
          _imagemDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
        _idFornecedorMeta,
        idFornecedor.isAcceptableOrUnknown(
          data['id_fornecedor']!,
          _idFornecedorMeta,
        ),
      );
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_documento_origem')) {
      context.handle(
        _idFinDocumentoOrigemMeta,
        idFinDocumentoOrigem.isAcceptableOrUnknown(
          data['id_fin_documento_origem']!,
          _idFinDocumentoOrigemMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_natureza_financeira')) {
      context.handle(
        _idFinNaturezaFinanceiraMeta,
        idFinNaturezaFinanceira.isAcceptableOrUnknown(
          data['id_fin_natureza_financeira']!,
          _idFinNaturezaFinanceiraMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_parcela')) {
      context.handle(
        _quantidadeParcelaMeta,
        quantidadeParcela.isAcceptableOrUnknown(
          data['quantidade_parcela']!,
          _quantidadeParcelaMeta,
        ),
      );
    }
    if (data.containsKey('valor_a_pagar')) {
      context.handle(
        _valorAPagarMeta,
        valorAPagar.isAcceptableOrUnknown(
          data['valor_a_pagar']!,
          _valorAPagarMeta,
        ),
      );
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
        _dataLancamentoMeta,
        dataLancamento.isAcceptableOrUnknown(
          data['data_lancamento']!,
          _dataLancamentoMeta,
        ),
      );
    }
    if (data.containsKey('numero_documento')) {
      context.handle(
        _numeroDocumentoMeta,
        numeroDocumento.isAcceptableOrUnknown(
          data['numero_documento']!,
          _numeroDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('primeiro_vencimento')) {
      context.handle(
        _primeiroVencimentoMeta,
        primeiroVencimento.isAcceptableOrUnknown(
          data['primeiro_vencimento']!,
          _primeiroVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('intervalo_entre_parcelas')) {
      context.handle(
        _intervaloEntreParcelasMeta,
        intervaloEntreParcelas.isAcceptableOrUnknown(
          data['intervalo_entre_parcelas']!,
          _intervaloEntreParcelasMeta,
        ),
      );
    }
    if (data.containsKey('dia_fixo')) {
      context.handle(
        _diaFixoMeta,
        diaFixo.isAcceptableOrUnknown(data['dia_fixo']!, _diaFixoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinLancamentoPagar map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinLancamentoPagar(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      imagemDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}imagem_documento'],
      ),
      idFornecedor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fornecedor'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      idFinDocumentoOrigem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_documento_origem'],
      ),
      idFinNaturezaFinanceira: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_natureza_financeira'],
      ),
      quantidadeParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_parcela'],
      ),
      valorAPagar: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_a_pagar'],
      ),
      dataLancamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_lancamento'],
      ),
      numeroDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_documento'],
      ),
      primeiroVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}primeiro_vencimento'],
      ),
      intervaloEntreParcelas: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}intervalo_entre_parcelas'],
      ),
      diaFixo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}dia_fixo'],
      ),
    );
  }

  @override
  $FinLancamentoPagarsTable createAlias(String alias) {
    return $FinLancamentoPagarsTable(attachedDatabase, alias);
  }
}

class FinLancamentoPagar extends DataClass
    implements Insertable<FinLancamentoPagar> {
  final int? id;
  final String? imagemDocumento;
  final int? idFornecedor;
  final int? idBancoContaCaixa;
  final int? idFinDocumentoOrigem;
  final int? idFinNaturezaFinanceira;
  final int? quantidadeParcela;
  final double? valorAPagar;
  final DateTime? dataLancamento;
  final String? numeroDocumento;
  final DateTime? primeiroVencimento;
  final int? intervaloEntreParcelas;
  final String? diaFixo;
  const FinLancamentoPagar({
    this.id,
    this.imagemDocumento,
    this.idFornecedor,
    this.idBancoContaCaixa,
    this.idFinDocumentoOrigem,
    this.idFinNaturezaFinanceira,
    this.quantidadeParcela,
    this.valorAPagar,
    this.dataLancamento,
    this.numeroDocumento,
    this.primeiroVencimento,
    this.intervaloEntreParcelas,
    this.diaFixo,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || imagemDocumento != null) {
      map['imagem_documento'] = Variable<String>(imagemDocumento);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || idFinDocumentoOrigem != null) {
      map['id_fin_documento_origem'] = Variable<int>(idFinDocumentoOrigem);
    }
    if (!nullToAbsent || idFinNaturezaFinanceira != null) {
      map['id_fin_natureza_financeira'] = Variable<int>(
        idFinNaturezaFinanceira,
      );
    }
    if (!nullToAbsent || quantidadeParcela != null) {
      map['quantidade_parcela'] = Variable<int>(quantidadeParcela);
    }
    if (!nullToAbsent || valorAPagar != null) {
      map['valor_a_pagar'] = Variable<double>(valorAPagar);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || numeroDocumento != null) {
      map['numero_documento'] = Variable<String>(numeroDocumento);
    }
    if (!nullToAbsent || primeiroVencimento != null) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento);
    }
    if (!nullToAbsent || intervaloEntreParcelas != null) {
      map['intervalo_entre_parcelas'] = Variable<int>(intervaloEntreParcelas);
    }
    if (!nullToAbsent || diaFixo != null) {
      map['dia_fixo'] = Variable<String>(diaFixo);
    }
    return map;
  }

  factory FinLancamentoPagar.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinLancamentoPagar(
      id: serializer.fromJson<int?>(json['id']),
      imagemDocumento: serializer.fromJson<String?>(json['imagemDocumento']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      idFinDocumentoOrigem: serializer.fromJson<int?>(
        json['idFinDocumentoOrigem'],
      ),
      idFinNaturezaFinanceira: serializer.fromJson<int?>(
        json['idFinNaturezaFinanceira'],
      ),
      quantidadeParcela: serializer.fromJson<int?>(json['quantidadeParcela']),
      valorAPagar: serializer.fromJson<double?>(json['valorAPagar']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      numeroDocumento: serializer.fromJson<String?>(json['numeroDocumento']),
      primeiroVencimento: serializer.fromJson<DateTime?>(
        json['primeiroVencimento'],
      ),
      intervaloEntreParcelas: serializer.fromJson<int?>(
        json['intervaloEntreParcelas'],
      ),
      diaFixo: serializer.fromJson<String?>(json['diaFixo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'imagemDocumento': serializer.toJson<String?>(imagemDocumento),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'idFinDocumentoOrigem': serializer.toJson<int?>(idFinDocumentoOrigem),
      'idFinNaturezaFinanceira': serializer.toJson<int?>(
        idFinNaturezaFinanceira,
      ),
      'quantidadeParcela': serializer.toJson<int?>(quantidadeParcela),
      'valorAPagar': serializer.toJson<double?>(valorAPagar),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'numeroDocumento': serializer.toJson<String?>(numeroDocumento),
      'primeiroVencimento': serializer.toJson<DateTime?>(primeiroVencimento),
      'intervaloEntreParcelas': serializer.toJson<int?>(intervaloEntreParcelas),
      'diaFixo': serializer.toJson<String?>(diaFixo),
    };
  }

  FinLancamentoPagar copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> imagemDocumento = const Value.absent(),
    Value<int?> idFornecedor = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<int?> idFinDocumentoOrigem = const Value.absent(),
    Value<int?> idFinNaturezaFinanceira = const Value.absent(),
    Value<int?> quantidadeParcela = const Value.absent(),
    Value<double?> valorAPagar = const Value.absent(),
    Value<DateTime?> dataLancamento = const Value.absent(),
    Value<String?> numeroDocumento = const Value.absent(),
    Value<DateTime?> primeiroVencimento = const Value.absent(),
    Value<int?> intervaloEntreParcelas = const Value.absent(),
    Value<String?> diaFixo = const Value.absent(),
  }) => FinLancamentoPagar(
    id: id.present ? id.value : this.id,
    imagemDocumento:
        imagemDocumento.present ? imagemDocumento.value : this.imagemDocumento,
    idFornecedor: idFornecedor.present ? idFornecedor.value : this.idFornecedor,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    idFinDocumentoOrigem:
        idFinDocumentoOrigem.present
            ? idFinDocumentoOrigem.value
            : this.idFinDocumentoOrigem,
    idFinNaturezaFinanceira:
        idFinNaturezaFinanceira.present
            ? idFinNaturezaFinanceira.value
            : this.idFinNaturezaFinanceira,
    quantidadeParcela:
        quantidadeParcela.present
            ? quantidadeParcela.value
            : this.quantidadeParcela,
    valorAPagar: valorAPagar.present ? valorAPagar.value : this.valorAPagar,
    dataLancamento:
        dataLancamento.present ? dataLancamento.value : this.dataLancamento,
    numeroDocumento:
        numeroDocumento.present ? numeroDocumento.value : this.numeroDocumento,
    primeiroVencimento:
        primeiroVencimento.present
            ? primeiroVencimento.value
            : this.primeiroVencimento,
    intervaloEntreParcelas:
        intervaloEntreParcelas.present
            ? intervaloEntreParcelas.value
            : this.intervaloEntreParcelas,
    diaFixo: diaFixo.present ? diaFixo.value : this.diaFixo,
  );
  FinLancamentoPagar copyWithCompanion(FinLancamentoPagarsCompanion data) {
    return FinLancamentoPagar(
      id: data.id.present ? data.id.value : this.id,
      imagemDocumento:
          data.imagemDocumento.present
              ? data.imagemDocumento.value
              : this.imagemDocumento,
      idFornecedor:
          data.idFornecedor.present
              ? data.idFornecedor.value
              : this.idFornecedor,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      idFinDocumentoOrigem:
          data.idFinDocumentoOrigem.present
              ? data.idFinDocumentoOrigem.value
              : this.idFinDocumentoOrigem,
      idFinNaturezaFinanceira:
          data.idFinNaturezaFinanceira.present
              ? data.idFinNaturezaFinanceira.value
              : this.idFinNaturezaFinanceira,
      quantidadeParcela:
          data.quantidadeParcela.present
              ? data.quantidadeParcela.value
              : this.quantidadeParcela,
      valorAPagar:
          data.valorAPagar.present ? data.valorAPagar.value : this.valorAPagar,
      dataLancamento:
          data.dataLancamento.present
              ? data.dataLancamento.value
              : this.dataLancamento,
      numeroDocumento:
          data.numeroDocumento.present
              ? data.numeroDocumento.value
              : this.numeroDocumento,
      primeiroVencimento:
          data.primeiroVencimento.present
              ? data.primeiroVencimento.value
              : this.primeiroVencimento,
      intervaloEntreParcelas:
          data.intervaloEntreParcelas.present
              ? data.intervaloEntreParcelas.value
              : this.intervaloEntreParcelas,
      diaFixo: data.diaFixo.present ? data.diaFixo.value : this.diaFixo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinLancamentoPagar(')
          ..write('id: $id, ')
          ..write('imagemDocumento: $imagemDocumento, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('idFinDocumentoOrigem: $idFinDocumentoOrigem, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('quantidadeParcela: $quantidadeParcela, ')
          ..write('valorAPagar: $valorAPagar, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixo: $diaFixo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    imagemDocumento,
    idFornecedor,
    idBancoContaCaixa,
    idFinDocumentoOrigem,
    idFinNaturezaFinanceira,
    quantidadeParcela,
    valorAPagar,
    dataLancamento,
    numeroDocumento,
    primeiroVencimento,
    intervaloEntreParcelas,
    diaFixo,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinLancamentoPagar &&
          other.id == this.id &&
          other.imagemDocumento == this.imagemDocumento &&
          other.idFornecedor == this.idFornecedor &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.idFinDocumentoOrigem == this.idFinDocumentoOrigem &&
          other.idFinNaturezaFinanceira == this.idFinNaturezaFinanceira &&
          other.quantidadeParcela == this.quantidadeParcela &&
          other.valorAPagar == this.valorAPagar &&
          other.dataLancamento == this.dataLancamento &&
          other.numeroDocumento == this.numeroDocumento &&
          other.primeiroVencimento == this.primeiroVencimento &&
          other.intervaloEntreParcelas == this.intervaloEntreParcelas &&
          other.diaFixo == this.diaFixo);
}

class FinLancamentoPagarsCompanion extends UpdateCompanion<FinLancamentoPagar> {
  final Value<int?> id;
  final Value<String?> imagemDocumento;
  final Value<int?> idFornecedor;
  final Value<int?> idBancoContaCaixa;
  final Value<int?> idFinDocumentoOrigem;
  final Value<int?> idFinNaturezaFinanceira;
  final Value<int?> quantidadeParcela;
  final Value<double?> valorAPagar;
  final Value<DateTime?> dataLancamento;
  final Value<String?> numeroDocumento;
  final Value<DateTime?> primeiroVencimento;
  final Value<int?> intervaloEntreParcelas;
  final Value<String?> diaFixo;
  const FinLancamentoPagarsCompanion({
    this.id = const Value.absent(),
    this.imagemDocumento = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.idFinDocumentoOrigem = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.quantidadeParcela = const Value.absent(),
    this.valorAPagar = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixo = const Value.absent(),
  });
  FinLancamentoPagarsCompanion.insert({
    this.id = const Value.absent(),
    this.imagemDocumento = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.idFinDocumentoOrigem = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.quantidadeParcela = const Value.absent(),
    this.valorAPagar = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixo = const Value.absent(),
  });
  static Insertable<FinLancamentoPagar> custom({
    Expression<int>? id,
    Expression<String>? imagemDocumento,
    Expression<int>? idFornecedor,
    Expression<int>? idBancoContaCaixa,
    Expression<int>? idFinDocumentoOrigem,
    Expression<int>? idFinNaturezaFinanceira,
    Expression<int>? quantidadeParcela,
    Expression<double>? valorAPagar,
    Expression<DateTime>? dataLancamento,
    Expression<String>? numeroDocumento,
    Expression<DateTime>? primeiroVencimento,
    Expression<int>? intervaloEntreParcelas,
    Expression<String>? diaFixo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (imagemDocumento != null) 'imagem_documento': imagemDocumento,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (idFinDocumentoOrigem != null)
        'id_fin_documento_origem': idFinDocumentoOrigem,
      if (idFinNaturezaFinanceira != null)
        'id_fin_natureza_financeira': idFinNaturezaFinanceira,
      if (quantidadeParcela != null) 'quantidade_parcela': quantidadeParcela,
      if (valorAPagar != null) 'valor_a_pagar': valorAPagar,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (numeroDocumento != null) 'numero_documento': numeroDocumento,
      if (primeiroVencimento != null) 'primeiro_vencimento': primeiroVencimento,
      if (intervaloEntreParcelas != null)
        'intervalo_entre_parcelas': intervaloEntreParcelas,
      if (diaFixo != null) 'dia_fixo': diaFixo,
    });
  }

  FinLancamentoPagarsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? imagemDocumento,
    Value<int?>? idFornecedor,
    Value<int?>? idBancoContaCaixa,
    Value<int?>? idFinDocumentoOrigem,
    Value<int?>? idFinNaturezaFinanceira,
    Value<int?>? quantidadeParcela,
    Value<double?>? valorAPagar,
    Value<DateTime?>? dataLancamento,
    Value<String?>? numeroDocumento,
    Value<DateTime?>? primeiroVencimento,
    Value<int?>? intervaloEntreParcelas,
    Value<String?>? diaFixo,
  }) {
    return FinLancamentoPagarsCompanion(
      id: id ?? this.id,
      imagemDocumento: imagemDocumento ?? this.imagemDocumento,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      idFinDocumentoOrigem: idFinDocumentoOrigem ?? this.idFinDocumentoOrigem,
      idFinNaturezaFinanceira:
          idFinNaturezaFinanceira ?? this.idFinNaturezaFinanceira,
      quantidadeParcela: quantidadeParcela ?? this.quantidadeParcela,
      valorAPagar: valorAPagar ?? this.valorAPagar,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      numeroDocumento: numeroDocumento ?? this.numeroDocumento,
      primeiroVencimento: primeiroVencimento ?? this.primeiroVencimento,
      intervaloEntreParcelas:
          intervaloEntreParcelas ?? this.intervaloEntreParcelas,
      diaFixo: diaFixo ?? this.diaFixo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (imagemDocumento.present) {
      map['imagem_documento'] = Variable<String>(imagemDocumento.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (idFinDocumentoOrigem.present) {
      map['id_fin_documento_origem'] = Variable<int>(
        idFinDocumentoOrigem.value,
      );
    }
    if (idFinNaturezaFinanceira.present) {
      map['id_fin_natureza_financeira'] = Variable<int>(
        idFinNaturezaFinanceira.value,
      );
    }
    if (quantidadeParcela.present) {
      map['quantidade_parcela'] = Variable<int>(quantidadeParcela.value);
    }
    if (valorAPagar.present) {
      map['valor_a_pagar'] = Variable<double>(valorAPagar.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (numeroDocumento.present) {
      map['numero_documento'] = Variable<String>(numeroDocumento.value);
    }
    if (primeiroVencimento.present) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento.value);
    }
    if (intervaloEntreParcelas.present) {
      map['intervalo_entre_parcelas'] = Variable<int>(
        intervaloEntreParcelas.value,
      );
    }
    if (diaFixo.present) {
      map['dia_fixo'] = Variable<String>(diaFixo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinLancamentoPagarsCompanion(')
          ..write('id: $id, ')
          ..write('imagemDocumento: $imagemDocumento, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('idFinDocumentoOrigem: $idFinDocumentoOrigem, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('quantidadeParcela: $quantidadeParcela, ')
          ..write('valorAPagar: $valorAPagar, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixo: $diaFixo')
          ..write(')'))
        .toString();
  }
}

class $FinLancamentoRecebersTable extends FinLancamentoRecebers
    with TableInfo<$FinLancamentoRecebersTable, FinLancamentoReceber> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinLancamentoRecebersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinDocumentoOrigemMeta =
      const VerificationMeta('idFinDocumentoOrigem');
  @override
  late final GeneratedColumn<int> idFinDocumentoOrigem = GeneratedColumn<int>(
    'id_fin_documento_origem',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFinNaturezaFinanceiraMeta =
      const VerificationMeta('idFinNaturezaFinanceira');
  @override
  late final GeneratedColumn<int> idFinNaturezaFinanceira =
      GeneratedColumn<int>(
        'id_fin_natureza_financeira',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _quantidadeParcelaMeta = const VerificationMeta(
    'quantidadeParcela',
  );
  @override
  late final GeneratedColumn<int> quantidadeParcela = GeneratedColumn<int>(
    'quantidade_parcela',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorAReceberMeta = const VerificationMeta(
    'valorAReceber',
  );
  @override
  late final GeneratedColumn<double> valorAReceber = GeneratedColumn<double>(
    'valor_a_receber',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataLancamentoMeta = const VerificationMeta(
    'dataLancamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>(
        'data_lancamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _numeroDocumentoMeta = const VerificationMeta(
    'numeroDocumento',
  );
  @override
  late final GeneratedColumn<String> numeroDocumento = GeneratedColumn<String>(
    'numero_documento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _primeiroVencimentoMeta =
      const VerificationMeta('primeiroVencimento');
  @override
  late final GeneratedColumn<DateTime> primeiroVencimento =
      GeneratedColumn<DateTime>(
        'primeiro_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _taxaComissaoMeta = const VerificationMeta(
    'taxaComissao',
  );
  @override
  late final GeneratedColumn<double> taxaComissao = GeneratedColumn<double>(
    'taxa_comissao',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorComissaoMeta = const VerificationMeta(
    'valorComissao',
  );
  @override
  late final GeneratedColumn<double> valorComissao = GeneratedColumn<double>(
    'valor_comissao',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _intervaloEntreParcelasMeta =
      const VerificationMeta('intervaloEntreParcelas');
  @override
  late final GeneratedColumn<int> intervaloEntreParcelas = GeneratedColumn<int>(
    'intervalo_entre_parcelas',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _diaFixoMeta = const VerificationMeta(
    'diaFixo',
  );
  @override
  late final GeneratedColumn<String> diaFixo = GeneratedColumn<String>(
    'dia_fixo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    idBancoContaCaixa,
    idFinDocumentoOrigem,
    idFinNaturezaFinanceira,
    quantidadeParcela,
    valorAReceber,
    dataLancamento,
    numeroDocumento,
    primeiroVencimento,
    taxaComissao,
    valorComissao,
    intervaloEntreParcelas,
    diaFixo,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_lancamento_receber';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinLancamentoReceber> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_documento_origem')) {
      context.handle(
        _idFinDocumentoOrigemMeta,
        idFinDocumentoOrigem.isAcceptableOrUnknown(
          data['id_fin_documento_origem']!,
          _idFinDocumentoOrigemMeta,
        ),
      );
    }
    if (data.containsKey('id_fin_natureza_financeira')) {
      context.handle(
        _idFinNaturezaFinanceiraMeta,
        idFinNaturezaFinanceira.isAcceptableOrUnknown(
          data['id_fin_natureza_financeira']!,
          _idFinNaturezaFinanceiraMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_parcela')) {
      context.handle(
        _quantidadeParcelaMeta,
        quantidadeParcela.isAcceptableOrUnknown(
          data['quantidade_parcela']!,
          _quantidadeParcelaMeta,
        ),
      );
    }
    if (data.containsKey('valor_a_receber')) {
      context.handle(
        _valorAReceberMeta,
        valorAReceber.isAcceptableOrUnknown(
          data['valor_a_receber']!,
          _valorAReceberMeta,
        ),
      );
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
        _dataLancamentoMeta,
        dataLancamento.isAcceptableOrUnknown(
          data['data_lancamento']!,
          _dataLancamentoMeta,
        ),
      );
    }
    if (data.containsKey('numero_documento')) {
      context.handle(
        _numeroDocumentoMeta,
        numeroDocumento.isAcceptableOrUnknown(
          data['numero_documento']!,
          _numeroDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('primeiro_vencimento')) {
      context.handle(
        _primeiroVencimentoMeta,
        primeiroVencimento.isAcceptableOrUnknown(
          data['primeiro_vencimento']!,
          _primeiroVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('taxa_comissao')) {
      context.handle(
        _taxaComissaoMeta,
        taxaComissao.isAcceptableOrUnknown(
          data['taxa_comissao']!,
          _taxaComissaoMeta,
        ),
      );
    }
    if (data.containsKey('valor_comissao')) {
      context.handle(
        _valorComissaoMeta,
        valorComissao.isAcceptableOrUnknown(
          data['valor_comissao']!,
          _valorComissaoMeta,
        ),
      );
    }
    if (data.containsKey('intervalo_entre_parcelas')) {
      context.handle(
        _intervaloEntreParcelasMeta,
        intervaloEntreParcelas.isAcceptableOrUnknown(
          data['intervalo_entre_parcelas']!,
          _intervaloEntreParcelasMeta,
        ),
      );
    }
    if (data.containsKey('dia_fixo')) {
      context.handle(
        _diaFixoMeta,
        diaFixo.isAcceptableOrUnknown(data['dia_fixo']!, _diaFixoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinLancamentoReceber map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinLancamentoReceber(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      idFinDocumentoOrigem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_documento_origem'],
      ),
      idFinNaturezaFinanceira: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fin_natureza_financeira'],
      ),
      quantidadeParcela: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_parcela'],
      ),
      valorAReceber: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_a_receber'],
      ),
      dataLancamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_lancamento'],
      ),
      numeroDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_documento'],
      ),
      primeiroVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}primeiro_vencimento'],
      ),
      taxaComissao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_comissao'],
      ),
      valorComissao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_comissao'],
      ),
      intervaloEntreParcelas: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}intervalo_entre_parcelas'],
      ),
      diaFixo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}dia_fixo'],
      ),
    );
  }

  @override
  $FinLancamentoRecebersTable createAlias(String alias) {
    return $FinLancamentoRecebersTable(attachedDatabase, alias);
  }
}

class FinLancamentoReceber extends DataClass
    implements Insertable<FinLancamentoReceber> {
  final int? id;
  final int? idCliente;
  final int? idBancoContaCaixa;
  final int? idFinDocumentoOrigem;
  final int? idFinNaturezaFinanceira;
  final int? quantidadeParcela;
  final double? valorAReceber;
  final DateTime? dataLancamento;
  final String? numeroDocumento;
  final DateTime? primeiroVencimento;
  final double? taxaComissao;
  final double? valorComissao;
  final int? intervaloEntreParcelas;
  final String? diaFixo;
  const FinLancamentoReceber({
    this.id,
    this.idCliente,
    this.idBancoContaCaixa,
    this.idFinDocumentoOrigem,
    this.idFinNaturezaFinanceira,
    this.quantidadeParcela,
    this.valorAReceber,
    this.dataLancamento,
    this.numeroDocumento,
    this.primeiroVencimento,
    this.taxaComissao,
    this.valorComissao,
    this.intervaloEntreParcelas,
    this.diaFixo,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || idFinDocumentoOrigem != null) {
      map['id_fin_documento_origem'] = Variable<int>(idFinDocumentoOrigem);
    }
    if (!nullToAbsent || idFinNaturezaFinanceira != null) {
      map['id_fin_natureza_financeira'] = Variable<int>(
        idFinNaturezaFinanceira,
      );
    }
    if (!nullToAbsent || quantidadeParcela != null) {
      map['quantidade_parcela'] = Variable<int>(quantidadeParcela);
    }
    if (!nullToAbsent || valorAReceber != null) {
      map['valor_a_receber'] = Variable<double>(valorAReceber);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || numeroDocumento != null) {
      map['numero_documento'] = Variable<String>(numeroDocumento);
    }
    if (!nullToAbsent || primeiroVencimento != null) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento);
    }
    if (!nullToAbsent || taxaComissao != null) {
      map['taxa_comissao'] = Variable<double>(taxaComissao);
    }
    if (!nullToAbsent || valorComissao != null) {
      map['valor_comissao'] = Variable<double>(valorComissao);
    }
    if (!nullToAbsent || intervaloEntreParcelas != null) {
      map['intervalo_entre_parcelas'] = Variable<int>(intervaloEntreParcelas);
    }
    if (!nullToAbsent || diaFixo != null) {
      map['dia_fixo'] = Variable<String>(diaFixo);
    }
    return map;
  }

  factory FinLancamentoReceber.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinLancamentoReceber(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      idFinDocumentoOrigem: serializer.fromJson<int?>(
        json['idFinDocumentoOrigem'],
      ),
      idFinNaturezaFinanceira: serializer.fromJson<int?>(
        json['idFinNaturezaFinanceira'],
      ),
      quantidadeParcela: serializer.fromJson<int?>(json['quantidadeParcela']),
      valorAReceber: serializer.fromJson<double?>(json['valorAReceber']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      numeroDocumento: serializer.fromJson<String?>(json['numeroDocumento']),
      primeiroVencimento: serializer.fromJson<DateTime?>(
        json['primeiroVencimento'],
      ),
      taxaComissao: serializer.fromJson<double?>(json['taxaComissao']),
      valorComissao: serializer.fromJson<double?>(json['valorComissao']),
      intervaloEntreParcelas: serializer.fromJson<int?>(
        json['intervaloEntreParcelas'],
      ),
      diaFixo: serializer.fromJson<String?>(json['diaFixo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'idFinDocumentoOrigem': serializer.toJson<int?>(idFinDocumentoOrigem),
      'idFinNaturezaFinanceira': serializer.toJson<int?>(
        idFinNaturezaFinanceira,
      ),
      'quantidadeParcela': serializer.toJson<int?>(quantidadeParcela),
      'valorAReceber': serializer.toJson<double?>(valorAReceber),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'numeroDocumento': serializer.toJson<String?>(numeroDocumento),
      'primeiroVencimento': serializer.toJson<DateTime?>(primeiroVencimento),
      'taxaComissao': serializer.toJson<double?>(taxaComissao),
      'valorComissao': serializer.toJson<double?>(valorComissao),
      'intervaloEntreParcelas': serializer.toJson<int?>(intervaloEntreParcelas),
      'diaFixo': serializer.toJson<String?>(diaFixo),
    };
  }

  FinLancamentoReceber copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<int?> idFinDocumentoOrigem = const Value.absent(),
    Value<int?> idFinNaturezaFinanceira = const Value.absent(),
    Value<int?> quantidadeParcela = const Value.absent(),
    Value<double?> valorAReceber = const Value.absent(),
    Value<DateTime?> dataLancamento = const Value.absent(),
    Value<String?> numeroDocumento = const Value.absent(),
    Value<DateTime?> primeiroVencimento = const Value.absent(),
    Value<double?> taxaComissao = const Value.absent(),
    Value<double?> valorComissao = const Value.absent(),
    Value<int?> intervaloEntreParcelas = const Value.absent(),
    Value<String?> diaFixo = const Value.absent(),
  }) => FinLancamentoReceber(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    idFinDocumentoOrigem:
        idFinDocumentoOrigem.present
            ? idFinDocumentoOrigem.value
            : this.idFinDocumentoOrigem,
    idFinNaturezaFinanceira:
        idFinNaturezaFinanceira.present
            ? idFinNaturezaFinanceira.value
            : this.idFinNaturezaFinanceira,
    quantidadeParcela:
        quantidadeParcela.present
            ? quantidadeParcela.value
            : this.quantidadeParcela,
    valorAReceber:
        valorAReceber.present ? valorAReceber.value : this.valorAReceber,
    dataLancamento:
        dataLancamento.present ? dataLancamento.value : this.dataLancamento,
    numeroDocumento:
        numeroDocumento.present ? numeroDocumento.value : this.numeroDocumento,
    primeiroVencimento:
        primeiroVencimento.present
            ? primeiroVencimento.value
            : this.primeiroVencimento,
    taxaComissao: taxaComissao.present ? taxaComissao.value : this.taxaComissao,
    valorComissao:
        valorComissao.present ? valorComissao.value : this.valorComissao,
    intervaloEntreParcelas:
        intervaloEntreParcelas.present
            ? intervaloEntreParcelas.value
            : this.intervaloEntreParcelas,
    diaFixo: diaFixo.present ? diaFixo.value : this.diaFixo,
  );
  FinLancamentoReceber copyWithCompanion(FinLancamentoRecebersCompanion data) {
    return FinLancamentoReceber(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      idFinDocumentoOrigem:
          data.idFinDocumentoOrigem.present
              ? data.idFinDocumentoOrigem.value
              : this.idFinDocumentoOrigem,
      idFinNaturezaFinanceira:
          data.idFinNaturezaFinanceira.present
              ? data.idFinNaturezaFinanceira.value
              : this.idFinNaturezaFinanceira,
      quantidadeParcela:
          data.quantidadeParcela.present
              ? data.quantidadeParcela.value
              : this.quantidadeParcela,
      valorAReceber:
          data.valorAReceber.present
              ? data.valorAReceber.value
              : this.valorAReceber,
      dataLancamento:
          data.dataLancamento.present
              ? data.dataLancamento.value
              : this.dataLancamento,
      numeroDocumento:
          data.numeroDocumento.present
              ? data.numeroDocumento.value
              : this.numeroDocumento,
      primeiroVencimento:
          data.primeiroVencimento.present
              ? data.primeiroVencimento.value
              : this.primeiroVencimento,
      taxaComissao:
          data.taxaComissao.present
              ? data.taxaComissao.value
              : this.taxaComissao,
      valorComissao:
          data.valorComissao.present
              ? data.valorComissao.value
              : this.valorComissao,
      intervaloEntreParcelas:
          data.intervaloEntreParcelas.present
              ? data.intervaloEntreParcelas.value
              : this.intervaloEntreParcelas,
      diaFixo: data.diaFixo.present ? data.diaFixo.value : this.diaFixo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinLancamentoReceber(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('idFinDocumentoOrigem: $idFinDocumentoOrigem, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('quantidadeParcela: $quantidadeParcela, ')
          ..write('valorAReceber: $valorAReceber, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixo: $diaFixo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    idBancoContaCaixa,
    idFinDocumentoOrigem,
    idFinNaturezaFinanceira,
    quantidadeParcela,
    valorAReceber,
    dataLancamento,
    numeroDocumento,
    primeiroVencimento,
    taxaComissao,
    valorComissao,
    intervaloEntreParcelas,
    diaFixo,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinLancamentoReceber &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.idFinDocumentoOrigem == this.idFinDocumentoOrigem &&
          other.idFinNaturezaFinanceira == this.idFinNaturezaFinanceira &&
          other.quantidadeParcela == this.quantidadeParcela &&
          other.valorAReceber == this.valorAReceber &&
          other.dataLancamento == this.dataLancamento &&
          other.numeroDocumento == this.numeroDocumento &&
          other.primeiroVencimento == this.primeiroVencimento &&
          other.taxaComissao == this.taxaComissao &&
          other.valorComissao == this.valorComissao &&
          other.intervaloEntreParcelas == this.intervaloEntreParcelas &&
          other.diaFixo == this.diaFixo);
}

class FinLancamentoRecebersCompanion
    extends UpdateCompanion<FinLancamentoReceber> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idBancoContaCaixa;
  final Value<int?> idFinDocumentoOrigem;
  final Value<int?> idFinNaturezaFinanceira;
  final Value<int?> quantidadeParcela;
  final Value<double?> valorAReceber;
  final Value<DateTime?> dataLancamento;
  final Value<String?> numeroDocumento;
  final Value<DateTime?> primeiroVencimento;
  final Value<double?> taxaComissao;
  final Value<double?> valorComissao;
  final Value<int?> intervaloEntreParcelas;
  final Value<String?> diaFixo;
  const FinLancamentoRecebersCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.idFinDocumentoOrigem = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.quantidadeParcela = const Value.absent(),
    this.valorAReceber = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixo = const Value.absent(),
  });
  FinLancamentoRecebersCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.idFinDocumentoOrigem = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.quantidadeParcela = const Value.absent(),
    this.valorAReceber = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.primeiroVencimento = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixo = const Value.absent(),
  });
  static Insertable<FinLancamentoReceber> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idBancoContaCaixa,
    Expression<int>? idFinDocumentoOrigem,
    Expression<int>? idFinNaturezaFinanceira,
    Expression<int>? quantidadeParcela,
    Expression<double>? valorAReceber,
    Expression<DateTime>? dataLancamento,
    Expression<String>? numeroDocumento,
    Expression<DateTime>? primeiroVencimento,
    Expression<double>? taxaComissao,
    Expression<double>? valorComissao,
    Expression<int>? intervaloEntreParcelas,
    Expression<String>? diaFixo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (idFinDocumentoOrigem != null)
        'id_fin_documento_origem': idFinDocumentoOrigem,
      if (idFinNaturezaFinanceira != null)
        'id_fin_natureza_financeira': idFinNaturezaFinanceira,
      if (quantidadeParcela != null) 'quantidade_parcela': quantidadeParcela,
      if (valorAReceber != null) 'valor_a_receber': valorAReceber,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (numeroDocumento != null) 'numero_documento': numeroDocumento,
      if (primeiroVencimento != null) 'primeiro_vencimento': primeiroVencimento,
      if (taxaComissao != null) 'taxa_comissao': taxaComissao,
      if (valorComissao != null) 'valor_comissao': valorComissao,
      if (intervaloEntreParcelas != null)
        'intervalo_entre_parcelas': intervaloEntreParcelas,
      if (diaFixo != null) 'dia_fixo': diaFixo,
    });
  }

  FinLancamentoRecebersCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<int?>? idBancoContaCaixa,
    Value<int?>? idFinDocumentoOrigem,
    Value<int?>? idFinNaturezaFinanceira,
    Value<int?>? quantidadeParcela,
    Value<double?>? valorAReceber,
    Value<DateTime?>? dataLancamento,
    Value<String?>? numeroDocumento,
    Value<DateTime?>? primeiroVencimento,
    Value<double?>? taxaComissao,
    Value<double?>? valorComissao,
    Value<int?>? intervaloEntreParcelas,
    Value<String?>? diaFixo,
  }) {
    return FinLancamentoRecebersCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      idFinDocumentoOrigem: idFinDocumentoOrigem ?? this.idFinDocumentoOrigem,
      idFinNaturezaFinanceira:
          idFinNaturezaFinanceira ?? this.idFinNaturezaFinanceira,
      quantidadeParcela: quantidadeParcela ?? this.quantidadeParcela,
      valorAReceber: valorAReceber ?? this.valorAReceber,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      numeroDocumento: numeroDocumento ?? this.numeroDocumento,
      primeiroVencimento: primeiroVencimento ?? this.primeiroVencimento,
      taxaComissao: taxaComissao ?? this.taxaComissao,
      valorComissao: valorComissao ?? this.valorComissao,
      intervaloEntreParcelas:
          intervaloEntreParcelas ?? this.intervaloEntreParcelas,
      diaFixo: diaFixo ?? this.diaFixo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (idFinDocumentoOrigem.present) {
      map['id_fin_documento_origem'] = Variable<int>(
        idFinDocumentoOrigem.value,
      );
    }
    if (idFinNaturezaFinanceira.present) {
      map['id_fin_natureza_financeira'] = Variable<int>(
        idFinNaturezaFinanceira.value,
      );
    }
    if (quantidadeParcela.present) {
      map['quantidade_parcela'] = Variable<int>(quantidadeParcela.value);
    }
    if (valorAReceber.present) {
      map['valor_a_receber'] = Variable<double>(valorAReceber.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (numeroDocumento.present) {
      map['numero_documento'] = Variable<String>(numeroDocumento.value);
    }
    if (primeiroVencimento.present) {
      map['primeiro_vencimento'] = Variable<DateTime>(primeiroVencimento.value);
    }
    if (taxaComissao.present) {
      map['taxa_comissao'] = Variable<double>(taxaComissao.value);
    }
    if (valorComissao.present) {
      map['valor_comissao'] = Variable<double>(valorComissao.value);
    }
    if (intervaloEntreParcelas.present) {
      map['intervalo_entre_parcelas'] = Variable<int>(
        intervaloEntreParcelas.value,
      );
    }
    if (diaFixo.present) {
      map['dia_fixo'] = Variable<String>(diaFixo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinLancamentoRecebersCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('idFinDocumentoOrigem: $idFinDocumentoOrigem, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('quantidadeParcela: $quantidadeParcela, ')
          ..write('valorAReceber: $valorAReceber, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('primeiroVencimento: $primeiroVencimento, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixo: $diaFixo')
          ..write(')'))
        .toString();
  }
}

class $BancosTable extends Bancos with TableInfo<$BancosTable, Banco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
    'url',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, url];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco';
  @override
  VerificationContext validateIntegrity(
    Insertable<Banco> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('url')) {
      context.handle(
        _urlMeta,
        url.isAcceptableOrUnknown(data['url']!, _urlMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Banco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Banco(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      url: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}url'],
      ),
    );
  }

  @override
  $BancosTable createAlias(String alias) {
    return $BancosTable(attachedDatabase, alias);
  }
}

class Banco extends DataClass implements Insertable<Banco> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? url;
  const Banco({this.id, this.codigo, this.nome, this.url});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || url != null) {
      map['url'] = Variable<String>(url);
    }
    return map;
  }

  factory Banco.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Banco(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      url: serializer.fromJson<String?>(json['url']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'url': serializer.toJson<String?>(url),
    };
  }

  Banco copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> url = const Value.absent(),
  }) => Banco(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    nome: nome.present ? nome.value : this.nome,
    url: url.present ? url.value : this.url,
  );
  Banco copyWithCompanion(BancosCompanion data) {
    return Banco(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
      url: data.url.present ? data.url.value : this.url,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Banco(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, url);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Banco &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.url == this.url);
}

class BancosCompanion extends UpdateCompanion<Banco> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> url;
  const BancosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  BancosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  static Insertable<Banco> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? url,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (url != null) 'url': url,
    });
  }

  BancosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? nome,
    Value<String?>? url,
  }) {
    return BancosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      url: url ?? this.url,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }
}

class $BancoAgenciasTable extends BancoAgencias
    with TableInfo<$BancoAgenciasTable, BancoAgencia> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoAgenciasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoMeta = const VerificationMeta(
    'idBanco',
  );
  @override
  late final GeneratedColumn<int> idBanco = GeneratedColumn<int>(
    'id_banco',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
    'digito',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _telefoneMeta = const VerificationMeta(
    'telefone',
  );
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
    'telefone',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 15,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _contatoMeta = const VerificationMeta(
    'contato',
  );
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
    'contato',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _gerenteMeta = const VerificationMeta(
    'gerente',
  );
  @override
  late final GeneratedColumn<String> gerente = GeneratedColumn<String>(
    'gerente',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBanco,
    numero,
    digito,
    nome,
    telefone,
    contato,
    gerente,
    observacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco_agencia';
  @override
  VerificationContext validateIntegrity(
    Insertable<BancoAgencia> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco')) {
      context.handle(
        _idBancoMeta,
        idBanco.isAcceptableOrUnknown(data['id_banco']!, _idBancoMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('digito')) {
      context.handle(
        _digitoMeta,
        digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('telefone')) {
      context.handle(
        _telefoneMeta,
        telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta),
      );
    }
    if (data.containsKey('contato')) {
      context.handle(
        _contatoMeta,
        contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta),
      );
    }
    if (data.containsKey('gerente')) {
      context.handle(
        _gerenteMeta,
        gerente.isAcceptableOrUnknown(data['gerente']!, _gerenteMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoAgencia map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoAgencia(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBanco: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      digito: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}digito'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      telefone: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}telefone'],
      ),
      contato: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}contato'],
      ),
      gerente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}gerente'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
    );
  }

  @override
  $BancoAgenciasTable createAlias(String alias) {
    return $BancoAgenciasTable(attachedDatabase, alias);
  }
}

class BancoAgencia extends DataClass implements Insertable<BancoAgencia> {
  final int? id;
  final int? idBanco;
  final String? numero;
  final String? digito;
  final String? nome;
  final String? telefone;
  final String? contato;
  final String? gerente;
  final String? observacao;
  const BancoAgencia({
    this.id,
    this.idBanco,
    this.numero,
    this.digito,
    this.nome,
    this.telefone,
    this.contato,
    this.gerente,
    this.observacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBanco != null) {
      map['id_banco'] = Variable<int>(idBanco);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || gerente != null) {
      map['gerente'] = Variable<String>(gerente);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory BancoAgencia.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoAgencia(
      id: serializer.fromJson<int?>(json['id']),
      idBanco: serializer.fromJson<int?>(json['idBanco']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      nome: serializer.fromJson<String?>(json['nome']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      contato: serializer.fromJson<String?>(json['contato']),
      gerente: serializer.fromJson<String?>(json['gerente']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBanco': serializer.toJson<int?>(idBanco),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'nome': serializer.toJson<String?>(nome),
      'telefone': serializer.toJson<String?>(telefone),
      'contato': serializer.toJson<String?>(contato),
      'gerente': serializer.toJson<String?>(gerente),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  BancoAgencia copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBanco = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> digito = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> telefone = const Value.absent(),
    Value<String?> contato = const Value.absent(),
    Value<String?> gerente = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
  }) => BancoAgencia(
    id: id.present ? id.value : this.id,
    idBanco: idBanco.present ? idBanco.value : this.idBanco,
    numero: numero.present ? numero.value : this.numero,
    digito: digito.present ? digito.value : this.digito,
    nome: nome.present ? nome.value : this.nome,
    telefone: telefone.present ? telefone.value : this.telefone,
    contato: contato.present ? contato.value : this.contato,
    gerente: gerente.present ? gerente.value : this.gerente,
    observacao: observacao.present ? observacao.value : this.observacao,
  );
  BancoAgencia copyWithCompanion(BancoAgenciasCompanion data) {
    return BancoAgencia(
      id: data.id.present ? data.id.value : this.id,
      idBanco: data.idBanco.present ? data.idBanco.value : this.idBanco,
      numero: data.numero.present ? data.numero.value : this.numero,
      digito: data.digito.present ? data.digito.value : this.digito,
      nome: data.nome.present ? data.nome.value : this.nome,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
      contato: data.contato.present ? data.contato.value : this.contato,
      gerente: data.gerente.present ? data.gerente.value : this.gerente,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BancoAgencia(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBanco,
    numero,
    digito,
    nome,
    telefone,
    contato,
    gerente,
    observacao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoAgencia &&
          other.id == this.id &&
          other.idBanco == this.idBanco &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.nome == this.nome &&
          other.telefone == this.telefone &&
          other.contato == this.contato &&
          other.gerente == this.gerente &&
          other.observacao == this.observacao);
}

class BancoAgenciasCompanion extends UpdateCompanion<BancoAgencia> {
  final Value<int?> id;
  final Value<int?> idBanco;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> nome;
  final Value<String?> telefone;
  final Value<String?> contato;
  final Value<String?> gerente;
  final Value<String?> observacao;
  const BancoAgenciasCompanion({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  BancoAgenciasCompanion.insert({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<BancoAgencia> custom({
    Expression<int>? id,
    Expression<int>? idBanco,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? nome,
    Expression<String>? telefone,
    Expression<String>? contato,
    Expression<String>? gerente,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBanco != null) 'id_banco': idBanco,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (nome != null) 'nome': nome,
      if (telefone != null) 'telefone': telefone,
      if (contato != null) 'contato': contato,
      if (gerente != null) 'gerente': gerente,
      if (observacao != null) 'observacao': observacao,
    });
  }

  BancoAgenciasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBanco,
    Value<String?>? numero,
    Value<String?>? digito,
    Value<String?>? nome,
    Value<String?>? telefone,
    Value<String?>? contato,
    Value<String?>? gerente,
    Value<String?>? observacao,
  }) {
    return BancoAgenciasCompanion(
      id: id ?? this.id,
      idBanco: idBanco ?? this.idBanco,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      nome: nome ?? this.nome,
      telefone: telefone ?? this.telefone,
      contato: contato ?? this.contato,
      gerente: gerente ?? this.gerente,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBanco.present) {
      map['id_banco'] = Variable<int>(idBanco.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (gerente.present) {
      map['gerente'] = Variable<String>(gerente.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoAgenciasCompanion(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $BancoContaCaixasTable extends BancoContaCaixas
    with TableInfo<$BancoContaCaixasTable, BancoContaCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoContaCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoAgenciaMeta = const VerificationMeta(
    'idBancoAgencia',
  );
  @override
  late final GeneratedColumn<int> idBancoAgencia = GeneratedColumn<int>(
    'id_banco_agencia',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
    'digito',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoAgencia,
    numero,
    digito,
    nome,
    tipo,
    descricao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco_conta_caixa';
  @override
  VerificationContext validateIntegrity(
    Insertable<BancoContaCaixa> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_agencia')) {
      context.handle(
        _idBancoAgenciaMeta,
        idBancoAgencia.isAcceptableOrUnknown(
          data['id_banco_agencia']!,
          _idBancoAgenciaMeta,
        ),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('digito')) {
      context.handle(
        _digitoMeta,
        digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoContaCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoContaCaixa(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoAgencia: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_agencia'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      digito: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}digito'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $BancoContaCaixasTable createAlias(String alias) {
    return $BancoContaCaixasTable(attachedDatabase, alias);
  }
}

class BancoContaCaixa extends DataClass implements Insertable<BancoContaCaixa> {
  final int? id;
  final int? idBancoAgencia;
  final String? numero;
  final String? digito;
  final String? nome;
  final String? tipo;
  final String? descricao;
  const BancoContaCaixa({
    this.id,
    this.idBancoAgencia,
    this.numero,
    this.digito,
    this.nome,
    this.tipo,
    this.descricao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoAgencia != null) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory BancoContaCaixa.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoContaCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idBancoAgencia: serializer.fromJson<int?>(json['idBancoAgencia']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoAgencia': serializer.toJson<int?>(idBancoAgencia),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  BancoContaCaixa copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoAgencia = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> digito = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => BancoContaCaixa(
    id: id.present ? id.value : this.id,
    idBancoAgencia:
        idBancoAgencia.present ? idBancoAgencia.value : this.idBancoAgencia,
    numero: numero.present ? numero.value : this.numero,
    digito: digito.present ? digito.value : this.digito,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  BancoContaCaixa copyWithCompanion(BancoContaCaixasCompanion data) {
    return BancoContaCaixa(
      id: data.id.present ? data.id.value : this.id,
      idBancoAgencia:
          data.idBancoAgencia.present
              ? data.idBancoAgencia.value
              : this.idBancoAgencia,
      numero: data.numero.present ? data.numero.value : this.numero,
      digito: data.digito.present ? data.digito.value : this.digito,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BancoContaCaixa(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idBancoAgencia, numero, digito, nome, tipo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoContaCaixa &&
          other.id == this.id &&
          other.idBancoAgencia == this.idBancoAgencia &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao);
}

class BancoContaCaixasCompanion extends UpdateCompanion<BancoContaCaixa> {
  final Value<int?> id;
  final Value<int?> idBancoAgencia;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> descricao;
  const BancoContaCaixasCompanion({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  BancoContaCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<BancoContaCaixa> custom({
    Expression<int>? id,
    Expression<int>? idBancoAgencia,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoAgencia != null) 'id_banco_agencia': idBancoAgencia,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  BancoContaCaixasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoAgencia,
    Value<String?>? numero,
    Value<String?>? digito,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? descricao,
  }) {
    return BancoContaCaixasCompanion(
      id: id ?? this.id,
      idBancoAgencia: idBancoAgencia ?? this.idBancoAgencia,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoAgencia.present) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoContaCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FinFechamentoCaixaBancosTable extends FinFechamentoCaixaBancos
    with TableInfo<$FinFechamentoCaixaBancosTable, FinFechamentoCaixaBanco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinFechamentoCaixaBancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataFechamentoMeta = const VerificationMeta(
    'dataFechamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataFechamento =
      GeneratedColumn<DateTime>(
        'data_fechamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _mesAnoMeta = const VerificationMeta('mesAno');
  @override
  late final GeneratedColumn<String> mesAno = GeneratedColumn<String>(
    'mes_ano',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 7,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _mesMeta = const VerificationMeta('mes');
  @override
  late final GeneratedColumn<String> mes = GeneratedColumn<String>(
    'mes',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
    'ano',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 4,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _saldoAnteriorMeta = const VerificationMeta(
    'saldoAnterior',
  );
  @override
  late final GeneratedColumn<double> saldoAnterior = GeneratedColumn<double>(
    'saldo_anterior',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _recebimentosMeta = const VerificationMeta(
    'recebimentos',
  );
  @override
  late final GeneratedColumn<double> recebimentos = GeneratedColumn<double>(
    'recebimentos',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pagamentosMeta = const VerificationMeta(
    'pagamentos',
  );
  @override
  late final GeneratedColumn<double> pagamentos = GeneratedColumn<double>(
    'pagamentos',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _saldoContaMeta = const VerificationMeta(
    'saldoConta',
  );
  @override
  late final GeneratedColumn<double> saldoConta = GeneratedColumn<double>(
    'saldo_conta',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _chequeNaoCompensadoMeta =
      const VerificationMeta('chequeNaoCompensado');
  @override
  late final GeneratedColumn<double> chequeNaoCompensado =
      GeneratedColumn<double>(
        'cheque_nao_compensado',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _saldoDisponivelMeta = const VerificationMeta(
    'saldoDisponivel',
  );
  @override
  late final GeneratedColumn<double> saldoDisponivel = GeneratedColumn<double>(
    'saldo_disponivel',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    dataFechamento,
    mesAno,
    mes,
    ano,
    saldoAnterior,
    recebimentos,
    pagamentos,
    saldoConta,
    chequeNaoCompensado,
    saldoDisponivel,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_fechamento_caixa_banco';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinFechamentoCaixaBanco> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('data_fechamento')) {
      context.handle(
        _dataFechamentoMeta,
        dataFechamento.isAcceptableOrUnknown(
          data['data_fechamento']!,
          _dataFechamentoMeta,
        ),
      );
    }
    if (data.containsKey('mes_ano')) {
      context.handle(
        _mesAnoMeta,
        mesAno.isAcceptableOrUnknown(data['mes_ano']!, _mesAnoMeta),
      );
    }
    if (data.containsKey('mes')) {
      context.handle(
        _mesMeta,
        mes.isAcceptableOrUnknown(data['mes']!, _mesMeta),
      );
    }
    if (data.containsKey('ano')) {
      context.handle(
        _anoMeta,
        ano.isAcceptableOrUnknown(data['ano']!, _anoMeta),
      );
    }
    if (data.containsKey('saldo_anterior')) {
      context.handle(
        _saldoAnteriorMeta,
        saldoAnterior.isAcceptableOrUnknown(
          data['saldo_anterior']!,
          _saldoAnteriorMeta,
        ),
      );
    }
    if (data.containsKey('recebimentos')) {
      context.handle(
        _recebimentosMeta,
        recebimentos.isAcceptableOrUnknown(
          data['recebimentos']!,
          _recebimentosMeta,
        ),
      );
    }
    if (data.containsKey('pagamentos')) {
      context.handle(
        _pagamentosMeta,
        pagamentos.isAcceptableOrUnknown(data['pagamentos']!, _pagamentosMeta),
      );
    }
    if (data.containsKey('saldo_conta')) {
      context.handle(
        _saldoContaMeta,
        saldoConta.isAcceptableOrUnknown(data['saldo_conta']!, _saldoContaMeta),
      );
    }
    if (data.containsKey('cheque_nao_compensado')) {
      context.handle(
        _chequeNaoCompensadoMeta,
        chequeNaoCompensado.isAcceptableOrUnknown(
          data['cheque_nao_compensado']!,
          _chequeNaoCompensadoMeta,
        ),
      );
    }
    if (data.containsKey('saldo_disponivel')) {
      context.handle(
        _saldoDisponivelMeta,
        saldoDisponivel.isAcceptableOrUnknown(
          data['saldo_disponivel']!,
          _saldoDisponivelMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinFechamentoCaixaBanco map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinFechamentoCaixaBanco(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      dataFechamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_fechamento'],
      ),
      mesAno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mes_ano'],
      ),
      mes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mes'],
      ),
      ano: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ano'],
      ),
      saldoAnterior: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}saldo_anterior'],
      ),
      recebimentos: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}recebimentos'],
      ),
      pagamentos: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}pagamentos'],
      ),
      saldoConta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}saldo_conta'],
      ),
      chequeNaoCompensado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}cheque_nao_compensado'],
      ),
      saldoDisponivel: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}saldo_disponivel'],
      ),
    );
  }

  @override
  $FinFechamentoCaixaBancosTable createAlias(String alias) {
    return $FinFechamentoCaixaBancosTable(attachedDatabase, alias);
  }
}

class FinFechamentoCaixaBanco extends DataClass
    implements Insertable<FinFechamentoCaixaBanco> {
  final int? id;
  final int? idBancoContaCaixa;
  final DateTime? dataFechamento;
  final String? mesAno;
  final String? mes;
  final String? ano;
  final double? saldoAnterior;
  final double? recebimentos;
  final double? pagamentos;
  final double? saldoConta;
  final double? chequeNaoCompensado;
  final double? saldoDisponivel;
  const FinFechamentoCaixaBanco({
    this.id,
    this.idBancoContaCaixa,
    this.dataFechamento,
    this.mesAno,
    this.mes,
    this.ano,
    this.saldoAnterior,
    this.recebimentos,
    this.pagamentos,
    this.saldoConta,
    this.chequeNaoCompensado,
    this.saldoDisponivel,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || dataFechamento != null) {
      map['data_fechamento'] = Variable<DateTime>(dataFechamento);
    }
    if (!nullToAbsent || mesAno != null) {
      map['mes_ano'] = Variable<String>(mesAno);
    }
    if (!nullToAbsent || mes != null) {
      map['mes'] = Variable<String>(mes);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || saldoAnterior != null) {
      map['saldo_anterior'] = Variable<double>(saldoAnterior);
    }
    if (!nullToAbsent || recebimentos != null) {
      map['recebimentos'] = Variable<double>(recebimentos);
    }
    if (!nullToAbsent || pagamentos != null) {
      map['pagamentos'] = Variable<double>(pagamentos);
    }
    if (!nullToAbsent || saldoConta != null) {
      map['saldo_conta'] = Variable<double>(saldoConta);
    }
    if (!nullToAbsent || chequeNaoCompensado != null) {
      map['cheque_nao_compensado'] = Variable<double>(chequeNaoCompensado);
    }
    if (!nullToAbsent || saldoDisponivel != null) {
      map['saldo_disponivel'] = Variable<double>(saldoDisponivel);
    }
    return map;
  }

  factory FinFechamentoCaixaBanco.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinFechamentoCaixaBanco(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      dataFechamento: serializer.fromJson<DateTime?>(json['dataFechamento']),
      mesAno: serializer.fromJson<String?>(json['mesAno']),
      mes: serializer.fromJson<String?>(json['mes']),
      ano: serializer.fromJson<String?>(json['ano']),
      saldoAnterior: serializer.fromJson<double?>(json['saldoAnterior']),
      recebimentos: serializer.fromJson<double?>(json['recebimentos']),
      pagamentos: serializer.fromJson<double?>(json['pagamentos']),
      saldoConta: serializer.fromJson<double?>(json['saldoConta']),
      chequeNaoCompensado: serializer.fromJson<double?>(
        json['chequeNaoCompensado'],
      ),
      saldoDisponivel: serializer.fromJson<double?>(json['saldoDisponivel']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'dataFechamento': serializer.toJson<DateTime?>(dataFechamento),
      'mesAno': serializer.toJson<String?>(mesAno),
      'mes': serializer.toJson<String?>(mes),
      'ano': serializer.toJson<String?>(ano),
      'saldoAnterior': serializer.toJson<double?>(saldoAnterior),
      'recebimentos': serializer.toJson<double?>(recebimentos),
      'pagamentos': serializer.toJson<double?>(pagamentos),
      'saldoConta': serializer.toJson<double?>(saldoConta),
      'chequeNaoCompensado': serializer.toJson<double?>(chequeNaoCompensado),
      'saldoDisponivel': serializer.toJson<double?>(saldoDisponivel),
    };
  }

  FinFechamentoCaixaBanco copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<DateTime?> dataFechamento = const Value.absent(),
    Value<String?> mesAno = const Value.absent(),
    Value<String?> mes = const Value.absent(),
    Value<String?> ano = const Value.absent(),
    Value<double?> saldoAnterior = const Value.absent(),
    Value<double?> recebimentos = const Value.absent(),
    Value<double?> pagamentos = const Value.absent(),
    Value<double?> saldoConta = const Value.absent(),
    Value<double?> chequeNaoCompensado = const Value.absent(),
    Value<double?> saldoDisponivel = const Value.absent(),
  }) => FinFechamentoCaixaBanco(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    dataFechamento:
        dataFechamento.present ? dataFechamento.value : this.dataFechamento,
    mesAno: mesAno.present ? mesAno.value : this.mesAno,
    mes: mes.present ? mes.value : this.mes,
    ano: ano.present ? ano.value : this.ano,
    saldoAnterior:
        saldoAnterior.present ? saldoAnterior.value : this.saldoAnterior,
    recebimentos: recebimentos.present ? recebimentos.value : this.recebimentos,
    pagamentos: pagamentos.present ? pagamentos.value : this.pagamentos,
    saldoConta: saldoConta.present ? saldoConta.value : this.saldoConta,
    chequeNaoCompensado:
        chequeNaoCompensado.present
            ? chequeNaoCompensado.value
            : this.chequeNaoCompensado,
    saldoDisponivel:
        saldoDisponivel.present ? saldoDisponivel.value : this.saldoDisponivel,
  );
  FinFechamentoCaixaBanco copyWithCompanion(
    FinFechamentoCaixaBancosCompanion data,
  ) {
    return FinFechamentoCaixaBanco(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      dataFechamento:
          data.dataFechamento.present
              ? data.dataFechamento.value
              : this.dataFechamento,
      mesAno: data.mesAno.present ? data.mesAno.value : this.mesAno,
      mes: data.mes.present ? data.mes.value : this.mes,
      ano: data.ano.present ? data.ano.value : this.ano,
      saldoAnterior:
          data.saldoAnterior.present
              ? data.saldoAnterior.value
              : this.saldoAnterior,
      recebimentos:
          data.recebimentos.present
              ? data.recebimentos.value
              : this.recebimentos,
      pagamentos:
          data.pagamentos.present ? data.pagamentos.value : this.pagamentos,
      saldoConta:
          data.saldoConta.present ? data.saldoConta.value : this.saldoConta,
      chequeNaoCompensado:
          data.chequeNaoCompensado.present
              ? data.chequeNaoCompensado.value
              : this.chequeNaoCompensado,
      saldoDisponivel:
          data.saldoDisponivel.present
              ? data.saldoDisponivel.value
              : this.saldoDisponivel,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinFechamentoCaixaBanco(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataFechamento: $dataFechamento, ')
          ..write('mesAno: $mesAno, ')
          ..write('mes: $mes, ')
          ..write('ano: $ano, ')
          ..write('saldoAnterior: $saldoAnterior, ')
          ..write('recebimentos: $recebimentos, ')
          ..write('pagamentos: $pagamentos, ')
          ..write('saldoConta: $saldoConta, ')
          ..write('chequeNaoCompensado: $chequeNaoCompensado, ')
          ..write('saldoDisponivel: $saldoDisponivel')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    dataFechamento,
    mesAno,
    mes,
    ano,
    saldoAnterior,
    recebimentos,
    pagamentos,
    saldoConta,
    chequeNaoCompensado,
    saldoDisponivel,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinFechamentoCaixaBanco &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.dataFechamento == this.dataFechamento &&
          other.mesAno == this.mesAno &&
          other.mes == this.mes &&
          other.ano == this.ano &&
          other.saldoAnterior == this.saldoAnterior &&
          other.recebimentos == this.recebimentos &&
          other.pagamentos == this.pagamentos &&
          other.saldoConta == this.saldoConta &&
          other.chequeNaoCompensado == this.chequeNaoCompensado &&
          other.saldoDisponivel == this.saldoDisponivel);
}

class FinFechamentoCaixaBancosCompanion
    extends UpdateCompanion<FinFechamentoCaixaBanco> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<DateTime?> dataFechamento;
  final Value<String?> mesAno;
  final Value<String?> mes;
  final Value<String?> ano;
  final Value<double?> saldoAnterior;
  final Value<double?> recebimentos;
  final Value<double?> pagamentos;
  final Value<double?> saldoConta;
  final Value<double?> chequeNaoCompensado;
  final Value<double?> saldoDisponivel;
  const FinFechamentoCaixaBancosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataFechamento = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.mes = const Value.absent(),
    this.ano = const Value.absent(),
    this.saldoAnterior = const Value.absent(),
    this.recebimentos = const Value.absent(),
    this.pagamentos = const Value.absent(),
    this.saldoConta = const Value.absent(),
    this.chequeNaoCompensado = const Value.absent(),
    this.saldoDisponivel = const Value.absent(),
  });
  FinFechamentoCaixaBancosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.dataFechamento = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.mes = const Value.absent(),
    this.ano = const Value.absent(),
    this.saldoAnterior = const Value.absent(),
    this.recebimentos = const Value.absent(),
    this.pagamentos = const Value.absent(),
    this.saldoConta = const Value.absent(),
    this.chequeNaoCompensado = const Value.absent(),
    this.saldoDisponivel = const Value.absent(),
  });
  static Insertable<FinFechamentoCaixaBanco> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<DateTime>? dataFechamento,
    Expression<String>? mesAno,
    Expression<String>? mes,
    Expression<String>? ano,
    Expression<double>? saldoAnterior,
    Expression<double>? recebimentos,
    Expression<double>? pagamentos,
    Expression<double>? saldoConta,
    Expression<double>? chequeNaoCompensado,
    Expression<double>? saldoDisponivel,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (dataFechamento != null) 'data_fechamento': dataFechamento,
      if (mesAno != null) 'mes_ano': mesAno,
      if (mes != null) 'mes': mes,
      if (ano != null) 'ano': ano,
      if (saldoAnterior != null) 'saldo_anterior': saldoAnterior,
      if (recebimentos != null) 'recebimentos': recebimentos,
      if (pagamentos != null) 'pagamentos': pagamentos,
      if (saldoConta != null) 'saldo_conta': saldoConta,
      if (chequeNaoCompensado != null)
        'cheque_nao_compensado': chequeNaoCompensado,
      if (saldoDisponivel != null) 'saldo_disponivel': saldoDisponivel,
    });
  }

  FinFechamentoCaixaBancosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<DateTime?>? dataFechamento,
    Value<String?>? mesAno,
    Value<String?>? mes,
    Value<String?>? ano,
    Value<double?>? saldoAnterior,
    Value<double?>? recebimentos,
    Value<double?>? pagamentos,
    Value<double?>? saldoConta,
    Value<double?>? chequeNaoCompensado,
    Value<double?>? saldoDisponivel,
  }) {
    return FinFechamentoCaixaBancosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      dataFechamento: dataFechamento ?? this.dataFechamento,
      mesAno: mesAno ?? this.mesAno,
      mes: mes ?? this.mes,
      ano: ano ?? this.ano,
      saldoAnterior: saldoAnterior ?? this.saldoAnterior,
      recebimentos: recebimentos ?? this.recebimentos,
      pagamentos: pagamentos ?? this.pagamentos,
      saldoConta: saldoConta ?? this.saldoConta,
      chequeNaoCompensado: chequeNaoCompensado ?? this.chequeNaoCompensado,
      saldoDisponivel: saldoDisponivel ?? this.saldoDisponivel,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (dataFechamento.present) {
      map['data_fechamento'] = Variable<DateTime>(dataFechamento.value);
    }
    if (mesAno.present) {
      map['mes_ano'] = Variable<String>(mesAno.value);
    }
    if (mes.present) {
      map['mes'] = Variable<String>(mes.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (saldoAnterior.present) {
      map['saldo_anterior'] = Variable<double>(saldoAnterior.value);
    }
    if (recebimentos.present) {
      map['recebimentos'] = Variable<double>(recebimentos.value);
    }
    if (pagamentos.present) {
      map['pagamentos'] = Variable<double>(pagamentos.value);
    }
    if (saldoConta.present) {
      map['saldo_conta'] = Variable<double>(saldoConta.value);
    }
    if (chequeNaoCompensado.present) {
      map['cheque_nao_compensado'] = Variable<double>(
        chequeNaoCompensado.value,
      );
    }
    if (saldoDisponivel.present) {
      map['saldo_disponivel'] = Variable<double>(saldoDisponivel.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinFechamentoCaixaBancosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('dataFechamento: $dataFechamento, ')
          ..write('mesAno: $mesAno, ')
          ..write('mes: $mes, ')
          ..write('ano: $ano, ')
          ..write('saldoAnterior: $saldoAnterior, ')
          ..write('recebimentos: $recebimentos, ')
          ..write('pagamentos: $pagamentos, ')
          ..write('saldoConta: $saldoConta, ')
          ..write('chequeNaoCompensado: $chequeNaoCompensado, ')
          ..write('saldoDisponivel: $saldoDisponivel')
          ..write(')'))
        .toString();
  }
}

class $FinExtratoContaBancosTable extends FinExtratoContaBancos
    with TableInfo<$FinExtratoContaBancosTable, FinExtratoContaBanco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinExtratoContaBancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _mesAnoMeta = const VerificationMeta('mesAno');
  @override
  late final GeneratedColumn<String> mesAno = GeneratedColumn<String>(
    'mes_ano',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 7,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _mesMeta = const VerificationMeta('mes');
  @override
  late final GeneratedColumn<String> mes = GeneratedColumn<String>(
    'mes',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
    'ano',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 4,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataMovimentoMeta = const VerificationMeta(
    'dataMovimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataMovimento =
      GeneratedColumn<DateTime>(
        'data_movimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataBalanceteMeta = const VerificationMeta(
    'dataBalancete',
  );
  @override
  late final GeneratedColumn<DateTime> dataBalancete =
      GeneratedColumn<DateTime>(
        'data_balancete',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _historicoMeta = const VerificationMeta(
    'historico',
  );
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
    'historico',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _documentoMeta = const VerificationMeta(
    'documento',
  );
  @override
  late final GeneratedColumn<String> documento = GeneratedColumn<String>(
    'documento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _conciliadoMeta = const VerificationMeta(
    'conciliado',
  );
  @override
  late final GeneratedColumn<String> conciliado = GeneratedColumn<String>(
    'conciliado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    mesAno,
    mes,
    ano,
    dataMovimento,
    dataBalancete,
    historico,
    documento,
    valor,
    conciliado,
    observacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_extrato_conta_banco';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinExtratoContaBanco> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('mes_ano')) {
      context.handle(
        _mesAnoMeta,
        mesAno.isAcceptableOrUnknown(data['mes_ano']!, _mesAnoMeta),
      );
    }
    if (data.containsKey('mes')) {
      context.handle(
        _mesMeta,
        mes.isAcceptableOrUnknown(data['mes']!, _mesMeta),
      );
    }
    if (data.containsKey('ano')) {
      context.handle(
        _anoMeta,
        ano.isAcceptableOrUnknown(data['ano']!, _anoMeta),
      );
    }
    if (data.containsKey('data_movimento')) {
      context.handle(
        _dataMovimentoMeta,
        dataMovimento.isAcceptableOrUnknown(
          data['data_movimento']!,
          _dataMovimentoMeta,
        ),
      );
    }
    if (data.containsKey('data_balancete')) {
      context.handle(
        _dataBalanceteMeta,
        dataBalancete.isAcceptableOrUnknown(
          data['data_balancete']!,
          _dataBalanceteMeta,
        ),
      );
    }
    if (data.containsKey('historico')) {
      context.handle(
        _historicoMeta,
        historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta),
      );
    }
    if (data.containsKey('documento')) {
      context.handle(
        _documentoMeta,
        documento.isAcceptableOrUnknown(data['documento']!, _documentoMeta),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('conciliado')) {
      context.handle(
        _conciliadoMeta,
        conciliado.isAcceptableOrUnknown(data['conciliado']!, _conciliadoMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinExtratoContaBanco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinExtratoContaBanco(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      mesAno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mes_ano'],
      ),
      mes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mes'],
      ),
      ano: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ano'],
      ),
      dataMovimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_movimento'],
      ),
      dataBalancete: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_balancete'],
      ),
      historico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}historico'],
      ),
      documento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}documento'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      conciliado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}conciliado'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
    );
  }

  @override
  $FinExtratoContaBancosTable createAlias(String alias) {
    return $FinExtratoContaBancosTable(attachedDatabase, alias);
  }
}

class FinExtratoContaBanco extends DataClass
    implements Insertable<FinExtratoContaBanco> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? mesAno;
  final String? mes;
  final String? ano;
  final DateTime? dataMovimento;
  final DateTime? dataBalancete;
  final String? historico;
  final String? documento;
  final double? valor;
  final String? conciliado;
  final String? observacao;
  const FinExtratoContaBanco({
    this.id,
    this.idBancoContaCaixa,
    this.mesAno,
    this.mes,
    this.ano,
    this.dataMovimento,
    this.dataBalancete,
    this.historico,
    this.documento,
    this.valor,
    this.conciliado,
    this.observacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || mesAno != null) {
      map['mes_ano'] = Variable<String>(mesAno);
    }
    if (!nullToAbsent || mes != null) {
      map['mes'] = Variable<String>(mes);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || dataMovimento != null) {
      map['data_movimento'] = Variable<DateTime>(dataMovimento);
    }
    if (!nullToAbsent || dataBalancete != null) {
      map['data_balancete'] = Variable<DateTime>(dataBalancete);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    if (!nullToAbsent || documento != null) {
      map['documento'] = Variable<String>(documento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || conciliado != null) {
      map['conciliado'] = Variable<String>(conciliado);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FinExtratoContaBanco.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinExtratoContaBanco(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      mesAno: serializer.fromJson<String?>(json['mesAno']),
      mes: serializer.fromJson<String?>(json['mes']),
      ano: serializer.fromJson<String?>(json['ano']),
      dataMovimento: serializer.fromJson<DateTime?>(json['dataMovimento']),
      dataBalancete: serializer.fromJson<DateTime?>(json['dataBalancete']),
      historico: serializer.fromJson<String?>(json['historico']),
      documento: serializer.fromJson<String?>(json['documento']),
      valor: serializer.fromJson<double?>(json['valor']),
      conciliado: serializer.fromJson<String?>(json['conciliado']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'mesAno': serializer.toJson<String?>(mesAno),
      'mes': serializer.toJson<String?>(mes),
      'ano': serializer.toJson<String?>(ano),
      'dataMovimento': serializer.toJson<DateTime?>(dataMovimento),
      'dataBalancete': serializer.toJson<DateTime?>(dataBalancete),
      'historico': serializer.toJson<String?>(historico),
      'documento': serializer.toJson<String?>(documento),
      'valor': serializer.toJson<double?>(valor),
      'conciliado': serializer.toJson<String?>(conciliado),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FinExtratoContaBanco copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> mesAno = const Value.absent(),
    Value<String?> mes = const Value.absent(),
    Value<String?> ano = const Value.absent(),
    Value<DateTime?> dataMovimento = const Value.absent(),
    Value<DateTime?> dataBalancete = const Value.absent(),
    Value<String?> historico = const Value.absent(),
    Value<String?> documento = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<String?> conciliado = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
  }) => FinExtratoContaBanco(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    mesAno: mesAno.present ? mesAno.value : this.mesAno,
    mes: mes.present ? mes.value : this.mes,
    ano: ano.present ? ano.value : this.ano,
    dataMovimento:
        dataMovimento.present ? dataMovimento.value : this.dataMovimento,
    dataBalancete:
        dataBalancete.present ? dataBalancete.value : this.dataBalancete,
    historico: historico.present ? historico.value : this.historico,
    documento: documento.present ? documento.value : this.documento,
    valor: valor.present ? valor.value : this.valor,
    conciliado: conciliado.present ? conciliado.value : this.conciliado,
    observacao: observacao.present ? observacao.value : this.observacao,
  );
  FinExtratoContaBanco copyWithCompanion(FinExtratoContaBancosCompanion data) {
    return FinExtratoContaBanco(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      mesAno: data.mesAno.present ? data.mesAno.value : this.mesAno,
      mes: data.mes.present ? data.mes.value : this.mes,
      ano: data.ano.present ? data.ano.value : this.ano,
      dataMovimento:
          data.dataMovimento.present
              ? data.dataMovimento.value
              : this.dataMovimento,
      dataBalancete:
          data.dataBalancete.present
              ? data.dataBalancete.value
              : this.dataBalancete,
      historico: data.historico.present ? data.historico.value : this.historico,
      documento: data.documento.present ? data.documento.value : this.documento,
      valor: data.valor.present ? data.valor.value : this.valor,
      conciliado:
          data.conciliado.present ? data.conciliado.value : this.conciliado,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinExtratoContaBanco(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('mesAno: $mesAno, ')
          ..write('mes: $mes, ')
          ..write('ano: $ano, ')
          ..write('dataMovimento: $dataMovimento, ')
          ..write('dataBalancete: $dataBalancete, ')
          ..write('historico: $historico, ')
          ..write('documento: $documento, ')
          ..write('valor: $valor, ')
          ..write('conciliado: $conciliado, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    mesAno,
    mes,
    ano,
    dataMovimento,
    dataBalancete,
    historico,
    documento,
    valor,
    conciliado,
    observacao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinExtratoContaBanco &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.mesAno == this.mesAno &&
          other.mes == this.mes &&
          other.ano == this.ano &&
          other.dataMovimento == this.dataMovimento &&
          other.dataBalancete == this.dataBalancete &&
          other.historico == this.historico &&
          other.documento == this.documento &&
          other.valor == this.valor &&
          other.conciliado == this.conciliado &&
          other.observacao == this.observacao);
}

class FinExtratoContaBancosCompanion
    extends UpdateCompanion<FinExtratoContaBanco> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> mesAno;
  final Value<String?> mes;
  final Value<String?> ano;
  final Value<DateTime?> dataMovimento;
  final Value<DateTime?> dataBalancete;
  final Value<String?> historico;
  final Value<String?> documento;
  final Value<double?> valor;
  final Value<String?> conciliado;
  final Value<String?> observacao;
  const FinExtratoContaBancosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.mes = const Value.absent(),
    this.ano = const Value.absent(),
    this.dataMovimento = const Value.absent(),
    this.dataBalancete = const Value.absent(),
    this.historico = const Value.absent(),
    this.documento = const Value.absent(),
    this.valor = const Value.absent(),
    this.conciliado = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FinExtratoContaBancosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.mes = const Value.absent(),
    this.ano = const Value.absent(),
    this.dataMovimento = const Value.absent(),
    this.dataBalancete = const Value.absent(),
    this.historico = const Value.absent(),
    this.documento = const Value.absent(),
    this.valor = const Value.absent(),
    this.conciliado = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FinExtratoContaBanco> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? mesAno,
    Expression<String>? mes,
    Expression<String>? ano,
    Expression<DateTime>? dataMovimento,
    Expression<DateTime>? dataBalancete,
    Expression<String>? historico,
    Expression<String>? documento,
    Expression<double>? valor,
    Expression<String>? conciliado,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (mesAno != null) 'mes_ano': mesAno,
      if (mes != null) 'mes': mes,
      if (ano != null) 'ano': ano,
      if (dataMovimento != null) 'data_movimento': dataMovimento,
      if (dataBalancete != null) 'data_balancete': dataBalancete,
      if (historico != null) 'historico': historico,
      if (documento != null) 'documento': documento,
      if (valor != null) 'valor': valor,
      if (conciliado != null) 'conciliado': conciliado,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FinExtratoContaBancosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? mesAno,
    Value<String?>? mes,
    Value<String?>? ano,
    Value<DateTime?>? dataMovimento,
    Value<DateTime?>? dataBalancete,
    Value<String?>? historico,
    Value<String?>? documento,
    Value<double?>? valor,
    Value<String?>? conciliado,
    Value<String?>? observacao,
  }) {
    return FinExtratoContaBancosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      mesAno: mesAno ?? this.mesAno,
      mes: mes ?? this.mes,
      ano: ano ?? this.ano,
      dataMovimento: dataMovimento ?? this.dataMovimento,
      dataBalancete: dataBalancete ?? this.dataBalancete,
      historico: historico ?? this.historico,
      documento: documento ?? this.documento,
      valor: valor ?? this.valor,
      conciliado: conciliado ?? this.conciliado,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (mesAno.present) {
      map['mes_ano'] = Variable<String>(mesAno.value);
    }
    if (mes.present) {
      map['mes'] = Variable<String>(mes.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (dataMovimento.present) {
      map['data_movimento'] = Variable<DateTime>(dataMovimento.value);
    }
    if (dataBalancete.present) {
      map['data_balancete'] = Variable<DateTime>(dataBalancete.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    if (documento.present) {
      map['documento'] = Variable<String>(documento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (conciliado.present) {
      map['conciliado'] = Variable<String>(conciliado.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinExtratoContaBancosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('mesAno: $mesAno, ')
          ..write('mes: $mes, ')
          ..write('ano: $ano, ')
          ..write('dataMovimento: $dataMovimento, ')
          ..write('dataBalancete: $dataBalancete, ')
          ..write('historico: $historico, ')
          ..write('documento: $documento, ')
          ..write('valor: $valor, ')
          ..write('conciliado: $conciliado, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FinDocumentoOrigemsTable extends FinDocumentoOrigems
    with TableInfo<$FinDocumentoOrigemsTable, FinDocumentoOrigem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinDocumentoOrigemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
    'sigla',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, sigla, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_documento_origem';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinDocumentoOrigem> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('sigla')) {
      context.handle(
        _siglaMeta,
        sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinDocumentoOrigem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinDocumentoOrigem(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      sigla: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}sigla'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $FinDocumentoOrigemsTable createAlias(String alias) {
    return $FinDocumentoOrigemsTable(attachedDatabase, alias);
  }
}

class FinDocumentoOrigem extends DataClass
    implements Insertable<FinDocumentoOrigem> {
  final int? id;
  final String? codigo;
  final String? sigla;
  final String? descricao;
  const FinDocumentoOrigem({this.id, this.codigo, this.sigla, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FinDocumentoOrigem.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinDocumentoOrigem(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'sigla': serializer.toJson<String?>(sigla),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FinDocumentoOrigem copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> sigla = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => FinDocumentoOrigem(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    sigla: sigla.present ? sigla.value : this.sigla,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  FinDocumentoOrigem copyWithCompanion(FinDocumentoOrigemsCompanion data) {
    return FinDocumentoOrigem(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      sigla: data.sigla.present ? data.sigla.value : this.sigla,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinDocumentoOrigem(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, sigla, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinDocumentoOrigem &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.sigla == this.sigla &&
          other.descricao == this.descricao);
}

class FinDocumentoOrigemsCompanion extends UpdateCompanion<FinDocumentoOrigem> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> sigla;
  final Value<String?> descricao;
  const FinDocumentoOrigemsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FinDocumentoOrigemsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FinDocumentoOrigem> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? sigla,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (sigla != null) 'sigla': sigla,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FinDocumentoOrigemsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? sigla,
    Value<String?>? descricao,
  }) {
    return FinDocumentoOrigemsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      sigla: sigla ?? this.sigla,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinDocumentoOrigemsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FinNaturezaFinanceirasTable extends FinNaturezaFinanceiras
    with TableInfo<$FinNaturezaFinanceirasTable, FinNaturezaFinanceira> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinNaturezaFinanceirasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 4,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _aplicacaoMeta = const VerificationMeta(
    'aplicacao',
  );
  @override
  late final GeneratedColumn<String> aplicacao = GeneratedColumn<String>(
    'aplicacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    codigo,
    tipo,
    descricao,
    aplicacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_natureza_financeira';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinNaturezaFinanceira> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('aplicacao')) {
      context.handle(
        _aplicacaoMeta,
        aplicacao.isAcceptableOrUnknown(data['aplicacao']!, _aplicacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinNaturezaFinanceira map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinNaturezaFinanceira(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      aplicacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}aplicacao'],
      ),
    );
  }

  @override
  $FinNaturezaFinanceirasTable createAlias(String alias) {
    return $FinNaturezaFinanceirasTable(attachedDatabase, alias);
  }
}

class FinNaturezaFinanceira extends DataClass
    implements Insertable<FinNaturezaFinanceira> {
  final int? id;
  final String? codigo;
  final String? tipo;
  final String? descricao;
  final String? aplicacao;
  const FinNaturezaFinanceira({
    this.id,
    this.codigo,
    this.tipo,
    this.descricao,
    this.aplicacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || aplicacao != null) {
      map['aplicacao'] = Variable<String>(aplicacao);
    }
    return map;
  }

  factory FinNaturezaFinanceira.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinNaturezaFinanceira(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      aplicacao: serializer.fromJson<String?>(json['aplicacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
      'aplicacao': serializer.toJson<String?>(aplicacao),
    };
  }

  FinNaturezaFinanceira copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> aplicacao = const Value.absent(),
  }) => FinNaturezaFinanceira(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    tipo: tipo.present ? tipo.value : this.tipo,
    descricao: descricao.present ? descricao.value : this.descricao,
    aplicacao: aplicacao.present ? aplicacao.value : this.aplicacao,
  );
  FinNaturezaFinanceira copyWithCompanion(
    FinNaturezaFinanceirasCompanion data,
  ) {
    return FinNaturezaFinanceira(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      aplicacao: data.aplicacao.present ? data.aplicacao.value : this.aplicacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceira(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, tipo, descricao, aplicacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinNaturezaFinanceira &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao &&
          other.aplicacao == this.aplicacao);
}

class FinNaturezaFinanceirasCompanion
    extends UpdateCompanion<FinNaturezaFinanceira> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> tipo;
  final Value<String?> descricao;
  final Value<String?> aplicacao;
  const FinNaturezaFinanceirasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  FinNaturezaFinanceirasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  static Insertable<FinNaturezaFinanceira> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? tipo,
    Expression<String>? descricao,
    Expression<String>? aplicacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
      if (aplicacao != null) 'aplicacao': aplicacao,
    });
  }

  FinNaturezaFinanceirasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? tipo,
    Value<String?>? descricao,
    Value<String?>? aplicacao,
  }) {
    return FinNaturezaFinanceirasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
      aplicacao: aplicacao ?? this.aplicacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (aplicacao.present) {
      map['aplicacao'] = Variable<String>(aplicacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceirasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }
}

class $FinStatusParcelasTable extends FinStatusParcelas
    with TableInfo<$FinStatusParcelasTable, FinStatusParcela> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinStatusParcelasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _situacaoMeta = const VerificationMeta(
    'situacao',
  );
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
    'situacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 30,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _procedimentoMeta = const VerificationMeta(
    'procedimento',
  );
  @override
  late final GeneratedColumn<String> procedimento = GeneratedColumn<String>(
    'procedimento',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, situacao, descricao, procedimento];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_status_parcela';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinStatusParcela> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(
        _situacaoMeta,
        situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('procedimento')) {
      context.handle(
        _procedimentoMeta,
        procedimento.isAcceptableOrUnknown(
          data['procedimento']!,
          _procedimentoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinStatusParcela map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinStatusParcela(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      situacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}situacao'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      procedimento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}procedimento'],
      ),
    );
  }

  @override
  $FinStatusParcelasTable createAlias(String alias) {
    return $FinStatusParcelasTable(attachedDatabase, alias);
  }
}

class FinStatusParcela extends DataClass
    implements Insertable<FinStatusParcela> {
  final int? id;
  final String? situacao;
  final String? descricao;
  final String? procedimento;
  const FinStatusParcela({
    this.id,
    this.situacao,
    this.descricao,
    this.procedimento,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || procedimento != null) {
      map['procedimento'] = Variable<String>(procedimento);
    }
    return map;
  }

  factory FinStatusParcela.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinStatusParcela(
      id: serializer.fromJson<int?>(json['id']),
      situacao: serializer.fromJson<String?>(json['situacao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      procedimento: serializer.fromJson<String?>(json['procedimento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'situacao': serializer.toJson<String?>(situacao),
      'descricao': serializer.toJson<String?>(descricao),
      'procedimento': serializer.toJson<String?>(procedimento),
    };
  }

  FinStatusParcela copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> situacao = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> procedimento = const Value.absent(),
  }) => FinStatusParcela(
    id: id.present ? id.value : this.id,
    situacao: situacao.present ? situacao.value : this.situacao,
    descricao: descricao.present ? descricao.value : this.descricao,
    procedimento: procedimento.present ? procedimento.value : this.procedimento,
  );
  FinStatusParcela copyWithCompanion(FinStatusParcelasCompanion data) {
    return FinStatusParcela(
      id: data.id.present ? data.id.value : this.id,
      situacao: data.situacao.present ? data.situacao.value : this.situacao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      procedimento:
          data.procedimento.present
              ? data.procedimento.value
              : this.procedimento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinStatusParcela(')
          ..write('id: $id, ')
          ..write('situacao: $situacao, ')
          ..write('descricao: $descricao, ')
          ..write('procedimento: $procedimento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, situacao, descricao, procedimento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinStatusParcela &&
          other.id == this.id &&
          other.situacao == this.situacao &&
          other.descricao == this.descricao &&
          other.procedimento == this.procedimento);
}

class FinStatusParcelasCompanion extends UpdateCompanion<FinStatusParcela> {
  final Value<int?> id;
  final Value<String?> situacao;
  final Value<String?> descricao;
  final Value<String?> procedimento;
  const FinStatusParcelasCompanion({
    this.id = const Value.absent(),
    this.situacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.procedimento = const Value.absent(),
  });
  FinStatusParcelasCompanion.insert({
    this.id = const Value.absent(),
    this.situacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.procedimento = const Value.absent(),
  });
  static Insertable<FinStatusParcela> custom({
    Expression<int>? id,
    Expression<String>? situacao,
    Expression<String>? descricao,
    Expression<String>? procedimento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (situacao != null) 'situacao': situacao,
      if (descricao != null) 'descricao': descricao,
      if (procedimento != null) 'procedimento': procedimento,
    });
  }

  FinStatusParcelasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? situacao,
    Value<String?>? descricao,
    Value<String?>? procedimento,
  }) {
    return FinStatusParcelasCompanion(
      id: id ?? this.id,
      situacao: situacao ?? this.situacao,
      descricao: descricao ?? this.descricao,
      procedimento: procedimento ?? this.procedimento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (procedimento.present) {
      map['procedimento'] = Variable<String>(procedimento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinStatusParcelasCompanion(')
          ..write('id: $id, ')
          ..write('situacao: $situacao, ')
          ..write('descricao: $descricao, ')
          ..write('procedimento: $procedimento')
          ..write(')'))
        .toString();
  }
}

class $FinTipoPagamentosTable extends FinTipoPagamentos
    with TableInfo<$FinTipoPagamentosTable, FinTipoPagamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinTipoPagamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 30,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_tipo_pagamento';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinTipoPagamento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinTipoPagamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinTipoPagamento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $FinTipoPagamentosTable createAlias(String alias) {
    return $FinTipoPagamentosTable(attachedDatabase, alias);
  }
}

class FinTipoPagamento extends DataClass
    implements Insertable<FinTipoPagamento> {
  final int? id;
  final String? codigo;
  final String? descricao;
  const FinTipoPagamento({this.id, this.codigo, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FinTipoPagamento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinTipoPagamento(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FinTipoPagamento copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => FinTipoPagamento(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  FinTipoPagamento copyWithCompanion(FinTipoPagamentosCompanion data) {
    return FinTipoPagamento(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinTipoPagamento(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinTipoPagamento &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao);
}

class FinTipoPagamentosCompanion extends UpdateCompanion<FinTipoPagamento> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  const FinTipoPagamentosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FinTipoPagamentosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FinTipoPagamento> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FinTipoPagamentosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? descricao,
  }) {
    return FinTipoPagamentosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinTipoPagamentosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FinChequeEmitidosTable extends FinChequeEmitidos
    with TableInfo<$FinChequeEmitidosTable, FinChequeEmitido> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinChequeEmitidosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idChequeMeta = const VerificationMeta(
    'idCheque',
  );
  @override
  late final GeneratedColumn<int> idCheque = GeneratedColumn<int>(
    'id_cheque',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bomParaMeta = const VerificationMeta(
    'bomPara',
  );
  @override
  late final GeneratedColumn<DateTime> bomPara = GeneratedColumn<DateTime>(
    'bom_para',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCompensacaoMeta = const VerificationMeta(
    'dataCompensacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataCompensacao =
      GeneratedColumn<DateTime>(
        'data_compensacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nominalAMeta = const VerificationMeta(
    'nominalA',
  );
  @override
  late final GeneratedColumn<String> nominalA = GeneratedColumn<String>(
    'nominal_a',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCheque,
    dataEmissao,
    bomPara,
    dataCompensacao,
    valor,
    nominalA,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_cheque_emitido';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinChequeEmitido> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cheque')) {
      context.handle(
        _idChequeMeta,
        idCheque.isAcceptableOrUnknown(data['id_cheque']!, _idChequeMeta),
      );
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('bom_para')) {
      context.handle(
        _bomParaMeta,
        bomPara.isAcceptableOrUnknown(data['bom_para']!, _bomParaMeta),
      );
    }
    if (data.containsKey('data_compensacao')) {
      context.handle(
        _dataCompensacaoMeta,
        dataCompensacao.isAcceptableOrUnknown(
          data['data_compensacao']!,
          _dataCompensacaoMeta,
        ),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('nominal_a')) {
      context.handle(
        _nominalAMeta,
        nominalA.isAcceptableOrUnknown(data['nominal_a']!, _nominalAMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinChequeEmitido map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinChequeEmitido(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCheque: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cheque'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      bomPara: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}bom_para'],
      ),
      dataCompensacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_compensacao'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      nominalA: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nominal_a'],
      ),
    );
  }

  @override
  $FinChequeEmitidosTable createAlias(String alias) {
    return $FinChequeEmitidosTable(attachedDatabase, alias);
  }
}

class FinChequeEmitido extends DataClass
    implements Insertable<FinChequeEmitido> {
  final int? id;
  final int? idCheque;
  final DateTime? dataEmissao;
  final DateTime? bomPara;
  final DateTime? dataCompensacao;
  final double? valor;
  final String? nominalA;
  const FinChequeEmitido({
    this.id,
    this.idCheque,
    this.dataEmissao,
    this.bomPara,
    this.dataCompensacao,
    this.valor,
    this.nominalA,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCheque != null) {
      map['id_cheque'] = Variable<int>(idCheque);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || bomPara != null) {
      map['bom_para'] = Variable<DateTime>(bomPara);
    }
    if (!nullToAbsent || dataCompensacao != null) {
      map['data_compensacao'] = Variable<DateTime>(dataCompensacao);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || nominalA != null) {
      map['nominal_a'] = Variable<String>(nominalA);
    }
    return map;
  }

  factory FinChequeEmitido.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinChequeEmitido(
      id: serializer.fromJson<int?>(json['id']),
      idCheque: serializer.fromJson<int?>(json['idCheque']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      bomPara: serializer.fromJson<DateTime?>(json['bomPara']),
      dataCompensacao: serializer.fromJson<DateTime?>(json['dataCompensacao']),
      valor: serializer.fromJson<double?>(json['valor']),
      nominalA: serializer.fromJson<String?>(json['nominalA']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCheque': serializer.toJson<int?>(idCheque),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'bomPara': serializer.toJson<DateTime?>(bomPara),
      'dataCompensacao': serializer.toJson<DateTime?>(dataCompensacao),
      'valor': serializer.toJson<double?>(valor),
      'nominalA': serializer.toJson<String?>(nominalA),
    };
  }

  FinChequeEmitido copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCheque = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> bomPara = const Value.absent(),
    Value<DateTime?> dataCompensacao = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<String?> nominalA = const Value.absent(),
  }) => FinChequeEmitido(
    id: id.present ? id.value : this.id,
    idCheque: idCheque.present ? idCheque.value : this.idCheque,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    bomPara: bomPara.present ? bomPara.value : this.bomPara,
    dataCompensacao:
        dataCompensacao.present ? dataCompensacao.value : this.dataCompensacao,
    valor: valor.present ? valor.value : this.valor,
    nominalA: nominalA.present ? nominalA.value : this.nominalA,
  );
  FinChequeEmitido copyWithCompanion(FinChequeEmitidosCompanion data) {
    return FinChequeEmitido(
      id: data.id.present ? data.id.value : this.id,
      idCheque: data.idCheque.present ? data.idCheque.value : this.idCheque,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      bomPara: data.bomPara.present ? data.bomPara.value : this.bomPara,
      dataCompensacao:
          data.dataCompensacao.present
              ? data.dataCompensacao.value
              : this.dataCompensacao,
      valor: data.valor.present ? data.valor.value : this.valor,
      nominalA: data.nominalA.present ? data.nominalA.value : this.nominalA,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinChequeEmitido(')
          ..write('id: $id, ')
          ..write('idCheque: $idCheque, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('bomPara: $bomPara, ')
          ..write('dataCompensacao: $dataCompensacao, ')
          ..write('valor: $valor, ')
          ..write('nominalA: $nominalA')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCheque,
    dataEmissao,
    bomPara,
    dataCompensacao,
    valor,
    nominalA,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinChequeEmitido &&
          other.id == this.id &&
          other.idCheque == this.idCheque &&
          other.dataEmissao == this.dataEmissao &&
          other.bomPara == this.bomPara &&
          other.dataCompensacao == this.dataCompensacao &&
          other.valor == this.valor &&
          other.nominalA == this.nominalA);
}

class FinChequeEmitidosCompanion extends UpdateCompanion<FinChequeEmitido> {
  final Value<int?> id;
  final Value<int?> idCheque;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> bomPara;
  final Value<DateTime?> dataCompensacao;
  final Value<double?> valor;
  final Value<String?> nominalA;
  const FinChequeEmitidosCompanion({
    this.id = const Value.absent(),
    this.idCheque = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.bomPara = const Value.absent(),
    this.dataCompensacao = const Value.absent(),
    this.valor = const Value.absent(),
    this.nominalA = const Value.absent(),
  });
  FinChequeEmitidosCompanion.insert({
    this.id = const Value.absent(),
    this.idCheque = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.bomPara = const Value.absent(),
    this.dataCompensacao = const Value.absent(),
    this.valor = const Value.absent(),
    this.nominalA = const Value.absent(),
  });
  static Insertable<FinChequeEmitido> custom({
    Expression<int>? id,
    Expression<int>? idCheque,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? bomPara,
    Expression<DateTime>? dataCompensacao,
    Expression<double>? valor,
    Expression<String>? nominalA,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCheque != null) 'id_cheque': idCheque,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (bomPara != null) 'bom_para': bomPara,
      if (dataCompensacao != null) 'data_compensacao': dataCompensacao,
      if (valor != null) 'valor': valor,
      if (nominalA != null) 'nominal_a': nominalA,
    });
  }

  FinChequeEmitidosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCheque,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? bomPara,
    Value<DateTime?>? dataCompensacao,
    Value<double?>? valor,
    Value<String?>? nominalA,
  }) {
    return FinChequeEmitidosCompanion(
      id: id ?? this.id,
      idCheque: idCheque ?? this.idCheque,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      bomPara: bomPara ?? this.bomPara,
      dataCompensacao: dataCompensacao ?? this.dataCompensacao,
      valor: valor ?? this.valor,
      nominalA: nominalA ?? this.nominalA,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCheque.present) {
      map['id_cheque'] = Variable<int>(idCheque.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (bomPara.present) {
      map['bom_para'] = Variable<DateTime>(bomPara.value);
    }
    if (dataCompensacao.present) {
      map['data_compensacao'] = Variable<DateTime>(dataCompensacao.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (nominalA.present) {
      map['nominal_a'] = Variable<String>(nominalA.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinChequeEmitidosCompanion(')
          ..write('id: $id, ')
          ..write('idCheque: $idCheque, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('bomPara: $bomPara, ')
          ..write('dataCompensacao: $dataCompensacao, ')
          ..write('valor: $valor, ')
          ..write('nominalA: $nominalA')
          ..write(')'))
        .toString();
  }
}

class $FinTipoRecebimentosTable extends FinTipoRecebimentos
    with TableInfo<$FinTipoRecebimentosTable, FinTipoRecebimento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinTipoRecebimentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_tipo_recebimento';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinTipoRecebimento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinTipoRecebimento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinTipoRecebimento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $FinTipoRecebimentosTable createAlias(String alias) {
    return $FinTipoRecebimentosTable(attachedDatabase, alias);
  }
}

class FinTipoRecebimento extends DataClass
    implements Insertable<FinTipoRecebimento> {
  final int? id;
  final String? codigo;
  final String? descricao;
  const FinTipoRecebimento({this.id, this.codigo, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FinTipoRecebimento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinTipoRecebimento(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FinTipoRecebimento copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => FinTipoRecebimento(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  FinTipoRecebimento copyWithCompanion(FinTipoRecebimentosCompanion data) {
    return FinTipoRecebimento(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinTipoRecebimento(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinTipoRecebimento &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao);
}

class FinTipoRecebimentosCompanion extends UpdateCompanion<FinTipoRecebimento> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  const FinTipoRecebimentosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FinTipoRecebimentosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FinTipoRecebimento> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FinTipoRecebimentosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? descricao,
  }) {
    return FinTipoRecebimentosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinTipoRecebimentosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FinChequeRecebidosTable extends FinChequeRecebidos
    with TableInfo<$FinChequeRecebidosTable, FinChequeRecebido> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinChequeRecebidosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
    'cpf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 11,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
    'cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoBancoMeta = const VerificationMeta(
    'codigoBanco',
  );
  @override
  late final GeneratedColumn<String> codigoBanco = GeneratedColumn<String>(
    'codigo_banco',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoAgenciaMeta = const VerificationMeta(
    'codigoAgencia',
  );
  @override
  late final GeneratedColumn<String> codigoAgencia = GeneratedColumn<String>(
    'codigo_agencia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _contaMeta = const VerificationMeta('conta');
  @override
  late final GeneratedColumn<String> conta = GeneratedColumn<String>(
    'conta',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
    'numero',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bomParaMeta = const VerificationMeta(
    'bomPara',
  );
  @override
  late final GeneratedColumn<DateTime> bomPara = GeneratedColumn<DateTime>(
    'bom_para',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCompensacaoMeta = const VerificationMeta(
    'dataCompensacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataCompensacao =
      GeneratedColumn<DateTime>(
        'data_compensacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custodiaDataMeta = const VerificationMeta(
    'custodiaData',
  );
  @override
  late final GeneratedColumn<DateTime> custodiaData = GeneratedColumn<DateTime>(
    'custodia_data',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custodiaTarifaMeta = const VerificationMeta(
    'custodiaTarifa',
  );
  @override
  late final GeneratedColumn<double> custodiaTarifa = GeneratedColumn<double>(
    'custodia_tarifa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custodiaComissaoMeta = const VerificationMeta(
    'custodiaComissao',
  );
  @override
  late final GeneratedColumn<double> custodiaComissao = GeneratedColumn<double>(
    'custodia_comissao',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descontoDataMeta = const VerificationMeta(
    'descontoData',
  );
  @override
  late final GeneratedColumn<DateTime> descontoData = GeneratedColumn<DateTime>(
    'desconto_data',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descontoTarifaMeta = const VerificationMeta(
    'descontoTarifa',
  );
  @override
  late final GeneratedColumn<double> descontoTarifa = GeneratedColumn<double>(
    'desconto_tarifa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descontoComissaoMeta = const VerificationMeta(
    'descontoComissao',
  );
  @override
  late final GeneratedColumn<double> descontoComissao = GeneratedColumn<double>(
    'desconto_comissao',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorRecebidoMeta = const VerificationMeta(
    'valorRecebido',
  );
  @override
  late final GeneratedColumn<double> valorRecebido = GeneratedColumn<double>(
    'valor_recebido',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    cpf,
    cnpj,
    nome,
    codigoBanco,
    codigoAgencia,
    conta,
    numero,
    dataEmissao,
    bomPara,
    dataCompensacao,
    valor,
    custodiaData,
    custodiaTarifa,
    custodiaComissao,
    descontoData,
    descontoTarifa,
    descontoComissao,
    valorRecebido,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_cheque_recebido';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinChequeRecebido> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('cpf')) {
      context.handle(
        _cpfMeta,
        cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta),
      );
    }
    if (data.containsKey('cnpj')) {
      context.handle(
        _cnpjMeta,
        cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('codigo_banco')) {
      context.handle(
        _codigoBancoMeta,
        codigoBanco.isAcceptableOrUnknown(
          data['codigo_banco']!,
          _codigoBancoMeta,
        ),
      );
    }
    if (data.containsKey('codigo_agencia')) {
      context.handle(
        _codigoAgenciaMeta,
        codigoAgencia.isAcceptableOrUnknown(
          data['codigo_agencia']!,
          _codigoAgenciaMeta,
        ),
      );
    }
    if (data.containsKey('conta')) {
      context.handle(
        _contaMeta,
        conta.isAcceptableOrUnknown(data['conta']!, _contaMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('bom_para')) {
      context.handle(
        _bomParaMeta,
        bomPara.isAcceptableOrUnknown(data['bom_para']!, _bomParaMeta),
      );
    }
    if (data.containsKey('data_compensacao')) {
      context.handle(
        _dataCompensacaoMeta,
        dataCompensacao.isAcceptableOrUnknown(
          data['data_compensacao']!,
          _dataCompensacaoMeta,
        ),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('custodia_data')) {
      context.handle(
        _custodiaDataMeta,
        custodiaData.isAcceptableOrUnknown(
          data['custodia_data']!,
          _custodiaDataMeta,
        ),
      );
    }
    if (data.containsKey('custodia_tarifa')) {
      context.handle(
        _custodiaTarifaMeta,
        custodiaTarifa.isAcceptableOrUnknown(
          data['custodia_tarifa']!,
          _custodiaTarifaMeta,
        ),
      );
    }
    if (data.containsKey('custodia_comissao')) {
      context.handle(
        _custodiaComissaoMeta,
        custodiaComissao.isAcceptableOrUnknown(
          data['custodia_comissao']!,
          _custodiaComissaoMeta,
        ),
      );
    }
    if (data.containsKey('desconto_data')) {
      context.handle(
        _descontoDataMeta,
        descontoData.isAcceptableOrUnknown(
          data['desconto_data']!,
          _descontoDataMeta,
        ),
      );
    }
    if (data.containsKey('desconto_tarifa')) {
      context.handle(
        _descontoTarifaMeta,
        descontoTarifa.isAcceptableOrUnknown(
          data['desconto_tarifa']!,
          _descontoTarifaMeta,
        ),
      );
    }
    if (data.containsKey('desconto_comissao')) {
      context.handle(
        _descontoComissaoMeta,
        descontoComissao.isAcceptableOrUnknown(
          data['desconto_comissao']!,
          _descontoComissaoMeta,
        ),
      );
    }
    if (data.containsKey('valor_recebido')) {
      context.handle(
        _valorRecebidoMeta,
        valorRecebido.isAcceptableOrUnknown(
          data['valor_recebido']!,
          _valorRecebidoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinChequeRecebido map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinChequeRecebido(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      cpf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf'],
      ),
      cnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cnpj'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      codigoBanco: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_banco'],
      ),
      codigoAgencia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_agencia'],
      ),
      conta: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}conta'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}numero'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      bomPara: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}bom_para'],
      ),
      dataCompensacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_compensacao'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      custodiaData: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}custodia_data'],
      ),
      custodiaTarifa: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custodia_tarifa'],
      ),
      custodiaComissao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custodia_comissao'],
      ),
      descontoData: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desconto_data'],
      ),
      descontoTarifa: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}desconto_tarifa'],
      ),
      descontoComissao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}desconto_comissao'],
      ),
      valorRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_recebido'],
      ),
    );
  }

  @override
  $FinChequeRecebidosTable createAlias(String alias) {
    return $FinChequeRecebidosTable(attachedDatabase, alias);
  }
}

class FinChequeRecebido extends DataClass
    implements Insertable<FinChequeRecebido> {
  final int? id;
  final int? idCliente;
  final String? cpf;
  final String? cnpj;
  final String? nome;
  final String? codigoBanco;
  final String? codigoAgencia;
  final String? conta;
  final int? numero;
  final DateTime? dataEmissao;
  final DateTime? bomPara;
  final DateTime? dataCompensacao;
  final double? valor;
  final DateTime? custodiaData;
  final double? custodiaTarifa;
  final double? custodiaComissao;
  final DateTime? descontoData;
  final double? descontoTarifa;
  final double? descontoComissao;
  final double? valorRecebido;
  const FinChequeRecebido({
    this.id,
    this.idCliente,
    this.cpf,
    this.cnpj,
    this.nome,
    this.codigoBanco,
    this.codigoAgencia,
    this.conta,
    this.numero,
    this.dataEmissao,
    this.bomPara,
    this.dataCompensacao,
    this.valor,
    this.custodiaData,
    this.custodiaTarifa,
    this.custodiaComissao,
    this.descontoData,
    this.descontoTarifa,
    this.descontoComissao,
    this.valorRecebido,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || codigoBanco != null) {
      map['codigo_banco'] = Variable<String>(codigoBanco);
    }
    if (!nullToAbsent || codigoAgencia != null) {
      map['codigo_agencia'] = Variable<String>(codigoAgencia);
    }
    if (!nullToAbsent || conta != null) {
      map['conta'] = Variable<String>(conta);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || bomPara != null) {
      map['bom_para'] = Variable<DateTime>(bomPara);
    }
    if (!nullToAbsent || dataCompensacao != null) {
      map['data_compensacao'] = Variable<DateTime>(dataCompensacao);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || custodiaData != null) {
      map['custodia_data'] = Variable<DateTime>(custodiaData);
    }
    if (!nullToAbsent || custodiaTarifa != null) {
      map['custodia_tarifa'] = Variable<double>(custodiaTarifa);
    }
    if (!nullToAbsent || custodiaComissao != null) {
      map['custodia_comissao'] = Variable<double>(custodiaComissao);
    }
    if (!nullToAbsent || descontoData != null) {
      map['desconto_data'] = Variable<DateTime>(descontoData);
    }
    if (!nullToAbsent || descontoTarifa != null) {
      map['desconto_tarifa'] = Variable<double>(descontoTarifa);
    }
    if (!nullToAbsent || descontoComissao != null) {
      map['desconto_comissao'] = Variable<double>(descontoComissao);
    }
    if (!nullToAbsent || valorRecebido != null) {
      map['valor_recebido'] = Variable<double>(valorRecebido);
    }
    return map;
  }

  factory FinChequeRecebido.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinChequeRecebido(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      nome: serializer.fromJson<String?>(json['nome']),
      codigoBanco: serializer.fromJson<String?>(json['codigoBanco']),
      codigoAgencia: serializer.fromJson<String?>(json['codigoAgencia']),
      conta: serializer.fromJson<String?>(json['conta']),
      numero: serializer.fromJson<int?>(json['numero']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      bomPara: serializer.fromJson<DateTime?>(json['bomPara']),
      dataCompensacao: serializer.fromJson<DateTime?>(json['dataCompensacao']),
      valor: serializer.fromJson<double?>(json['valor']),
      custodiaData: serializer.fromJson<DateTime?>(json['custodiaData']),
      custodiaTarifa: serializer.fromJson<double?>(json['custodiaTarifa']),
      custodiaComissao: serializer.fromJson<double?>(json['custodiaComissao']),
      descontoData: serializer.fromJson<DateTime?>(json['descontoData']),
      descontoTarifa: serializer.fromJson<double?>(json['descontoTarifa']),
      descontoComissao: serializer.fromJson<double?>(json['descontoComissao']),
      valorRecebido: serializer.fromJson<double?>(json['valorRecebido']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'cpf': serializer.toJson<String?>(cpf),
      'cnpj': serializer.toJson<String?>(cnpj),
      'nome': serializer.toJson<String?>(nome),
      'codigoBanco': serializer.toJson<String?>(codigoBanco),
      'codigoAgencia': serializer.toJson<String?>(codigoAgencia),
      'conta': serializer.toJson<String?>(conta),
      'numero': serializer.toJson<int?>(numero),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'bomPara': serializer.toJson<DateTime?>(bomPara),
      'dataCompensacao': serializer.toJson<DateTime?>(dataCompensacao),
      'valor': serializer.toJson<double?>(valor),
      'custodiaData': serializer.toJson<DateTime?>(custodiaData),
      'custodiaTarifa': serializer.toJson<double?>(custodiaTarifa),
      'custodiaComissao': serializer.toJson<double?>(custodiaComissao),
      'descontoData': serializer.toJson<DateTime?>(descontoData),
      'descontoTarifa': serializer.toJson<double?>(descontoTarifa),
      'descontoComissao': serializer.toJson<double?>(descontoComissao),
      'valorRecebido': serializer.toJson<double?>(valorRecebido),
    };
  }

  FinChequeRecebido copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<String?> cpf = const Value.absent(),
    Value<String?> cnpj = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> codigoBanco = const Value.absent(),
    Value<String?> codigoAgencia = const Value.absent(),
    Value<String?> conta = const Value.absent(),
    Value<int?> numero = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> bomPara = const Value.absent(),
    Value<DateTime?> dataCompensacao = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<DateTime?> custodiaData = const Value.absent(),
    Value<double?> custodiaTarifa = const Value.absent(),
    Value<double?> custodiaComissao = const Value.absent(),
    Value<DateTime?> descontoData = const Value.absent(),
    Value<double?> descontoTarifa = const Value.absent(),
    Value<double?> descontoComissao = const Value.absent(),
    Value<double?> valorRecebido = const Value.absent(),
  }) => FinChequeRecebido(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    cpf: cpf.present ? cpf.value : this.cpf,
    cnpj: cnpj.present ? cnpj.value : this.cnpj,
    nome: nome.present ? nome.value : this.nome,
    codigoBanco: codigoBanco.present ? codigoBanco.value : this.codigoBanco,
    codigoAgencia:
        codigoAgencia.present ? codigoAgencia.value : this.codigoAgencia,
    conta: conta.present ? conta.value : this.conta,
    numero: numero.present ? numero.value : this.numero,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    bomPara: bomPara.present ? bomPara.value : this.bomPara,
    dataCompensacao:
        dataCompensacao.present ? dataCompensacao.value : this.dataCompensacao,
    valor: valor.present ? valor.value : this.valor,
    custodiaData: custodiaData.present ? custodiaData.value : this.custodiaData,
    custodiaTarifa:
        custodiaTarifa.present ? custodiaTarifa.value : this.custodiaTarifa,
    custodiaComissao:
        custodiaComissao.present
            ? custodiaComissao.value
            : this.custodiaComissao,
    descontoData: descontoData.present ? descontoData.value : this.descontoData,
    descontoTarifa:
        descontoTarifa.present ? descontoTarifa.value : this.descontoTarifa,
    descontoComissao:
        descontoComissao.present
            ? descontoComissao.value
            : this.descontoComissao,
    valorRecebido:
        valorRecebido.present ? valorRecebido.value : this.valorRecebido,
  );
  FinChequeRecebido copyWithCompanion(FinChequeRecebidosCompanion data) {
    return FinChequeRecebido(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      cpf: data.cpf.present ? data.cpf.value : this.cpf,
      cnpj: data.cnpj.present ? data.cnpj.value : this.cnpj,
      nome: data.nome.present ? data.nome.value : this.nome,
      codigoBanco:
          data.codigoBanco.present ? data.codigoBanco.value : this.codigoBanco,
      codigoAgencia:
          data.codigoAgencia.present
              ? data.codigoAgencia.value
              : this.codigoAgencia,
      conta: data.conta.present ? data.conta.value : this.conta,
      numero: data.numero.present ? data.numero.value : this.numero,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      bomPara: data.bomPara.present ? data.bomPara.value : this.bomPara,
      dataCompensacao:
          data.dataCompensacao.present
              ? data.dataCompensacao.value
              : this.dataCompensacao,
      valor: data.valor.present ? data.valor.value : this.valor,
      custodiaData:
          data.custodiaData.present
              ? data.custodiaData.value
              : this.custodiaData,
      custodiaTarifa:
          data.custodiaTarifa.present
              ? data.custodiaTarifa.value
              : this.custodiaTarifa,
      custodiaComissao:
          data.custodiaComissao.present
              ? data.custodiaComissao.value
              : this.custodiaComissao,
      descontoData:
          data.descontoData.present
              ? data.descontoData.value
              : this.descontoData,
      descontoTarifa:
          data.descontoTarifa.present
              ? data.descontoTarifa.value
              : this.descontoTarifa,
      descontoComissao:
          data.descontoComissao.present
              ? data.descontoComissao.value
              : this.descontoComissao,
      valorRecebido:
          data.valorRecebido.present
              ? data.valorRecebido.value
              : this.valorRecebido,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinChequeRecebido(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('cpf: $cpf, ')
          ..write('cnpj: $cnpj, ')
          ..write('nome: $nome, ')
          ..write('codigoBanco: $codigoBanco, ')
          ..write('codigoAgencia: $codigoAgencia, ')
          ..write('conta: $conta, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('bomPara: $bomPara, ')
          ..write('dataCompensacao: $dataCompensacao, ')
          ..write('valor: $valor, ')
          ..write('custodiaData: $custodiaData, ')
          ..write('custodiaTarifa: $custodiaTarifa, ')
          ..write('custodiaComissao: $custodiaComissao, ')
          ..write('descontoData: $descontoData, ')
          ..write('descontoTarifa: $descontoTarifa, ')
          ..write('descontoComissao: $descontoComissao, ')
          ..write('valorRecebido: $valorRecebido')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    cpf,
    cnpj,
    nome,
    codigoBanco,
    codigoAgencia,
    conta,
    numero,
    dataEmissao,
    bomPara,
    dataCompensacao,
    valor,
    custodiaData,
    custodiaTarifa,
    custodiaComissao,
    descontoData,
    descontoTarifa,
    descontoComissao,
    valorRecebido,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinChequeRecebido &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.cpf == this.cpf &&
          other.cnpj == this.cnpj &&
          other.nome == this.nome &&
          other.codigoBanco == this.codigoBanco &&
          other.codigoAgencia == this.codigoAgencia &&
          other.conta == this.conta &&
          other.numero == this.numero &&
          other.dataEmissao == this.dataEmissao &&
          other.bomPara == this.bomPara &&
          other.dataCompensacao == this.dataCompensacao &&
          other.valor == this.valor &&
          other.custodiaData == this.custodiaData &&
          other.custodiaTarifa == this.custodiaTarifa &&
          other.custodiaComissao == this.custodiaComissao &&
          other.descontoData == this.descontoData &&
          other.descontoTarifa == this.descontoTarifa &&
          other.descontoComissao == this.descontoComissao &&
          other.valorRecebido == this.valorRecebido);
}

class FinChequeRecebidosCompanion extends UpdateCompanion<FinChequeRecebido> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<String?> cpf;
  final Value<String?> cnpj;
  final Value<String?> nome;
  final Value<String?> codigoBanco;
  final Value<String?> codigoAgencia;
  final Value<String?> conta;
  final Value<int?> numero;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> bomPara;
  final Value<DateTime?> dataCompensacao;
  final Value<double?> valor;
  final Value<DateTime?> custodiaData;
  final Value<double?> custodiaTarifa;
  final Value<double?> custodiaComissao;
  final Value<DateTime?> descontoData;
  final Value<double?> descontoTarifa;
  final Value<double?> descontoComissao;
  final Value<double?> valorRecebido;
  const FinChequeRecebidosCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.cpf = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoBanco = const Value.absent(),
    this.codigoAgencia = const Value.absent(),
    this.conta = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.bomPara = const Value.absent(),
    this.dataCompensacao = const Value.absent(),
    this.valor = const Value.absent(),
    this.custodiaData = const Value.absent(),
    this.custodiaTarifa = const Value.absent(),
    this.custodiaComissao = const Value.absent(),
    this.descontoData = const Value.absent(),
    this.descontoTarifa = const Value.absent(),
    this.descontoComissao = const Value.absent(),
    this.valorRecebido = const Value.absent(),
  });
  FinChequeRecebidosCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.cpf = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoBanco = const Value.absent(),
    this.codigoAgencia = const Value.absent(),
    this.conta = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.bomPara = const Value.absent(),
    this.dataCompensacao = const Value.absent(),
    this.valor = const Value.absent(),
    this.custodiaData = const Value.absent(),
    this.custodiaTarifa = const Value.absent(),
    this.custodiaComissao = const Value.absent(),
    this.descontoData = const Value.absent(),
    this.descontoTarifa = const Value.absent(),
    this.descontoComissao = const Value.absent(),
    this.valorRecebido = const Value.absent(),
  });
  static Insertable<FinChequeRecebido> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<String>? cpf,
    Expression<String>? cnpj,
    Expression<String>? nome,
    Expression<String>? codigoBanco,
    Expression<String>? codigoAgencia,
    Expression<String>? conta,
    Expression<int>? numero,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? bomPara,
    Expression<DateTime>? dataCompensacao,
    Expression<double>? valor,
    Expression<DateTime>? custodiaData,
    Expression<double>? custodiaTarifa,
    Expression<double>? custodiaComissao,
    Expression<DateTime>? descontoData,
    Expression<double>? descontoTarifa,
    Expression<double>? descontoComissao,
    Expression<double>? valorRecebido,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (cpf != null) 'cpf': cpf,
      if (cnpj != null) 'cnpj': cnpj,
      if (nome != null) 'nome': nome,
      if (codigoBanco != null) 'codigo_banco': codigoBanco,
      if (codigoAgencia != null) 'codigo_agencia': codigoAgencia,
      if (conta != null) 'conta': conta,
      if (numero != null) 'numero': numero,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (bomPara != null) 'bom_para': bomPara,
      if (dataCompensacao != null) 'data_compensacao': dataCompensacao,
      if (valor != null) 'valor': valor,
      if (custodiaData != null) 'custodia_data': custodiaData,
      if (custodiaTarifa != null) 'custodia_tarifa': custodiaTarifa,
      if (custodiaComissao != null) 'custodia_comissao': custodiaComissao,
      if (descontoData != null) 'desconto_data': descontoData,
      if (descontoTarifa != null) 'desconto_tarifa': descontoTarifa,
      if (descontoComissao != null) 'desconto_comissao': descontoComissao,
      if (valorRecebido != null) 'valor_recebido': valorRecebido,
    });
  }

  FinChequeRecebidosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<String?>? cpf,
    Value<String?>? cnpj,
    Value<String?>? nome,
    Value<String?>? codigoBanco,
    Value<String?>? codigoAgencia,
    Value<String?>? conta,
    Value<int?>? numero,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? bomPara,
    Value<DateTime?>? dataCompensacao,
    Value<double?>? valor,
    Value<DateTime?>? custodiaData,
    Value<double?>? custodiaTarifa,
    Value<double?>? custodiaComissao,
    Value<DateTime?>? descontoData,
    Value<double?>? descontoTarifa,
    Value<double?>? descontoComissao,
    Value<double?>? valorRecebido,
  }) {
    return FinChequeRecebidosCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      cpf: cpf ?? this.cpf,
      cnpj: cnpj ?? this.cnpj,
      nome: nome ?? this.nome,
      codigoBanco: codigoBanco ?? this.codigoBanco,
      codigoAgencia: codigoAgencia ?? this.codigoAgencia,
      conta: conta ?? this.conta,
      numero: numero ?? this.numero,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      bomPara: bomPara ?? this.bomPara,
      dataCompensacao: dataCompensacao ?? this.dataCompensacao,
      valor: valor ?? this.valor,
      custodiaData: custodiaData ?? this.custodiaData,
      custodiaTarifa: custodiaTarifa ?? this.custodiaTarifa,
      custodiaComissao: custodiaComissao ?? this.custodiaComissao,
      descontoData: descontoData ?? this.descontoData,
      descontoTarifa: descontoTarifa ?? this.descontoTarifa,
      descontoComissao: descontoComissao ?? this.descontoComissao,
      valorRecebido: valorRecebido ?? this.valorRecebido,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (codigoBanco.present) {
      map['codigo_banco'] = Variable<String>(codigoBanco.value);
    }
    if (codigoAgencia.present) {
      map['codigo_agencia'] = Variable<String>(codigoAgencia.value);
    }
    if (conta.present) {
      map['conta'] = Variable<String>(conta.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (bomPara.present) {
      map['bom_para'] = Variable<DateTime>(bomPara.value);
    }
    if (dataCompensacao.present) {
      map['data_compensacao'] = Variable<DateTime>(dataCompensacao.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (custodiaData.present) {
      map['custodia_data'] = Variable<DateTime>(custodiaData.value);
    }
    if (custodiaTarifa.present) {
      map['custodia_tarifa'] = Variable<double>(custodiaTarifa.value);
    }
    if (custodiaComissao.present) {
      map['custodia_comissao'] = Variable<double>(custodiaComissao.value);
    }
    if (descontoData.present) {
      map['desconto_data'] = Variable<DateTime>(descontoData.value);
    }
    if (descontoTarifa.present) {
      map['desconto_tarifa'] = Variable<double>(descontoTarifa.value);
    }
    if (descontoComissao.present) {
      map['desconto_comissao'] = Variable<double>(descontoComissao.value);
    }
    if (valorRecebido.present) {
      map['valor_recebido'] = Variable<double>(valorRecebido.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinChequeRecebidosCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('cpf: $cpf, ')
          ..write('cnpj: $cnpj, ')
          ..write('nome: $nome, ')
          ..write('codigoBanco: $codigoBanco, ')
          ..write('codigoAgencia: $codigoAgencia, ')
          ..write('conta: $conta, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('bomPara: $bomPara, ')
          ..write('dataCompensacao: $dataCompensacao, ')
          ..write('valor: $valor, ')
          ..write('custodiaData: $custodiaData, ')
          ..write('custodiaTarifa: $custodiaTarifa, ')
          ..write('custodiaComissao: $custodiaComissao, ')
          ..write('descontoData: $descontoData, ')
          ..write('descontoTarifa: $descontoTarifa, ')
          ..write('descontoComissao: $descontoComissao, ')
          ..write('valorRecebido: $valorRecebido')
          ..write(')'))
        .toString();
  }
}

class $FinConfiguracaoBoletosTable extends FinConfiguracaoBoletos
    with TableInfo<$FinConfiguracaoBoletosTable, FinConfiguracaoBoleto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinConfiguracaoBoletosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _instrucao01Meta = const VerificationMeta(
    'instrucao01',
  );
  @override
  late final GeneratedColumn<String> instrucao01 = GeneratedColumn<String>(
    'instrucao01',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _instrucao02Meta = const VerificationMeta(
    'instrucao02',
  );
  @override
  late final GeneratedColumn<String> instrucao02 = GeneratedColumn<String>(
    'instrucao02',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _caminhoArquivoRemessaMeta =
      const VerificationMeta('caminhoArquivoRemessa');
  @override
  late final GeneratedColumn<String> caminhoArquivoRemessa =
      GeneratedColumn<String>(
        'caminho_arquivo_remessa',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 250,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _caminhoArquivoRetornoMeta =
      const VerificationMeta('caminhoArquivoRetorno');
  @override
  late final GeneratedColumn<String> caminhoArquivoRetorno =
      GeneratedColumn<String>(
        'caminho_arquivo_retorno',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 250,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _caminhoArquivoLogotipoMeta =
      const VerificationMeta('caminhoArquivoLogotipo');
  @override
  late final GeneratedColumn<String> caminhoArquivoLogotipo =
      GeneratedColumn<String>(
        'caminho_arquivo_logotipo',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 250,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _caminhoArquivoPdfMeta = const VerificationMeta(
    'caminhoArquivoPdf',
  );
  @override
  late final GeneratedColumn<String> caminhoArquivoPdf =
      GeneratedColumn<String>(
        'caminho_arquivo_pdf',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 250,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _mensagemMeta = const VerificationMeta(
    'mensagem',
  );
  @override
  late final GeneratedColumn<String> mensagem = GeneratedColumn<String>(
    'mensagem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _localPagamentoMeta = const VerificationMeta(
    'localPagamento',
  );
  @override
  late final GeneratedColumn<String> localPagamento = GeneratedColumn<String>(
    'local_pagamento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _layoutRemessaMeta = const VerificationMeta(
    'layoutRemessa',
  );
  @override
  late final GeneratedColumn<String> layoutRemessa = GeneratedColumn<String>(
    'layout_remessa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _aceiteMeta = const VerificationMeta('aceite');
  @override
  late final GeneratedColumn<String> aceite = GeneratedColumn<String>(
    'aceite',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _especieMeta = const VerificationMeta(
    'especie',
  );
  @override
  late final GeneratedColumn<String> especie = GeneratedColumn<String>(
    'especie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _carteiraMeta = const VerificationMeta(
    'carteira',
  );
  @override
  late final GeneratedColumn<String> carteira = GeneratedColumn<String>(
    'carteira',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoConvenioMeta = const VerificationMeta(
    'codigoConvenio',
  );
  @override
  late final GeneratedColumn<String> codigoConvenio = GeneratedColumn<String>(
    'codigo_convenio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoCedenteMeta = const VerificationMeta(
    'codigoCedente',
  );
  @override
  late final GeneratedColumn<String> codigoCedente = GeneratedColumn<String>(
    'codigo_cedente',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaMultaMeta = const VerificationMeta(
    'taxaMulta',
  );
  @override
  late final GeneratedColumn<double> taxaMulta = GeneratedColumn<double>(
    'taxa_multa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaJuroMeta = const VerificationMeta(
    'taxaJuro',
  );
  @override
  late final GeneratedColumn<double> taxaJuro = GeneratedColumn<double>(
    'taxa_juro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _diasProtestoMeta = const VerificationMeta(
    'diasProtesto',
  );
  @override
  late final GeneratedColumn<int> diasProtesto = GeneratedColumn<int>(
    'dias_protesto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nossoNumeroAnteriorMeta =
      const VerificationMeta('nossoNumeroAnterior');
  @override
  late final GeneratedColumn<String> nossoNumeroAnterior =
      GeneratedColumn<String>(
        'nosso_numero_anterior',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 50,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    instrucao01,
    instrucao02,
    caminhoArquivoRemessa,
    caminhoArquivoRetorno,
    caminhoArquivoLogotipo,
    caminhoArquivoPdf,
    mensagem,
    localPagamento,
    layoutRemessa,
    aceite,
    especie,
    carteira,
    codigoConvenio,
    codigoCedente,
    taxaMulta,
    taxaJuro,
    diasProtesto,
    nossoNumeroAnterior,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_configuracao_boleto';
  @override
  VerificationContext validateIntegrity(
    Insertable<FinConfiguracaoBoleto> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('instrucao01')) {
      context.handle(
        _instrucao01Meta,
        instrucao01.isAcceptableOrUnknown(
          data['instrucao01']!,
          _instrucao01Meta,
        ),
      );
    }
    if (data.containsKey('instrucao02')) {
      context.handle(
        _instrucao02Meta,
        instrucao02.isAcceptableOrUnknown(
          data['instrucao02']!,
          _instrucao02Meta,
        ),
      );
    }
    if (data.containsKey('caminho_arquivo_remessa')) {
      context.handle(
        _caminhoArquivoRemessaMeta,
        caminhoArquivoRemessa.isAcceptableOrUnknown(
          data['caminho_arquivo_remessa']!,
          _caminhoArquivoRemessaMeta,
        ),
      );
    }
    if (data.containsKey('caminho_arquivo_retorno')) {
      context.handle(
        _caminhoArquivoRetornoMeta,
        caminhoArquivoRetorno.isAcceptableOrUnknown(
          data['caminho_arquivo_retorno']!,
          _caminhoArquivoRetornoMeta,
        ),
      );
    }
    if (data.containsKey('caminho_arquivo_logotipo')) {
      context.handle(
        _caminhoArquivoLogotipoMeta,
        caminhoArquivoLogotipo.isAcceptableOrUnknown(
          data['caminho_arquivo_logotipo']!,
          _caminhoArquivoLogotipoMeta,
        ),
      );
    }
    if (data.containsKey('caminho_arquivo_pdf')) {
      context.handle(
        _caminhoArquivoPdfMeta,
        caminhoArquivoPdf.isAcceptableOrUnknown(
          data['caminho_arquivo_pdf']!,
          _caminhoArquivoPdfMeta,
        ),
      );
    }
    if (data.containsKey('mensagem')) {
      context.handle(
        _mensagemMeta,
        mensagem.isAcceptableOrUnknown(data['mensagem']!, _mensagemMeta),
      );
    }
    if (data.containsKey('local_pagamento')) {
      context.handle(
        _localPagamentoMeta,
        localPagamento.isAcceptableOrUnknown(
          data['local_pagamento']!,
          _localPagamentoMeta,
        ),
      );
    }
    if (data.containsKey('layout_remessa')) {
      context.handle(
        _layoutRemessaMeta,
        layoutRemessa.isAcceptableOrUnknown(
          data['layout_remessa']!,
          _layoutRemessaMeta,
        ),
      );
    }
    if (data.containsKey('aceite')) {
      context.handle(
        _aceiteMeta,
        aceite.isAcceptableOrUnknown(data['aceite']!, _aceiteMeta),
      );
    }
    if (data.containsKey('especie')) {
      context.handle(
        _especieMeta,
        especie.isAcceptableOrUnknown(data['especie']!, _especieMeta),
      );
    }
    if (data.containsKey('carteira')) {
      context.handle(
        _carteiraMeta,
        carteira.isAcceptableOrUnknown(data['carteira']!, _carteiraMeta),
      );
    }
    if (data.containsKey('codigo_convenio')) {
      context.handle(
        _codigoConvenioMeta,
        codigoConvenio.isAcceptableOrUnknown(
          data['codigo_convenio']!,
          _codigoConvenioMeta,
        ),
      );
    }
    if (data.containsKey('codigo_cedente')) {
      context.handle(
        _codigoCedenteMeta,
        codigoCedente.isAcceptableOrUnknown(
          data['codigo_cedente']!,
          _codigoCedenteMeta,
        ),
      );
    }
    if (data.containsKey('taxa_multa')) {
      context.handle(
        _taxaMultaMeta,
        taxaMulta.isAcceptableOrUnknown(data['taxa_multa']!, _taxaMultaMeta),
      );
    }
    if (data.containsKey('taxa_juro')) {
      context.handle(
        _taxaJuroMeta,
        taxaJuro.isAcceptableOrUnknown(data['taxa_juro']!, _taxaJuroMeta),
      );
    }
    if (data.containsKey('dias_protesto')) {
      context.handle(
        _diasProtestoMeta,
        diasProtesto.isAcceptableOrUnknown(
          data['dias_protesto']!,
          _diasProtestoMeta,
        ),
      );
    }
    if (data.containsKey('nosso_numero_anterior')) {
      context.handle(
        _nossoNumeroAnteriorMeta,
        nossoNumeroAnterior.isAcceptableOrUnknown(
          data['nosso_numero_anterior']!,
          _nossoNumeroAnteriorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinConfiguracaoBoleto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinConfiguracaoBoleto(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      instrucao01: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}instrucao01'],
      ),
      instrucao02: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}instrucao02'],
      ),
      caminhoArquivoRemessa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}caminho_arquivo_remessa'],
      ),
      caminhoArquivoRetorno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}caminho_arquivo_retorno'],
      ),
      caminhoArquivoLogotipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}caminho_arquivo_logotipo'],
      ),
      caminhoArquivoPdf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}caminho_arquivo_pdf'],
      ),
      mensagem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mensagem'],
      ),
      localPagamento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}local_pagamento'],
      ),
      layoutRemessa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}layout_remessa'],
      ),
      aceite: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}aceite'],
      ),
      especie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}especie'],
      ),
      carteira: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}carteira'],
      ),
      codigoConvenio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_convenio'],
      ),
      codigoCedente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_cedente'],
      ),
      taxaMulta: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_multa'],
      ),
      taxaJuro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_juro'],
      ),
      diasProtesto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}dias_protesto'],
      ),
      nossoNumeroAnterior: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nosso_numero_anterior'],
      ),
    );
  }

  @override
  $FinConfiguracaoBoletosTable createAlias(String alias) {
    return $FinConfiguracaoBoletosTable(attachedDatabase, alias);
  }
}

class FinConfiguracaoBoleto extends DataClass
    implements Insertable<FinConfiguracaoBoleto> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? instrucao01;
  final String? instrucao02;
  final String? caminhoArquivoRemessa;
  final String? caminhoArquivoRetorno;
  final String? caminhoArquivoLogotipo;
  final String? caminhoArquivoPdf;
  final String? mensagem;
  final String? localPagamento;
  final String? layoutRemessa;
  final String? aceite;
  final String? especie;
  final String? carteira;
  final String? codigoConvenio;
  final String? codigoCedente;
  final double? taxaMulta;
  final double? taxaJuro;
  final int? diasProtesto;
  final String? nossoNumeroAnterior;
  const FinConfiguracaoBoleto({
    this.id,
    this.idBancoContaCaixa,
    this.instrucao01,
    this.instrucao02,
    this.caminhoArquivoRemessa,
    this.caminhoArquivoRetorno,
    this.caminhoArquivoLogotipo,
    this.caminhoArquivoPdf,
    this.mensagem,
    this.localPagamento,
    this.layoutRemessa,
    this.aceite,
    this.especie,
    this.carteira,
    this.codigoConvenio,
    this.codigoCedente,
    this.taxaMulta,
    this.taxaJuro,
    this.diasProtesto,
    this.nossoNumeroAnterior,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || instrucao01 != null) {
      map['instrucao01'] = Variable<String>(instrucao01);
    }
    if (!nullToAbsent || instrucao02 != null) {
      map['instrucao02'] = Variable<String>(instrucao02);
    }
    if (!nullToAbsent || caminhoArquivoRemessa != null) {
      map['caminho_arquivo_remessa'] = Variable<String>(caminhoArquivoRemessa);
    }
    if (!nullToAbsent || caminhoArquivoRetorno != null) {
      map['caminho_arquivo_retorno'] = Variable<String>(caminhoArquivoRetorno);
    }
    if (!nullToAbsent || caminhoArquivoLogotipo != null) {
      map['caminho_arquivo_logotipo'] = Variable<String>(
        caminhoArquivoLogotipo,
      );
    }
    if (!nullToAbsent || caminhoArquivoPdf != null) {
      map['caminho_arquivo_pdf'] = Variable<String>(caminhoArquivoPdf);
    }
    if (!nullToAbsent || mensagem != null) {
      map['mensagem'] = Variable<String>(mensagem);
    }
    if (!nullToAbsent || localPagamento != null) {
      map['local_pagamento'] = Variable<String>(localPagamento);
    }
    if (!nullToAbsent || layoutRemessa != null) {
      map['layout_remessa'] = Variable<String>(layoutRemessa);
    }
    if (!nullToAbsent || aceite != null) {
      map['aceite'] = Variable<String>(aceite);
    }
    if (!nullToAbsent || especie != null) {
      map['especie'] = Variable<String>(especie);
    }
    if (!nullToAbsent || carteira != null) {
      map['carteira'] = Variable<String>(carteira);
    }
    if (!nullToAbsent || codigoConvenio != null) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio);
    }
    if (!nullToAbsent || codigoCedente != null) {
      map['codigo_cedente'] = Variable<String>(codigoCedente);
    }
    if (!nullToAbsent || taxaMulta != null) {
      map['taxa_multa'] = Variable<double>(taxaMulta);
    }
    if (!nullToAbsent || taxaJuro != null) {
      map['taxa_juro'] = Variable<double>(taxaJuro);
    }
    if (!nullToAbsent || diasProtesto != null) {
      map['dias_protesto'] = Variable<int>(diasProtesto);
    }
    if (!nullToAbsent || nossoNumeroAnterior != null) {
      map['nosso_numero_anterior'] = Variable<String>(nossoNumeroAnterior);
    }
    return map;
  }

  factory FinConfiguracaoBoleto.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinConfiguracaoBoleto(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      instrucao01: serializer.fromJson<String?>(json['instrucao01']),
      instrucao02: serializer.fromJson<String?>(json['instrucao02']),
      caminhoArquivoRemessa: serializer.fromJson<String?>(
        json['caminhoArquivoRemessa'],
      ),
      caminhoArquivoRetorno: serializer.fromJson<String?>(
        json['caminhoArquivoRetorno'],
      ),
      caminhoArquivoLogotipo: serializer.fromJson<String?>(
        json['caminhoArquivoLogotipo'],
      ),
      caminhoArquivoPdf: serializer.fromJson<String?>(
        json['caminhoArquivoPdf'],
      ),
      mensagem: serializer.fromJson<String?>(json['mensagem']),
      localPagamento: serializer.fromJson<String?>(json['localPagamento']),
      layoutRemessa: serializer.fromJson<String?>(json['layoutRemessa']),
      aceite: serializer.fromJson<String?>(json['aceite']),
      especie: serializer.fromJson<String?>(json['especie']),
      carteira: serializer.fromJson<String?>(json['carteira']),
      codigoConvenio: serializer.fromJson<String?>(json['codigoConvenio']),
      codigoCedente: serializer.fromJson<String?>(json['codigoCedente']),
      taxaMulta: serializer.fromJson<double?>(json['taxaMulta']),
      taxaJuro: serializer.fromJson<double?>(json['taxaJuro']),
      diasProtesto: serializer.fromJson<int?>(json['diasProtesto']),
      nossoNumeroAnterior: serializer.fromJson<String?>(
        json['nossoNumeroAnterior'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'instrucao01': serializer.toJson<String?>(instrucao01),
      'instrucao02': serializer.toJson<String?>(instrucao02),
      'caminhoArquivoRemessa': serializer.toJson<String?>(
        caminhoArquivoRemessa,
      ),
      'caminhoArquivoRetorno': serializer.toJson<String?>(
        caminhoArquivoRetorno,
      ),
      'caminhoArquivoLogotipo': serializer.toJson<String?>(
        caminhoArquivoLogotipo,
      ),
      'caminhoArquivoPdf': serializer.toJson<String?>(caminhoArquivoPdf),
      'mensagem': serializer.toJson<String?>(mensagem),
      'localPagamento': serializer.toJson<String?>(localPagamento),
      'layoutRemessa': serializer.toJson<String?>(layoutRemessa),
      'aceite': serializer.toJson<String?>(aceite),
      'especie': serializer.toJson<String?>(especie),
      'carteira': serializer.toJson<String?>(carteira),
      'codigoConvenio': serializer.toJson<String?>(codigoConvenio),
      'codigoCedente': serializer.toJson<String?>(codigoCedente),
      'taxaMulta': serializer.toJson<double?>(taxaMulta),
      'taxaJuro': serializer.toJson<double?>(taxaJuro),
      'diasProtesto': serializer.toJson<int?>(diasProtesto),
      'nossoNumeroAnterior': serializer.toJson<String?>(nossoNumeroAnterior),
    };
  }

  FinConfiguracaoBoleto copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> instrucao01 = const Value.absent(),
    Value<String?> instrucao02 = const Value.absent(),
    Value<String?> caminhoArquivoRemessa = const Value.absent(),
    Value<String?> caminhoArquivoRetorno = const Value.absent(),
    Value<String?> caminhoArquivoLogotipo = const Value.absent(),
    Value<String?> caminhoArquivoPdf = const Value.absent(),
    Value<String?> mensagem = const Value.absent(),
    Value<String?> localPagamento = const Value.absent(),
    Value<String?> layoutRemessa = const Value.absent(),
    Value<String?> aceite = const Value.absent(),
    Value<String?> especie = const Value.absent(),
    Value<String?> carteira = const Value.absent(),
    Value<String?> codigoConvenio = const Value.absent(),
    Value<String?> codigoCedente = const Value.absent(),
    Value<double?> taxaMulta = const Value.absent(),
    Value<double?> taxaJuro = const Value.absent(),
    Value<int?> diasProtesto = const Value.absent(),
    Value<String?> nossoNumeroAnterior = const Value.absent(),
  }) => FinConfiguracaoBoleto(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    instrucao01: instrucao01.present ? instrucao01.value : this.instrucao01,
    instrucao02: instrucao02.present ? instrucao02.value : this.instrucao02,
    caminhoArquivoRemessa:
        caminhoArquivoRemessa.present
            ? caminhoArquivoRemessa.value
            : this.caminhoArquivoRemessa,
    caminhoArquivoRetorno:
        caminhoArquivoRetorno.present
            ? caminhoArquivoRetorno.value
            : this.caminhoArquivoRetorno,
    caminhoArquivoLogotipo:
        caminhoArquivoLogotipo.present
            ? caminhoArquivoLogotipo.value
            : this.caminhoArquivoLogotipo,
    caminhoArquivoPdf:
        caminhoArquivoPdf.present
            ? caminhoArquivoPdf.value
            : this.caminhoArquivoPdf,
    mensagem: mensagem.present ? mensagem.value : this.mensagem,
    localPagamento:
        localPagamento.present ? localPagamento.value : this.localPagamento,
    layoutRemessa:
        layoutRemessa.present ? layoutRemessa.value : this.layoutRemessa,
    aceite: aceite.present ? aceite.value : this.aceite,
    especie: especie.present ? especie.value : this.especie,
    carteira: carteira.present ? carteira.value : this.carteira,
    codigoConvenio:
        codigoConvenio.present ? codigoConvenio.value : this.codigoConvenio,
    codigoCedente:
        codigoCedente.present ? codigoCedente.value : this.codigoCedente,
    taxaMulta: taxaMulta.present ? taxaMulta.value : this.taxaMulta,
    taxaJuro: taxaJuro.present ? taxaJuro.value : this.taxaJuro,
    diasProtesto: diasProtesto.present ? diasProtesto.value : this.diasProtesto,
    nossoNumeroAnterior:
        nossoNumeroAnterior.present
            ? nossoNumeroAnterior.value
            : this.nossoNumeroAnterior,
  );
  FinConfiguracaoBoleto copyWithCompanion(
    FinConfiguracaoBoletosCompanion data,
  ) {
    return FinConfiguracaoBoleto(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      instrucao01:
          data.instrucao01.present ? data.instrucao01.value : this.instrucao01,
      instrucao02:
          data.instrucao02.present ? data.instrucao02.value : this.instrucao02,
      caminhoArquivoRemessa:
          data.caminhoArquivoRemessa.present
              ? data.caminhoArquivoRemessa.value
              : this.caminhoArquivoRemessa,
      caminhoArquivoRetorno:
          data.caminhoArquivoRetorno.present
              ? data.caminhoArquivoRetorno.value
              : this.caminhoArquivoRetorno,
      caminhoArquivoLogotipo:
          data.caminhoArquivoLogotipo.present
              ? data.caminhoArquivoLogotipo.value
              : this.caminhoArquivoLogotipo,
      caminhoArquivoPdf:
          data.caminhoArquivoPdf.present
              ? data.caminhoArquivoPdf.value
              : this.caminhoArquivoPdf,
      mensagem: data.mensagem.present ? data.mensagem.value : this.mensagem,
      localPagamento:
          data.localPagamento.present
              ? data.localPagamento.value
              : this.localPagamento,
      layoutRemessa:
          data.layoutRemessa.present
              ? data.layoutRemessa.value
              : this.layoutRemessa,
      aceite: data.aceite.present ? data.aceite.value : this.aceite,
      especie: data.especie.present ? data.especie.value : this.especie,
      carteira: data.carteira.present ? data.carteira.value : this.carteira,
      codigoConvenio:
          data.codigoConvenio.present
              ? data.codigoConvenio.value
              : this.codigoConvenio,
      codigoCedente:
          data.codigoCedente.present
              ? data.codigoCedente.value
              : this.codigoCedente,
      taxaMulta: data.taxaMulta.present ? data.taxaMulta.value : this.taxaMulta,
      taxaJuro: data.taxaJuro.present ? data.taxaJuro.value : this.taxaJuro,
      diasProtesto:
          data.diasProtesto.present
              ? data.diasProtesto.value
              : this.diasProtesto,
      nossoNumeroAnterior:
          data.nossoNumeroAnterior.present
              ? data.nossoNumeroAnterior.value
              : this.nossoNumeroAnterior,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinConfiguracaoBoleto(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('instrucao01: $instrucao01, ')
          ..write('instrucao02: $instrucao02, ')
          ..write('caminhoArquivoRemessa: $caminhoArquivoRemessa, ')
          ..write('caminhoArquivoRetorno: $caminhoArquivoRetorno, ')
          ..write('caminhoArquivoLogotipo: $caminhoArquivoLogotipo, ')
          ..write('caminhoArquivoPdf: $caminhoArquivoPdf, ')
          ..write('mensagem: $mensagem, ')
          ..write('localPagamento: $localPagamento, ')
          ..write('layoutRemessa: $layoutRemessa, ')
          ..write('aceite: $aceite, ')
          ..write('especie: $especie, ')
          ..write('carteira: $carteira, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('codigoCedente: $codigoCedente, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('diasProtesto: $diasProtesto, ')
          ..write('nossoNumeroAnterior: $nossoNumeroAnterior')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    instrucao01,
    instrucao02,
    caminhoArquivoRemessa,
    caminhoArquivoRetorno,
    caminhoArquivoLogotipo,
    caminhoArquivoPdf,
    mensagem,
    localPagamento,
    layoutRemessa,
    aceite,
    especie,
    carteira,
    codigoConvenio,
    codigoCedente,
    taxaMulta,
    taxaJuro,
    diasProtesto,
    nossoNumeroAnterior,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinConfiguracaoBoleto &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.instrucao01 == this.instrucao01 &&
          other.instrucao02 == this.instrucao02 &&
          other.caminhoArquivoRemessa == this.caminhoArquivoRemessa &&
          other.caminhoArquivoRetorno == this.caminhoArquivoRetorno &&
          other.caminhoArquivoLogotipo == this.caminhoArquivoLogotipo &&
          other.caminhoArquivoPdf == this.caminhoArquivoPdf &&
          other.mensagem == this.mensagem &&
          other.localPagamento == this.localPagamento &&
          other.layoutRemessa == this.layoutRemessa &&
          other.aceite == this.aceite &&
          other.especie == this.especie &&
          other.carteira == this.carteira &&
          other.codigoConvenio == this.codigoConvenio &&
          other.codigoCedente == this.codigoCedente &&
          other.taxaMulta == this.taxaMulta &&
          other.taxaJuro == this.taxaJuro &&
          other.diasProtesto == this.diasProtesto &&
          other.nossoNumeroAnterior == this.nossoNumeroAnterior);
}

class FinConfiguracaoBoletosCompanion
    extends UpdateCompanion<FinConfiguracaoBoleto> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> instrucao01;
  final Value<String?> instrucao02;
  final Value<String?> caminhoArquivoRemessa;
  final Value<String?> caminhoArquivoRetorno;
  final Value<String?> caminhoArquivoLogotipo;
  final Value<String?> caminhoArquivoPdf;
  final Value<String?> mensagem;
  final Value<String?> localPagamento;
  final Value<String?> layoutRemessa;
  final Value<String?> aceite;
  final Value<String?> especie;
  final Value<String?> carteira;
  final Value<String?> codigoConvenio;
  final Value<String?> codigoCedente;
  final Value<double?> taxaMulta;
  final Value<double?> taxaJuro;
  final Value<int?> diasProtesto;
  final Value<String?> nossoNumeroAnterior;
  const FinConfiguracaoBoletosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.instrucao01 = const Value.absent(),
    this.instrucao02 = const Value.absent(),
    this.caminhoArquivoRemessa = const Value.absent(),
    this.caminhoArquivoRetorno = const Value.absent(),
    this.caminhoArquivoLogotipo = const Value.absent(),
    this.caminhoArquivoPdf = const Value.absent(),
    this.mensagem = const Value.absent(),
    this.localPagamento = const Value.absent(),
    this.layoutRemessa = const Value.absent(),
    this.aceite = const Value.absent(),
    this.especie = const Value.absent(),
    this.carteira = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.codigoCedente = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.diasProtesto = const Value.absent(),
    this.nossoNumeroAnterior = const Value.absent(),
  });
  FinConfiguracaoBoletosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.instrucao01 = const Value.absent(),
    this.instrucao02 = const Value.absent(),
    this.caminhoArquivoRemessa = const Value.absent(),
    this.caminhoArquivoRetorno = const Value.absent(),
    this.caminhoArquivoLogotipo = const Value.absent(),
    this.caminhoArquivoPdf = const Value.absent(),
    this.mensagem = const Value.absent(),
    this.localPagamento = const Value.absent(),
    this.layoutRemessa = const Value.absent(),
    this.aceite = const Value.absent(),
    this.especie = const Value.absent(),
    this.carteira = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.codigoCedente = const Value.absent(),
    this.taxaMulta = const Value.absent(),
    this.taxaJuro = const Value.absent(),
    this.diasProtesto = const Value.absent(),
    this.nossoNumeroAnterior = const Value.absent(),
  });
  static Insertable<FinConfiguracaoBoleto> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? instrucao01,
    Expression<String>? instrucao02,
    Expression<String>? caminhoArquivoRemessa,
    Expression<String>? caminhoArquivoRetorno,
    Expression<String>? caminhoArquivoLogotipo,
    Expression<String>? caminhoArquivoPdf,
    Expression<String>? mensagem,
    Expression<String>? localPagamento,
    Expression<String>? layoutRemessa,
    Expression<String>? aceite,
    Expression<String>? especie,
    Expression<String>? carteira,
    Expression<String>? codigoConvenio,
    Expression<String>? codigoCedente,
    Expression<double>? taxaMulta,
    Expression<double>? taxaJuro,
    Expression<int>? diasProtesto,
    Expression<String>? nossoNumeroAnterior,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (instrucao01 != null) 'instrucao01': instrucao01,
      if (instrucao02 != null) 'instrucao02': instrucao02,
      if (caminhoArquivoRemessa != null)
        'caminho_arquivo_remessa': caminhoArquivoRemessa,
      if (caminhoArquivoRetorno != null)
        'caminho_arquivo_retorno': caminhoArquivoRetorno,
      if (caminhoArquivoLogotipo != null)
        'caminho_arquivo_logotipo': caminhoArquivoLogotipo,
      if (caminhoArquivoPdf != null) 'caminho_arquivo_pdf': caminhoArquivoPdf,
      if (mensagem != null) 'mensagem': mensagem,
      if (localPagamento != null) 'local_pagamento': localPagamento,
      if (layoutRemessa != null) 'layout_remessa': layoutRemessa,
      if (aceite != null) 'aceite': aceite,
      if (especie != null) 'especie': especie,
      if (carteira != null) 'carteira': carteira,
      if (codigoConvenio != null) 'codigo_convenio': codigoConvenio,
      if (codigoCedente != null) 'codigo_cedente': codigoCedente,
      if (taxaMulta != null) 'taxa_multa': taxaMulta,
      if (taxaJuro != null) 'taxa_juro': taxaJuro,
      if (diasProtesto != null) 'dias_protesto': diasProtesto,
      if (nossoNumeroAnterior != null)
        'nosso_numero_anterior': nossoNumeroAnterior,
    });
  }

  FinConfiguracaoBoletosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? instrucao01,
    Value<String?>? instrucao02,
    Value<String?>? caminhoArquivoRemessa,
    Value<String?>? caminhoArquivoRetorno,
    Value<String?>? caminhoArquivoLogotipo,
    Value<String?>? caminhoArquivoPdf,
    Value<String?>? mensagem,
    Value<String?>? localPagamento,
    Value<String?>? layoutRemessa,
    Value<String?>? aceite,
    Value<String?>? especie,
    Value<String?>? carteira,
    Value<String?>? codigoConvenio,
    Value<String?>? codigoCedente,
    Value<double?>? taxaMulta,
    Value<double?>? taxaJuro,
    Value<int?>? diasProtesto,
    Value<String?>? nossoNumeroAnterior,
  }) {
    return FinConfiguracaoBoletosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      instrucao01: instrucao01 ?? this.instrucao01,
      instrucao02: instrucao02 ?? this.instrucao02,
      caminhoArquivoRemessa:
          caminhoArquivoRemessa ?? this.caminhoArquivoRemessa,
      caminhoArquivoRetorno:
          caminhoArquivoRetorno ?? this.caminhoArquivoRetorno,
      caminhoArquivoLogotipo:
          caminhoArquivoLogotipo ?? this.caminhoArquivoLogotipo,
      caminhoArquivoPdf: caminhoArquivoPdf ?? this.caminhoArquivoPdf,
      mensagem: mensagem ?? this.mensagem,
      localPagamento: localPagamento ?? this.localPagamento,
      layoutRemessa: layoutRemessa ?? this.layoutRemessa,
      aceite: aceite ?? this.aceite,
      especie: especie ?? this.especie,
      carteira: carteira ?? this.carteira,
      codigoConvenio: codigoConvenio ?? this.codigoConvenio,
      codigoCedente: codigoCedente ?? this.codigoCedente,
      taxaMulta: taxaMulta ?? this.taxaMulta,
      taxaJuro: taxaJuro ?? this.taxaJuro,
      diasProtesto: diasProtesto ?? this.diasProtesto,
      nossoNumeroAnterior: nossoNumeroAnterior ?? this.nossoNumeroAnterior,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (instrucao01.present) {
      map['instrucao01'] = Variable<String>(instrucao01.value);
    }
    if (instrucao02.present) {
      map['instrucao02'] = Variable<String>(instrucao02.value);
    }
    if (caminhoArquivoRemessa.present) {
      map['caminho_arquivo_remessa'] = Variable<String>(
        caminhoArquivoRemessa.value,
      );
    }
    if (caminhoArquivoRetorno.present) {
      map['caminho_arquivo_retorno'] = Variable<String>(
        caminhoArquivoRetorno.value,
      );
    }
    if (caminhoArquivoLogotipo.present) {
      map['caminho_arquivo_logotipo'] = Variable<String>(
        caminhoArquivoLogotipo.value,
      );
    }
    if (caminhoArquivoPdf.present) {
      map['caminho_arquivo_pdf'] = Variable<String>(caminhoArquivoPdf.value);
    }
    if (mensagem.present) {
      map['mensagem'] = Variable<String>(mensagem.value);
    }
    if (localPagamento.present) {
      map['local_pagamento'] = Variable<String>(localPagamento.value);
    }
    if (layoutRemessa.present) {
      map['layout_remessa'] = Variable<String>(layoutRemessa.value);
    }
    if (aceite.present) {
      map['aceite'] = Variable<String>(aceite.value);
    }
    if (especie.present) {
      map['especie'] = Variable<String>(especie.value);
    }
    if (carteira.present) {
      map['carteira'] = Variable<String>(carteira.value);
    }
    if (codigoConvenio.present) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio.value);
    }
    if (codigoCedente.present) {
      map['codigo_cedente'] = Variable<String>(codigoCedente.value);
    }
    if (taxaMulta.present) {
      map['taxa_multa'] = Variable<double>(taxaMulta.value);
    }
    if (taxaJuro.present) {
      map['taxa_juro'] = Variable<double>(taxaJuro.value);
    }
    if (diasProtesto.present) {
      map['dias_protesto'] = Variable<int>(diasProtesto.value);
    }
    if (nossoNumeroAnterior.present) {
      map['nosso_numero_anterior'] = Variable<String>(
        nossoNumeroAnterior.value,
      );
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinConfiguracaoBoletosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('instrucao01: $instrucao01, ')
          ..write('instrucao02: $instrucao02, ')
          ..write('caminhoArquivoRemessa: $caminhoArquivoRemessa, ')
          ..write('caminhoArquivoRetorno: $caminhoArquivoRetorno, ')
          ..write('caminhoArquivoLogotipo: $caminhoArquivoLogotipo, ')
          ..write('caminhoArquivoPdf: $caminhoArquivoPdf, ')
          ..write('mensagem: $mensagem, ')
          ..write('localPagamento: $localPagamento, ')
          ..write('layoutRemessa: $layoutRemessa, ')
          ..write('aceite: $aceite, ')
          ..write('especie: $especie, ')
          ..write('carteira: $carteira, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('codigoCedente: $codigoCedente, ')
          ..write('taxaMulta: $taxaMulta, ')
          ..write('taxaJuro: $taxaJuro, ')
          ..write('diasProtesto: $diasProtesto, ')
          ..write('nossoNumeroAnterior: $nossoNumeroAnterior')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaClientesTable extends ViewPessoaClientes
    with TableInfo<$ViewPessoaClientesTable, ViewPessoaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
    'desde',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaDescontoMeta = const VerificationMeta(
    'taxaDesconto',
  );
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
    'taxa_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _limiteCreditoMeta = const VerificationMeta(
    'limiteCredito',
  );
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
    'limite_credito',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    taxaDesconto,
    limiteCredito,
    dataCadastro,
    observacao,
    idPessoa,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('desde')) {
      context.handle(
        _desdeMeta,
        desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta),
      );
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
        _taxaDescontoMeta,
        taxaDesconto.isAcceptableOrUnknown(
          data['taxa_desconto']!,
          _taxaDescontoMeta,
        ),
      );
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
        _limiteCreditoMeta,
        limiteCredito.isAcceptableOrUnknown(
          data['limite_credito']!,
          _limiteCreditoMeta,
        ),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      desde: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desde'],
      ),
      taxaDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_desconto'],
      ),
      limiteCredito: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}limite_credito'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
    );
  }

  @override
  $ViewPessoaClientesTable createAlias(String alias) {
    return $ViewPessoaClientesTable(attachedDatabase, alias);
  }
}

class ViewPessoaCliente extends DataClass
    implements Insertable<ViewPessoaCliente> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaCliente({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.desde,
    this.taxaDesconto,
    this.limiteCredito,
    this.dataCadastro,
    this.observacao,
    this.idPessoa,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaCliente(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<DateTime?> desde = const Value.absent(),
    Value<double?> taxaDesconto = const Value.absent(),
    Value<double?> limiteCredito = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
  }) => ViewPessoaCliente(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    desde: desde.present ? desde.value : this.desde,
    taxaDesconto: taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
    limiteCredito:
        limiteCredito.present ? limiteCredito.value : this.limiteCredito,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    observacao: observacao.present ? observacao.value : this.observacao,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
  );
  ViewPessoaCliente copyWithCompanion(ViewPessoaClientesCompanion data) {
    return ViewPessoaCliente(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      taxaDesconto:
          data.taxaDesconto.present
              ? data.taxaDesconto.value
              : this.taxaDesconto,
      limiteCredito:
          data.limiteCredito.present
              ? data.limiteCredito.value
              : this.limiteCredito,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaCliente(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    taxaDesconto,
    limiteCredito,
    dataCadastro,
    observacao,
    idPessoa,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaCliente &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaClientesCompanion extends UpdateCompanion<ViewPessoaCliente> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaClientesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaCliente> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaClientesCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<DateTime?>? desde,
    Value<double?>? taxaDesconto,
    Value<double?>? limiteCredito,
    Value<DateTime?>? dataCadastro,
    Value<String?>? observacao,
    Value<int?>? idPessoa,
  }) {
    return ViewPessoaClientesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaClientesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaFornecedorsTable extends ViewPessoaFornecedors
    with TableInfo<$ViewPessoaFornecedorsTable, ViewPessoaFornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaFornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
    'desde',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    dataCadastro,
    observacao,
    idPessoa,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_fornecedor';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaFornecedor> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('desde')) {
      context.handle(
        _desdeMeta,
        desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaFornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaFornecedor(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      desde: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desde'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
    );
  }

  @override
  $ViewPessoaFornecedorsTable createAlias(String alias) {
    return $ViewPessoaFornecedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaFornecedor extends DataClass
    implements Insertable<ViewPessoaFornecedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaFornecedor({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.desde,
    this.dataCadastro,
    this.observacao,
    this.idPessoa,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaFornecedor.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaFornecedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaFornecedor copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<DateTime?> desde = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
  }) => ViewPessoaFornecedor(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    desde: desde.present ? desde.value : this.desde,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    observacao: observacao.present ? observacao.value : this.observacao,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
  );
  ViewPessoaFornecedor copyWithCompanion(ViewPessoaFornecedorsCompanion data) {
    return ViewPessoaFornecedor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    dataCadastro,
    observacao,
    idPessoa,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaFornecedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaFornecedorsCompanion
    extends UpdateCompanion<ViewPessoaFornecedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaFornecedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaFornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaFornecedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaFornecedorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<DateTime?>? desde,
    Value<DateTime?>? dataCadastro,
    Value<String?>? observacao,
    Value<int?>? idPessoa,
  }) {
    return ViewPessoaFornecedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewFinMovimentoCaixaBancosTable extends ViewFinMovimentoCaixaBancos
    with
        TableInfo<
          $ViewFinMovimentoCaixaBancosTable,
          ViewFinMovimentoCaixaBanco
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewFinMovimentoCaixaBancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeContaCaixaMeta = const VerificationMeta(
    'nomeContaCaixa',
  );
  @override
  late final GeneratedColumn<String> nomeContaCaixa = GeneratedColumn<String>(
    'nome_conta_caixa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 255,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomePessoaMeta = const VerificationMeta(
    'nomePessoa',
  );
  @override
  late final GeneratedColumn<String> nomePessoa = GeneratedColumn<String>(
    'nome_pessoa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 255,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataLancamentoMeta = const VerificationMeta(
    'dataLancamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>(
        'data_lancamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataPagoRecebidoMeta = const VerificationMeta(
    'dataPagoRecebido',
  );
  @override
  late final GeneratedColumn<DateTime> dataPagoRecebido =
      GeneratedColumn<DateTime>(
        'data_pago_recebido',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _mesAnoMeta = const VerificationMeta('mesAno');
  @override
  late final GeneratedColumn<String> mesAno = GeneratedColumn<String>(
    'mes_ano',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 7,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _historicoMeta = const VerificationMeta(
    'historico',
  );
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
    'historico',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoDocumentoOrigemMeta =
      const VerificationMeta('descricaoDocumentoOrigem');
  @override
  late final GeneratedColumn<String> descricaoDocumentoOrigem =
      GeneratedColumn<String>(
        'descricao_documento_origem',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 255,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _operacaoMeta = const VerificationMeta(
    'operacao',
  );
  @override
  late final GeneratedColumn<String> operacao = GeneratedColumn<String>(
    'operacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    nomePessoa,
    dataLancamento,
    dataPagoRecebido,
    mesAno,
    historico,
    valor,
    descricaoDocumentoOrigem,
    operacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_fin_movimento_caixa_banco';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewFinMovimentoCaixaBanco> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('nome_conta_caixa')) {
      context.handle(
        _nomeContaCaixaMeta,
        nomeContaCaixa.isAcceptableOrUnknown(
          data['nome_conta_caixa']!,
          _nomeContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('nome_pessoa')) {
      context.handle(
        _nomePessoaMeta,
        nomePessoa.isAcceptableOrUnknown(data['nome_pessoa']!, _nomePessoaMeta),
      );
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
        _dataLancamentoMeta,
        dataLancamento.isAcceptableOrUnknown(
          data['data_lancamento']!,
          _dataLancamentoMeta,
        ),
      );
    }
    if (data.containsKey('data_pago_recebido')) {
      context.handle(
        _dataPagoRecebidoMeta,
        dataPagoRecebido.isAcceptableOrUnknown(
          data['data_pago_recebido']!,
          _dataPagoRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('mes_ano')) {
      context.handle(
        _mesAnoMeta,
        mesAno.isAcceptableOrUnknown(data['mes_ano']!, _mesAnoMeta),
      );
    }
    if (data.containsKey('historico')) {
      context.handle(
        _historicoMeta,
        historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('descricao_documento_origem')) {
      context.handle(
        _descricaoDocumentoOrigemMeta,
        descricaoDocumentoOrigem.isAcceptableOrUnknown(
          data['descricao_documento_origem']!,
          _descricaoDocumentoOrigemMeta,
        ),
      );
    }
    if (data.containsKey('operacao')) {
      context.handle(
        _operacaoMeta,
        operacao.isAcceptableOrUnknown(data['operacao']!, _operacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewFinMovimentoCaixaBanco map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewFinMovimentoCaixaBanco(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      nomeContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_conta_caixa'],
      ),
      nomePessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_pessoa'],
      ),
      dataLancamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_lancamento'],
      ),
      dataPagoRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_pago_recebido'],
      ),
      mesAno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}mes_ano'],
      ),
      historico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}historico'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      descricaoDocumentoOrigem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao_documento_origem'],
      ),
      operacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}operacao'],
      ),
    );
  }

  @override
  $ViewFinMovimentoCaixaBancosTable createAlias(String alias) {
    return $ViewFinMovimentoCaixaBancosTable(attachedDatabase, alias);
  }
}

class ViewFinMovimentoCaixaBanco extends DataClass
    implements Insertable<ViewFinMovimentoCaixaBanco> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? nomeContaCaixa;
  final String? nomePessoa;
  final DateTime? dataLancamento;
  final DateTime? dataPagoRecebido;
  final String? mesAno;
  final String? historico;
  final double? valor;
  final String? descricaoDocumentoOrigem;
  final String? operacao;
  const ViewFinMovimentoCaixaBanco({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.nomePessoa,
    this.dataLancamento,
    this.dataPagoRecebido,
    this.mesAno,
    this.historico,
    this.valor,
    this.descricaoDocumentoOrigem,
    this.operacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || nomeContaCaixa != null) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa);
    }
    if (!nullToAbsent || nomePessoa != null) {
      map['nome_pessoa'] = Variable<String>(nomePessoa);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || dataPagoRecebido != null) {
      map['data_pago_recebido'] = Variable<DateTime>(dataPagoRecebido);
    }
    if (!nullToAbsent || mesAno != null) {
      map['mes_ano'] = Variable<String>(mesAno);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || descricaoDocumentoOrigem != null) {
      map['descricao_documento_origem'] = Variable<String>(
        descricaoDocumentoOrigem,
      );
    }
    if (!nullToAbsent || operacao != null) {
      map['operacao'] = Variable<String>(operacao);
    }
    return map;
  }

  factory ViewFinMovimentoCaixaBanco.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewFinMovimentoCaixaBanco(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      nomeContaCaixa: serializer.fromJson<String?>(json['nomeContaCaixa']),
      nomePessoa: serializer.fromJson<String?>(json['nomePessoa']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      dataPagoRecebido: serializer.fromJson<DateTime?>(
        json['dataPagoRecebido'],
      ),
      mesAno: serializer.fromJson<String?>(json['mesAno']),
      historico: serializer.fromJson<String?>(json['historico']),
      valor: serializer.fromJson<double?>(json['valor']),
      descricaoDocumentoOrigem: serializer.fromJson<String?>(
        json['descricaoDocumentoOrigem'],
      ),
      operacao: serializer.fromJson<String?>(json['operacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'nomeContaCaixa': serializer.toJson<String?>(nomeContaCaixa),
      'nomePessoa': serializer.toJson<String?>(nomePessoa),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'dataPagoRecebido': serializer.toJson<DateTime?>(dataPagoRecebido),
      'mesAno': serializer.toJson<String?>(mesAno),
      'historico': serializer.toJson<String?>(historico),
      'valor': serializer.toJson<double?>(valor),
      'descricaoDocumentoOrigem': serializer.toJson<String?>(
        descricaoDocumentoOrigem,
      ),
      'operacao': serializer.toJson<String?>(operacao),
    };
  }

  ViewFinMovimentoCaixaBanco copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> nomeContaCaixa = const Value.absent(),
    Value<String?> nomePessoa = const Value.absent(),
    Value<DateTime?> dataLancamento = const Value.absent(),
    Value<DateTime?> dataPagoRecebido = const Value.absent(),
    Value<String?> mesAno = const Value.absent(),
    Value<String?> historico = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<String?> descricaoDocumentoOrigem = const Value.absent(),
    Value<String?> operacao = const Value.absent(),
  }) => ViewFinMovimentoCaixaBanco(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    nomeContaCaixa:
        nomeContaCaixa.present ? nomeContaCaixa.value : this.nomeContaCaixa,
    nomePessoa: nomePessoa.present ? nomePessoa.value : this.nomePessoa,
    dataLancamento:
        dataLancamento.present ? dataLancamento.value : this.dataLancamento,
    dataPagoRecebido:
        dataPagoRecebido.present
            ? dataPagoRecebido.value
            : this.dataPagoRecebido,
    mesAno: mesAno.present ? mesAno.value : this.mesAno,
    historico: historico.present ? historico.value : this.historico,
    valor: valor.present ? valor.value : this.valor,
    descricaoDocumentoOrigem:
        descricaoDocumentoOrigem.present
            ? descricaoDocumentoOrigem.value
            : this.descricaoDocumentoOrigem,
    operacao: operacao.present ? operacao.value : this.operacao,
  );
  ViewFinMovimentoCaixaBanco copyWithCompanion(
    ViewFinMovimentoCaixaBancosCompanion data,
  ) {
    return ViewFinMovimentoCaixaBanco(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      nomeContaCaixa:
          data.nomeContaCaixa.present
              ? data.nomeContaCaixa.value
              : this.nomeContaCaixa,
      nomePessoa:
          data.nomePessoa.present ? data.nomePessoa.value : this.nomePessoa,
      dataLancamento:
          data.dataLancamento.present
              ? data.dataLancamento.value
              : this.dataLancamento,
      dataPagoRecebido:
          data.dataPagoRecebido.present
              ? data.dataPagoRecebido.value
              : this.dataPagoRecebido,
      mesAno: data.mesAno.present ? data.mesAno.value : this.mesAno,
      historico: data.historico.present ? data.historico.value : this.historico,
      valor: data.valor.present ? data.valor.value : this.valor,
      descricaoDocumentoOrigem:
          data.descricaoDocumentoOrigem.present
              ? data.descricaoDocumentoOrigem.value
              : this.descricaoDocumentoOrigem,
      operacao: data.operacao.present ? data.operacao.value : this.operacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinMovimentoCaixaBanco(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('nomePessoa: $nomePessoa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataPagoRecebido: $dataPagoRecebido, ')
          ..write('mesAno: $mesAno, ')
          ..write('historico: $historico, ')
          ..write('valor: $valor, ')
          ..write('descricaoDocumentoOrigem: $descricaoDocumentoOrigem, ')
          ..write('operacao: $operacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    nomePessoa,
    dataLancamento,
    dataPagoRecebido,
    mesAno,
    historico,
    valor,
    descricaoDocumentoOrigem,
    operacao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewFinMovimentoCaixaBanco &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.nomeContaCaixa == this.nomeContaCaixa &&
          other.nomePessoa == this.nomePessoa &&
          other.dataLancamento == this.dataLancamento &&
          other.dataPagoRecebido == this.dataPagoRecebido &&
          other.mesAno == this.mesAno &&
          other.historico == this.historico &&
          other.valor == this.valor &&
          other.descricaoDocumentoOrigem == this.descricaoDocumentoOrigem &&
          other.operacao == this.operacao);
}

class ViewFinMovimentoCaixaBancosCompanion
    extends UpdateCompanion<ViewFinMovimentoCaixaBanco> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> nomeContaCaixa;
  final Value<String?> nomePessoa;
  final Value<DateTime?> dataLancamento;
  final Value<DateTime?> dataPagoRecebido;
  final Value<String?> mesAno;
  final Value<String?> historico;
  final Value<double?> valor;
  final Value<String?> descricaoDocumentoOrigem;
  final Value<String?> operacao;
  const ViewFinMovimentoCaixaBancosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.nomePessoa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataPagoRecebido = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.historico = const Value.absent(),
    this.valor = const Value.absent(),
    this.descricaoDocumentoOrigem = const Value.absent(),
    this.operacao = const Value.absent(),
  });
  ViewFinMovimentoCaixaBancosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.nomePessoa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataPagoRecebido = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.historico = const Value.absent(),
    this.valor = const Value.absent(),
    this.descricaoDocumentoOrigem = const Value.absent(),
    this.operacao = const Value.absent(),
  });
  static Insertable<ViewFinMovimentoCaixaBanco> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? nomeContaCaixa,
    Expression<String>? nomePessoa,
    Expression<DateTime>? dataLancamento,
    Expression<DateTime>? dataPagoRecebido,
    Expression<String>? mesAno,
    Expression<String>? historico,
    Expression<double>? valor,
    Expression<String>? descricaoDocumentoOrigem,
    Expression<String>? operacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (nomeContaCaixa != null) 'nome_conta_caixa': nomeContaCaixa,
      if (nomePessoa != null) 'nome_pessoa': nomePessoa,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (dataPagoRecebido != null) 'data_pago_recebido': dataPagoRecebido,
      if (mesAno != null) 'mes_ano': mesAno,
      if (historico != null) 'historico': historico,
      if (valor != null) 'valor': valor,
      if (descricaoDocumentoOrigem != null)
        'descricao_documento_origem': descricaoDocumentoOrigem,
      if (operacao != null) 'operacao': operacao,
    });
  }

  ViewFinMovimentoCaixaBancosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? nomeContaCaixa,
    Value<String?>? nomePessoa,
    Value<DateTime?>? dataLancamento,
    Value<DateTime?>? dataPagoRecebido,
    Value<String?>? mesAno,
    Value<String?>? historico,
    Value<double?>? valor,
    Value<String?>? descricaoDocumentoOrigem,
    Value<String?>? operacao,
  }) {
    return ViewFinMovimentoCaixaBancosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa ?? this.nomeContaCaixa,
      nomePessoa: nomePessoa ?? this.nomePessoa,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      dataPagoRecebido: dataPagoRecebido ?? this.dataPagoRecebido,
      mesAno: mesAno ?? this.mesAno,
      historico: historico ?? this.historico,
      valor: valor ?? this.valor,
      descricaoDocumentoOrigem:
          descricaoDocumentoOrigem ?? this.descricaoDocumentoOrigem,
      operacao: operacao ?? this.operacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (nomeContaCaixa.present) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa.value);
    }
    if (nomePessoa.present) {
      map['nome_pessoa'] = Variable<String>(nomePessoa.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (dataPagoRecebido.present) {
      map['data_pago_recebido'] = Variable<DateTime>(dataPagoRecebido.value);
    }
    if (mesAno.present) {
      map['mes_ano'] = Variable<String>(mesAno.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (descricaoDocumentoOrigem.present) {
      map['descricao_documento_origem'] = Variable<String>(
        descricaoDocumentoOrigem.value,
      );
    }
    if (operacao.present) {
      map['operacao'] = Variable<String>(operacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinMovimentoCaixaBancosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('nomePessoa: $nomePessoa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataPagoRecebido: $dataPagoRecebido, ')
          ..write('mesAno: $mesAno, ')
          ..write('historico: $historico, ')
          ..write('valor: $valor, ')
          ..write('descricaoDocumentoOrigem: $descricaoDocumentoOrigem, ')
          ..write('operacao: $operacao')
          ..write(')'))
        .toString();
  }
}

class $ViewFinFluxoCaixasTable extends ViewFinFluxoCaixas
    with TableInfo<$ViewFinFluxoCaixasTable, ViewFinFluxoCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewFinFluxoCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeContaCaixaMeta = const VerificationMeta(
    'nomeContaCaixa',
  );
  @override
  late final GeneratedColumn<String> nomeContaCaixa = GeneratedColumn<String>(
    'nome_conta_caixa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 255,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomePessoaMeta = const VerificationMeta(
    'nomePessoa',
  );
  @override
  late final GeneratedColumn<String> nomePessoa = GeneratedColumn<String>(
    'nome_pessoa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 255,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataLancamentoMeta = const VerificationMeta(
    'dataLancamento',
  );
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>(
        'data_lancamento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataVencimentoMeta = const VerificationMeta(
    'dataVencimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>(
        'data_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoSituacaoMeta = const VerificationMeta(
    'codigoSituacao',
  );
  @override
  late final GeneratedColumn<String> codigoSituacao = GeneratedColumn<String>(
    'codigo_situacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoSituacaoMeta = const VerificationMeta(
    'descricaoSituacao',
  );
  @override
  late final GeneratedColumn<String> descricaoSituacao =
      GeneratedColumn<String>(
        'descricao_situacao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 255,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _operacaoMeta = const VerificationMeta(
    'operacao',
  );
  @override
  late final GeneratedColumn<String> operacao = GeneratedColumn<String>(
    'operacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    nomePessoa,
    dataLancamento,
    dataVencimento,
    valor,
    codigoSituacao,
    descricaoSituacao,
    operacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_fin_fluxo_caixa';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewFinFluxoCaixa> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('nome_conta_caixa')) {
      context.handle(
        _nomeContaCaixaMeta,
        nomeContaCaixa.isAcceptableOrUnknown(
          data['nome_conta_caixa']!,
          _nomeContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('nome_pessoa')) {
      context.handle(
        _nomePessoaMeta,
        nomePessoa.isAcceptableOrUnknown(data['nome_pessoa']!, _nomePessoaMeta),
      );
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
        _dataLancamentoMeta,
        dataLancamento.isAcceptableOrUnknown(
          data['data_lancamento']!,
          _dataLancamentoMeta,
        ),
      );
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
        _dataVencimentoMeta,
        dataVencimento.isAcceptableOrUnknown(
          data['data_vencimento']!,
          _dataVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    if (data.containsKey('codigo_situacao')) {
      context.handle(
        _codigoSituacaoMeta,
        codigoSituacao.isAcceptableOrUnknown(
          data['codigo_situacao']!,
          _codigoSituacaoMeta,
        ),
      );
    }
    if (data.containsKey('descricao_situacao')) {
      context.handle(
        _descricaoSituacaoMeta,
        descricaoSituacao.isAcceptableOrUnknown(
          data['descricao_situacao']!,
          _descricaoSituacaoMeta,
        ),
      );
    }
    if (data.containsKey('operacao')) {
      context.handle(
        _operacaoMeta,
        operacao.isAcceptableOrUnknown(data['operacao']!, _operacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewFinFluxoCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewFinFluxoCaixa(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      nomeContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_conta_caixa'],
      ),
      nomePessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_pessoa'],
      ),
      dataLancamento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_lancamento'],
      ),
      dataVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_vencimento'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
      codigoSituacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_situacao'],
      ),
      descricaoSituacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao_situacao'],
      ),
      operacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}operacao'],
      ),
    );
  }

  @override
  $ViewFinFluxoCaixasTable createAlias(String alias) {
    return $ViewFinFluxoCaixasTable(attachedDatabase, alias);
  }
}

class ViewFinFluxoCaixa extends DataClass
    implements Insertable<ViewFinFluxoCaixa> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? nomeContaCaixa;
  final String? nomePessoa;
  final DateTime? dataLancamento;
  final DateTime? dataVencimento;
  final double? valor;
  final String? codigoSituacao;
  final String? descricaoSituacao;
  final String? operacao;
  const ViewFinFluxoCaixa({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.nomePessoa,
    this.dataLancamento,
    this.dataVencimento,
    this.valor,
    this.codigoSituacao,
    this.descricaoSituacao,
    this.operacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || nomeContaCaixa != null) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa);
    }
    if (!nullToAbsent || nomePessoa != null) {
      map['nome_pessoa'] = Variable<String>(nomePessoa);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || codigoSituacao != null) {
      map['codigo_situacao'] = Variable<String>(codigoSituacao);
    }
    if (!nullToAbsent || descricaoSituacao != null) {
      map['descricao_situacao'] = Variable<String>(descricaoSituacao);
    }
    if (!nullToAbsent || operacao != null) {
      map['operacao'] = Variable<String>(operacao);
    }
    return map;
  }

  factory ViewFinFluxoCaixa.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewFinFluxoCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      nomeContaCaixa: serializer.fromJson<String?>(json['nomeContaCaixa']),
      nomePessoa: serializer.fromJson<String?>(json['nomePessoa']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      valor: serializer.fromJson<double?>(json['valor']),
      codigoSituacao: serializer.fromJson<String?>(json['codigoSituacao']),
      descricaoSituacao: serializer.fromJson<String?>(
        json['descricaoSituacao'],
      ),
      operacao: serializer.fromJson<String?>(json['operacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'nomeContaCaixa': serializer.toJson<String?>(nomeContaCaixa),
      'nomePessoa': serializer.toJson<String?>(nomePessoa),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'valor': serializer.toJson<double?>(valor),
      'codigoSituacao': serializer.toJson<String?>(codigoSituacao),
      'descricaoSituacao': serializer.toJson<String?>(descricaoSituacao),
      'operacao': serializer.toJson<String?>(operacao),
    };
  }

  ViewFinFluxoCaixa copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> nomeContaCaixa = const Value.absent(),
    Value<String?> nomePessoa = const Value.absent(),
    Value<DateTime?> dataLancamento = const Value.absent(),
    Value<DateTime?> dataVencimento = const Value.absent(),
    Value<double?> valor = const Value.absent(),
    Value<String?> codigoSituacao = const Value.absent(),
    Value<String?> descricaoSituacao = const Value.absent(),
    Value<String?> operacao = const Value.absent(),
  }) => ViewFinFluxoCaixa(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    nomeContaCaixa:
        nomeContaCaixa.present ? nomeContaCaixa.value : this.nomeContaCaixa,
    nomePessoa: nomePessoa.present ? nomePessoa.value : this.nomePessoa,
    dataLancamento:
        dataLancamento.present ? dataLancamento.value : this.dataLancamento,
    dataVencimento:
        dataVencimento.present ? dataVencimento.value : this.dataVencimento,
    valor: valor.present ? valor.value : this.valor,
    codigoSituacao:
        codigoSituacao.present ? codigoSituacao.value : this.codigoSituacao,
    descricaoSituacao:
        descricaoSituacao.present
            ? descricaoSituacao.value
            : this.descricaoSituacao,
    operacao: operacao.present ? operacao.value : this.operacao,
  );
  ViewFinFluxoCaixa copyWithCompanion(ViewFinFluxoCaixasCompanion data) {
    return ViewFinFluxoCaixa(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      nomeContaCaixa:
          data.nomeContaCaixa.present
              ? data.nomeContaCaixa.value
              : this.nomeContaCaixa,
      nomePessoa:
          data.nomePessoa.present ? data.nomePessoa.value : this.nomePessoa,
      dataLancamento:
          data.dataLancamento.present
              ? data.dataLancamento.value
              : this.dataLancamento,
      dataVencimento:
          data.dataVencimento.present
              ? data.dataVencimento.value
              : this.dataVencimento,
      valor: data.valor.present ? data.valor.value : this.valor,
      codigoSituacao:
          data.codigoSituacao.present
              ? data.codigoSituacao.value
              : this.codigoSituacao,
      descricaoSituacao:
          data.descricaoSituacao.present
              ? data.descricaoSituacao.value
              : this.descricaoSituacao,
      operacao: data.operacao.present ? data.operacao.value : this.operacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinFluxoCaixa(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('nomePessoa: $nomePessoa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valor: $valor, ')
          ..write('codigoSituacao: $codigoSituacao, ')
          ..write('descricaoSituacao: $descricaoSituacao, ')
          ..write('operacao: $operacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    nomePessoa,
    dataLancamento,
    dataVencimento,
    valor,
    codigoSituacao,
    descricaoSituacao,
    operacao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewFinFluxoCaixa &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.nomeContaCaixa == this.nomeContaCaixa &&
          other.nomePessoa == this.nomePessoa &&
          other.dataLancamento == this.dataLancamento &&
          other.dataVencimento == this.dataVencimento &&
          other.valor == this.valor &&
          other.codigoSituacao == this.codigoSituacao &&
          other.descricaoSituacao == this.descricaoSituacao &&
          other.operacao == this.operacao);
}

class ViewFinFluxoCaixasCompanion extends UpdateCompanion<ViewFinFluxoCaixa> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> nomeContaCaixa;
  final Value<String?> nomePessoa;
  final Value<DateTime?> dataLancamento;
  final Value<DateTime?> dataVencimento;
  final Value<double?> valor;
  final Value<String?> codigoSituacao;
  final Value<String?> descricaoSituacao;
  final Value<String?> operacao;
  const ViewFinFluxoCaixasCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.nomePessoa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valor = const Value.absent(),
    this.codigoSituacao = const Value.absent(),
    this.descricaoSituacao = const Value.absent(),
    this.operacao = const Value.absent(),
  });
  ViewFinFluxoCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.nomePessoa = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valor = const Value.absent(),
    this.codigoSituacao = const Value.absent(),
    this.descricaoSituacao = const Value.absent(),
    this.operacao = const Value.absent(),
  });
  static Insertable<ViewFinFluxoCaixa> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? nomeContaCaixa,
    Expression<String>? nomePessoa,
    Expression<DateTime>? dataLancamento,
    Expression<DateTime>? dataVencimento,
    Expression<double>? valor,
    Expression<String>? codigoSituacao,
    Expression<String>? descricaoSituacao,
    Expression<String>? operacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (nomeContaCaixa != null) 'nome_conta_caixa': nomeContaCaixa,
      if (nomePessoa != null) 'nome_pessoa': nomePessoa,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (valor != null) 'valor': valor,
      if (codigoSituacao != null) 'codigo_situacao': codigoSituacao,
      if (descricaoSituacao != null) 'descricao_situacao': descricaoSituacao,
      if (operacao != null) 'operacao': operacao,
    });
  }

  ViewFinFluxoCaixasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? nomeContaCaixa,
    Value<String?>? nomePessoa,
    Value<DateTime?>? dataLancamento,
    Value<DateTime?>? dataVencimento,
    Value<double?>? valor,
    Value<String?>? codigoSituacao,
    Value<String?>? descricaoSituacao,
    Value<String?>? operacao,
  }) {
    return ViewFinFluxoCaixasCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa ?? this.nomeContaCaixa,
      nomePessoa: nomePessoa ?? this.nomePessoa,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      valor: valor ?? this.valor,
      codigoSituacao: codigoSituacao ?? this.codigoSituacao,
      descricaoSituacao: descricaoSituacao ?? this.descricaoSituacao,
      operacao: operacao ?? this.operacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (nomeContaCaixa.present) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa.value);
    }
    if (nomePessoa.present) {
      map['nome_pessoa'] = Variable<String>(nomePessoa.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (codigoSituacao.present) {
      map['codigo_situacao'] = Variable<String>(codigoSituacao.value);
    }
    if (descricaoSituacao.present) {
      map['descricao_situacao'] = Variable<String>(descricaoSituacao.value);
    }
    if (operacao.present) {
      map['operacao'] = Variable<String>(operacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinFluxoCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('nomePessoa: $nomePessoa, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valor: $valor, ')
          ..write('codigoSituacao: $codigoSituacao, ')
          ..write('descricaoSituacao: $descricaoSituacao, ')
          ..write('operacao: $operacao')
          ..write(')'))
        .toString();
  }
}

class $ViewFinChequeNaoCompensadosTable extends ViewFinChequeNaoCompensados
    with
        TableInfo<
          $ViewFinChequeNaoCompensadosTable,
          ViewFinChequeNaoCompensado
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewFinChequeNaoCompensadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBancoContaCaixaMeta = const VerificationMeta(
    'idBancoContaCaixa',
  );
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
    'id_banco_conta_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeContaCaixaMeta = const VerificationMeta(
    'nomeContaCaixa',
  );
  @override
  late final GeneratedColumn<String> nomeContaCaixa = GeneratedColumn<String>(
    'nome_conta_caixa',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 255,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _talaoMeta = const VerificationMeta('talao');
  @override
  late final GeneratedColumn<String> talao = GeneratedColumn<String>(
    'talao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroTalaoMeta = const VerificationMeta(
    'numeroTalao',
  );
  @override
  late final GeneratedColumn<String> numeroTalao = GeneratedColumn<String>(
    'numero_talao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroChequeMeta = const VerificationMeta(
    'numeroCheque',
  );
  @override
  late final GeneratedColumn<String> numeroCheque = GeneratedColumn<String>(
    'numero_cheque',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _statusChequeMeta = const VerificationMeta(
    'statusCheque',
  );
  @override
  late final GeneratedColumn<String> statusCheque = GeneratedColumn<String>(
    'status_cheque',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataStatusMeta = const VerificationMeta(
    'dataStatus',
  );
  @override
  late final GeneratedColumn<DateTime> dataStatus = GeneratedColumn<DateTime>(
    'data_status',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
    'valor',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    talao,
    numeroTalao,
    numeroCheque,
    statusCheque,
    dataStatus,
    valor,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_fin_cheque_nao_compensado';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewFinChequeNaoCompensado> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
        _idBancoContaCaixaMeta,
        idBancoContaCaixa.isAcceptableOrUnknown(
          data['id_banco_conta_caixa']!,
          _idBancoContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('nome_conta_caixa')) {
      context.handle(
        _nomeContaCaixaMeta,
        nomeContaCaixa.isAcceptableOrUnknown(
          data['nome_conta_caixa']!,
          _nomeContaCaixaMeta,
        ),
      );
    }
    if (data.containsKey('talao')) {
      context.handle(
        _talaoMeta,
        talao.isAcceptableOrUnknown(data['talao']!, _talaoMeta),
      );
    }
    if (data.containsKey('numero_talao')) {
      context.handle(
        _numeroTalaoMeta,
        numeroTalao.isAcceptableOrUnknown(
          data['numero_talao']!,
          _numeroTalaoMeta,
        ),
      );
    }
    if (data.containsKey('numero_cheque')) {
      context.handle(
        _numeroChequeMeta,
        numeroCheque.isAcceptableOrUnknown(
          data['numero_cheque']!,
          _numeroChequeMeta,
        ),
      );
    }
    if (data.containsKey('status_cheque')) {
      context.handle(
        _statusChequeMeta,
        statusCheque.isAcceptableOrUnknown(
          data['status_cheque']!,
          _statusChequeMeta,
        ),
      );
    }
    if (data.containsKey('data_status')) {
      context.handle(
        _dataStatusMeta,
        dataStatus.isAcceptableOrUnknown(data['data_status']!, _dataStatusMeta),
      );
    }
    if (data.containsKey('valor')) {
      context.handle(
        _valorMeta,
        valor.isAcceptableOrUnknown(data['valor']!, _valorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewFinChequeNaoCompensado map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewFinChequeNaoCompensado(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_banco_conta_caixa'],
      ),
      nomeContaCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_conta_caixa'],
      ),
      talao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}talao'],
      ),
      numeroTalao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_talao'],
      ),
      numeroCheque: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_cheque'],
      ),
      statusCheque: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status_cheque'],
      ),
      dataStatus: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_status'],
      ),
      valor: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor'],
      ),
    );
  }

  @override
  $ViewFinChequeNaoCompensadosTable createAlias(String alias) {
    return $ViewFinChequeNaoCompensadosTable(attachedDatabase, alias);
  }
}

class ViewFinChequeNaoCompensado extends DataClass
    implements Insertable<ViewFinChequeNaoCompensado> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? nomeContaCaixa;
  final String? talao;
  final String? numeroTalao;
  final String? numeroCheque;
  final String? statusCheque;
  final DateTime? dataStatus;
  final double? valor;
  const ViewFinChequeNaoCompensado({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.talao,
    this.numeroTalao,
    this.numeroCheque,
    this.statusCheque,
    this.dataStatus,
    this.valor,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || nomeContaCaixa != null) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa);
    }
    if (!nullToAbsent || talao != null) {
      map['talao'] = Variable<String>(talao);
    }
    if (!nullToAbsent || numeroTalao != null) {
      map['numero_talao'] = Variable<String>(numeroTalao);
    }
    if (!nullToAbsent || numeroCheque != null) {
      map['numero_cheque'] = Variable<String>(numeroCheque);
    }
    if (!nullToAbsent || statusCheque != null) {
      map['status_cheque'] = Variable<String>(statusCheque);
    }
    if (!nullToAbsent || dataStatus != null) {
      map['data_status'] = Variable<DateTime>(dataStatus);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ViewFinChequeNaoCompensado.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewFinChequeNaoCompensado(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      nomeContaCaixa: serializer.fromJson<String?>(json['nomeContaCaixa']),
      talao: serializer.fromJson<String?>(json['talao']),
      numeroTalao: serializer.fromJson<String?>(json['numeroTalao']),
      numeroCheque: serializer.fromJson<String?>(json['numeroCheque']),
      statusCheque: serializer.fromJson<String?>(json['statusCheque']),
      dataStatus: serializer.fromJson<DateTime?>(json['dataStatus']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'nomeContaCaixa': serializer.toJson<String?>(nomeContaCaixa),
      'talao': serializer.toJson<String?>(talao),
      'numeroTalao': serializer.toJson<String?>(numeroTalao),
      'numeroCheque': serializer.toJson<String?>(numeroCheque),
      'statusCheque': serializer.toJson<String?>(statusCheque),
      'dataStatus': serializer.toJson<DateTime?>(dataStatus),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ViewFinChequeNaoCompensado copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBancoContaCaixa = const Value.absent(),
    Value<String?> nomeContaCaixa = const Value.absent(),
    Value<String?> talao = const Value.absent(),
    Value<String?> numeroTalao = const Value.absent(),
    Value<String?> numeroCheque = const Value.absent(),
    Value<String?> statusCheque = const Value.absent(),
    Value<DateTime?> dataStatus = const Value.absent(),
    Value<double?> valor = const Value.absent(),
  }) => ViewFinChequeNaoCompensado(
    id: id.present ? id.value : this.id,
    idBancoContaCaixa:
        idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
    nomeContaCaixa:
        nomeContaCaixa.present ? nomeContaCaixa.value : this.nomeContaCaixa,
    talao: talao.present ? talao.value : this.talao,
    numeroTalao: numeroTalao.present ? numeroTalao.value : this.numeroTalao,
    numeroCheque: numeroCheque.present ? numeroCheque.value : this.numeroCheque,
    statusCheque: statusCheque.present ? statusCheque.value : this.statusCheque,
    dataStatus: dataStatus.present ? dataStatus.value : this.dataStatus,
    valor: valor.present ? valor.value : this.valor,
  );
  ViewFinChequeNaoCompensado copyWithCompanion(
    ViewFinChequeNaoCompensadosCompanion data,
  ) {
    return ViewFinChequeNaoCompensado(
      id: data.id.present ? data.id.value : this.id,
      idBancoContaCaixa:
          data.idBancoContaCaixa.present
              ? data.idBancoContaCaixa.value
              : this.idBancoContaCaixa,
      nomeContaCaixa:
          data.nomeContaCaixa.present
              ? data.nomeContaCaixa.value
              : this.nomeContaCaixa,
      talao: data.talao.present ? data.talao.value : this.talao,
      numeroTalao:
          data.numeroTalao.present ? data.numeroTalao.value : this.numeroTalao,
      numeroCheque:
          data.numeroCheque.present
              ? data.numeroCheque.value
              : this.numeroCheque,
      statusCheque:
          data.statusCheque.present
              ? data.statusCheque.value
              : this.statusCheque,
      dataStatus:
          data.dataStatus.present ? data.dataStatus.value : this.dataStatus,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinChequeNaoCompensado(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('talao: $talao, ')
          ..write('numeroTalao: $numeroTalao, ')
          ..write('numeroCheque: $numeroCheque, ')
          ..write('statusCheque: $statusCheque, ')
          ..write('dataStatus: $dataStatus, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBancoContaCaixa,
    nomeContaCaixa,
    talao,
    numeroTalao,
    numeroCheque,
    statusCheque,
    dataStatus,
    valor,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewFinChequeNaoCompensado &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.nomeContaCaixa == this.nomeContaCaixa &&
          other.talao == this.talao &&
          other.numeroTalao == this.numeroTalao &&
          other.numeroCheque == this.numeroCheque &&
          other.statusCheque == this.statusCheque &&
          other.dataStatus == this.dataStatus &&
          other.valor == this.valor);
}

class ViewFinChequeNaoCompensadosCompanion
    extends UpdateCompanion<ViewFinChequeNaoCompensado> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> nomeContaCaixa;
  final Value<String?> talao;
  final Value<String?> numeroTalao;
  final Value<String?> numeroCheque;
  final Value<String?> statusCheque;
  final Value<DateTime?> dataStatus;
  final Value<double?> valor;
  const ViewFinChequeNaoCompensadosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.talao = const Value.absent(),
    this.numeroTalao = const Value.absent(),
    this.numeroCheque = const Value.absent(),
    this.statusCheque = const Value.absent(),
    this.dataStatus = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ViewFinChequeNaoCompensadosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.nomeContaCaixa = const Value.absent(),
    this.talao = const Value.absent(),
    this.numeroTalao = const Value.absent(),
    this.numeroCheque = const Value.absent(),
    this.statusCheque = const Value.absent(),
    this.dataStatus = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ViewFinChequeNaoCompensado> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? nomeContaCaixa,
    Expression<String>? talao,
    Expression<String>? numeroTalao,
    Expression<String>? numeroCheque,
    Expression<String>? statusCheque,
    Expression<DateTime>? dataStatus,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (nomeContaCaixa != null) 'nome_conta_caixa': nomeContaCaixa,
      if (talao != null) 'talao': talao,
      if (numeroTalao != null) 'numero_talao': numeroTalao,
      if (numeroCheque != null) 'numero_cheque': numeroCheque,
      if (statusCheque != null) 'status_cheque': statusCheque,
      if (dataStatus != null) 'data_status': dataStatus,
      if (valor != null) 'valor': valor,
    });
  }

  ViewFinChequeNaoCompensadosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBancoContaCaixa,
    Value<String?>? nomeContaCaixa,
    Value<String?>? talao,
    Value<String?>? numeroTalao,
    Value<String?>? numeroCheque,
    Value<String?>? statusCheque,
    Value<DateTime?>? dataStatus,
    Value<double?>? valor,
  }) {
    return ViewFinChequeNaoCompensadosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa ?? this.nomeContaCaixa,
      talao: talao ?? this.talao,
      numeroTalao: numeroTalao ?? this.numeroTalao,
      numeroCheque: numeroCheque ?? this.numeroCheque,
      statusCheque: statusCheque ?? this.statusCheque,
      dataStatus: dataStatus ?? this.dataStatus,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (nomeContaCaixa.present) {
      map['nome_conta_caixa'] = Variable<String>(nomeContaCaixa.value);
    }
    if (talao.present) {
      map['talao'] = Variable<String>(talao.value);
    }
    if (numeroTalao.present) {
      map['numero_talao'] = Variable<String>(numeroTalao.value);
    }
    if (numeroCheque.present) {
      map['numero_cheque'] = Variable<String>(numeroCheque.value);
    }
    if (statusCheque.present) {
      map['status_cheque'] = Variable<String>(statusCheque.value);
    }
    if (dataStatus.present) {
      map['data_status'] = Variable<DateTime>(dataStatus.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewFinChequeNaoCompensadosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('nomeContaCaixa: $nomeContaCaixa, ')
          ..write('talao: $talao, ')
          ..write('numeroTalao: $numeroTalao, ')
          ..write('numeroCheque: $numeroCheque, ')
          ..write('statusCheque: $statusCheque, ')
          ..write('dataStatus: $dataStatus, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ChequesTable cheques = $ChequesTable(this);
  late final $FinParcelaPagarsTable finParcelaPagars = $FinParcelaPagarsTable(
    this,
  );
  late final $FinParcelaRecebersTable finParcelaRecebers =
      $FinParcelaRecebersTable(this);
  late final $TalonarioChequesTable talonarioCheques = $TalonarioChequesTable(
    this,
  );
  late final $FinLancamentoPagarsTable finLancamentoPagars =
      $FinLancamentoPagarsTable(this);
  late final $FinLancamentoRecebersTable finLancamentoRecebers =
      $FinLancamentoRecebersTable(this);
  late final $BancosTable bancos = $BancosTable(this);
  late final $BancoAgenciasTable bancoAgencias = $BancoAgenciasTable(this);
  late final $BancoContaCaixasTable bancoContaCaixas = $BancoContaCaixasTable(
    this,
  );
  late final $FinFechamentoCaixaBancosTable finFechamentoCaixaBancos =
      $FinFechamentoCaixaBancosTable(this);
  late final $FinExtratoContaBancosTable finExtratoContaBancos =
      $FinExtratoContaBancosTable(this);
  late final $FinDocumentoOrigemsTable finDocumentoOrigems =
      $FinDocumentoOrigemsTable(this);
  late final $FinNaturezaFinanceirasTable finNaturezaFinanceiras =
      $FinNaturezaFinanceirasTable(this);
  late final $FinStatusParcelasTable finStatusParcelas =
      $FinStatusParcelasTable(this);
  late final $FinTipoPagamentosTable finTipoPagamentos =
      $FinTipoPagamentosTable(this);
  late final $FinChequeEmitidosTable finChequeEmitidos =
      $FinChequeEmitidosTable(this);
  late final $FinTipoRecebimentosTable finTipoRecebimentos =
      $FinTipoRecebimentosTable(this);
  late final $FinChequeRecebidosTable finChequeRecebidos =
      $FinChequeRecebidosTable(this);
  late final $FinConfiguracaoBoletosTable finConfiguracaoBoletos =
      $FinConfiguracaoBoletosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaClientesTable viewPessoaClientes =
      $ViewPessoaClientesTable(this);
  late final $ViewPessoaFornecedorsTable viewPessoaFornecedors =
      $ViewPessoaFornecedorsTable(this);
  late final $ViewFinMovimentoCaixaBancosTable viewFinMovimentoCaixaBancos =
      $ViewFinMovimentoCaixaBancosTable(this);
  late final $ViewFinFluxoCaixasTable viewFinFluxoCaixas =
      $ViewFinFluxoCaixasTable(this);
  late final $ViewFinChequeNaoCompensadosTable viewFinChequeNaoCompensados =
      $ViewFinChequeNaoCompensadosTable(this);
  late final TalonarioChequeDao talonarioChequeDao = TalonarioChequeDao(
    this as AppDatabase,
  );
  late final FinLancamentoPagarDao finLancamentoPagarDao =
      FinLancamentoPagarDao(this as AppDatabase);
  late final FinLancamentoReceberDao finLancamentoReceberDao =
      FinLancamentoReceberDao(this as AppDatabase);
  late final BancoDao bancoDao = BancoDao(this as AppDatabase);
  late final BancoAgenciaDao bancoAgenciaDao = BancoAgenciaDao(
    this as AppDatabase,
  );
  late final BancoContaCaixaDao bancoContaCaixaDao = BancoContaCaixaDao(
    this as AppDatabase,
  );
  late final FinFechamentoCaixaBancoDao finFechamentoCaixaBancoDao =
      FinFechamentoCaixaBancoDao(this as AppDatabase);
  late final FinExtratoContaBancoDao finExtratoContaBancoDao =
      FinExtratoContaBancoDao(this as AppDatabase);
  late final FinDocumentoOrigemDao finDocumentoOrigemDao =
      FinDocumentoOrigemDao(this as AppDatabase);
  late final FinNaturezaFinanceiraDao finNaturezaFinanceiraDao =
      FinNaturezaFinanceiraDao(this as AppDatabase);
  late final FinStatusParcelaDao finStatusParcelaDao = FinStatusParcelaDao(
    this as AppDatabase,
  );
  late final FinTipoPagamentoDao finTipoPagamentoDao = FinTipoPagamentoDao(
    this as AppDatabase,
  );
  late final FinChequeEmitidoDao finChequeEmitidoDao = FinChequeEmitidoDao(
    this as AppDatabase,
  );
  late final FinTipoRecebimentoDao finTipoRecebimentoDao =
      FinTipoRecebimentoDao(this as AppDatabase);
  late final FinChequeRecebidoDao finChequeRecebidoDao = FinChequeRecebidoDao(
    this as AppDatabase,
  );
  late final FinConfiguracaoBoletoDao finConfiguracaoBoletoDao =
      FinConfiguracaoBoletoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final ViewPessoaClienteDao viewPessoaClienteDao = ViewPessoaClienteDao(
    this as AppDatabase,
  );
  late final ViewPessoaFornecedorDao viewPessoaFornecedorDao =
      ViewPessoaFornecedorDao(this as AppDatabase);
  late final ViewFinMovimentoCaixaBancoDao viewFinMovimentoCaixaBancoDao =
      ViewFinMovimentoCaixaBancoDao(this as AppDatabase);
  late final ViewFinFluxoCaixaDao viewFinFluxoCaixaDao = ViewFinFluxoCaixaDao(
    this as AppDatabase,
  );
  late final ViewFinChequeNaoCompensadoDao viewFinChequeNaoCompensadoDao =
      ViewFinChequeNaoCompensadoDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    cheques,
    finParcelaPagars,
    finParcelaRecebers,
    talonarioCheques,
    finLancamentoPagars,
    finLancamentoRecebers,
    bancos,
    bancoAgencias,
    bancoContaCaixas,
    finFechamentoCaixaBancos,
    finExtratoContaBancos,
    finDocumentoOrigems,
    finNaturezaFinanceiras,
    finStatusParcelas,
    finTipoPagamentos,
    finChequeEmitidos,
    finTipoRecebimentos,
    finChequeRecebidos,
    finConfiguracaoBoletos,
    viewControleAcessos,
    viewPessoaUsuarios,
    viewPessoaClientes,
    viewPessoaFornecedors,
    viewFinMovimentoCaixaBancos,
    viewFinFluxoCaixas,
    viewFinChequeNaoCompensados,
  ];
}

typedef $$ChequesTableCreateCompanionBuilder =
    ChequesCompanion Function({
      Value<int?> id,
      Value<int?> idTalonarioCheque,
      Value<int?> numero,
      Value<String?> statusCheque,
      Value<DateTime?> dataStatus,
    });
typedef $$ChequesTableUpdateCompanionBuilder =
    ChequesCompanion Function({
      Value<int?> id,
      Value<int?> idTalonarioCheque,
      Value<int?> numero,
      Value<String?> statusCheque,
      Value<DateTime?> dataStatus,
    });

class $$ChequesTableFilterComposer
    extends Composer<_$AppDatabase, $ChequesTable> {
  $$ChequesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTalonarioCheque => $composableBuilder(
    column: $table.idTalonarioCheque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ChequesTableOrderingComposer
    extends Composer<_$AppDatabase, $ChequesTable> {
  $$ChequesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTalonarioCheque => $composableBuilder(
    column: $table.idTalonarioCheque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ChequesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ChequesTable> {
  $$ChequesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idTalonarioCheque => $composableBuilder(
    column: $table.idTalonarioCheque,
    builder: (column) => column,
  );

  GeneratedColumn<int> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => column,
  );
}

class $$ChequesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ChequesTable,
          Cheque,
          $$ChequesTableFilterComposer,
          $$ChequesTableOrderingComposer,
          $$ChequesTableAnnotationComposer,
          $$ChequesTableCreateCompanionBuilder,
          $$ChequesTableUpdateCompanionBuilder,
          (Cheque, BaseReferences<_$AppDatabase, $ChequesTable, Cheque>),
          Cheque,
          PrefetchHooks Function()
        > {
  $$ChequesTableTableManager(_$AppDatabase db, $ChequesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ChequesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$ChequesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$ChequesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTalonarioCheque = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<String?> statusCheque = const Value.absent(),
                Value<DateTime?> dataStatus = const Value.absent(),
              }) => ChequesCompanion(
                id: id,
                idTalonarioCheque: idTalonarioCheque,
                numero: numero,
                statusCheque: statusCheque,
                dataStatus: dataStatus,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTalonarioCheque = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<String?> statusCheque = const Value.absent(),
                Value<DateTime?> dataStatus = const Value.absent(),
              }) => ChequesCompanion.insert(
                id: id,
                idTalonarioCheque: idTalonarioCheque,
                numero: numero,
                statusCheque: statusCheque,
                dataStatus: dataStatus,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ChequesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ChequesTable,
      Cheque,
      $$ChequesTableFilterComposer,
      $$ChequesTableOrderingComposer,
      $$ChequesTableAnnotationComposer,
      $$ChequesTableCreateCompanionBuilder,
      $$ChequesTableUpdateCompanionBuilder,
      (Cheque, BaseReferences<_$AppDatabase, $ChequesTable, Cheque>),
      Cheque,
      PrefetchHooks Function()
    >;
typedef $$FinParcelaPagarsTableCreateCompanionBuilder =
    FinParcelaPagarsCompanion Function({
      Value<int?> id,
      Value<int?> idFinLancamentoPagar,
      Value<int?> idFinChequeEmitido,
      Value<int?> idFinStatusParcela,
      Value<int?> idFinTipoPagamento,
      Value<int?> numeroParcela,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataPagamento,
      Value<DateTime?> descontoAte,
      Value<double?> valor,
      Value<double?> taxaJuro,
      Value<double?> taxaMulta,
      Value<double?> taxaDesconto,
      Value<double?> valorJuro,
      Value<double?> valorMulta,
      Value<double?> valorDesconto,
      Value<double?> valorPago,
      Value<String?> historico,
    });
typedef $$FinParcelaPagarsTableUpdateCompanionBuilder =
    FinParcelaPagarsCompanion Function({
      Value<int?> id,
      Value<int?> idFinLancamentoPagar,
      Value<int?> idFinChequeEmitido,
      Value<int?> idFinStatusParcela,
      Value<int?> idFinTipoPagamento,
      Value<int?> numeroParcela,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataPagamento,
      Value<DateTime?> descontoAte,
      Value<double?> valor,
      Value<double?> taxaJuro,
      Value<double?> taxaMulta,
      Value<double?> taxaDesconto,
      Value<double?> valorJuro,
      Value<double?> valorMulta,
      Value<double?> valorDesconto,
      Value<double?> valorPago,
      Value<String?> historico,
    });

class $$FinParcelaPagarsTableFilterComposer
    extends Composer<_$AppDatabase, $FinParcelaPagarsTable> {
  $$FinParcelaPagarsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinLancamentoPagar => $composableBuilder(
    column: $table.idFinLancamentoPagar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinChequeEmitido => $composableBuilder(
    column: $table.idFinChequeEmitido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinTipoPagamento => $composableBuilder(
    column: $table.idFinTipoPagamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataPagamento => $composableBuilder(
    column: $table.dataPagamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorJuro => $composableBuilder(
    column: $table.valorJuro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorPago => $composableBuilder(
    column: $table.valorPago,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinParcelaPagarsTableOrderingComposer
    extends Composer<_$AppDatabase, $FinParcelaPagarsTable> {
  $$FinParcelaPagarsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinLancamentoPagar => $composableBuilder(
    column: $table.idFinLancamentoPagar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinChequeEmitido => $composableBuilder(
    column: $table.idFinChequeEmitido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinTipoPagamento => $composableBuilder(
    column: $table.idFinTipoPagamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataPagamento => $composableBuilder(
    column: $table.dataPagamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorJuro => $composableBuilder(
    column: $table.valorJuro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorPago => $composableBuilder(
    column: $table.valorPago,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinParcelaPagarsTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinParcelaPagarsTable> {
  $$FinParcelaPagarsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idFinLancamentoPagar => $composableBuilder(
    column: $table.idFinLancamentoPagar,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinChequeEmitido => $composableBuilder(
    column: $table.idFinChequeEmitido,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinTipoPagamento => $composableBuilder(
    column: $table.idFinTipoPagamento,
    builder: (column) => column,
  );

  GeneratedColumn<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataPagamento => $composableBuilder(
    column: $table.dataPagamento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<double> get taxaJuro =>
      $composableBuilder(column: $table.taxaJuro, builder: (column) => column);

  GeneratedColumn<double> get taxaMulta =>
      $composableBuilder(column: $table.taxaMulta, builder: (column) => column);

  GeneratedColumn<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorJuro =>
      $composableBuilder(column: $table.valorJuro, builder: (column) => column);

  GeneratedColumn<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorPago =>
      $composableBuilder(column: $table.valorPago, builder: (column) => column);

  GeneratedColumn<String> get historico =>
      $composableBuilder(column: $table.historico, builder: (column) => column);
}

class $$FinParcelaPagarsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinParcelaPagarsTable,
          FinParcelaPagar,
          $$FinParcelaPagarsTableFilterComposer,
          $$FinParcelaPagarsTableOrderingComposer,
          $$FinParcelaPagarsTableAnnotationComposer,
          $$FinParcelaPagarsTableCreateCompanionBuilder,
          $$FinParcelaPagarsTableUpdateCompanionBuilder,
          (
            FinParcelaPagar,
            BaseReferences<
              _$AppDatabase,
              $FinParcelaPagarsTable,
              FinParcelaPagar
            >,
          ),
          FinParcelaPagar,
          PrefetchHooks Function()
        > {
  $$FinParcelaPagarsTableTableManager(
    _$AppDatabase db,
    $FinParcelaPagarsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$FinParcelaPagarsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$FinParcelaPagarsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinParcelaPagarsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idFinLancamentoPagar = const Value.absent(),
                Value<int?> idFinChequeEmitido = const Value.absent(),
                Value<int?> idFinStatusParcela = const Value.absent(),
                Value<int?> idFinTipoPagamento = const Value.absent(),
                Value<int?> numeroParcela = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataPagamento = const Value.absent(),
                Value<DateTime?> descontoAte = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> valorJuro = const Value.absent(),
                Value<double?> valorMulta = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<double?> valorPago = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => FinParcelaPagarsCompanion(
                id: id,
                idFinLancamentoPagar: idFinLancamentoPagar,
                idFinChequeEmitido: idFinChequeEmitido,
                idFinStatusParcela: idFinStatusParcela,
                idFinTipoPagamento: idFinTipoPagamento,
                numeroParcela: numeroParcela,
                dataEmissao: dataEmissao,
                dataVencimento: dataVencimento,
                dataPagamento: dataPagamento,
                descontoAte: descontoAte,
                valor: valor,
                taxaJuro: taxaJuro,
                taxaMulta: taxaMulta,
                taxaDesconto: taxaDesconto,
                valorJuro: valorJuro,
                valorMulta: valorMulta,
                valorDesconto: valorDesconto,
                valorPago: valorPago,
                historico: historico,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idFinLancamentoPagar = const Value.absent(),
                Value<int?> idFinChequeEmitido = const Value.absent(),
                Value<int?> idFinStatusParcela = const Value.absent(),
                Value<int?> idFinTipoPagamento = const Value.absent(),
                Value<int?> numeroParcela = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataPagamento = const Value.absent(),
                Value<DateTime?> descontoAte = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> valorJuro = const Value.absent(),
                Value<double?> valorMulta = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<double?> valorPago = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => FinParcelaPagarsCompanion.insert(
                id: id,
                idFinLancamentoPagar: idFinLancamentoPagar,
                idFinChequeEmitido: idFinChequeEmitido,
                idFinStatusParcela: idFinStatusParcela,
                idFinTipoPagamento: idFinTipoPagamento,
                numeroParcela: numeroParcela,
                dataEmissao: dataEmissao,
                dataVencimento: dataVencimento,
                dataPagamento: dataPagamento,
                descontoAte: descontoAte,
                valor: valor,
                taxaJuro: taxaJuro,
                taxaMulta: taxaMulta,
                taxaDesconto: taxaDesconto,
                valorJuro: valorJuro,
                valorMulta: valorMulta,
                valorDesconto: valorDesconto,
                valorPago: valorPago,
                historico: historico,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinParcelaPagarsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinParcelaPagarsTable,
      FinParcelaPagar,
      $$FinParcelaPagarsTableFilterComposer,
      $$FinParcelaPagarsTableOrderingComposer,
      $$FinParcelaPagarsTableAnnotationComposer,
      $$FinParcelaPagarsTableCreateCompanionBuilder,
      $$FinParcelaPagarsTableUpdateCompanionBuilder,
      (
        FinParcelaPagar,
        BaseReferences<_$AppDatabase, $FinParcelaPagarsTable, FinParcelaPagar>,
      ),
      FinParcelaPagar,
      PrefetchHooks Function()
    >;
typedef $$FinParcelaRecebersTableCreateCompanionBuilder =
    FinParcelaRecebersCompanion Function({
      Value<int?> id,
      Value<int?> idFinLancamentoReceber,
      Value<int?> idFinChequeRecebido,
      Value<int?> idFinStatusParcela,
      Value<int?> idFinTipoRecebimento,
      Value<int?> numeroParcela,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataRecebimento,
      Value<DateTime?> descontoAte,
      Value<double?> valor,
      Value<double?> taxaJuro,
      Value<double?> taxaMulta,
      Value<double?> taxaDesconto,
      Value<double?> valorJuro,
      Value<double?> valorMulta,
      Value<double?> valorDesconto,
      Value<String?> emitiuBoleto,
      Value<String?> boletoNossoNumero,
      Value<double?> valorRecebido,
      Value<String?> historico,
    });
typedef $$FinParcelaRecebersTableUpdateCompanionBuilder =
    FinParcelaRecebersCompanion Function({
      Value<int?> id,
      Value<int?> idFinLancamentoReceber,
      Value<int?> idFinChequeRecebido,
      Value<int?> idFinStatusParcela,
      Value<int?> idFinTipoRecebimento,
      Value<int?> numeroParcela,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataRecebimento,
      Value<DateTime?> descontoAte,
      Value<double?> valor,
      Value<double?> taxaJuro,
      Value<double?> taxaMulta,
      Value<double?> taxaDesconto,
      Value<double?> valorJuro,
      Value<double?> valorMulta,
      Value<double?> valorDesconto,
      Value<String?> emitiuBoleto,
      Value<String?> boletoNossoNumero,
      Value<double?> valorRecebido,
      Value<String?> historico,
    });

class $$FinParcelaRecebersTableFilterComposer
    extends Composer<_$AppDatabase, $FinParcelaRecebersTable> {
  $$FinParcelaRecebersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinLancamentoReceber => $composableBuilder(
    column: $table.idFinLancamentoReceber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinChequeRecebido => $composableBuilder(
    column: $table.idFinChequeRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinTipoRecebimento => $composableBuilder(
    column: $table.idFinTipoRecebimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorJuro => $composableBuilder(
    column: $table.valorJuro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get emitiuBoleto => $composableBuilder(
    column: $table.emitiuBoleto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get boletoNossoNumero => $composableBuilder(
    column: $table.boletoNossoNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinParcelaRecebersTableOrderingComposer
    extends Composer<_$AppDatabase, $FinParcelaRecebersTable> {
  $$FinParcelaRecebersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinLancamentoReceber => $composableBuilder(
    column: $table.idFinLancamentoReceber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinChequeRecebido => $composableBuilder(
    column: $table.idFinChequeRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinTipoRecebimento => $composableBuilder(
    column: $table.idFinTipoRecebimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorJuro => $composableBuilder(
    column: $table.valorJuro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get emitiuBoleto => $composableBuilder(
    column: $table.emitiuBoleto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get boletoNossoNumero => $composableBuilder(
    column: $table.boletoNossoNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinParcelaRecebersTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinParcelaRecebersTable> {
  $$FinParcelaRecebersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idFinLancamentoReceber => $composableBuilder(
    column: $table.idFinLancamentoReceber,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinChequeRecebido => $composableBuilder(
    column: $table.idFinChequeRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinStatusParcela => $composableBuilder(
    column: $table.idFinStatusParcela,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinTipoRecebimento => $composableBuilder(
    column: $table.idFinTipoRecebimento,
    builder: (column) => column,
  );

  GeneratedColumn<int> get numeroParcela => $composableBuilder(
    column: $table.numeroParcela,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get descontoAte => $composableBuilder(
    column: $table.descontoAte,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<double> get taxaJuro =>
      $composableBuilder(column: $table.taxaJuro, builder: (column) => column);

  GeneratedColumn<double> get taxaMulta =>
      $composableBuilder(column: $table.taxaMulta, builder: (column) => column);

  GeneratedColumn<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorJuro =>
      $composableBuilder(column: $table.valorJuro, builder: (column) => column);

  GeneratedColumn<double> get valorMulta => $composableBuilder(
    column: $table.valorMulta,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<String> get emitiuBoleto => $composableBuilder(
    column: $table.emitiuBoleto,
    builder: (column) => column,
  );

  GeneratedColumn<String> get boletoNossoNumero => $composableBuilder(
    column: $table.boletoNossoNumero,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<String> get historico =>
      $composableBuilder(column: $table.historico, builder: (column) => column);
}

class $$FinParcelaRecebersTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinParcelaRecebersTable,
          FinParcelaReceber,
          $$FinParcelaRecebersTableFilterComposer,
          $$FinParcelaRecebersTableOrderingComposer,
          $$FinParcelaRecebersTableAnnotationComposer,
          $$FinParcelaRecebersTableCreateCompanionBuilder,
          $$FinParcelaRecebersTableUpdateCompanionBuilder,
          (
            FinParcelaReceber,
            BaseReferences<
              _$AppDatabase,
              $FinParcelaRecebersTable,
              FinParcelaReceber
            >,
          ),
          FinParcelaReceber,
          PrefetchHooks Function()
        > {
  $$FinParcelaRecebersTableTableManager(
    _$AppDatabase db,
    $FinParcelaRecebersTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinParcelaRecebersTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinParcelaRecebersTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinParcelaRecebersTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idFinLancamentoReceber = const Value.absent(),
                Value<int?> idFinChequeRecebido = const Value.absent(),
                Value<int?> idFinStatusParcela = const Value.absent(),
                Value<int?> idFinTipoRecebimento = const Value.absent(),
                Value<int?> numeroParcela = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataRecebimento = const Value.absent(),
                Value<DateTime?> descontoAte = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> valorJuro = const Value.absent(),
                Value<double?> valorMulta = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<String?> emitiuBoleto = const Value.absent(),
                Value<String?> boletoNossoNumero = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => FinParcelaRecebersCompanion(
                id: id,
                idFinLancamentoReceber: idFinLancamentoReceber,
                idFinChequeRecebido: idFinChequeRecebido,
                idFinStatusParcela: idFinStatusParcela,
                idFinTipoRecebimento: idFinTipoRecebimento,
                numeroParcela: numeroParcela,
                dataEmissao: dataEmissao,
                dataVencimento: dataVencimento,
                dataRecebimento: dataRecebimento,
                descontoAte: descontoAte,
                valor: valor,
                taxaJuro: taxaJuro,
                taxaMulta: taxaMulta,
                taxaDesconto: taxaDesconto,
                valorJuro: valorJuro,
                valorMulta: valorMulta,
                valorDesconto: valorDesconto,
                emitiuBoleto: emitiuBoleto,
                boletoNossoNumero: boletoNossoNumero,
                valorRecebido: valorRecebido,
                historico: historico,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idFinLancamentoReceber = const Value.absent(),
                Value<int?> idFinChequeRecebido = const Value.absent(),
                Value<int?> idFinStatusParcela = const Value.absent(),
                Value<int?> idFinTipoRecebimento = const Value.absent(),
                Value<int?> numeroParcela = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataRecebimento = const Value.absent(),
                Value<DateTime?> descontoAte = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> valorJuro = const Value.absent(),
                Value<double?> valorMulta = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<String?> emitiuBoleto = const Value.absent(),
                Value<String?> boletoNossoNumero = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => FinParcelaRecebersCompanion.insert(
                id: id,
                idFinLancamentoReceber: idFinLancamentoReceber,
                idFinChequeRecebido: idFinChequeRecebido,
                idFinStatusParcela: idFinStatusParcela,
                idFinTipoRecebimento: idFinTipoRecebimento,
                numeroParcela: numeroParcela,
                dataEmissao: dataEmissao,
                dataVencimento: dataVencimento,
                dataRecebimento: dataRecebimento,
                descontoAte: descontoAte,
                valor: valor,
                taxaJuro: taxaJuro,
                taxaMulta: taxaMulta,
                taxaDesconto: taxaDesconto,
                valorJuro: valorJuro,
                valorMulta: valorMulta,
                valorDesconto: valorDesconto,
                emitiuBoleto: emitiuBoleto,
                boletoNossoNumero: boletoNossoNumero,
                valorRecebido: valorRecebido,
                historico: historico,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinParcelaRecebersTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinParcelaRecebersTable,
      FinParcelaReceber,
      $$FinParcelaRecebersTableFilterComposer,
      $$FinParcelaRecebersTableOrderingComposer,
      $$FinParcelaRecebersTableAnnotationComposer,
      $$FinParcelaRecebersTableCreateCompanionBuilder,
      $$FinParcelaRecebersTableUpdateCompanionBuilder,
      (
        FinParcelaReceber,
        BaseReferences<
          _$AppDatabase,
          $FinParcelaRecebersTable,
          FinParcelaReceber
        >,
      ),
      FinParcelaReceber,
      PrefetchHooks Function()
    >;
typedef $$TalonarioChequesTableCreateCompanionBuilder =
    TalonarioChequesCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> talao,
      Value<int?> numero,
      Value<String?> statusTalao,
    });
typedef $$TalonarioChequesTableUpdateCompanionBuilder =
    TalonarioChequesCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> talao,
      Value<int?> numero,
      Value<String?> statusTalao,
    });

class $$TalonarioChequesTableFilterComposer
    extends Composer<_$AppDatabase, $TalonarioChequesTable> {
  $$TalonarioChequesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get talao => $composableBuilder(
    column: $table.talao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get statusTalao => $composableBuilder(
    column: $table.statusTalao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$TalonarioChequesTableOrderingComposer
    extends Composer<_$AppDatabase, $TalonarioChequesTable> {
  $$TalonarioChequesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get talao => $composableBuilder(
    column: $table.talao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get statusTalao => $composableBuilder(
    column: $table.statusTalao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$TalonarioChequesTableAnnotationComposer
    extends Composer<_$AppDatabase, $TalonarioChequesTable> {
  $$TalonarioChequesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get talao =>
      $composableBuilder(column: $table.talao, builder: (column) => column);

  GeneratedColumn<int> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get statusTalao => $composableBuilder(
    column: $table.statusTalao,
    builder: (column) => column,
  );
}

class $$TalonarioChequesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $TalonarioChequesTable,
          TalonarioCheque,
          $$TalonarioChequesTableFilterComposer,
          $$TalonarioChequesTableOrderingComposer,
          $$TalonarioChequesTableAnnotationComposer,
          $$TalonarioChequesTableCreateCompanionBuilder,
          $$TalonarioChequesTableUpdateCompanionBuilder,
          (
            TalonarioCheque,
            BaseReferences<
              _$AppDatabase,
              $TalonarioChequesTable,
              TalonarioCheque
            >,
          ),
          TalonarioCheque,
          PrefetchHooks Function()
        > {
  $$TalonarioChequesTableTableManager(
    _$AppDatabase db,
    $TalonarioChequesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$TalonarioChequesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$TalonarioChequesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$TalonarioChequesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> talao = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<String?> statusTalao = const Value.absent(),
              }) => TalonarioChequesCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                talao: talao,
                numero: numero,
                statusTalao: statusTalao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> talao = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<String?> statusTalao = const Value.absent(),
              }) => TalonarioChequesCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                talao: talao,
                numero: numero,
                statusTalao: statusTalao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$TalonarioChequesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $TalonarioChequesTable,
      TalonarioCheque,
      $$TalonarioChequesTableFilterComposer,
      $$TalonarioChequesTableOrderingComposer,
      $$TalonarioChequesTableAnnotationComposer,
      $$TalonarioChequesTableCreateCompanionBuilder,
      $$TalonarioChequesTableUpdateCompanionBuilder,
      (
        TalonarioCheque,
        BaseReferences<_$AppDatabase, $TalonarioChequesTable, TalonarioCheque>,
      ),
      TalonarioCheque,
      PrefetchHooks Function()
    >;
typedef $$FinLancamentoPagarsTableCreateCompanionBuilder =
    FinLancamentoPagarsCompanion Function({
      Value<int?> id,
      Value<String?> imagemDocumento,
      Value<int?> idFornecedor,
      Value<int?> idBancoContaCaixa,
      Value<int?> idFinDocumentoOrigem,
      Value<int?> idFinNaturezaFinanceira,
      Value<int?> quantidadeParcela,
      Value<double?> valorAPagar,
      Value<DateTime?> dataLancamento,
      Value<String?> numeroDocumento,
      Value<DateTime?> primeiroVencimento,
      Value<int?> intervaloEntreParcelas,
      Value<String?> diaFixo,
    });
typedef $$FinLancamentoPagarsTableUpdateCompanionBuilder =
    FinLancamentoPagarsCompanion Function({
      Value<int?> id,
      Value<String?> imagemDocumento,
      Value<int?> idFornecedor,
      Value<int?> idBancoContaCaixa,
      Value<int?> idFinDocumentoOrigem,
      Value<int?> idFinNaturezaFinanceira,
      Value<int?> quantidadeParcela,
      Value<double?> valorAPagar,
      Value<DateTime?> dataLancamento,
      Value<String?> numeroDocumento,
      Value<DateTime?> primeiroVencimento,
      Value<int?> intervaloEntreParcelas,
      Value<String?> diaFixo,
    });

class $$FinLancamentoPagarsTableFilterComposer
    extends Composer<_$AppDatabase, $FinLancamentoPagarsTable> {
  $$FinLancamentoPagarsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get imagemDocumento => $composableBuilder(
    column: $table.imagemDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorAPagar => $composableBuilder(
    column: $table.valorAPagar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get diaFixo => $composableBuilder(
    column: $table.diaFixo,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinLancamentoPagarsTableOrderingComposer
    extends Composer<_$AppDatabase, $FinLancamentoPagarsTable> {
  $$FinLancamentoPagarsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get imagemDocumento => $composableBuilder(
    column: $table.imagemDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorAPagar => $composableBuilder(
    column: $table.valorAPagar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get diaFixo => $composableBuilder(
    column: $table.diaFixo,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinLancamentoPagarsTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinLancamentoPagarsTable> {
  $$FinLancamentoPagarsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get imagemDocumento => $composableBuilder(
    column: $table.imagemDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorAPagar => $composableBuilder(
    column: $table.valorAPagar,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => column,
  );

  GeneratedColumn<String> get diaFixo =>
      $composableBuilder(column: $table.diaFixo, builder: (column) => column);
}

class $$FinLancamentoPagarsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinLancamentoPagarsTable,
          FinLancamentoPagar,
          $$FinLancamentoPagarsTableFilterComposer,
          $$FinLancamentoPagarsTableOrderingComposer,
          $$FinLancamentoPagarsTableAnnotationComposer,
          $$FinLancamentoPagarsTableCreateCompanionBuilder,
          $$FinLancamentoPagarsTableUpdateCompanionBuilder,
          (
            FinLancamentoPagar,
            BaseReferences<
              _$AppDatabase,
              $FinLancamentoPagarsTable,
              FinLancamentoPagar
            >,
          ),
          FinLancamentoPagar,
          PrefetchHooks Function()
        > {
  $$FinLancamentoPagarsTableTableManager(
    _$AppDatabase db,
    $FinLancamentoPagarsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinLancamentoPagarsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinLancamentoPagarsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinLancamentoPagarsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> imagemDocumento = const Value.absent(),
                Value<int?> idFornecedor = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<int?> idFinDocumentoOrigem = const Value.absent(),
                Value<int?> idFinNaturezaFinanceira = const Value.absent(),
                Value<int?> quantidadeParcela = const Value.absent(),
                Value<double?> valorAPagar = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<DateTime?> primeiroVencimento = const Value.absent(),
                Value<int?> intervaloEntreParcelas = const Value.absent(),
                Value<String?> diaFixo = const Value.absent(),
              }) => FinLancamentoPagarsCompanion(
                id: id,
                imagemDocumento: imagemDocumento,
                idFornecedor: idFornecedor,
                idBancoContaCaixa: idBancoContaCaixa,
                idFinDocumentoOrigem: idFinDocumentoOrigem,
                idFinNaturezaFinanceira: idFinNaturezaFinanceira,
                quantidadeParcela: quantidadeParcela,
                valorAPagar: valorAPagar,
                dataLancamento: dataLancamento,
                numeroDocumento: numeroDocumento,
                primeiroVencimento: primeiroVencimento,
                intervaloEntreParcelas: intervaloEntreParcelas,
                diaFixo: diaFixo,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> imagemDocumento = const Value.absent(),
                Value<int?> idFornecedor = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<int?> idFinDocumentoOrigem = const Value.absent(),
                Value<int?> idFinNaturezaFinanceira = const Value.absent(),
                Value<int?> quantidadeParcela = const Value.absent(),
                Value<double?> valorAPagar = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<DateTime?> primeiroVencimento = const Value.absent(),
                Value<int?> intervaloEntreParcelas = const Value.absent(),
                Value<String?> diaFixo = const Value.absent(),
              }) => FinLancamentoPagarsCompanion.insert(
                id: id,
                imagemDocumento: imagemDocumento,
                idFornecedor: idFornecedor,
                idBancoContaCaixa: idBancoContaCaixa,
                idFinDocumentoOrigem: idFinDocumentoOrigem,
                idFinNaturezaFinanceira: idFinNaturezaFinanceira,
                quantidadeParcela: quantidadeParcela,
                valorAPagar: valorAPagar,
                dataLancamento: dataLancamento,
                numeroDocumento: numeroDocumento,
                primeiroVencimento: primeiroVencimento,
                intervaloEntreParcelas: intervaloEntreParcelas,
                diaFixo: diaFixo,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinLancamentoPagarsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinLancamentoPagarsTable,
      FinLancamentoPagar,
      $$FinLancamentoPagarsTableFilterComposer,
      $$FinLancamentoPagarsTableOrderingComposer,
      $$FinLancamentoPagarsTableAnnotationComposer,
      $$FinLancamentoPagarsTableCreateCompanionBuilder,
      $$FinLancamentoPagarsTableUpdateCompanionBuilder,
      (
        FinLancamentoPagar,
        BaseReferences<
          _$AppDatabase,
          $FinLancamentoPagarsTable,
          FinLancamentoPagar
        >,
      ),
      FinLancamentoPagar,
      PrefetchHooks Function()
    >;
typedef $$FinLancamentoRecebersTableCreateCompanionBuilder =
    FinLancamentoRecebersCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idBancoContaCaixa,
      Value<int?> idFinDocumentoOrigem,
      Value<int?> idFinNaturezaFinanceira,
      Value<int?> quantidadeParcela,
      Value<double?> valorAReceber,
      Value<DateTime?> dataLancamento,
      Value<String?> numeroDocumento,
      Value<DateTime?> primeiroVencimento,
      Value<double?> taxaComissao,
      Value<double?> valorComissao,
      Value<int?> intervaloEntreParcelas,
      Value<String?> diaFixo,
    });
typedef $$FinLancamentoRecebersTableUpdateCompanionBuilder =
    FinLancamentoRecebersCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idBancoContaCaixa,
      Value<int?> idFinDocumentoOrigem,
      Value<int?> idFinNaturezaFinanceira,
      Value<int?> quantidadeParcela,
      Value<double?> valorAReceber,
      Value<DateTime?> dataLancamento,
      Value<String?> numeroDocumento,
      Value<DateTime?> primeiroVencimento,
      Value<double?> taxaComissao,
      Value<double?> valorComissao,
      Value<int?> intervaloEntreParcelas,
      Value<String?> diaFixo,
    });

class $$FinLancamentoRecebersTableFilterComposer
    extends Composer<_$AppDatabase, $FinLancamentoRecebersTable> {
  $$FinLancamentoRecebersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorAReceber => $composableBuilder(
    column: $table.valorAReceber,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaComissao => $composableBuilder(
    column: $table.taxaComissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorComissao => $composableBuilder(
    column: $table.valorComissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get diaFixo => $composableBuilder(
    column: $table.diaFixo,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinLancamentoRecebersTableOrderingComposer
    extends Composer<_$AppDatabase, $FinLancamentoRecebersTable> {
  $$FinLancamentoRecebersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorAReceber => $composableBuilder(
    column: $table.valorAReceber,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaComissao => $composableBuilder(
    column: $table.taxaComissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorComissao => $composableBuilder(
    column: $table.valorComissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get diaFixo => $composableBuilder(
    column: $table.diaFixo,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinLancamentoRecebersTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinLancamentoRecebersTable> {
  $$FinLancamentoRecebersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinDocumentoOrigem => $composableBuilder(
    column: $table.idFinDocumentoOrigem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFinNaturezaFinanceira => $composableBuilder(
    column: $table.idFinNaturezaFinanceira,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeParcela => $composableBuilder(
    column: $table.quantidadeParcela,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorAReceber => $composableBuilder(
    column: $table.valorAReceber,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get primeiroVencimento => $composableBuilder(
    column: $table.primeiroVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaComissao => $composableBuilder(
    column: $table.taxaComissao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorComissao => $composableBuilder(
    column: $table.valorComissao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get intervaloEntreParcelas => $composableBuilder(
    column: $table.intervaloEntreParcelas,
    builder: (column) => column,
  );

  GeneratedColumn<String> get diaFixo =>
      $composableBuilder(column: $table.diaFixo, builder: (column) => column);
}

class $$FinLancamentoRecebersTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinLancamentoRecebersTable,
          FinLancamentoReceber,
          $$FinLancamentoRecebersTableFilterComposer,
          $$FinLancamentoRecebersTableOrderingComposer,
          $$FinLancamentoRecebersTableAnnotationComposer,
          $$FinLancamentoRecebersTableCreateCompanionBuilder,
          $$FinLancamentoRecebersTableUpdateCompanionBuilder,
          (
            FinLancamentoReceber,
            BaseReferences<
              _$AppDatabase,
              $FinLancamentoRecebersTable,
              FinLancamentoReceber
            >,
          ),
          FinLancamentoReceber,
          PrefetchHooks Function()
        > {
  $$FinLancamentoRecebersTableTableManager(
    _$AppDatabase db,
    $FinLancamentoRecebersTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinLancamentoRecebersTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinLancamentoRecebersTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinLancamentoRecebersTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<int?> idFinDocumentoOrigem = const Value.absent(),
                Value<int?> idFinNaturezaFinanceira = const Value.absent(),
                Value<int?> quantidadeParcela = const Value.absent(),
                Value<double?> valorAReceber = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<DateTime?> primeiroVencimento = const Value.absent(),
                Value<double?> taxaComissao = const Value.absent(),
                Value<double?> valorComissao = const Value.absent(),
                Value<int?> intervaloEntreParcelas = const Value.absent(),
                Value<String?> diaFixo = const Value.absent(),
              }) => FinLancamentoRecebersCompanion(
                id: id,
                idCliente: idCliente,
                idBancoContaCaixa: idBancoContaCaixa,
                idFinDocumentoOrigem: idFinDocumentoOrigem,
                idFinNaturezaFinanceira: idFinNaturezaFinanceira,
                quantidadeParcela: quantidadeParcela,
                valorAReceber: valorAReceber,
                dataLancamento: dataLancamento,
                numeroDocumento: numeroDocumento,
                primeiroVencimento: primeiroVencimento,
                taxaComissao: taxaComissao,
                valorComissao: valorComissao,
                intervaloEntreParcelas: intervaloEntreParcelas,
                diaFixo: diaFixo,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<int?> idFinDocumentoOrigem = const Value.absent(),
                Value<int?> idFinNaturezaFinanceira = const Value.absent(),
                Value<int?> quantidadeParcela = const Value.absent(),
                Value<double?> valorAReceber = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<DateTime?> primeiroVencimento = const Value.absent(),
                Value<double?> taxaComissao = const Value.absent(),
                Value<double?> valorComissao = const Value.absent(),
                Value<int?> intervaloEntreParcelas = const Value.absent(),
                Value<String?> diaFixo = const Value.absent(),
              }) => FinLancamentoRecebersCompanion.insert(
                id: id,
                idCliente: idCliente,
                idBancoContaCaixa: idBancoContaCaixa,
                idFinDocumentoOrigem: idFinDocumentoOrigem,
                idFinNaturezaFinanceira: idFinNaturezaFinanceira,
                quantidadeParcela: quantidadeParcela,
                valorAReceber: valorAReceber,
                dataLancamento: dataLancamento,
                numeroDocumento: numeroDocumento,
                primeiroVencimento: primeiroVencimento,
                taxaComissao: taxaComissao,
                valorComissao: valorComissao,
                intervaloEntreParcelas: intervaloEntreParcelas,
                diaFixo: diaFixo,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinLancamentoRecebersTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinLancamentoRecebersTable,
      FinLancamentoReceber,
      $$FinLancamentoRecebersTableFilterComposer,
      $$FinLancamentoRecebersTableOrderingComposer,
      $$FinLancamentoRecebersTableAnnotationComposer,
      $$FinLancamentoRecebersTableCreateCompanionBuilder,
      $$FinLancamentoRecebersTableUpdateCompanionBuilder,
      (
        FinLancamentoReceber,
        BaseReferences<
          _$AppDatabase,
          $FinLancamentoRecebersTable,
          FinLancamentoReceber
        >,
      ),
      FinLancamentoReceber,
      PrefetchHooks Function()
    >;
typedef $$BancosTableCreateCompanionBuilder =
    BancosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> nome,
      Value<String?> url,
    });
typedef $$BancosTableUpdateCompanionBuilder =
    BancosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> nome,
      Value<String?> url,
    });

class $$BancosTableFilterComposer
    extends Composer<_$AppDatabase, $BancosTable> {
  $$BancosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get url => $composableBuilder(
    column: $table.url,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BancosTableOrderingComposer
    extends Composer<_$AppDatabase, $BancosTable> {
  $$BancosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get url => $composableBuilder(
    column: $table.url,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BancosTableAnnotationComposer
    extends Composer<_$AppDatabase, $BancosTable> {
  $$BancosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get url =>
      $composableBuilder(column: $table.url, builder: (column) => column);
}

class $$BancosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BancosTable,
          Banco,
          $$BancosTableFilterComposer,
          $$BancosTableOrderingComposer,
          $$BancosTableAnnotationComposer,
          $$BancosTableCreateCompanionBuilder,
          $$BancosTableUpdateCompanionBuilder,
          (Banco, BaseReferences<_$AppDatabase, $BancosTable, Banco>),
          Banco,
          PrefetchHooks Function()
        > {
  $$BancosTableTableManager(_$AppDatabase db, $BancosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BancosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BancosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BancosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> url = const Value.absent(),
              }) =>
                  BancosCompanion(id: id, codigo: codigo, nome: nome, url: url),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> url = const Value.absent(),
              }) => BancosCompanion.insert(
                id: id,
                codigo: codigo,
                nome: nome,
                url: url,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BancosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BancosTable,
      Banco,
      $$BancosTableFilterComposer,
      $$BancosTableOrderingComposer,
      $$BancosTableAnnotationComposer,
      $$BancosTableCreateCompanionBuilder,
      $$BancosTableUpdateCompanionBuilder,
      (Banco, BaseReferences<_$AppDatabase, $BancosTable, Banco>),
      Banco,
      PrefetchHooks Function()
    >;
typedef $$BancoAgenciasTableCreateCompanionBuilder =
    BancoAgenciasCompanion Function({
      Value<int?> id,
      Value<int?> idBanco,
      Value<String?> numero,
      Value<String?> digito,
      Value<String?> nome,
      Value<String?> telefone,
      Value<String?> contato,
      Value<String?> gerente,
      Value<String?> observacao,
    });
typedef $$BancoAgenciasTableUpdateCompanionBuilder =
    BancoAgenciasCompanion Function({
      Value<int?> id,
      Value<int?> idBanco,
      Value<String?> numero,
      Value<String?> digito,
      Value<String?> nome,
      Value<String?> telefone,
      Value<String?> contato,
      Value<String?> gerente,
      Value<String?> observacao,
    });

class $$BancoAgenciasTableFilterComposer
    extends Composer<_$AppDatabase, $BancoAgenciasTable> {
  $$BancoAgenciasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBanco => $composableBuilder(
    column: $table.idBanco,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get digito => $composableBuilder(
    column: $table.digito,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get contato => $composableBuilder(
    column: $table.contato,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get gerente => $composableBuilder(
    column: $table.gerente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BancoAgenciasTableOrderingComposer
    extends Composer<_$AppDatabase, $BancoAgenciasTable> {
  $$BancoAgenciasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBanco => $composableBuilder(
    column: $table.idBanco,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get digito => $composableBuilder(
    column: $table.digito,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get contato => $composableBuilder(
    column: $table.contato,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get gerente => $composableBuilder(
    column: $table.gerente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BancoAgenciasTableAnnotationComposer
    extends Composer<_$AppDatabase, $BancoAgenciasTable> {
  $$BancoAgenciasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBanco =>
      $composableBuilder(column: $table.idBanco, builder: (column) => column);

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get digito =>
      $composableBuilder(column: $table.digito, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get telefone =>
      $composableBuilder(column: $table.telefone, builder: (column) => column);

  GeneratedColumn<String> get contato =>
      $composableBuilder(column: $table.contato, builder: (column) => column);

  GeneratedColumn<String> get gerente =>
      $composableBuilder(column: $table.gerente, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );
}

class $$BancoAgenciasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BancoAgenciasTable,
          BancoAgencia,
          $$BancoAgenciasTableFilterComposer,
          $$BancoAgenciasTableOrderingComposer,
          $$BancoAgenciasTableAnnotationComposer,
          $$BancoAgenciasTableCreateCompanionBuilder,
          $$BancoAgenciasTableUpdateCompanionBuilder,
          (
            BancoAgencia,
            BaseReferences<_$AppDatabase, $BancoAgenciasTable, BancoAgencia>,
          ),
          BancoAgencia,
          PrefetchHooks Function()
        > {
  $$BancoAgenciasTableTableManager(_$AppDatabase db, $BancoAgenciasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BancoAgenciasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$BancoAgenciasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BancoAgenciasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBanco = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> digito = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> contato = const Value.absent(),
                Value<String?> gerente = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => BancoAgenciasCompanion(
                id: id,
                idBanco: idBanco,
                numero: numero,
                digito: digito,
                nome: nome,
                telefone: telefone,
                contato: contato,
                gerente: gerente,
                observacao: observacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBanco = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> digito = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> contato = const Value.absent(),
                Value<String?> gerente = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => BancoAgenciasCompanion.insert(
                id: id,
                idBanco: idBanco,
                numero: numero,
                digito: digito,
                nome: nome,
                telefone: telefone,
                contato: contato,
                gerente: gerente,
                observacao: observacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BancoAgenciasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BancoAgenciasTable,
      BancoAgencia,
      $$BancoAgenciasTableFilterComposer,
      $$BancoAgenciasTableOrderingComposer,
      $$BancoAgenciasTableAnnotationComposer,
      $$BancoAgenciasTableCreateCompanionBuilder,
      $$BancoAgenciasTableUpdateCompanionBuilder,
      (
        BancoAgencia,
        BaseReferences<_$AppDatabase, $BancoAgenciasTable, BancoAgencia>,
      ),
      BancoAgencia,
      PrefetchHooks Function()
    >;
typedef $$BancoContaCaixasTableCreateCompanionBuilder =
    BancoContaCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idBancoAgencia,
      Value<String?> numero,
      Value<String?> digito,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> descricao,
    });
typedef $$BancoContaCaixasTableUpdateCompanionBuilder =
    BancoContaCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idBancoAgencia,
      Value<String?> numero,
      Value<String?> digito,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> descricao,
    });

class $$BancoContaCaixasTableFilterComposer
    extends Composer<_$AppDatabase, $BancoContaCaixasTable> {
  $$BancoContaCaixasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoAgencia => $composableBuilder(
    column: $table.idBancoAgencia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get digito => $composableBuilder(
    column: $table.digito,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BancoContaCaixasTableOrderingComposer
    extends Composer<_$AppDatabase, $BancoContaCaixasTable> {
  $$BancoContaCaixasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoAgencia => $composableBuilder(
    column: $table.idBancoAgencia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get digito => $composableBuilder(
    column: $table.digito,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BancoContaCaixasTableAnnotationComposer
    extends Composer<_$AppDatabase, $BancoContaCaixasTable> {
  $$BancoContaCaixasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoAgencia => $composableBuilder(
    column: $table.idBancoAgencia,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get digito =>
      $composableBuilder(column: $table.digito, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$BancoContaCaixasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BancoContaCaixasTable,
          BancoContaCaixa,
          $$BancoContaCaixasTableFilterComposer,
          $$BancoContaCaixasTableOrderingComposer,
          $$BancoContaCaixasTableAnnotationComposer,
          $$BancoContaCaixasTableCreateCompanionBuilder,
          $$BancoContaCaixasTableUpdateCompanionBuilder,
          (
            BancoContaCaixa,
            BaseReferences<
              _$AppDatabase,
              $BancoContaCaixasTable,
              BancoContaCaixa
            >,
          ),
          BancoContaCaixa,
          PrefetchHooks Function()
        > {
  $$BancoContaCaixasTableTableManager(
    _$AppDatabase db,
    $BancoContaCaixasTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$BancoContaCaixasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BancoContaCaixasTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$BancoContaCaixasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoAgencia = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> digito = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => BancoContaCaixasCompanion(
                id: id,
                idBancoAgencia: idBancoAgencia,
                numero: numero,
                digito: digito,
                nome: nome,
                tipo: tipo,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoAgencia = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> digito = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => BancoContaCaixasCompanion.insert(
                id: id,
                idBancoAgencia: idBancoAgencia,
                numero: numero,
                digito: digito,
                nome: nome,
                tipo: tipo,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BancoContaCaixasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BancoContaCaixasTable,
      BancoContaCaixa,
      $$BancoContaCaixasTableFilterComposer,
      $$BancoContaCaixasTableOrderingComposer,
      $$BancoContaCaixasTableAnnotationComposer,
      $$BancoContaCaixasTableCreateCompanionBuilder,
      $$BancoContaCaixasTableUpdateCompanionBuilder,
      (
        BancoContaCaixa,
        BaseReferences<_$AppDatabase, $BancoContaCaixasTable, BancoContaCaixa>,
      ),
      BancoContaCaixa,
      PrefetchHooks Function()
    >;
typedef $$FinFechamentoCaixaBancosTableCreateCompanionBuilder =
    FinFechamentoCaixaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<DateTime?> dataFechamento,
      Value<String?> mesAno,
      Value<String?> mes,
      Value<String?> ano,
      Value<double?> saldoAnterior,
      Value<double?> recebimentos,
      Value<double?> pagamentos,
      Value<double?> saldoConta,
      Value<double?> chequeNaoCompensado,
      Value<double?> saldoDisponivel,
    });
typedef $$FinFechamentoCaixaBancosTableUpdateCompanionBuilder =
    FinFechamentoCaixaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<DateTime?> dataFechamento,
      Value<String?> mesAno,
      Value<String?> mes,
      Value<String?> ano,
      Value<double?> saldoAnterior,
      Value<double?> recebimentos,
      Value<double?> pagamentos,
      Value<double?> saldoConta,
      Value<double?> chequeNaoCompensado,
      Value<double?> saldoDisponivel,
    });

class $$FinFechamentoCaixaBancosTableFilterComposer
    extends Composer<_$AppDatabase, $FinFechamentoCaixaBancosTable> {
  $$FinFechamentoCaixaBancosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataFechamento => $composableBuilder(
    column: $table.dataFechamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get saldoAnterior => $composableBuilder(
    column: $table.saldoAnterior,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get recebimentos => $composableBuilder(
    column: $table.recebimentos,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get pagamentos => $composableBuilder(
    column: $table.pagamentos,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get saldoConta => $composableBuilder(
    column: $table.saldoConta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get chequeNaoCompensado => $composableBuilder(
    column: $table.chequeNaoCompensado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get saldoDisponivel => $composableBuilder(
    column: $table.saldoDisponivel,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinFechamentoCaixaBancosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinFechamentoCaixaBancosTable> {
  $$FinFechamentoCaixaBancosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataFechamento => $composableBuilder(
    column: $table.dataFechamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get saldoAnterior => $composableBuilder(
    column: $table.saldoAnterior,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get recebimentos => $composableBuilder(
    column: $table.recebimentos,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get pagamentos => $composableBuilder(
    column: $table.pagamentos,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get saldoConta => $composableBuilder(
    column: $table.saldoConta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get chequeNaoCompensado => $composableBuilder(
    column: $table.chequeNaoCompensado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get saldoDisponivel => $composableBuilder(
    column: $table.saldoDisponivel,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinFechamentoCaixaBancosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinFechamentoCaixaBancosTable> {
  $$FinFechamentoCaixaBancosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataFechamento => $composableBuilder(
    column: $table.dataFechamento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get mesAno =>
      $composableBuilder(column: $table.mesAno, builder: (column) => column);

  GeneratedColumn<String> get mes =>
      $composableBuilder(column: $table.mes, builder: (column) => column);

  GeneratedColumn<String> get ano =>
      $composableBuilder(column: $table.ano, builder: (column) => column);

  GeneratedColumn<double> get saldoAnterior => $composableBuilder(
    column: $table.saldoAnterior,
    builder: (column) => column,
  );

  GeneratedColumn<double> get recebimentos => $composableBuilder(
    column: $table.recebimentos,
    builder: (column) => column,
  );

  GeneratedColumn<double> get pagamentos => $composableBuilder(
    column: $table.pagamentos,
    builder: (column) => column,
  );

  GeneratedColumn<double> get saldoConta => $composableBuilder(
    column: $table.saldoConta,
    builder: (column) => column,
  );

  GeneratedColumn<double> get chequeNaoCompensado => $composableBuilder(
    column: $table.chequeNaoCompensado,
    builder: (column) => column,
  );

  GeneratedColumn<double> get saldoDisponivel => $composableBuilder(
    column: $table.saldoDisponivel,
    builder: (column) => column,
  );
}

class $$FinFechamentoCaixaBancosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinFechamentoCaixaBancosTable,
          FinFechamentoCaixaBanco,
          $$FinFechamentoCaixaBancosTableFilterComposer,
          $$FinFechamentoCaixaBancosTableOrderingComposer,
          $$FinFechamentoCaixaBancosTableAnnotationComposer,
          $$FinFechamentoCaixaBancosTableCreateCompanionBuilder,
          $$FinFechamentoCaixaBancosTableUpdateCompanionBuilder,
          (
            FinFechamentoCaixaBanco,
            BaseReferences<
              _$AppDatabase,
              $FinFechamentoCaixaBancosTable,
              FinFechamentoCaixaBanco
            >,
          ),
          FinFechamentoCaixaBanco,
          PrefetchHooks Function()
        > {
  $$FinFechamentoCaixaBancosTableTableManager(
    _$AppDatabase db,
    $FinFechamentoCaixaBancosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinFechamentoCaixaBancosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinFechamentoCaixaBancosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinFechamentoCaixaBancosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<DateTime?> dataFechamento = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> mes = const Value.absent(),
                Value<String?> ano = const Value.absent(),
                Value<double?> saldoAnterior = const Value.absent(),
                Value<double?> recebimentos = const Value.absent(),
                Value<double?> pagamentos = const Value.absent(),
                Value<double?> saldoConta = const Value.absent(),
                Value<double?> chequeNaoCompensado = const Value.absent(),
                Value<double?> saldoDisponivel = const Value.absent(),
              }) => FinFechamentoCaixaBancosCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                dataFechamento: dataFechamento,
                mesAno: mesAno,
                mes: mes,
                ano: ano,
                saldoAnterior: saldoAnterior,
                recebimentos: recebimentos,
                pagamentos: pagamentos,
                saldoConta: saldoConta,
                chequeNaoCompensado: chequeNaoCompensado,
                saldoDisponivel: saldoDisponivel,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<DateTime?> dataFechamento = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> mes = const Value.absent(),
                Value<String?> ano = const Value.absent(),
                Value<double?> saldoAnterior = const Value.absent(),
                Value<double?> recebimentos = const Value.absent(),
                Value<double?> pagamentos = const Value.absent(),
                Value<double?> saldoConta = const Value.absent(),
                Value<double?> chequeNaoCompensado = const Value.absent(),
                Value<double?> saldoDisponivel = const Value.absent(),
              }) => FinFechamentoCaixaBancosCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                dataFechamento: dataFechamento,
                mesAno: mesAno,
                mes: mes,
                ano: ano,
                saldoAnterior: saldoAnterior,
                recebimentos: recebimentos,
                pagamentos: pagamentos,
                saldoConta: saldoConta,
                chequeNaoCompensado: chequeNaoCompensado,
                saldoDisponivel: saldoDisponivel,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinFechamentoCaixaBancosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinFechamentoCaixaBancosTable,
      FinFechamentoCaixaBanco,
      $$FinFechamentoCaixaBancosTableFilterComposer,
      $$FinFechamentoCaixaBancosTableOrderingComposer,
      $$FinFechamentoCaixaBancosTableAnnotationComposer,
      $$FinFechamentoCaixaBancosTableCreateCompanionBuilder,
      $$FinFechamentoCaixaBancosTableUpdateCompanionBuilder,
      (
        FinFechamentoCaixaBanco,
        BaseReferences<
          _$AppDatabase,
          $FinFechamentoCaixaBancosTable,
          FinFechamentoCaixaBanco
        >,
      ),
      FinFechamentoCaixaBanco,
      PrefetchHooks Function()
    >;
typedef $$FinExtratoContaBancosTableCreateCompanionBuilder =
    FinExtratoContaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> mesAno,
      Value<String?> mes,
      Value<String?> ano,
      Value<DateTime?> dataMovimento,
      Value<DateTime?> dataBalancete,
      Value<String?> historico,
      Value<String?> documento,
      Value<double?> valor,
      Value<String?> conciliado,
      Value<String?> observacao,
    });
typedef $$FinExtratoContaBancosTableUpdateCompanionBuilder =
    FinExtratoContaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> mesAno,
      Value<String?> mes,
      Value<String?> ano,
      Value<DateTime?> dataMovimento,
      Value<DateTime?> dataBalancete,
      Value<String?> historico,
      Value<String?> documento,
      Value<double?> valor,
      Value<String?> conciliado,
      Value<String?> observacao,
    });

class $$FinExtratoContaBancosTableFilterComposer
    extends Composer<_$AppDatabase, $FinExtratoContaBancosTable> {
  $$FinExtratoContaBancosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataMovimento => $composableBuilder(
    column: $table.dataMovimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataBalancete => $composableBuilder(
    column: $table.dataBalancete,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get documento => $composableBuilder(
    column: $table.documento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get conciliado => $composableBuilder(
    column: $table.conciliado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinExtratoContaBancosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinExtratoContaBancosTable> {
  $$FinExtratoContaBancosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataMovimento => $composableBuilder(
    column: $table.dataMovimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataBalancete => $composableBuilder(
    column: $table.dataBalancete,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get documento => $composableBuilder(
    column: $table.documento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get conciliado => $composableBuilder(
    column: $table.conciliado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinExtratoContaBancosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinExtratoContaBancosTable> {
  $$FinExtratoContaBancosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get mesAno =>
      $composableBuilder(column: $table.mesAno, builder: (column) => column);

  GeneratedColumn<String> get mes =>
      $composableBuilder(column: $table.mes, builder: (column) => column);

  GeneratedColumn<String> get ano =>
      $composableBuilder(column: $table.ano, builder: (column) => column);

  GeneratedColumn<DateTime> get dataMovimento => $composableBuilder(
    column: $table.dataMovimento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataBalancete => $composableBuilder(
    column: $table.dataBalancete,
    builder: (column) => column,
  );

  GeneratedColumn<String> get historico =>
      $composableBuilder(column: $table.historico, builder: (column) => column);

  GeneratedColumn<String> get documento =>
      $composableBuilder(column: $table.documento, builder: (column) => column);

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<String> get conciliado => $composableBuilder(
    column: $table.conciliado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );
}

class $$FinExtratoContaBancosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinExtratoContaBancosTable,
          FinExtratoContaBanco,
          $$FinExtratoContaBancosTableFilterComposer,
          $$FinExtratoContaBancosTableOrderingComposer,
          $$FinExtratoContaBancosTableAnnotationComposer,
          $$FinExtratoContaBancosTableCreateCompanionBuilder,
          $$FinExtratoContaBancosTableUpdateCompanionBuilder,
          (
            FinExtratoContaBanco,
            BaseReferences<
              _$AppDatabase,
              $FinExtratoContaBancosTable,
              FinExtratoContaBanco
            >,
          ),
          FinExtratoContaBanco,
          PrefetchHooks Function()
        > {
  $$FinExtratoContaBancosTableTableManager(
    _$AppDatabase db,
    $FinExtratoContaBancosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinExtratoContaBancosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinExtratoContaBancosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinExtratoContaBancosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> mes = const Value.absent(),
                Value<String?> ano = const Value.absent(),
                Value<DateTime?> dataMovimento = const Value.absent(),
                Value<DateTime?> dataBalancete = const Value.absent(),
                Value<String?> historico = const Value.absent(),
                Value<String?> documento = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> conciliado = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => FinExtratoContaBancosCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                mesAno: mesAno,
                mes: mes,
                ano: ano,
                dataMovimento: dataMovimento,
                dataBalancete: dataBalancete,
                historico: historico,
                documento: documento,
                valor: valor,
                conciliado: conciliado,
                observacao: observacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> mes = const Value.absent(),
                Value<String?> ano = const Value.absent(),
                Value<DateTime?> dataMovimento = const Value.absent(),
                Value<DateTime?> dataBalancete = const Value.absent(),
                Value<String?> historico = const Value.absent(),
                Value<String?> documento = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> conciliado = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => FinExtratoContaBancosCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                mesAno: mesAno,
                mes: mes,
                ano: ano,
                dataMovimento: dataMovimento,
                dataBalancete: dataBalancete,
                historico: historico,
                documento: documento,
                valor: valor,
                conciliado: conciliado,
                observacao: observacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinExtratoContaBancosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinExtratoContaBancosTable,
      FinExtratoContaBanco,
      $$FinExtratoContaBancosTableFilterComposer,
      $$FinExtratoContaBancosTableOrderingComposer,
      $$FinExtratoContaBancosTableAnnotationComposer,
      $$FinExtratoContaBancosTableCreateCompanionBuilder,
      $$FinExtratoContaBancosTableUpdateCompanionBuilder,
      (
        FinExtratoContaBanco,
        BaseReferences<
          _$AppDatabase,
          $FinExtratoContaBancosTable,
          FinExtratoContaBanco
        >,
      ),
      FinExtratoContaBanco,
      PrefetchHooks Function()
    >;
typedef $$FinDocumentoOrigemsTableCreateCompanionBuilder =
    FinDocumentoOrigemsCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> sigla,
      Value<String?> descricao,
    });
typedef $$FinDocumentoOrigemsTableUpdateCompanionBuilder =
    FinDocumentoOrigemsCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> sigla,
      Value<String?> descricao,
    });

class $$FinDocumentoOrigemsTableFilterComposer
    extends Composer<_$AppDatabase, $FinDocumentoOrigemsTable> {
  $$FinDocumentoOrigemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get sigla => $composableBuilder(
    column: $table.sigla,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinDocumentoOrigemsTableOrderingComposer
    extends Composer<_$AppDatabase, $FinDocumentoOrigemsTable> {
  $$FinDocumentoOrigemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get sigla => $composableBuilder(
    column: $table.sigla,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinDocumentoOrigemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinDocumentoOrigemsTable> {
  $$FinDocumentoOrigemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get sigla =>
      $composableBuilder(column: $table.sigla, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$FinDocumentoOrigemsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinDocumentoOrigemsTable,
          FinDocumentoOrigem,
          $$FinDocumentoOrigemsTableFilterComposer,
          $$FinDocumentoOrigemsTableOrderingComposer,
          $$FinDocumentoOrigemsTableAnnotationComposer,
          $$FinDocumentoOrigemsTableCreateCompanionBuilder,
          $$FinDocumentoOrigemsTableUpdateCompanionBuilder,
          (
            FinDocumentoOrigem,
            BaseReferences<
              _$AppDatabase,
              $FinDocumentoOrigemsTable,
              FinDocumentoOrigem
            >,
          ),
          FinDocumentoOrigem,
          PrefetchHooks Function()
        > {
  $$FinDocumentoOrigemsTableTableManager(
    _$AppDatabase db,
    $FinDocumentoOrigemsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinDocumentoOrigemsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinDocumentoOrigemsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinDocumentoOrigemsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> sigla = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinDocumentoOrigemsCompanion(
                id: id,
                codigo: codigo,
                sigla: sigla,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> sigla = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinDocumentoOrigemsCompanion.insert(
                id: id,
                codigo: codigo,
                sigla: sigla,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinDocumentoOrigemsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinDocumentoOrigemsTable,
      FinDocumentoOrigem,
      $$FinDocumentoOrigemsTableFilterComposer,
      $$FinDocumentoOrigemsTableOrderingComposer,
      $$FinDocumentoOrigemsTableAnnotationComposer,
      $$FinDocumentoOrigemsTableCreateCompanionBuilder,
      $$FinDocumentoOrigemsTableUpdateCompanionBuilder,
      (
        FinDocumentoOrigem,
        BaseReferences<
          _$AppDatabase,
          $FinDocumentoOrigemsTable,
          FinDocumentoOrigem
        >,
      ),
      FinDocumentoOrigem,
      PrefetchHooks Function()
    >;
typedef $$FinNaturezaFinanceirasTableCreateCompanionBuilder =
    FinNaturezaFinanceirasCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> tipo,
      Value<String?> descricao,
      Value<String?> aplicacao,
    });
typedef $$FinNaturezaFinanceirasTableUpdateCompanionBuilder =
    FinNaturezaFinanceirasCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> tipo,
      Value<String?> descricao,
      Value<String?> aplicacao,
    });

class $$FinNaturezaFinanceirasTableFilterComposer
    extends Composer<_$AppDatabase, $FinNaturezaFinanceirasTable> {
  $$FinNaturezaFinanceirasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get aplicacao => $composableBuilder(
    column: $table.aplicacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinNaturezaFinanceirasTableOrderingComposer
    extends Composer<_$AppDatabase, $FinNaturezaFinanceirasTable> {
  $$FinNaturezaFinanceirasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get aplicacao => $composableBuilder(
    column: $table.aplicacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinNaturezaFinanceirasTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinNaturezaFinanceirasTable> {
  $$FinNaturezaFinanceirasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get aplicacao =>
      $composableBuilder(column: $table.aplicacao, builder: (column) => column);
}

class $$FinNaturezaFinanceirasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinNaturezaFinanceirasTable,
          FinNaturezaFinanceira,
          $$FinNaturezaFinanceirasTableFilterComposer,
          $$FinNaturezaFinanceirasTableOrderingComposer,
          $$FinNaturezaFinanceirasTableAnnotationComposer,
          $$FinNaturezaFinanceirasTableCreateCompanionBuilder,
          $$FinNaturezaFinanceirasTableUpdateCompanionBuilder,
          (
            FinNaturezaFinanceira,
            BaseReferences<
              _$AppDatabase,
              $FinNaturezaFinanceirasTable,
              FinNaturezaFinanceira
            >,
          ),
          FinNaturezaFinanceira,
          PrefetchHooks Function()
        > {
  $$FinNaturezaFinanceirasTableTableManager(
    _$AppDatabase db,
    $FinNaturezaFinanceirasTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinNaturezaFinanceirasTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinNaturezaFinanceirasTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinNaturezaFinanceirasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> aplicacao = const Value.absent(),
              }) => FinNaturezaFinanceirasCompanion(
                id: id,
                codigo: codigo,
                tipo: tipo,
                descricao: descricao,
                aplicacao: aplicacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> aplicacao = const Value.absent(),
              }) => FinNaturezaFinanceirasCompanion.insert(
                id: id,
                codigo: codigo,
                tipo: tipo,
                descricao: descricao,
                aplicacao: aplicacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinNaturezaFinanceirasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinNaturezaFinanceirasTable,
      FinNaturezaFinanceira,
      $$FinNaturezaFinanceirasTableFilterComposer,
      $$FinNaturezaFinanceirasTableOrderingComposer,
      $$FinNaturezaFinanceirasTableAnnotationComposer,
      $$FinNaturezaFinanceirasTableCreateCompanionBuilder,
      $$FinNaturezaFinanceirasTableUpdateCompanionBuilder,
      (
        FinNaturezaFinanceira,
        BaseReferences<
          _$AppDatabase,
          $FinNaturezaFinanceirasTable,
          FinNaturezaFinanceira
        >,
      ),
      FinNaturezaFinanceira,
      PrefetchHooks Function()
    >;
typedef $$FinStatusParcelasTableCreateCompanionBuilder =
    FinStatusParcelasCompanion Function({
      Value<int?> id,
      Value<String?> situacao,
      Value<String?> descricao,
      Value<String?> procedimento,
    });
typedef $$FinStatusParcelasTableUpdateCompanionBuilder =
    FinStatusParcelasCompanion Function({
      Value<int?> id,
      Value<String?> situacao,
      Value<String?> descricao,
      Value<String?> procedimento,
    });

class $$FinStatusParcelasTableFilterComposer
    extends Composer<_$AppDatabase, $FinStatusParcelasTable> {
  $$FinStatusParcelasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get situacao => $composableBuilder(
    column: $table.situacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get procedimento => $composableBuilder(
    column: $table.procedimento,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinStatusParcelasTableOrderingComposer
    extends Composer<_$AppDatabase, $FinStatusParcelasTable> {
  $$FinStatusParcelasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get situacao => $composableBuilder(
    column: $table.situacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get procedimento => $composableBuilder(
    column: $table.procedimento,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinStatusParcelasTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinStatusParcelasTable> {
  $$FinStatusParcelasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get situacao =>
      $composableBuilder(column: $table.situacao, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get procedimento => $composableBuilder(
    column: $table.procedimento,
    builder: (column) => column,
  );
}

class $$FinStatusParcelasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinStatusParcelasTable,
          FinStatusParcela,
          $$FinStatusParcelasTableFilterComposer,
          $$FinStatusParcelasTableOrderingComposer,
          $$FinStatusParcelasTableAnnotationComposer,
          $$FinStatusParcelasTableCreateCompanionBuilder,
          $$FinStatusParcelasTableUpdateCompanionBuilder,
          (
            FinStatusParcela,
            BaseReferences<
              _$AppDatabase,
              $FinStatusParcelasTable,
              FinStatusParcela
            >,
          ),
          FinStatusParcela,
          PrefetchHooks Function()
        > {
  $$FinStatusParcelasTableTableManager(
    _$AppDatabase db,
    $FinStatusParcelasTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinStatusParcelasTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinStatusParcelasTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinStatusParcelasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> situacao = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> procedimento = const Value.absent(),
              }) => FinStatusParcelasCompanion(
                id: id,
                situacao: situacao,
                descricao: descricao,
                procedimento: procedimento,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> situacao = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> procedimento = const Value.absent(),
              }) => FinStatusParcelasCompanion.insert(
                id: id,
                situacao: situacao,
                descricao: descricao,
                procedimento: procedimento,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinStatusParcelasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinStatusParcelasTable,
      FinStatusParcela,
      $$FinStatusParcelasTableFilterComposer,
      $$FinStatusParcelasTableOrderingComposer,
      $$FinStatusParcelasTableAnnotationComposer,
      $$FinStatusParcelasTableCreateCompanionBuilder,
      $$FinStatusParcelasTableUpdateCompanionBuilder,
      (
        FinStatusParcela,
        BaseReferences<
          _$AppDatabase,
          $FinStatusParcelasTable,
          FinStatusParcela
        >,
      ),
      FinStatusParcela,
      PrefetchHooks Function()
    >;
typedef $$FinTipoPagamentosTableCreateCompanionBuilder =
    FinTipoPagamentosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });
typedef $$FinTipoPagamentosTableUpdateCompanionBuilder =
    FinTipoPagamentosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });

class $$FinTipoPagamentosTableFilterComposer
    extends Composer<_$AppDatabase, $FinTipoPagamentosTable> {
  $$FinTipoPagamentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinTipoPagamentosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinTipoPagamentosTable> {
  $$FinTipoPagamentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinTipoPagamentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinTipoPagamentosTable> {
  $$FinTipoPagamentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$FinTipoPagamentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinTipoPagamentosTable,
          FinTipoPagamento,
          $$FinTipoPagamentosTableFilterComposer,
          $$FinTipoPagamentosTableOrderingComposer,
          $$FinTipoPagamentosTableAnnotationComposer,
          $$FinTipoPagamentosTableCreateCompanionBuilder,
          $$FinTipoPagamentosTableUpdateCompanionBuilder,
          (
            FinTipoPagamento,
            BaseReferences<
              _$AppDatabase,
              $FinTipoPagamentosTable,
              FinTipoPagamento
            >,
          ),
          FinTipoPagamento,
          PrefetchHooks Function()
        > {
  $$FinTipoPagamentosTableTableManager(
    _$AppDatabase db,
    $FinTipoPagamentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinTipoPagamentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinTipoPagamentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinTipoPagamentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinTipoPagamentosCompanion(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinTipoPagamentosCompanion.insert(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinTipoPagamentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinTipoPagamentosTable,
      FinTipoPagamento,
      $$FinTipoPagamentosTableFilterComposer,
      $$FinTipoPagamentosTableOrderingComposer,
      $$FinTipoPagamentosTableAnnotationComposer,
      $$FinTipoPagamentosTableCreateCompanionBuilder,
      $$FinTipoPagamentosTableUpdateCompanionBuilder,
      (
        FinTipoPagamento,
        BaseReferences<
          _$AppDatabase,
          $FinTipoPagamentosTable,
          FinTipoPagamento
        >,
      ),
      FinTipoPagamento,
      PrefetchHooks Function()
    >;
typedef $$FinChequeEmitidosTableCreateCompanionBuilder =
    FinChequeEmitidosCompanion Function({
      Value<int?> id,
      Value<int?> idCheque,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> bomPara,
      Value<DateTime?> dataCompensacao,
      Value<double?> valor,
      Value<String?> nominalA,
    });
typedef $$FinChequeEmitidosTableUpdateCompanionBuilder =
    FinChequeEmitidosCompanion Function({
      Value<int?> id,
      Value<int?> idCheque,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> bomPara,
      Value<DateTime?> dataCompensacao,
      Value<double?> valor,
      Value<String?> nominalA,
    });

class $$FinChequeEmitidosTableFilterComposer
    extends Composer<_$AppDatabase, $FinChequeEmitidosTable> {
  $$FinChequeEmitidosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCheque => $composableBuilder(
    column: $table.idCheque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get bomPara => $composableBuilder(
    column: $table.bomPara,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nominalA => $composableBuilder(
    column: $table.nominalA,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinChequeEmitidosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinChequeEmitidosTable> {
  $$FinChequeEmitidosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCheque => $composableBuilder(
    column: $table.idCheque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get bomPara => $composableBuilder(
    column: $table.bomPara,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nominalA => $composableBuilder(
    column: $table.nominalA,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinChequeEmitidosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinChequeEmitidosTable> {
  $$FinChequeEmitidosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCheque =>
      $composableBuilder(column: $table.idCheque, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get bomPara =>
      $composableBuilder(column: $table.bomPara, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<String> get nominalA =>
      $composableBuilder(column: $table.nominalA, builder: (column) => column);
}

class $$FinChequeEmitidosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinChequeEmitidosTable,
          FinChequeEmitido,
          $$FinChequeEmitidosTableFilterComposer,
          $$FinChequeEmitidosTableOrderingComposer,
          $$FinChequeEmitidosTableAnnotationComposer,
          $$FinChequeEmitidosTableCreateCompanionBuilder,
          $$FinChequeEmitidosTableUpdateCompanionBuilder,
          (
            FinChequeEmitido,
            BaseReferences<
              _$AppDatabase,
              $FinChequeEmitidosTable,
              FinChequeEmitido
            >,
          ),
          FinChequeEmitido,
          PrefetchHooks Function()
        > {
  $$FinChequeEmitidosTableTableManager(
    _$AppDatabase db,
    $FinChequeEmitidosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinChequeEmitidosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinChequeEmitidosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinChequeEmitidosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCheque = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> bomPara = const Value.absent(),
                Value<DateTime?> dataCompensacao = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> nominalA = const Value.absent(),
              }) => FinChequeEmitidosCompanion(
                id: id,
                idCheque: idCheque,
                dataEmissao: dataEmissao,
                bomPara: bomPara,
                dataCompensacao: dataCompensacao,
                valor: valor,
                nominalA: nominalA,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCheque = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> bomPara = const Value.absent(),
                Value<DateTime?> dataCompensacao = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> nominalA = const Value.absent(),
              }) => FinChequeEmitidosCompanion.insert(
                id: id,
                idCheque: idCheque,
                dataEmissao: dataEmissao,
                bomPara: bomPara,
                dataCompensacao: dataCompensacao,
                valor: valor,
                nominalA: nominalA,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinChequeEmitidosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinChequeEmitidosTable,
      FinChequeEmitido,
      $$FinChequeEmitidosTableFilterComposer,
      $$FinChequeEmitidosTableOrderingComposer,
      $$FinChequeEmitidosTableAnnotationComposer,
      $$FinChequeEmitidosTableCreateCompanionBuilder,
      $$FinChequeEmitidosTableUpdateCompanionBuilder,
      (
        FinChequeEmitido,
        BaseReferences<
          _$AppDatabase,
          $FinChequeEmitidosTable,
          FinChequeEmitido
        >,
      ),
      FinChequeEmitido,
      PrefetchHooks Function()
    >;
typedef $$FinTipoRecebimentosTableCreateCompanionBuilder =
    FinTipoRecebimentosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });
typedef $$FinTipoRecebimentosTableUpdateCompanionBuilder =
    FinTipoRecebimentosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });

class $$FinTipoRecebimentosTableFilterComposer
    extends Composer<_$AppDatabase, $FinTipoRecebimentosTable> {
  $$FinTipoRecebimentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinTipoRecebimentosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinTipoRecebimentosTable> {
  $$FinTipoRecebimentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinTipoRecebimentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinTipoRecebimentosTable> {
  $$FinTipoRecebimentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$FinTipoRecebimentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinTipoRecebimentosTable,
          FinTipoRecebimento,
          $$FinTipoRecebimentosTableFilterComposer,
          $$FinTipoRecebimentosTableOrderingComposer,
          $$FinTipoRecebimentosTableAnnotationComposer,
          $$FinTipoRecebimentosTableCreateCompanionBuilder,
          $$FinTipoRecebimentosTableUpdateCompanionBuilder,
          (
            FinTipoRecebimento,
            BaseReferences<
              _$AppDatabase,
              $FinTipoRecebimentosTable,
              FinTipoRecebimento
            >,
          ),
          FinTipoRecebimento,
          PrefetchHooks Function()
        > {
  $$FinTipoRecebimentosTableTableManager(
    _$AppDatabase db,
    $FinTipoRecebimentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinTipoRecebimentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinTipoRecebimentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinTipoRecebimentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinTipoRecebimentosCompanion(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => FinTipoRecebimentosCompanion.insert(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinTipoRecebimentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinTipoRecebimentosTable,
      FinTipoRecebimento,
      $$FinTipoRecebimentosTableFilterComposer,
      $$FinTipoRecebimentosTableOrderingComposer,
      $$FinTipoRecebimentosTableAnnotationComposer,
      $$FinTipoRecebimentosTableCreateCompanionBuilder,
      $$FinTipoRecebimentosTableUpdateCompanionBuilder,
      (
        FinTipoRecebimento,
        BaseReferences<
          _$AppDatabase,
          $FinTipoRecebimentosTable,
          FinTipoRecebimento
        >,
      ),
      FinTipoRecebimento,
      PrefetchHooks Function()
    >;
typedef $$FinChequeRecebidosTableCreateCompanionBuilder =
    FinChequeRecebidosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<String?> cpf,
      Value<String?> cnpj,
      Value<String?> nome,
      Value<String?> codigoBanco,
      Value<String?> codigoAgencia,
      Value<String?> conta,
      Value<int?> numero,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> bomPara,
      Value<DateTime?> dataCompensacao,
      Value<double?> valor,
      Value<DateTime?> custodiaData,
      Value<double?> custodiaTarifa,
      Value<double?> custodiaComissao,
      Value<DateTime?> descontoData,
      Value<double?> descontoTarifa,
      Value<double?> descontoComissao,
      Value<double?> valorRecebido,
    });
typedef $$FinChequeRecebidosTableUpdateCompanionBuilder =
    FinChequeRecebidosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<String?> cpf,
      Value<String?> cnpj,
      Value<String?> nome,
      Value<String?> codigoBanco,
      Value<String?> codigoAgencia,
      Value<String?> conta,
      Value<int?> numero,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> bomPara,
      Value<DateTime?> dataCompensacao,
      Value<double?> valor,
      Value<DateTime?> custodiaData,
      Value<double?> custodiaTarifa,
      Value<double?> custodiaComissao,
      Value<DateTime?> descontoData,
      Value<double?> descontoTarifa,
      Value<double?> descontoComissao,
      Value<double?> valorRecebido,
    });

class $$FinChequeRecebidosTableFilterComposer
    extends Composer<_$AppDatabase, $FinChequeRecebidosTable> {
  $$FinChequeRecebidosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoBanco => $composableBuilder(
    column: $table.codigoBanco,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoAgencia => $composableBuilder(
    column: $table.codigoAgencia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get conta => $composableBuilder(
    column: $table.conta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get bomPara => $composableBuilder(
    column: $table.bomPara,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get custodiaData => $composableBuilder(
    column: $table.custodiaData,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custodiaTarifa => $composableBuilder(
    column: $table.custodiaTarifa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custodiaComissao => $composableBuilder(
    column: $table.custodiaComissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get descontoData => $composableBuilder(
    column: $table.descontoData,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get descontoTarifa => $composableBuilder(
    column: $table.descontoTarifa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get descontoComissao => $composableBuilder(
    column: $table.descontoComissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinChequeRecebidosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinChequeRecebidosTable> {
  $$FinChequeRecebidosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoBanco => $composableBuilder(
    column: $table.codigoBanco,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoAgencia => $composableBuilder(
    column: $table.codigoAgencia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get conta => $composableBuilder(
    column: $table.conta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get bomPara => $composableBuilder(
    column: $table.bomPara,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get custodiaData => $composableBuilder(
    column: $table.custodiaData,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custodiaTarifa => $composableBuilder(
    column: $table.custodiaTarifa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custodiaComissao => $composableBuilder(
    column: $table.custodiaComissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get descontoData => $composableBuilder(
    column: $table.descontoData,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get descontoTarifa => $composableBuilder(
    column: $table.descontoTarifa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get descontoComissao => $composableBuilder(
    column: $table.descontoComissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinChequeRecebidosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinChequeRecebidosTable> {
  $$FinChequeRecebidosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<String> get cpf =>
      $composableBuilder(column: $table.cpf, builder: (column) => column);

  GeneratedColumn<String> get cnpj =>
      $composableBuilder(column: $table.cnpj, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get codigoBanco => $composableBuilder(
    column: $table.codigoBanco,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoAgencia => $composableBuilder(
    column: $table.codigoAgencia,
    builder: (column) => column,
  );

  GeneratedColumn<String> get conta =>
      $composableBuilder(column: $table.conta, builder: (column) => column);

  GeneratedColumn<int> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get bomPara =>
      $composableBuilder(column: $table.bomPara, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCompensacao => $composableBuilder(
    column: $table.dataCompensacao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<DateTime> get custodiaData => $composableBuilder(
    column: $table.custodiaData,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custodiaTarifa => $composableBuilder(
    column: $table.custodiaTarifa,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custodiaComissao => $composableBuilder(
    column: $table.custodiaComissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get descontoData => $composableBuilder(
    column: $table.descontoData,
    builder: (column) => column,
  );

  GeneratedColumn<double> get descontoTarifa => $composableBuilder(
    column: $table.descontoTarifa,
    builder: (column) => column,
  );

  GeneratedColumn<double> get descontoComissao => $composableBuilder(
    column: $table.descontoComissao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => column,
  );
}

class $$FinChequeRecebidosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinChequeRecebidosTable,
          FinChequeRecebido,
          $$FinChequeRecebidosTableFilterComposer,
          $$FinChequeRecebidosTableOrderingComposer,
          $$FinChequeRecebidosTableAnnotationComposer,
          $$FinChequeRecebidosTableCreateCompanionBuilder,
          $$FinChequeRecebidosTableUpdateCompanionBuilder,
          (
            FinChequeRecebido,
            BaseReferences<
              _$AppDatabase,
              $FinChequeRecebidosTable,
              FinChequeRecebido
            >,
          ),
          FinChequeRecebido,
          PrefetchHooks Function()
        > {
  $$FinChequeRecebidosTableTableManager(
    _$AppDatabase db,
    $FinChequeRecebidosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinChequeRecebidosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinChequeRecebidosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinChequeRecebidosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> codigoBanco = const Value.absent(),
                Value<String?> codigoAgencia = const Value.absent(),
                Value<String?> conta = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> bomPara = const Value.absent(),
                Value<DateTime?> dataCompensacao = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<DateTime?> custodiaData = const Value.absent(),
                Value<double?> custodiaTarifa = const Value.absent(),
                Value<double?> custodiaComissao = const Value.absent(),
                Value<DateTime?> descontoData = const Value.absent(),
                Value<double?> descontoTarifa = const Value.absent(),
                Value<double?> descontoComissao = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
              }) => FinChequeRecebidosCompanion(
                id: id,
                idCliente: idCliente,
                cpf: cpf,
                cnpj: cnpj,
                nome: nome,
                codigoBanco: codigoBanco,
                codigoAgencia: codigoAgencia,
                conta: conta,
                numero: numero,
                dataEmissao: dataEmissao,
                bomPara: bomPara,
                dataCompensacao: dataCompensacao,
                valor: valor,
                custodiaData: custodiaData,
                custodiaTarifa: custodiaTarifa,
                custodiaComissao: custodiaComissao,
                descontoData: descontoData,
                descontoTarifa: descontoTarifa,
                descontoComissao: descontoComissao,
                valorRecebido: valorRecebido,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> codigoBanco = const Value.absent(),
                Value<String?> codigoAgencia = const Value.absent(),
                Value<String?> conta = const Value.absent(),
                Value<int?> numero = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> bomPara = const Value.absent(),
                Value<DateTime?> dataCompensacao = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<DateTime?> custodiaData = const Value.absent(),
                Value<double?> custodiaTarifa = const Value.absent(),
                Value<double?> custodiaComissao = const Value.absent(),
                Value<DateTime?> descontoData = const Value.absent(),
                Value<double?> descontoTarifa = const Value.absent(),
                Value<double?> descontoComissao = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
              }) => FinChequeRecebidosCompanion.insert(
                id: id,
                idCliente: idCliente,
                cpf: cpf,
                cnpj: cnpj,
                nome: nome,
                codigoBanco: codigoBanco,
                codigoAgencia: codigoAgencia,
                conta: conta,
                numero: numero,
                dataEmissao: dataEmissao,
                bomPara: bomPara,
                dataCompensacao: dataCompensacao,
                valor: valor,
                custodiaData: custodiaData,
                custodiaTarifa: custodiaTarifa,
                custodiaComissao: custodiaComissao,
                descontoData: descontoData,
                descontoTarifa: descontoTarifa,
                descontoComissao: descontoComissao,
                valorRecebido: valorRecebido,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinChequeRecebidosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinChequeRecebidosTable,
      FinChequeRecebido,
      $$FinChequeRecebidosTableFilterComposer,
      $$FinChequeRecebidosTableOrderingComposer,
      $$FinChequeRecebidosTableAnnotationComposer,
      $$FinChequeRecebidosTableCreateCompanionBuilder,
      $$FinChequeRecebidosTableUpdateCompanionBuilder,
      (
        FinChequeRecebido,
        BaseReferences<
          _$AppDatabase,
          $FinChequeRecebidosTable,
          FinChequeRecebido
        >,
      ),
      FinChequeRecebido,
      PrefetchHooks Function()
    >;
typedef $$FinConfiguracaoBoletosTableCreateCompanionBuilder =
    FinConfiguracaoBoletosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> instrucao01,
      Value<String?> instrucao02,
      Value<String?> caminhoArquivoRemessa,
      Value<String?> caminhoArquivoRetorno,
      Value<String?> caminhoArquivoLogotipo,
      Value<String?> caminhoArquivoPdf,
      Value<String?> mensagem,
      Value<String?> localPagamento,
      Value<String?> layoutRemessa,
      Value<String?> aceite,
      Value<String?> especie,
      Value<String?> carteira,
      Value<String?> codigoConvenio,
      Value<String?> codigoCedente,
      Value<double?> taxaMulta,
      Value<double?> taxaJuro,
      Value<int?> diasProtesto,
      Value<String?> nossoNumeroAnterior,
    });
typedef $$FinConfiguracaoBoletosTableUpdateCompanionBuilder =
    FinConfiguracaoBoletosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> instrucao01,
      Value<String?> instrucao02,
      Value<String?> caminhoArquivoRemessa,
      Value<String?> caminhoArquivoRetorno,
      Value<String?> caminhoArquivoLogotipo,
      Value<String?> caminhoArquivoPdf,
      Value<String?> mensagem,
      Value<String?> localPagamento,
      Value<String?> layoutRemessa,
      Value<String?> aceite,
      Value<String?> especie,
      Value<String?> carteira,
      Value<String?> codigoConvenio,
      Value<String?> codigoCedente,
      Value<double?> taxaMulta,
      Value<double?> taxaJuro,
      Value<int?> diasProtesto,
      Value<String?> nossoNumeroAnterior,
    });

class $$FinConfiguracaoBoletosTableFilterComposer
    extends Composer<_$AppDatabase, $FinConfiguracaoBoletosTable> {
  $$FinConfiguracaoBoletosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get instrucao01 => $composableBuilder(
    column: $table.instrucao01,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get instrucao02 => $composableBuilder(
    column: $table.instrucao02,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get caminhoArquivoRemessa => $composableBuilder(
    column: $table.caminhoArquivoRemessa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get caminhoArquivoRetorno => $composableBuilder(
    column: $table.caminhoArquivoRetorno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get caminhoArquivoLogotipo => $composableBuilder(
    column: $table.caminhoArquivoLogotipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get caminhoArquivoPdf => $composableBuilder(
    column: $table.caminhoArquivoPdf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mensagem => $composableBuilder(
    column: $table.mensagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get localPagamento => $composableBuilder(
    column: $table.localPagamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get layoutRemessa => $composableBuilder(
    column: $table.layoutRemessa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get aceite => $composableBuilder(
    column: $table.aceite,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get especie => $composableBuilder(
    column: $table.especie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get carteira => $composableBuilder(
    column: $table.carteira,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoCedente => $composableBuilder(
    column: $table.codigoCedente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get diasProtesto => $composableBuilder(
    column: $table.diasProtesto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nossoNumeroAnterior => $composableBuilder(
    column: $table.nossoNumeroAnterior,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FinConfiguracaoBoletosTableOrderingComposer
    extends Composer<_$AppDatabase, $FinConfiguracaoBoletosTable> {
  $$FinConfiguracaoBoletosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get instrucao01 => $composableBuilder(
    column: $table.instrucao01,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get instrucao02 => $composableBuilder(
    column: $table.instrucao02,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get caminhoArquivoRemessa => $composableBuilder(
    column: $table.caminhoArquivoRemessa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get caminhoArquivoRetorno => $composableBuilder(
    column: $table.caminhoArquivoRetorno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get caminhoArquivoLogotipo => $composableBuilder(
    column: $table.caminhoArquivoLogotipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get caminhoArquivoPdf => $composableBuilder(
    column: $table.caminhoArquivoPdf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mensagem => $composableBuilder(
    column: $table.mensagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get localPagamento => $composableBuilder(
    column: $table.localPagamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get layoutRemessa => $composableBuilder(
    column: $table.layoutRemessa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get aceite => $composableBuilder(
    column: $table.aceite,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get especie => $composableBuilder(
    column: $table.especie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get carteira => $composableBuilder(
    column: $table.carteira,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoCedente => $composableBuilder(
    column: $table.codigoCedente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaMulta => $composableBuilder(
    column: $table.taxaMulta,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaJuro => $composableBuilder(
    column: $table.taxaJuro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get diasProtesto => $composableBuilder(
    column: $table.diasProtesto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nossoNumeroAnterior => $composableBuilder(
    column: $table.nossoNumeroAnterior,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FinConfiguracaoBoletosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FinConfiguracaoBoletosTable> {
  $$FinConfiguracaoBoletosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get instrucao01 => $composableBuilder(
    column: $table.instrucao01,
    builder: (column) => column,
  );

  GeneratedColumn<String> get instrucao02 => $composableBuilder(
    column: $table.instrucao02,
    builder: (column) => column,
  );

  GeneratedColumn<String> get caminhoArquivoRemessa => $composableBuilder(
    column: $table.caminhoArquivoRemessa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get caminhoArquivoRetorno => $composableBuilder(
    column: $table.caminhoArquivoRetorno,
    builder: (column) => column,
  );

  GeneratedColumn<String> get caminhoArquivoLogotipo => $composableBuilder(
    column: $table.caminhoArquivoLogotipo,
    builder: (column) => column,
  );

  GeneratedColumn<String> get caminhoArquivoPdf => $composableBuilder(
    column: $table.caminhoArquivoPdf,
    builder: (column) => column,
  );

  GeneratedColumn<String> get mensagem =>
      $composableBuilder(column: $table.mensagem, builder: (column) => column);

  GeneratedColumn<String> get localPagamento => $composableBuilder(
    column: $table.localPagamento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get layoutRemessa => $composableBuilder(
    column: $table.layoutRemessa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get aceite =>
      $composableBuilder(column: $table.aceite, builder: (column) => column);

  GeneratedColumn<String> get especie =>
      $composableBuilder(column: $table.especie, builder: (column) => column);

  GeneratedColumn<String> get carteira =>
      $composableBuilder(column: $table.carteira, builder: (column) => column);

  GeneratedColumn<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoCedente => $composableBuilder(
    column: $table.codigoCedente,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaMulta =>
      $composableBuilder(column: $table.taxaMulta, builder: (column) => column);

  GeneratedColumn<double> get taxaJuro =>
      $composableBuilder(column: $table.taxaJuro, builder: (column) => column);

  GeneratedColumn<int> get diasProtesto => $composableBuilder(
    column: $table.diasProtesto,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nossoNumeroAnterior => $composableBuilder(
    column: $table.nossoNumeroAnterior,
    builder: (column) => column,
  );
}

class $$FinConfiguracaoBoletosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FinConfiguracaoBoletosTable,
          FinConfiguracaoBoleto,
          $$FinConfiguracaoBoletosTableFilterComposer,
          $$FinConfiguracaoBoletosTableOrderingComposer,
          $$FinConfiguracaoBoletosTableAnnotationComposer,
          $$FinConfiguracaoBoletosTableCreateCompanionBuilder,
          $$FinConfiguracaoBoletosTableUpdateCompanionBuilder,
          (
            FinConfiguracaoBoleto,
            BaseReferences<
              _$AppDatabase,
              $FinConfiguracaoBoletosTable,
              FinConfiguracaoBoleto
            >,
          ),
          FinConfiguracaoBoleto,
          PrefetchHooks Function()
        > {
  $$FinConfiguracaoBoletosTableTableManager(
    _$AppDatabase db,
    $FinConfiguracaoBoletosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FinConfiguracaoBoletosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$FinConfiguracaoBoletosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FinConfiguracaoBoletosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> instrucao01 = const Value.absent(),
                Value<String?> instrucao02 = const Value.absent(),
                Value<String?> caminhoArquivoRemessa = const Value.absent(),
                Value<String?> caminhoArquivoRetorno = const Value.absent(),
                Value<String?> caminhoArquivoLogotipo = const Value.absent(),
                Value<String?> caminhoArquivoPdf = const Value.absent(),
                Value<String?> mensagem = const Value.absent(),
                Value<String?> localPagamento = const Value.absent(),
                Value<String?> layoutRemessa = const Value.absent(),
                Value<String?> aceite = const Value.absent(),
                Value<String?> especie = const Value.absent(),
                Value<String?> carteira = const Value.absent(),
                Value<String?> codigoConvenio = const Value.absent(),
                Value<String?> codigoCedente = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<int?> diasProtesto = const Value.absent(),
                Value<String?> nossoNumeroAnterior = const Value.absent(),
              }) => FinConfiguracaoBoletosCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                instrucao01: instrucao01,
                instrucao02: instrucao02,
                caminhoArquivoRemessa: caminhoArquivoRemessa,
                caminhoArquivoRetorno: caminhoArquivoRetorno,
                caminhoArquivoLogotipo: caminhoArquivoLogotipo,
                caminhoArquivoPdf: caminhoArquivoPdf,
                mensagem: mensagem,
                localPagamento: localPagamento,
                layoutRemessa: layoutRemessa,
                aceite: aceite,
                especie: especie,
                carteira: carteira,
                codigoConvenio: codigoConvenio,
                codigoCedente: codigoCedente,
                taxaMulta: taxaMulta,
                taxaJuro: taxaJuro,
                diasProtesto: diasProtesto,
                nossoNumeroAnterior: nossoNumeroAnterior,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> instrucao01 = const Value.absent(),
                Value<String?> instrucao02 = const Value.absent(),
                Value<String?> caminhoArquivoRemessa = const Value.absent(),
                Value<String?> caminhoArquivoRetorno = const Value.absent(),
                Value<String?> caminhoArquivoLogotipo = const Value.absent(),
                Value<String?> caminhoArquivoPdf = const Value.absent(),
                Value<String?> mensagem = const Value.absent(),
                Value<String?> localPagamento = const Value.absent(),
                Value<String?> layoutRemessa = const Value.absent(),
                Value<String?> aceite = const Value.absent(),
                Value<String?> especie = const Value.absent(),
                Value<String?> carteira = const Value.absent(),
                Value<String?> codigoConvenio = const Value.absent(),
                Value<String?> codigoCedente = const Value.absent(),
                Value<double?> taxaMulta = const Value.absent(),
                Value<double?> taxaJuro = const Value.absent(),
                Value<int?> diasProtesto = const Value.absent(),
                Value<String?> nossoNumeroAnterior = const Value.absent(),
              }) => FinConfiguracaoBoletosCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                instrucao01: instrucao01,
                instrucao02: instrucao02,
                caminhoArquivoRemessa: caminhoArquivoRemessa,
                caminhoArquivoRetorno: caminhoArquivoRetorno,
                caminhoArquivoLogotipo: caminhoArquivoLogotipo,
                caminhoArquivoPdf: caminhoArquivoPdf,
                mensagem: mensagem,
                localPagamento: localPagamento,
                layoutRemessa: layoutRemessa,
                aceite: aceite,
                especie: especie,
                carteira: carteira,
                codigoConvenio: codigoConvenio,
                codigoCedente: codigoCedente,
                taxaMulta: taxaMulta,
                taxaJuro: taxaJuro,
                diasProtesto: diasProtesto,
                nossoNumeroAnterior: nossoNumeroAnterior,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FinConfiguracaoBoletosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FinConfiguracaoBoletosTable,
      FinConfiguracaoBoleto,
      $$FinConfiguracaoBoletosTableFilterComposer,
      $$FinConfiguracaoBoletosTableOrderingComposer,
      $$FinConfiguracaoBoletosTableAnnotationComposer,
      $$FinConfiguracaoBoletosTableCreateCompanionBuilder,
      $$FinConfiguracaoBoletosTableUpdateCompanionBuilder,
      (
        FinConfiguracaoBoleto,
        BaseReferences<
          _$AppDatabase,
          $FinConfiguracaoBoletosTable,
          FinConfiguracaoBoleto
        >,
      ),
      FinConfiguracaoBoleto,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaClientesTableCreateCompanionBuilder =
    ViewPessoaClientesCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<double?> taxaDesconto,
      Value<double?> limiteCredito,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });
typedef $$ViewPessoaClientesTableUpdateCompanionBuilder =
    ViewPessoaClientesCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<double?> taxaDesconto,
      Value<double?> limiteCredito,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });

class $$ViewPessoaClientesTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<DateTime> get desde =>
      $composableBuilder(column: $table.desde, builder: (column) => column);

  GeneratedColumn<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);
}

class $$ViewPessoaClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaClientesTable,
          ViewPessoaCliente,
          $$ViewPessoaClientesTableFilterComposer,
          $$ViewPessoaClientesTableOrderingComposer,
          $$ViewPessoaClientesTableAnnotationComposer,
          $$ViewPessoaClientesTableCreateCompanionBuilder,
          $$ViewPessoaClientesTableUpdateCompanionBuilder,
          (
            ViewPessoaCliente,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaClientesTable,
              ViewPessoaCliente
            >,
          ),
          ViewPessoaCliente,
          PrefetchHooks Function()
        > {
  $$ViewPessoaClientesTableTableManager(
    _$AppDatabase db,
    $ViewPessoaClientesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaClientesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaClientesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaClientesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> limiteCredito = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaClientesCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                taxaDesconto: taxaDesconto,
                limiteCredito: limiteCredito,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> limiteCredito = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaClientesCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                taxaDesconto: taxaDesconto,
                limiteCredito: limiteCredito,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaClientesTable,
      ViewPessoaCliente,
      $$ViewPessoaClientesTableFilterComposer,
      $$ViewPessoaClientesTableOrderingComposer,
      $$ViewPessoaClientesTableAnnotationComposer,
      $$ViewPessoaClientesTableCreateCompanionBuilder,
      $$ViewPessoaClientesTableUpdateCompanionBuilder,
      (
        ViewPessoaCliente,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaClientesTable,
          ViewPessoaCliente
        >,
      ),
      ViewPessoaCliente,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaFornecedorsTableCreateCompanionBuilder =
    ViewPessoaFornecedorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });
typedef $$ViewPessoaFornecedorsTableUpdateCompanionBuilder =
    ViewPessoaFornecedorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });

class $$ViewPessoaFornecedorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaFornecedorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaFornecedorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<DateTime> get desde =>
      $composableBuilder(column: $table.desde, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);
}

class $$ViewPessoaFornecedorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaFornecedorsTable,
          ViewPessoaFornecedor,
          $$ViewPessoaFornecedorsTableFilterComposer,
          $$ViewPessoaFornecedorsTableOrderingComposer,
          $$ViewPessoaFornecedorsTableAnnotationComposer,
          $$ViewPessoaFornecedorsTableCreateCompanionBuilder,
          $$ViewPessoaFornecedorsTableUpdateCompanionBuilder,
          (
            ViewPessoaFornecedor,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaFornecedorsTable,
              ViewPessoaFornecedor
            >,
          ),
          ViewPessoaFornecedor,
          PrefetchHooks Function()
        > {
  $$ViewPessoaFornecedorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaFornecedorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaFornecedorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaFornecedorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaFornecedorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaFornecedorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaFornecedorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaFornecedorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaFornecedorsTable,
      ViewPessoaFornecedor,
      $$ViewPessoaFornecedorsTableFilterComposer,
      $$ViewPessoaFornecedorsTableOrderingComposer,
      $$ViewPessoaFornecedorsTableAnnotationComposer,
      $$ViewPessoaFornecedorsTableCreateCompanionBuilder,
      $$ViewPessoaFornecedorsTableUpdateCompanionBuilder,
      (
        ViewPessoaFornecedor,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaFornecedorsTable,
          ViewPessoaFornecedor
        >,
      ),
      ViewPessoaFornecedor,
      PrefetchHooks Function()
    >;
typedef $$ViewFinMovimentoCaixaBancosTableCreateCompanionBuilder =
    ViewFinMovimentoCaixaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> nomePessoa,
      Value<DateTime?> dataLancamento,
      Value<DateTime?> dataPagoRecebido,
      Value<String?> mesAno,
      Value<String?> historico,
      Value<double?> valor,
      Value<String?> descricaoDocumentoOrigem,
      Value<String?> operacao,
    });
typedef $$ViewFinMovimentoCaixaBancosTableUpdateCompanionBuilder =
    ViewFinMovimentoCaixaBancosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> nomePessoa,
      Value<DateTime?> dataLancamento,
      Value<DateTime?> dataPagoRecebido,
      Value<String?> mesAno,
      Value<String?> historico,
      Value<double?> valor,
      Value<String?> descricaoDocumentoOrigem,
      Value<String?> operacao,
    });

class $$ViewFinMovimentoCaixaBancosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewFinMovimentoCaixaBancosTable> {
  $$ViewFinMovimentoCaixaBancosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataPagoRecebido => $composableBuilder(
    column: $table.dataPagoRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricaoDocumentoOrigem => $composableBuilder(
    column: $table.descricaoDocumentoOrigem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get operacao => $composableBuilder(
    column: $table.operacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewFinMovimentoCaixaBancosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewFinMovimentoCaixaBancosTable> {
  $$ViewFinMovimentoCaixaBancosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataPagoRecebido => $composableBuilder(
    column: $table.dataPagoRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get mesAno => $composableBuilder(
    column: $table.mesAno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricaoDocumentoOrigem => $composableBuilder(
    column: $table.descricaoDocumentoOrigem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get operacao => $composableBuilder(
    column: $table.operacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewFinMovimentoCaixaBancosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewFinMovimentoCaixaBancosTable> {
  $$ViewFinMovimentoCaixaBancosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataPagoRecebido => $composableBuilder(
    column: $table.dataPagoRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<String> get mesAno =>
      $composableBuilder(column: $table.mesAno, builder: (column) => column);

  GeneratedColumn<String> get historico =>
      $composableBuilder(column: $table.historico, builder: (column) => column);

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<String> get descricaoDocumentoOrigem => $composableBuilder(
    column: $table.descricaoDocumentoOrigem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get operacao =>
      $composableBuilder(column: $table.operacao, builder: (column) => column);
}

class $$ViewFinMovimentoCaixaBancosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewFinMovimentoCaixaBancosTable,
          ViewFinMovimentoCaixaBanco,
          $$ViewFinMovimentoCaixaBancosTableFilterComposer,
          $$ViewFinMovimentoCaixaBancosTableOrderingComposer,
          $$ViewFinMovimentoCaixaBancosTableAnnotationComposer,
          $$ViewFinMovimentoCaixaBancosTableCreateCompanionBuilder,
          $$ViewFinMovimentoCaixaBancosTableUpdateCompanionBuilder,
          (
            ViewFinMovimentoCaixaBanco,
            BaseReferences<
              _$AppDatabase,
              $ViewFinMovimentoCaixaBancosTable,
              ViewFinMovimentoCaixaBanco
            >,
          ),
          ViewFinMovimentoCaixaBanco,
          PrefetchHooks Function()
        > {
  $$ViewFinMovimentoCaixaBancosTableTableManager(
    _$AppDatabase db,
    $ViewFinMovimentoCaixaBancosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewFinMovimentoCaixaBancosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewFinMovimentoCaixaBancosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewFinMovimentoCaixaBancosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> nomePessoa = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<DateTime?> dataPagoRecebido = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> historico = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> descricaoDocumentoOrigem = const Value.absent(),
                Value<String?> operacao = const Value.absent(),
              }) => ViewFinMovimentoCaixaBancosCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                nomePessoa: nomePessoa,
                dataLancamento: dataLancamento,
                dataPagoRecebido: dataPagoRecebido,
                mesAno: mesAno,
                historico: historico,
                valor: valor,
                descricaoDocumentoOrigem: descricaoDocumentoOrigem,
                operacao: operacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> nomePessoa = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<DateTime?> dataPagoRecebido = const Value.absent(),
                Value<String?> mesAno = const Value.absent(),
                Value<String?> historico = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> descricaoDocumentoOrigem = const Value.absent(),
                Value<String?> operacao = const Value.absent(),
              }) => ViewFinMovimentoCaixaBancosCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                nomePessoa: nomePessoa,
                dataLancamento: dataLancamento,
                dataPagoRecebido: dataPagoRecebido,
                mesAno: mesAno,
                historico: historico,
                valor: valor,
                descricaoDocumentoOrigem: descricaoDocumentoOrigem,
                operacao: operacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewFinMovimentoCaixaBancosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewFinMovimentoCaixaBancosTable,
      ViewFinMovimentoCaixaBanco,
      $$ViewFinMovimentoCaixaBancosTableFilterComposer,
      $$ViewFinMovimentoCaixaBancosTableOrderingComposer,
      $$ViewFinMovimentoCaixaBancosTableAnnotationComposer,
      $$ViewFinMovimentoCaixaBancosTableCreateCompanionBuilder,
      $$ViewFinMovimentoCaixaBancosTableUpdateCompanionBuilder,
      (
        ViewFinMovimentoCaixaBanco,
        BaseReferences<
          _$AppDatabase,
          $ViewFinMovimentoCaixaBancosTable,
          ViewFinMovimentoCaixaBanco
        >,
      ),
      ViewFinMovimentoCaixaBanco,
      PrefetchHooks Function()
    >;
typedef $$ViewFinFluxoCaixasTableCreateCompanionBuilder =
    ViewFinFluxoCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> nomePessoa,
      Value<DateTime?> dataLancamento,
      Value<DateTime?> dataVencimento,
      Value<double?> valor,
      Value<String?> codigoSituacao,
      Value<String?> descricaoSituacao,
      Value<String?> operacao,
    });
typedef $$ViewFinFluxoCaixasTableUpdateCompanionBuilder =
    ViewFinFluxoCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> nomePessoa,
      Value<DateTime?> dataLancamento,
      Value<DateTime?> dataVencimento,
      Value<double?> valor,
      Value<String?> codigoSituacao,
      Value<String?> descricaoSituacao,
      Value<String?> operacao,
    });

class $$ViewFinFluxoCaixasTableFilterComposer
    extends Composer<_$AppDatabase, $ViewFinFluxoCaixasTable> {
  $$ViewFinFluxoCaixasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoSituacao => $composableBuilder(
    column: $table.codigoSituacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricaoSituacao => $composableBuilder(
    column: $table.descricaoSituacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get operacao => $composableBuilder(
    column: $table.operacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewFinFluxoCaixasTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewFinFluxoCaixasTable> {
  $$ViewFinFluxoCaixasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoSituacao => $composableBuilder(
    column: $table.codigoSituacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricaoSituacao => $composableBuilder(
    column: $table.descricaoSituacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get operacao => $composableBuilder(
    column: $table.operacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewFinFluxoCaixasTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewFinFluxoCaixasTable> {
  $$ViewFinFluxoCaixasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomePessoa => $composableBuilder(
    column: $table.nomePessoa,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataLancamento => $composableBuilder(
    column: $table.dataLancamento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);

  GeneratedColumn<String> get codigoSituacao => $composableBuilder(
    column: $table.codigoSituacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descricaoSituacao => $composableBuilder(
    column: $table.descricaoSituacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get operacao =>
      $composableBuilder(column: $table.operacao, builder: (column) => column);
}

class $$ViewFinFluxoCaixasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewFinFluxoCaixasTable,
          ViewFinFluxoCaixa,
          $$ViewFinFluxoCaixasTableFilterComposer,
          $$ViewFinFluxoCaixasTableOrderingComposer,
          $$ViewFinFluxoCaixasTableAnnotationComposer,
          $$ViewFinFluxoCaixasTableCreateCompanionBuilder,
          $$ViewFinFluxoCaixasTableUpdateCompanionBuilder,
          (
            ViewFinFluxoCaixa,
            BaseReferences<
              _$AppDatabase,
              $ViewFinFluxoCaixasTable,
              ViewFinFluxoCaixa
            >,
          ),
          ViewFinFluxoCaixa,
          PrefetchHooks Function()
        > {
  $$ViewFinFluxoCaixasTableTableManager(
    _$AppDatabase db,
    $ViewFinFluxoCaixasTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewFinFluxoCaixasTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewFinFluxoCaixasTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewFinFluxoCaixasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> nomePessoa = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> codigoSituacao = const Value.absent(),
                Value<String?> descricaoSituacao = const Value.absent(),
                Value<String?> operacao = const Value.absent(),
              }) => ViewFinFluxoCaixasCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                nomePessoa: nomePessoa,
                dataLancamento: dataLancamento,
                dataVencimento: dataVencimento,
                valor: valor,
                codigoSituacao: codigoSituacao,
                descricaoSituacao: descricaoSituacao,
                operacao: operacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> nomePessoa = const Value.absent(),
                Value<DateTime?> dataLancamento = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<double?> valor = const Value.absent(),
                Value<String?> codigoSituacao = const Value.absent(),
                Value<String?> descricaoSituacao = const Value.absent(),
                Value<String?> operacao = const Value.absent(),
              }) => ViewFinFluxoCaixasCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                nomePessoa: nomePessoa,
                dataLancamento: dataLancamento,
                dataVencimento: dataVencimento,
                valor: valor,
                codigoSituacao: codigoSituacao,
                descricaoSituacao: descricaoSituacao,
                operacao: operacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewFinFluxoCaixasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewFinFluxoCaixasTable,
      ViewFinFluxoCaixa,
      $$ViewFinFluxoCaixasTableFilterComposer,
      $$ViewFinFluxoCaixasTableOrderingComposer,
      $$ViewFinFluxoCaixasTableAnnotationComposer,
      $$ViewFinFluxoCaixasTableCreateCompanionBuilder,
      $$ViewFinFluxoCaixasTableUpdateCompanionBuilder,
      (
        ViewFinFluxoCaixa,
        BaseReferences<
          _$AppDatabase,
          $ViewFinFluxoCaixasTable,
          ViewFinFluxoCaixa
        >,
      ),
      ViewFinFluxoCaixa,
      PrefetchHooks Function()
    >;
typedef $$ViewFinChequeNaoCompensadosTableCreateCompanionBuilder =
    ViewFinChequeNaoCompensadosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> talao,
      Value<String?> numeroTalao,
      Value<String?> numeroCheque,
      Value<String?> statusCheque,
      Value<DateTime?> dataStatus,
      Value<double?> valor,
    });
typedef $$ViewFinChequeNaoCompensadosTableUpdateCompanionBuilder =
    ViewFinChequeNaoCompensadosCompanion Function({
      Value<int?> id,
      Value<int?> idBancoContaCaixa,
      Value<String?> nomeContaCaixa,
      Value<String?> talao,
      Value<String?> numeroTalao,
      Value<String?> numeroCheque,
      Value<String?> statusCheque,
      Value<DateTime?> dataStatus,
      Value<double?> valor,
    });

class $$ViewFinChequeNaoCompensadosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewFinChequeNaoCompensadosTable> {
  $$ViewFinChequeNaoCompensadosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get talao => $composableBuilder(
    column: $table.talao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroTalao => $composableBuilder(
    column: $table.numeroTalao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroCheque => $composableBuilder(
    column: $table.numeroCheque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewFinChequeNaoCompensadosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewFinChequeNaoCompensadosTable> {
  $$ViewFinChequeNaoCompensadosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get talao => $composableBuilder(
    column: $table.talao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroTalao => $composableBuilder(
    column: $table.numeroTalao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroCheque => $composableBuilder(
    column: $table.numeroCheque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valor => $composableBuilder(
    column: $table.valor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewFinChequeNaoCompensadosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewFinChequeNaoCompensadosTable> {
  $$ViewFinChequeNaoCompensadosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBancoContaCaixa => $composableBuilder(
    column: $table.idBancoContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeContaCaixa => $composableBuilder(
    column: $table.nomeContaCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get talao =>
      $composableBuilder(column: $table.talao, builder: (column) => column);

  GeneratedColumn<String> get numeroTalao => $composableBuilder(
    column: $table.numeroTalao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroCheque => $composableBuilder(
    column: $table.numeroCheque,
    builder: (column) => column,
  );

  GeneratedColumn<String> get statusCheque => $composableBuilder(
    column: $table.statusCheque,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataStatus => $composableBuilder(
    column: $table.dataStatus,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valor =>
      $composableBuilder(column: $table.valor, builder: (column) => column);
}

class $$ViewFinChequeNaoCompensadosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewFinChequeNaoCompensadosTable,
          ViewFinChequeNaoCompensado,
          $$ViewFinChequeNaoCompensadosTableFilterComposer,
          $$ViewFinChequeNaoCompensadosTableOrderingComposer,
          $$ViewFinChequeNaoCompensadosTableAnnotationComposer,
          $$ViewFinChequeNaoCompensadosTableCreateCompanionBuilder,
          $$ViewFinChequeNaoCompensadosTableUpdateCompanionBuilder,
          (
            ViewFinChequeNaoCompensado,
            BaseReferences<
              _$AppDatabase,
              $ViewFinChequeNaoCompensadosTable,
              ViewFinChequeNaoCompensado
            >,
          ),
          ViewFinChequeNaoCompensado,
          PrefetchHooks Function()
        > {
  $$ViewFinChequeNaoCompensadosTableTableManager(
    _$AppDatabase db,
    $ViewFinChequeNaoCompensadosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewFinChequeNaoCompensadosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewFinChequeNaoCompensadosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewFinChequeNaoCompensadosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> talao = const Value.absent(),
                Value<String?> numeroTalao = const Value.absent(),
                Value<String?> numeroCheque = const Value.absent(),
                Value<String?> statusCheque = const Value.absent(),
                Value<DateTime?> dataStatus = const Value.absent(),
                Value<double?> valor = const Value.absent(),
              }) => ViewFinChequeNaoCompensadosCompanion(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                talao: talao,
                numeroTalao: numeroTalao,
                numeroCheque: numeroCheque,
                statusCheque: statusCheque,
                dataStatus: dataStatus,
                valor: valor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBancoContaCaixa = const Value.absent(),
                Value<String?> nomeContaCaixa = const Value.absent(),
                Value<String?> talao = const Value.absent(),
                Value<String?> numeroTalao = const Value.absent(),
                Value<String?> numeroCheque = const Value.absent(),
                Value<String?> statusCheque = const Value.absent(),
                Value<DateTime?> dataStatus = const Value.absent(),
                Value<double?> valor = const Value.absent(),
              }) => ViewFinChequeNaoCompensadosCompanion.insert(
                id: id,
                idBancoContaCaixa: idBancoContaCaixa,
                nomeContaCaixa: nomeContaCaixa,
                talao: talao,
                numeroTalao: numeroTalao,
                numeroCheque: numeroCheque,
                statusCheque: statusCheque,
                dataStatus: dataStatus,
                valor: valor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewFinChequeNaoCompensadosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewFinChequeNaoCompensadosTable,
      ViewFinChequeNaoCompensado,
      $$ViewFinChequeNaoCompensadosTableFilterComposer,
      $$ViewFinChequeNaoCompensadosTableOrderingComposer,
      $$ViewFinChequeNaoCompensadosTableAnnotationComposer,
      $$ViewFinChequeNaoCompensadosTableCreateCompanionBuilder,
      $$ViewFinChequeNaoCompensadosTableUpdateCompanionBuilder,
      (
        ViewFinChequeNaoCompensado,
        BaseReferences<
          _$AppDatabase,
          $ViewFinChequeNaoCompensadosTable,
          ViewFinChequeNaoCompensado
        >,
      ),
      ViewFinChequeNaoCompensado,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ChequesTableTableManager get cheques =>
      $$ChequesTableTableManager(_db, _db.cheques);
  $$FinParcelaPagarsTableTableManager get finParcelaPagars =>
      $$FinParcelaPagarsTableTableManager(_db, _db.finParcelaPagars);
  $$FinParcelaRecebersTableTableManager get finParcelaRecebers =>
      $$FinParcelaRecebersTableTableManager(_db, _db.finParcelaRecebers);
  $$TalonarioChequesTableTableManager get talonarioCheques =>
      $$TalonarioChequesTableTableManager(_db, _db.talonarioCheques);
  $$FinLancamentoPagarsTableTableManager get finLancamentoPagars =>
      $$FinLancamentoPagarsTableTableManager(_db, _db.finLancamentoPagars);
  $$FinLancamentoRecebersTableTableManager get finLancamentoRecebers =>
      $$FinLancamentoRecebersTableTableManager(_db, _db.finLancamentoRecebers);
  $$BancosTableTableManager get bancos =>
      $$BancosTableTableManager(_db, _db.bancos);
  $$BancoAgenciasTableTableManager get bancoAgencias =>
      $$BancoAgenciasTableTableManager(_db, _db.bancoAgencias);
  $$BancoContaCaixasTableTableManager get bancoContaCaixas =>
      $$BancoContaCaixasTableTableManager(_db, _db.bancoContaCaixas);
  $$FinFechamentoCaixaBancosTableTableManager get finFechamentoCaixaBancos =>
      $$FinFechamentoCaixaBancosTableTableManager(
        _db,
        _db.finFechamentoCaixaBancos,
      );
  $$FinExtratoContaBancosTableTableManager get finExtratoContaBancos =>
      $$FinExtratoContaBancosTableTableManager(_db, _db.finExtratoContaBancos);
  $$FinDocumentoOrigemsTableTableManager get finDocumentoOrigems =>
      $$FinDocumentoOrigemsTableTableManager(_db, _db.finDocumentoOrigems);
  $$FinNaturezaFinanceirasTableTableManager get finNaturezaFinanceiras =>
      $$FinNaturezaFinanceirasTableTableManager(
        _db,
        _db.finNaturezaFinanceiras,
      );
  $$FinStatusParcelasTableTableManager get finStatusParcelas =>
      $$FinStatusParcelasTableTableManager(_db, _db.finStatusParcelas);
  $$FinTipoPagamentosTableTableManager get finTipoPagamentos =>
      $$FinTipoPagamentosTableTableManager(_db, _db.finTipoPagamentos);
  $$FinChequeEmitidosTableTableManager get finChequeEmitidos =>
      $$FinChequeEmitidosTableTableManager(_db, _db.finChequeEmitidos);
  $$FinTipoRecebimentosTableTableManager get finTipoRecebimentos =>
      $$FinTipoRecebimentosTableTableManager(_db, _db.finTipoRecebimentos);
  $$FinChequeRecebidosTableTableManager get finChequeRecebidos =>
      $$FinChequeRecebidosTableTableManager(_db, _db.finChequeRecebidos);
  $$FinConfiguracaoBoletosTableTableManager get finConfiguracaoBoletos =>
      $$FinConfiguracaoBoletosTableTableManager(
        _db,
        _db.finConfiguracaoBoletos,
      );
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaClientesTableTableManager get viewPessoaClientes =>
      $$ViewPessoaClientesTableTableManager(_db, _db.viewPessoaClientes);
  $$ViewPessoaFornecedorsTableTableManager get viewPessoaFornecedors =>
      $$ViewPessoaFornecedorsTableTableManager(_db, _db.viewPessoaFornecedors);
  $$ViewFinMovimentoCaixaBancosTableTableManager
  get viewFinMovimentoCaixaBancos =>
      $$ViewFinMovimentoCaixaBancosTableTableManager(
        _db,
        _db.viewFinMovimentoCaixaBancos,
      );
  $$ViewFinFluxoCaixasTableTableManager get viewFinFluxoCaixas =>
      $$ViewFinFluxoCaixasTableTableManager(_db, _db.viewFinFluxoCaixas);
  $$ViewFinChequeNaoCompensadosTableTableManager
  get viewFinChequeNaoCompensados =>
      $$ViewFinChequeNaoCompensadosTableTableManager(
        _db,
        _db.viewFinChequeNaoCompensados,
      );
}
