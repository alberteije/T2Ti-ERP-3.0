import 'dart:convert';
import 'package:financeiro/app/data/provider/api/api_provider_base.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ViewFinFluxoCaixaApiProvider extends ApiProviderBase {

	Future<List<ViewFinFluxoCaixaModel>?> getList({Filter? filter}) async {
		List<ViewFinFluxoCaixaModel> viewFinFluxoCaixaModelList = [];

		try {
			handleFilter(filter, '/view-fin-fluxo-caixa/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition());

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinFluxoCaixaModelJson = json.decode(response.body) as List<dynamic>;
					for (var viewFinFluxoCaixaModel in viewFinFluxoCaixaModelJson) {
						viewFinFluxoCaixaModelList.add(ViewFinFluxoCaixaModel.fromJson(viewFinFluxoCaixaModel));
					}
					return viewFinFluxoCaixaModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ViewFinFluxoCaixaModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/view-fin-fluxo-caixa/$pk')!, headers: ApiProviderBase.headerRequisition());

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinFluxoCaixaModelJson = json.decode(response.body);
					return ViewFinFluxoCaixaModel.fromJson(viewFinFluxoCaixaModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinFluxoCaixaModel?>? insert(ViewFinFluxoCaixaModel viewFinFluxoCaixaModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/view-fin-fluxo-caixa')!,
				headers: ApiProviderBase.headerRequisition(),
				body: viewFinFluxoCaixaModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinFluxoCaixaModelJson = json.decode(response.body);
					return ViewFinFluxoCaixaModel.fromJson(viewFinFluxoCaixaModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinFluxoCaixaModel?>? update(ViewFinFluxoCaixaModel viewFinFluxoCaixaModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/view-fin-fluxo-caixa')!,
				headers: ApiProviderBase.headerRequisition(),
				body: viewFinFluxoCaixaModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinFluxoCaixaModelJson = json.decode(response.body);
					return ViewFinFluxoCaixaModel.fromJson(viewFinFluxoCaixaModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/view-fin-fluxo-caixa/$pk')!,
				headers: ApiProviderBase.headerRequisition(),
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
