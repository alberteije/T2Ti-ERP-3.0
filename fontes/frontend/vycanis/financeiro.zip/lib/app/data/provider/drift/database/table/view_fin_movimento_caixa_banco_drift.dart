import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';

@DataClassName("ViewFinMovimentoCaixaBanco")
class ViewFinMovimentoCaixaBancos extends Table {
	@override
	String get tableName => 'view_fin_movimento_caixa_banco';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBancoContaCaixa => integer().named('id_banco_conta_caixa').nullable()();
	TextColumn get nomeContaCaixa => text().named('nome_conta_caixa').withLength(min: 0, max: 255).nullable()();
	TextColumn get nomePessoa => text().named('nome_pessoa').withLength(min: 0, max: 255).nullable()();
	DateTimeColumn get dataLancamento => dateTime().named('data_lancamento').nullable()();
	DateTimeColumn get dataPagoRecebido => dateTime().named('data_pago_recebido').nullable()();
	TextColumn get mesAno => text().named('mes_ano').withLength(min: 0, max: 7).nullable()();
	TextColumn get historico => text().named('historico').nullable()();
	RealColumn get valor => real().named('valor').nullable()();
	TextColumn get descricaoDocumentoOrigem => text().named('descricao_documento_origem').withLength(min: 0, max: 255).nullable()();
	TextColumn get operacao => text().named('operacao').withLength(min: 0, max: 1).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ViewFinMovimentoCaixaBancoGrouped {
	ViewFinMovimentoCaixaBanco? viewFinMovimentoCaixaBanco; 
	BancoContaCaixa? bancoContaCaixa; 

  ViewFinMovimentoCaixaBancoGrouped({
		this.viewFinMovimentoCaixaBanco, 
		this.bancoContaCaixa, 

  });
}
