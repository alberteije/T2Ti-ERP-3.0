// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_tipo_recebimento_dao.dart';

// ignore_for_file: type=lint
mixin _$FinTipoRecebimentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinTipoRecebimentosTable get finTipoRecebimentos =>
      attachedDatabase.finTipoRecebimentos;
}
