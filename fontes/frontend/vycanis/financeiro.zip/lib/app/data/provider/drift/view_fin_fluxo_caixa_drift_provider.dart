import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';
import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/data/provider/provider_base.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinFluxoCaixaDriftProvider extends ProviderBase {

	Future<List<ViewFinFluxoCaixaModel>?> getList({Filter? filter}) async {
		List<ViewFinFluxoCaixaGrouped> viewFinFluxoCaixaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				viewFinFluxoCaixaDriftList = await Session.database.viewFinFluxoCaixaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				viewFinFluxoCaixaDriftList = await Session.database.viewFinFluxoCaixaDao.getGroupedList(); 
			}
			if (viewFinFluxoCaixaDriftList.isNotEmpty) {
				return toListModel(viewFinFluxoCaixaDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ViewFinFluxoCaixaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.viewFinFluxoCaixaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinFluxoCaixaModel?>? insert(ViewFinFluxoCaixaModel viewFinFluxoCaixaModel) async {
		try {
			final lastPk = await Session.database.viewFinFluxoCaixaDao.insertObject(toDrift(viewFinFluxoCaixaModel));
			viewFinFluxoCaixaModel.id = lastPk;
			return viewFinFluxoCaixaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinFluxoCaixaModel?>? update(ViewFinFluxoCaixaModel viewFinFluxoCaixaModel) async {
		try {
			await Session.database.viewFinFluxoCaixaDao.updateObject(toDrift(viewFinFluxoCaixaModel));
			return viewFinFluxoCaixaModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.viewFinFluxoCaixaDao.deleteObject(toDrift(ViewFinFluxoCaixaModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ViewFinFluxoCaixaModel> toListModel(List<ViewFinFluxoCaixaGrouped> viewFinFluxoCaixaDriftList) {
		List<ViewFinFluxoCaixaModel> listModel = [];
		for (var viewFinFluxoCaixaDrift in viewFinFluxoCaixaDriftList) {
			listModel.add(toModel(viewFinFluxoCaixaDrift)!);
		}
		return listModel;
	}	

	ViewFinFluxoCaixaModel? toModel(ViewFinFluxoCaixaGrouped? viewFinFluxoCaixaDrift) {
		if (viewFinFluxoCaixaDrift != null) {
			return ViewFinFluxoCaixaModel(
				id: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.id,
				idBancoContaCaixa: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.idBancoContaCaixa,
				nomeContaCaixa: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.nomeContaCaixa,
				nomePessoa: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.nomePessoa,
				dataLancamento: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.dataLancamento,
				dataVencimento: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.dataVencimento,
				valor: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.valor,
				codigoSituacao: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.codigoSituacao,
				descricaoSituacao: viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.descricaoSituacao,
				operacao: ViewFinFluxoCaixaDomain.getOperacao(viewFinFluxoCaixaDrift.viewFinFluxoCaixa?.operacao),
				bancoContaCaixaModel: BancoContaCaixaModel(
					id: viewFinFluxoCaixaDrift.bancoContaCaixa?.id,
					idBancoAgencia: viewFinFluxoCaixaDrift.bancoContaCaixa?.idBancoAgencia,
					numero: viewFinFluxoCaixaDrift.bancoContaCaixa?.numero,
					digito: viewFinFluxoCaixaDrift.bancoContaCaixa?.digito,
					nome: viewFinFluxoCaixaDrift.bancoContaCaixa?.nome,
					tipo: viewFinFluxoCaixaDrift.bancoContaCaixa?.tipo,
					descricao: viewFinFluxoCaixaDrift.bancoContaCaixa?.descricao,
				),
			);
		} else {
			return null;
		}
	}


	ViewFinFluxoCaixaGrouped toDrift(ViewFinFluxoCaixaModel viewFinFluxoCaixaModel) {
		return ViewFinFluxoCaixaGrouped(
			viewFinFluxoCaixa: ViewFinFluxoCaixa(
				id: viewFinFluxoCaixaModel.id,
				idBancoContaCaixa: viewFinFluxoCaixaModel.idBancoContaCaixa,
				nomeContaCaixa: viewFinFluxoCaixaModel.nomeContaCaixa,
				nomePessoa: viewFinFluxoCaixaModel.nomePessoa,
				dataLancamento: viewFinFluxoCaixaModel.dataLancamento,
				dataVencimento: viewFinFluxoCaixaModel.dataVencimento,
				valor: viewFinFluxoCaixaModel.valor,
				codigoSituacao: viewFinFluxoCaixaModel.codigoSituacao,
				descricaoSituacao: viewFinFluxoCaixaModel.descricaoSituacao,
				operacao: ViewFinFluxoCaixaDomain.setOperacao(viewFinFluxoCaixaModel.operacao),
			),
		);
	}

		
}
