// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_tipo_pagamento_dao.dart';

// ignore_for_file: type=lint
mixin _$FinTipoPagamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinTipoPagamentosTable get finTipoPagamentos =>
      attachedDatabase.finTipoPagamentos;
}
