// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_fin_cheque_nao_compensado_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewFinChequeNaoCompensadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewFinChequeNaoCompensadosTable get viewFinChequeNaoCompensados =>
      attachedDatabase.viewFinChequeNaoCompensados;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
