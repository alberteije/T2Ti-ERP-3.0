// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_cheque_emitido_dao.dart';

// ignore_for_file: type=lint
mixin _$FinChequeEmitidoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinChequeEmitidosTable get finChequeEmitidos =>
      attachedDatabase.finChequeEmitidos;
  $ChequesTable get cheques => attachedDatabase.cheques;
}
