import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';

part 'view_fin_cheque_nao_compensado_dao.g.dart';

@DriftAccessor(tables: [
	ViewFinChequeNaoCompensados,
	BancoContaCaixas,
])
class ViewFinChequeNaoCompensadoDao extends DatabaseAccessor<AppDatabase> with _$ViewFinChequeNaoCompensadoDaoMixin {
	final AppDatabase db;

	List<ViewFinChequeNaoCompensado> viewFinChequeNaoCompensadoList = []; 
	List<ViewFinChequeNaoCompensadoGrouped> viewFinChequeNaoCompensadoGroupedList = []; 

	ViewFinChequeNaoCompensadoDao(this.db) : super(db);

	Future<List<ViewFinChequeNaoCompensado>> getList() async {
		viewFinChequeNaoCompensadoList = await select(viewFinChequeNaoCompensados).get();
		return viewFinChequeNaoCompensadoList;
	}

	Future<List<ViewFinChequeNaoCompensado>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		viewFinChequeNaoCompensadoList = await (select(viewFinChequeNaoCompensados)..where((t) => expression)).get();
		return viewFinChequeNaoCompensadoList;	 
	}

	Future<List<ViewFinChequeNaoCompensadoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(viewFinChequeNaoCompensados)
			.join([ 
				leftOuterJoin(bancoContaCaixas, bancoContaCaixas.id.equalsExp(viewFinChequeNaoCompensados.idBancoContaCaixa)), 
			]);

		if (field != null && field != '') { 
			final column = viewFinChequeNaoCompensados.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		viewFinChequeNaoCompensadoGroupedList = await query.map((row) {
			final viewFinChequeNaoCompensado = row.readTableOrNull(viewFinChequeNaoCompensados); 
			final bancoContaCaixa = row.readTableOrNull(bancoContaCaixas); 

			return ViewFinChequeNaoCompensadoGrouped(
				viewFinChequeNaoCompensado: viewFinChequeNaoCompensado, 
				bancoContaCaixa: bancoContaCaixa, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var viewFinChequeNaoCompensadoGrouped in viewFinChequeNaoCompensadoGroupedList) {
		//}		

		return viewFinChequeNaoCompensadoGroupedList;	
	}

	Future<ViewFinChequeNaoCompensado?> getObject(dynamic pk) async {
		return await (select(viewFinChequeNaoCompensados)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<ViewFinChequeNaoCompensado?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM view_fin_cheque_nao_compensado WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as ViewFinChequeNaoCompensado;		 
	} 

	Future<ViewFinChequeNaoCompensadoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(ViewFinChequeNaoCompensadoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.viewFinChequeNaoCompensado = object.viewFinChequeNaoCompensado!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(viewFinChequeNaoCompensados).insert(object.viewFinChequeNaoCompensado!);
			object.viewFinChequeNaoCompensado = object.viewFinChequeNaoCompensado!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(ViewFinChequeNaoCompensadoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(viewFinChequeNaoCompensados).replace(object.viewFinChequeNaoCompensado!);
		});	 
	} 

	Future<int> deleteObject(ViewFinChequeNaoCompensadoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(viewFinChequeNaoCompensados).delete(object.viewFinChequeNaoCompensado!);
		});		
	}

	Future<void> insertChildren(ViewFinChequeNaoCompensadoGrouped object) async {
	}
	
	Future<void> deleteChildren(ViewFinChequeNaoCompensadoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from view_fin_cheque_nao_compensado").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}