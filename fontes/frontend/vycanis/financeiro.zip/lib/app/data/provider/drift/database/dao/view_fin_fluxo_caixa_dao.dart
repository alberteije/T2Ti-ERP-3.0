import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';

part 'view_fin_fluxo_caixa_dao.g.dart';

@DriftAccessor(tables: [
	ViewFinFluxoCaixas,
	BancoContaCaixas,
])
class ViewFinFluxoCaixaDao extends DatabaseAccessor<AppDatabase> with _$ViewFinFluxoCaixaDaoMixin {
	final AppDatabase db;

	List<ViewFinFluxoCaixa> viewFinFluxoCaixaList = []; 
	List<ViewFinFluxoCaixaGrouped> viewFinFluxoCaixaGroupedList = []; 

	ViewFinFluxoCaixaDao(this.db) : super(db);

	Future<List<ViewFinFluxoCaixa>> getList() async {
		viewFinFluxoCaixaList = await select(viewFinFluxoCaixas).get();
		return viewFinFluxoCaixaList;
	}

	Future<List<ViewFinFluxoCaixa>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		viewFinFluxoCaixaList = await (select(viewFinFluxoCaixas)..where((t) => expression)).get();
		return viewFinFluxoCaixaList;	 
	}

	Future<List<ViewFinFluxoCaixaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(viewFinFluxoCaixas)
			.join([ 
				leftOuterJoin(bancoContaCaixas, bancoContaCaixas.id.equalsExp(viewFinFluxoCaixas.idBancoContaCaixa)), 
			]);

		if (field != null && field != '') { 
			final column = viewFinFluxoCaixas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		viewFinFluxoCaixaGroupedList = await query.map((row) {
			final viewFinFluxoCaixa = row.readTableOrNull(viewFinFluxoCaixas); 
			final bancoContaCaixa = row.readTableOrNull(bancoContaCaixas); 

			return ViewFinFluxoCaixaGrouped(
				viewFinFluxoCaixa: viewFinFluxoCaixa, 
				bancoContaCaixa: bancoContaCaixa, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var viewFinFluxoCaixaGrouped in viewFinFluxoCaixaGroupedList) {
		//}		

		return viewFinFluxoCaixaGroupedList;	
	}

	Future<ViewFinFluxoCaixa?> getObject(dynamic pk) async {
		return await (select(viewFinFluxoCaixas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<ViewFinFluxoCaixa?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM view_fin_fluxo_caixa WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as ViewFinFluxoCaixa;		 
	} 

	Future<ViewFinFluxoCaixaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(ViewFinFluxoCaixaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.viewFinFluxoCaixa = object.viewFinFluxoCaixa!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(viewFinFluxoCaixas).insert(object.viewFinFluxoCaixa!);
			object.viewFinFluxoCaixa = object.viewFinFluxoCaixa!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(ViewFinFluxoCaixaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(viewFinFluxoCaixas).replace(object.viewFinFluxoCaixa!);
		});	 
	} 

	Future<int> deleteObject(ViewFinFluxoCaixaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(viewFinFluxoCaixas).delete(object.viewFinFluxoCaixa!);
		});		
	}

	Future<void> insertChildren(ViewFinFluxoCaixaGrouped object) async {
	}
	
	Future<void> deleteChildren(ViewFinFluxoCaixaGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from view_fin_fluxo_caixa").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}