// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_lancamento_pagar_dao.dart';

// ignore_for_file: type=lint
mixin _$FinLancamentoPagarDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinLancamentoPagarsTable get finLancamentoPagars =>
      attachedDatabase.finLancamentoPagars;
  $FinParcelaPagarsTable get finParcelaPagars =>
      attachedDatabase.finParcelaPagars;
  $FinStatusParcelasTable get finStatusParcelas =>
      attachedDatabase.finStatusParcelas;
  $FinTipoPagamentosTable get finTipoPagamentos =>
      attachedDatabase.finTipoPagamentos;
  $FinDocumentoOrigemsTable get finDocumentoOrigems =>
      attachedDatabase.finDocumentoOrigems;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
}
