import 'dart:convert';
import 'package:financeiro/app/data/provider/api/api_provider_base.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ViewFinChequeNaoCompensadoApiProvider extends ApiProviderBase {

	Future<List<ViewFinChequeNaoCompensadoModel>?> getList({Filter? filter}) async {
		List<ViewFinChequeNaoCompensadoModel> viewFinChequeNaoCompensadoModelList = [];

		try {
			handleFilter(filter, '/view-fin-cheque-nao-compensado/');
			
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse(url)!, headers: ApiProviderBase.headerRequisition());

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinChequeNaoCompensadoModelJson = json.decode(response.body) as List<dynamic>;
					for (var viewFinChequeNaoCompensadoModel in viewFinChequeNaoCompensadoModelJson) {
						viewFinChequeNaoCompensadoModelList.add(ViewFinChequeNaoCompensadoModel.fromJson(viewFinChequeNaoCompensadoModel));
					}
					return viewFinChequeNaoCompensadoModelList;
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ViewFinChequeNaoCompensadoModel?> getObject(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.get(Uri.tryParse('$endpoint/view-fin-cheque-nao-compensado/$pk')!, headers: ApiProviderBase.headerRequisition());

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinChequeNaoCompensadoModelJson = json.decode(response.body);
					return ViewFinChequeNaoCompensadoModel.fromJson(viewFinChequeNaoCompensadoModelJson);		 
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinChequeNaoCompensadoModel?>? insert(ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel) async {
		try {
			final response = await ApiProviderBase.httpClient.post(
				Uri.tryParse('$endpoint/view-fin-cheque-nao-compensado')!,
				headers: ApiProviderBase.headerRequisition(),
				body: viewFinChequeNaoCompensadoModel.objectEncodeJson(),
			);

			if (response.statusCode == 200 || response.statusCode == 201) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinChequeNaoCompensadoModelJson = json.decode(response.body);
					return ViewFinChequeNaoCompensadoModel.fromJson(viewFinChequeNaoCompensadoModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinChequeNaoCompensadoModel?>? update(ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel) async {
		try {
			final response = await ApiProviderBase.httpClient.put(
				Uri.tryParse('$endpoint/view-fin-cheque-nao-compensado')!,
				headers: ApiProviderBase.headerRequisition(),
				body: viewFinChequeNaoCompensadoModel.objectEncodeJson(),
			);

			if (response.statusCode == 200) {
				if (response.headers["content-type"]!.contains("html")) {
					handleResultError(response.body, response.headers);
					return null;
				} else {
					var viewFinChequeNaoCompensadoModelJson = json.decode(response.body);
					return ViewFinChequeNaoCompensadoModel.fromJson(viewFinChequeNaoCompensadoModelJson);
				}
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			final response = await ApiProviderBase.httpClient.delete(
				Uri.tryParse('$endpoint/view-fin-cheque-nao-compensado/$pk')!,
				headers: ApiProviderBase.headerRequisition(),
			);

			if (response.statusCode == 200) {
				return true;
			} else {
				handleResultError(response.body, response.headers);
				return null;
			}
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	
}
