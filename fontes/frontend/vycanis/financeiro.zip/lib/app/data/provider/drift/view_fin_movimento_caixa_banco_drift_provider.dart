import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';
import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/data/provider/provider_base.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinMovimentoCaixaBancoDriftProvider extends ProviderBase {

	Future<List<ViewFinMovimentoCaixaBancoModel>?> getList({Filter? filter}) async {
		List<ViewFinMovimentoCaixaBancoGrouped> viewFinMovimentoCaixaBancoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				viewFinMovimentoCaixaBancoDriftList = await Session.database.viewFinMovimentoCaixaBancoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				viewFinMovimentoCaixaBancoDriftList = await Session.database.viewFinMovimentoCaixaBancoDao.getGroupedList(); 
			}
			if (viewFinMovimentoCaixaBancoDriftList.isNotEmpty) {
				return toListModel(viewFinMovimentoCaixaBancoDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ViewFinMovimentoCaixaBancoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.viewFinMovimentoCaixaBancoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinMovimentoCaixaBancoModel?>? insert(ViewFinMovimentoCaixaBancoModel viewFinMovimentoCaixaBancoModel) async {
		try {
			final lastPk = await Session.database.viewFinMovimentoCaixaBancoDao.insertObject(toDrift(viewFinMovimentoCaixaBancoModel));
			viewFinMovimentoCaixaBancoModel.id = lastPk;
			return viewFinMovimentoCaixaBancoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinMovimentoCaixaBancoModel?>? update(ViewFinMovimentoCaixaBancoModel viewFinMovimentoCaixaBancoModel) async {
		try {
			await Session.database.viewFinMovimentoCaixaBancoDao.updateObject(toDrift(viewFinMovimentoCaixaBancoModel));
			return viewFinMovimentoCaixaBancoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.viewFinMovimentoCaixaBancoDao.deleteObject(toDrift(ViewFinMovimentoCaixaBancoModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ViewFinMovimentoCaixaBancoModel> toListModel(List<ViewFinMovimentoCaixaBancoGrouped> viewFinMovimentoCaixaBancoDriftList) {
		List<ViewFinMovimentoCaixaBancoModel> listModel = [];
		for (var viewFinMovimentoCaixaBancoDrift in viewFinMovimentoCaixaBancoDriftList) {
			listModel.add(toModel(viewFinMovimentoCaixaBancoDrift)!);
		}
		return listModel;
	}	

	ViewFinMovimentoCaixaBancoModel? toModel(ViewFinMovimentoCaixaBancoGrouped? viewFinMovimentoCaixaBancoDrift) {
		if (viewFinMovimentoCaixaBancoDrift != null) {
			return ViewFinMovimentoCaixaBancoModel(
				id: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.id,
				idBancoContaCaixa: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.idBancoContaCaixa,
				nomeContaCaixa: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.nomeContaCaixa,
				nomePessoa: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.nomePessoa,
				dataLancamento: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.dataLancamento,
				dataPagoRecebido: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.dataPagoRecebido,
				mesAno: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.mesAno,
				historico: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.historico,
				valor: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.valor,
				descricaoDocumentoOrigem: viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.descricaoDocumentoOrigem,
				operacao: ViewFinMovimentoCaixaBancoDomain.getOperacao(viewFinMovimentoCaixaBancoDrift.viewFinMovimentoCaixaBanco?.operacao),
				bancoContaCaixaModel: BancoContaCaixaModel(
					id: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.id,
					idBancoAgencia: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.idBancoAgencia,
					numero: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.numero,
					digito: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.digito,
					nome: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.nome,
					tipo: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.tipo,
					descricao: viewFinMovimentoCaixaBancoDrift.bancoContaCaixa?.descricao,
				),
			);
		} else {
			return null;
		}
	}


	ViewFinMovimentoCaixaBancoGrouped toDrift(ViewFinMovimentoCaixaBancoModel viewFinMovimentoCaixaBancoModel) {
		return ViewFinMovimentoCaixaBancoGrouped(
			viewFinMovimentoCaixaBanco: ViewFinMovimentoCaixaBanco(
				id: viewFinMovimentoCaixaBancoModel.id,
				idBancoContaCaixa: viewFinMovimentoCaixaBancoModel.idBancoContaCaixa,
				nomeContaCaixa: viewFinMovimentoCaixaBancoModel.nomeContaCaixa,
				nomePessoa: viewFinMovimentoCaixaBancoModel.nomePessoa,
				dataLancamento: viewFinMovimentoCaixaBancoModel.dataLancamento,
				dataPagoRecebido: viewFinMovimentoCaixaBancoModel.dataPagoRecebido,
				mesAno: viewFinMovimentoCaixaBancoModel.mesAno,
				historico: viewFinMovimentoCaixaBancoModel.historico,
				valor: viewFinMovimentoCaixaBancoModel.valor,
				descricaoDocumentoOrigem: viewFinMovimentoCaixaBancoModel.descricaoDocumentoOrigem,
				operacao: ViewFinMovimentoCaixaBancoDomain.setOperacao(viewFinMovimentoCaixaBancoModel.operacao),
			),
		);
	}

		
}
