import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';

part 'view_fin_movimento_caixa_banco_dao.g.dart';

@DriftAccessor(tables: [
	ViewFinMovimentoCaixaBancos,
	BancoContaCaixas,
])
class ViewFinMovimentoCaixaBancoDao extends DatabaseAccessor<AppDatabase> with _$ViewFinMovimentoCaixaBancoDaoMixin {
	final AppDatabase db;

	List<ViewFinMovimentoCaixaBanco> viewFinMovimentoCaixaBancoList = []; 
	List<ViewFinMovimentoCaixaBancoGrouped> viewFinMovimentoCaixaBancoGroupedList = []; 

	ViewFinMovimentoCaixaBancoDao(this.db) : super(db);

	Future<List<ViewFinMovimentoCaixaBanco>> getList() async {
		viewFinMovimentoCaixaBancoList = await select(viewFinMovimentoCaixaBancos).get();
		return viewFinMovimentoCaixaBancoList;
	}

	Future<List<ViewFinMovimentoCaixaBanco>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		viewFinMovimentoCaixaBancoList = await (select(viewFinMovimentoCaixaBancos)..where((t) => expression)).get();
		return viewFinMovimentoCaixaBancoList;	 
	}

	Future<List<ViewFinMovimentoCaixaBancoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(viewFinMovimentoCaixaBancos)
			.join([ 
				leftOuterJoin(bancoContaCaixas, bancoContaCaixas.id.equalsExp(viewFinMovimentoCaixaBancos.idBancoContaCaixa)), 
			]);

		if (field != null && field != '') { 
			final column = viewFinMovimentoCaixaBancos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		viewFinMovimentoCaixaBancoGroupedList = await query.map((row) {
			final viewFinMovimentoCaixaBanco = row.readTableOrNull(viewFinMovimentoCaixaBancos); 
			final bancoContaCaixa = row.readTableOrNull(bancoContaCaixas); 

			return ViewFinMovimentoCaixaBancoGrouped(
				viewFinMovimentoCaixaBanco: viewFinMovimentoCaixaBanco, 
				bancoContaCaixa: bancoContaCaixa, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var viewFinMovimentoCaixaBancoGrouped in viewFinMovimentoCaixaBancoGroupedList) {
		//}		

		return viewFinMovimentoCaixaBancoGroupedList;	
	}

	Future<ViewFinMovimentoCaixaBanco?> getObject(dynamic pk) async {
		return await (select(viewFinMovimentoCaixaBancos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<ViewFinMovimentoCaixaBanco?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM view_fin_movimento_caixa_banco WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as ViewFinMovimentoCaixaBanco;		 
	} 

	Future<ViewFinMovimentoCaixaBancoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(ViewFinMovimentoCaixaBancoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.viewFinMovimentoCaixaBanco = object.viewFinMovimentoCaixaBanco!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(viewFinMovimentoCaixaBancos).insert(object.viewFinMovimentoCaixaBanco!);
			object.viewFinMovimentoCaixaBanco = object.viewFinMovimentoCaixaBanco!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(ViewFinMovimentoCaixaBancoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(viewFinMovimentoCaixaBancos).replace(object.viewFinMovimentoCaixaBanco!);
		});	 
	} 

	Future<int> deleteObject(ViewFinMovimentoCaixaBancoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(viewFinMovimentoCaixaBancos).delete(object.viewFinMovimentoCaixaBanco!);
		});		
	}

	Future<void> insertChildren(ViewFinMovimentoCaixaBancoGrouped object) async {
	}
	
	Future<void> deleteChildren(ViewFinMovimentoCaixaBancoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from view_fin_movimento_caixa_banco").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}