// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_fechamento_caixa_banco_dao.dart';

// ignore_for_file: type=lint
mixin _$FinFechamentoCaixaBancoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinFechamentoCaixaBancosTable get finFechamentoCaixaBancos =>
      attachedDatabase.finFechamentoCaixaBancos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
