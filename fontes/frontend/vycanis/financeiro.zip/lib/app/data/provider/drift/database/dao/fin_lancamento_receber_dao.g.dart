// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_lancamento_receber_dao.dart';

// ignore_for_file: type=lint
mixin _$FinLancamentoReceberDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinLancamentoRecebersTable get finLancamentoRecebers =>
      attachedDatabase.finLancamentoRecebers;
  $FinParcelaRecebersTable get finParcelaRecebers =>
      attachedDatabase.finParcelaRecebers;
  $FinStatusParcelasTable get finStatusParcelas =>
      attachedDatabase.finStatusParcelas;
  $FinTipoRecebimentosTable get finTipoRecebimentos =>
      attachedDatabase.finTipoRecebimentos;
  $FinDocumentoOrigemsTable get finDocumentoOrigems =>
      attachedDatabase.finDocumentoOrigems;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
