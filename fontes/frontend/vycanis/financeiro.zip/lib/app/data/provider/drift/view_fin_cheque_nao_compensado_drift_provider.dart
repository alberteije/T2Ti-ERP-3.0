import 'package:financeiro/app/data/provider/drift/database/database_imports.dart';
import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/data/provider/provider_base.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinChequeNaoCompensadoDriftProvider extends ProviderBase {

	Future<List<ViewFinChequeNaoCompensadoModel>?> getList({Filter? filter}) async {
		List<ViewFinChequeNaoCompensadoGrouped> viewFinChequeNaoCompensadoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				viewFinChequeNaoCompensadoDriftList = await Session.database.viewFinChequeNaoCompensadoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				viewFinChequeNaoCompensadoDriftList = await Session.database.viewFinChequeNaoCompensadoDao.getGroupedList(); 
			}
			if (viewFinChequeNaoCompensadoDriftList.isNotEmpty) {
				return toListModel(viewFinChequeNaoCompensadoDriftList);
			} else {
				return [];
			}			 
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ViewFinChequeNaoCompensadoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.viewFinChequeNaoCompensadoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinChequeNaoCompensadoModel?>? insert(ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel) async {
		try {
			final lastPk = await Session.database.viewFinChequeNaoCompensadoDao.insertObject(toDrift(viewFinChequeNaoCompensadoModel));
			viewFinChequeNaoCompensadoModel.id = lastPk;
			return viewFinChequeNaoCompensadoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ViewFinChequeNaoCompensadoModel?>? update(ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel) async {
		try {
			await Session.database.viewFinChequeNaoCompensadoDao.updateObject(toDrift(viewFinChequeNaoCompensadoModel));
			return viewFinChequeNaoCompensadoModel;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.viewFinChequeNaoCompensadoDao.deleteObject(toDrift(ViewFinChequeNaoCompensadoModel(id: pk)));
			return true;
		} on Exception catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ViewFinChequeNaoCompensadoModel> toListModel(List<ViewFinChequeNaoCompensadoGrouped> viewFinChequeNaoCompensadoDriftList) {
		List<ViewFinChequeNaoCompensadoModel> listModel = [];
		for (var viewFinChequeNaoCompensadoDrift in viewFinChequeNaoCompensadoDriftList) {
			listModel.add(toModel(viewFinChequeNaoCompensadoDrift)!);
		}
		return listModel;
	}	

	ViewFinChequeNaoCompensadoModel? toModel(ViewFinChequeNaoCompensadoGrouped? viewFinChequeNaoCompensadoDrift) {
		if (viewFinChequeNaoCompensadoDrift != null) {
			return ViewFinChequeNaoCompensadoModel(
				id: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.id,
				idBancoContaCaixa: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.idBancoContaCaixa,
				nomeContaCaixa: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.nomeContaCaixa,
				talao: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.talao,
				numeroTalao: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.numeroTalao,
				numeroCheque: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.numeroCheque,
				statusCheque: ViewFinChequeNaoCompensadoDomain.getStatusCheque(viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.statusCheque),
				dataStatus: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.dataStatus,
				valor: viewFinChequeNaoCompensadoDrift.viewFinChequeNaoCompensado?.valor,
				bancoContaCaixaModel: BancoContaCaixaModel(
					id: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.id,
					idBancoAgencia: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.idBancoAgencia,
					numero: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.numero,
					digito: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.digito,
					nome: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.nome,
					tipo: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.tipo,
					descricao: viewFinChequeNaoCompensadoDrift.bancoContaCaixa?.descricao,
				),
			);
		} else {
			return null;
		}
	}


	ViewFinChequeNaoCompensadoGrouped toDrift(ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel) {
		return ViewFinChequeNaoCompensadoGrouped(
			viewFinChequeNaoCompensado: ViewFinChequeNaoCompensado(
				id: viewFinChequeNaoCompensadoModel.id,
				idBancoContaCaixa: viewFinChequeNaoCompensadoModel.idBancoContaCaixa,
				nomeContaCaixa: viewFinChequeNaoCompensadoModel.nomeContaCaixa,
				talao: viewFinChequeNaoCompensadoModel.talao,
				numeroTalao: viewFinChequeNaoCompensadoModel.numeroTalao,
				numeroCheque: viewFinChequeNaoCompensadoModel.numeroCheque,
				statusCheque: ViewFinChequeNaoCompensadoDomain.setStatusCheque(viewFinChequeNaoCompensadoModel.statusCheque),
				dataStatus: viewFinChequeNaoCompensadoModel.dataStatus,
				valor: viewFinChequeNaoCompensadoModel.valor,
			),
		);
	}

		
}
