// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'talonario_cheque_dao.dart';

// ignore_for_file: type=lint
mixin _$TalonarioChequeDaoMixin on DatabaseAccessor<AppDatabase> {
  $TalonarioChequesTable get talonarioCheques =>
      attachedDatabase.talonarioCheques;
  $ChequesTable get cheques => attachedDatabase.cheques;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
