import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';

@DataClassName("ViewFinFluxoCaixa")
class ViewFinFluxoCaixas extends Table {
	@override
	String get tableName => 'view_fin_fluxo_caixa';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBancoContaCaixa => integer().named('id_banco_conta_caixa').nullable()();
	TextColumn get nomeContaCaixa => text().named('nome_conta_caixa').withLength(min: 0, max: 255).nullable()();
	TextColumn get nomePessoa => text().named('nome_pessoa').withLength(min: 0, max: 255).nullable()();
	DateTimeColumn get dataLancamento => dateTime().named('data_lancamento').nullable()();
	DateTimeColumn get dataVencimento => dateTime().named('data_vencimento').nullable()();
	RealColumn get valor => real().named('valor').nullable()();
	TextColumn get codigoSituacao => text().named('codigo_situacao').withLength(min: 0, max: 10).nullable()();
	TextColumn get descricaoSituacao => text().named('descricao_situacao').withLength(min: 0, max: 255).nullable()();
	TextColumn get operacao => text().named('operacao').withLength(min: 0, max: 1).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ViewFinFluxoCaixaGrouped {
	ViewFinFluxoCaixa? viewFinFluxoCaixa; 
	BancoContaCaixa? bancoContaCaixa; 

  ViewFinFluxoCaixaGrouped({
		this.viewFinFluxoCaixa, 
		this.bancoContaCaixa, 

  });
}
