import 'package:drift/drift.dart';
import 'package:financeiro/app/data/provider/drift/database/database.dart';

@DataClassName("ViewFinChequeNaoCompensado")
class ViewFinChequeNaoCompensados extends Table {
	@override
	String get tableName => 'view_fin_cheque_nao_compensado';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBancoContaCaixa => integer().named('id_banco_conta_caixa').nullable()();
	TextColumn get nomeContaCaixa => text().named('nome_conta_caixa').withLength(min: 0, max: 255).nullable()();
	TextColumn get talao => text().named('talao').withLength(min: 0, max: 50).nullable()();
	TextColumn get numeroTalao => text().named('numero_talao').withLength(min: 0, max: 50).nullable()();
	TextColumn get numeroCheque => text().named('numero_cheque').withLength(min: 0, max: 50).nullable()();
	TextColumn get statusCheque => text().named('status_cheque').withLength(min: 0, max: 1).nullable()();
	DateTimeColumn get dataStatus => dateTime().named('data_status').nullable()();
	RealColumn get valor => real().named('valor').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ViewFinChequeNaoCompensadoGrouped {
	ViewFinChequeNaoCompensado? viewFinChequeNaoCompensado; 
	BancoContaCaixa? bancoContaCaixa; 

  ViewFinChequeNaoCompensadoGrouped({
		this.viewFinChequeNaoCompensado, 
		this.bancoContaCaixa, 

  });
}
