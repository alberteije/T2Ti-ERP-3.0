// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_fin_fluxo_caixa_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewFinFluxoCaixaDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewFinFluxoCaixasTable get viewFinFluxoCaixas =>
      attachedDatabase.viewFinFluxoCaixas;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
