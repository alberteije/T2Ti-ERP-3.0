// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_fin_movimento_caixa_banco_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewFinMovimentoCaixaBancoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewFinMovimentoCaixaBancosTable get viewFinMovimentoCaixaBancos =>
      attachedDatabase.viewFinMovimentoCaixaBancos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
