// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_cheque_recebido_dao.dart';

// ignore_for_file: type=lint
mixin _$FinChequeRecebidoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinChequeRecebidosTable get finChequeRecebidos =>
      attachedDatabase.finChequeRecebidos;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
