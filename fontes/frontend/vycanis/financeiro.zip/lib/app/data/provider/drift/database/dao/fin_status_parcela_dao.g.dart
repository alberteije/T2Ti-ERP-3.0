// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_status_parcela_dao.dart';

// ignore_for_file: type=lint
mixin _$FinStatusParcelaDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinStatusParcelasTable get finStatusParcelas =>
      attachedDatabase.finStatusParcelas;
}
