abstract class Routes {
  static const splashPage = '/splashPage';
  static const loginPage = '/loginPage';
  static const homePage = '/homePage';
  static const filterPage = '/filterPage';
  static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';

  static const talonarioChequeListPage = '/talonarioChequeListPage';
  static const talonarioChequeTabPage = '/talonarioChequeTabPage';
  static const finLancamentoPagarListPage = '/finLancamentoPagarListPage';
  static const finLancamentoPagarTabPage = '/finLancamentoPagarTabPage';
  static const finLancamentoReceberListPage = '/finLancamentoReceberListPage';
  static const finLancamentoReceberTabPage = '/finLancamentoReceberTabPage';
  static const bancoContaCaixaListPage = '/bancoContaCaixaListPage';
  static const bancoContaCaixaEditPage = '/bancoContaCaixaEditPage';
  static const finFechamentoCaixaBancoListPage = '/finFechamentoCaixaBancoListPage';
  static const finExtratoContaBancoListPage = '/finExtratoContaBancoListPage';
  static const finDocumentoOrigemListPage = '/finDocumentoOrigemListPage';
  static const finDocumentoOrigemEditPage = '/finDocumentoOrigemEditPage';
  static const finNaturezaFinanceiraListPage = '/finNaturezaFinanceiraListPage';
  static const finNaturezaFinanceiraEditPage = '/finNaturezaFinanceiraEditPage';
  static const finStatusParcelaListPage = '/finStatusParcelaListPage';
  static const finStatusParcelaEditPage = '/finStatusParcelaEditPage';
  static const finTipoPagamentoListPage = '/finTipoPagamentoListPage';
  static const finTipoPagamentoEditPage = '/finTipoPagamentoEditPage';
  static const finChequeEmitidoListPage = '/finChequeEmitidoListPage';
  static const finChequeEmitidoEditPage = '/finChequeEmitidoEditPage';
  static const finTipoRecebimentoListPage = '/finTipoRecebimentoListPage';
  static const finTipoRecebimentoEditPage = '/finTipoRecebimentoEditPage';
  static const finChequeRecebidoListPage = '/finChequeRecebidoListPage';
  static const finChequeRecebidoEditPage = '/finChequeRecebidoEditPage';
  static const finConfiguracaoBoletoListPage = '/finConfiguracaoBoletoListPage';
  static const finConfiguracaoBoletoEditPage = '/finConfiguracaoBoletoEditPage';
  static const viewFinMovimentoCaixaBancoListPage = '/viewFinMovimentoCaixaBancoListPage';
  static const viewFinFluxoCaixaListPage = '/viewFinFluxoCaixaListPage';
  static const resumoTesourariaListPage = '/resumoTesourariaListPage';
}
