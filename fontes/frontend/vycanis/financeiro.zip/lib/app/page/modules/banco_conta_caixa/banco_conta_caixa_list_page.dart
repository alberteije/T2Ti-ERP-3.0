import 'package:flutter/material.dart';
import 'package:financeiro/app/controller/banco_conta_caixa_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class BancoContaCaixaListPage extends ListPageBase<BancoContaCaixaController> {
  const BancoContaCaixaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> additionalAppBarActions() {
    return [
      IconButton(
        tooltip: 'Extrato Bancário / Conciliação',
        icon: const Icon(Icons.account_balance_wallet),
        color: Colors.lime,
        onPressed: controller.showExtratoBancarioPage,
      ),
      IconButton(
        tooltip: 'Movimento Bancário',
        icon: const Icon(Icons.money),
        color: Colors.lime,
        onPressed: controller.showMovimentoBancarioPage,
      ),
      const SizedBox(width: 20,),
      IconButton(
        tooltip: 'Fluxo de Caixa',
        icon: const Icon(Icons.bar_chart),
        color: Colors.blue,
        onPressed: controller.showFluxoCaixaPage,
      ),
      IconButton(
        tooltip: 'Tesouraria',
        icon: const Icon(Icons.attach_money_outlined),
        color: Colors.blue,
        onPressed: controller.showResumoTesourariaPage,
      ),
      const SizedBox(width: 20,),
    ];
  }
}