import 'package:flutter/material.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';
import 'package:financeiro/app/page/shared_widget/shared_widget_imports.dart';
import 'package:financeiro/app/controller/fin_parcela_receber_controller.dart';

class FinParcelaReceberListPage extends ListPageBase<FinParcelaReceberController> {
  const FinParcelaReceberListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> standardAppBarActions() { 
    return [];
  }

  @override
  List<Widget> standardBottomActions() { 
    return [
      editButton(onPressed: controller.canUpdate ? controller.editSelectedItem : controller.noPrivilegeMessage),
      deleteButton(onPressed: controller.canDelete ? controller.deleteSelected : controller.noPrivilegeMessage),
      IconButton(
        tooltip: 'Emitir Boleto',
        icon: const Icon(Icons.print),
        onPressed: controller.emitirBoleto,
      )
    ];
  }

  @override
  PreferredSizeWidget? appBar() { 
    return null;
  }
}