import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/page/shared_widget/input/input_imports.dart';
import 'package:financeiro/app/page/shared_widget/shared_widget_imports.dart';
import 'package:financeiro/app/controller/view_fin_fluxo_caixa_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class ViewFinFluxoCaixaListPage extends ListPageBase<ViewFinFluxoCaixaController> {
  const ViewFinFluxoCaixaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  Widget buildMobileView() {
    return buildDesktopView();
  }

  @override
  Widget buildDesktopView() {
    final additionalContentBottom = buildAdditionalContentBottom();

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(controller.screenTitle), actions: [...additionalAppBarActions(), exitButton(), const SizedBox(height: 10, width: 5)]),
      bottomNavigationBar: BottomAppBar(color: Colors.black26, shape: const CircularNotchedRectangle(), height: 70, child: Row(children: [...additionalBottomActions()])),
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          children: [
            Expanded(
              child: PlutoGrid(
                mode: PlutoGridMode.readOnly,
                configuration: gridConfiguration(),
                noRowsWidget: Text('grid_no_rows'.tr),
                columns: controller.gridColumns,
                rows: controller.plutoRows(),
                onLoaded: (event) {
                  controller.plutoGridStateManager = event.stateManager;
                  controller.plutoGridStateManager.setSelectingMode(PlutoGridSelectingMode.row);
                  controller.keyboardListener = controller.plutoGridStateManager.keyManager!.subject.stream.listen(controller.handleKeyboard);
                  controller.loadData();
                },
              ),
            ),
            additionalContentBottom,
          ],
        ),
      ),
    );
  }

  @override
  List<Widget> additionalAppBarActions() {
    return [];
  }

  @override
  List<Widget> additionalBottomActions() {
    return [
      Expanded(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: InputDecorator(
            decoration: inputDecoration(hintText: 'Data início', labelText: 'Data início', usePadding: true, color: Colors.white),
            isEmpty: false,
            child: DatePickerItem(
              dateTime: controller.initialDate,
              firstDate: DateTime.parse('1000-01-01'),
              lastDate: DateTime.parse('5000-01-01'),
              onChanged: (DateTime? value) async {
                controller.initialDate = value!;
                await controller.loadData();
              },
            ),
          ),
        ),
      ),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: InputDecorator(
            decoration: inputDecoration(hintText: 'Data fim', labelText: 'Data fim', usePadding: true, color: Colors.white),
            isEmpty: false,
            child: DatePickerItem(
              dateTime: controller.finalDate,
              firstDate: DateTime.parse('1000-01-01'),
              lastDate: DateTime.parse('5000-01-01'),
              onChanged: (DateTime? value) async {
                controller.finalDate = value!;
                await controller.loadData();
              },
            ),
          ),
        ),
      ),
    ];
  }

  @override
  Widget buildAdditionalContentBottom() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 20.0),
      color: Colors.black,
      alignment: Alignment.center,
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Obx(() => Text("A Receber: ${Util.moneyFormat(controller.creditos)}", style: const TextStyle(color: Colors.white))),
            const SizedBox(width: 16),
            Obx(() => Text("A Pagar: ${Util.moneyFormat(controller.debitos)}", style: const TextStyle(color: Colors.white))),
            const SizedBox(width: 16),
            Obx(() => Text("Saldo: ${Util.moneyFormat(controller.saldo)}", style: const TextStyle(color: Colors.white))),
          ],
        ),
      ),
    );
  }
}
