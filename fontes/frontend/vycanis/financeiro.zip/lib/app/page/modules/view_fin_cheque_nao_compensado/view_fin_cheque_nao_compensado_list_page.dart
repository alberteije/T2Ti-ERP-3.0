import 'package:flutter/material.dart';
import 'package:financeiro/app/controller/view_fin_cheque_nao_compensado_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class ViewFinChequeNaoCompensadoListPage extends ListPageBase<ViewFinChequeNaoCompensadoController> {
  const ViewFinChequeNaoCompensadoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}