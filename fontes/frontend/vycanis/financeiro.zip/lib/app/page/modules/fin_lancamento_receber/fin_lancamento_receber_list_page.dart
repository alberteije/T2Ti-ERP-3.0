import 'package:flutter/material.dart';
import 'package:financeiro/app/controller/fin_lancamento_receber_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class FinLancamentoReceberListPage extends ListPageBase<FinLancamentoReceberController> {
  const FinLancamentoReceberListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}