import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/page/shared_widget/shared_widget_imports.dart';
import 'package:financeiro/app/controller/fin_cheque_emitido_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class FinChequeEmitidoListPage extends ListPageBase<FinChequeEmitidoController> {
  const FinChequeEmitidoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  Widget buildMobileView() {
    return buildDesktopView();
  }

  @override
  Widget buildDesktopView() {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(controller.screenTitle),
        actions: [
          exitButton(),
          const SizedBox(
            height: 10,
            width: 5,
          )
        ],
      ),
      bottomNavigationBar: const BottomAppBar(
        color: Colors.black26,
        shape: CircularNotchedRectangle(),
        child: Row(children: [
        ]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          children: [
            Expanded(
              child: PlutoGrid(
                mode: PlutoGridMode.readOnly,
                configuration: gridConfiguration(),
                noRowsWidget: Text('grid_no_rows'.tr),
                columns: controller.gridColumns,
                rows: controller.plutoRows(),
                onLoaded: (event) {
                  controller.plutoGridStateManager = event.stateManager;
                  controller.plutoGridStateManager.setSelectingMode(PlutoGridSelectingMode.row);
                  controller.keyboardListener = controller.plutoGridStateManager.keyManager!.subject.stream.listen(controller.handleKeyboard);
                  controller.loadData();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

}