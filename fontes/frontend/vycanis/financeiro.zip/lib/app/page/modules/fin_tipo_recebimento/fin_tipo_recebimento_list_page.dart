import 'package:flutter/material.dart';
import 'package:financeiro/app/controller/fin_tipo_recebimento_controller.dart';
import 'package:financeiro/app/page/shared_page/list_page_base.dart';

class FinTipoRecebimentoListPage extends ListPageBase<FinTipoRecebimentoController> {
  const FinTipoRecebimentoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}