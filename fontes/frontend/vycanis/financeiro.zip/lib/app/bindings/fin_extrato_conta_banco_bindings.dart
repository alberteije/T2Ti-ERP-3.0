import 'package:get/get.dart';
import 'package:financeiro/app/controller/fin_extrato_conta_banco_controller.dart';
import 'package:financeiro/app/data/provider/api/fin_extrato_conta_banco_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/fin_extrato_conta_banco_drift_provider.dart';
import 'package:financeiro/app/data/repository/fin_extrato_conta_banco_repository.dart';

class FinExtratoContaBancoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FinExtratoContaBancoController>(() => FinExtratoContaBancoController(
					repository: FinExtratoContaBancoRepository(finExtratoContaBancoApiProvider: FinExtratoContaBancoApiProvider(), finExtratoContaBancoDriftProvider: FinExtratoContaBancoDriftProvider()))),
		];
	}
}
