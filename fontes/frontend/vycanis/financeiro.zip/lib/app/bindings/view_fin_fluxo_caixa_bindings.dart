import 'package:get/get.dart';
import 'package:financeiro/app/controller/view_fin_fluxo_caixa_controller.dart';
import 'package:financeiro/app/data/provider/api/view_fin_fluxo_caixa_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_fluxo_caixa_drift_provider.dart';
import 'package:financeiro/app/data/repository/view_fin_fluxo_caixa_repository.dart';

class ViewFinFluxoCaixaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ViewFinFluxoCaixaController>(() => ViewFinFluxoCaixaController(
					repository: ViewFinFluxoCaixaRepository(viewFinFluxoCaixaApiProvider: ViewFinFluxoCaixaApiProvider(), viewFinFluxoCaixaDriftProvider: ViewFinFluxoCaixaDriftProvider()))),
		];
	}
}
