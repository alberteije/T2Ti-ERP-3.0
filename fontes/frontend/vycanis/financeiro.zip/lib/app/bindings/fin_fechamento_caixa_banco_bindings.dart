import 'package:get/get.dart';
import 'package:financeiro/app/controller/fin_fechamento_caixa_banco_controller.dart';
import 'package:financeiro/app/data/provider/api/fin_fechamento_caixa_banco_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/fin_fechamento_caixa_banco_drift_provider.dart';
import 'package:financeiro/app/data/repository/fin_fechamento_caixa_banco_repository.dart';

class FinFechamentoCaixaBancoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FinFechamentoCaixaBancoController>(() => FinFechamentoCaixaBancoController(
					repository: FinFechamentoCaixaBancoRepository(finFechamentoCaixaBancoApiProvider: FinFechamentoCaixaBancoApiProvider(), finFechamentoCaixaBancoDriftProvider: FinFechamentoCaixaBancoDriftProvider()))),
		];
	}
}
