import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:get/get.dart';
import 'package:financeiro/app/data/provider/api/view_fin_movimento_caixa_banco_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_movimento_caixa_banco_drift_provider.dart';
import 'package:financeiro/app/data/repository/view_fin_movimento_caixa_banco_repository.dart';
import 'package:financeiro/app/data/repository/fin_fechamento_caixa_banco_repository.dart';
import 'package:financeiro/app/data/provider/api/fin_fechamento_caixa_banco_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/fin_fechamento_caixa_banco_drift_provider.dart';
import 'package:financeiro/app/data/provider/api/view_fin_cheque_nao_compensado_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_cheque_nao_compensado_drift_provider.dart';
import 'package:financeiro/app/data/repository/view_fin_cheque_nao_compensado_repository.dart';

class ViewFinMovimentoCaixaBancoBindings implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<ViewFinMovimentoCaixaBancoController>(
        () => ViewFinMovimentoCaixaBancoController(
          repository: ViewFinMovimentoCaixaBancoRepository(
            viewFinMovimentoCaixaBancoApiProvider: ViewFinMovimentoCaixaBancoApiProvider(),
            viewFinMovimentoCaixaBancoDriftProvider: ViewFinMovimentoCaixaBancoDriftProvider(),
          ),
          finFechamentoCaixaBancoRepository: FinFechamentoCaixaBancoRepository(
            finFechamentoCaixaBancoApiProvider: FinFechamentoCaixaBancoApiProvider(),
            finFechamentoCaixaBancoDriftProvider: FinFechamentoCaixaBancoDriftProvider(),
          ),
          viewFinChequeNaoCompensadoRepository: ViewFinChequeNaoCompensadoRepository(
            viewFinChequeNaoCompensadoApiProvider: ViewFinChequeNaoCompensadoApiProvider(),
            viewFinChequeNaoCompensadoDriftProvider: ViewFinChequeNaoCompensadoDriftProvider(),
          ),
        ),
      ),
      Bind.lazyPut<ResumoTesourariaController>(
        () => ResumoTesourariaController(
          repository: ViewFinMovimentoCaixaBancoRepository(
            viewFinMovimentoCaixaBancoApiProvider: ViewFinMovimentoCaixaBancoApiProvider(),
            viewFinMovimentoCaixaBancoDriftProvider: ViewFinMovimentoCaixaBancoDriftProvider(),
          ),
        ),
      ),
    ];
  }
}
