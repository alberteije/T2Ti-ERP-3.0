import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_natureza_financeira_repository.dart';

class FinNaturezaFinanceiraController extends ControllerBase<FinNaturezaFinanceiraModel, FinNaturezaFinanceiraRepository> {

  FinNaturezaFinanceiraController({required super.repository}) {
    dbColumns = FinNaturezaFinanceiraModel.dbColumns;
    aliasColumns = FinNaturezaFinanceiraModel.aliasColumns;
    gridColumns = finNaturezaFinanceiraGridColumns();
    functionName = "fin_natureza_financeira";
    screenTitle = "Natureza Financeira";
  }

  @override
  FinNaturezaFinanceiraModel createNewModel() => FinNaturezaFinanceiraModel();

  @override
  final standardFieldForFilter = FinNaturezaFinanceiraModel.aliasColumns[FinNaturezaFinanceiraModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final descricaoController = TextEditingController();
  final aplicacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finNaturezaFinanceira) => finNaturezaFinanceira.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finNaturezaFinanceiraEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    descricaoController.text = '';
    aplicacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finNaturezaFinanceiraEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    aplicacaoController.text = currentModel.aplicacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finNaturezaFinanceiraModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    descricaoController.dispose();
    aplicacaoController.dispose();
    super.onClose();
  }

}