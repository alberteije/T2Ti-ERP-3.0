import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_configuracao_boleto_repository.dart';

class FinConfiguracaoBoletoController extends ControllerBase<FinConfiguracaoBoletoModel, FinConfiguracaoBoletoRepository> {

  FinConfiguracaoBoletoController({required super.repository}) {
    dbColumns = FinConfiguracaoBoletoModel.dbColumns;
    aliasColumns = FinConfiguracaoBoletoModel.aliasColumns;
    gridColumns = finConfiguracaoBoletoGridColumns();
    functionName = "fin_configuracao_boleto";
    screenTitle = "Configuracões Boleto";
  }

  @override
  FinConfiguracaoBoletoModel createNewModel() => FinConfiguracaoBoletoModel();

  @override
  final standardFieldForFilter = FinConfiguracaoBoletoModel.aliasColumns[FinConfiguracaoBoletoModel.dbColumns.indexOf('instrucao01')];

  final bancoContaCaixaModelController = TextEditingController();
  final instrucao01Controller = TextEditingController();
  final instrucao02Controller = TextEditingController();
  final caminhoArquivoRemessaController = TextEditingController();
  final caminhoArquivoRetornoController = TextEditingController();
  final caminhoArquivoLogotipoController = TextEditingController();
  final caminhoArquivoPdfController = TextEditingController();
  final mensagemController = TextEditingController();
  final localPagamentoController = TextEditingController();
  final carteiraController = TextEditingController();
  final codigoConvenioController = TextEditingController();
  final codigoCedenteController = TextEditingController();
  final taxaMultaController = MoneyMaskedTextController();
  final taxaJuroController = MoneyMaskedTextController();
  final diasProtestoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nossoNumeroAnteriorController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['instrucao01'],
    'secondaryColumns': ['instrucao02'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finConfiguracaoBoleto) => finConfiguracaoBoleto.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finConfiguracaoBoletoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    bancoContaCaixaModelController.text = '';
    instrucao01Controller.text = '';
    instrucao02Controller.text = '';
    caminhoArquivoRemessaController.text = '';
    caminhoArquivoRetornoController.text = '';
    caminhoArquivoLogotipoController.text = '';
    caminhoArquivoPdfController.text = '';
    mensagemController.text = '';
    localPagamentoController.text = '';
    carteiraController.text = '';
    codigoConvenioController.text = '';
    codigoCedenteController.text = '';
    taxaMultaController.updateValue(0);
    taxaJuroController.updateValue(0);
    diasProtestoController.updateValue(0);
    nossoNumeroAnteriorController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finConfiguracaoBoletoEditPage);
  }

  void updateControllersFromModel() {
    bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome?.toString() ?? '';
    instrucao01Controller.text = currentModel.instrucao01 ?? '';
    instrucao02Controller.text = currentModel.instrucao02 ?? '';
    caminhoArquivoRemessaController.text = currentModel.caminhoArquivoRemessa ?? '';
    caminhoArquivoRetornoController.text = currentModel.caminhoArquivoRetorno ?? '';
    caminhoArquivoLogotipoController.text = currentModel.caminhoArquivoLogotipo ?? '';
    caminhoArquivoPdfController.text = currentModel.caminhoArquivoPdf ?? '';
    mensagemController.text = currentModel.mensagem ?? '';
    localPagamentoController.text = currentModel.localPagamento ?? '';
    carteiraController.text = currentModel.carteira ?? '';
    codigoConvenioController.text = currentModel.codigoConvenio ?? '';
    codigoCedenteController.text = currentModel.codigoCedente ?? '';
    taxaMultaController.updateValue(currentModel.taxaMulta ?? 0);
    taxaJuroController.updateValue(currentModel.taxaJuro ?? 0);
    diasProtestoController.updateValue((currentModel.diasProtesto ?? 0).toDouble());
    nossoNumeroAnteriorController.text = currentModel.nossoNumeroAnterior ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finConfiguracaoBoletoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta/Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 
		lookupController.standardColumn = BancoContaCaixaModel.aliasColumns[BancoContaCaixaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			currentModel.bancoContaCaixaModel = BancoContaCaixaModel.fromPlutoRow(plutoRowResult); 
			bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    bancoContaCaixaModelController.dispose();
    instrucao01Controller.dispose();
    instrucao02Controller.dispose();
    caminhoArquivoRemessaController.dispose();
    caminhoArquivoRetornoController.dispose();
    caminhoArquivoLogotipoController.dispose();
    caminhoArquivoPdfController.dispose();
    mensagemController.dispose();
    localPagamentoController.dispose();
    carteiraController.dispose();
    codigoConvenioController.dispose();
    codigoCedenteController.dispose();
    taxaMultaController.dispose();
    taxaJuroController.dispose();
    diasProtestoController.dispose();
    nossoNumeroAnteriorController.dispose();
    super.onClose();
  }

}