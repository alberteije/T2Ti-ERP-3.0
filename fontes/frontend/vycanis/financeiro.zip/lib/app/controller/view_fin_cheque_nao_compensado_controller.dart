import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/view_fin_cheque_nao_compensado_repository.dart';

class ViewFinChequeNaoCompensadoController extends ControllerBase<ViewFinChequeNaoCompensadoModel, ViewFinChequeNaoCompensadoRepository> {

  ViewFinChequeNaoCompensadoController({required super.repository}) {
    dbColumns = ViewFinChequeNaoCompensadoModel.dbColumns;
    aliasColumns = ViewFinChequeNaoCompensadoModel.aliasColumns;
    gridColumns = viewFinChequeNaoCompensadoGridColumns();
    functionName = "view_fin_cheque_nao_compensado";
    screenTitle = "View Fin Cheque Nao Compensado";
  }

  @override
  ViewFinChequeNaoCompensadoModel createNewModel() => ViewFinChequeNaoCompensadoModel();

  @override
  final standardFieldForFilter = ViewFinChequeNaoCompensadoModel.aliasColumns[ViewFinChequeNaoCompensadoModel.dbColumns.indexOf('nome_conta_caixa')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_conta_caixa'],
    'secondaryColumns': ['talao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((viewFinChequeNaoCompensado) => viewFinChequeNaoCompensado.toJson).toList();
  }

  @override
  void prepareForInsert() {
  }

  @override
  void selectRowForEditingById(int id) {
  }

  @override
  Future<void> save() async {
  }


}