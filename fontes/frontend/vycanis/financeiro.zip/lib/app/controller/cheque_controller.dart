import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/page/page_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ChequeController extends ControllerBase<ChequeModel, void> {

  ChequeController() : super(repository: null) {
    dbColumns = ChequeModel.dbColumns;
    aliasColumns = ChequeModel.aliasColumns;
    gridColumns = chequeGridColumns();
    functionName = "cheque";
    screenTitle = "Cheque";
  }

  final _chequeModel = ChequeModel().obs;
  ChequeModel get chequeModel => _chequeModel.value;
  set chequeModel(value) => _chequeModel.value = value ?? ChequeModel();

  List<ChequeModel> get chequeModelList => Get.find<TalonarioChequeController>().currentModel.chequeModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final chequeScaffoldKey = GlobalKey<ScaffoldState>();
  final chequeFormKey = GlobalKey<FormState>();

  @override
  ChequeModel createNewModel() => ChequeModel();

  @override
  final standardFieldForFilter = ChequeModel.aliasColumns[ChequeModel.dbColumns.indexOf('numero')];

  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['status_cheque'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cheque) => cheque.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(chequeModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    chequeModel = createNewModel();
    _resetForm();
    Get.to(() => ChequeEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = chequeModelList.firstWhere((m) => m.id == id);
    chequeModel = model.clone();
    updateControllersFromModel();
    Get.to(() => ChequeEditPage());
  }

  void updateControllersFromModel() {
    numeroController.updateValue((chequeModel.numero ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!chequeFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        chequeModelList.insert(0, chequeModel.clone());
      } else {
        final index = chequeModelList.indexWhere((m) => m.id == chequeModel.id);
        if (index >= 0) {
          chequeModelList[index] = chequeModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      chequeModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroController.dispose();
  }

}