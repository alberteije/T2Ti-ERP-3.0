import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/view_fin_movimento_caixa_banco_repository.dart';

class ResumoTesourariaController extends ControllerBase<ViewFinMovimentoCaixaBancoModel, ViewFinMovimentoCaixaBancoRepository> {

  ResumoTesourariaController({
		required super.repository,
	}) {
    dbColumns = ViewFinMovimentoCaixaBancoModel.dbColumns;
    aliasColumns = ViewFinMovimentoCaixaBancoModel.aliasColumns;
    gridColumns = viewFinMovimentoCaixaBancoGridColumns();
    functionName = "resumo_tesouraria";
    screenTitle = "Resumo Tesouraria";
  }

  BancoContaCaixaModel get bancoContaCaixaModel => Get.find<BancoContaCaixaController>().currentModel;

  DateTime initialDate = DateTime.now();
  DateTime finalDate = DateTime.now();

  final _creditos = 0.0.obs;
  double get creditos => _creditos.value;
  set creditos(double value) => _creditos.value = value;

  final _debitos = 0.0.obs;
  double get debitos => _debitos.value;
  set debitos(double value) => _debitos.value = value;

  final _saldo = 0.0.obs;
  double get saldo => _saldo.value;
  set saldo(double value) => _saldo.value = value;

  @override
  ViewFinMovimentoCaixaBancoModel createNewModel() => ViewFinMovimentoCaixaBancoModel();

  @override
  final standardFieldForFilter = ViewFinMovimentoCaixaBancoModel.aliasColumns[ViewFinMovimentoCaixaBancoModel.dbColumns.indexOf('nome_conta_caixa')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_conta_caixa'],
    'secondaryColumns': ['nome_pessoa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((viewFinMovimentoCaixaBanco) => viewFinMovimentoCaixaBanco.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {
    filter = Filter(
      field: 'data_pago_recebido',
      condition: 'between',
      initialDate: Util.formatDate(initialDate, format: 'yyyy-MM-dd'),
      finalDate: Util.formatDate(finalDate, format: 'yyyy-MM-dd'),
    );
    await super.getList(filter: filter);
  }

  @override
  Future<void> loadData() async {
    await super.loadData();
    calculateSummaryValues();
  }

  @override
  void prepareForInsert() {
  }

  @override
  void selectRowForEditingById(int id) {
  }

  @override
  Future<void> save() async {
  }

  void calculateSummaryValues() {
    double tempCreditos = 0.0;
    double tempDebitos = 0.0;

    for (var lancamento in modelList) {
      if (lancamento.operacao == 'Entrada') {
        tempCreditos += lancamento.valor ?? 0;
      } else {
        tempDebitos += lancamento.valor ?? 0;
      }
    }

    // Atualiza os valores observáveis
    creditos = tempCreditos;
    debitos = tempDebitos;
    saldo = tempCreditos - tempDebitos;
  }

  @override
  void onInit() {
    screenTitle += " - [${bancoContaCaixaModel.nome}]";
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    loadData();
  }

}