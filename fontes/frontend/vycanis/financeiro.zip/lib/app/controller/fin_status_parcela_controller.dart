import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_status_parcela_repository.dart';

class FinStatusParcelaController extends ControllerBase<FinStatusParcelaModel, FinStatusParcelaRepository> {

  FinStatusParcelaController({required super.repository}) {
    dbColumns = FinStatusParcelaModel.dbColumns;
    aliasColumns = FinStatusParcelaModel.aliasColumns;
    gridColumns = finStatusParcelaGridColumns();
    functionName = "fin_status_parcela";
    screenTitle = "Status Parcela";
  }

  @override
  FinStatusParcelaModel createNewModel() => FinStatusParcelaModel();

  @override
  final standardFieldForFilter = FinStatusParcelaModel.aliasColumns[FinStatusParcelaModel.dbColumns.indexOf('situacao')];

  final descricaoController = TextEditingController();
  final procedimentoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['situacao'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finStatusParcela) => finStatusParcela.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finStatusParcelaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    procedimentoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finStatusParcelaEditPage);
  }

  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    procedimentoController.text = currentModel.procedimento ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finStatusParcelaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    descricaoController.dispose();
    procedimentoController.dispose();
    super.onClose();
  }

}