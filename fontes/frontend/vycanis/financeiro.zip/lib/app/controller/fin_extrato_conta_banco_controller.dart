// ignore_for_file: deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:xml/xml.dart' as xml;
import 'package:file_picker/file_picker.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/page/shared_widget/shared_widget_imports.dart';
import 'package:financeiro/app/data/repository/fin_extrato_conta_banco_repository.dart';

class FinExtratoContaBancoController extends ControllerBase<FinExtratoContaBancoModel, FinExtratoContaBancoRepository> {
  FinExtratoContaBancoController({required super.repository}) {
    dbColumns = FinExtratoContaBancoModel.dbColumns;
    aliasColumns = FinExtratoContaBancoModel.aliasColumns;
    gridColumns = finExtratoContaBancoGridColumns();
    functionName = "fin_extrato_conta_banco";
    screenTitle = "Extrato Bancário";
  }

  BancoContaCaixaModel get bancoContaCaixaModel => Get.find<BancoContaCaixaController>().currentModel;

  String mesAno = "";

  final _creditos = 0.0.obs;
  double get creditos => _creditos.value;
  set creditos(double value) => _creditos.value = value;

  final _debitos = 0.0.obs;
  double get debitos => _debitos.value;
  set debitos(double value) => _debitos.value = value;

  final _saldo = 0.0.obs;
  double get saldo => _saldo.value;
  set saldo(double value) => _saldo.value = value;

  @override
  FinExtratoContaBancoModel createNewModel() => FinExtratoContaBancoModel();

  @override
  final standardFieldForFilter = FinExtratoContaBancoModel.aliasColumns[FinExtratoContaBancoModel.dbColumns.indexOf('mes_ano')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['mes_ano'],
    'secondaryColumns': ['data_movimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finExtratoContaBanco) => finExtratoContaBanco.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {
    final queryFilters =
        StringBuffer()
          ..write('?filter=mes_ano||\$eq||${mesAno.padLeft(7, '0')}')
          ..write('&filter=id_banco_conta_caixa||\$eq||${bancoContaCaixaModel.id}');
    filter = Filter(condition: 'where', where: queryFilters.toString());
    await super.getList(filter: filter);
  }

  @override
  Future<void> loadData() async {
    await super.loadData();
    calculateSummaryValues();
  }

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  @override
  Future<void> save() async {}

  Future<void> importOfx() async {
    showQuestionDialog('Deseja importar o arquivo do extrato bancário (Formato OFX)?', () async {
      try {
        FilePickerResult? result = await FilePicker.platform.pickFiles();
        if (result != null) {
          String arquivoOFX;

          if (kIsWeb) {
            Uint8List fileBytes = result.files.single.bytes!;
            arquivoOFX = utf8.decode(fileBytes);
          } else {
            File file = File(result.files.single.path!);
            arquivoOFX = await file.readAsString();
          }

          final arquivoXML = xml.XmlDocument.parse(arquivoOFX);
          List<FinExtratoContaBancoModel> lancamentosParaEnviar = [];

          // Captura os lançamentos no arquivo
          final lancamentos = arquivoXML.findAllElements('STMTTRN');
          for (var lancamento in lancamentos) {
            var model = FinExtratoContaBancoModel();
            model.id = null;
            final ano = int.parse(lancamento.getElement('DTPOSTED')?.text.substring(0, 4) ?? '');
            final mes = int.parse(lancamento.getElement('DTPOSTED')?.text.substring(4, 6) ?? '');
            final dia = int.parse(lancamento.getElement('DTPOSTED')?.text.substring(6, 8) ?? '');

            String mesAnoExtrato = "$mes/$ano";
            if (mesAno != mesAnoExtrato) {
              showErrorSnackBar(message: "Existem lançamentos no extrato que estão fora do mês selecionado.");
              return;
            }

            model.mesAno = mesAnoExtrato.padLeft(7, '0');
            model.mes = mes.toString().padLeft(2, '0');
            model.ano = ano.toString();
            model.dataMovimento = DateTime(ano, mes, dia);
            model.dataBalancete = DateTime(ano, mes, dia);
            model.historico = lancamento.getElement('MEMO')?.text;
            model.documento = lancamento.getElement('REFNUM')?.text;
            model.valor = double.tryParse(lancamento.getElement('TRNAMT')?.text ?? "0");
            model.conciliado = 'N';
            model.observacao = "CHECKNUM = ${lancamento.getElement('CHECKNUM')?.text} - FITID = ${lancamento.getElement('FITID')?.text}";
            model.idBancoContaCaixa = bancoContaCaixaModel.id;
            model.bancoContaCaixaModel = BancoContaCaixaModel(id: bancoContaCaixaModel.id);

            lancamentosParaEnviar.add(model);
          }

          if (lancamentosParaEnviar.isNotEmpty) {
            final success = await repository.saveBatch(lancamentosParaEnviar);

            if (success == true) {
              modelList.clear();
              await loadData();
              showInfoSnackBar(message: "${lancamentosParaEnviar.length} lançamentos importados com sucesso!");
            } else {
              showErrorSnackBar(message: "Erro ao importar lançamentos.");
            }
          } else {
            showInfoSnackBar(message: "Nenhum lançamento encontrado no arquivo.");
          }
        } else {
          showInfoSnackBar(message: "Nenhum arquivo selecionado.");
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao importar extrato: ${e.toString()}");
      }
    });
  }

  Future<void> reconcileTransactions() async {
    showQuestionDialog('Deseja conciliar os lançamentos?', () async {
      try {
        final success = await repository.reconcileTransactions(mesAno.padLeft(7, '0'));

        if (success) {
          await loadData();
          showInfoSnackBar(message: "Conciliação realizada com sucesso");
        } else {
          showErrorSnackBar(message: "Erro ao conciliar lançamentos");
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro: ${e.toString()}");
      }
    });
  }

  void calculateSummaryValues() {
    double tempCreditos = 0.0;
    double tempDebitos = 0.0;
    double tempSaldo = 0.0;

    for (var lancamento in modelList) {
      lancamento.valor = lancamento.valor ?? 0;
      if (lancamento.valor! >= 0) {
        tempCreditos += lancamento.valor ?? 0;
      } else {
        tempDebitos += lancamento.valor ?? 0;
      }
      tempSaldo += lancamento.valor ?? 0;
    }

    // Atualiza os valores observáveis
    creditos = tempCreditos;
    debitos = tempDebitos;
    saldo = tempSaldo;
  }

  @override
  void onInit() {
    mesAno = mesAno.isEmpty ? "${DateTime.now().month}/${DateTime.now().year}" : mesAno;
    screenTitle += " - [${bancoContaCaixaModel.nome}]";
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    loadData();
  }
}
