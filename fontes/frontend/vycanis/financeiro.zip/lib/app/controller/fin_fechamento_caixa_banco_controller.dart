import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_fechamento_caixa_banco_repository.dart';

class FinFechamentoCaixaBancoController extends ControllerBase<FinFechamentoCaixaBancoModel, FinFechamentoCaixaBancoRepository> {

  FinFechamentoCaixaBancoController({required super.repository}) {
    dbColumns = FinFechamentoCaixaBancoModel.dbColumns;
    aliasColumns = FinFechamentoCaixaBancoModel.aliasColumns;
    gridColumns = finFechamentoCaixaBancoGridColumns();
    functionName = "fin_fechamento_caixa_banco";
    screenTitle = "Fechamento Caixa/Banco";
  }

  @override
  FinFechamentoCaixaBancoModel createNewModel() => FinFechamentoCaixaBancoModel();

  @override
  final standardFieldForFilter = FinFechamentoCaixaBancoModel.aliasColumns[FinFechamentoCaixaBancoModel.dbColumns.indexOf('data_fechamento')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_fechamento'],
    'secondaryColumns': ['mes_ano'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finFechamentoCaixaBanco) => finFechamentoCaixaBanco.toJson).toList();
  }

  @override
  void prepareForInsert() {
  }

  @override
  void selectRowForEditingById(int id) {
  }

  @override
  Future<void> save() async {
  }

}