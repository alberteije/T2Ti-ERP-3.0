import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_cheque_emitido_repository.dart';

class FinChequeEmitidoController extends ControllerBase<FinChequeEmitidoModel, FinChequeEmitidoRepository> {

  FinChequeEmitidoController({required super.repository}) {
    dbColumns = FinChequeEmitidoModel.dbColumns;
    aliasColumns = FinChequeEmitidoModel.aliasColumns;
    gridColumns = finChequeEmitidoGridColumns();
    functionName = "fin_cheque_emitido";
    screenTitle = "Cheque Emitido";
  }

  @override
  FinChequeEmitidoModel createNewModel() => FinChequeEmitidoModel();

  @override
  final standardFieldForFilter = FinChequeEmitidoModel.aliasColumns[FinChequeEmitidoModel.dbColumns.indexOf('data_emissao')];

  final chequeModelController = TextEditingController();
  final valorController = MoneyMaskedTextController();
  final nominalAController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_emissao'],
    'secondaryColumns': ['bom_para'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finChequeEmitido) => finChequeEmitido.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finChequeEmitidoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    chequeModelController.text = '';
    valorController.updateValue(0);
    nominalAController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finChequeEmitidoEditPage);
  }

  void updateControllersFromModel() {
    chequeModelController.text = currentModel.chequeModel?.numero?.toString() ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    nominalAController.text = currentModel.nominalA ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finChequeEmitidoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callChequeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Número Cheque]'; 
		lookupController.route = '/cheque/'; 
		lookupController.gridColumns = chequeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ChequeModel.aliasColumns; 
		lookupController.dbColumns = ChequeModel.dbColumns; 
		lookupController.standardColumn = ChequeModel.aliasColumns[ChequeModel.dbColumns.indexOf('numero')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCheque = plutoRowResult.cells['id']!.value; 
			currentModel.chequeModel = ChequeModel.fromPlutoRow(plutoRowResult); 
			chequeModelController.text = currentModel.chequeModel?.numero?.toString() ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    chequeModelController.dispose();
    valorController.dispose();
    nominalAController.dispose();
    super.onClose();
  }

}