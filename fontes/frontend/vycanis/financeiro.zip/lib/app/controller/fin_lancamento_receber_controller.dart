import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/page/page_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_lancamento_receber_repository.dart';

class FinLancamentoReceberController extends ControllerBase<FinLancamentoReceberModel, FinLancamentoReceberRepository> 
with GetSingleTickerProviderStateMixin {

  FinLancamentoReceberController({required super.repository}) {
    dbColumns = FinLancamentoReceberModel.dbColumns;
    aliasColumns = FinLancamentoReceberModel.aliasColumns;
    gridColumns = finLancamentoReceberGridColumns();
    functionName = "fin_lancamento_receber";
    screenTitle = "Lançamento a Receber";
  }

  final finLancamentoReceberScaffoldKey = GlobalKey<ScaffoldState>();
  final finLancamentoReceberTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final finLancamentoReceberFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FinLancamentoReceberModel createNewModel() => FinLancamentoReceberModel();

  @override
  final standardFieldForFilter = FinLancamentoReceberModel.aliasColumns[FinLancamentoReceberModel.dbColumns.indexOf('quantidade_parcela')];

  final viewPessoaClienteModelController = TextEditingController();
  final bancoContaCaixaModelController = TextEditingController();
  final finDocumentoOrigemModelController = TextEditingController();
  final finNaturezaFinanceiraModelController = TextEditingController();
  final quantidadeParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorAReceberController = MoneyMaskedTextController();
  final numeroDocumentoController = TextEditingController();
  final taxaComissaoController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();
  final intervaloEntreParcelasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diaFixoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade_parcela'],
    'secondaryColumns': ['valor_a_receber'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finLancamentoReceber) => finLancamentoReceber.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.finLancamentoReceberTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    bancoContaCaixaModelController.text = '';
    finDocumentoOrigemModelController.text = '';
    finNaturezaFinanceiraModelController.text = '';
    quantidadeParcelaController.updateValue(0);
    valorAReceberController.updateValue(0);
    numeroDocumentoController.text = '';
    taxaComissaoController.updateValue(0);
    valorComissaoController.updateValue(0);
    intervaloEntreParcelasController.updateValue(0);
    diaFixoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.finLancamentoReceberTabPage);
  }

  _configureChildrenControllers() {
    //Parcelas
		Get.put<FinParcelaReceberController>(FinParcelaReceberController()); 
		final finParcelaReceberController = Get.find<FinParcelaReceberController>(); 
		finParcelaReceberController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome?.toString() ?? '';
    finDocumentoOrigemModelController.text = currentModel.finDocumentoOrigemModel?.sigla?.toString() ?? '';
    finNaturezaFinanceiraModelController.text = currentModel.finNaturezaFinanceiraModel?.descricao?.toString() ?? '';
    quantidadeParcelaController.updateValue((currentModel.quantidadeParcela ?? 0).toDouble());
    valorAReceberController.updateValue(currentModel.valorAReceber ?? 0);
    numeroDocumentoController.text = currentModel.numeroDocumento ?? '';
    taxaComissaoController.updateValue(currentModel.taxaComissao ?? 0);
    valorComissaoController.updateValue(currentModel.valorComissao ?? 0);
    intervaloEntreParcelasController.updateValue((currentModel.intervaloEntreParcelas ?? 0).toDouble());
    diaFixoController.text = currentModel.diaFixo ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(finLancamentoReceberModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta/Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 
		lookupController.standardColumn = BancoContaCaixaModel.aliasColumns[BancoContaCaixaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			currentModel.bancoContaCaixaModel = BancoContaCaixaModel.fromPlutoRow(plutoRowResult); 
			bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFinDocumentoOrigemLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Documento Origem]'; 
		lookupController.route = '/fin-documento-origem/'; 
		lookupController.gridColumns = finDocumentoOrigemGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinDocumentoOrigemModel.aliasColumns; 
		lookupController.dbColumns = FinDocumentoOrigemModel.dbColumns; 
		lookupController.standardColumn = FinDocumentoOrigemModel.aliasColumns[FinDocumentoOrigemModel.dbColumns.indexOf('sigla')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFinDocumentoOrigem = plutoRowResult.cells['id']!.value; 
			currentModel.finDocumentoOrigemModel = FinDocumentoOrigemModel.fromPlutoRow(plutoRowResult); 
			finDocumentoOrigemModelController.text = currentModel.finDocumentoOrigemModel?.sigla ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFinNaturezaFinanceiraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Natureza Financeira]'; 
		lookupController.route = '/fin-natureza-financeira/'; 
		lookupController.gridColumns = finNaturezaFinanceiraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinNaturezaFinanceiraModel.aliasColumns; 
		lookupController.dbColumns = FinNaturezaFinanceiraModel.dbColumns; 
		lookupController.standardColumn = FinNaturezaFinanceiraModel.aliasColumns[FinNaturezaFinanceiraModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFinNaturezaFinanceira = plutoRowResult.cells['id']!.value; 
			currentModel.finNaturezaFinanceiraModel = FinNaturezaFinanceiraModel.fromPlutoRow(plutoRowResult); 
			finNaturezaFinanceiraModelController.text = currentModel.finNaturezaFinanceiraModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Lançamento a Receber', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Parcelas', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FinLancamentoReceberEditPage(),
      const FinParcelaReceberListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FinParcelaReceberController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.bancoContaCaixaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Conta/Caixa]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.finDocumentoOrigemModel?.sigla); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Documento Origem]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.finNaturezaFinanceiraModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Natureza Financeira]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future<void> gerarParcelas() async {
    // 1. Validações iniciais
    if (currentModel.valorAReceber == null || currentModel.valorAReceber! <= 0) {
      showErrorSnackBar(message: 'Valor a receber não pode ser nulo ou zero');
      return;
    }

    if (currentModel.quantidadeParcela == null || currentModel.quantidadeParcela! <= 0) {
      showErrorSnackBar(message: 'Quantidade de parcelas inválida');
      return;
    }

    if (currentModel.primeiroVencimento == null) {
      showErrorSnackBar(message: 'Primeiro vencimento não definido');
      return;
    }

    // 2. Confirmação do usuário
    tabController.animateTo(1);
    showQuestionDialog('Gerar Parcelas - Isso irá apagar todas as parcelas existentes. Deseja continuar?', _processarGeracaoParcelas);
  }

  void _processarGeracaoParcelas() {
    // 3. Obter o controller de parcelas
    final parcelaController = Get.find<FinParcelaReceberController>();

    // 4. Limpar parcelas existentes
    currentModel.finParcelaReceberModelList!.clear();

    // 5. Calcular valor por parcela
    final valorPorParcela = currentModel.valorAReceber! / currentModel.quantidadeParcela!;

    // 6. Gerar cada parcela
    for (var i = 0; i < currentModel.quantidadeParcela!; i++) {
      final parcela = FinParcelaReceberModel(
        idFinLancamentoReceber: currentModel.id,
        numeroParcela: i + 1,
        valor: valorPorParcela,
        dataEmissao: DateTime.now(),
        dataVencimento: _calcularDataVencimento(i),
        dataRecebimento: null,
        finStatusParcelaModel: FinStatusParcelaModel(id: 1, situacao: '01', descricao: 'Aberto'), // TODO: você pode paramatrizar isso no sistema
        finTipoRecebimentoModel: FinTipoRecebimentoModel(id: 1, codigo: '01', descricao: 'Dinheiro'), // TODO: você pode paramatrizar isso no sistema
      );

      // Adicionar à lista
      currentModel.finParcelaReceberModelList!.add(parcela);
    }

    // 7. Atualizar flag de alteração
    parcelaController.userMadeChanges = true;
    parcelaController.loadData();
    showInfoSnackBar(message: 'Parcelas geradas com sucesso');
  }

  DateTime _calcularDataVencimento(int numeroParcela) {
    DateTime dataBase = currentModel.primeiroVencimento!;

    // Se tem dia fixo definido
    if (currentModel.diaFixo != null && currentModel.diaFixo!.isNotEmpty) {
      final diaFixo = int.tryParse(currentModel.diaFixo!) ?? dataBase.day;

      // Para a primeira parcela, usa a data base se o dia já for o fixo
      if (numeroParcela == 0 && dataBase.day == diaFixo) {
        return dataBase;
      }

      // Para outras parcelas ou quando o dia base não coincide
      return DateTime(dataBase.year, dataBase.month + numeroParcela, diaFixo);
    }

    // Se não tem dia fixo, usa o intervalo entre parcelas
    final intervalo = currentModel.intervaloEntreParcelas ?? 30;
    return dataBase.add(Duration(days: intervalo * numeroParcela));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaClienteModelController.dispose();
    bancoContaCaixaModelController.dispose();
    finDocumentoOrigemModelController.dispose();
    finNaturezaFinanceiraModelController.dispose();
    quantidadeParcelaController.dispose();
    valorAReceberController.dispose();
    numeroDocumentoController.dispose();
    taxaComissaoController.dispose();
    valorComissaoController.dispose();
    intervaloEntreParcelasController.dispose();
    diaFixoController.dispose();
    super.onClose();
  }	
}