import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:financeiro/app/routes/app_routes.dart';

import 'package:financeiro/app/page/page_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/shared_page/shared_page_imports.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/data/provider/api/fin_lancamento_receber_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/fin_lancamento_receber_drift_provider.dart';
import 'package:financeiro/app/data/repository/fin_lancamento_receber_repository.dart';

class FinParcelaReceberController extends ControllerBase<FinParcelaReceberModel, void> {

  FinParcelaReceberController() : super(repository: null) {
    dbColumns = FinParcelaReceberModel.dbColumns;
    aliasColumns = FinParcelaReceberModel.aliasColumns;
    gridColumns = finParcelaReceberGridColumns();
    functionName = "fin_parcela_receber";
    screenTitle = "Parcelas";
  }

  final _finParcelaReceberModel = FinParcelaReceberModel().obs;
  FinParcelaReceberModel get finParcelaReceberModel => _finParcelaReceberModel.value;
  set finParcelaReceberModel(value) => _finParcelaReceberModel.value = value ?? FinParcelaReceberModel();

  List<FinParcelaReceberModel> get finParcelaReceberModelList => Get.find<FinLancamentoReceberController>().currentModel.finParcelaReceberModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final finParcelaReceberScaffoldKey = GlobalKey<ScaffoldState>();
  final finParcelaReceberFormKey = GlobalKey<FormState>();

  @override
  FinParcelaReceberModel createNewModel() => FinParcelaReceberModel();

  @override
  final standardFieldForFilter = FinParcelaReceberModel.aliasColumns[FinParcelaReceberModel.dbColumns.indexOf('numero_parcela')];

  final finStatusParcelaModelController = TextEditingController();
  final finTipoRecebimentoModelController = TextEditingController();
  final numeroParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorController = MoneyMaskedTextController();
  final taxaJuroController = MoneyMaskedTextController();
  final taxaMultaController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorJuroController = MoneyMaskedTextController();
  final valorMultaController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final boletoNossoNumeroController = TextEditingController();
  final valorRecebidoController = MoneyMaskedTextController();
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_parcela'],
    'secondaryColumns': ['data_emissao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finParcelaReceber) => finParcelaReceber.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(finParcelaReceberModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    finParcelaReceberModel = createNewModel();
    _resetForm();
    Get.to(() => FinParcelaReceberEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    finStatusParcelaModelController.text = '';
    finTipoRecebimentoModelController.text = '';
    numeroParcelaController.updateValue(0);
    valorController.updateValue(0);
    taxaJuroController.updateValue(0);
    taxaMultaController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorJuroController.updateValue(0);
    valorMultaController.updateValue(0);
    valorDescontoController.updateValue(0);
    boletoNossoNumeroController.text = '';
    valorRecebidoController.updateValue(0);
    historicoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = finParcelaReceberModelList.firstWhere((m) => m.tempId == tempId);
    finParcelaReceberModel = model.clone();
		finParcelaReceberModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FinParcelaReceberEditPage());
  }

  void updateControllersFromModel() {
    finStatusParcelaModelController.text = finParcelaReceberModel.finStatusParcelaModel?.descricao?.toString() ?? '';
    finTipoRecebimentoModelController.text = finParcelaReceberModel.finTipoRecebimentoModel?.descricao?.toString() ?? '';
    numeroParcelaController.updateValue((finParcelaReceberModel.numeroParcela ?? 0).toDouble());
    valorController.updateValue(finParcelaReceberModel.valor ?? 0);
    taxaJuroController.updateValue(finParcelaReceberModel.taxaJuro ?? 0);
    taxaMultaController.updateValue(finParcelaReceberModel.taxaMulta ?? 0);
    taxaDescontoController.updateValue(finParcelaReceberModel.taxaDesconto ?? 0);
    valorJuroController.updateValue(finParcelaReceberModel.valorJuro ?? 0);
    valorMultaController.updateValue(finParcelaReceberModel.valorMulta ?? 0);
    valorDescontoController.updateValue(finParcelaReceberModel.valorDesconto ?? 0);
    boletoNossoNumeroController.text = finParcelaReceberModel.boletoNossoNumero ?? '';
    valorRecebidoController.updateValue(finParcelaReceberModel.valorRecebido ?? 0);
    historicoController.text = finParcelaReceberModel.historico ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!finParcelaReceberFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        finParcelaReceberModelList.insert(0, finParcelaReceberModel.clone());
      } else {
        final index = finParcelaReceberModelList.indexWhere((m) => m.tempId == finParcelaReceberModel.tempId);
        if (index >= 0) {
          finParcelaReceberModelList[index] = finParcelaReceberModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFinStatusParcelaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Status Parcela]'; 
		lookupController.route = '/fin-status-parcela/'; 
		lookupController.gridColumns = finStatusParcelaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinStatusParcelaModel.aliasColumns; 
		lookupController.dbColumns = FinStatusParcelaModel.dbColumns; 
		lookupController.standardColumn = FinStatusParcelaModel.aliasColumns[FinStatusParcelaModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			finParcelaReceberModel.idFinStatusParcela = plutoRowResult.cells['id']!.value; 
			finParcelaReceberModel.finStatusParcelaModel = FinStatusParcelaModel.fromPlutoRow(plutoRowResult); 
			finStatusParcelaModelController.text = finParcelaReceberModel.finStatusParcelaModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFinTipoRecebimentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Recebimento]'; 
		lookupController.route = '/fin-tipo-recebimento/'; 
		lookupController.gridColumns = finTipoRecebimentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinTipoRecebimentoModel.aliasColumns; 
		lookupController.dbColumns = FinTipoRecebimentoModel.dbColumns; 
		lookupController.standardColumn = FinTipoRecebimentoModel.aliasColumns[FinTipoRecebimentoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			finParcelaReceberModel.idFinTipoRecebimento = plutoRowResult.cells['id']!.value; 
			finParcelaReceberModel.finTipoRecebimentoModel = FinTipoRecebimentoModel.fromPlutoRow(plutoRowResult); 
			finTipoRecebimentoModelController.text = finParcelaReceberModel.finTipoRecebimentoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      finParcelaReceberModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  Future<void> emitirBoleto() async {
    if (plutoGridStateManager.currentRow == null) {
      showInfoSnackBar(message: "Selecione uma parcela");
      return;
    }

    ByteData? pdfData;
    Uint8List? pdfBytes;
    if (Constants.usingLocalDatabase) {
      pdfData = await rootBundle.load('assets/pdf/boleto.pdf');
      pdfBytes = pdfData.buffer.asUint8List();
    } else {
      FinLancamentoReceberRepository lancamentoRepository = FinLancamentoReceberRepository(finLancamentoReceberApiProvider: FinLancamentoReceberApiProvider(), finLancamentoReceberDriftProvider: FinLancamentoReceberDriftProvider());
      final id = plutoGridStateManager.currentRow!.cells['id']?.value;
      pdfBytes = await lancamentoRepository.emitirBoleto(idParcela: id);
    }

    if (pdfBytes == null) {
      showErrorSnackBar(message: "Houve um erro ao gerar o boleto.");
      return;
    }

    Get.to(() => PdfPage(
      title: "Emissão de Boleto",
      pdfFile: pdfBytes,
    ));
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    finStatusParcelaModelController.dispose();
    finTipoRecebimentoModelController.dispose();
    numeroParcelaController.dispose();
    valorController.dispose();
    taxaJuroController.dispose();
    taxaMultaController.dispose();
    taxaDescontoController.dispose();
    valorJuroController.dispose();
    valorMultaController.dispose();
    valorDescontoController.dispose();
    boletoNossoNumeroController.dispose();
    valorRecebidoController.dispose();
    historicoController.dispose();
  }

}