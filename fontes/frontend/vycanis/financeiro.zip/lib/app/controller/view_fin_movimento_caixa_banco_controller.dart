import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/page/shared_widget/shared_widget_imports.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/view_fin_movimento_caixa_banco_repository.dart';

import 'package:financeiro/app/data/repository/fin_fechamento_caixa_banco_repository.dart';
import 'package:financeiro/app/data/repository/view_fin_cheque_nao_compensado_repository.dart';

class ViewFinMovimentoCaixaBancoController extends ControllerBase<ViewFinMovimentoCaixaBancoModel, ViewFinMovimentoCaixaBancoRepository> {

  final FinFechamentoCaixaBancoRepository finFechamentoCaixaBancoRepository;
  final ViewFinChequeNaoCompensadoRepository viewFinChequeNaoCompensadoRepository;

  ViewFinMovimentoCaixaBancoController({
		required super.repository, 
		required this.finFechamentoCaixaBancoRepository,
		required this.viewFinChequeNaoCompensadoRepository,
	}) {
    dbColumns = ViewFinMovimentoCaixaBancoModel.dbColumns;
    aliasColumns = ViewFinMovimentoCaixaBancoModel.aliasColumns;
    gridColumns = viewFinMovimentoCaixaBancoGridColumns();
    functionName = "view_fin_movimento_caixa_banco";
    screenTitle = "Movimento Caixa/Banco";
  }

  BancoContaCaixaModel get bancoContaCaixaModel => Get.find<BancoContaCaixaController>().currentModel;

  final _finFechamentoCaixaBancoModel = FinFechamentoCaixaBancoModel().obs;
  FinFechamentoCaixaBancoModel get finFechamentoCaixaBancoModel => _finFechamentoCaixaBancoModel.value;
  set finFechamentoCaixaBancoModel(FinFechamentoCaixaBancoModel value) {
    _finFechamentoCaixaBancoModel.value = value;
  }

  String mesAno = "";

  @override
  ViewFinMovimentoCaixaBancoModel createNewModel() => ViewFinMovimentoCaixaBancoModel();

  @override
  final standardFieldForFilter = ViewFinMovimentoCaixaBancoModel.aliasColumns[ViewFinMovimentoCaixaBancoModel.dbColumns.indexOf('nome_conta_caixa')];

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_conta_caixa'],
    'secondaryColumns': ['nome_pessoa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((viewFinMovimentoCaixaBanco) => viewFinMovimentoCaixaBanco.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {
    final queryFilters = StringBuffer()
      ..write('?filter=mes_ano||\$eq||${mesAno.padLeft(7, '0')}')
      ..write('&filter=id_banco_conta_caixa||\$eq||${bancoContaCaixaModel.id}');
    filter = Filter(condition: 'where', where: queryFilters.toString());
    await super.getList(filter: filter);
  }

  @override
  Future<void> loadData() async {
    await super.loadData();
    getFechamentoAtual();
  }

  @override
  void prepareForInsert() {
  }

  @override
  void selectRowForEditingById(int id) {
  }

  @override
  Future<void> save() async {
  }

  Future<void> closeMonth() async {
    showQuestionDialog('Deseja realizar o fechamento do mês?', () async {
        double totalRecebimentos = 0.0;
        double totalPagamentos = 0.0;
        double totalChequesNaoCompensados = 0.0;
        double saldoAnterior = 0.0;
        double saldoAtual = 0.0;
        double saldoDisponivel = 0.0;

        // fechamento anterior
        saldoAnterior = await getFechamentoAnterior();
        // fechamento atual
        await getFechamentoAtual();
        // cheques não compensados
        totalChequesNaoCompensados = await getChequesNaoCompensados();

        // entradas e saidas
        for (var lancamento in modelList) {
          if (lancamento.operacao == 'Entrada') {
            totalRecebimentos += lancamento.valor ?? 0;
          } else {
            totalPagamentos += lancamento.valor ?? 0;
          }
        }
        saldoAtual = totalRecebimentos - totalPagamentos;
        saldoDisponivel = saldoAtual - totalChequesNaoCompensados;

        // insere/atualiza o fechamento
        finFechamentoCaixaBancoModel.bancoContaCaixaModel = BancoContaCaixaModel(id: bancoContaCaixaModel.id);
        finFechamentoCaixaBancoModel.idBancoContaCaixa = bancoContaCaixaModel.id;
        finFechamentoCaixaBancoModel.dataFechamento = DateTime.now();
        finFechamentoCaixaBancoModel.mesAno = mesAno.padLeft(7, '0');
        finFechamentoCaixaBancoModel.mes = mesAno.padLeft(7, '0').substring(0, 2);
        finFechamentoCaixaBancoModel.ano = mesAno.padLeft(7, '0').substring(3, 7);
        finFechamentoCaixaBancoModel.saldoAnterior = saldoAnterior;
        finFechamentoCaixaBancoModel.recebimentos = totalRecebimentos;
        finFechamentoCaixaBancoModel.pagamentos = totalPagamentos;
        finFechamentoCaixaBancoModel.saldoConta = saldoAtual;
        finFechamentoCaixaBancoModel.chequeNaoCompensado = totalChequesNaoCompensados;
        finFechamentoCaixaBancoModel.saldoDisponivel = saldoDisponivel;
        await finFechamentoCaixaBancoRepository.save(finFechamentoCaixaBancoModel: finFechamentoCaixaBancoModel);

				_finFechamentoCaixaBancoModel.refresh();
      }
    );
  }

  Future<double> getFechamentoAnterior() async {
    // fechamento anterior
    double saldoAnterior = 0;
    final mesAnterior = Util.getPreviousMonth(mesAno.padLeft(7, '0'));
    final queryFiltersFechamentoAnterior = StringBuffer()
      ..write('?filter=mes_ano||\$eq||$mesAnterior')
      ..write('&filter=id_banco_conta_caixa||\$eq||${bancoContaCaixaModel.id}');
    filter = Filter(condition: 'where', where: queryFiltersFechamentoAnterior.toString());
    final fechamentoAnteriorList = await finFechamentoCaixaBancoRepository.getList(filter: filter);
    if (fechamentoAnteriorList.isNotEmpty) {
      saldoAnterior = fechamentoAnteriorList[0].saldoDisponivel;
    }
    return saldoAnterior;
  }

  Future<void> getFechamentoAtual() async {
    // fechamento atual
    final queryFiltersFechamentoAtual = StringBuffer()
      ..write('?filter=mes_ano||\$eq||${mesAno.padLeft(7, '0')}')
      ..write('&filter=id_banco_conta_caixa||\$eq||${bancoContaCaixaModel.id}');
    filter = Filter(condition: 'where', where: queryFiltersFechamentoAtual.toString());
    final fechamentoAtualList = await finFechamentoCaixaBancoRepository.getList(filter: filter);
    finFechamentoCaixaBancoModel = fechamentoAtualList.isNotEmpty ? fechamentoAtualList[0] : FinFechamentoCaixaBancoModel();
  }

  Future<double> getChequesNaoCompensados() async {
    // cheques não compensados
    double totalChequesNaoCompensados = 0.0;
    final queryFiltersCheque = StringBuffer()
      ..write('?filter=id_banco_conta_caixa||\$eq||${bancoContaCaixaModel.id}');
    filter = Filter(condition: 'where', where: queryFiltersCheque.toString());
    final chequesNaoCompensadosList = await viewFinChequeNaoCompensadoRepository.getList(filter: filter);
    for (var cheque in chequesNaoCompensadosList) {
      totalChequesNaoCompensados += cheque.valor;
    }
    return totalChequesNaoCompensados;
  }

  @override
  void onInit() {
    mesAno = mesAno.isEmpty ? "${DateTime.now().month}/${DateTime.now().year}" : mesAno;
    screenTitle += " - [${bancoContaCaixaModel.nome}]";
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    getFechamentoAtual();
  }

}