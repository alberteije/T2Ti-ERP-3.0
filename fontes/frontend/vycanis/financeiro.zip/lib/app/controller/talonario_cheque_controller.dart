import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/page/page_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/talonario_cheque_repository.dart';

class TalonarioChequeController extends ControllerBase<TalonarioChequeModel, TalonarioChequeRepository> 
with GetSingleTickerProviderStateMixin {

  TalonarioChequeController({required super.repository}) {
    dbColumns = TalonarioChequeModel.dbColumns;
    aliasColumns = TalonarioChequeModel.aliasColumns;
    gridColumns = talonarioChequeGridColumns();
    functionName = "talonario_cheque";
    screenTitle = "Talonário Cheque";
  }

  final talonarioChequeScaffoldKey = GlobalKey<ScaffoldState>();
  final talonarioChequeTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final talonarioChequeFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  TalonarioChequeModel createNewModel() => TalonarioChequeModel();

  @override
  final standardFieldForFilter = TalonarioChequeModel.aliasColumns[TalonarioChequeModel.dbColumns.indexOf('talao')];

  final bancoContaCaixaModelController = TextEditingController();
  final talaoController = TextEditingController();
  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['talao'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((talonarioCheque) => talonarioCheque.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.talonarioChequeTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    bancoContaCaixaModelController.text = '';
    talaoController.text = '';
    numeroController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.talonarioChequeTabPage);
  }

  _configureChildrenControllers() {
    //Cheque
		Get.put<ChequeController>(ChequeController()); 
		final chequeController = Get.find<ChequeController>(); 
		chequeController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome?.toString() ?? '';
    talaoController.text = currentModel.talao ?? '';
    numeroController.updateValue((currentModel.numero ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(talonarioChequeModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callBancoContaCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta/Caixa]'; 
		lookupController.route = '/banco-conta-caixa/'; 
		lookupController.gridColumns = bancoContaCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoContaCaixaModel.aliasColumns; 
		lookupController.dbColumns = BancoContaCaixaModel.dbColumns; 
		lookupController.standardColumn = BancoContaCaixaModel.aliasColumns[BancoContaCaixaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBancoContaCaixa = plutoRowResult.cells['id']!.value; 
			currentModel.bancoContaCaixaModel = BancoContaCaixaModel.fromPlutoRow(plutoRowResult); 
			bancoContaCaixaModelController.text = currentModel.bancoContaCaixaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Talonário Cheque', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Cheque', 
		),
  ];

  List<Widget> tabPages() {
    return [
      TalonarioChequeEditPage(),
      const ChequeListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ChequeController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.bancoContaCaixaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Conta/Caixa]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    bancoContaCaixaModelController.dispose();
    talaoController.dispose();
    numeroController.dispose();
    super.onClose();
  }	
}