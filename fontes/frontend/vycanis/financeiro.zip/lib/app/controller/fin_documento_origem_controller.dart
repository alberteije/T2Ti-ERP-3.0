import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_documento_origem_repository.dart';

class FinDocumentoOrigemController extends ControllerBase<FinDocumentoOrigemModel, FinDocumentoOrigemRepository> {

  FinDocumentoOrigemController({required super.repository}) {
    dbColumns = FinDocumentoOrigemModel.dbColumns;
    aliasColumns = FinDocumentoOrigemModel.aliasColumns;
    gridColumns = finDocumentoOrigemGridColumns();
    functionName = "fin_documento_origem";
    screenTitle = "Documento Origem";
  }

  @override
  FinDocumentoOrigemModel createNewModel() => FinDocumentoOrigemModel();

  @override
  final standardFieldForFilter = FinDocumentoOrigemModel.aliasColumns[FinDocumentoOrigemModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final siglaController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['sigla'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finDocumentoOrigem) => finDocumentoOrigem.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finDocumentoOrigemEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    siglaController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finDocumentoOrigemEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    siglaController.text = currentModel.sigla ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finDocumentoOrigemModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    siglaController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}