import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:financeiro/app/routes/app_routes.dart';

import 'package:financeiro/app/page/page_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class FinParcelaPagarController extends ControllerBase<FinParcelaPagarModel, void> {

  FinParcelaPagarController() : super(repository: null) {
    dbColumns = FinParcelaPagarModel.dbColumns;
    aliasColumns = FinParcelaPagarModel.aliasColumns;
    gridColumns = finParcelaPagarGridColumns();
    functionName = "fin_parcela_pagar";
    screenTitle = "Parcelas";
  }

  final _finParcelaPagarModel = FinParcelaPagarModel().obs;
  FinParcelaPagarModel get finParcelaPagarModel => _finParcelaPagarModel.value;
  set finParcelaPagarModel(value) => _finParcelaPagarModel.value = value ?? FinParcelaPagarModel();

  List<FinParcelaPagarModel> get finParcelaPagarModelList => Get.find<FinLancamentoPagarController>().currentModel.finParcelaPagarModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final finParcelaPagarScaffoldKey = GlobalKey<ScaffoldState>();
  final finParcelaPagarFormKey = GlobalKey<FormState>();

  @override
  FinParcelaPagarModel createNewModel() => FinParcelaPagarModel();

  @override
  final standardFieldForFilter = FinParcelaPagarModel.aliasColumns[FinParcelaPagarModel.dbColumns.indexOf('numero_parcela')];

  final finStatusParcelaModelController = TextEditingController();
  final finTipoPagamentoModelController = TextEditingController();
  final numeroParcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorController = MoneyMaskedTextController();
  final taxaJuroController = MoneyMaskedTextController();
  final taxaMultaController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorJuroController = MoneyMaskedTextController();
  final valorMultaController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorPagoController = MoneyMaskedTextController();
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_parcela'],
    'secondaryColumns': ['data_emissao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finParcelaPagar) => finParcelaPagar.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(finParcelaPagarModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    finParcelaPagarModel = createNewModel();
    _resetForm();
    Get.to(() => FinParcelaPagarEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    finStatusParcelaModelController.text = '';
    finTipoPagamentoModelController.text = '';
    numeroParcelaController.updateValue(0);
    valorController.updateValue(0);
    taxaJuroController.updateValue(0);
    taxaMultaController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorJuroController.updateValue(0);
    valorMultaController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorPagoController.updateValue(0);
    historicoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = finParcelaPagarModelList.firstWhere((m) => m.tempId == tempId);
    finParcelaPagarModel = model.clone();
		finParcelaPagarModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FinParcelaPagarEditPage());
  }

  void updateControllersFromModel() {
    finStatusParcelaModelController.text = finParcelaPagarModel.finStatusParcelaModel?.descricao?.toString() ?? '';
    finTipoPagamentoModelController.text = finParcelaPagarModel.finTipoPagamentoModel?.descricao?.toString() ?? '';
    numeroParcelaController.updateValue((finParcelaPagarModel.numeroParcela ?? 0).toDouble());
    valorController.updateValue(finParcelaPagarModel.valor ?? 0);
    taxaJuroController.updateValue(finParcelaPagarModel.taxaJuro ?? 0);
    taxaMultaController.updateValue(finParcelaPagarModel.taxaMulta ?? 0);
    taxaDescontoController.updateValue(finParcelaPagarModel.taxaDesconto ?? 0);
    valorJuroController.updateValue(finParcelaPagarModel.valorJuro ?? 0);
    valorMultaController.updateValue(finParcelaPagarModel.valorMulta ?? 0);
    valorDescontoController.updateValue(finParcelaPagarModel.valorDesconto ?? 0);
    valorPagoController.updateValue(finParcelaPagarModel.valorPago ?? 0);
    historicoController.text = finParcelaPagarModel.historico ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!finParcelaPagarFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        finParcelaPagarModelList.insert(0, finParcelaPagarModel.clone());
      } else {
        final index = finParcelaPagarModelList.indexWhere((m) => m.tempId == finParcelaPagarModel.tempId);
        if (index >= 0) {
          finParcelaPagarModelList[index] = finParcelaPagarModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFinStatusParcelaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Status Parcela]'; 
		lookupController.route = '/fin-status-parcela/'; 
		lookupController.gridColumns = finStatusParcelaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinStatusParcelaModel.aliasColumns; 
		lookupController.dbColumns = FinStatusParcelaModel.dbColumns; 
		lookupController.standardColumn = FinStatusParcelaModel.aliasColumns[FinStatusParcelaModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			finParcelaPagarModel.idFinStatusParcela = plutoRowResult.cells['id']!.value; 
			finParcelaPagarModel.finStatusParcelaModel = FinStatusParcelaModel.fromPlutoRow(plutoRowResult); 
			finStatusParcelaModelController.text = finParcelaPagarModel.finStatusParcelaModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFinTipoPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Pagamento]'; 
		lookupController.route = '/fin-tipo-pagamento/'; 
		lookupController.gridColumns = finTipoPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinTipoPagamentoModel.aliasColumns; 
		lookupController.dbColumns = FinTipoPagamentoModel.dbColumns; 
		lookupController.standardColumn = FinTipoPagamentoModel.aliasColumns[FinTipoPagamentoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			finParcelaPagarModel.idFinTipoPagamento = plutoRowResult.cells['id']!.value; 
			finParcelaPagarModel.finTipoPagamentoModel = FinTipoPagamentoModel.fromPlutoRow(plutoRowResult); 
			finTipoPagamentoModelController.text = finParcelaPagarModel.finTipoPagamentoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      finParcelaPagarModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    finStatusParcelaModelController.dispose();
    finTipoPagamentoModelController.dispose();
    numeroParcelaController.dispose();
    valorController.dispose();
    taxaJuroController.dispose();
    taxaMultaController.dispose();
    taxaDescontoController.dispose();
    valorJuroController.dispose();
    valorMultaController.dispose();
    valorDescontoController.dispose();
    valorPagoController.dispose();
    historicoController.dispose();
  }

}