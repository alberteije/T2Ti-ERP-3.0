import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/banco_conta_caixa_repository.dart';

class BancoContaCaixaController extends ControllerBase<BancoContaCaixaModel, BancoContaCaixaRepository> {

  BancoContaCaixaController({required super.repository}) {
    dbColumns = BancoContaCaixaModel.dbColumns;
    aliasColumns = BancoContaCaixaModel.aliasColumns;
    gridColumns = bancoContaCaixaGridColumns();
    functionName = "banco_conta_caixa";
    screenTitle = "Conta/Caixa";
  }

  @override
  BancoContaCaixaModel createNewModel() => BancoContaCaixaModel();

  @override
  final standardFieldForFilter = BancoContaCaixaModel.aliasColumns[BancoContaCaixaModel.dbColumns.indexOf('numero')];

  final bancoAgenciaModelController = TextEditingController();
  final numeroController = TextEditingController();
  final digitoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['digito'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bancoContaCaixa) => bancoContaCaixa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.bancoContaCaixaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    bancoAgenciaModelController.text = '';
    numeroController.text = '';
    digitoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.bancoContaCaixaEditPage);
  }

  void updateControllersFromModel() {
    bancoAgenciaModelController.text = currentModel.bancoAgenciaModel?.nome?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    digitoController.text = currentModel.digito ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(bancoContaCaixaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callBancoAgenciaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Agencia]'; 
		lookupController.route = '/banco-agencia/'; 
		lookupController.gridColumns = bancoAgenciaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoAgenciaModel.aliasColumns; 
		lookupController.dbColumns = BancoAgenciaModel.dbColumns; 
		lookupController.standardColumn = BancoAgenciaModel.aliasColumns[BancoAgenciaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBancoAgencia = plutoRowResult.cells['id']!.value; 
			currentModel.bancoAgenciaModel = BancoAgenciaModel.fromPlutoRow(plutoRowResult); 
			bancoAgenciaModelController.text = currentModel.bancoAgenciaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  void showExtratoBancarioPage() {
    if (plutoGridStateManager.currentRow == null) {
      showInfoSnackBar(message: "Selecione uma conta/caixa");
      return;
    }
    final id = plutoGridStateManager.currentRow!.cells['id']?.value;
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    Get.toNamed(Routes.finExtratoContaBancoListPage);
  }

  void showMovimentoBancarioPage() {
    if (plutoGridStateManager.currentRow == null) {
      showInfoSnackBar(message: "Selecione uma conta/caixa");
      return;
    }
    final id = plutoGridStateManager.currentRow!.cells['id']?.value;
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    Get.toNamed(Routes.viewFinMovimentoCaixaBancoListPage);
  }

  void showFluxoCaixaPage() {
    if (plutoGridStateManager.currentRow == null) {
      showInfoSnackBar(message: "Selecione uma conta/caixa");
      return;
    }
    final id = plutoGridStateManager.currentRow!.cells['id']?.value;
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    Get.toNamed(Routes.viewFinFluxoCaixaListPage);
  }

  void showResumoTesourariaPage() {
    if (plutoGridStateManager.currentRow == null) {
      showInfoSnackBar(message: "Selecione uma conta/caixa");
      return;
    }
    final id = plutoGridStateManager.currentRow!.cells['id']?.value;
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    Get.toNamed(Routes.resumoTesourariaListPage);
  }

  @override
  void onClose() {
    bancoAgenciaModelController.dispose();
    numeroController.dispose();
    digitoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}