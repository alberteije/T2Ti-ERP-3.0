import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/page/grid_columns/grid_columns_imports.dart';
import 'package:financeiro/app/routes/app_routes.dart';
import 'package:financeiro/app/controller/controller_imports.dart';
import 'package:financeiro/app/data/model/model_imports.dart';
import 'package:financeiro/app/data/repository/fin_cheque_recebido_repository.dart';

class FinChequeRecebidoController extends ControllerBase<FinChequeRecebidoModel, FinChequeRecebidoRepository> {

  FinChequeRecebidoController({required super.repository}) {
    dbColumns = FinChequeRecebidoModel.dbColumns;
    aliasColumns = FinChequeRecebidoModel.aliasColumns;
    gridColumns = finChequeRecebidoGridColumns();
    functionName = "fin_cheque_recebido";
    screenTitle = "Cheque Recebido";
  }

  @override
  FinChequeRecebidoModel createNewModel() => FinChequeRecebidoModel();

  @override
  final standardFieldForFilter = FinChequeRecebidoModel.aliasColumns[FinChequeRecebidoModel.dbColumns.indexOf('cpf')];

  final viewPessoaClienteModelController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final nomeController = TextEditingController();
  final codigoBancoController = TextEditingController();
  final codigoAgenciaController = TextEditingController();
  final contaController = TextEditingController();
  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorController = MoneyMaskedTextController();
  final custodiaTarifaController = MoneyMaskedTextController();
  final custodiaComissaoController = MoneyMaskedTextController();
  final descontoTarifaController = MoneyMaskedTextController();
  final descontoComissaoController = MoneyMaskedTextController();
  final valorRecebidoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cpf'],
    'secondaryColumns': ['cnpj'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((finChequeRecebido) => finChequeRecebido.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.finChequeRecebidoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    cpfController.text = '';
    cnpjController.text = '';
    nomeController.text = '';
    codigoBancoController.text = '';
    codigoAgenciaController.text = '';
    contaController.text = '';
    numeroController.updateValue(0);
    valorController.updateValue(0);
    custodiaTarifaController.updateValue(0);
    custodiaComissaoController.updateValue(0);
    descontoTarifaController.updateValue(0);
    descontoComissaoController.updateValue(0);
    valorRecebidoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.finChequeRecebidoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    cpfController.text = currentModel.cpf ?? '';
    cnpjController.text = currentModel.cnpj ?? '';
    nomeController.text = currentModel.nome ?? '';
    codigoBancoController.text = currentModel.codigoBanco ?? '';
    codigoAgenciaController.text = currentModel.codigoAgencia ?? '';
    contaController.text = currentModel.conta ?? '';
    numeroController.updateValue((currentModel.numero ?? 0).toDouble());
    valorController.updateValue(currentModel.valor ?? 0);
    custodiaTarifaController.updateValue(currentModel.custodiaTarifa ?? 0);
    custodiaComissaoController.updateValue(currentModel.custodiaComissao ?? 0);
    descontoTarifaController.updateValue(currentModel.descontoTarifa ?? 0);
    descontoComissaoController.updateValue(currentModel.descontoComissao ?? 0);
    valorRecebidoController.updateValue(currentModel.valorRecebido ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(finChequeRecebidoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    cpfController.dispose();
    cnpjController.dispose();
    nomeController.dispose();
    codigoBancoController.dispose();
    codigoAgenciaController.dispose();
    contaController.dispose();
    numeroController.dispose();
    valorController.dispose();
    custodiaTarifaController.dispose();
    custodiaComissaoController.dispose();
    descontoTarifaController.dispose();
    descontoComissaoController.dispose();
    valorRecebidoController.dispose();
    super.onClose();
  }

}