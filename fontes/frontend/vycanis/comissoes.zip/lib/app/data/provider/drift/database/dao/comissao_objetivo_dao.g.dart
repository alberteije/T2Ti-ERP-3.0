// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'comissao_objetivo_dao.dart';

// ignore_for_file: type=lint
mixin _$ComissaoObjetivoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ComissaoObjetivosTable get comissaoObjetivos =>
      attachedDatabase.comissaoObjetivos;
  $ComissaoPerfilsTable get comissaoPerfils => attachedDatabase.comissaoPerfils;
}
