import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:comissoes/app/data/model/model_imports.dart';

import 'package:comissoes/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ComissaoObjetivoModel extends ModelBase {
  int? id;
  int? idComissaoPerfil;
  String? codigo;
  String? nome;
  String? descricao;
  double? taxaPagamento;
  double? valorPagamento;
  double? valorMeta;
  DateTime? dataInicio;
  DateTime? dataFim;
  ComissaoPerfilModel? comissaoPerfilModel;

  ComissaoObjetivoModel({
    this.id,
    this.idComissaoPerfil,
    this.codigo,
    this.nome,
    this.descricao,
    this.taxaPagamento,
    this.valorPagamento,
    this.valorMeta,
    this.dataInicio,
    this.dataFim,
    ComissaoPerfilModel? comissaoPerfilModel,
  }) {
    this.comissaoPerfilModel = comissaoPerfilModel ?? ComissaoPerfilModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'descricao',
    'taxa_pagamento',
    'valor_pagamento',
    'valor_meta',
    'data_inicio',
    'data_fim',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Descricao',
    'Taxa Pagamento',
    'Valor Pagamento',
    'Valor Meta',
    'Data Inicio',
    'Data Fim',
  ];

  ComissaoObjetivoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idComissaoPerfil = jsonData['idComissaoPerfil'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    taxaPagamento = jsonData['taxaPagamento']?.toDouble();
    valorPagamento = jsonData['valorPagamento']?.toDouble();
    valorMeta = jsonData['valorMeta']?.toDouble();
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    comissaoPerfilModel = jsonData['comissaoPerfilModel'] == null ? ComissaoPerfilModel() : ComissaoPerfilModel.fromJson(jsonData['comissaoPerfilModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idComissaoPerfil'] = idComissaoPerfil != 0 ? idComissaoPerfil : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['taxaPagamento'] = taxaPagamento;
    jsonData['valorPagamento'] = valorPagamento;
    jsonData['valorMeta'] = valorMeta;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['comissaoPerfilModel'] = comissaoPerfilModel?.toJson;
    jsonData['comissaoPerfil'] = comissaoPerfilModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ComissaoObjetivoModel fromPlutoRow(PlutoRow row) {
    return ComissaoObjetivoModel(
      id: row.cells['id']?.value,
      idComissaoPerfil: row.cells['idComissaoPerfil']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      taxaPagamento: row.cells['taxaPagamento']?.value,
      valorPagamento: row.cells['valorPagamento']?.value,
      valorMeta: row.cells['valorMeta']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idComissaoPerfil': PlutoCell(value: idComissaoPerfil ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'taxaPagamento': PlutoCell(value: taxaPagamento ?? 0.0),
        'valorPagamento': PlutoCell(value: valorPagamento ?? 0.0),
        'valorMeta': PlutoCell(value: valorMeta ?? 0.0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'comissaoPerfil': PlutoCell(value: comissaoPerfilModel?.nome ?? ''),
      },
    );
  }

  ComissaoObjetivoModel clone() {
    return ComissaoObjetivoModel(
      id: id,
      idComissaoPerfil: idComissaoPerfil,
      codigo: codigo,
      nome: nome,
      descricao: descricao,
      taxaPagamento: taxaPagamento,
      valorPagamento: valorPagamento,
      valorMeta: valorMeta,
      dataInicio: dataInicio,
      dataFim: dataFim,
      comissaoPerfilModel: ComissaoPerfilModel.cloneFrom(comissaoPerfilModel),
    );
  }

  static ComissaoObjetivoModel cloneFrom(ComissaoObjetivoModel? model) {
    return ComissaoObjetivoModel(
      id: model?.id,
      idComissaoPerfil: model?.idComissaoPerfil,
      codigo: model?.codigo,
      nome: model?.nome,
      descricao: model?.descricao,
      taxaPagamento: model?.taxaPagamento,
      valorPagamento: model?.valorPagamento,
      valorMeta: model?.valorMeta,
      dataInicio: model?.dataInicio,
      dataFim: model?.dataFim,
      comissaoPerfilModel: ComissaoPerfilModel.cloneFrom(model?.comissaoPerfilModel),
    );
  }


}