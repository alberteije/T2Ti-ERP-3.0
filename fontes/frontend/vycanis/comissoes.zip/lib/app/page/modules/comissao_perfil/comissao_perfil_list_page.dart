import 'package:flutter/material.dart';
import 'package:comissoes/app/controller/comissao_perfil_controller.dart';
import 'package:comissoes/app/page/shared_page/list_page_base.dart';

class ComissaoPerfilListPage extends ListPageBase<ComissaoPerfilController> {
  const ComissaoPerfilListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}