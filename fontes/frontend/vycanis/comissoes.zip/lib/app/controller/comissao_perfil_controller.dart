import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:comissoes/app/page/shared_widget/message_dialog.dart';
import 'package:comissoes/app/page/grid_columns/grid_columns_imports.dart';
import 'package:comissoes/app/routes/app_routes.dart';
import 'package:comissoes/app/controller/controller_imports.dart';
import 'package:comissoes/app/data/model/model_imports.dart';
import 'package:comissoes/app/data/repository/comissao_perfil_repository.dart';

class ComissaoPerfilController extends ControllerBase<ComissaoPerfilModel, ComissaoPerfilRepository> {

  ComissaoPerfilController({required super.repository}) {
    dbColumns = ComissaoPerfilModel.dbColumns;
    aliasColumns = ComissaoPerfilModel.aliasColumns;
    gridColumns = comissaoPerfilGridColumns();
    functionName = "comissao_perfil";
    screenTitle = "Perfis";
  }

  @override
  ComissaoPerfilModel createNewModel() => ComissaoPerfilModel();

  @override
  final standardFieldForFilter = ComissaoPerfilModel.aliasColumns[ComissaoPerfilModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((comissaoPerfil) => comissaoPerfil.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.comissaoPerfilEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.comissaoPerfilEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(comissaoPerfilModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}