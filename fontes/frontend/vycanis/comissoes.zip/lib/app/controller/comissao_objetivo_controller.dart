import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:comissoes/app/page/shared_widget/message_dialog.dart';
import 'package:comissoes/app/page/grid_columns/grid_columns_imports.dart';
import 'package:comissoes/app/routes/app_routes.dart';
import 'package:comissoes/app/controller/controller_imports.dart';
import 'package:comissoes/app/data/model/model_imports.dart';
import 'package:comissoes/app/data/repository/comissao_objetivo_repository.dart';

class ComissaoObjetivoController extends ControllerBase<ComissaoObjetivoModel, ComissaoObjetivoRepository> {

  ComissaoObjetivoController({required super.repository}) {
    dbColumns = ComissaoObjetivoModel.dbColumns;
    aliasColumns = ComissaoObjetivoModel.aliasColumns;
    gridColumns = comissaoObjetivoGridColumns();
    functionName = "comissao_objetivo";
    screenTitle = "Objetivos e Metas";
  }

  @override
  ComissaoObjetivoModel createNewModel() => ComissaoObjetivoModel();

  @override
  final standardFieldForFilter = ComissaoObjetivoModel.aliasColumns[ComissaoObjetivoModel.dbColumns.indexOf('codigo')];

  final comissaoPerfilModelController = TextEditingController();
  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final taxaPagamentoController = MoneyMaskedTextController();
  final valorPagamentoController = MoneyMaskedTextController();
  final valorMetaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((comissaoObjetivo) => comissaoObjetivo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.comissaoObjetivoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    comissaoPerfilModelController.text = '';
    codigoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    taxaPagamentoController.updateValue(0);
    valorPagamentoController.updateValue(0);
    valorMetaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.comissaoObjetivoEditPage);
  }

  void updateControllersFromModel() {
    comissaoPerfilModelController.text = currentModel.comissaoPerfilModel?.nome?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    taxaPagamentoController.updateValue(currentModel.taxaPagamento ?? 0);
    valorPagamentoController.updateValue(currentModel.valorPagamento ?? 0);
    valorMetaController.updateValue(currentModel.valorMeta ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(comissaoObjetivoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callComissaoPerfilLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Perfil]'; 
		lookupController.route = '/comissao-perfil/'; 
		lookupController.gridColumns = comissaoPerfilGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ComissaoPerfilModel.aliasColumns; 
		lookupController.dbColumns = ComissaoPerfilModel.dbColumns; 
		lookupController.standardColumn = ComissaoPerfilModel.aliasColumns[ComissaoPerfilModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idComissaoPerfil = plutoRowResult.cells['id']!.value; 
			currentModel.comissaoPerfilModel = ComissaoPerfilModel.fromPlutoRow(plutoRowResult); 
			comissaoPerfilModelController.text = currentModel.comissaoPerfilModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    comissaoPerfilModelController.dispose();
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    taxaPagamentoController.dispose();
    valorPagamentoController.dispose();
    valorMetaController.dispose();
    super.onClose();
  }

}