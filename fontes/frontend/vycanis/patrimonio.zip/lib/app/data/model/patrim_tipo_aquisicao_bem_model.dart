import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

import 'package:patrimonio/app/data/domain/domain_imports.dart';

class PatrimTipoAquisicaoBemModel extends ModelBase {
  int? id;
  String? tipo;
  String? nome;
  String? descricao;

  PatrimTipoAquisicaoBemModel({
    this.id,
    this.tipo = '1=Compra',
    this.nome,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'nome',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Nome',
    'Descricao',
  ];

  PatrimTipoAquisicaoBemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    tipo = PatrimTipoAquisicaoBemDomain.getTipo(jsonData['tipo']);
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['tipo'] = PatrimTipoAquisicaoBemDomain.setTipo(tipo);
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimTipoAquisicaoBemModel fromPlutoRow(PlutoRow row) {
    return PatrimTipoAquisicaoBemModel(
      id: row.cells['id']?.value,
      tipo: row.cells['tipo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  PatrimTipoAquisicaoBemModel clone() {
    return PatrimTipoAquisicaoBemModel(
      id: id,
      tipo: tipo,
      nome: nome,
      descricao: descricao,
    );
  }


}