import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:patrimonio/app/data/domain/domain_imports.dart';

class PatrimBemModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  int? idFornecedor;
  int? idColaborador;
  int? idPatrimTipoAquisicaoBem;
  int? idPatrimEstadoConservacao;
  int? idPatrimGrupoBem;
  int? idSetor;
  String? numeroNb;
  String? nome;
  String? descricao;
  DateTime? dataAquisicao;
  DateTime? dataAceite;
  DateTime? dataCadastro;
  DateTime? dataContabilizado;
  DateTime? dataVistoria;
  DateTime? dataMarcacao;
  DateTime? dataBaixa;
  DateTime? vencimentoGarantia;
  String? numeroNotaFiscal;
  String? numeroSerie;
  String? chaveNfe;
  double? valorOriginal;
  double? valorCompra;
  double? valorAtualizado;
  double? valorBaixa;
  String? deprecia;
  String? metodoDepreciacao;
  DateTime? inicioDepreciacao;
  DateTime? ultimaDepreciacao;
  String? tipoDepreciacao;
  double? taxaAnualDepreciacao;
  double? taxaMensalDepreciacao;
  double? taxaDepreciacaoAcelerada;
  double? taxaDepreciacaoIncentivada;
  String? funcao;
  List<PatrimDocumentoBemModel>? patrimDocumentoBemModelList;
  List<PatrimDepreciacaoBemModel>? patrimDepreciacaoBemModelList;
  List<PatrimMovimentacaoBemModel>? patrimMovimentacaoBemModelList;
  List<PatrimApoliceSeguroModel>? patrimApoliceSeguroModelList;
  CentroResultadoModel? centroResultadoModel;
  PatrimEstadoConservacaoModel? patrimEstadoConservacaoModel;
  SetorModel? setorModel;
  ViewPessoaFornecedorModel? viewPessoaFornecedorModel;
  PatrimTipoAquisicaoBemModel? patrimTipoAquisicaoBemModel;
  PatrimGrupoBemModel? patrimGrupoBemModel;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  PatrimBemModel({
    this.id,
    this.idCentroResultado,
    this.idFornecedor,
    this.idColaborador,
    this.idPatrimTipoAquisicaoBem,
    this.idPatrimEstadoConservacao,
    this.idPatrimGrupoBem,
    this.idSetor,
    this.numeroNb,
    this.nome,
    this.descricao,
    this.dataAquisicao,
    this.dataAceite,
    this.dataCadastro,
    this.dataContabilizado,
    this.dataVistoria,
    this.dataMarcacao,
    this.dataBaixa,
    this.vencimentoGarantia,
    this.numeroNotaFiscal,
    this.numeroSerie,
    this.chaveNfe,
    this.valorOriginal,
    this.valorCompra,
    this.valorAtualizado,
    this.valorBaixa,
    this.deprecia = 'Sim',
    this.metodoDepreciacao = '1=Linear',
    this.inicioDepreciacao,
    this.ultimaDepreciacao,
    this.tipoDepreciacao = 'Normal',
    this.taxaAnualDepreciacao,
    this.taxaMensalDepreciacao,
    this.taxaDepreciacaoAcelerada,
    this.taxaDepreciacaoIncentivada,
    this.funcao,
    List<PatrimDocumentoBemModel>? patrimDocumentoBemModelList,
    List<PatrimDepreciacaoBemModel>? patrimDepreciacaoBemModelList,
    List<PatrimMovimentacaoBemModel>? patrimMovimentacaoBemModelList,
    List<PatrimApoliceSeguroModel>? patrimApoliceSeguroModelList,
    CentroResultadoModel? centroResultadoModel,
    PatrimEstadoConservacaoModel? patrimEstadoConservacaoModel,
    SetorModel? setorModel,
    ViewPessoaFornecedorModel? viewPessoaFornecedorModel,
    PatrimTipoAquisicaoBemModel? patrimTipoAquisicaoBemModel,
    PatrimGrupoBemModel? patrimGrupoBemModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.patrimDocumentoBemModelList = patrimDocumentoBemModelList?.toList(growable: true) ?? [];
    this.patrimDepreciacaoBemModelList = patrimDepreciacaoBemModelList?.toList(growable: true) ?? [];
    this.patrimMovimentacaoBemModelList = patrimMovimentacaoBemModelList?.toList(growable: true) ?? [];
    this.patrimApoliceSeguroModelList = patrimApoliceSeguroModelList?.toList(growable: true) ?? [];
    this.centroResultadoModel = centroResultadoModel ?? CentroResultadoModel();
    this.patrimEstadoConservacaoModel = patrimEstadoConservacaoModel ?? PatrimEstadoConservacaoModel();
    this.setorModel = setorModel ?? SetorModel();
    this.viewPessoaFornecedorModel = viewPessoaFornecedorModel ?? ViewPessoaFornecedorModel();
    this.patrimTipoAquisicaoBemModel = patrimTipoAquisicaoBemModel ?? PatrimTipoAquisicaoBemModel();
    this.patrimGrupoBemModel = patrimGrupoBemModel ?? PatrimGrupoBemModel();
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero_nb',
    'nome',
    'descricao',
    'data_aquisicao',
    'data_aceite',
    'data_cadastro',
    'data_contabilizado',
    'data_vistoria',
    'data_marcacao',
    'data_baixa',
    'vencimento_garantia',
    'numero_nota_fiscal',
    'numero_serie',
    'chave_nfe',
    'valor_original',
    'valor_compra',
    'valor_atualizado',
    'valor_baixa',
    'deprecia',
    'metodo_depreciacao',
    'inicio_depreciacao',
    'ultima_depreciacao',
    'tipo_depreciacao',
    'taxa_anual_depreciacao',
    'taxa_mensal_depreciacao',
    'taxa_depreciacao_acelerada',
    'taxa_depreciacao_incentivada',
    'funcao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Nb',
    'Nome',
    'Descricao',
    'Data Aquisicao',
    'Data Aceite',
    'Data Cadastro',
    'Data Contabilizado',
    'Data Vistoria',
    'Data Marcacao',
    'Data Baixa',
    'Vencimento Garantia',
    'Numero Nota Fiscal',
    'Numero Serie',
    'Chave Nfe',
    'Valor Original',
    'Valor Compra',
    'Valor Atualizado',
    'Valor Baixa',
    'Deprecia',
    'Metodo Depreciacao',
    'Inicio Depreciacao',
    'Ultima Depreciacao',
    'Tipo Depreciacao',
    'Taxa Anual Depreciacao',
    'Taxa Mensal Depreciacao',
    'Taxa Depreciacao Acelerada',
    'Taxa Depreciacao Incentivada',
    'Funcao',
  ];

  PatrimBemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    idFornecedor = jsonData['idFornecedor'];
    idColaborador = jsonData['idColaborador'];
    idPatrimTipoAquisicaoBem = jsonData['idPatrimTipoAquisicaoBem'];
    idPatrimEstadoConservacao = jsonData['idPatrimEstadoConservacao'];
    idPatrimGrupoBem = jsonData['idPatrimGrupoBem'];
    idSetor = jsonData['idSetor'];
    numeroNb = jsonData['numeroNb'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    dataAquisicao = jsonData['dataAquisicao'] != null ? DateTime.tryParse(jsonData['dataAquisicao']) : null;
    dataAceite = jsonData['dataAceite'] != null ? DateTime.tryParse(jsonData['dataAceite']) : null;
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataContabilizado = jsonData['dataContabilizado'] != null ? DateTime.tryParse(jsonData['dataContabilizado']) : null;
    dataVistoria = jsonData['dataVistoria'] != null ? DateTime.tryParse(jsonData['dataVistoria']) : null;
    dataMarcacao = jsonData['dataMarcacao'] != null ? DateTime.tryParse(jsonData['dataMarcacao']) : null;
    dataBaixa = jsonData['dataBaixa'] != null ? DateTime.tryParse(jsonData['dataBaixa']) : null;
    vencimentoGarantia = jsonData['vencimentoGarantia'] != null ? DateTime.tryParse(jsonData['vencimentoGarantia']) : null;
    numeroNotaFiscal = jsonData['numeroNotaFiscal'];
    numeroSerie = jsonData['numeroSerie'];
    chaveNfe = jsonData['chaveNfe'];
    valorOriginal = jsonData['valorOriginal']?.toDouble();
    valorCompra = jsonData['valorCompra']?.toDouble();
    valorAtualizado = jsonData['valorAtualizado']?.toDouble();
    valorBaixa = jsonData['valorBaixa']?.toDouble();
    deprecia = PatrimBemDomain.getDeprecia(jsonData['deprecia']);
    metodoDepreciacao = PatrimBemDomain.getMetodoDepreciacao(jsonData['metodoDepreciacao']);
    inicioDepreciacao = jsonData['inicioDepreciacao'] != null ? DateTime.tryParse(jsonData['inicioDepreciacao']) : null;
    ultimaDepreciacao = jsonData['ultimaDepreciacao'] != null ? DateTime.tryParse(jsonData['ultimaDepreciacao']) : null;
    tipoDepreciacao = PatrimBemDomain.getTipoDepreciacao(jsonData['tipoDepreciacao']);
    taxaAnualDepreciacao = jsonData['taxaAnualDepreciacao']?.toDouble();
    taxaMensalDepreciacao = jsonData['taxaMensalDepreciacao']?.toDouble();
    taxaDepreciacaoAcelerada = jsonData['taxaDepreciacaoAcelerada']?.toDouble();
    taxaDepreciacaoIncentivada = jsonData['taxaDepreciacaoIncentivada']?.toDouble();
    funcao = jsonData['funcao'];
    patrimDocumentoBemModelList = (jsonData['patrimDocumentoBemModelList'] as Iterable?)?.map((m) => PatrimDocumentoBemModel.fromJson(m)).toList() ?? [];
    patrimDepreciacaoBemModelList = (jsonData['patrimDepreciacaoBemModelList'] as Iterable?)?.map((m) => PatrimDepreciacaoBemModel.fromJson(m)).toList() ?? [];
    patrimMovimentacaoBemModelList = (jsonData['patrimMovimentacaoBemModelList'] as Iterable?)?.map((m) => PatrimMovimentacaoBemModel.fromJson(m)).toList() ?? [];
    patrimApoliceSeguroModelList = (jsonData['patrimApoliceSeguroModelList'] as Iterable?)?.map((m) => PatrimApoliceSeguroModel.fromJson(m)).toList() ?? [];
    centroResultadoModel = jsonData['centroResultadoModel'] == null ? CentroResultadoModel() : CentroResultadoModel.fromJson(jsonData['centroResultadoModel']);
    patrimEstadoConservacaoModel = jsonData['patrimEstadoConservacaoModel'] == null ? PatrimEstadoConservacaoModel() : PatrimEstadoConservacaoModel.fromJson(jsonData['patrimEstadoConservacaoModel']);
    setorModel = jsonData['setorModel'] == null ? SetorModel() : SetorModel.fromJson(jsonData['setorModel']);
    viewPessoaFornecedorModel = jsonData['viewPessoaFornecedorModel'] == null ? ViewPessoaFornecedorModel() : ViewPessoaFornecedorModel.fromJson(jsonData['viewPessoaFornecedorModel']);
    patrimTipoAquisicaoBemModel = jsonData['patrimTipoAquisicaoBemModel'] == null ? PatrimTipoAquisicaoBemModel() : PatrimTipoAquisicaoBemModel.fromJson(jsonData['patrimTipoAquisicaoBemModel']);
    patrimGrupoBemModel = jsonData['patrimGrupoBemModel'] == null ? PatrimGrupoBemModel() : PatrimGrupoBemModel.fromJson(jsonData['patrimGrupoBemModel']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado != 0 ? idCentroResultado : null;
    jsonData['idFornecedor'] = idFornecedor != 0 ? idFornecedor : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idPatrimTipoAquisicaoBem'] = idPatrimTipoAquisicaoBem != 0 ? idPatrimTipoAquisicaoBem : null;
    jsonData['idPatrimEstadoConservacao'] = idPatrimEstadoConservacao != 0 ? idPatrimEstadoConservacao : null;
    jsonData['idPatrimGrupoBem'] = idPatrimGrupoBem != 0 ? idPatrimGrupoBem : null;
    jsonData['idSetor'] = idSetor != 0 ? idSetor : null;
    jsonData['numeroNb'] = numeroNb;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['dataAquisicao'] = dataAquisicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAquisicao!) : null;
    jsonData['dataAceite'] = dataAceite != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAceite!) : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataContabilizado'] = dataContabilizado != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataContabilizado!) : null;
    jsonData['dataVistoria'] = dataVistoria != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVistoria!) : null;
    jsonData['dataMarcacao'] = dataMarcacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataMarcacao!) : null;
    jsonData['dataBaixa'] = dataBaixa != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBaixa!) : null;
    jsonData['vencimentoGarantia'] = vencimentoGarantia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(vencimentoGarantia!) : null;
    jsonData['numeroNotaFiscal'] = numeroNotaFiscal;
    jsonData['numeroSerie'] = numeroSerie;
    jsonData['chaveNfe'] = chaveNfe;
    jsonData['valorOriginal'] = valorOriginal;
    jsonData['valorCompra'] = valorCompra;
    jsonData['valorAtualizado'] = valorAtualizado;
    jsonData['valorBaixa'] = valorBaixa;
    jsonData['deprecia'] = PatrimBemDomain.setDeprecia(deprecia);
    jsonData['metodoDepreciacao'] = PatrimBemDomain.setMetodoDepreciacao(metodoDepreciacao);
    jsonData['inicioDepreciacao'] = inicioDepreciacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(inicioDepreciacao!) : null;
    jsonData['ultimaDepreciacao'] = ultimaDepreciacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(ultimaDepreciacao!) : null;
    jsonData['tipoDepreciacao'] = PatrimBemDomain.setTipoDepreciacao(tipoDepreciacao);
    jsonData['taxaAnualDepreciacao'] = taxaAnualDepreciacao;
    jsonData['taxaMensalDepreciacao'] = taxaMensalDepreciacao;
    jsonData['taxaDepreciacaoAcelerada'] = taxaDepreciacaoAcelerada;
    jsonData['taxaDepreciacaoIncentivada'] = taxaDepreciacaoIncentivada;
    jsonData['funcao'] = funcao;
    
		var patrimDocumentoBemModelLocalList = []; 
		for (PatrimDocumentoBemModel object in patrimDocumentoBemModelList ?? []) { 
			patrimDocumentoBemModelLocalList.add(object.toJson); 
		}
		jsonData['patrimDocumentoBemModelList'] = patrimDocumentoBemModelLocalList;
    
		var patrimDepreciacaoBemModelLocalList = []; 
		for (PatrimDepreciacaoBemModel object in patrimDepreciacaoBemModelList ?? []) { 
			patrimDepreciacaoBemModelLocalList.add(object.toJson); 
		}
		jsonData['patrimDepreciacaoBemModelList'] = patrimDepreciacaoBemModelLocalList;
    
		var patrimMovimentacaoBemModelLocalList = []; 
		for (PatrimMovimentacaoBemModel object in patrimMovimentacaoBemModelList ?? []) { 
			patrimMovimentacaoBemModelLocalList.add(object.toJson); 
		}
		jsonData['patrimMovimentacaoBemModelList'] = patrimMovimentacaoBemModelLocalList;
    
		var patrimApoliceSeguroModelLocalList = []; 
		for (PatrimApoliceSeguroModel object in patrimApoliceSeguroModelList ?? []) { 
			patrimApoliceSeguroModelLocalList.add(object.toJson); 
		}
		jsonData['patrimApoliceSeguroModelList'] = patrimApoliceSeguroModelLocalList;
    jsonData['centroResultadoModel'] = centroResultadoModel?.toJson;
    jsonData['centroResultado'] = centroResultadoModel?.descricao ?? '';
    jsonData['patrimEstadoConservacaoModel'] = patrimEstadoConservacaoModel?.toJson;
    jsonData['patrimEstadoConservacao'] = patrimEstadoConservacaoModel?.nome ?? '';
    jsonData['setorModel'] = setorModel?.toJson;
    jsonData['setor'] = setorModel?.nome ?? '';
    jsonData['viewPessoaFornecedorModel'] = viewPessoaFornecedorModel?.toJson;
    jsonData['viewPessoaFornecedor'] = viewPessoaFornecedorModel?.nome ?? '';
    jsonData['patrimTipoAquisicaoBemModel'] = patrimTipoAquisicaoBemModel?.toJson;
    jsonData['patrimTipoAquisicaoBem'] = patrimTipoAquisicaoBemModel?.nome ?? '';
    jsonData['patrimGrupoBemModel'] = patrimGrupoBemModel?.toJson;
    jsonData['patrimGrupoBem'] = patrimGrupoBemModel?.nome ?? '';
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimBemModel fromPlutoRow(PlutoRow row) {
    return PatrimBemModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idPatrimTipoAquisicaoBem: row.cells['idPatrimTipoAquisicaoBem']?.value,
      idPatrimEstadoConservacao: row.cells['idPatrimEstadoConservacao']?.value,
      idPatrimGrupoBem: row.cells['idPatrimGrupoBem']?.value,
      idSetor: row.cells['idSetor']?.value,
      numeroNb: row.cells['numeroNb']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      dataAquisicao: Util.stringToDate(row.cells['dataAquisicao']?.value),
      dataAceite: Util.stringToDate(row.cells['dataAceite']?.value),
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataContabilizado: Util.stringToDate(row.cells['dataContabilizado']?.value),
      dataVistoria: Util.stringToDate(row.cells['dataVistoria']?.value),
      dataMarcacao: Util.stringToDate(row.cells['dataMarcacao']?.value),
      dataBaixa: Util.stringToDate(row.cells['dataBaixa']?.value),
      vencimentoGarantia: Util.stringToDate(row.cells['vencimentoGarantia']?.value),
      numeroNotaFiscal: row.cells['numeroNotaFiscal']?.value,
      numeroSerie: row.cells['numeroSerie']?.value,
      chaveNfe: row.cells['chaveNfe']?.value,
      valorOriginal: row.cells['valorOriginal']?.value,
      valorCompra: row.cells['valorCompra']?.value,
      valorAtualizado: row.cells['valorAtualizado']?.value,
      valorBaixa: row.cells['valorBaixa']?.value,
      deprecia: row.cells['deprecia']?.value,
      metodoDepreciacao: row.cells['metodoDepreciacao']?.value,
      inicioDepreciacao: Util.stringToDate(row.cells['inicioDepreciacao']?.value),
      ultimaDepreciacao: Util.stringToDate(row.cells['ultimaDepreciacao']?.value),
      tipoDepreciacao: row.cells['tipoDepreciacao']?.value,
      taxaAnualDepreciacao: row.cells['taxaAnualDepreciacao']?.value,
      taxaMensalDepreciacao: row.cells['taxaMensalDepreciacao']?.value,
      taxaDepreciacaoAcelerada: row.cells['taxaDepreciacaoAcelerada']?.value,
      taxaDepreciacaoIncentivada: row.cells['taxaDepreciacaoIncentivada']?.value,
      funcao: row.cells['funcao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idPatrimTipoAquisicaoBem': PlutoCell(value: idPatrimTipoAquisicaoBem ?? 0),
        'idPatrimEstadoConservacao': PlutoCell(value: idPatrimEstadoConservacao ?? 0),
        'idPatrimGrupoBem': PlutoCell(value: idPatrimGrupoBem ?? 0),
        'idSetor': PlutoCell(value: idSetor ?? 0),
        'numeroNb': PlutoCell(value: numeroNb ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'dataAquisicao': PlutoCell(value: dataAquisicao),
        'dataAceite': PlutoCell(value: dataAceite),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataContabilizado': PlutoCell(value: dataContabilizado),
        'dataVistoria': PlutoCell(value: dataVistoria),
        'dataMarcacao': PlutoCell(value: dataMarcacao),
        'dataBaixa': PlutoCell(value: dataBaixa),
        'vencimentoGarantia': PlutoCell(value: vencimentoGarantia),
        'numeroNotaFiscal': PlutoCell(value: numeroNotaFiscal ?? ''),
        'numeroSerie': PlutoCell(value: numeroSerie ?? ''),
        'chaveNfe': PlutoCell(value: chaveNfe ?? ''),
        'valorOriginal': PlutoCell(value: valorOriginal ?? 0.0),
        'valorCompra': PlutoCell(value: valorCompra ?? 0.0),
        'valorAtualizado': PlutoCell(value: valorAtualizado ?? 0.0),
        'valorBaixa': PlutoCell(value: valorBaixa ?? 0.0),
        'deprecia': PlutoCell(value: deprecia ?? ''),
        'metodoDepreciacao': PlutoCell(value: metodoDepreciacao ?? ''),
        'inicioDepreciacao': PlutoCell(value: inicioDepreciacao),
        'ultimaDepreciacao': PlutoCell(value: ultimaDepreciacao),
        'tipoDepreciacao': PlutoCell(value: tipoDepreciacao ?? ''),
        'taxaAnualDepreciacao': PlutoCell(value: taxaAnualDepreciacao ?? 0.0),
        'taxaMensalDepreciacao': PlutoCell(value: taxaMensalDepreciacao ?? 0.0),
        'taxaDepreciacaoAcelerada': PlutoCell(value: taxaDepreciacaoAcelerada ?? 0.0),
        'taxaDepreciacaoIncentivada': PlutoCell(value: taxaDepreciacaoIncentivada ?? 0.0),
        'funcao': PlutoCell(value: funcao ?? ''),
        'centroResultado': PlutoCell(value: centroResultadoModel?.descricao ?? ''),
        'patrimEstadoConservacao': PlutoCell(value: patrimEstadoConservacaoModel?.nome ?? ''),
        'setor': PlutoCell(value: setorModel?.nome ?? ''),
        'viewPessoaFornecedor': PlutoCell(value: viewPessoaFornecedorModel?.nome ?? ''),
        'patrimTipoAquisicaoBem': PlutoCell(value: patrimTipoAquisicaoBemModel?.nome ?? ''),
        'patrimGrupoBem': PlutoCell(value: patrimGrupoBemModel?.nome ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  PatrimBemModel clone() {
    return PatrimBemModel(
      id: id,
      idCentroResultado: idCentroResultado,
      idFornecedor: idFornecedor,
      idColaborador: idColaborador,
      idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao: idPatrimEstadoConservacao,
      idPatrimGrupoBem: idPatrimGrupoBem,
      idSetor: idSetor,
      numeroNb: numeroNb,
      nome: nome,
      descricao: descricao,
      dataAquisicao: dataAquisicao,
      dataAceite: dataAceite,
      dataCadastro: dataCadastro,
      dataContabilizado: dataContabilizado,
      dataVistoria: dataVistoria,
      dataMarcacao: dataMarcacao,
      dataBaixa: dataBaixa,
      vencimentoGarantia: vencimentoGarantia,
      numeroNotaFiscal: numeroNotaFiscal,
      numeroSerie: numeroSerie,
      chaveNfe: chaveNfe,
      valorOriginal: valorOriginal,
      valorCompra: valorCompra,
      valorAtualizado: valorAtualizado,
      valorBaixa: valorBaixa,
      deprecia: deprecia,
      metodoDepreciacao: metodoDepreciacao,
      inicioDepreciacao: inicioDepreciacao,
      ultimaDepreciacao: ultimaDepreciacao,
      tipoDepreciacao: tipoDepreciacao,
      taxaAnualDepreciacao: taxaAnualDepreciacao,
      taxaMensalDepreciacao: taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
      funcao: funcao,
      patrimDocumentoBemModelList: patrimDocumentoBemModelListClone(patrimDocumentoBemModelList!),
      patrimDepreciacaoBemModelList: patrimDepreciacaoBemModelListClone(patrimDepreciacaoBemModelList!),
      patrimMovimentacaoBemModelList: patrimMovimentacaoBemModelListClone(patrimMovimentacaoBemModelList!),
      patrimApoliceSeguroModelList: patrimApoliceSeguroModelListClone(patrimApoliceSeguroModelList!),
      centroResultadoModel: centroResultadoModel?.clone(),
      patrimEstadoConservacaoModel: patrimEstadoConservacaoModel?.clone(),
      setorModel: setorModel?.clone(),
      viewPessoaFornecedorModel: viewPessoaFornecedorModel?.clone(),
      patrimTipoAquisicaoBemModel: patrimTipoAquisicaoBemModel?.clone(),
      patrimGrupoBemModel: patrimGrupoBemModel?.clone(),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }

  patrimDocumentoBemModelListClone(List<PatrimDocumentoBemModel> patrimDocumentoBemModelList) { 
		List<PatrimDocumentoBemModel> resultList = [];
		for (var patrimDocumentoBemModel in patrimDocumentoBemModelList) {
			resultList.add(patrimDocumentoBemModel.clone());
		}
		return resultList;
	}

  patrimDepreciacaoBemModelListClone(List<PatrimDepreciacaoBemModel> patrimDepreciacaoBemModelList) { 
		List<PatrimDepreciacaoBemModel> resultList = [];
		for (var patrimDepreciacaoBemModel in patrimDepreciacaoBemModelList) {
			resultList.add(patrimDepreciacaoBemModel.clone());
		}
		return resultList;
	}

  patrimMovimentacaoBemModelListClone(List<PatrimMovimentacaoBemModel> patrimMovimentacaoBemModelList) { 
		List<PatrimMovimentacaoBemModel> resultList = [];
		for (var patrimMovimentacaoBemModel in patrimMovimentacaoBemModelList) {
			resultList.add(patrimMovimentacaoBemModel.clone());
		}
		return resultList;
	}

  patrimApoliceSeguroModelListClone(List<PatrimApoliceSeguroModel> patrimApoliceSeguroModelList) { 
		List<PatrimApoliceSeguroModel> resultList = [];
		for (var patrimApoliceSeguroModel in patrimApoliceSeguroModelList) {
			resultList.add(patrimApoliceSeguroModel.clone());
		}
		return resultList;
	}


}