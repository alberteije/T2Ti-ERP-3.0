import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';


class PatrimTaxaDepreciacaoModel extends ModelBase {
  int? id;
  String? ncm;
  String? bem;
  double? vida;
  double? taxa;

  PatrimTaxaDepreciacaoModel({
    this.id,
    this.ncm,
    this.bem,
    this.vida,
    this.taxa,
  });

  static List<String> dbColumns = <String>[
    'id',
    'ncm',
    'bem',
    'vida',
    'taxa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Ncm',
    'Bem',
    'Vida',
    'Taxa',
  ];

  PatrimTaxaDepreciacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    ncm = jsonData['ncm'];
    bem = jsonData['bem'];
    vida = jsonData['vida']?.toDouble();
    taxa = jsonData['taxa']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['ncm'] = ncm;
    jsonData['bem'] = bem;
    jsonData['vida'] = vida;
    jsonData['taxa'] = taxa;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimTaxaDepreciacaoModel fromPlutoRow(PlutoRow row) {
    return PatrimTaxaDepreciacaoModel(
      id: row.cells['id']?.value,
      ncm: row.cells['ncm']?.value,
      bem: row.cells['bem']?.value,
      vida: row.cells['vida']?.value,
      taxa: row.cells['taxa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'ncm': PlutoCell(value: ncm ?? ''),
        'bem': PlutoCell(value: bem ?? ''),
        'vida': PlutoCell(value: vida ?? 0.0),
        'taxa': PlutoCell(value: taxa ?? 0.0),
      },
    );
  }

  PatrimTaxaDepreciacaoModel clone() {
    return PatrimTaxaDepreciacaoModel(
      id: id,
      ncm: ncm,
      bem: bem,
      vida: vida,
      taxa: taxa,
    );
  }


}