import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class PatrimMovimentacaoBemModel extends ModelBase {
  int? id;
  int? idPatrimBem;
  int? idPatrimTipoMovimentacao;
  DateTime? dataMovimentacao;
  String? responsavel;
  PatrimTipoMovimentacaoModel? patrimTipoMovimentacaoModel;

  PatrimMovimentacaoBemModel({
    this.id,
    this.idPatrimBem,
    this.idPatrimTipoMovimentacao,
    this.dataMovimentacao,
    this.responsavel,
    PatrimTipoMovimentacaoModel? patrimTipoMovimentacaoModel,
  }) {
    this.patrimTipoMovimentacaoModel = patrimTipoMovimentacaoModel ?? PatrimTipoMovimentacaoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_movimentacao',
    'responsavel',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Movimentacao',
    'Responsavel',
  ];

  PatrimMovimentacaoBemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPatrimBem = jsonData['idPatrimBem'];
    idPatrimTipoMovimentacao = jsonData['idPatrimTipoMovimentacao'];
    dataMovimentacao = jsonData['dataMovimentacao'] != null ? DateTime.tryParse(jsonData['dataMovimentacao']) : null;
    responsavel = jsonData['responsavel'];
    patrimTipoMovimentacaoModel = jsonData['patrimTipoMovimentacaoModel'] == null ? PatrimTipoMovimentacaoModel() : PatrimTipoMovimentacaoModel.fromJson(jsonData['patrimTipoMovimentacaoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPatrimBem'] = idPatrimBem != 0 ? idPatrimBem : null;
    jsonData['idPatrimTipoMovimentacao'] = idPatrimTipoMovimentacao != 0 ? idPatrimTipoMovimentacao : null;
    jsonData['dataMovimentacao'] = dataMovimentacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataMovimentacao!) : null;
    jsonData['responsavel'] = responsavel;
    jsonData['patrimTipoMovimentacaoModel'] = patrimTipoMovimentacaoModel?.toJson;
    jsonData['patrimTipoMovimentacao'] = patrimTipoMovimentacaoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimMovimentacaoBemModel fromPlutoRow(PlutoRow row) {
    return PatrimMovimentacaoBemModel(
      id: row.cells['id']?.value,
      idPatrimBem: row.cells['idPatrimBem']?.value,
      idPatrimTipoMovimentacao: row.cells['idPatrimTipoMovimentacao']?.value,
      dataMovimentacao: Util.stringToDate(row.cells['dataMovimentacao']?.value),
      responsavel: row.cells['responsavel']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPatrimBem': PlutoCell(value: idPatrimBem ?? 0),
        'idPatrimTipoMovimentacao': PlutoCell(value: idPatrimTipoMovimentacao ?? 0),
        'dataMovimentacao': PlutoCell(value: dataMovimentacao),
        'responsavel': PlutoCell(value: responsavel ?? ''),
        'patrimTipoMovimentacao': PlutoCell(value: patrimTipoMovimentacaoModel?.nome ?? ''),
      },
    );
  }

  PatrimMovimentacaoBemModel clone() {
    return PatrimMovimentacaoBemModel(
      id: id,
      idPatrimBem: idPatrimBem,
      idPatrimTipoMovimentacao: idPatrimTipoMovimentacao,
      dataMovimentacao: dataMovimentacao,
      responsavel: responsavel,
      patrimTipoMovimentacaoModel: patrimTipoMovimentacaoModel?.clone(),
    );
  }


}