import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

import 'package:patrimonio/app/data/domain/domain_imports.dart';

class CentroResultadoModel extends ModelBase {
  int? id;
  int? idPlanoCentroResultado;
  String? classificacao;
  String? descricao;
  String? sofreRateiro;

  CentroResultadoModel({
    this.id,
    this.idPlanoCentroResultado,
    this.classificacao,
    this.descricao,
    this.sofreRateiro = 'AAA',
  });

  static List<String> dbColumns = <String>[
    'id',
    'id_plano_centro_resultado',
    'classificacao',
    'descricao',
    'sofre_rateiro',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Plano Centro Resultado',
    'Classificacao',
    'Descricao',
    'Sofre Rateiro',
  ];

  CentroResultadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPlanoCentroResultado = jsonData['idPlanoCentroResultado'];
    classificacao = jsonData['classificacao'];
    descricao = jsonData['descricao'];
    sofreRateiro = CentroResultadoDomain.getSofreRateiro(jsonData['sofreRateiro']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPlanoCentroResultado'] = idPlanoCentroResultado;
    jsonData['classificacao'] = classificacao;
    jsonData['descricao'] = descricao;
    jsonData['sofreRateiro'] = CentroResultadoDomain.setSofreRateiro(sofreRateiro);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CentroResultadoModel fromPlutoRow(PlutoRow row) {
    return CentroResultadoModel(
      id: row.cells['id']?.value,
      idPlanoCentroResultado: row.cells['idPlanoCentroResultado']?.value,
      classificacao: row.cells['classificacao']?.value,
      descricao: row.cells['descricao']?.value,
      sofreRateiro: row.cells['sofreRateiro']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPlanoCentroResultado': PlutoCell(value: idPlanoCentroResultado ?? 0),
        'classificacao': PlutoCell(value: classificacao ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'sofreRateiro': PlutoCell(value: sofreRateiro ?? ''),
      },
    );
  }

  CentroResultadoModel clone() {
    return CentroResultadoModel(
      id: id,
      idPlanoCentroResultado: idPlanoCentroResultado,
      classificacao: classificacao,
      descricao: descricao,
      sofreRateiro: sofreRateiro,
    );
  }


}