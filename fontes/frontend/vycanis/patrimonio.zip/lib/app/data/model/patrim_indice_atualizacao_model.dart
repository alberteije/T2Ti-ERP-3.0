import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class PatrimIndiceAtualizacaoModel extends ModelBase {
  int? id;
  DateTime? dataIndice;
  String? nome;
  double? valor;
  double? valorAlternativo;

  PatrimIndiceAtualizacaoModel({
    this.id,
    this.dataIndice,
    this.nome,
    this.valor,
    this.valorAlternativo,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_indice',
    'nome',
    'valor',
    'valor_alternativo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Indice',
    'Nome',
    'Valor',
    'Valor Alternativo',
  ];

  PatrimIndiceAtualizacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataIndice = jsonData['dataIndice'] != null ? DateTime.tryParse(jsonData['dataIndice']) : null;
    nome = jsonData['nome'];
    valor = jsonData['valor']?.toDouble();
    valorAlternativo = jsonData['valorAlternativo']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataIndice'] = dataIndice != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataIndice!) : null;
    jsonData['nome'] = nome;
    jsonData['valor'] = valor;
    jsonData['valorAlternativo'] = valorAlternativo;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimIndiceAtualizacaoModel fromPlutoRow(PlutoRow row) {
    return PatrimIndiceAtualizacaoModel(
      id: row.cells['id']?.value,
      dataIndice: Util.stringToDate(row.cells['dataIndice']?.value),
      nome: row.cells['nome']?.value,
      valor: row.cells['valor']?.value,
      valorAlternativo: row.cells['valorAlternativo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataIndice': PlutoCell(value: dataIndice),
        'nome': PlutoCell(value: nome ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'valorAlternativo': PlutoCell(value: valorAlternativo ?? 0.0),
      },
    );
  }

  PatrimIndiceAtualizacaoModel clone() {
    return PatrimIndiceAtualizacaoModel(
      id: id,
      dataIndice: dataIndice,
      nome: nome,
      valor: valor,
      valorAlternativo: valorAlternativo,
    );
  }


}