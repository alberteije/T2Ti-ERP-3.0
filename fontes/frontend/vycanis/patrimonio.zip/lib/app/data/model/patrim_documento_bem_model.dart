import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';


class PatrimDocumentoBemModel extends ModelBase {
  int? id;
  int? idPatrimBem;
  String? nome;
  String? descricao;
  String? imagem;

  PatrimDocumentoBemModel({
    this.id,
    this.idPatrimBem,
    this.nome,
    this.descricao,
    this.imagem,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'imagem',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Imagem',
  ];

  PatrimDocumentoBemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPatrimBem = jsonData['idPatrimBem'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    imagem = jsonData['imagem'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPatrimBem'] = idPatrimBem != 0 ? idPatrimBem : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['imagem'] = imagem;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimDocumentoBemModel fromPlutoRow(PlutoRow row) {
    return PatrimDocumentoBemModel(
      id: row.cells['id']?.value,
      idPatrimBem: row.cells['idPatrimBem']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      imagem: row.cells['imagem']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPatrimBem': PlutoCell(value: idPatrimBem ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'imagem': PlutoCell(value: imagem ?? ''),
      },
    );
  }

  PatrimDocumentoBemModel clone() {
    return PatrimDocumentoBemModel(
      id: id,
      idPatrimBem: idPatrimBem,
      nome: nome,
      descricao: descricao,
      imagem: imagem,
    );
  }


}