import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimGrupoBemApiProvider extends ApiProviderBase {
  static const _path = '/patrim-grupo-bem';

  Future<List<PatrimGrupoBemModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimGrupoBemModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimGrupoBemModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimGrupoBemModel.fromJson(json),
    );
  }

  Future<PatrimGrupoBemModel?>? insert(PatrimGrupoBemModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimGrupoBemModel.fromJson(json),
    );
  }

  Future<PatrimGrupoBemModel?>? update(PatrimGrupoBemModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimGrupoBemModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
