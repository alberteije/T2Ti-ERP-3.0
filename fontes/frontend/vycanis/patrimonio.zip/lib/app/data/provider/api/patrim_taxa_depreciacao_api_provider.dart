import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimTaxaDepreciacaoApiProvider extends ApiProviderBase {
  static const _path = '/patrim-taxa-depreciacao';

  Future<List<PatrimTaxaDepreciacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimTaxaDepreciacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimTaxaDepreciacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimTaxaDepreciacaoModel.fromJson(json),
    );
  }

  Future<PatrimTaxaDepreciacaoModel?>? insert(PatrimTaxaDepreciacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimTaxaDepreciacaoModel.fromJson(json),
    );
  }

  Future<PatrimTaxaDepreciacaoModel?>? update(PatrimTaxaDepreciacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimTaxaDepreciacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
