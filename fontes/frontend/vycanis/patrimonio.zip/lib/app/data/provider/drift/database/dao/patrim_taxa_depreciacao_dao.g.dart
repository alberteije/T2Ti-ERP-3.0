// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_taxa_depreciacao_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimTaxaDepreciacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimTaxaDepreciacaosTable get patrimTaxaDepreciacaos =>
      attachedDatabase.patrimTaxaDepreciacaos;
}
