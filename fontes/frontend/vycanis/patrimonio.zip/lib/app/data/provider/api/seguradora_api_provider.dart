import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class SeguradoraApiProvider extends ApiProviderBase {
  static const _path = '/seguradora';

  Future<List<SeguradoraModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SeguradoraModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SeguradoraModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SeguradoraModel.fromJson(json),
    );
  }

  Future<SeguradoraModel?>? insert(SeguradoraModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SeguradoraModel.fromJson(json),
    );
  }

  Future<SeguradoraModel?>? update(SeguradoraModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SeguradoraModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
