import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimTipoMovimentacaoApiProvider extends ApiProviderBase {
  static const _path = '/patrim-tipo-movimentacao';

  Future<List<PatrimTipoMovimentacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimTipoMovimentacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimTipoMovimentacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimTipoMovimentacaoModel.fromJson(json),
    );
  }

  Future<PatrimTipoMovimentacaoModel?>? insert(PatrimTipoMovimentacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimTipoMovimentacaoModel.fromJson(json),
    );
  }

  Future<PatrimTipoMovimentacaoModel?>? update(PatrimTipoMovimentacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimTipoMovimentacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
