// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_grupo_bem_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimGrupoBemDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimGrupoBemsTable get patrimGrupoBems => attachedDatabase.patrimGrupoBems;
}
