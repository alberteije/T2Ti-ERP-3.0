import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimEstadoConservacaoApiProvider extends ApiProviderBase {
  static const _path = '/patrim-estado-conservacao';

  Future<List<PatrimEstadoConservacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimEstadoConservacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimEstadoConservacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimEstadoConservacaoModel.fromJson(json),
    );
  }

  Future<PatrimEstadoConservacaoModel?>? insert(PatrimEstadoConservacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimEstadoConservacaoModel.fromJson(json),
    );
  }

  Future<PatrimEstadoConservacaoModel?>? update(PatrimEstadoConservacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimEstadoConservacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
