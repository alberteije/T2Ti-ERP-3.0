import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class ViewPessoaFornecedorApiProvider extends ApiProviderBase {
  static const _path = '/view-pessoa-fornecedor';

  Future<List<ViewPessoaFornecedorModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewPessoaFornecedorModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewPessoaFornecedorModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewPessoaFornecedorModel.fromJson(json),
    );
  }

  Future<ViewPessoaFornecedorModel?>? insert(ViewPessoaFornecedorModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewPessoaFornecedorModel.fromJson(json),
    );
  }

  Future<ViewPessoaFornecedorModel?>? update(ViewPessoaFornecedorModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewPessoaFornecedorModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
