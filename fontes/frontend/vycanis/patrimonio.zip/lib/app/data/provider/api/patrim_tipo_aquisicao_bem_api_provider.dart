import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimTipoAquisicaoBemApiProvider extends ApiProviderBase {
  static const _path = '/patrim-tipo-aquisicao-bem';

  Future<List<PatrimTipoAquisicaoBemModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimTipoAquisicaoBemModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimTipoAquisicaoBemModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimTipoAquisicaoBemModel.fromJson(json),
    );
  }

  Future<PatrimTipoAquisicaoBemModel?>? insert(PatrimTipoAquisicaoBemModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimTipoAquisicaoBemModel.fromJson(json),
    );
  }

  Future<PatrimTipoAquisicaoBemModel?>? update(PatrimTipoAquisicaoBemModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimTipoAquisicaoBemModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
