// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_tipo_movimentacao_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimTipoMovimentacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimTipoMovimentacaosTable get patrimTipoMovimentacaos =>
      attachedDatabase.patrimTipoMovimentacaos;
}
