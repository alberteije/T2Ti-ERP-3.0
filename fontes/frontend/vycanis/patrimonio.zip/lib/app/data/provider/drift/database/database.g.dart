// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PatrimDocumentoBemsTable extends PatrimDocumentoBems
    with TableInfo<$PatrimDocumentoBemsTable, PatrimDocumentoBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimDocumentoBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimBemMeta =
      const VerificationMeta('idPatrimBem');
  @override
  late final GeneratedColumn<int> idPatrimBem = GeneratedColumn<int>(
      'id_patrim_bem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _imagemMeta = const VerificationMeta('imagem');
  @override
  late final GeneratedColumn<String> imagem = GeneratedColumn<String>(
      'imagem', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPatrimBem, nome, descricao, imagem];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_documento_bem';
  @override
  VerificationContext validateIntegrity(Insertable<PatrimDocumentoBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_patrim_bem')) {
      context.handle(
          _idPatrimBemMeta,
          idPatrimBem.isAcceptableOrUnknown(
              data['id_patrim_bem']!, _idPatrimBemMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('imagem')) {
      context.handle(_imagemMeta,
          imagem.isAcceptableOrUnknown(data['imagem']!, _imagemMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimDocumentoBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimDocumentoBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPatrimBem: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_patrim_bem']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      imagem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}imagem']),
    );
  }

  @override
  $PatrimDocumentoBemsTable createAlias(String alias) {
    return $PatrimDocumentoBemsTable(attachedDatabase, alias);
  }
}

class PatrimDocumentoBem extends DataClass
    implements Insertable<PatrimDocumentoBem> {
  final int? id;
  final int? idPatrimBem;
  final String? nome;
  final String? descricao;
  final String? imagem;
  const PatrimDocumentoBem(
      {this.id, this.idPatrimBem, this.nome, this.descricao, this.imagem});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPatrimBem != null) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || imagem != null) {
      map['imagem'] = Variable<String>(imagem);
    }
    return map;
  }

  factory PatrimDocumentoBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimDocumentoBem(
      id: serializer.fromJson<int?>(json['id']),
      idPatrimBem: serializer.fromJson<int?>(json['idPatrimBem']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      imagem: serializer.fromJson<String?>(json['imagem']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPatrimBem': serializer.toJson<int?>(idPatrimBem),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'imagem': serializer.toJson<String?>(imagem),
    };
  }

  PatrimDocumentoBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPatrimBem = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> imagem = const Value.absent()}) =>
      PatrimDocumentoBem(
        id: id.present ? id.value : this.id,
        idPatrimBem: idPatrimBem.present ? idPatrimBem.value : this.idPatrimBem,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        imagem: imagem.present ? imagem.value : this.imagem,
      );
  PatrimDocumentoBem copyWithCompanion(PatrimDocumentoBemsCompanion data) {
    return PatrimDocumentoBem(
      id: data.id.present ? data.id.value : this.id,
      idPatrimBem:
          data.idPatrimBem.present ? data.idPatrimBem.value : this.idPatrimBem,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      imagem: data.imagem.present ? data.imagem.value : this.imagem,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimDocumentoBem(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('imagem: $imagem')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPatrimBem, nome, descricao, imagem);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimDocumentoBem &&
          other.id == this.id &&
          other.idPatrimBem == this.idPatrimBem &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.imagem == this.imagem);
}

class PatrimDocumentoBemsCompanion extends UpdateCompanion<PatrimDocumentoBem> {
  final Value<int?> id;
  final Value<int?> idPatrimBem;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> imagem;
  const PatrimDocumentoBemsCompanion({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.imagem = const Value.absent(),
  });
  PatrimDocumentoBemsCompanion.insert({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.imagem = const Value.absent(),
  });
  static Insertable<PatrimDocumentoBem> custom({
    Expression<int>? id,
    Expression<int>? idPatrimBem,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? imagem,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPatrimBem != null) 'id_patrim_bem': idPatrimBem,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (imagem != null) 'imagem': imagem,
    });
  }

  PatrimDocumentoBemsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPatrimBem,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? imagem}) {
    return PatrimDocumentoBemsCompanion(
      id: id ?? this.id,
      idPatrimBem: idPatrimBem ?? this.idPatrimBem,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      imagem: imagem ?? this.imagem,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPatrimBem.present) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (imagem.present) {
      map['imagem'] = Variable<String>(imagem.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimDocumentoBemsCompanion(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('imagem: $imagem')
          ..write(')'))
        .toString();
  }
}

class $PatrimDepreciacaoBemsTable extends PatrimDepreciacaoBems
    with TableInfo<$PatrimDepreciacaoBemsTable, PatrimDepreciacaoBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimDepreciacaoBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimBemMeta =
      const VerificationMeta('idPatrimBem');
  @override
  late final GeneratedColumn<int> idPatrimBem = GeneratedColumn<int>(
      'id_patrim_bem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataDepreciacaoMeta =
      const VerificationMeta('dataDepreciacao');
  @override
  late final GeneratedColumn<DateTime> dataDepreciacao =
      GeneratedColumn<DateTime>('data_depreciacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diasMeta = const VerificationMeta('dias');
  @override
  late final GeneratedColumn<int> dias = GeneratedColumn<int>(
      'dias', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _taxaMeta = const VerificationMeta('taxa');
  @override
  late final GeneratedColumn<double> taxa = GeneratedColumn<double>(
      'taxa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _indiceMeta = const VerificationMeta('indice');
  @override
  late final GeneratedColumn<double> indice = GeneratedColumn<double>(
      'indice', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _depreciacaoAcumuladaMeta =
      const VerificationMeta('depreciacaoAcumulada');
  @override
  late final GeneratedColumn<double> depreciacaoAcumulada =
      GeneratedColumn<double>('depreciacao_acumulada', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPatrimBem,
        dataDepreciacao,
        dias,
        taxa,
        indice,
        valor,
        depreciacaoAcumulada
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_depreciacao_bem';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimDepreciacaoBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_patrim_bem')) {
      context.handle(
          _idPatrimBemMeta,
          idPatrimBem.isAcceptableOrUnknown(
              data['id_patrim_bem']!, _idPatrimBemMeta));
    }
    if (data.containsKey('data_depreciacao')) {
      context.handle(
          _dataDepreciacaoMeta,
          dataDepreciacao.isAcceptableOrUnknown(
              data['data_depreciacao']!, _dataDepreciacaoMeta));
    }
    if (data.containsKey('dias')) {
      context.handle(
          _diasMeta, dias.isAcceptableOrUnknown(data['dias']!, _diasMeta));
    }
    if (data.containsKey('taxa')) {
      context.handle(
          _taxaMeta, taxa.isAcceptableOrUnknown(data['taxa']!, _taxaMeta));
    }
    if (data.containsKey('indice')) {
      context.handle(_indiceMeta,
          indice.isAcceptableOrUnknown(data['indice']!, _indiceMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('depreciacao_acumulada')) {
      context.handle(
          _depreciacaoAcumuladaMeta,
          depreciacaoAcumulada.isAcceptableOrUnknown(
              data['depreciacao_acumulada']!, _depreciacaoAcumuladaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimDepreciacaoBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimDepreciacaoBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPatrimBem: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_patrim_bem']),
      dataDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_depreciacao']),
      dias: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias']),
      taxa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa']),
      indice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}indice']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      depreciacaoAcumulada: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}depreciacao_acumulada']),
    );
  }

  @override
  $PatrimDepreciacaoBemsTable createAlias(String alias) {
    return $PatrimDepreciacaoBemsTable(attachedDatabase, alias);
  }
}

class PatrimDepreciacaoBem extends DataClass
    implements Insertable<PatrimDepreciacaoBem> {
  final int? id;
  final int? idPatrimBem;
  final DateTime? dataDepreciacao;
  final int? dias;
  final double? taxa;
  final double? indice;
  final double? valor;
  final double? depreciacaoAcumulada;
  const PatrimDepreciacaoBem(
      {this.id,
      this.idPatrimBem,
      this.dataDepreciacao,
      this.dias,
      this.taxa,
      this.indice,
      this.valor,
      this.depreciacaoAcumulada});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPatrimBem != null) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem);
    }
    if (!nullToAbsent || dataDepreciacao != null) {
      map['data_depreciacao'] = Variable<DateTime>(dataDepreciacao);
    }
    if (!nullToAbsent || dias != null) {
      map['dias'] = Variable<int>(dias);
    }
    if (!nullToAbsent || taxa != null) {
      map['taxa'] = Variable<double>(taxa);
    }
    if (!nullToAbsent || indice != null) {
      map['indice'] = Variable<double>(indice);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || depreciacaoAcumulada != null) {
      map['depreciacao_acumulada'] = Variable<double>(depreciacaoAcumulada);
    }
    return map;
  }

  factory PatrimDepreciacaoBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimDepreciacaoBem(
      id: serializer.fromJson<int?>(json['id']),
      idPatrimBem: serializer.fromJson<int?>(json['idPatrimBem']),
      dataDepreciacao: serializer.fromJson<DateTime?>(json['dataDepreciacao']),
      dias: serializer.fromJson<int?>(json['dias']),
      taxa: serializer.fromJson<double?>(json['taxa']),
      indice: serializer.fromJson<double?>(json['indice']),
      valor: serializer.fromJson<double?>(json['valor']),
      depreciacaoAcumulada:
          serializer.fromJson<double?>(json['depreciacaoAcumulada']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPatrimBem': serializer.toJson<int?>(idPatrimBem),
      'dataDepreciacao': serializer.toJson<DateTime?>(dataDepreciacao),
      'dias': serializer.toJson<int?>(dias),
      'taxa': serializer.toJson<double?>(taxa),
      'indice': serializer.toJson<double?>(indice),
      'valor': serializer.toJson<double?>(valor),
      'depreciacaoAcumulada': serializer.toJson<double?>(depreciacaoAcumulada),
    };
  }

  PatrimDepreciacaoBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPatrimBem = const Value.absent(),
          Value<DateTime?> dataDepreciacao = const Value.absent(),
          Value<int?> dias = const Value.absent(),
          Value<double?> taxa = const Value.absent(),
          Value<double?> indice = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<double?> depreciacaoAcumulada = const Value.absent()}) =>
      PatrimDepreciacaoBem(
        id: id.present ? id.value : this.id,
        idPatrimBem: idPatrimBem.present ? idPatrimBem.value : this.idPatrimBem,
        dataDepreciacao: dataDepreciacao.present
            ? dataDepreciacao.value
            : this.dataDepreciacao,
        dias: dias.present ? dias.value : this.dias,
        taxa: taxa.present ? taxa.value : this.taxa,
        indice: indice.present ? indice.value : this.indice,
        valor: valor.present ? valor.value : this.valor,
        depreciacaoAcumulada: depreciacaoAcumulada.present
            ? depreciacaoAcumulada.value
            : this.depreciacaoAcumulada,
      );
  PatrimDepreciacaoBem copyWithCompanion(PatrimDepreciacaoBemsCompanion data) {
    return PatrimDepreciacaoBem(
      id: data.id.present ? data.id.value : this.id,
      idPatrimBem:
          data.idPatrimBem.present ? data.idPatrimBem.value : this.idPatrimBem,
      dataDepreciacao: data.dataDepreciacao.present
          ? data.dataDepreciacao.value
          : this.dataDepreciacao,
      dias: data.dias.present ? data.dias.value : this.dias,
      taxa: data.taxa.present ? data.taxa.value : this.taxa,
      indice: data.indice.present ? data.indice.value : this.indice,
      valor: data.valor.present ? data.valor.value : this.valor,
      depreciacaoAcumulada: data.depreciacaoAcumulada.present
          ? data.depreciacaoAcumulada.value
          : this.depreciacaoAcumulada,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimDepreciacaoBem(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('dataDepreciacao: $dataDepreciacao, ')
          ..write('dias: $dias, ')
          ..write('taxa: $taxa, ')
          ..write('indice: $indice, ')
          ..write('valor: $valor, ')
          ..write('depreciacaoAcumulada: $depreciacaoAcumulada')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPatrimBem, dataDepreciacao, dias, taxa,
      indice, valor, depreciacaoAcumulada);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimDepreciacaoBem &&
          other.id == this.id &&
          other.idPatrimBem == this.idPatrimBem &&
          other.dataDepreciacao == this.dataDepreciacao &&
          other.dias == this.dias &&
          other.taxa == this.taxa &&
          other.indice == this.indice &&
          other.valor == this.valor &&
          other.depreciacaoAcumulada == this.depreciacaoAcumulada);
}

class PatrimDepreciacaoBemsCompanion
    extends UpdateCompanion<PatrimDepreciacaoBem> {
  final Value<int?> id;
  final Value<int?> idPatrimBem;
  final Value<DateTime?> dataDepreciacao;
  final Value<int?> dias;
  final Value<double?> taxa;
  final Value<double?> indice;
  final Value<double?> valor;
  final Value<double?> depreciacaoAcumulada;
  const PatrimDepreciacaoBemsCompanion({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.dataDepreciacao = const Value.absent(),
    this.dias = const Value.absent(),
    this.taxa = const Value.absent(),
    this.indice = const Value.absent(),
    this.valor = const Value.absent(),
    this.depreciacaoAcumulada = const Value.absent(),
  });
  PatrimDepreciacaoBemsCompanion.insert({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.dataDepreciacao = const Value.absent(),
    this.dias = const Value.absent(),
    this.taxa = const Value.absent(),
    this.indice = const Value.absent(),
    this.valor = const Value.absent(),
    this.depreciacaoAcumulada = const Value.absent(),
  });
  static Insertable<PatrimDepreciacaoBem> custom({
    Expression<int>? id,
    Expression<int>? idPatrimBem,
    Expression<DateTime>? dataDepreciacao,
    Expression<int>? dias,
    Expression<double>? taxa,
    Expression<double>? indice,
    Expression<double>? valor,
    Expression<double>? depreciacaoAcumulada,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPatrimBem != null) 'id_patrim_bem': idPatrimBem,
      if (dataDepreciacao != null) 'data_depreciacao': dataDepreciacao,
      if (dias != null) 'dias': dias,
      if (taxa != null) 'taxa': taxa,
      if (indice != null) 'indice': indice,
      if (valor != null) 'valor': valor,
      if (depreciacaoAcumulada != null)
        'depreciacao_acumulada': depreciacaoAcumulada,
    });
  }

  PatrimDepreciacaoBemsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPatrimBem,
      Value<DateTime?>? dataDepreciacao,
      Value<int?>? dias,
      Value<double?>? taxa,
      Value<double?>? indice,
      Value<double?>? valor,
      Value<double?>? depreciacaoAcumulada}) {
    return PatrimDepreciacaoBemsCompanion(
      id: id ?? this.id,
      idPatrimBem: idPatrimBem ?? this.idPatrimBem,
      dataDepreciacao: dataDepreciacao ?? this.dataDepreciacao,
      dias: dias ?? this.dias,
      taxa: taxa ?? this.taxa,
      indice: indice ?? this.indice,
      valor: valor ?? this.valor,
      depreciacaoAcumulada: depreciacaoAcumulada ?? this.depreciacaoAcumulada,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPatrimBem.present) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem.value);
    }
    if (dataDepreciacao.present) {
      map['data_depreciacao'] = Variable<DateTime>(dataDepreciacao.value);
    }
    if (dias.present) {
      map['dias'] = Variable<int>(dias.value);
    }
    if (taxa.present) {
      map['taxa'] = Variable<double>(taxa.value);
    }
    if (indice.present) {
      map['indice'] = Variable<double>(indice.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (depreciacaoAcumulada.present) {
      map['depreciacao_acumulada'] =
          Variable<double>(depreciacaoAcumulada.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimDepreciacaoBemsCompanion(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('dataDepreciacao: $dataDepreciacao, ')
          ..write('dias: $dias, ')
          ..write('taxa: $taxa, ')
          ..write('indice: $indice, ')
          ..write('valor: $valor, ')
          ..write('depreciacaoAcumulada: $depreciacaoAcumulada')
          ..write(')'))
        .toString();
  }
}

class $PatrimMovimentacaoBemsTable extends PatrimMovimentacaoBems
    with TableInfo<$PatrimMovimentacaoBemsTable, PatrimMovimentacaoBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimMovimentacaoBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimBemMeta =
      const VerificationMeta('idPatrimBem');
  @override
  late final GeneratedColumn<int> idPatrimBem = GeneratedColumn<int>(
      'id_patrim_bem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimTipoMovimentacaoMeta =
      const VerificationMeta('idPatrimTipoMovimentacao');
  @override
  late final GeneratedColumn<int> idPatrimTipoMovimentacao =
      GeneratedColumn<int>('id_patrim_tipo_movimentacao', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataMovimentacaoMeta =
      const VerificationMeta('dataMovimentacao');
  @override
  late final GeneratedColumn<DateTime> dataMovimentacao =
      GeneratedColumn<DateTime>('data_movimentacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _responsavelMeta =
      const VerificationMeta('responsavel');
  @override
  late final GeneratedColumn<String> responsavel = GeneratedColumn<String>(
      'responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPatrimBem,
        idPatrimTipoMovimentacao,
        dataMovimentacao,
        responsavel
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_movimentacao_bem';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimMovimentacaoBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_patrim_bem')) {
      context.handle(
          _idPatrimBemMeta,
          idPatrimBem.isAcceptableOrUnknown(
              data['id_patrim_bem']!, _idPatrimBemMeta));
    }
    if (data.containsKey('id_patrim_tipo_movimentacao')) {
      context.handle(
          _idPatrimTipoMovimentacaoMeta,
          idPatrimTipoMovimentacao.isAcceptableOrUnknown(
              data['id_patrim_tipo_movimentacao']!,
              _idPatrimTipoMovimentacaoMeta));
    }
    if (data.containsKey('data_movimentacao')) {
      context.handle(
          _dataMovimentacaoMeta,
          dataMovimentacao.isAcceptableOrUnknown(
              data['data_movimentacao']!, _dataMovimentacaoMeta));
    }
    if (data.containsKey('responsavel')) {
      context.handle(
          _responsavelMeta,
          responsavel.isAcceptableOrUnknown(
              data['responsavel']!, _responsavelMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimMovimentacaoBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimMovimentacaoBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPatrimBem: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_patrim_bem']),
      idPatrimTipoMovimentacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_patrim_tipo_movimentacao']),
      dataMovimentacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_movimentacao']),
      responsavel: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}responsavel']),
    );
  }

  @override
  $PatrimMovimentacaoBemsTable createAlias(String alias) {
    return $PatrimMovimentacaoBemsTable(attachedDatabase, alias);
  }
}

class PatrimMovimentacaoBem extends DataClass
    implements Insertable<PatrimMovimentacaoBem> {
  final int? id;
  final int? idPatrimBem;
  final int? idPatrimTipoMovimentacao;
  final DateTime? dataMovimentacao;
  final String? responsavel;
  const PatrimMovimentacaoBem(
      {this.id,
      this.idPatrimBem,
      this.idPatrimTipoMovimentacao,
      this.dataMovimentacao,
      this.responsavel});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPatrimBem != null) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem);
    }
    if (!nullToAbsent || idPatrimTipoMovimentacao != null) {
      map['id_patrim_tipo_movimentacao'] =
          Variable<int>(idPatrimTipoMovimentacao);
    }
    if (!nullToAbsent || dataMovimentacao != null) {
      map['data_movimentacao'] = Variable<DateTime>(dataMovimentacao);
    }
    if (!nullToAbsent || responsavel != null) {
      map['responsavel'] = Variable<String>(responsavel);
    }
    return map;
  }

  factory PatrimMovimentacaoBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimMovimentacaoBem(
      id: serializer.fromJson<int?>(json['id']),
      idPatrimBem: serializer.fromJson<int?>(json['idPatrimBem']),
      idPatrimTipoMovimentacao:
          serializer.fromJson<int?>(json['idPatrimTipoMovimentacao']),
      dataMovimentacao:
          serializer.fromJson<DateTime?>(json['dataMovimentacao']),
      responsavel: serializer.fromJson<String?>(json['responsavel']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPatrimBem': serializer.toJson<int?>(idPatrimBem),
      'idPatrimTipoMovimentacao':
          serializer.toJson<int?>(idPatrimTipoMovimentacao),
      'dataMovimentacao': serializer.toJson<DateTime?>(dataMovimentacao),
      'responsavel': serializer.toJson<String?>(responsavel),
    };
  }

  PatrimMovimentacaoBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPatrimBem = const Value.absent(),
          Value<int?> idPatrimTipoMovimentacao = const Value.absent(),
          Value<DateTime?> dataMovimentacao = const Value.absent(),
          Value<String?> responsavel = const Value.absent()}) =>
      PatrimMovimentacaoBem(
        id: id.present ? id.value : this.id,
        idPatrimBem: idPatrimBem.present ? idPatrimBem.value : this.idPatrimBem,
        idPatrimTipoMovimentacao: idPatrimTipoMovimentacao.present
            ? idPatrimTipoMovimentacao.value
            : this.idPatrimTipoMovimentacao,
        dataMovimentacao: dataMovimentacao.present
            ? dataMovimentacao.value
            : this.dataMovimentacao,
        responsavel: responsavel.present ? responsavel.value : this.responsavel,
      );
  PatrimMovimentacaoBem copyWithCompanion(
      PatrimMovimentacaoBemsCompanion data) {
    return PatrimMovimentacaoBem(
      id: data.id.present ? data.id.value : this.id,
      idPatrimBem:
          data.idPatrimBem.present ? data.idPatrimBem.value : this.idPatrimBem,
      idPatrimTipoMovimentacao: data.idPatrimTipoMovimentacao.present
          ? data.idPatrimTipoMovimentacao.value
          : this.idPatrimTipoMovimentacao,
      dataMovimentacao: data.dataMovimentacao.present
          ? data.dataMovimentacao.value
          : this.dataMovimentacao,
      responsavel:
          data.responsavel.present ? data.responsavel.value : this.responsavel,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimMovimentacaoBem(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('idPatrimTipoMovimentacao: $idPatrimTipoMovimentacao, ')
          ..write('dataMovimentacao: $dataMovimentacao, ')
          ..write('responsavel: $responsavel')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPatrimBem, idPatrimTipoMovimentacao, dataMovimentacao, responsavel);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimMovimentacaoBem &&
          other.id == this.id &&
          other.idPatrimBem == this.idPatrimBem &&
          other.idPatrimTipoMovimentacao == this.idPatrimTipoMovimentacao &&
          other.dataMovimentacao == this.dataMovimentacao &&
          other.responsavel == this.responsavel);
}

class PatrimMovimentacaoBemsCompanion
    extends UpdateCompanion<PatrimMovimentacaoBem> {
  final Value<int?> id;
  final Value<int?> idPatrimBem;
  final Value<int?> idPatrimTipoMovimentacao;
  final Value<DateTime?> dataMovimentacao;
  final Value<String?> responsavel;
  const PatrimMovimentacaoBemsCompanion({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.idPatrimTipoMovimentacao = const Value.absent(),
    this.dataMovimentacao = const Value.absent(),
    this.responsavel = const Value.absent(),
  });
  PatrimMovimentacaoBemsCompanion.insert({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.idPatrimTipoMovimentacao = const Value.absent(),
    this.dataMovimentacao = const Value.absent(),
    this.responsavel = const Value.absent(),
  });
  static Insertable<PatrimMovimentacaoBem> custom({
    Expression<int>? id,
    Expression<int>? idPatrimBem,
    Expression<int>? idPatrimTipoMovimentacao,
    Expression<DateTime>? dataMovimentacao,
    Expression<String>? responsavel,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPatrimBem != null) 'id_patrim_bem': idPatrimBem,
      if (idPatrimTipoMovimentacao != null)
        'id_patrim_tipo_movimentacao': idPatrimTipoMovimentacao,
      if (dataMovimentacao != null) 'data_movimentacao': dataMovimentacao,
      if (responsavel != null) 'responsavel': responsavel,
    });
  }

  PatrimMovimentacaoBemsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPatrimBem,
      Value<int?>? idPatrimTipoMovimentacao,
      Value<DateTime?>? dataMovimentacao,
      Value<String?>? responsavel}) {
    return PatrimMovimentacaoBemsCompanion(
      id: id ?? this.id,
      idPatrimBem: idPatrimBem ?? this.idPatrimBem,
      idPatrimTipoMovimentacao:
          idPatrimTipoMovimentacao ?? this.idPatrimTipoMovimentacao,
      dataMovimentacao: dataMovimentacao ?? this.dataMovimentacao,
      responsavel: responsavel ?? this.responsavel,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPatrimBem.present) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem.value);
    }
    if (idPatrimTipoMovimentacao.present) {
      map['id_patrim_tipo_movimentacao'] =
          Variable<int>(idPatrimTipoMovimentacao.value);
    }
    if (dataMovimentacao.present) {
      map['data_movimentacao'] = Variable<DateTime>(dataMovimentacao.value);
    }
    if (responsavel.present) {
      map['responsavel'] = Variable<String>(responsavel.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimMovimentacaoBemsCompanion(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('idPatrimTipoMovimentacao: $idPatrimTipoMovimentacao, ')
          ..write('dataMovimentacao: $dataMovimentacao, ')
          ..write('responsavel: $responsavel')
          ..write(')'))
        .toString();
  }
}

class $PatrimApoliceSegurosTable extends PatrimApoliceSeguros
    with TableInfo<$PatrimApoliceSegurosTable, PatrimApoliceSeguro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimApoliceSegurosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimBemMeta =
      const VerificationMeta('idPatrimBem');
  @override
  late final GeneratedColumn<int> idPatrimBem = GeneratedColumn<int>(
      'id_patrim_bem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSeguradoraMeta =
      const VerificationMeta('idSeguradora');
  @override
  late final GeneratedColumn<int> idSeguradora = GeneratedColumn<int>(
      'id_seguradora', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataContratacaoMeta =
      const VerificationMeta('dataContratacao');
  @override
  late final GeneratedColumn<DateTime> dataContratacao =
      GeneratedColumn<DateTime>('data_contratacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorPremioMeta =
      const VerificationMeta('valorPremio');
  @override
  late final GeneratedColumn<double> valorPremio = GeneratedColumn<double>(
      'valor_premio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSeguradoMeta =
      const VerificationMeta('valorSegurado');
  @override
  late final GeneratedColumn<double> valorSegurado = GeneratedColumn<double>(
      'valor_segurado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _imagemMeta = const VerificationMeta('imagem');
  @override
  late final GeneratedColumn<String> imagem = GeneratedColumn<String>(
      'imagem', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPatrimBem,
        idSeguradora,
        numero,
        dataContratacao,
        dataVencimento,
        valorPremio,
        valorSegurado,
        observacao,
        imagem
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_apolice_seguro';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimApoliceSeguro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_patrim_bem')) {
      context.handle(
          _idPatrimBemMeta,
          idPatrimBem.isAcceptableOrUnknown(
              data['id_patrim_bem']!, _idPatrimBemMeta));
    }
    if (data.containsKey('id_seguradora')) {
      context.handle(
          _idSeguradoraMeta,
          idSeguradora.isAcceptableOrUnknown(
              data['id_seguradora']!, _idSeguradoraMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_contratacao')) {
      context.handle(
          _dataContratacaoMeta,
          dataContratacao.isAcceptableOrUnknown(
              data['data_contratacao']!, _dataContratacaoMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('valor_premio')) {
      context.handle(
          _valorPremioMeta,
          valorPremio.isAcceptableOrUnknown(
              data['valor_premio']!, _valorPremioMeta));
    }
    if (data.containsKey('valor_segurado')) {
      context.handle(
          _valorSeguradoMeta,
          valorSegurado.isAcceptableOrUnknown(
              data['valor_segurado']!, _valorSeguradoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('imagem')) {
      context.handle(_imagemMeta,
          imagem.isAcceptableOrUnknown(data['imagem']!, _imagemMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimApoliceSeguro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimApoliceSeguro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPatrimBem: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_patrim_bem']),
      idSeguradora: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_seguradora']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataContratacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_contratacao']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      valorPremio: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_premio']),
      valorSegurado: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_segurado']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      imagem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}imagem']),
    );
  }

  @override
  $PatrimApoliceSegurosTable createAlias(String alias) {
    return $PatrimApoliceSegurosTable(attachedDatabase, alias);
  }
}

class PatrimApoliceSeguro extends DataClass
    implements Insertable<PatrimApoliceSeguro> {
  final int? id;
  final int? idPatrimBem;
  final int? idSeguradora;
  final String? numero;
  final DateTime? dataContratacao;
  final DateTime? dataVencimento;
  final double? valorPremio;
  final double? valorSegurado;
  final String? observacao;
  final String? imagem;
  const PatrimApoliceSeguro(
      {this.id,
      this.idPatrimBem,
      this.idSeguradora,
      this.numero,
      this.dataContratacao,
      this.dataVencimento,
      this.valorPremio,
      this.valorSegurado,
      this.observacao,
      this.imagem});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPatrimBem != null) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem);
    }
    if (!nullToAbsent || idSeguradora != null) {
      map['id_seguradora'] = Variable<int>(idSeguradora);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataContratacao != null) {
      map['data_contratacao'] = Variable<DateTime>(dataContratacao);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || valorPremio != null) {
      map['valor_premio'] = Variable<double>(valorPremio);
    }
    if (!nullToAbsent || valorSegurado != null) {
      map['valor_segurado'] = Variable<double>(valorSegurado);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || imagem != null) {
      map['imagem'] = Variable<String>(imagem);
    }
    return map;
  }

  factory PatrimApoliceSeguro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimApoliceSeguro(
      id: serializer.fromJson<int?>(json['id']),
      idPatrimBem: serializer.fromJson<int?>(json['idPatrimBem']),
      idSeguradora: serializer.fromJson<int?>(json['idSeguradora']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataContratacao: serializer.fromJson<DateTime?>(json['dataContratacao']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      valorPremio: serializer.fromJson<double?>(json['valorPremio']),
      valorSegurado: serializer.fromJson<double?>(json['valorSegurado']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      imagem: serializer.fromJson<String?>(json['imagem']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPatrimBem': serializer.toJson<int?>(idPatrimBem),
      'idSeguradora': serializer.toJson<int?>(idSeguradora),
      'numero': serializer.toJson<String?>(numero),
      'dataContratacao': serializer.toJson<DateTime?>(dataContratacao),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'valorPremio': serializer.toJson<double?>(valorPremio),
      'valorSegurado': serializer.toJson<double?>(valorSegurado),
      'observacao': serializer.toJson<String?>(observacao),
      'imagem': serializer.toJson<String?>(imagem),
    };
  }

  PatrimApoliceSeguro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPatrimBem = const Value.absent(),
          Value<int?> idSeguradora = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataContratacao = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<double?> valorPremio = const Value.absent(),
          Value<double?> valorSegurado = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> imagem = const Value.absent()}) =>
      PatrimApoliceSeguro(
        id: id.present ? id.value : this.id,
        idPatrimBem: idPatrimBem.present ? idPatrimBem.value : this.idPatrimBem,
        idSeguradora:
            idSeguradora.present ? idSeguradora.value : this.idSeguradora,
        numero: numero.present ? numero.value : this.numero,
        dataContratacao: dataContratacao.present
            ? dataContratacao.value
            : this.dataContratacao,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        valorPremio: valorPremio.present ? valorPremio.value : this.valorPremio,
        valorSegurado:
            valorSegurado.present ? valorSegurado.value : this.valorSegurado,
        observacao: observacao.present ? observacao.value : this.observacao,
        imagem: imagem.present ? imagem.value : this.imagem,
      );
  PatrimApoliceSeguro copyWithCompanion(PatrimApoliceSegurosCompanion data) {
    return PatrimApoliceSeguro(
      id: data.id.present ? data.id.value : this.id,
      idPatrimBem:
          data.idPatrimBem.present ? data.idPatrimBem.value : this.idPatrimBem,
      idSeguradora: data.idSeguradora.present
          ? data.idSeguradora.value
          : this.idSeguradora,
      numero: data.numero.present ? data.numero.value : this.numero,
      dataContratacao: data.dataContratacao.present
          ? data.dataContratacao.value
          : this.dataContratacao,
      dataVencimento: data.dataVencimento.present
          ? data.dataVencimento.value
          : this.dataVencimento,
      valorPremio:
          data.valorPremio.present ? data.valorPremio.value : this.valorPremio,
      valorSegurado: data.valorSegurado.present
          ? data.valorSegurado.value
          : this.valorSegurado,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      imagem: data.imagem.present ? data.imagem.value : this.imagem,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimApoliceSeguro(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('idSeguradora: $idSeguradora, ')
          ..write('numero: $numero, ')
          ..write('dataContratacao: $dataContratacao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valorPremio: $valorPremio, ')
          ..write('valorSegurado: $valorSegurado, ')
          ..write('observacao: $observacao, ')
          ..write('imagem: $imagem')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPatrimBem,
      idSeguradora,
      numero,
      dataContratacao,
      dataVencimento,
      valorPremio,
      valorSegurado,
      observacao,
      imagem);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimApoliceSeguro &&
          other.id == this.id &&
          other.idPatrimBem == this.idPatrimBem &&
          other.idSeguradora == this.idSeguradora &&
          other.numero == this.numero &&
          other.dataContratacao == this.dataContratacao &&
          other.dataVencimento == this.dataVencimento &&
          other.valorPremio == this.valorPremio &&
          other.valorSegurado == this.valorSegurado &&
          other.observacao == this.observacao &&
          other.imagem == this.imagem);
}

class PatrimApoliceSegurosCompanion
    extends UpdateCompanion<PatrimApoliceSeguro> {
  final Value<int?> id;
  final Value<int?> idPatrimBem;
  final Value<int?> idSeguradora;
  final Value<String?> numero;
  final Value<DateTime?> dataContratacao;
  final Value<DateTime?> dataVencimento;
  final Value<double?> valorPremio;
  final Value<double?> valorSegurado;
  final Value<String?> observacao;
  final Value<String?> imagem;
  const PatrimApoliceSegurosCompanion({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.idSeguradora = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataContratacao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valorPremio = const Value.absent(),
    this.valorSegurado = const Value.absent(),
    this.observacao = const Value.absent(),
    this.imagem = const Value.absent(),
  });
  PatrimApoliceSegurosCompanion.insert({
    this.id = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
    this.idSeguradora = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataContratacao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valorPremio = const Value.absent(),
    this.valorSegurado = const Value.absent(),
    this.observacao = const Value.absent(),
    this.imagem = const Value.absent(),
  });
  static Insertable<PatrimApoliceSeguro> custom({
    Expression<int>? id,
    Expression<int>? idPatrimBem,
    Expression<int>? idSeguradora,
    Expression<String>? numero,
    Expression<DateTime>? dataContratacao,
    Expression<DateTime>? dataVencimento,
    Expression<double>? valorPremio,
    Expression<double>? valorSegurado,
    Expression<String>? observacao,
    Expression<String>? imagem,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPatrimBem != null) 'id_patrim_bem': idPatrimBem,
      if (idSeguradora != null) 'id_seguradora': idSeguradora,
      if (numero != null) 'numero': numero,
      if (dataContratacao != null) 'data_contratacao': dataContratacao,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (valorPremio != null) 'valor_premio': valorPremio,
      if (valorSegurado != null) 'valor_segurado': valorSegurado,
      if (observacao != null) 'observacao': observacao,
      if (imagem != null) 'imagem': imagem,
    });
  }

  PatrimApoliceSegurosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPatrimBem,
      Value<int?>? idSeguradora,
      Value<String?>? numero,
      Value<DateTime?>? dataContratacao,
      Value<DateTime?>? dataVencimento,
      Value<double?>? valorPremio,
      Value<double?>? valorSegurado,
      Value<String?>? observacao,
      Value<String?>? imagem}) {
    return PatrimApoliceSegurosCompanion(
      id: id ?? this.id,
      idPatrimBem: idPatrimBem ?? this.idPatrimBem,
      idSeguradora: idSeguradora ?? this.idSeguradora,
      numero: numero ?? this.numero,
      dataContratacao: dataContratacao ?? this.dataContratacao,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      valorPremio: valorPremio ?? this.valorPremio,
      valorSegurado: valorSegurado ?? this.valorSegurado,
      observacao: observacao ?? this.observacao,
      imagem: imagem ?? this.imagem,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPatrimBem.present) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem.value);
    }
    if (idSeguradora.present) {
      map['id_seguradora'] = Variable<int>(idSeguradora.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataContratacao.present) {
      map['data_contratacao'] = Variable<DateTime>(dataContratacao.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (valorPremio.present) {
      map['valor_premio'] = Variable<double>(valorPremio.value);
    }
    if (valorSegurado.present) {
      map['valor_segurado'] = Variable<double>(valorSegurado.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (imagem.present) {
      map['imagem'] = Variable<String>(imagem.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimApoliceSegurosCompanion(')
          ..write('id: $id, ')
          ..write('idPatrimBem: $idPatrimBem, ')
          ..write('idSeguradora: $idSeguradora, ')
          ..write('numero: $numero, ')
          ..write('dataContratacao: $dataContratacao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valorPremio: $valorPremio, ')
          ..write('valorSegurado: $valorSegurado, ')
          ..write('observacao: $observacao, ')
          ..write('imagem: $imagem')
          ..write(')'))
        .toString();
  }
}

class $PatrimBemsTable extends PatrimBems
    with TableInfo<$PatrimBemsTable, PatrimBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFornecedorMeta =
      const VerificationMeta('idFornecedor');
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
      'id_fornecedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimTipoAquisicaoBemMeta =
      const VerificationMeta('idPatrimTipoAquisicaoBem');
  @override
  late final GeneratedColumn<int> idPatrimTipoAquisicaoBem =
      GeneratedColumn<int>('id_patrim_tipo_aquisicao_bem', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimEstadoConservacaoMeta =
      const VerificationMeta('idPatrimEstadoConservacao');
  @override
  late final GeneratedColumn<int> idPatrimEstadoConservacao =
      GeneratedColumn<int>('id_patrim_estado_conservacao', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPatrimGrupoBemMeta =
      const VerificationMeta('idPatrimGrupoBem');
  @override
  late final GeneratedColumn<int> idPatrimGrupoBem = GeneratedColumn<int>(
      'id_patrim_grupo_bem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroNbMeta =
      const VerificationMeta('numeroNb');
  @override
  late final GeneratedColumn<String> numeroNb = GeneratedColumn<String>(
      'numero_nb', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _dataAquisicaoMeta =
      const VerificationMeta('dataAquisicao');
  @override
  late final GeneratedColumn<DateTime> dataAquisicao =
      GeneratedColumn<DateTime>('data_aquisicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAceiteMeta =
      const VerificationMeta('dataAceite');
  @override
  late final GeneratedColumn<DateTime> dataAceite = GeneratedColumn<DateTime>(
      'data_aceite', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataContabilizadoMeta =
      const VerificationMeta('dataContabilizado');
  @override
  late final GeneratedColumn<DateTime> dataContabilizado =
      GeneratedColumn<DateTime>('data_contabilizado', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataVistoriaMeta =
      const VerificationMeta('dataVistoria');
  @override
  late final GeneratedColumn<DateTime> dataVistoria = GeneratedColumn<DateTime>(
      'data_vistoria', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataMarcacaoMeta =
      const VerificationMeta('dataMarcacao');
  @override
  late final GeneratedColumn<DateTime> dataMarcacao = GeneratedColumn<DateTime>(
      'data_marcacao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataBaixaMeta =
      const VerificationMeta('dataBaixa');
  @override
  late final GeneratedColumn<DateTime> dataBaixa = GeneratedColumn<DateTime>(
      'data_baixa', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _vencimentoGarantiaMeta =
      const VerificationMeta('vencimentoGarantia');
  @override
  late final GeneratedColumn<DateTime> vencimentoGarantia =
      GeneratedColumn<DateTime>('vencimento_garantia', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _numeroNotaFiscalMeta =
      const VerificationMeta('numeroNotaFiscal');
  @override
  late final GeneratedColumn<String> numeroNotaFiscal = GeneratedColumn<String>(
      'numero_nota_fiscal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroSerieMeta =
      const VerificationMeta('numeroSerie');
  @override
  late final GeneratedColumn<String> numeroSerie = GeneratedColumn<String>(
      'numero_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _chaveNfeMeta =
      const VerificationMeta('chaveNfe');
  @override
  late final GeneratedColumn<String> chaveNfe = GeneratedColumn<String>(
      'chave_nfe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorOriginalMeta =
      const VerificationMeta('valorOriginal');
  @override
  late final GeneratedColumn<double> valorOriginal = GeneratedColumn<double>(
      'valor_original', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAtualizadoMeta =
      const VerificationMeta('valorAtualizado');
  @override
  late final GeneratedColumn<double> valorAtualizado = GeneratedColumn<double>(
      'valor_atualizado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBaixaMeta =
      const VerificationMeta('valorBaixa');
  @override
  late final GeneratedColumn<double> valorBaixa = GeneratedColumn<double>(
      'valor_baixa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _depreciaMeta =
      const VerificationMeta('deprecia');
  @override
  late final GeneratedColumn<String> deprecia = GeneratedColumn<String>(
      'deprecia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _metodoDepreciacaoMeta =
      const VerificationMeta('metodoDepreciacao');
  @override
  late final GeneratedColumn<String> metodoDepreciacao =
      GeneratedColumn<String>('metodo_depreciacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inicioDepreciacaoMeta =
      const VerificationMeta('inicioDepreciacao');
  @override
  late final GeneratedColumn<DateTime> inicioDepreciacao =
      GeneratedColumn<DateTime>('inicio_depreciacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ultimaDepreciacaoMeta =
      const VerificationMeta('ultimaDepreciacao');
  @override
  late final GeneratedColumn<DateTime> ultimaDepreciacao =
      GeneratedColumn<DateTime>('ultima_depreciacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoDepreciacaoMeta =
      const VerificationMeta('tipoDepreciacao');
  @override
  late final GeneratedColumn<String> tipoDepreciacao = GeneratedColumn<String>(
      'tipo_depreciacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _taxaAnualDepreciacaoMeta =
      const VerificationMeta('taxaAnualDepreciacao');
  @override
  late final GeneratedColumn<double> taxaAnualDepreciacao =
      GeneratedColumn<double>('taxa_anual_depreciacao', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaMensalDepreciacaoMeta =
      const VerificationMeta('taxaMensalDepreciacao');
  @override
  late final GeneratedColumn<double> taxaMensalDepreciacao =
      GeneratedColumn<double>('taxa_mensal_depreciacao', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDepreciacaoAceleradaMeta =
      const VerificationMeta('taxaDepreciacaoAcelerada');
  @override
  late final GeneratedColumn<double> taxaDepreciacaoAcelerada =
      GeneratedColumn<double>('taxa_depreciacao_acelerada', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDepreciacaoIncentivadaMeta =
      const VerificationMeta('taxaDepreciacaoIncentivada');
  @override
  late final GeneratedColumn<double> taxaDepreciacaoIncentivada =
      GeneratedColumn<double>('taxa_depreciacao_incentivada', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _funcaoMeta = const VerificationMeta('funcao');
  @override
  late final GeneratedColumn<String> funcao = GeneratedColumn<String>(
      'funcao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCentroResultado,
        idFornecedor,
        idColaborador,
        idPatrimTipoAquisicaoBem,
        idPatrimEstadoConservacao,
        idPatrimGrupoBem,
        idSetor,
        numeroNb,
        nome,
        descricao,
        dataAquisicao,
        dataAceite,
        dataCadastro,
        dataContabilizado,
        dataVistoria,
        dataMarcacao,
        dataBaixa,
        vencimentoGarantia,
        numeroNotaFiscal,
        numeroSerie,
        chaveNfe,
        valorOriginal,
        valorCompra,
        valorAtualizado,
        valorBaixa,
        deprecia,
        metodoDepreciacao,
        inicioDepreciacao,
        ultimaDepreciacao,
        tipoDepreciacao,
        taxaAnualDepreciacao,
        taxaMensalDepreciacao,
        taxaDepreciacaoAcelerada,
        taxaDepreciacaoIncentivada,
        funcao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_bem';
  @override
  VerificationContext validateIntegrity(Insertable<PatrimBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
          _idFornecedorMeta,
          idFornecedor.isAcceptableOrUnknown(
              data['id_fornecedor']!, _idFornecedorMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_patrim_tipo_aquisicao_bem')) {
      context.handle(
          _idPatrimTipoAquisicaoBemMeta,
          idPatrimTipoAquisicaoBem.isAcceptableOrUnknown(
              data['id_patrim_tipo_aquisicao_bem']!,
              _idPatrimTipoAquisicaoBemMeta));
    }
    if (data.containsKey('id_patrim_estado_conservacao')) {
      context.handle(
          _idPatrimEstadoConservacaoMeta,
          idPatrimEstadoConservacao.isAcceptableOrUnknown(
              data['id_patrim_estado_conservacao']!,
              _idPatrimEstadoConservacaoMeta));
    }
    if (data.containsKey('id_patrim_grupo_bem')) {
      context.handle(
          _idPatrimGrupoBemMeta,
          idPatrimGrupoBem.isAcceptableOrUnknown(
              data['id_patrim_grupo_bem']!, _idPatrimGrupoBemMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    if (data.containsKey('numero_nb')) {
      context.handle(_numeroNbMeta,
          numeroNb.isAcceptableOrUnknown(data['numero_nb']!, _numeroNbMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('data_aquisicao')) {
      context.handle(
          _dataAquisicaoMeta,
          dataAquisicao.isAcceptableOrUnknown(
              data['data_aquisicao']!, _dataAquisicaoMeta));
    }
    if (data.containsKey('data_aceite')) {
      context.handle(
          _dataAceiteMeta,
          dataAceite.isAcceptableOrUnknown(
              data['data_aceite']!, _dataAceiteMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_contabilizado')) {
      context.handle(
          _dataContabilizadoMeta,
          dataContabilizado.isAcceptableOrUnknown(
              data['data_contabilizado']!, _dataContabilizadoMeta));
    }
    if (data.containsKey('data_vistoria')) {
      context.handle(
          _dataVistoriaMeta,
          dataVistoria.isAcceptableOrUnknown(
              data['data_vistoria']!, _dataVistoriaMeta));
    }
    if (data.containsKey('data_marcacao')) {
      context.handle(
          _dataMarcacaoMeta,
          dataMarcacao.isAcceptableOrUnknown(
              data['data_marcacao']!, _dataMarcacaoMeta));
    }
    if (data.containsKey('data_baixa')) {
      context.handle(_dataBaixaMeta,
          dataBaixa.isAcceptableOrUnknown(data['data_baixa']!, _dataBaixaMeta));
    }
    if (data.containsKey('vencimento_garantia')) {
      context.handle(
          _vencimentoGarantiaMeta,
          vencimentoGarantia.isAcceptableOrUnknown(
              data['vencimento_garantia']!, _vencimentoGarantiaMeta));
    }
    if (data.containsKey('numero_nota_fiscal')) {
      context.handle(
          _numeroNotaFiscalMeta,
          numeroNotaFiscal.isAcceptableOrUnknown(
              data['numero_nota_fiscal']!, _numeroNotaFiscalMeta));
    }
    if (data.containsKey('numero_serie')) {
      context.handle(
          _numeroSerieMeta,
          numeroSerie.isAcceptableOrUnknown(
              data['numero_serie']!, _numeroSerieMeta));
    }
    if (data.containsKey('chave_nfe')) {
      context.handle(_chaveNfeMeta,
          chaveNfe.isAcceptableOrUnknown(data['chave_nfe']!, _chaveNfeMeta));
    }
    if (data.containsKey('valor_original')) {
      context.handle(
          _valorOriginalMeta,
          valorOriginal.isAcceptableOrUnknown(
              data['valor_original']!, _valorOriginalMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_atualizado')) {
      context.handle(
          _valorAtualizadoMeta,
          valorAtualizado.isAcceptableOrUnknown(
              data['valor_atualizado']!, _valorAtualizadoMeta));
    }
    if (data.containsKey('valor_baixa')) {
      context.handle(
          _valorBaixaMeta,
          valorBaixa.isAcceptableOrUnknown(
              data['valor_baixa']!, _valorBaixaMeta));
    }
    if (data.containsKey('deprecia')) {
      context.handle(_depreciaMeta,
          deprecia.isAcceptableOrUnknown(data['deprecia']!, _depreciaMeta));
    }
    if (data.containsKey('metodo_depreciacao')) {
      context.handle(
          _metodoDepreciacaoMeta,
          metodoDepreciacao.isAcceptableOrUnknown(
              data['metodo_depreciacao']!, _metodoDepreciacaoMeta));
    }
    if (data.containsKey('inicio_depreciacao')) {
      context.handle(
          _inicioDepreciacaoMeta,
          inicioDepreciacao.isAcceptableOrUnknown(
              data['inicio_depreciacao']!, _inicioDepreciacaoMeta));
    }
    if (data.containsKey('ultima_depreciacao')) {
      context.handle(
          _ultimaDepreciacaoMeta,
          ultimaDepreciacao.isAcceptableOrUnknown(
              data['ultima_depreciacao']!, _ultimaDepreciacaoMeta));
    }
    if (data.containsKey('tipo_depreciacao')) {
      context.handle(
          _tipoDepreciacaoMeta,
          tipoDepreciacao.isAcceptableOrUnknown(
              data['tipo_depreciacao']!, _tipoDepreciacaoMeta));
    }
    if (data.containsKey('taxa_anual_depreciacao')) {
      context.handle(
          _taxaAnualDepreciacaoMeta,
          taxaAnualDepreciacao.isAcceptableOrUnknown(
              data['taxa_anual_depreciacao']!, _taxaAnualDepreciacaoMeta));
    }
    if (data.containsKey('taxa_mensal_depreciacao')) {
      context.handle(
          _taxaMensalDepreciacaoMeta,
          taxaMensalDepreciacao.isAcceptableOrUnknown(
              data['taxa_mensal_depreciacao']!, _taxaMensalDepreciacaoMeta));
    }
    if (data.containsKey('taxa_depreciacao_acelerada')) {
      context.handle(
          _taxaDepreciacaoAceleradaMeta,
          taxaDepreciacaoAcelerada.isAcceptableOrUnknown(
              data['taxa_depreciacao_acelerada']!,
              _taxaDepreciacaoAceleradaMeta));
    }
    if (data.containsKey('taxa_depreciacao_incentivada')) {
      context.handle(
          _taxaDepreciacaoIncentivadaMeta,
          taxaDepreciacaoIncentivada.isAcceptableOrUnknown(
              data['taxa_depreciacao_incentivada']!,
              _taxaDepreciacaoIncentivadaMeta));
    }
    if (data.containsKey('funcao')) {
      context.handle(_funcaoMeta,
          funcao.isAcceptableOrUnknown(data['funcao']!, _funcaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      idFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fornecedor']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idPatrimTipoAquisicaoBem: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_patrim_tipo_aquisicao_bem']),
      idPatrimEstadoConservacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_patrim_estado_conservacao']),
      idPatrimGrupoBem: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_patrim_grupo_bem']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
      numeroNb: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_nb']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      dataAquisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_aquisicao']),
      dataAceite: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_aceite']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataContabilizado: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_contabilizado']),
      dataVistoria: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_vistoria']),
      dataMarcacao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_marcacao']),
      dataBaixa: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_baixa']),
      vencimentoGarantia: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}vencimento_garantia']),
      numeroNotaFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numero_nota_fiscal']),
      numeroSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_serie']),
      chaveNfe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_nfe']),
      valorOriginal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_original']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorAtualizado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_atualizado']),
      valorBaixa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_baixa']),
      deprecia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deprecia']),
      metodoDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}metodo_depreciacao']),
      inicioDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}inicio_depreciacao']),
      ultimaDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ultima_depreciacao']),
      tipoDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tipo_depreciacao']),
      taxaAnualDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}taxa_anual_depreciacao']),
      taxaMensalDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}taxa_mensal_depreciacao']),
      taxaDepreciacaoAcelerada: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}taxa_depreciacao_acelerada']),
      taxaDepreciacaoIncentivada: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}taxa_depreciacao_incentivada']),
      funcao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao']),
    );
  }

  @override
  $PatrimBemsTable createAlias(String alias) {
    return $PatrimBemsTable(attachedDatabase, alias);
  }
}

class PatrimBem extends DataClass implements Insertable<PatrimBem> {
  final int? id;
  final int? idCentroResultado;
  final int? idFornecedor;
  final int? idColaborador;
  final int? idPatrimTipoAquisicaoBem;
  final int? idPatrimEstadoConservacao;
  final int? idPatrimGrupoBem;
  final int? idSetor;
  final String? numeroNb;
  final String? nome;
  final String? descricao;
  final DateTime? dataAquisicao;
  final DateTime? dataAceite;
  final DateTime? dataCadastro;
  final DateTime? dataContabilizado;
  final DateTime? dataVistoria;
  final DateTime? dataMarcacao;
  final DateTime? dataBaixa;
  final DateTime? vencimentoGarantia;
  final String? numeroNotaFiscal;
  final String? numeroSerie;
  final String? chaveNfe;
  final double? valorOriginal;
  final double? valorCompra;
  final double? valorAtualizado;
  final double? valorBaixa;
  final String? deprecia;
  final String? metodoDepreciacao;
  final DateTime? inicioDepreciacao;
  final DateTime? ultimaDepreciacao;
  final String? tipoDepreciacao;
  final double? taxaAnualDepreciacao;
  final double? taxaMensalDepreciacao;
  final double? taxaDepreciacaoAcelerada;
  final double? taxaDepreciacaoIncentivada;
  final String? funcao;
  const PatrimBem(
      {this.id,
      this.idCentroResultado,
      this.idFornecedor,
      this.idColaborador,
      this.idPatrimTipoAquisicaoBem,
      this.idPatrimEstadoConservacao,
      this.idPatrimGrupoBem,
      this.idSetor,
      this.numeroNb,
      this.nome,
      this.descricao,
      this.dataAquisicao,
      this.dataAceite,
      this.dataCadastro,
      this.dataContabilizado,
      this.dataVistoria,
      this.dataMarcacao,
      this.dataBaixa,
      this.vencimentoGarantia,
      this.numeroNotaFiscal,
      this.numeroSerie,
      this.chaveNfe,
      this.valorOriginal,
      this.valorCompra,
      this.valorAtualizado,
      this.valorBaixa,
      this.deprecia,
      this.metodoDepreciacao,
      this.inicioDepreciacao,
      this.ultimaDepreciacao,
      this.tipoDepreciacao,
      this.taxaAnualDepreciacao,
      this.taxaMensalDepreciacao,
      this.taxaDepreciacaoAcelerada,
      this.taxaDepreciacaoIncentivada,
      this.funcao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idPatrimTipoAquisicaoBem != null) {
      map['id_patrim_tipo_aquisicao_bem'] =
          Variable<int>(idPatrimTipoAquisicaoBem);
    }
    if (!nullToAbsent || idPatrimEstadoConservacao != null) {
      map['id_patrim_estado_conservacao'] =
          Variable<int>(idPatrimEstadoConservacao);
    }
    if (!nullToAbsent || idPatrimGrupoBem != null) {
      map['id_patrim_grupo_bem'] = Variable<int>(idPatrimGrupoBem);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || numeroNb != null) {
      map['numero_nb'] = Variable<String>(numeroNb);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || dataAquisicao != null) {
      map['data_aquisicao'] = Variable<DateTime>(dataAquisicao);
    }
    if (!nullToAbsent || dataAceite != null) {
      map['data_aceite'] = Variable<DateTime>(dataAceite);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataContabilizado != null) {
      map['data_contabilizado'] = Variable<DateTime>(dataContabilizado);
    }
    if (!nullToAbsent || dataVistoria != null) {
      map['data_vistoria'] = Variable<DateTime>(dataVistoria);
    }
    if (!nullToAbsent || dataMarcacao != null) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao);
    }
    if (!nullToAbsent || dataBaixa != null) {
      map['data_baixa'] = Variable<DateTime>(dataBaixa);
    }
    if (!nullToAbsent || vencimentoGarantia != null) {
      map['vencimento_garantia'] = Variable<DateTime>(vencimentoGarantia);
    }
    if (!nullToAbsent || numeroNotaFiscal != null) {
      map['numero_nota_fiscal'] = Variable<String>(numeroNotaFiscal);
    }
    if (!nullToAbsent || numeroSerie != null) {
      map['numero_serie'] = Variable<String>(numeroSerie);
    }
    if (!nullToAbsent || chaveNfe != null) {
      map['chave_nfe'] = Variable<String>(chaveNfe);
    }
    if (!nullToAbsent || valorOriginal != null) {
      map['valor_original'] = Variable<double>(valorOriginal);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorAtualizado != null) {
      map['valor_atualizado'] = Variable<double>(valorAtualizado);
    }
    if (!nullToAbsent || valorBaixa != null) {
      map['valor_baixa'] = Variable<double>(valorBaixa);
    }
    if (!nullToAbsent || deprecia != null) {
      map['deprecia'] = Variable<String>(deprecia);
    }
    if (!nullToAbsent || metodoDepreciacao != null) {
      map['metodo_depreciacao'] = Variable<String>(metodoDepreciacao);
    }
    if (!nullToAbsent || inicioDepreciacao != null) {
      map['inicio_depreciacao'] = Variable<DateTime>(inicioDepreciacao);
    }
    if (!nullToAbsent || ultimaDepreciacao != null) {
      map['ultima_depreciacao'] = Variable<DateTime>(ultimaDepreciacao);
    }
    if (!nullToAbsent || tipoDepreciacao != null) {
      map['tipo_depreciacao'] = Variable<String>(tipoDepreciacao);
    }
    if (!nullToAbsent || taxaAnualDepreciacao != null) {
      map['taxa_anual_depreciacao'] = Variable<double>(taxaAnualDepreciacao);
    }
    if (!nullToAbsent || taxaMensalDepreciacao != null) {
      map['taxa_mensal_depreciacao'] = Variable<double>(taxaMensalDepreciacao);
    }
    if (!nullToAbsent || taxaDepreciacaoAcelerada != null) {
      map['taxa_depreciacao_acelerada'] =
          Variable<double>(taxaDepreciacaoAcelerada);
    }
    if (!nullToAbsent || taxaDepreciacaoIncentivada != null) {
      map['taxa_depreciacao_incentivada'] =
          Variable<double>(taxaDepreciacaoIncentivada);
    }
    if (!nullToAbsent || funcao != null) {
      map['funcao'] = Variable<String>(funcao);
    }
    return map;
  }

  factory PatrimBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimBem(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idPatrimTipoAquisicaoBem:
          serializer.fromJson<int?>(json['idPatrimTipoAquisicaoBem']),
      idPatrimEstadoConservacao:
          serializer.fromJson<int?>(json['idPatrimEstadoConservacao']),
      idPatrimGrupoBem: serializer.fromJson<int?>(json['idPatrimGrupoBem']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      numeroNb: serializer.fromJson<String?>(json['numeroNb']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      dataAquisicao: serializer.fromJson<DateTime?>(json['dataAquisicao']),
      dataAceite: serializer.fromJson<DateTime?>(json['dataAceite']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataContabilizado:
          serializer.fromJson<DateTime?>(json['dataContabilizado']),
      dataVistoria: serializer.fromJson<DateTime?>(json['dataVistoria']),
      dataMarcacao: serializer.fromJson<DateTime?>(json['dataMarcacao']),
      dataBaixa: serializer.fromJson<DateTime?>(json['dataBaixa']),
      vencimentoGarantia:
          serializer.fromJson<DateTime?>(json['vencimentoGarantia']),
      numeroNotaFiscal: serializer.fromJson<String?>(json['numeroNotaFiscal']),
      numeroSerie: serializer.fromJson<String?>(json['numeroSerie']),
      chaveNfe: serializer.fromJson<String?>(json['chaveNfe']),
      valorOriginal: serializer.fromJson<double?>(json['valorOriginal']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorAtualizado: serializer.fromJson<double?>(json['valorAtualizado']),
      valorBaixa: serializer.fromJson<double?>(json['valorBaixa']),
      deprecia: serializer.fromJson<String?>(json['deprecia']),
      metodoDepreciacao:
          serializer.fromJson<String?>(json['metodoDepreciacao']),
      inicioDepreciacao:
          serializer.fromJson<DateTime?>(json['inicioDepreciacao']),
      ultimaDepreciacao:
          serializer.fromJson<DateTime?>(json['ultimaDepreciacao']),
      tipoDepreciacao: serializer.fromJson<String?>(json['tipoDepreciacao']),
      taxaAnualDepreciacao:
          serializer.fromJson<double?>(json['taxaAnualDepreciacao']),
      taxaMensalDepreciacao:
          serializer.fromJson<double?>(json['taxaMensalDepreciacao']),
      taxaDepreciacaoAcelerada:
          serializer.fromJson<double?>(json['taxaDepreciacaoAcelerada']),
      taxaDepreciacaoIncentivada:
          serializer.fromJson<double?>(json['taxaDepreciacaoIncentivada']),
      funcao: serializer.fromJson<String?>(json['funcao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idPatrimTipoAquisicaoBem':
          serializer.toJson<int?>(idPatrimTipoAquisicaoBem),
      'idPatrimEstadoConservacao':
          serializer.toJson<int?>(idPatrimEstadoConservacao),
      'idPatrimGrupoBem': serializer.toJson<int?>(idPatrimGrupoBem),
      'idSetor': serializer.toJson<int?>(idSetor),
      'numeroNb': serializer.toJson<String?>(numeroNb),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'dataAquisicao': serializer.toJson<DateTime?>(dataAquisicao),
      'dataAceite': serializer.toJson<DateTime?>(dataAceite),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataContabilizado': serializer.toJson<DateTime?>(dataContabilizado),
      'dataVistoria': serializer.toJson<DateTime?>(dataVistoria),
      'dataMarcacao': serializer.toJson<DateTime?>(dataMarcacao),
      'dataBaixa': serializer.toJson<DateTime?>(dataBaixa),
      'vencimentoGarantia': serializer.toJson<DateTime?>(vencimentoGarantia),
      'numeroNotaFiscal': serializer.toJson<String?>(numeroNotaFiscal),
      'numeroSerie': serializer.toJson<String?>(numeroSerie),
      'chaveNfe': serializer.toJson<String?>(chaveNfe),
      'valorOriginal': serializer.toJson<double?>(valorOriginal),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorAtualizado': serializer.toJson<double?>(valorAtualizado),
      'valorBaixa': serializer.toJson<double?>(valorBaixa),
      'deprecia': serializer.toJson<String?>(deprecia),
      'metodoDepreciacao': serializer.toJson<String?>(metodoDepreciacao),
      'inicioDepreciacao': serializer.toJson<DateTime?>(inicioDepreciacao),
      'ultimaDepreciacao': serializer.toJson<DateTime?>(ultimaDepreciacao),
      'tipoDepreciacao': serializer.toJson<String?>(tipoDepreciacao),
      'taxaAnualDepreciacao': serializer.toJson<double?>(taxaAnualDepreciacao),
      'taxaMensalDepreciacao':
          serializer.toJson<double?>(taxaMensalDepreciacao),
      'taxaDepreciacaoAcelerada':
          serializer.toJson<double?>(taxaDepreciacaoAcelerada),
      'taxaDepreciacaoIncentivada':
          serializer.toJson<double?>(taxaDepreciacaoIncentivada),
      'funcao': serializer.toJson<String?>(funcao),
    };
  }

  PatrimBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<int?> idFornecedor = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
          Value<int?> idPatrimEstadoConservacao = const Value.absent(),
          Value<int?> idPatrimGrupoBem = const Value.absent(),
          Value<int?> idSetor = const Value.absent(),
          Value<String?> numeroNb = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<DateTime?> dataAquisicao = const Value.absent(),
          Value<DateTime?> dataAceite = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataContabilizado = const Value.absent(),
          Value<DateTime?> dataVistoria = const Value.absent(),
          Value<DateTime?> dataMarcacao = const Value.absent(),
          Value<DateTime?> dataBaixa = const Value.absent(),
          Value<DateTime?> vencimentoGarantia = const Value.absent(),
          Value<String?> numeroNotaFiscal = const Value.absent(),
          Value<String?> numeroSerie = const Value.absent(),
          Value<String?> chaveNfe = const Value.absent(),
          Value<double?> valorOriginal = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorAtualizado = const Value.absent(),
          Value<double?> valorBaixa = const Value.absent(),
          Value<String?> deprecia = const Value.absent(),
          Value<String?> metodoDepreciacao = const Value.absent(),
          Value<DateTime?> inicioDepreciacao = const Value.absent(),
          Value<DateTime?> ultimaDepreciacao = const Value.absent(),
          Value<String?> tipoDepreciacao = const Value.absent(),
          Value<double?> taxaAnualDepreciacao = const Value.absent(),
          Value<double?> taxaMensalDepreciacao = const Value.absent(),
          Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
          Value<double?> taxaDepreciacaoIncentivada = const Value.absent(),
          Value<String?> funcao = const Value.absent()}) =>
      PatrimBem(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        idFornecedor:
            idFornecedor.present ? idFornecedor.value : this.idFornecedor,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem.present
            ? idPatrimTipoAquisicaoBem.value
            : this.idPatrimTipoAquisicaoBem,
        idPatrimEstadoConservacao: idPatrimEstadoConservacao.present
            ? idPatrimEstadoConservacao.value
            : this.idPatrimEstadoConservacao,
        idPatrimGrupoBem: idPatrimGrupoBem.present
            ? idPatrimGrupoBem.value
            : this.idPatrimGrupoBem,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
        numeroNb: numeroNb.present ? numeroNb.value : this.numeroNb,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        dataAquisicao:
            dataAquisicao.present ? dataAquisicao.value : this.dataAquisicao,
        dataAceite: dataAceite.present ? dataAceite.value : this.dataAceite,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataContabilizado: dataContabilizado.present
            ? dataContabilizado.value
            : this.dataContabilizado,
        dataVistoria:
            dataVistoria.present ? dataVistoria.value : this.dataVistoria,
        dataMarcacao:
            dataMarcacao.present ? dataMarcacao.value : this.dataMarcacao,
        dataBaixa: dataBaixa.present ? dataBaixa.value : this.dataBaixa,
        vencimentoGarantia: vencimentoGarantia.present
            ? vencimentoGarantia.value
            : this.vencimentoGarantia,
        numeroNotaFiscal: numeroNotaFiscal.present
            ? numeroNotaFiscal.value
            : this.numeroNotaFiscal,
        numeroSerie: numeroSerie.present ? numeroSerie.value : this.numeroSerie,
        chaveNfe: chaveNfe.present ? chaveNfe.value : this.chaveNfe,
        valorOriginal:
            valorOriginal.present ? valorOriginal.value : this.valorOriginal,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorAtualizado: valorAtualizado.present
            ? valorAtualizado.value
            : this.valorAtualizado,
        valorBaixa: valorBaixa.present ? valorBaixa.value : this.valorBaixa,
        deprecia: deprecia.present ? deprecia.value : this.deprecia,
        metodoDepreciacao: metodoDepreciacao.present
            ? metodoDepreciacao.value
            : this.metodoDepreciacao,
        inicioDepreciacao: inicioDepreciacao.present
            ? inicioDepreciacao.value
            : this.inicioDepreciacao,
        ultimaDepreciacao: ultimaDepreciacao.present
            ? ultimaDepreciacao.value
            : this.ultimaDepreciacao,
        tipoDepreciacao: tipoDepreciacao.present
            ? tipoDepreciacao.value
            : this.tipoDepreciacao,
        taxaAnualDepreciacao: taxaAnualDepreciacao.present
            ? taxaAnualDepreciacao.value
            : this.taxaAnualDepreciacao,
        taxaMensalDepreciacao: taxaMensalDepreciacao.present
            ? taxaMensalDepreciacao.value
            : this.taxaMensalDepreciacao,
        taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada.present
            ? taxaDepreciacaoAcelerada.value
            : this.taxaDepreciacaoAcelerada,
        taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada.present
            ? taxaDepreciacaoIncentivada.value
            : this.taxaDepreciacaoIncentivada,
        funcao: funcao.present ? funcao.value : this.funcao,
      );
  PatrimBem copyWithCompanion(PatrimBemsCompanion data) {
    return PatrimBem(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      idFornecedor: data.idFornecedor.present
          ? data.idFornecedor.value
          : this.idFornecedor,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idPatrimTipoAquisicaoBem: data.idPatrimTipoAquisicaoBem.present
          ? data.idPatrimTipoAquisicaoBem.value
          : this.idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao: data.idPatrimEstadoConservacao.present
          ? data.idPatrimEstadoConservacao.value
          : this.idPatrimEstadoConservacao,
      idPatrimGrupoBem: data.idPatrimGrupoBem.present
          ? data.idPatrimGrupoBem.value
          : this.idPatrimGrupoBem,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
      numeroNb: data.numeroNb.present ? data.numeroNb.value : this.numeroNb,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      dataAquisicao: data.dataAquisicao.present
          ? data.dataAquisicao.value
          : this.dataAquisicao,
      dataAceite:
          data.dataAceite.present ? data.dataAceite.value : this.dataAceite,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataContabilizado: data.dataContabilizado.present
          ? data.dataContabilizado.value
          : this.dataContabilizado,
      dataVistoria: data.dataVistoria.present
          ? data.dataVistoria.value
          : this.dataVistoria,
      dataMarcacao: data.dataMarcacao.present
          ? data.dataMarcacao.value
          : this.dataMarcacao,
      dataBaixa: data.dataBaixa.present ? data.dataBaixa.value : this.dataBaixa,
      vencimentoGarantia: data.vencimentoGarantia.present
          ? data.vencimentoGarantia.value
          : this.vencimentoGarantia,
      numeroNotaFiscal: data.numeroNotaFiscal.present
          ? data.numeroNotaFiscal.value
          : this.numeroNotaFiscal,
      numeroSerie:
          data.numeroSerie.present ? data.numeroSerie.value : this.numeroSerie,
      chaveNfe: data.chaveNfe.present ? data.chaveNfe.value : this.chaveNfe,
      valorOriginal: data.valorOriginal.present
          ? data.valorOriginal.value
          : this.valorOriginal,
      valorCompra:
          data.valorCompra.present ? data.valorCompra.value : this.valorCompra,
      valorAtualizado: data.valorAtualizado.present
          ? data.valorAtualizado.value
          : this.valorAtualizado,
      valorBaixa:
          data.valorBaixa.present ? data.valorBaixa.value : this.valorBaixa,
      deprecia: data.deprecia.present ? data.deprecia.value : this.deprecia,
      metodoDepreciacao: data.metodoDepreciacao.present
          ? data.metodoDepreciacao.value
          : this.metodoDepreciacao,
      inicioDepreciacao: data.inicioDepreciacao.present
          ? data.inicioDepreciacao.value
          : this.inicioDepreciacao,
      ultimaDepreciacao: data.ultimaDepreciacao.present
          ? data.ultimaDepreciacao.value
          : this.ultimaDepreciacao,
      tipoDepreciacao: data.tipoDepreciacao.present
          ? data.tipoDepreciacao.value
          : this.tipoDepreciacao,
      taxaAnualDepreciacao: data.taxaAnualDepreciacao.present
          ? data.taxaAnualDepreciacao.value
          : this.taxaAnualDepreciacao,
      taxaMensalDepreciacao: data.taxaMensalDepreciacao.present
          ? data.taxaMensalDepreciacao.value
          : this.taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada: data.taxaDepreciacaoAcelerada.present
          ? data.taxaDepreciacaoAcelerada.value
          : this.taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada: data.taxaDepreciacaoIncentivada.present
          ? data.taxaDepreciacaoIncentivada.value
          : this.taxaDepreciacaoIncentivada,
      funcao: data.funcao.present ? data.funcao.value : this.funcao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimBem(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPatrimTipoAquisicaoBem: $idPatrimTipoAquisicaoBem, ')
          ..write('idPatrimEstadoConservacao: $idPatrimEstadoConservacao, ')
          ..write('idPatrimGrupoBem: $idPatrimGrupoBem, ')
          ..write('idSetor: $idSetor, ')
          ..write('numeroNb: $numeroNb, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('dataAquisicao: $dataAquisicao, ')
          ..write('dataAceite: $dataAceite, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataContabilizado: $dataContabilizado, ')
          ..write('dataVistoria: $dataVistoria, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('dataBaixa: $dataBaixa, ')
          ..write('vencimentoGarantia: $vencimentoGarantia, ')
          ..write('numeroNotaFiscal: $numeroNotaFiscal, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorAtualizado: $valorAtualizado, ')
          ..write('valorBaixa: $valorBaixa, ')
          ..write('deprecia: $deprecia, ')
          ..write('metodoDepreciacao: $metodoDepreciacao, ')
          ..write('inicioDepreciacao: $inicioDepreciacao, ')
          ..write('ultimaDepreciacao: $ultimaDepreciacao, ')
          ..write('tipoDepreciacao: $tipoDepreciacao, ')
          ..write('taxaAnualDepreciacao: $taxaAnualDepreciacao, ')
          ..write('taxaMensalDepreciacao: $taxaMensalDepreciacao, ')
          ..write('taxaDepreciacaoAcelerada: $taxaDepreciacaoAcelerada, ')
          ..write('taxaDepreciacaoIncentivada: $taxaDepreciacaoIncentivada, ')
          ..write('funcao: $funcao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idCentroResultado,
        idFornecedor,
        idColaborador,
        idPatrimTipoAquisicaoBem,
        idPatrimEstadoConservacao,
        idPatrimGrupoBem,
        idSetor,
        numeroNb,
        nome,
        descricao,
        dataAquisicao,
        dataAceite,
        dataCadastro,
        dataContabilizado,
        dataVistoria,
        dataMarcacao,
        dataBaixa,
        vencimentoGarantia,
        numeroNotaFiscal,
        numeroSerie,
        chaveNfe,
        valorOriginal,
        valorCompra,
        valorAtualizado,
        valorBaixa,
        deprecia,
        metodoDepreciacao,
        inicioDepreciacao,
        ultimaDepreciacao,
        tipoDepreciacao,
        taxaAnualDepreciacao,
        taxaMensalDepreciacao,
        taxaDepreciacaoAcelerada,
        taxaDepreciacaoIncentivada,
        funcao
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimBem &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.idFornecedor == this.idFornecedor &&
          other.idColaborador == this.idColaborador &&
          other.idPatrimTipoAquisicaoBem == this.idPatrimTipoAquisicaoBem &&
          other.idPatrimEstadoConservacao == this.idPatrimEstadoConservacao &&
          other.idPatrimGrupoBem == this.idPatrimGrupoBem &&
          other.idSetor == this.idSetor &&
          other.numeroNb == this.numeroNb &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.dataAquisicao == this.dataAquisicao &&
          other.dataAceite == this.dataAceite &&
          other.dataCadastro == this.dataCadastro &&
          other.dataContabilizado == this.dataContabilizado &&
          other.dataVistoria == this.dataVistoria &&
          other.dataMarcacao == this.dataMarcacao &&
          other.dataBaixa == this.dataBaixa &&
          other.vencimentoGarantia == this.vencimentoGarantia &&
          other.numeroNotaFiscal == this.numeroNotaFiscal &&
          other.numeroSerie == this.numeroSerie &&
          other.chaveNfe == this.chaveNfe &&
          other.valorOriginal == this.valorOriginal &&
          other.valorCompra == this.valorCompra &&
          other.valorAtualizado == this.valorAtualizado &&
          other.valorBaixa == this.valorBaixa &&
          other.deprecia == this.deprecia &&
          other.metodoDepreciacao == this.metodoDepreciacao &&
          other.inicioDepreciacao == this.inicioDepreciacao &&
          other.ultimaDepreciacao == this.ultimaDepreciacao &&
          other.tipoDepreciacao == this.tipoDepreciacao &&
          other.taxaAnualDepreciacao == this.taxaAnualDepreciacao &&
          other.taxaMensalDepreciacao == this.taxaMensalDepreciacao &&
          other.taxaDepreciacaoAcelerada == this.taxaDepreciacaoAcelerada &&
          other.taxaDepreciacaoIncentivada == this.taxaDepreciacaoIncentivada &&
          other.funcao == this.funcao);
}

class PatrimBemsCompanion extends UpdateCompanion<PatrimBem> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<int?> idFornecedor;
  final Value<int?> idColaborador;
  final Value<int?> idPatrimTipoAquisicaoBem;
  final Value<int?> idPatrimEstadoConservacao;
  final Value<int?> idPatrimGrupoBem;
  final Value<int?> idSetor;
  final Value<String?> numeroNb;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<DateTime?> dataAquisicao;
  final Value<DateTime?> dataAceite;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataContabilizado;
  final Value<DateTime?> dataVistoria;
  final Value<DateTime?> dataMarcacao;
  final Value<DateTime?> dataBaixa;
  final Value<DateTime?> vencimentoGarantia;
  final Value<String?> numeroNotaFiscal;
  final Value<String?> numeroSerie;
  final Value<String?> chaveNfe;
  final Value<double?> valorOriginal;
  final Value<double?> valorCompra;
  final Value<double?> valorAtualizado;
  final Value<double?> valorBaixa;
  final Value<String?> deprecia;
  final Value<String?> metodoDepreciacao;
  final Value<DateTime?> inicioDepreciacao;
  final Value<DateTime?> ultimaDepreciacao;
  final Value<String?> tipoDepreciacao;
  final Value<double?> taxaAnualDepreciacao;
  final Value<double?> taxaMensalDepreciacao;
  final Value<double?> taxaDepreciacaoAcelerada;
  final Value<double?> taxaDepreciacaoIncentivada;
  final Value<String?> funcao;
  const PatrimBemsCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPatrimTipoAquisicaoBem = const Value.absent(),
    this.idPatrimEstadoConservacao = const Value.absent(),
    this.idPatrimGrupoBem = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.numeroNb = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataAquisicao = const Value.absent(),
    this.dataAceite = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataContabilizado = const Value.absent(),
    this.dataVistoria = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.dataBaixa = const Value.absent(),
    this.vencimentoGarantia = const Value.absent(),
    this.numeroNotaFiscal = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorAtualizado = const Value.absent(),
    this.valorBaixa = const Value.absent(),
    this.deprecia = const Value.absent(),
    this.metodoDepreciacao = const Value.absent(),
    this.inicioDepreciacao = const Value.absent(),
    this.ultimaDepreciacao = const Value.absent(),
    this.tipoDepreciacao = const Value.absent(),
    this.taxaAnualDepreciacao = const Value.absent(),
    this.taxaMensalDepreciacao = const Value.absent(),
    this.taxaDepreciacaoAcelerada = const Value.absent(),
    this.taxaDepreciacaoIncentivada = const Value.absent(),
    this.funcao = const Value.absent(),
  });
  PatrimBemsCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPatrimTipoAquisicaoBem = const Value.absent(),
    this.idPatrimEstadoConservacao = const Value.absent(),
    this.idPatrimGrupoBem = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.numeroNb = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataAquisicao = const Value.absent(),
    this.dataAceite = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataContabilizado = const Value.absent(),
    this.dataVistoria = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.dataBaixa = const Value.absent(),
    this.vencimentoGarantia = const Value.absent(),
    this.numeroNotaFiscal = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorAtualizado = const Value.absent(),
    this.valorBaixa = const Value.absent(),
    this.deprecia = const Value.absent(),
    this.metodoDepreciacao = const Value.absent(),
    this.inicioDepreciacao = const Value.absent(),
    this.ultimaDepreciacao = const Value.absent(),
    this.tipoDepreciacao = const Value.absent(),
    this.taxaAnualDepreciacao = const Value.absent(),
    this.taxaMensalDepreciacao = const Value.absent(),
    this.taxaDepreciacaoAcelerada = const Value.absent(),
    this.taxaDepreciacaoIncentivada = const Value.absent(),
    this.funcao = const Value.absent(),
  });
  static Insertable<PatrimBem> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<int>? idFornecedor,
    Expression<int>? idColaborador,
    Expression<int>? idPatrimTipoAquisicaoBem,
    Expression<int>? idPatrimEstadoConservacao,
    Expression<int>? idPatrimGrupoBem,
    Expression<int>? idSetor,
    Expression<String>? numeroNb,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<DateTime>? dataAquisicao,
    Expression<DateTime>? dataAceite,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataContabilizado,
    Expression<DateTime>? dataVistoria,
    Expression<DateTime>? dataMarcacao,
    Expression<DateTime>? dataBaixa,
    Expression<DateTime>? vencimentoGarantia,
    Expression<String>? numeroNotaFiscal,
    Expression<String>? numeroSerie,
    Expression<String>? chaveNfe,
    Expression<double>? valorOriginal,
    Expression<double>? valorCompra,
    Expression<double>? valorAtualizado,
    Expression<double>? valorBaixa,
    Expression<String>? deprecia,
    Expression<String>? metodoDepreciacao,
    Expression<DateTime>? inicioDepreciacao,
    Expression<DateTime>? ultimaDepreciacao,
    Expression<String>? tipoDepreciacao,
    Expression<double>? taxaAnualDepreciacao,
    Expression<double>? taxaMensalDepreciacao,
    Expression<double>? taxaDepreciacaoAcelerada,
    Expression<double>? taxaDepreciacaoIncentivada,
    Expression<String>? funcao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idPatrimTipoAquisicaoBem != null)
        'id_patrim_tipo_aquisicao_bem': idPatrimTipoAquisicaoBem,
      if (idPatrimEstadoConservacao != null)
        'id_patrim_estado_conservacao': idPatrimEstadoConservacao,
      if (idPatrimGrupoBem != null) 'id_patrim_grupo_bem': idPatrimGrupoBem,
      if (idSetor != null) 'id_setor': idSetor,
      if (numeroNb != null) 'numero_nb': numeroNb,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (dataAquisicao != null) 'data_aquisicao': dataAquisicao,
      if (dataAceite != null) 'data_aceite': dataAceite,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataContabilizado != null) 'data_contabilizado': dataContabilizado,
      if (dataVistoria != null) 'data_vistoria': dataVistoria,
      if (dataMarcacao != null) 'data_marcacao': dataMarcacao,
      if (dataBaixa != null) 'data_baixa': dataBaixa,
      if (vencimentoGarantia != null) 'vencimento_garantia': vencimentoGarantia,
      if (numeroNotaFiscal != null) 'numero_nota_fiscal': numeroNotaFiscal,
      if (numeroSerie != null) 'numero_serie': numeroSerie,
      if (chaveNfe != null) 'chave_nfe': chaveNfe,
      if (valorOriginal != null) 'valor_original': valorOriginal,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorAtualizado != null) 'valor_atualizado': valorAtualizado,
      if (valorBaixa != null) 'valor_baixa': valorBaixa,
      if (deprecia != null) 'deprecia': deprecia,
      if (metodoDepreciacao != null) 'metodo_depreciacao': metodoDepreciacao,
      if (inicioDepreciacao != null) 'inicio_depreciacao': inicioDepreciacao,
      if (ultimaDepreciacao != null) 'ultima_depreciacao': ultimaDepreciacao,
      if (tipoDepreciacao != null) 'tipo_depreciacao': tipoDepreciacao,
      if (taxaAnualDepreciacao != null)
        'taxa_anual_depreciacao': taxaAnualDepreciacao,
      if (taxaMensalDepreciacao != null)
        'taxa_mensal_depreciacao': taxaMensalDepreciacao,
      if (taxaDepreciacaoAcelerada != null)
        'taxa_depreciacao_acelerada': taxaDepreciacaoAcelerada,
      if (taxaDepreciacaoIncentivada != null)
        'taxa_depreciacao_incentivada': taxaDepreciacaoIncentivada,
      if (funcao != null) 'funcao': funcao,
    });
  }

  PatrimBemsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<int?>? idFornecedor,
      Value<int?>? idColaborador,
      Value<int?>? idPatrimTipoAquisicaoBem,
      Value<int?>? idPatrimEstadoConservacao,
      Value<int?>? idPatrimGrupoBem,
      Value<int?>? idSetor,
      Value<String?>? numeroNb,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<DateTime?>? dataAquisicao,
      Value<DateTime?>? dataAceite,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataContabilizado,
      Value<DateTime?>? dataVistoria,
      Value<DateTime?>? dataMarcacao,
      Value<DateTime?>? dataBaixa,
      Value<DateTime?>? vencimentoGarantia,
      Value<String?>? numeroNotaFiscal,
      Value<String?>? numeroSerie,
      Value<String?>? chaveNfe,
      Value<double?>? valorOriginal,
      Value<double?>? valorCompra,
      Value<double?>? valorAtualizado,
      Value<double?>? valorBaixa,
      Value<String?>? deprecia,
      Value<String?>? metodoDepreciacao,
      Value<DateTime?>? inicioDepreciacao,
      Value<DateTime?>? ultimaDepreciacao,
      Value<String?>? tipoDepreciacao,
      Value<double?>? taxaAnualDepreciacao,
      Value<double?>? taxaMensalDepreciacao,
      Value<double?>? taxaDepreciacaoAcelerada,
      Value<double?>? taxaDepreciacaoIncentivada,
      Value<String?>? funcao}) {
    return PatrimBemsCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      idColaborador: idColaborador ?? this.idColaborador,
      idPatrimTipoAquisicaoBem:
          idPatrimTipoAquisicaoBem ?? this.idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao:
          idPatrimEstadoConservacao ?? this.idPatrimEstadoConservacao,
      idPatrimGrupoBem: idPatrimGrupoBem ?? this.idPatrimGrupoBem,
      idSetor: idSetor ?? this.idSetor,
      numeroNb: numeroNb ?? this.numeroNb,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      dataAquisicao: dataAquisicao ?? this.dataAquisicao,
      dataAceite: dataAceite ?? this.dataAceite,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataContabilizado: dataContabilizado ?? this.dataContabilizado,
      dataVistoria: dataVistoria ?? this.dataVistoria,
      dataMarcacao: dataMarcacao ?? this.dataMarcacao,
      dataBaixa: dataBaixa ?? this.dataBaixa,
      vencimentoGarantia: vencimentoGarantia ?? this.vencimentoGarantia,
      numeroNotaFiscal: numeroNotaFiscal ?? this.numeroNotaFiscal,
      numeroSerie: numeroSerie ?? this.numeroSerie,
      chaveNfe: chaveNfe ?? this.chaveNfe,
      valorOriginal: valorOriginal ?? this.valorOriginal,
      valorCompra: valorCompra ?? this.valorCompra,
      valorAtualizado: valorAtualizado ?? this.valorAtualizado,
      valorBaixa: valorBaixa ?? this.valorBaixa,
      deprecia: deprecia ?? this.deprecia,
      metodoDepreciacao: metodoDepreciacao ?? this.metodoDepreciacao,
      inicioDepreciacao: inicioDepreciacao ?? this.inicioDepreciacao,
      ultimaDepreciacao: ultimaDepreciacao ?? this.ultimaDepreciacao,
      tipoDepreciacao: tipoDepreciacao ?? this.tipoDepreciacao,
      taxaAnualDepreciacao: taxaAnualDepreciacao ?? this.taxaAnualDepreciacao,
      taxaMensalDepreciacao:
          taxaMensalDepreciacao ?? this.taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada:
          taxaDepreciacaoAcelerada ?? this.taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada:
          taxaDepreciacaoIncentivada ?? this.taxaDepreciacaoIncentivada,
      funcao: funcao ?? this.funcao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idPatrimTipoAquisicaoBem.present) {
      map['id_patrim_tipo_aquisicao_bem'] =
          Variable<int>(idPatrimTipoAquisicaoBem.value);
    }
    if (idPatrimEstadoConservacao.present) {
      map['id_patrim_estado_conservacao'] =
          Variable<int>(idPatrimEstadoConservacao.value);
    }
    if (idPatrimGrupoBem.present) {
      map['id_patrim_grupo_bem'] = Variable<int>(idPatrimGrupoBem.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (numeroNb.present) {
      map['numero_nb'] = Variable<String>(numeroNb.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (dataAquisicao.present) {
      map['data_aquisicao'] = Variable<DateTime>(dataAquisicao.value);
    }
    if (dataAceite.present) {
      map['data_aceite'] = Variable<DateTime>(dataAceite.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataContabilizado.present) {
      map['data_contabilizado'] = Variable<DateTime>(dataContabilizado.value);
    }
    if (dataVistoria.present) {
      map['data_vistoria'] = Variable<DateTime>(dataVistoria.value);
    }
    if (dataMarcacao.present) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao.value);
    }
    if (dataBaixa.present) {
      map['data_baixa'] = Variable<DateTime>(dataBaixa.value);
    }
    if (vencimentoGarantia.present) {
      map['vencimento_garantia'] = Variable<DateTime>(vencimentoGarantia.value);
    }
    if (numeroNotaFiscal.present) {
      map['numero_nota_fiscal'] = Variable<String>(numeroNotaFiscal.value);
    }
    if (numeroSerie.present) {
      map['numero_serie'] = Variable<String>(numeroSerie.value);
    }
    if (chaveNfe.present) {
      map['chave_nfe'] = Variable<String>(chaveNfe.value);
    }
    if (valorOriginal.present) {
      map['valor_original'] = Variable<double>(valorOriginal.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorAtualizado.present) {
      map['valor_atualizado'] = Variable<double>(valorAtualizado.value);
    }
    if (valorBaixa.present) {
      map['valor_baixa'] = Variable<double>(valorBaixa.value);
    }
    if (deprecia.present) {
      map['deprecia'] = Variable<String>(deprecia.value);
    }
    if (metodoDepreciacao.present) {
      map['metodo_depreciacao'] = Variable<String>(metodoDepreciacao.value);
    }
    if (inicioDepreciacao.present) {
      map['inicio_depreciacao'] = Variable<DateTime>(inicioDepreciacao.value);
    }
    if (ultimaDepreciacao.present) {
      map['ultima_depreciacao'] = Variable<DateTime>(ultimaDepreciacao.value);
    }
    if (tipoDepreciacao.present) {
      map['tipo_depreciacao'] = Variable<String>(tipoDepreciacao.value);
    }
    if (taxaAnualDepreciacao.present) {
      map['taxa_anual_depreciacao'] =
          Variable<double>(taxaAnualDepreciacao.value);
    }
    if (taxaMensalDepreciacao.present) {
      map['taxa_mensal_depreciacao'] =
          Variable<double>(taxaMensalDepreciacao.value);
    }
    if (taxaDepreciacaoAcelerada.present) {
      map['taxa_depreciacao_acelerada'] =
          Variable<double>(taxaDepreciacaoAcelerada.value);
    }
    if (taxaDepreciacaoIncentivada.present) {
      map['taxa_depreciacao_incentivada'] =
          Variable<double>(taxaDepreciacaoIncentivada.value);
    }
    if (funcao.present) {
      map['funcao'] = Variable<String>(funcao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimBemsCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPatrimTipoAquisicaoBem: $idPatrimTipoAquisicaoBem, ')
          ..write('idPatrimEstadoConservacao: $idPatrimEstadoConservacao, ')
          ..write('idPatrimGrupoBem: $idPatrimGrupoBem, ')
          ..write('idSetor: $idSetor, ')
          ..write('numeroNb: $numeroNb, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('dataAquisicao: $dataAquisicao, ')
          ..write('dataAceite: $dataAceite, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataContabilizado: $dataContabilizado, ')
          ..write('dataVistoria: $dataVistoria, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('dataBaixa: $dataBaixa, ')
          ..write('vencimentoGarantia: $vencimentoGarantia, ')
          ..write('numeroNotaFiscal: $numeroNotaFiscal, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorAtualizado: $valorAtualizado, ')
          ..write('valorBaixa: $valorBaixa, ')
          ..write('deprecia: $deprecia, ')
          ..write('metodoDepreciacao: $metodoDepreciacao, ')
          ..write('inicioDepreciacao: $inicioDepreciacao, ')
          ..write('ultimaDepreciacao: $ultimaDepreciacao, ')
          ..write('tipoDepreciacao: $tipoDepreciacao, ')
          ..write('taxaAnualDepreciacao: $taxaAnualDepreciacao, ')
          ..write('taxaMensalDepreciacao: $taxaMensalDepreciacao, ')
          ..write('taxaDepreciacaoAcelerada: $taxaDepreciacaoAcelerada, ')
          ..write('taxaDepreciacaoIncentivada: $taxaDepreciacaoIncentivada, ')
          ..write('funcao: $funcao')
          ..write(')'))
        .toString();
  }
}

class $SetorsTable extends Setors with TableInfo<$SetorsTable, Setor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SetorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'setor';
  @override
  VerificationContext validateIntegrity(Insertable<Setor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Setor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Setor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $SetorsTable createAlias(String alias) {
    return $SetorsTable(attachedDatabase, alias);
  }
}

class Setor extends DataClass implements Insertable<Setor> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Setor({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Setor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Setor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Setor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Setor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  Setor copyWithCompanion(SetorsCompanion data) {
    return Setor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Setor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Setor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class SetorsCompanion extends UpdateCompanion<Setor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const SetorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  SetorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Setor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  SetorsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return SetorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SetorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $CentroResultadosTable extends CentroResultados
    with TableInfo<$CentroResultadosTable, CentroResultado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CentroResultadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPlanoCentroResultadoMeta =
      const VerificationMeta('idPlanoCentroResultado');
  @override
  late final GeneratedColumn<int> idPlanoCentroResultado = GeneratedColumn<int>(
      'id_plano_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _classificacaoMeta =
      const VerificationMeta('classificacao');
  @override
  late final GeneratedColumn<String> classificacao = GeneratedColumn<String>(
      'classificacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _sofreRateiroMeta =
      const VerificationMeta('sofreRateiro');
  @override
  late final GeneratedColumn<String> sofreRateiro = GeneratedColumn<String>(
      'sofre_rateiro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPlanoCentroResultado, classificacao, descricao, sofreRateiro];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'centro_resultado';
  @override
  VerificationContext validateIntegrity(Insertable<CentroResultado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_plano_centro_resultado')) {
      context.handle(
          _idPlanoCentroResultadoMeta,
          idPlanoCentroResultado.isAcceptableOrUnknown(
              data['id_plano_centro_resultado']!, _idPlanoCentroResultadoMeta));
    }
    if (data.containsKey('classificacao')) {
      context.handle(
          _classificacaoMeta,
          classificacao.isAcceptableOrUnknown(
              data['classificacao']!, _classificacaoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('sofre_rateiro')) {
      context.handle(
          _sofreRateiroMeta,
          sofreRateiro.isAcceptableOrUnknown(
              data['sofre_rateiro']!, _sofreRateiroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CentroResultado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CentroResultado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPlanoCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_plano_centro_resultado']),
      classificacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}classificacao']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      sofreRateiro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sofre_rateiro']),
    );
  }

  @override
  $CentroResultadosTable createAlias(String alias) {
    return $CentroResultadosTable(attachedDatabase, alias);
  }
}

class CentroResultado extends DataClass implements Insertable<CentroResultado> {
  final int? id;
  final int? idPlanoCentroResultado;
  final String? classificacao;
  final String? descricao;
  final String? sofreRateiro;
  const CentroResultado(
      {this.id,
      this.idPlanoCentroResultado,
      this.classificacao,
      this.descricao,
      this.sofreRateiro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPlanoCentroResultado != null) {
      map['id_plano_centro_resultado'] = Variable<int>(idPlanoCentroResultado);
    }
    if (!nullToAbsent || classificacao != null) {
      map['classificacao'] = Variable<String>(classificacao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || sofreRateiro != null) {
      map['sofre_rateiro'] = Variable<String>(sofreRateiro);
    }
    return map;
  }

  factory CentroResultado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CentroResultado(
      id: serializer.fromJson<int?>(json['id']),
      idPlanoCentroResultado:
          serializer.fromJson<int?>(json['idPlanoCentroResultado']),
      classificacao: serializer.fromJson<String?>(json['classificacao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      sofreRateiro: serializer.fromJson<String?>(json['sofreRateiro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPlanoCentroResultado': serializer.toJson<int?>(idPlanoCentroResultado),
      'classificacao': serializer.toJson<String?>(classificacao),
      'descricao': serializer.toJson<String?>(descricao),
      'sofreRateiro': serializer.toJson<String?>(sofreRateiro),
    };
  }

  CentroResultado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPlanoCentroResultado = const Value.absent(),
          Value<String?> classificacao = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> sofreRateiro = const Value.absent()}) =>
      CentroResultado(
        id: id.present ? id.value : this.id,
        idPlanoCentroResultado: idPlanoCentroResultado.present
            ? idPlanoCentroResultado.value
            : this.idPlanoCentroResultado,
        classificacao:
            classificacao.present ? classificacao.value : this.classificacao,
        descricao: descricao.present ? descricao.value : this.descricao,
        sofreRateiro:
            sofreRateiro.present ? sofreRateiro.value : this.sofreRateiro,
      );
  CentroResultado copyWithCompanion(CentroResultadosCompanion data) {
    return CentroResultado(
      id: data.id.present ? data.id.value : this.id,
      idPlanoCentroResultado: data.idPlanoCentroResultado.present
          ? data.idPlanoCentroResultado.value
          : this.idPlanoCentroResultado,
      classificacao: data.classificacao.present
          ? data.classificacao.value
          : this.classificacao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      sofreRateiro: data.sofreRateiro.present
          ? data.sofreRateiro.value
          : this.sofreRateiro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CentroResultado(')
          ..write('id: $id, ')
          ..write('idPlanoCentroResultado: $idPlanoCentroResultado, ')
          ..write('classificacao: $classificacao, ')
          ..write('descricao: $descricao, ')
          ..write('sofreRateiro: $sofreRateiro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPlanoCentroResultado, classificacao, descricao, sofreRateiro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CentroResultado &&
          other.id == this.id &&
          other.idPlanoCentroResultado == this.idPlanoCentroResultado &&
          other.classificacao == this.classificacao &&
          other.descricao == this.descricao &&
          other.sofreRateiro == this.sofreRateiro);
}

class CentroResultadosCompanion extends UpdateCompanion<CentroResultado> {
  final Value<int?> id;
  final Value<int?> idPlanoCentroResultado;
  final Value<String?> classificacao;
  final Value<String?> descricao;
  final Value<String?> sofreRateiro;
  const CentroResultadosCompanion({
    this.id = const Value.absent(),
    this.idPlanoCentroResultado = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.sofreRateiro = const Value.absent(),
  });
  CentroResultadosCompanion.insert({
    this.id = const Value.absent(),
    this.idPlanoCentroResultado = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.sofreRateiro = const Value.absent(),
  });
  static Insertable<CentroResultado> custom({
    Expression<int>? id,
    Expression<int>? idPlanoCentroResultado,
    Expression<String>? classificacao,
    Expression<String>? descricao,
    Expression<String>? sofreRateiro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPlanoCentroResultado != null)
        'id_plano_centro_resultado': idPlanoCentroResultado,
      if (classificacao != null) 'classificacao': classificacao,
      if (descricao != null) 'descricao': descricao,
      if (sofreRateiro != null) 'sofre_rateiro': sofreRateiro,
    });
  }

  CentroResultadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPlanoCentroResultado,
      Value<String?>? classificacao,
      Value<String?>? descricao,
      Value<String?>? sofreRateiro}) {
    return CentroResultadosCompanion(
      id: id ?? this.id,
      idPlanoCentroResultado:
          idPlanoCentroResultado ?? this.idPlanoCentroResultado,
      classificacao: classificacao ?? this.classificacao,
      descricao: descricao ?? this.descricao,
      sofreRateiro: sofreRateiro ?? this.sofreRateiro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPlanoCentroResultado.present) {
      map['id_plano_centro_resultado'] =
          Variable<int>(idPlanoCentroResultado.value);
    }
    if (classificacao.present) {
      map['classificacao'] = Variable<String>(classificacao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (sofreRateiro.present) {
      map['sofre_rateiro'] = Variable<String>(sofreRateiro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CentroResultadosCompanion(')
          ..write('id: $id, ')
          ..write('idPlanoCentroResultado: $idPlanoCentroResultado, ')
          ..write('classificacao: $classificacao, ')
          ..write('descricao: $descricao, ')
          ..write('sofreRateiro: $sofreRateiro')
          ..write(')'))
        .toString();
  }
}

class $PatrimIndiceAtualizacaosTable extends PatrimIndiceAtualizacaos
    with TableInfo<$PatrimIndiceAtualizacaosTable, PatrimIndiceAtualizacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimIndiceAtualizacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataIndiceMeta =
      const VerificationMeta('dataIndice');
  @override
  late final GeneratedColumn<DateTime> dataIndice = GeneratedColumn<DateTime>(
      'data_indice', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAlternativoMeta =
      const VerificationMeta('valorAlternativo');
  @override
  late final GeneratedColumn<double> valorAlternativo = GeneratedColumn<double>(
      'valor_alternativo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, dataIndice, nome, valor, valorAlternativo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_indice_atualizacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimIndiceAtualizacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_indice')) {
      context.handle(
          _dataIndiceMeta,
          dataIndice.isAcceptableOrUnknown(
              data['data_indice']!, _dataIndiceMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('valor_alternativo')) {
      context.handle(
          _valorAlternativoMeta,
          valorAlternativo.isAcceptableOrUnknown(
              data['valor_alternativo']!, _valorAlternativoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimIndiceAtualizacao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimIndiceAtualizacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataIndice: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_indice']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      valorAlternativo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_alternativo']),
    );
  }

  @override
  $PatrimIndiceAtualizacaosTable createAlias(String alias) {
    return $PatrimIndiceAtualizacaosTable(attachedDatabase, alias);
  }
}

class PatrimIndiceAtualizacao extends DataClass
    implements Insertable<PatrimIndiceAtualizacao> {
  final int? id;
  final DateTime? dataIndice;
  final String? nome;
  final double? valor;
  final double? valorAlternativo;
  const PatrimIndiceAtualizacao(
      {this.id, this.dataIndice, this.nome, this.valor, this.valorAlternativo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataIndice != null) {
      map['data_indice'] = Variable<DateTime>(dataIndice);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || valorAlternativo != null) {
      map['valor_alternativo'] = Variable<double>(valorAlternativo);
    }
    return map;
  }

  factory PatrimIndiceAtualizacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimIndiceAtualizacao(
      id: serializer.fromJson<int?>(json['id']),
      dataIndice: serializer.fromJson<DateTime?>(json['dataIndice']),
      nome: serializer.fromJson<String?>(json['nome']),
      valor: serializer.fromJson<double?>(json['valor']),
      valorAlternativo: serializer.fromJson<double?>(json['valorAlternativo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataIndice': serializer.toJson<DateTime?>(dataIndice),
      'nome': serializer.toJson<String?>(nome),
      'valor': serializer.toJson<double?>(valor),
      'valorAlternativo': serializer.toJson<double?>(valorAlternativo),
    };
  }

  PatrimIndiceAtualizacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataIndice = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<double?> valorAlternativo = const Value.absent()}) =>
      PatrimIndiceAtualizacao(
        id: id.present ? id.value : this.id,
        dataIndice: dataIndice.present ? dataIndice.value : this.dataIndice,
        nome: nome.present ? nome.value : this.nome,
        valor: valor.present ? valor.value : this.valor,
        valorAlternativo: valorAlternativo.present
            ? valorAlternativo.value
            : this.valorAlternativo,
      );
  PatrimIndiceAtualizacao copyWithCompanion(
      PatrimIndiceAtualizacaosCompanion data) {
    return PatrimIndiceAtualizacao(
      id: data.id.present ? data.id.value : this.id,
      dataIndice:
          data.dataIndice.present ? data.dataIndice.value : this.dataIndice,
      nome: data.nome.present ? data.nome.value : this.nome,
      valor: data.valor.present ? data.valor.value : this.valor,
      valorAlternativo: data.valorAlternativo.present
          ? data.valorAlternativo.value
          : this.valorAlternativo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimIndiceAtualizacao(')
          ..write('id: $id, ')
          ..write('dataIndice: $dataIndice, ')
          ..write('nome: $nome, ')
          ..write('valor: $valor, ')
          ..write('valorAlternativo: $valorAlternativo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, dataIndice, nome, valor, valorAlternativo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimIndiceAtualizacao &&
          other.id == this.id &&
          other.dataIndice == this.dataIndice &&
          other.nome == this.nome &&
          other.valor == this.valor &&
          other.valorAlternativo == this.valorAlternativo);
}

class PatrimIndiceAtualizacaosCompanion
    extends UpdateCompanion<PatrimIndiceAtualizacao> {
  final Value<int?> id;
  final Value<DateTime?> dataIndice;
  final Value<String?> nome;
  final Value<double?> valor;
  final Value<double?> valorAlternativo;
  const PatrimIndiceAtualizacaosCompanion({
    this.id = const Value.absent(),
    this.dataIndice = const Value.absent(),
    this.nome = const Value.absent(),
    this.valor = const Value.absent(),
    this.valorAlternativo = const Value.absent(),
  });
  PatrimIndiceAtualizacaosCompanion.insert({
    this.id = const Value.absent(),
    this.dataIndice = const Value.absent(),
    this.nome = const Value.absent(),
    this.valor = const Value.absent(),
    this.valorAlternativo = const Value.absent(),
  });
  static Insertable<PatrimIndiceAtualizacao> custom({
    Expression<int>? id,
    Expression<DateTime>? dataIndice,
    Expression<String>? nome,
    Expression<double>? valor,
    Expression<double>? valorAlternativo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataIndice != null) 'data_indice': dataIndice,
      if (nome != null) 'nome': nome,
      if (valor != null) 'valor': valor,
      if (valorAlternativo != null) 'valor_alternativo': valorAlternativo,
    });
  }

  PatrimIndiceAtualizacaosCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataIndice,
      Value<String?>? nome,
      Value<double?>? valor,
      Value<double?>? valorAlternativo}) {
    return PatrimIndiceAtualizacaosCompanion(
      id: id ?? this.id,
      dataIndice: dataIndice ?? this.dataIndice,
      nome: nome ?? this.nome,
      valor: valor ?? this.valor,
      valorAlternativo: valorAlternativo ?? this.valorAlternativo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataIndice.present) {
      map['data_indice'] = Variable<DateTime>(dataIndice.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (valorAlternativo.present) {
      map['valor_alternativo'] = Variable<double>(valorAlternativo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimIndiceAtualizacaosCompanion(')
          ..write('id: $id, ')
          ..write('dataIndice: $dataIndice, ')
          ..write('nome: $nome, ')
          ..write('valor: $valor, ')
          ..write('valorAlternativo: $valorAlternativo')
          ..write(')'))
        .toString();
  }
}

class $PatrimTaxaDepreciacaosTable extends PatrimTaxaDepreciacaos
    with TableInfo<$PatrimTaxaDepreciacaosTable, PatrimTaxaDepreciacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimTaxaDepreciacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ncmMeta = const VerificationMeta('ncm');
  @override
  late final GeneratedColumn<String> ncm = GeneratedColumn<String>(
      'ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bemMeta = const VerificationMeta('bem');
  @override
  late final GeneratedColumn<String> bem = GeneratedColumn<String>(
      'bem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _vidaMeta = const VerificationMeta('vida');
  @override
  late final GeneratedColumn<double> vida = GeneratedColumn<double>(
      'vida', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaMeta = const VerificationMeta('taxa');
  @override
  late final GeneratedColumn<double> taxa = GeneratedColumn<double>(
      'taxa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, ncm, bem, vida, taxa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_taxa_depreciacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimTaxaDepreciacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('ncm')) {
      context.handle(
          _ncmMeta, ncm.isAcceptableOrUnknown(data['ncm']!, _ncmMeta));
    }
    if (data.containsKey('bem')) {
      context.handle(
          _bemMeta, bem.isAcceptableOrUnknown(data['bem']!, _bemMeta));
    }
    if (data.containsKey('vida')) {
      context.handle(
          _vidaMeta, vida.isAcceptableOrUnknown(data['vida']!, _vidaMeta));
    }
    if (data.containsKey('taxa')) {
      context.handle(
          _taxaMeta, taxa.isAcceptableOrUnknown(data['taxa']!, _taxaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimTaxaDepreciacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimTaxaDepreciacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      ncm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ncm']),
      bem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bem']),
      vida: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}vida']),
      taxa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa']),
    );
  }

  @override
  $PatrimTaxaDepreciacaosTable createAlias(String alias) {
    return $PatrimTaxaDepreciacaosTable(attachedDatabase, alias);
  }
}

class PatrimTaxaDepreciacao extends DataClass
    implements Insertable<PatrimTaxaDepreciacao> {
  final int? id;
  final String? ncm;
  final String? bem;
  final double? vida;
  final double? taxa;
  const PatrimTaxaDepreciacao(
      {this.id, this.ncm, this.bem, this.vida, this.taxa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || ncm != null) {
      map['ncm'] = Variable<String>(ncm);
    }
    if (!nullToAbsent || bem != null) {
      map['bem'] = Variable<String>(bem);
    }
    if (!nullToAbsent || vida != null) {
      map['vida'] = Variable<double>(vida);
    }
    if (!nullToAbsent || taxa != null) {
      map['taxa'] = Variable<double>(taxa);
    }
    return map;
  }

  factory PatrimTaxaDepreciacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimTaxaDepreciacao(
      id: serializer.fromJson<int?>(json['id']),
      ncm: serializer.fromJson<String?>(json['ncm']),
      bem: serializer.fromJson<String?>(json['bem']),
      vida: serializer.fromJson<double?>(json['vida']),
      taxa: serializer.fromJson<double?>(json['taxa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'ncm': serializer.toJson<String?>(ncm),
      'bem': serializer.toJson<String?>(bem),
      'vida': serializer.toJson<double?>(vida),
      'taxa': serializer.toJson<double?>(taxa),
    };
  }

  PatrimTaxaDepreciacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> ncm = const Value.absent(),
          Value<String?> bem = const Value.absent(),
          Value<double?> vida = const Value.absent(),
          Value<double?> taxa = const Value.absent()}) =>
      PatrimTaxaDepreciacao(
        id: id.present ? id.value : this.id,
        ncm: ncm.present ? ncm.value : this.ncm,
        bem: bem.present ? bem.value : this.bem,
        vida: vida.present ? vida.value : this.vida,
        taxa: taxa.present ? taxa.value : this.taxa,
      );
  PatrimTaxaDepreciacao copyWithCompanion(
      PatrimTaxaDepreciacaosCompanion data) {
    return PatrimTaxaDepreciacao(
      id: data.id.present ? data.id.value : this.id,
      ncm: data.ncm.present ? data.ncm.value : this.ncm,
      bem: data.bem.present ? data.bem.value : this.bem,
      vida: data.vida.present ? data.vida.value : this.vida,
      taxa: data.taxa.present ? data.taxa.value : this.taxa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTaxaDepreciacao(')
          ..write('id: $id, ')
          ..write('ncm: $ncm, ')
          ..write('bem: $bem, ')
          ..write('vida: $vida, ')
          ..write('taxa: $taxa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, ncm, bem, vida, taxa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimTaxaDepreciacao &&
          other.id == this.id &&
          other.ncm == this.ncm &&
          other.bem == this.bem &&
          other.vida == this.vida &&
          other.taxa == this.taxa);
}

class PatrimTaxaDepreciacaosCompanion
    extends UpdateCompanion<PatrimTaxaDepreciacao> {
  final Value<int?> id;
  final Value<String?> ncm;
  final Value<String?> bem;
  final Value<double?> vida;
  final Value<double?> taxa;
  const PatrimTaxaDepreciacaosCompanion({
    this.id = const Value.absent(),
    this.ncm = const Value.absent(),
    this.bem = const Value.absent(),
    this.vida = const Value.absent(),
    this.taxa = const Value.absent(),
  });
  PatrimTaxaDepreciacaosCompanion.insert({
    this.id = const Value.absent(),
    this.ncm = const Value.absent(),
    this.bem = const Value.absent(),
    this.vida = const Value.absent(),
    this.taxa = const Value.absent(),
  });
  static Insertable<PatrimTaxaDepreciacao> custom({
    Expression<int>? id,
    Expression<String>? ncm,
    Expression<String>? bem,
    Expression<double>? vida,
    Expression<double>? taxa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (ncm != null) 'ncm': ncm,
      if (bem != null) 'bem': bem,
      if (vida != null) 'vida': vida,
      if (taxa != null) 'taxa': taxa,
    });
  }

  PatrimTaxaDepreciacaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? ncm,
      Value<String?>? bem,
      Value<double?>? vida,
      Value<double?>? taxa}) {
    return PatrimTaxaDepreciacaosCompanion(
      id: id ?? this.id,
      ncm: ncm ?? this.ncm,
      bem: bem ?? this.bem,
      vida: vida ?? this.vida,
      taxa: taxa ?? this.taxa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (ncm.present) {
      map['ncm'] = Variable<String>(ncm.value);
    }
    if (bem.present) {
      map['bem'] = Variable<String>(bem.value);
    }
    if (vida.present) {
      map['vida'] = Variable<double>(vida.value);
    }
    if (taxa.present) {
      map['taxa'] = Variable<double>(taxa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTaxaDepreciacaosCompanion(')
          ..write('id: $id, ')
          ..write('ncm: $ncm, ')
          ..write('bem: $bem, ')
          ..write('vida: $vida, ')
          ..write('taxa: $taxa')
          ..write(')'))
        .toString();
  }
}

class $PatrimGrupoBemsTable extends PatrimGrupoBems
    with TableInfo<$PatrimGrupoBemsTable, PatrimGrupoBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimGrupoBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contaAtivoImobilizadoMeta =
      const VerificationMeta('contaAtivoImobilizado');
  @override
  late final GeneratedColumn<String> contaAtivoImobilizado =
      GeneratedColumn<String>('conta_ativo_imobilizado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaDepreciacaoAcumuladaMeta =
      const VerificationMeta('contaDepreciacaoAcumulada');
  @override
  late final GeneratedColumn<String> contaDepreciacaoAcumulada =
      GeneratedColumn<String>('conta_depreciacao_acumulada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaDespesaDepreciacaoMeta =
      const VerificationMeta('contaDespesaDepreciacao');
  @override
  late final GeneratedColumn<String> contaDespesaDepreciacao =
      GeneratedColumn<String>('conta_despesa_depreciacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHistoricoMeta =
      const VerificationMeta('codigoHistorico');
  @override
  late final GeneratedColumn<int> codigoHistorico = GeneratedColumn<int>(
      'codigo_historico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        codigo,
        nome,
        descricao,
        contaAtivoImobilizado,
        contaDepreciacaoAcumulada,
        contaDespesaDepreciacao,
        codigoHistorico
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_grupo_bem';
  @override
  VerificationContext validateIntegrity(Insertable<PatrimGrupoBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('conta_ativo_imobilizado')) {
      context.handle(
          _contaAtivoImobilizadoMeta,
          contaAtivoImobilizado.isAcceptableOrUnknown(
              data['conta_ativo_imobilizado']!, _contaAtivoImobilizadoMeta));
    }
    if (data.containsKey('conta_depreciacao_acumulada')) {
      context.handle(
          _contaDepreciacaoAcumuladaMeta,
          contaDepreciacaoAcumulada.isAcceptableOrUnknown(
              data['conta_depreciacao_acumulada']!,
              _contaDepreciacaoAcumuladaMeta));
    }
    if (data.containsKey('conta_despesa_depreciacao')) {
      context.handle(
          _contaDespesaDepreciacaoMeta,
          contaDespesaDepreciacao.isAcceptableOrUnknown(
              data['conta_despesa_depreciacao']!,
              _contaDespesaDepreciacaoMeta));
    }
    if (data.containsKey('codigo_historico')) {
      context.handle(
          _codigoHistoricoMeta,
          codigoHistorico.isAcceptableOrUnknown(
              data['codigo_historico']!, _codigoHistoricoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimGrupoBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimGrupoBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      contaAtivoImobilizado: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_ativo_imobilizado']),
      contaDepreciacaoAcumulada: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_depreciacao_acumulada']),
      contaDespesaDepreciacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_despesa_depreciacao']),
      codigoHistorico: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_historico']),
    );
  }

  @override
  $PatrimGrupoBemsTable createAlias(String alias) {
    return $PatrimGrupoBemsTable(attachedDatabase, alias);
  }
}

class PatrimGrupoBem extends DataClass implements Insertable<PatrimGrupoBem> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  final String? contaAtivoImobilizado;
  final String? contaDepreciacaoAcumulada;
  final String? contaDespesaDepreciacao;
  final int? codigoHistorico;
  const PatrimGrupoBem(
      {this.id,
      this.codigo,
      this.nome,
      this.descricao,
      this.contaAtivoImobilizado,
      this.contaDepreciacaoAcumulada,
      this.contaDespesaDepreciacao,
      this.codigoHistorico});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || contaAtivoImobilizado != null) {
      map['conta_ativo_imobilizado'] = Variable<String>(contaAtivoImobilizado);
    }
    if (!nullToAbsent || contaDepreciacaoAcumulada != null) {
      map['conta_depreciacao_acumulada'] =
          Variable<String>(contaDepreciacaoAcumulada);
    }
    if (!nullToAbsent || contaDespesaDepreciacao != null) {
      map['conta_despesa_depreciacao'] =
          Variable<String>(contaDespesaDepreciacao);
    }
    if (!nullToAbsent || codigoHistorico != null) {
      map['codigo_historico'] = Variable<int>(codigoHistorico);
    }
    return map;
  }

  factory PatrimGrupoBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimGrupoBem(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      contaAtivoImobilizado:
          serializer.fromJson<String?>(json['contaAtivoImobilizado']),
      contaDepreciacaoAcumulada:
          serializer.fromJson<String?>(json['contaDepreciacaoAcumulada']),
      contaDespesaDepreciacao:
          serializer.fromJson<String?>(json['contaDespesaDepreciacao']),
      codigoHistorico: serializer.fromJson<int?>(json['codigoHistorico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'contaAtivoImobilizado':
          serializer.toJson<String?>(contaAtivoImobilizado),
      'contaDepreciacaoAcumulada':
          serializer.toJson<String?>(contaDepreciacaoAcumulada),
      'contaDespesaDepreciacao':
          serializer.toJson<String?>(contaDespesaDepreciacao),
      'codigoHistorico': serializer.toJson<int?>(codigoHistorico),
    };
  }

  PatrimGrupoBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> contaAtivoImobilizado = const Value.absent(),
          Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
          Value<String?> contaDespesaDepreciacao = const Value.absent(),
          Value<int?> codigoHistorico = const Value.absent()}) =>
      PatrimGrupoBem(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        contaAtivoImobilizado: contaAtivoImobilizado.present
            ? contaAtivoImobilizado.value
            : this.contaAtivoImobilizado,
        contaDepreciacaoAcumulada: contaDepreciacaoAcumulada.present
            ? contaDepreciacaoAcumulada.value
            : this.contaDepreciacaoAcumulada,
        contaDespesaDepreciacao: contaDespesaDepreciacao.present
            ? contaDespesaDepreciacao.value
            : this.contaDespesaDepreciacao,
        codigoHistorico: codigoHistorico.present
            ? codigoHistorico.value
            : this.codigoHistorico,
      );
  PatrimGrupoBem copyWithCompanion(PatrimGrupoBemsCompanion data) {
    return PatrimGrupoBem(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      contaAtivoImobilizado: data.contaAtivoImobilizado.present
          ? data.contaAtivoImobilizado.value
          : this.contaAtivoImobilizado,
      contaDepreciacaoAcumulada: data.contaDepreciacaoAcumulada.present
          ? data.contaDepreciacaoAcumulada.value
          : this.contaDepreciacaoAcumulada,
      contaDespesaDepreciacao: data.contaDespesaDepreciacao.present
          ? data.contaDespesaDepreciacao.value
          : this.contaDespesaDepreciacao,
      codigoHistorico: data.codigoHistorico.present
          ? data.codigoHistorico.value
          : this.codigoHistorico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimGrupoBem(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('contaAtivoImobilizado: $contaAtivoImobilizado, ')
          ..write('contaDepreciacaoAcumulada: $contaDepreciacaoAcumulada, ')
          ..write('contaDespesaDepreciacao: $contaDespesaDepreciacao, ')
          ..write('codigoHistorico: $codigoHistorico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      codigo,
      nome,
      descricao,
      contaAtivoImobilizado,
      contaDepreciacaoAcumulada,
      contaDespesaDepreciacao,
      codigoHistorico);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimGrupoBem &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.contaAtivoImobilizado == this.contaAtivoImobilizado &&
          other.contaDepreciacaoAcumulada == this.contaDepreciacaoAcumulada &&
          other.contaDespesaDepreciacao == this.contaDespesaDepreciacao &&
          other.codigoHistorico == this.codigoHistorico);
}

class PatrimGrupoBemsCompanion extends UpdateCompanion<PatrimGrupoBem> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> contaAtivoImobilizado;
  final Value<String?> contaDepreciacaoAcumulada;
  final Value<String?> contaDespesaDepreciacao;
  final Value<int?> codigoHistorico;
  const PatrimGrupoBemsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.contaAtivoImobilizado = const Value.absent(),
    this.contaDepreciacaoAcumulada = const Value.absent(),
    this.contaDespesaDepreciacao = const Value.absent(),
    this.codigoHistorico = const Value.absent(),
  });
  PatrimGrupoBemsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.contaAtivoImobilizado = const Value.absent(),
    this.contaDepreciacaoAcumulada = const Value.absent(),
    this.contaDespesaDepreciacao = const Value.absent(),
    this.codigoHistorico = const Value.absent(),
  });
  static Insertable<PatrimGrupoBem> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? contaAtivoImobilizado,
    Expression<String>? contaDepreciacaoAcumulada,
    Expression<String>? contaDespesaDepreciacao,
    Expression<int>? codigoHistorico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (contaAtivoImobilizado != null)
        'conta_ativo_imobilizado': contaAtivoImobilizado,
      if (contaDepreciacaoAcumulada != null)
        'conta_depreciacao_acumulada': contaDepreciacaoAcumulada,
      if (contaDespesaDepreciacao != null)
        'conta_despesa_depreciacao': contaDespesaDepreciacao,
      if (codigoHistorico != null) 'codigo_historico': codigoHistorico,
    });
  }

  PatrimGrupoBemsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? contaAtivoImobilizado,
      Value<String?>? contaDepreciacaoAcumulada,
      Value<String?>? contaDespesaDepreciacao,
      Value<int?>? codigoHistorico}) {
    return PatrimGrupoBemsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      contaAtivoImobilizado:
          contaAtivoImobilizado ?? this.contaAtivoImobilizado,
      contaDepreciacaoAcumulada:
          contaDepreciacaoAcumulada ?? this.contaDepreciacaoAcumulada,
      contaDespesaDepreciacao:
          contaDespesaDepreciacao ?? this.contaDespesaDepreciacao,
      codigoHistorico: codigoHistorico ?? this.codigoHistorico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (contaAtivoImobilizado.present) {
      map['conta_ativo_imobilizado'] =
          Variable<String>(contaAtivoImobilizado.value);
    }
    if (contaDepreciacaoAcumulada.present) {
      map['conta_depreciacao_acumulada'] =
          Variable<String>(contaDepreciacaoAcumulada.value);
    }
    if (contaDespesaDepreciacao.present) {
      map['conta_despesa_depreciacao'] =
          Variable<String>(contaDespesaDepreciacao.value);
    }
    if (codigoHistorico.present) {
      map['codigo_historico'] = Variable<int>(codigoHistorico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimGrupoBemsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('contaAtivoImobilizado: $contaAtivoImobilizado, ')
          ..write('contaDepreciacaoAcumulada: $contaDepreciacaoAcumulada, ')
          ..write('contaDespesaDepreciacao: $contaDespesaDepreciacao, ')
          ..write('codigoHistorico: $codigoHistorico')
          ..write(')'))
        .toString();
  }
}

class $PatrimTipoAquisicaoBemsTable extends PatrimTipoAquisicaoBems
    with TableInfo<$PatrimTipoAquisicaoBemsTable, PatrimTipoAquisicaoBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimTipoAquisicaoBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, tipo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_tipo_aquisicao_bem';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimTipoAquisicaoBem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimTipoAquisicaoBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimTipoAquisicaoBem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $PatrimTipoAquisicaoBemsTable createAlias(String alias) {
    return $PatrimTipoAquisicaoBemsTable(attachedDatabase, alias);
  }
}

class PatrimTipoAquisicaoBem extends DataClass
    implements Insertable<PatrimTipoAquisicaoBem> {
  final int? id;
  final String? tipo;
  final String? nome;
  final String? descricao;
  const PatrimTipoAquisicaoBem({this.id, this.tipo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory PatrimTipoAquisicaoBem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimTipoAquisicaoBem(
      id: serializer.fromJson<int?>(json['id']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'tipo': serializer.toJson<String?>(tipo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  PatrimTipoAquisicaoBem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      PatrimTipoAquisicaoBem(
        id: id.present ? id.value : this.id,
        tipo: tipo.present ? tipo.value : this.tipo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  PatrimTipoAquisicaoBem copyWithCompanion(
      PatrimTipoAquisicaoBemsCompanion data) {
    return PatrimTipoAquisicaoBem(
      id: data.id.present ? data.id.value : this.id,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTipoAquisicaoBem(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tipo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimTipoAquisicaoBem &&
          other.id == this.id &&
          other.tipo == this.tipo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class PatrimTipoAquisicaoBemsCompanion
    extends UpdateCompanion<PatrimTipoAquisicaoBem> {
  final Value<int?> id;
  final Value<String?> tipo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const PatrimTipoAquisicaoBemsCompanion({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  PatrimTipoAquisicaoBemsCompanion.insert({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<PatrimTipoAquisicaoBem> custom({
    Expression<int>? id,
    Expression<String>? tipo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tipo != null) 'tipo': tipo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  PatrimTipoAquisicaoBemsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? tipo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return PatrimTipoAquisicaoBemsCompanion(
      id: id ?? this.id,
      tipo: tipo ?? this.tipo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTipoAquisicaoBemsCompanion(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $PatrimEstadoConservacaosTable extends PatrimEstadoConservacaos
    with TableInfo<$PatrimEstadoConservacaosTable, PatrimEstadoConservacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimEstadoConservacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_estado_conservacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimEstadoConservacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimEstadoConservacao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimEstadoConservacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $PatrimEstadoConservacaosTable createAlias(String alias) {
    return $PatrimEstadoConservacaosTable(attachedDatabase, alias);
  }
}

class PatrimEstadoConservacao extends DataClass
    implements Insertable<PatrimEstadoConservacao> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const PatrimEstadoConservacao(
      {this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory PatrimEstadoConservacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimEstadoConservacao(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  PatrimEstadoConservacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      PatrimEstadoConservacao(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  PatrimEstadoConservacao copyWithCompanion(
      PatrimEstadoConservacaosCompanion data) {
    return PatrimEstadoConservacao(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimEstadoConservacao(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimEstadoConservacao &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class PatrimEstadoConservacaosCompanion
    extends UpdateCompanion<PatrimEstadoConservacao> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const PatrimEstadoConservacaosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  PatrimEstadoConservacaosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<PatrimEstadoConservacao> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  PatrimEstadoConservacaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return PatrimEstadoConservacaosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimEstadoConservacaosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $SeguradorasTable extends Seguradoras
    with TableInfo<$SeguradorasTable, Seguradora> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SeguradorasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, contato, telefone];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'seguradora';
  @override
  VerificationContext validateIntegrity(Insertable<Seguradora> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Seguradora map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Seguradora(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
    );
  }

  @override
  $SeguradorasTable createAlias(String alias) {
    return $SeguradorasTable(attachedDatabase, alias);
  }
}

class Seguradora extends DataClass implements Insertable<Seguradora> {
  final int? id;
  final String? nome;
  final String? contato;
  final String? telefone;
  const Seguradora({this.id, this.nome, this.contato, this.telefone});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    return map;
  }

  factory Seguradora.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Seguradora(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      contato: serializer.fromJson<String?>(json['contato']),
      telefone: serializer.fromJson<String?>(json['telefone']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'contato': serializer.toJson<String?>(contato),
      'telefone': serializer.toJson<String?>(telefone),
    };
  }

  Seguradora copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<String?> telefone = const Value.absent()}) =>
      Seguradora(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        contato: contato.present ? contato.value : this.contato,
        telefone: telefone.present ? telefone.value : this.telefone,
      );
  Seguradora copyWithCompanion(SeguradorasCompanion data) {
    return Seguradora(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      contato: data.contato.present ? data.contato.value : this.contato,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Seguradora(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('contato: $contato, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, contato, telefone);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Seguradora &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.contato == this.contato &&
          other.telefone == this.telefone);
}

class SeguradorasCompanion extends UpdateCompanion<Seguradora> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> contato;
  final Value<String?> telefone;
  const SeguradorasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.contato = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  SeguradorasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.contato = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  static Insertable<Seguradora> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? contato,
    Expression<String>? telefone,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (contato != null) 'contato': contato,
      if (telefone != null) 'telefone': telefone,
    });
  }

  SeguradorasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? contato,
      Value<String?>? telefone}) {
    return SeguradorasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      contato: contato ?? this.contato,
      telefone: telefone ?? this.telefone,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SeguradorasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('contato: $contato, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }
}

class $PatrimTipoMovimentacaosTable extends PatrimTipoMovimentacaos
    with TableInfo<$PatrimTipoMovimentacaosTable, PatrimTipoMovimentacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimTipoMovimentacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, tipo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_tipo_movimentacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PatrimTipoMovimentacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimTipoMovimentacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimTipoMovimentacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $PatrimTipoMovimentacaosTable createAlias(String alias) {
    return $PatrimTipoMovimentacaosTable(attachedDatabase, alias);
  }
}

class PatrimTipoMovimentacao extends DataClass
    implements Insertable<PatrimTipoMovimentacao> {
  final int? id;
  final String? tipo;
  final String? nome;
  final String? descricao;
  const PatrimTipoMovimentacao({this.id, this.tipo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory PatrimTipoMovimentacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimTipoMovimentacao(
      id: serializer.fromJson<int?>(json['id']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'tipo': serializer.toJson<String?>(tipo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  PatrimTipoMovimentacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      PatrimTipoMovimentacao(
        id: id.present ? id.value : this.id,
        tipo: tipo.present ? tipo.value : this.tipo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  PatrimTipoMovimentacao copyWithCompanion(
      PatrimTipoMovimentacaosCompanion data) {
    return PatrimTipoMovimentacao(
      id: data.id.present ? data.id.value : this.id,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTipoMovimentacao(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, tipo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimTipoMovimentacao &&
          other.id == this.id &&
          other.tipo == this.tipo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class PatrimTipoMovimentacaosCompanion
    extends UpdateCompanion<PatrimTipoMovimentacao> {
  final Value<int?> id;
  final Value<String?> tipo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const PatrimTipoMovimentacaosCompanion({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  PatrimTipoMovimentacaosCompanion.insert({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<PatrimTipoMovimentacao> custom({
    Expression<int>? id,
    Expression<String>? tipo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tipo != null) 'tipo': tipo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  PatrimTipoMovimentacaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? tipo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return PatrimTipoMovimentacaosCompanion(
      id: id ?? this.id,
      tipo: tipo ?? this.tipo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimTipoMovimentacaosCompanion(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaFornecedorsTable extends ViewPessoaFornecedors
    with TableInfo<$ViewPessoaFornecedorsTable, ViewPessoaFornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaFornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_fornecedor';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaFornecedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaFornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaFornecedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaFornecedorsTable createAlias(String alias) {
    return $ViewPessoaFornecedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaFornecedor extends DataClass
    implements Insertable<ViewPessoaFornecedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaFornecedor(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaFornecedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaFornecedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaFornecedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaFornecedor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaFornecedor copyWithCompanion(ViewPessoaFornecedorsCompanion data) {
    return ViewPessoaFornecedor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaFornecedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaFornecedorsCompanion
    extends UpdateCompanion<ViewPessoaFornecedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaFornecedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaFornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaFornecedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaFornecedorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaFornecedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  ViewPessoaColaborador copyWithCompanion(
      ViewPessoaColaboradorsCompanion data) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataAdmissao: data.dataAdmissao.present
          ? data.dataAdmissao.value
          : this.dataAdmissao,
      dataDemissao: data.dataDemissao.present
          ? data.dataDemissao.value
          : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao: data.ctpsDataExpedicao.present
          ? data.ctpsDataExpedicao.value
          : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge: data.municipioIbge.present
          ? data.municipioIbge.value
          : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $PatrimDocumentoBemsTable patrimDocumentoBems =
      $PatrimDocumentoBemsTable(this);
  late final $PatrimDepreciacaoBemsTable patrimDepreciacaoBems =
      $PatrimDepreciacaoBemsTable(this);
  late final $PatrimMovimentacaoBemsTable patrimMovimentacaoBems =
      $PatrimMovimentacaoBemsTable(this);
  late final $PatrimApoliceSegurosTable patrimApoliceSeguros =
      $PatrimApoliceSegurosTable(this);
  late final $PatrimBemsTable patrimBems = $PatrimBemsTable(this);
  late final $SetorsTable setors = $SetorsTable(this);
  late final $CentroResultadosTable centroResultados =
      $CentroResultadosTable(this);
  late final $PatrimIndiceAtualizacaosTable patrimIndiceAtualizacaos =
      $PatrimIndiceAtualizacaosTable(this);
  late final $PatrimTaxaDepreciacaosTable patrimTaxaDepreciacaos =
      $PatrimTaxaDepreciacaosTable(this);
  late final $PatrimGrupoBemsTable patrimGrupoBems =
      $PatrimGrupoBemsTable(this);
  late final $PatrimTipoAquisicaoBemsTable patrimTipoAquisicaoBems =
      $PatrimTipoAquisicaoBemsTable(this);
  late final $PatrimEstadoConservacaosTable patrimEstadoConservacaos =
      $PatrimEstadoConservacaosTable(this);
  late final $SeguradorasTable seguradoras = $SeguradorasTable(this);
  late final $PatrimTipoMovimentacaosTable patrimTipoMovimentacaos =
      $PatrimTipoMovimentacaosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaFornecedorsTable viewPessoaFornecedors =
      $ViewPessoaFornecedorsTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final PatrimBemDao patrimBemDao = PatrimBemDao(this as AppDatabase);
  late final SetorDao setorDao = SetorDao(this as AppDatabase);
  late final CentroResultadoDao centroResultadoDao =
      CentroResultadoDao(this as AppDatabase);
  late final PatrimIndiceAtualizacaoDao patrimIndiceAtualizacaoDao =
      PatrimIndiceAtualizacaoDao(this as AppDatabase);
  late final PatrimTaxaDepreciacaoDao patrimTaxaDepreciacaoDao =
      PatrimTaxaDepreciacaoDao(this as AppDatabase);
  late final PatrimGrupoBemDao patrimGrupoBemDao =
      PatrimGrupoBemDao(this as AppDatabase);
  late final PatrimTipoAquisicaoBemDao patrimTipoAquisicaoBemDao =
      PatrimTipoAquisicaoBemDao(this as AppDatabase);
  late final PatrimEstadoConservacaoDao patrimEstadoConservacaoDao =
      PatrimEstadoConservacaoDao(this as AppDatabase);
  late final SeguradoraDao seguradoraDao = SeguradoraDao(this as AppDatabase);
  late final PatrimTipoMovimentacaoDao patrimTipoMovimentacaoDao =
      PatrimTipoMovimentacaoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaFornecedorDao viewPessoaFornecedorDao =
      ViewPessoaFornecedorDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        patrimDocumentoBems,
        patrimDepreciacaoBems,
        patrimMovimentacaoBems,
        patrimApoliceSeguros,
        patrimBems,
        setors,
        centroResultados,
        patrimIndiceAtualizacaos,
        patrimTaxaDepreciacaos,
        patrimGrupoBems,
        patrimTipoAquisicaoBems,
        patrimEstadoConservacaos,
        seguradoras,
        patrimTipoMovimentacaos,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaFornecedors,
        viewPessoaColaboradors
      ];
}

typedef $$PatrimDocumentoBemsTableCreateCompanionBuilder
    = PatrimDocumentoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> imagem,
});
typedef $$PatrimDocumentoBemsTableUpdateCompanionBuilder
    = PatrimDocumentoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> imagem,
});

class $$PatrimDocumentoBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimDocumentoBemsTable,
    PatrimDocumentoBem,
    $$PatrimDocumentoBemsTableFilterComposer,
    $$PatrimDocumentoBemsTableOrderingComposer,
    $$PatrimDocumentoBemsTableCreateCompanionBuilder,
    $$PatrimDocumentoBemsTableUpdateCompanionBuilder> {
  $$PatrimDocumentoBemsTableTableManager(
      _$AppDatabase db, $PatrimDocumentoBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimDocumentoBemsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimDocumentoBemsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> imagem = const Value.absent(),
          }) =>
              PatrimDocumentoBemsCompanion(
            id: id,
            idPatrimBem: idPatrimBem,
            nome: nome,
            descricao: descricao,
            imagem: imagem,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> imagem = const Value.absent(),
          }) =>
              PatrimDocumentoBemsCompanion.insert(
            id: id,
            idPatrimBem: idPatrimBem,
            nome: nome,
            descricao: descricao,
            imagem: imagem,
          ),
        ));
}

class $$PatrimDocumentoBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimDocumentoBemsTable> {
  $$PatrimDocumentoBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get imagem => $state.composableBuilder(
      column: $state.table.imagem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimDocumentoBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimDocumentoBemsTable> {
  $$PatrimDocumentoBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get imagem => $state.composableBuilder(
      column: $state.table.imagem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimDepreciacaoBemsTableCreateCompanionBuilder
    = PatrimDepreciacaoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<DateTime?> dataDepreciacao,
  Value<int?> dias,
  Value<double?> taxa,
  Value<double?> indice,
  Value<double?> valor,
  Value<double?> depreciacaoAcumulada,
});
typedef $$PatrimDepreciacaoBemsTableUpdateCompanionBuilder
    = PatrimDepreciacaoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<DateTime?> dataDepreciacao,
  Value<int?> dias,
  Value<double?> taxa,
  Value<double?> indice,
  Value<double?> valor,
  Value<double?> depreciacaoAcumulada,
});

class $$PatrimDepreciacaoBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimDepreciacaoBemsTable,
    PatrimDepreciacaoBem,
    $$PatrimDepreciacaoBemsTableFilterComposer,
    $$PatrimDepreciacaoBemsTableOrderingComposer,
    $$PatrimDepreciacaoBemsTableCreateCompanionBuilder,
    $$PatrimDepreciacaoBemsTableUpdateCompanionBuilder> {
  $$PatrimDepreciacaoBemsTableTableManager(
      _$AppDatabase db, $PatrimDepreciacaoBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimDepreciacaoBemsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimDepreciacaoBemsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<DateTime?> dataDepreciacao = const Value.absent(),
            Value<int?> dias = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
            Value<double?> indice = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<double?> depreciacaoAcumulada = const Value.absent(),
          }) =>
              PatrimDepreciacaoBemsCompanion(
            id: id,
            idPatrimBem: idPatrimBem,
            dataDepreciacao: dataDepreciacao,
            dias: dias,
            taxa: taxa,
            indice: indice,
            valor: valor,
            depreciacaoAcumulada: depreciacaoAcumulada,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<DateTime?> dataDepreciacao = const Value.absent(),
            Value<int?> dias = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
            Value<double?> indice = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<double?> depreciacaoAcumulada = const Value.absent(),
          }) =>
              PatrimDepreciacaoBemsCompanion.insert(
            id: id,
            idPatrimBem: idPatrimBem,
            dataDepreciacao: dataDepreciacao,
            dias: dias,
            taxa: taxa,
            indice: indice,
            valor: valor,
            depreciacaoAcumulada: depreciacaoAcumulada,
          ),
        ));
}

class $$PatrimDepreciacaoBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimDepreciacaoBemsTable> {
  $$PatrimDepreciacaoBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDepreciacao => $state.composableBuilder(
      column: $state.table.dataDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get dias => $state.composableBuilder(
      column: $state.table.dias,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get depreciacaoAcumulada => $state.composableBuilder(
      column: $state.table.depreciacaoAcumulada,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimDepreciacaoBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimDepreciacaoBemsTable> {
  $$PatrimDepreciacaoBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDepreciacao => $state.composableBuilder(
      column: $state.table.dataDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get dias => $state.composableBuilder(
      column: $state.table.dias,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get depreciacaoAcumulada => $state.composableBuilder(
      column: $state.table.depreciacaoAcumulada,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimMovimentacaoBemsTableCreateCompanionBuilder
    = PatrimMovimentacaoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<int?> idPatrimTipoMovimentacao,
  Value<DateTime?> dataMovimentacao,
  Value<String?> responsavel,
});
typedef $$PatrimMovimentacaoBemsTableUpdateCompanionBuilder
    = PatrimMovimentacaoBemsCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<int?> idPatrimTipoMovimentacao,
  Value<DateTime?> dataMovimentacao,
  Value<String?> responsavel,
});

class $$PatrimMovimentacaoBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimMovimentacaoBemsTable,
    PatrimMovimentacaoBem,
    $$PatrimMovimentacaoBemsTableFilterComposer,
    $$PatrimMovimentacaoBemsTableOrderingComposer,
    $$PatrimMovimentacaoBemsTableCreateCompanionBuilder,
    $$PatrimMovimentacaoBemsTableUpdateCompanionBuilder> {
  $$PatrimMovimentacaoBemsTableTableManager(
      _$AppDatabase db, $PatrimMovimentacaoBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimMovimentacaoBemsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimMovimentacaoBemsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<int?> idPatrimTipoMovimentacao = const Value.absent(),
            Value<DateTime?> dataMovimentacao = const Value.absent(),
            Value<String?> responsavel = const Value.absent(),
          }) =>
              PatrimMovimentacaoBemsCompanion(
            id: id,
            idPatrimBem: idPatrimBem,
            idPatrimTipoMovimentacao: idPatrimTipoMovimentacao,
            dataMovimentacao: dataMovimentacao,
            responsavel: responsavel,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<int?> idPatrimTipoMovimentacao = const Value.absent(),
            Value<DateTime?> dataMovimentacao = const Value.absent(),
            Value<String?> responsavel = const Value.absent(),
          }) =>
              PatrimMovimentacaoBemsCompanion.insert(
            id: id,
            idPatrimBem: idPatrimBem,
            idPatrimTipoMovimentacao: idPatrimTipoMovimentacao,
            dataMovimentacao: dataMovimentacao,
            responsavel: responsavel,
          ),
        ));
}

class $$PatrimMovimentacaoBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimMovimentacaoBemsTable> {
  $$PatrimMovimentacaoBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimTipoMovimentacao => $state.composableBuilder(
      column: $state.table.idPatrimTipoMovimentacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataMovimentacao => $state.composableBuilder(
      column: $state.table.dataMovimentacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get responsavel => $state.composableBuilder(
      column: $state.table.responsavel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimMovimentacaoBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimMovimentacaoBemsTable> {
  $$PatrimMovimentacaoBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimTipoMovimentacao => $state.composableBuilder(
      column: $state.table.idPatrimTipoMovimentacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataMovimentacao => $state.composableBuilder(
      column: $state.table.dataMovimentacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get responsavel => $state.composableBuilder(
      column: $state.table.responsavel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimApoliceSegurosTableCreateCompanionBuilder
    = PatrimApoliceSegurosCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<int?> idSeguradora,
  Value<String?> numero,
  Value<DateTime?> dataContratacao,
  Value<DateTime?> dataVencimento,
  Value<double?> valorPremio,
  Value<double?> valorSegurado,
  Value<String?> observacao,
  Value<String?> imagem,
});
typedef $$PatrimApoliceSegurosTableUpdateCompanionBuilder
    = PatrimApoliceSegurosCompanion Function({
  Value<int?> id,
  Value<int?> idPatrimBem,
  Value<int?> idSeguradora,
  Value<String?> numero,
  Value<DateTime?> dataContratacao,
  Value<DateTime?> dataVencimento,
  Value<double?> valorPremio,
  Value<double?> valorSegurado,
  Value<String?> observacao,
  Value<String?> imagem,
});

class $$PatrimApoliceSegurosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimApoliceSegurosTable,
    PatrimApoliceSeguro,
    $$PatrimApoliceSegurosTableFilterComposer,
    $$PatrimApoliceSegurosTableOrderingComposer,
    $$PatrimApoliceSegurosTableCreateCompanionBuilder,
    $$PatrimApoliceSegurosTableUpdateCompanionBuilder> {
  $$PatrimApoliceSegurosTableTableManager(
      _$AppDatabase db, $PatrimApoliceSegurosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimApoliceSegurosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimApoliceSegurosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<int?> idSeguradora = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<DateTime?> dataContratacao = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<double?> valorPremio = const Value.absent(),
            Value<double?> valorSegurado = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> imagem = const Value.absent(),
          }) =>
              PatrimApoliceSegurosCompanion(
            id: id,
            idPatrimBem: idPatrimBem,
            idSeguradora: idSeguradora,
            numero: numero,
            dataContratacao: dataContratacao,
            dataVencimento: dataVencimento,
            valorPremio: valorPremio,
            valorSegurado: valorSegurado,
            observacao: observacao,
            imagem: imagem,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPatrimBem = const Value.absent(),
            Value<int?> idSeguradora = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<DateTime?> dataContratacao = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<double?> valorPremio = const Value.absent(),
            Value<double?> valorSegurado = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> imagem = const Value.absent(),
          }) =>
              PatrimApoliceSegurosCompanion.insert(
            id: id,
            idPatrimBem: idPatrimBem,
            idSeguradora: idSeguradora,
            numero: numero,
            dataContratacao: dataContratacao,
            dataVencimento: dataVencimento,
            valorPremio: valorPremio,
            valorSegurado: valorSegurado,
            observacao: observacao,
            imagem: imagem,
          ),
        ));
}

class $$PatrimApoliceSegurosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimApoliceSegurosTable> {
  $$PatrimApoliceSegurosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSeguradora => $state.composableBuilder(
      column: $state.table.idSeguradora,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataContratacao => $state.composableBuilder(
      column: $state.table.dataContratacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorPremio => $state.composableBuilder(
      column: $state.table.valorPremio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSegurado => $state.composableBuilder(
      column: $state.table.valorSegurado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get imagem => $state.composableBuilder(
      column: $state.table.imagem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimApoliceSegurosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimApoliceSegurosTable> {
  $$PatrimApoliceSegurosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimBem => $state.composableBuilder(
      column: $state.table.idPatrimBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSeguradora => $state.composableBuilder(
      column: $state.table.idSeguradora,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataContratacao => $state.composableBuilder(
      column: $state.table.dataContratacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorPremio => $state.composableBuilder(
      column: $state.table.valorPremio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSegurado => $state.composableBuilder(
      column: $state.table.valorSegurado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get imagem => $state.composableBuilder(
      column: $state.table.imagem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimBemsTableCreateCompanionBuilder = PatrimBemsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idFornecedor,
  Value<int?> idColaborador,
  Value<int?> idPatrimTipoAquisicaoBem,
  Value<int?> idPatrimEstadoConservacao,
  Value<int?> idPatrimGrupoBem,
  Value<int?> idSetor,
  Value<String?> numeroNb,
  Value<String?> nome,
  Value<String?> descricao,
  Value<DateTime?> dataAquisicao,
  Value<DateTime?> dataAceite,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataContabilizado,
  Value<DateTime?> dataVistoria,
  Value<DateTime?> dataMarcacao,
  Value<DateTime?> dataBaixa,
  Value<DateTime?> vencimentoGarantia,
  Value<String?> numeroNotaFiscal,
  Value<String?> numeroSerie,
  Value<String?> chaveNfe,
  Value<double?> valorOriginal,
  Value<double?> valorCompra,
  Value<double?> valorAtualizado,
  Value<double?> valorBaixa,
  Value<String?> deprecia,
  Value<String?> metodoDepreciacao,
  Value<DateTime?> inicioDepreciacao,
  Value<DateTime?> ultimaDepreciacao,
  Value<String?> tipoDepreciacao,
  Value<double?> taxaAnualDepreciacao,
  Value<double?> taxaMensalDepreciacao,
  Value<double?> taxaDepreciacaoAcelerada,
  Value<double?> taxaDepreciacaoIncentivada,
  Value<String?> funcao,
});
typedef $$PatrimBemsTableUpdateCompanionBuilder = PatrimBemsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idFornecedor,
  Value<int?> idColaborador,
  Value<int?> idPatrimTipoAquisicaoBem,
  Value<int?> idPatrimEstadoConservacao,
  Value<int?> idPatrimGrupoBem,
  Value<int?> idSetor,
  Value<String?> numeroNb,
  Value<String?> nome,
  Value<String?> descricao,
  Value<DateTime?> dataAquisicao,
  Value<DateTime?> dataAceite,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataContabilizado,
  Value<DateTime?> dataVistoria,
  Value<DateTime?> dataMarcacao,
  Value<DateTime?> dataBaixa,
  Value<DateTime?> vencimentoGarantia,
  Value<String?> numeroNotaFiscal,
  Value<String?> numeroSerie,
  Value<String?> chaveNfe,
  Value<double?> valorOriginal,
  Value<double?> valorCompra,
  Value<double?> valorAtualizado,
  Value<double?> valorBaixa,
  Value<String?> deprecia,
  Value<String?> metodoDepreciacao,
  Value<DateTime?> inicioDepreciacao,
  Value<DateTime?> ultimaDepreciacao,
  Value<String?> tipoDepreciacao,
  Value<double?> taxaAnualDepreciacao,
  Value<double?> taxaMensalDepreciacao,
  Value<double?> taxaDepreciacaoAcelerada,
  Value<double?> taxaDepreciacaoIncentivada,
  Value<String?> funcao,
});

class $$PatrimBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimBemsTable,
    PatrimBem,
    $$PatrimBemsTableFilterComposer,
    $$PatrimBemsTableOrderingComposer,
    $$PatrimBemsTableCreateCompanionBuilder,
    $$PatrimBemsTableUpdateCompanionBuilder> {
  $$PatrimBemsTableTableManager(_$AppDatabase db, $PatrimBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PatrimBemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PatrimBemsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idFornecedor = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
            Value<int?> idPatrimEstadoConservacao = const Value.absent(),
            Value<int?> idPatrimGrupoBem = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<String?> numeroNb = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataAquisicao = const Value.absent(),
            Value<DateTime?> dataAceite = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataContabilizado = const Value.absent(),
            Value<DateTime?> dataVistoria = const Value.absent(),
            Value<DateTime?> dataMarcacao = const Value.absent(),
            Value<DateTime?> dataBaixa = const Value.absent(),
            Value<DateTime?> vencimentoGarantia = const Value.absent(),
            Value<String?> numeroNotaFiscal = const Value.absent(),
            Value<String?> numeroSerie = const Value.absent(),
            Value<String?> chaveNfe = const Value.absent(),
            Value<double?> valorOriginal = const Value.absent(),
            Value<double?> valorCompra = const Value.absent(),
            Value<double?> valorAtualizado = const Value.absent(),
            Value<double?> valorBaixa = const Value.absent(),
            Value<String?> deprecia = const Value.absent(),
            Value<String?> metodoDepreciacao = const Value.absent(),
            Value<DateTime?> inicioDepreciacao = const Value.absent(),
            Value<DateTime?> ultimaDepreciacao = const Value.absent(),
            Value<String?> tipoDepreciacao = const Value.absent(),
            Value<double?> taxaAnualDepreciacao = const Value.absent(),
            Value<double?> taxaMensalDepreciacao = const Value.absent(),
            Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
            Value<double?> taxaDepreciacaoIncentivada = const Value.absent(),
            Value<String?> funcao = const Value.absent(),
          }) =>
              PatrimBemsCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            idFornecedor: idFornecedor,
            idColaborador: idColaborador,
            idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
            idPatrimEstadoConservacao: idPatrimEstadoConservacao,
            idPatrimGrupoBem: idPatrimGrupoBem,
            idSetor: idSetor,
            numeroNb: numeroNb,
            nome: nome,
            descricao: descricao,
            dataAquisicao: dataAquisicao,
            dataAceite: dataAceite,
            dataCadastro: dataCadastro,
            dataContabilizado: dataContabilizado,
            dataVistoria: dataVistoria,
            dataMarcacao: dataMarcacao,
            dataBaixa: dataBaixa,
            vencimentoGarantia: vencimentoGarantia,
            numeroNotaFiscal: numeroNotaFiscal,
            numeroSerie: numeroSerie,
            chaveNfe: chaveNfe,
            valorOriginal: valorOriginal,
            valorCompra: valorCompra,
            valorAtualizado: valorAtualizado,
            valorBaixa: valorBaixa,
            deprecia: deprecia,
            metodoDepreciacao: metodoDepreciacao,
            inicioDepreciacao: inicioDepreciacao,
            ultimaDepreciacao: ultimaDepreciacao,
            tipoDepreciacao: tipoDepreciacao,
            taxaAnualDepreciacao: taxaAnualDepreciacao,
            taxaMensalDepreciacao: taxaMensalDepreciacao,
            taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
            taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
            funcao: funcao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idFornecedor = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
            Value<int?> idPatrimEstadoConservacao = const Value.absent(),
            Value<int?> idPatrimGrupoBem = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<String?> numeroNb = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataAquisicao = const Value.absent(),
            Value<DateTime?> dataAceite = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataContabilizado = const Value.absent(),
            Value<DateTime?> dataVistoria = const Value.absent(),
            Value<DateTime?> dataMarcacao = const Value.absent(),
            Value<DateTime?> dataBaixa = const Value.absent(),
            Value<DateTime?> vencimentoGarantia = const Value.absent(),
            Value<String?> numeroNotaFiscal = const Value.absent(),
            Value<String?> numeroSerie = const Value.absent(),
            Value<String?> chaveNfe = const Value.absent(),
            Value<double?> valorOriginal = const Value.absent(),
            Value<double?> valorCompra = const Value.absent(),
            Value<double?> valorAtualizado = const Value.absent(),
            Value<double?> valorBaixa = const Value.absent(),
            Value<String?> deprecia = const Value.absent(),
            Value<String?> metodoDepreciacao = const Value.absent(),
            Value<DateTime?> inicioDepreciacao = const Value.absent(),
            Value<DateTime?> ultimaDepreciacao = const Value.absent(),
            Value<String?> tipoDepreciacao = const Value.absent(),
            Value<double?> taxaAnualDepreciacao = const Value.absent(),
            Value<double?> taxaMensalDepreciacao = const Value.absent(),
            Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
            Value<double?> taxaDepreciacaoIncentivada = const Value.absent(),
            Value<String?> funcao = const Value.absent(),
          }) =>
              PatrimBemsCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            idFornecedor: idFornecedor,
            idColaborador: idColaborador,
            idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
            idPatrimEstadoConservacao: idPatrimEstadoConservacao,
            idPatrimGrupoBem: idPatrimGrupoBem,
            idSetor: idSetor,
            numeroNb: numeroNb,
            nome: nome,
            descricao: descricao,
            dataAquisicao: dataAquisicao,
            dataAceite: dataAceite,
            dataCadastro: dataCadastro,
            dataContabilizado: dataContabilizado,
            dataVistoria: dataVistoria,
            dataMarcacao: dataMarcacao,
            dataBaixa: dataBaixa,
            vencimentoGarantia: vencimentoGarantia,
            numeroNotaFiscal: numeroNotaFiscal,
            numeroSerie: numeroSerie,
            chaveNfe: chaveNfe,
            valorOriginal: valorOriginal,
            valorCompra: valorCompra,
            valorAtualizado: valorAtualizado,
            valorBaixa: valorBaixa,
            deprecia: deprecia,
            metodoDepreciacao: metodoDepreciacao,
            inicioDepreciacao: inicioDepreciacao,
            ultimaDepreciacao: ultimaDepreciacao,
            tipoDepreciacao: tipoDepreciacao,
            taxaAnualDepreciacao: taxaAnualDepreciacao,
            taxaMensalDepreciacao: taxaMensalDepreciacao,
            taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
            taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
            funcao: funcao,
          ),
        ));
}

class $$PatrimBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimBemsTable> {
  $$PatrimBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFornecedor => $state.composableBuilder(
      column: $state.table.idFornecedor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimTipoAquisicaoBem => $state.composableBuilder(
      column: $state.table.idPatrimTipoAquisicaoBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimEstadoConservacao => $state.composableBuilder(
      column: $state.table.idPatrimEstadoConservacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPatrimGrupoBem => $state.composableBuilder(
      column: $state.table.idPatrimGrupoBem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroNb => $state.composableBuilder(
      column: $state.table.numeroNb,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAquisicao => $state.composableBuilder(
      column: $state.table.dataAquisicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAceite => $state.composableBuilder(
      column: $state.table.dataAceite,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataContabilizado => $state.composableBuilder(
      column: $state.table.dataContabilizado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataVistoria => $state.composableBuilder(
      column: $state.table.dataVistoria,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataMarcacao => $state.composableBuilder(
      column: $state.table.dataMarcacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataBaixa => $state.composableBuilder(
      column: $state.table.dataBaixa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get vencimentoGarantia => $state.composableBuilder(
      column: $state.table.vencimentoGarantia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroNotaFiscal => $state.composableBuilder(
      column: $state.table.numeroNotaFiscal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroSerie => $state.composableBuilder(
      column: $state.table.numeroSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get chaveNfe => $state.composableBuilder(
      column: $state.table.chaveNfe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorOriginal => $state.composableBuilder(
      column: $state.table.valorOriginal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCompra => $state.composableBuilder(
      column: $state.table.valorCompra,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorAtualizado => $state.composableBuilder(
      column: $state.table.valorAtualizado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorBaixa => $state.composableBuilder(
      column: $state.table.valorBaixa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get deprecia => $state.composableBuilder(
      column: $state.table.deprecia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get metodoDepreciacao => $state.composableBuilder(
      column: $state.table.metodoDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get inicioDepreciacao => $state.composableBuilder(
      column: $state.table.inicioDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ultimaDepreciacao => $state.composableBuilder(
      column: $state.table.ultimaDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoDepreciacao => $state.composableBuilder(
      column: $state.table.tipoDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaAnualDepreciacao => $state.composableBuilder(
      column: $state.table.taxaAnualDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaMensalDepreciacao => $state.composableBuilder(
      column: $state.table.taxaMensalDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDepreciacaoAcelerada =>
      $state.composableBuilder(
          column: $state.table.taxaDepreciacaoAcelerada,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDepreciacaoIncentivada =>
      $state.composableBuilder(
          column: $state.table.taxaDepreciacaoIncentivada,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcao => $state.composableBuilder(
      column: $state.table.funcao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimBemsTable> {
  $$PatrimBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFornecedor => $state.composableBuilder(
      column: $state.table.idFornecedor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimTipoAquisicaoBem => $state.composableBuilder(
      column: $state.table.idPatrimTipoAquisicaoBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimEstadoConservacao =>
      $state.composableBuilder(
          column: $state.table.idPatrimEstadoConservacao,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPatrimGrupoBem => $state.composableBuilder(
      column: $state.table.idPatrimGrupoBem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroNb => $state.composableBuilder(
      column: $state.table.numeroNb,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAquisicao => $state.composableBuilder(
      column: $state.table.dataAquisicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAceite => $state.composableBuilder(
      column: $state.table.dataAceite,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataContabilizado => $state.composableBuilder(
      column: $state.table.dataContabilizado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataVistoria => $state.composableBuilder(
      column: $state.table.dataVistoria,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataMarcacao => $state.composableBuilder(
      column: $state.table.dataMarcacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataBaixa => $state.composableBuilder(
      column: $state.table.dataBaixa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get vencimentoGarantia => $state.composableBuilder(
      column: $state.table.vencimentoGarantia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroNotaFiscal => $state.composableBuilder(
      column: $state.table.numeroNotaFiscal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroSerie => $state.composableBuilder(
      column: $state.table.numeroSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get chaveNfe => $state.composableBuilder(
      column: $state.table.chaveNfe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorOriginal => $state.composableBuilder(
      column: $state.table.valorOriginal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCompra => $state.composableBuilder(
      column: $state.table.valorCompra,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorAtualizado => $state.composableBuilder(
      column: $state.table.valorAtualizado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorBaixa => $state.composableBuilder(
      column: $state.table.valorBaixa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get deprecia => $state.composableBuilder(
      column: $state.table.deprecia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get metodoDepreciacao => $state.composableBuilder(
      column: $state.table.metodoDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get inicioDepreciacao => $state.composableBuilder(
      column: $state.table.inicioDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ultimaDepreciacao => $state.composableBuilder(
      column: $state.table.ultimaDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoDepreciacao => $state.composableBuilder(
      column: $state.table.tipoDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaAnualDepreciacao => $state.composableBuilder(
      column: $state.table.taxaAnualDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaMensalDepreciacao => $state.composableBuilder(
      column: $state.table.taxaMensalDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDepreciacaoAcelerada =>
      $state.composableBuilder(
          column: $state.table.taxaDepreciacaoAcelerada,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDepreciacaoIncentivada =>
      $state.composableBuilder(
          column: $state.table.taxaDepreciacaoIncentivada,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcao => $state.composableBuilder(
      column: $state.table.funcao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$SetorsTableCreateCompanionBuilder = SetorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$SetorsTableUpdateCompanionBuilder = SetorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$SetorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SetorsTable,
    Setor,
    $$SetorsTableFilterComposer,
    $$SetorsTableOrderingComposer,
    $$SetorsTableCreateCompanionBuilder,
    $$SetorsTableUpdateCompanionBuilder> {
  $$SetorsTableTableManager(_$AppDatabase db, $SetorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SetorsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SetorsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              SetorsCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              SetorsCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$SetorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SetorsTable> {
  $$SetorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SetorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SetorsTable> {
  $$SetorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CentroResultadosTableCreateCompanionBuilder
    = CentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idPlanoCentroResultado,
  Value<String?> classificacao,
  Value<String?> descricao,
  Value<String?> sofreRateiro,
});
typedef $$CentroResultadosTableUpdateCompanionBuilder
    = CentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idPlanoCentroResultado,
  Value<String?> classificacao,
  Value<String?> descricao,
  Value<String?> sofreRateiro,
});

class $$CentroResultadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CentroResultadosTable,
    CentroResultado,
    $$CentroResultadosTableFilterComposer,
    $$CentroResultadosTableOrderingComposer,
    $$CentroResultadosTableCreateCompanionBuilder,
    $$CentroResultadosTableUpdateCompanionBuilder> {
  $$CentroResultadosTableTableManager(
      _$AppDatabase db, $CentroResultadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CentroResultadosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CentroResultadosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoCentroResultado = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> sofreRateiro = const Value.absent(),
          }) =>
              CentroResultadosCompanion(
            id: id,
            idPlanoCentroResultado: idPlanoCentroResultado,
            classificacao: classificacao,
            descricao: descricao,
            sofreRateiro: sofreRateiro,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoCentroResultado = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> sofreRateiro = const Value.absent(),
          }) =>
              CentroResultadosCompanion.insert(
            id: id,
            idPlanoCentroResultado: idPlanoCentroResultado,
            classificacao: classificacao,
            descricao: descricao,
            sofreRateiro: sofreRateiro,
          ),
        ));
}

class $$CentroResultadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $CentroResultadosTable> {
  $$CentroResultadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPlanoCentroResultado => $state.composableBuilder(
      column: $state.table.idPlanoCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get sofreRateiro => $state.composableBuilder(
      column: $state.table.sofreRateiro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CentroResultadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $CentroResultadosTable> {
  $$CentroResultadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPlanoCentroResultado => $state.composableBuilder(
      column: $state.table.idPlanoCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get sofreRateiro => $state.composableBuilder(
      column: $state.table.sofreRateiro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimIndiceAtualizacaosTableCreateCompanionBuilder
    = PatrimIndiceAtualizacaosCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataIndice,
  Value<String?> nome,
  Value<double?> valor,
  Value<double?> valorAlternativo,
});
typedef $$PatrimIndiceAtualizacaosTableUpdateCompanionBuilder
    = PatrimIndiceAtualizacaosCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataIndice,
  Value<String?> nome,
  Value<double?> valor,
  Value<double?> valorAlternativo,
});

class $$PatrimIndiceAtualizacaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimIndiceAtualizacaosTable,
    PatrimIndiceAtualizacao,
    $$PatrimIndiceAtualizacaosTableFilterComposer,
    $$PatrimIndiceAtualizacaosTableOrderingComposer,
    $$PatrimIndiceAtualizacaosTableCreateCompanionBuilder,
    $$PatrimIndiceAtualizacaosTableUpdateCompanionBuilder> {
  $$PatrimIndiceAtualizacaosTableTableManager(
      _$AppDatabase db, $PatrimIndiceAtualizacaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimIndiceAtualizacaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimIndiceAtualizacaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataIndice = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<double?> valorAlternativo = const Value.absent(),
          }) =>
              PatrimIndiceAtualizacaosCompanion(
            id: id,
            dataIndice: dataIndice,
            nome: nome,
            valor: valor,
            valorAlternativo: valorAlternativo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataIndice = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<double?> valorAlternativo = const Value.absent(),
          }) =>
              PatrimIndiceAtualizacaosCompanion.insert(
            id: id,
            dataIndice: dataIndice,
            nome: nome,
            valor: valor,
            valorAlternativo: valorAlternativo,
          ),
        ));
}

class $$PatrimIndiceAtualizacaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimIndiceAtualizacaosTable> {
  $$PatrimIndiceAtualizacaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataIndice => $state.composableBuilder(
      column: $state.table.dataIndice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorAlternativo => $state.composableBuilder(
      column: $state.table.valorAlternativo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimIndiceAtualizacaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimIndiceAtualizacaosTable> {
  $$PatrimIndiceAtualizacaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataIndice => $state.composableBuilder(
      column: $state.table.dataIndice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorAlternativo => $state.composableBuilder(
      column: $state.table.valorAlternativo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimTaxaDepreciacaosTableCreateCompanionBuilder
    = PatrimTaxaDepreciacaosCompanion Function({
  Value<int?> id,
  Value<String?> ncm,
  Value<String?> bem,
  Value<double?> vida,
  Value<double?> taxa,
});
typedef $$PatrimTaxaDepreciacaosTableUpdateCompanionBuilder
    = PatrimTaxaDepreciacaosCompanion Function({
  Value<int?> id,
  Value<String?> ncm,
  Value<String?> bem,
  Value<double?> vida,
  Value<double?> taxa,
});

class $$PatrimTaxaDepreciacaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimTaxaDepreciacaosTable,
    PatrimTaxaDepreciacao,
    $$PatrimTaxaDepreciacaosTableFilterComposer,
    $$PatrimTaxaDepreciacaosTableOrderingComposer,
    $$PatrimTaxaDepreciacaosTableCreateCompanionBuilder,
    $$PatrimTaxaDepreciacaosTableUpdateCompanionBuilder> {
  $$PatrimTaxaDepreciacaosTableTableManager(
      _$AppDatabase db, $PatrimTaxaDepreciacaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimTaxaDepreciacaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimTaxaDepreciacaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> ncm = const Value.absent(),
            Value<String?> bem = const Value.absent(),
            Value<double?> vida = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
          }) =>
              PatrimTaxaDepreciacaosCompanion(
            id: id,
            ncm: ncm,
            bem: bem,
            vida: vida,
            taxa: taxa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> ncm = const Value.absent(),
            Value<String?> bem = const Value.absent(),
            Value<double?> vida = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
          }) =>
              PatrimTaxaDepreciacaosCompanion.insert(
            id: id,
            ncm: ncm,
            bem: bem,
            vida: vida,
            taxa: taxa,
          ),
        ));
}

class $$PatrimTaxaDepreciacaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimTaxaDepreciacaosTable> {
  $$PatrimTaxaDepreciacaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ncm => $state.composableBuilder(
      column: $state.table.ncm,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bem => $state.composableBuilder(
      column: $state.table.bem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get vida => $state.composableBuilder(
      column: $state.table.vida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimTaxaDepreciacaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimTaxaDepreciacaosTable> {
  $$PatrimTaxaDepreciacaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ncm => $state.composableBuilder(
      column: $state.table.ncm,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bem => $state.composableBuilder(
      column: $state.table.bem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get vida => $state.composableBuilder(
      column: $state.table.vida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimGrupoBemsTableCreateCompanionBuilder = PatrimGrupoBemsCompanion
    Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> contaAtivoImobilizado,
  Value<String?> contaDepreciacaoAcumulada,
  Value<String?> contaDespesaDepreciacao,
  Value<int?> codigoHistorico,
});
typedef $$PatrimGrupoBemsTableUpdateCompanionBuilder = PatrimGrupoBemsCompanion
    Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> contaAtivoImobilizado,
  Value<String?> contaDepreciacaoAcumulada,
  Value<String?> contaDespesaDepreciacao,
  Value<int?> codigoHistorico,
});

class $$PatrimGrupoBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimGrupoBemsTable,
    PatrimGrupoBem,
    $$PatrimGrupoBemsTableFilterComposer,
    $$PatrimGrupoBemsTableOrderingComposer,
    $$PatrimGrupoBemsTableCreateCompanionBuilder,
    $$PatrimGrupoBemsTableUpdateCompanionBuilder> {
  $$PatrimGrupoBemsTableTableManager(
      _$AppDatabase db, $PatrimGrupoBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PatrimGrupoBemsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PatrimGrupoBemsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> contaAtivoImobilizado = const Value.absent(),
            Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
            Value<String?> contaDespesaDepreciacao = const Value.absent(),
            Value<int?> codigoHistorico = const Value.absent(),
          }) =>
              PatrimGrupoBemsCompanion(
            id: id,
            codigo: codigo,
            nome: nome,
            descricao: descricao,
            contaAtivoImobilizado: contaAtivoImobilizado,
            contaDepreciacaoAcumulada: contaDepreciacaoAcumulada,
            contaDespesaDepreciacao: contaDespesaDepreciacao,
            codigoHistorico: codigoHistorico,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> contaAtivoImobilizado = const Value.absent(),
            Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
            Value<String?> contaDespesaDepreciacao = const Value.absent(),
            Value<int?> codigoHistorico = const Value.absent(),
          }) =>
              PatrimGrupoBemsCompanion.insert(
            id: id,
            codigo: codigo,
            nome: nome,
            descricao: descricao,
            contaAtivoImobilizado: contaAtivoImobilizado,
            contaDepreciacaoAcumulada: contaDepreciacaoAcumulada,
            contaDespesaDepreciacao: contaDespesaDepreciacao,
            codigoHistorico: codigoHistorico,
          ),
        ));
}

class $$PatrimGrupoBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimGrupoBemsTable> {
  $$PatrimGrupoBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaAtivoImobilizado => $state.composableBuilder(
      column: $state.table.contaAtivoImobilizado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaDepreciacaoAcumulada =>
      $state.composableBuilder(
          column: $state.table.contaDepreciacaoAcumulada,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaDespesaDepreciacao => $state.composableBuilder(
      column: $state.table.contaDespesaDepreciacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get codigoHistorico => $state.composableBuilder(
      column: $state.table.codigoHistorico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimGrupoBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimGrupoBemsTable> {
  $$PatrimGrupoBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaAtivoImobilizado => $state.composableBuilder(
      column: $state.table.contaAtivoImobilizado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaDepreciacaoAcumulada => $state
      .composableBuilder(
          column: $state.table.contaDepreciacaoAcumulada,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaDespesaDepreciacao =>
      $state.composableBuilder(
          column: $state.table.contaDespesaDepreciacao,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get codigoHistorico => $state.composableBuilder(
      column: $state.table.codigoHistorico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimTipoAquisicaoBemsTableCreateCompanionBuilder
    = PatrimTipoAquisicaoBemsCompanion Function({
  Value<int?> id,
  Value<String?> tipo,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$PatrimTipoAquisicaoBemsTableUpdateCompanionBuilder
    = PatrimTipoAquisicaoBemsCompanion Function({
  Value<int?> id,
  Value<String?> tipo,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$PatrimTipoAquisicaoBemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimTipoAquisicaoBemsTable,
    PatrimTipoAquisicaoBem,
    $$PatrimTipoAquisicaoBemsTableFilterComposer,
    $$PatrimTipoAquisicaoBemsTableOrderingComposer,
    $$PatrimTipoAquisicaoBemsTableCreateCompanionBuilder,
    $$PatrimTipoAquisicaoBemsTableUpdateCompanionBuilder> {
  $$PatrimTipoAquisicaoBemsTableTableManager(
      _$AppDatabase db, $PatrimTipoAquisicaoBemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimTipoAquisicaoBemsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimTipoAquisicaoBemsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimTipoAquisicaoBemsCompanion(
            id: id,
            tipo: tipo,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimTipoAquisicaoBemsCompanion.insert(
            id: id,
            tipo: tipo,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$PatrimTipoAquisicaoBemsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimTipoAquisicaoBemsTable> {
  $$PatrimTipoAquisicaoBemsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimTipoAquisicaoBemsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimTipoAquisicaoBemsTable> {
  $$PatrimTipoAquisicaoBemsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimEstadoConservacaosTableCreateCompanionBuilder
    = PatrimEstadoConservacaosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$PatrimEstadoConservacaosTableUpdateCompanionBuilder
    = PatrimEstadoConservacaosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$PatrimEstadoConservacaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimEstadoConservacaosTable,
    PatrimEstadoConservacao,
    $$PatrimEstadoConservacaosTableFilterComposer,
    $$PatrimEstadoConservacaosTableOrderingComposer,
    $$PatrimEstadoConservacaosTableCreateCompanionBuilder,
    $$PatrimEstadoConservacaosTableUpdateCompanionBuilder> {
  $$PatrimEstadoConservacaosTableTableManager(
      _$AppDatabase db, $PatrimEstadoConservacaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimEstadoConservacaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimEstadoConservacaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimEstadoConservacaosCompanion(
            id: id,
            codigo: codigo,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimEstadoConservacaosCompanion.insert(
            id: id,
            codigo: codigo,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$PatrimEstadoConservacaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimEstadoConservacaosTable> {
  $$PatrimEstadoConservacaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimEstadoConservacaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimEstadoConservacaosTable> {
  $$PatrimEstadoConservacaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$SeguradorasTableCreateCompanionBuilder = SeguradorasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> contato,
  Value<String?> telefone,
});
typedef $$SeguradorasTableUpdateCompanionBuilder = SeguradorasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> contato,
  Value<String?> telefone,
});

class $$SeguradorasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SeguradorasTable,
    Seguradora,
    $$SeguradorasTableFilterComposer,
    $$SeguradorasTableOrderingComposer,
    $$SeguradorasTableCreateCompanionBuilder,
    $$SeguradorasTableUpdateCompanionBuilder> {
  $$SeguradorasTableTableManager(_$AppDatabase db, $SeguradorasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SeguradorasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SeguradorasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> contato = const Value.absent(),
            Value<String?> telefone = const Value.absent(),
          }) =>
              SeguradorasCompanion(
            id: id,
            nome: nome,
            contato: contato,
            telefone: telefone,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> contato = const Value.absent(),
            Value<String?> telefone = const Value.absent(),
          }) =>
              SeguradorasCompanion.insert(
            id: id,
            nome: nome,
            contato: contato,
            telefone: telefone,
          ),
        ));
}

class $$SeguradorasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SeguradorasTable> {
  $$SeguradorasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contato => $state.composableBuilder(
      column: $state.table.contato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get telefone => $state.composableBuilder(
      column: $state.table.telefone,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SeguradorasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SeguradorasTable> {
  $$SeguradorasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contato => $state.composableBuilder(
      column: $state.table.contato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get telefone => $state.composableBuilder(
      column: $state.table.telefone,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PatrimTipoMovimentacaosTableCreateCompanionBuilder
    = PatrimTipoMovimentacaosCompanion Function({
  Value<int?> id,
  Value<String?> tipo,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$PatrimTipoMovimentacaosTableUpdateCompanionBuilder
    = PatrimTipoMovimentacaosCompanion Function({
  Value<int?> id,
  Value<String?> tipo,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$PatrimTipoMovimentacaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PatrimTipoMovimentacaosTable,
    PatrimTipoMovimentacao,
    $$PatrimTipoMovimentacaosTableFilterComposer,
    $$PatrimTipoMovimentacaosTableOrderingComposer,
    $$PatrimTipoMovimentacaosTableCreateCompanionBuilder,
    $$PatrimTipoMovimentacaosTableUpdateCompanionBuilder> {
  $$PatrimTipoMovimentacaosTableTableManager(
      _$AppDatabase db, $PatrimTipoMovimentacaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PatrimTipoMovimentacaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PatrimTipoMovimentacaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimTipoMovimentacaosCompanion(
            id: id,
            tipo: tipo,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PatrimTipoMovimentacaosCompanion.insert(
            id: id,
            tipo: tipo,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$PatrimTipoMovimentacaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PatrimTipoMovimentacaosTable> {
  $$PatrimTipoMovimentacaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PatrimTipoMovimentacaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PatrimTipoMovimentacaosTable> {
  $$PatrimTipoMovimentacaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaFornecedorsTableCreateCompanionBuilder
    = ViewPessoaFornecedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaFornecedorsTableUpdateCompanionBuilder
    = ViewPessoaFornecedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaFornecedorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaFornecedorsTable,
    ViewPessoaFornecedor,
    $$ViewPessoaFornecedorsTableFilterComposer,
    $$ViewPessoaFornecedorsTableOrderingComposer,
    $$ViewPessoaFornecedorsTableCreateCompanionBuilder,
    $$ViewPessoaFornecedorsTableUpdateCompanionBuilder> {
  $$ViewPessoaFornecedorsTableTableManager(
      _$AppDatabase db, $ViewPessoaFornecedorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaFornecedorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaFornecedorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaFornecedorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaFornecedorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaFornecedorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaFornecedorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});

class $$ViewPessoaColaboradorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaColaboradorsTable,
    ViewPessoaColaborador,
    $$ViewPessoaColaboradorsTableFilterComposer,
    $$ViewPessoaColaboradorsTableOrderingComposer,
    $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
    $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableTableManager(
      _$AppDatabase db, $ViewPessoaColaboradorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaColaboradorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaColaboradorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
        ));
}

class $$ViewPessoaColaboradorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$PatrimDocumentoBemsTableTableManager get patrimDocumentoBems =>
      $$PatrimDocumentoBemsTableTableManager(_db, _db.patrimDocumentoBems);
  $$PatrimDepreciacaoBemsTableTableManager get patrimDepreciacaoBems =>
      $$PatrimDepreciacaoBemsTableTableManager(_db, _db.patrimDepreciacaoBems);
  $$PatrimMovimentacaoBemsTableTableManager get patrimMovimentacaoBems =>
      $$PatrimMovimentacaoBemsTableTableManager(
          _db, _db.patrimMovimentacaoBems);
  $$PatrimApoliceSegurosTableTableManager get patrimApoliceSeguros =>
      $$PatrimApoliceSegurosTableTableManager(_db, _db.patrimApoliceSeguros);
  $$PatrimBemsTableTableManager get patrimBems =>
      $$PatrimBemsTableTableManager(_db, _db.patrimBems);
  $$SetorsTableTableManager get setors =>
      $$SetorsTableTableManager(_db, _db.setors);
  $$CentroResultadosTableTableManager get centroResultados =>
      $$CentroResultadosTableTableManager(_db, _db.centroResultados);
  $$PatrimIndiceAtualizacaosTableTableManager get patrimIndiceAtualizacaos =>
      $$PatrimIndiceAtualizacaosTableTableManager(
          _db, _db.patrimIndiceAtualizacaos);
  $$PatrimTaxaDepreciacaosTableTableManager get patrimTaxaDepreciacaos =>
      $$PatrimTaxaDepreciacaosTableTableManager(
          _db, _db.patrimTaxaDepreciacaos);
  $$PatrimGrupoBemsTableTableManager get patrimGrupoBems =>
      $$PatrimGrupoBemsTableTableManager(_db, _db.patrimGrupoBems);
  $$PatrimTipoAquisicaoBemsTableTableManager get patrimTipoAquisicaoBems =>
      $$PatrimTipoAquisicaoBemsTableTableManager(
          _db, _db.patrimTipoAquisicaoBems);
  $$PatrimEstadoConservacaosTableTableManager get patrimEstadoConservacaos =>
      $$PatrimEstadoConservacaosTableTableManager(
          _db, _db.patrimEstadoConservacaos);
  $$SeguradorasTableTableManager get seguradoras =>
      $$SeguradorasTableTableManager(_db, _db.seguradoras);
  $$PatrimTipoMovimentacaosTableTableManager get patrimTipoMovimentacaos =>
      $$PatrimTipoMovimentacaosTableTableManager(
          _db, _db.patrimTipoMovimentacaos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaFornecedorsTableTableManager get viewPessoaFornecedors =>
      $$ViewPessoaFornecedorsTableTableManager(_db, _db.viewPessoaFornecedors);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
          _db, _db.viewPessoaColaboradors);
}
