import 'package:patrimonio/app/data/provider/api/api_provider_base.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimBemApiProvider extends ApiProviderBase {
  static const _path = '/patrim-bem';

  Future<List<PatrimBemModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PatrimBemModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PatrimBemModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PatrimBemModel.fromJson(json),
    );
  }

  Future<PatrimBemModel?>? insert(PatrimBemModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PatrimBemModel.fromJson(json),
    );
  }

  Future<PatrimBemModel?>? update(PatrimBemModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PatrimBemModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
