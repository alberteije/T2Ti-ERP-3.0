import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_estado_conservacao_repository.dart';

class PatrimEstadoConservacaoController extends ControllerBase<PatrimEstadoConservacaoModel, PatrimEstadoConservacaoRepository> {

  PatrimEstadoConservacaoController({required super.repository}) {
    dbColumns = PatrimEstadoConservacaoModel.dbColumns;
    aliasColumns = PatrimEstadoConservacaoModel.aliasColumns;
    gridColumns = patrimEstadoConservacaoGridColumns();
    functionName = "patrim_estado_conservacao";
    screenTitle = "Estado de Conservação";
  }

  @override
  PatrimEstadoConservacaoModel createNewModel() => PatrimEstadoConservacaoModel();

  @override
  final standardFieldForFilter = PatrimEstadoConservacaoModel.aliasColumns[PatrimEstadoConservacaoModel.dbColumns.indexOf('codigo')];

  final codigoController = CustomDropdownButtonController('1=Novo');
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimEstadoConservacao) => patrimEstadoConservacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.patrimEstadoConservacaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.selected = '1=Novo';
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.patrimEstadoConservacaoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.selected = currentModel.codigo ?? '1=Novo';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(patrimEstadoConservacaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}