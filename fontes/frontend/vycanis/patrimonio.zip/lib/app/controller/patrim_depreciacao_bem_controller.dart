import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

import 'package:patrimonio/app/page/page_imports.dart';
import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimDepreciacaoBemController extends ControllerBase<PatrimDepreciacaoBemModel, void> {

  PatrimDepreciacaoBemController() : super(repository: null) {
    dbColumns = PatrimDepreciacaoBemModel.dbColumns;
    aliasColumns = PatrimDepreciacaoBemModel.aliasColumns;
    gridColumns = patrimDepreciacaoBemGridColumns();
    functionName = "patrim_depreciacao_bem";
    screenTitle = "Depreciação";
  }

  final _patrimDepreciacaoBemModel = PatrimDepreciacaoBemModel().obs;
  PatrimDepreciacaoBemModel get patrimDepreciacaoBemModel => _patrimDepreciacaoBemModel.value;
  set patrimDepreciacaoBemModel(value) => _patrimDepreciacaoBemModel.value = value ?? PatrimDepreciacaoBemModel();

  List<PatrimDepreciacaoBemModel> get patrimDepreciacaoBemModelList => Get.find<PatrimBemController>().currentModel.patrimDepreciacaoBemModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final patrimDepreciacaoBemScaffoldKey = GlobalKey<ScaffoldState>();
  final patrimDepreciacaoBemFormKey = GlobalKey<FormState>();

  @override
  PatrimDepreciacaoBemModel createNewModel() => PatrimDepreciacaoBemModel();

  @override
  final standardFieldForFilter = PatrimDepreciacaoBemModel.aliasColumns[PatrimDepreciacaoBemModel.dbColumns.indexOf('data_depreciacao')];

  final dataDepreciacaoController = DatePickerItemController(null);
  final diasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final taxaController = MoneyMaskedTextController();
  final indiceController = MoneyMaskedTextController();
  final valorController = MoneyMaskedTextController();
  final depreciacaoAcumuladaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_depreciacao'],
    'secondaryColumns': ['dias'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimDepreciacaoBem) => patrimDepreciacaoBem.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(patrimDepreciacaoBemModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    patrimDepreciacaoBemModel = createNewModel();
    _resetForm();
    Get.to(() => PatrimDepreciacaoBemEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataDepreciacaoController.date = null;
    diasController.updateValue(0);
    taxaController.updateValue(0);
    indiceController.updateValue(0);
    valorController.updateValue(0);
    depreciacaoAcumuladaController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = patrimDepreciacaoBemModelList.firstWhere((m) => m.tempId == tempId);
    patrimDepreciacaoBemModel = model.clone();
		patrimDepreciacaoBemModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PatrimDepreciacaoBemEditPage());
  }

  void updateControllersFromModel() {
    dataDepreciacaoController.date = patrimDepreciacaoBemModel.dataDepreciacao;
    diasController.updateValue((patrimDepreciacaoBemModel.dias ?? 0).toDouble());
    taxaController.updateValue(patrimDepreciacaoBemModel.taxa ?? 0);
    indiceController.updateValue(patrimDepreciacaoBemModel.indice ?? 0);
    valorController.updateValue(patrimDepreciacaoBemModel.valor ?? 0);
    depreciacaoAcumuladaController.updateValue(patrimDepreciacaoBemModel.depreciacaoAcumulada ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!patrimDepreciacaoBemFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        patrimDepreciacaoBemModelList.insert(0, patrimDepreciacaoBemModel.clone());
      } else {
        final index = patrimDepreciacaoBemModelList.indexWhere((m) => m.tempId == patrimDepreciacaoBemModel.tempId);
        if (index >= 0) {
          patrimDepreciacaoBemModelList[index] = patrimDepreciacaoBemModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      patrimDepreciacaoBemModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataDepreciacaoController.dispose();
    diasController.dispose();
    taxaController.dispose();
    indiceController.dispose();
    valorController.dispose();
    depreciacaoAcumuladaController.dispose();
  }

}