import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_grupo_bem_repository.dart';

class PatrimGrupoBemController extends ControllerBase<PatrimGrupoBemModel, PatrimGrupoBemRepository> {

  PatrimGrupoBemController({required super.repository}) {
    dbColumns = PatrimGrupoBemModel.dbColumns;
    aliasColumns = PatrimGrupoBemModel.aliasColumns;
    gridColumns = patrimGrupoBemGridColumns();
    functionName = "patrim_grupo_bem";
    screenTitle = "Grupo";
  }

  @override
  PatrimGrupoBemModel createNewModel() => PatrimGrupoBemModel();

  @override
  final standardFieldForFilter = PatrimGrupoBemModel.aliasColumns[PatrimGrupoBemModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final contaAtivoImobilizadoController = TextEditingController();
  final contaDepreciacaoAcumuladaController = TextEditingController();
  final contaDespesaDepreciacaoController = TextEditingController();
  final codigoHistoricoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimGrupoBem) => patrimGrupoBem.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.patrimGrupoBemEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    contaAtivoImobilizadoController.text = '';
    contaDepreciacaoAcumuladaController.text = '';
    contaDespesaDepreciacaoController.text = '';
    codigoHistoricoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.patrimGrupoBemEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    contaAtivoImobilizadoController.text = currentModel.contaAtivoImobilizado ?? '';
    contaDepreciacaoAcumuladaController.text = currentModel.contaDepreciacaoAcumulada ?? '';
    contaDespesaDepreciacaoController.text = currentModel.contaDespesaDepreciacao ?? '';
    codigoHistoricoController.updateValue((currentModel.codigoHistorico ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(patrimGrupoBemModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    contaAtivoImobilizadoController.dispose();
    contaDepreciacaoAcumuladaController.dispose();
    contaDespesaDepreciacaoController.dispose();
    codigoHistoricoController.dispose();
    super.onClose();
  }

}