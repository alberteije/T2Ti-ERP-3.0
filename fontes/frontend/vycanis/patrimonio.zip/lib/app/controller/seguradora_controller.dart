import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/seguradora_repository.dart';

class SeguradoraController extends ControllerBase<SeguradoraModel, SeguradoraRepository> {

  SeguradoraController({required super.repository}) {
    dbColumns = SeguradoraModel.dbColumns;
    aliasColumns = SeguradoraModel.aliasColumns;
    gridColumns = seguradoraGridColumns();
    functionName = "seguradora";
    screenTitle = "Seguradora";
  }

  @override
  SeguradoraModel createNewModel() => SeguradoraModel();

  @override
  final standardFieldForFilter = SeguradoraModel.aliasColumns[SeguradoraModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final contatoController = TextEditingController();
  final telefoneController = MaskedTextController(mask: '(00)00000-0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['contato'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((seguradora) => seguradora.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.seguradoraEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    contatoController.text = '';
    telefoneController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.seguradoraEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    contatoController.text = currentModel.contato ?? '';
    telefoneController.text = currentModel.telefone ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(seguradoraModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    contatoController.dispose();
    telefoneController.dispose();
    super.onClose();
  }

}