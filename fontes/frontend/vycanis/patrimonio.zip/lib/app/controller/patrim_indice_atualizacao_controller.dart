import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_indice_atualizacao_repository.dart';

class PatrimIndiceAtualizacaoController extends ControllerBase<PatrimIndiceAtualizacaoModel, PatrimIndiceAtualizacaoRepository> {

  PatrimIndiceAtualizacaoController({required super.repository}) {
    dbColumns = PatrimIndiceAtualizacaoModel.dbColumns;
    aliasColumns = PatrimIndiceAtualizacaoModel.aliasColumns;
    gridColumns = patrimIndiceAtualizacaoGridColumns();
    functionName = "patrim_indice_atualizacao";
    screenTitle = "Índices de Atualização";
  }

  @override
  PatrimIndiceAtualizacaoModel createNewModel() => PatrimIndiceAtualizacaoModel();

  @override
  final standardFieldForFilter = PatrimIndiceAtualizacaoModel.aliasColumns[PatrimIndiceAtualizacaoModel.dbColumns.indexOf('data_indice')];

  final dataIndiceController = DatePickerItemController(null);
  final nomeController = TextEditingController();
  final valorController = MoneyMaskedTextController();
  final valorAlternativoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_indice'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimIndiceAtualizacao) => patrimIndiceAtualizacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.patrimIndiceAtualizacaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataIndiceController.date = null;
    nomeController.text = '';
    valorController.updateValue(0);
    valorAlternativoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.patrimIndiceAtualizacaoEditPage);
  }

  void updateControllersFromModel() {
    dataIndiceController.date = currentModel.dataIndice;
    nomeController.text = currentModel.nome ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    valorAlternativoController.updateValue(currentModel.valorAlternativo ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(patrimIndiceAtualizacaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    dataIndiceController.dispose();
    nomeController.dispose();
    valorController.dispose();
    valorAlternativoController.dispose();
    super.onClose();
  }

}