import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';

import 'package:patrimonio/app/page/page_imports.dart';
import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimMovimentacaoBemController extends ControllerBase<PatrimMovimentacaoBemModel, void> {

  PatrimMovimentacaoBemController() : super(repository: null) {
    dbColumns = PatrimMovimentacaoBemModel.dbColumns;
    aliasColumns = PatrimMovimentacaoBemModel.aliasColumns;
    gridColumns = patrimMovimentacaoBemGridColumns();
    functionName = "patrim_movimentacao_bem";
    screenTitle = "Movimentação";
  }

  final _patrimMovimentacaoBemModel = PatrimMovimentacaoBemModel().obs;
  PatrimMovimentacaoBemModel get patrimMovimentacaoBemModel => _patrimMovimentacaoBemModel.value;
  set patrimMovimentacaoBemModel(value) => _patrimMovimentacaoBemModel.value = value ?? PatrimMovimentacaoBemModel();

  List<PatrimMovimentacaoBemModel> get patrimMovimentacaoBemModelList => Get.find<PatrimBemController>().currentModel.patrimMovimentacaoBemModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final patrimMovimentacaoBemScaffoldKey = GlobalKey<ScaffoldState>();
  final patrimMovimentacaoBemFormKey = GlobalKey<FormState>();

  @override
  PatrimMovimentacaoBemModel createNewModel() => PatrimMovimentacaoBemModel();

  @override
  final standardFieldForFilter = PatrimMovimentacaoBemModel.aliasColumns[PatrimMovimentacaoBemModel.dbColumns.indexOf('data_movimentacao')];

  final patrimTipoMovimentacaoModelController = TextEditingController();
  final dataMovimentacaoController = DatePickerItemController(null);
  final responsavelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_movimentacao'],
    'secondaryColumns': ['responsavel'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimMovimentacaoBem) => patrimMovimentacaoBem.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(patrimMovimentacaoBemModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    patrimMovimentacaoBemModel = createNewModel();
    _resetForm();
    Get.to(() => PatrimMovimentacaoBemEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    patrimTipoMovimentacaoModelController.text = '';
    dataMovimentacaoController.date = null;
    responsavelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = patrimMovimentacaoBemModelList.firstWhere((m) => m.tempId == tempId);
    patrimMovimentacaoBemModel = model.clone();
		patrimMovimentacaoBemModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PatrimMovimentacaoBemEditPage());
  }

  void updateControllersFromModel() {
    patrimTipoMovimentacaoModelController.text = patrimMovimentacaoBemModel.patrimTipoMovimentacaoModel?.nome?.toString() ?? '';
    dataMovimentacaoController.date = patrimMovimentacaoBemModel.dataMovimentacao;
    responsavelController.text = patrimMovimentacaoBemModel.responsavel ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!patrimMovimentacaoBemFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        patrimMovimentacaoBemModelList.insert(0, patrimMovimentacaoBemModel.clone());
      } else {
        final index = patrimMovimentacaoBemModelList.indexWhere((m) => m.tempId == patrimMovimentacaoBemModel.tempId);
        if (index >= 0) {
          patrimMovimentacaoBemModelList[index] = patrimMovimentacaoBemModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callPatrimTipoMovimentacaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Movimentacao]'; 
		lookupController.route = '/patrim-tipo-movimentacao/'; 
		lookupController.gridColumns = patrimTipoMovimentacaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PatrimTipoMovimentacaoModel.aliasColumns; 
		lookupController.dbColumns = PatrimTipoMovimentacaoModel.dbColumns; 
		lookupController.standardColumn = PatrimTipoMovimentacaoModel.aliasColumns[PatrimTipoMovimentacaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			patrimMovimentacaoBemModel.idPatrimTipoMovimentacao = plutoRowResult.cells['id']!.value; 
			patrimMovimentacaoBemModel.patrimTipoMovimentacaoModel = PatrimTipoMovimentacaoModel.fromPlutoRow(plutoRowResult); 
			patrimTipoMovimentacaoModelController.text = patrimMovimentacaoBemModel.patrimTipoMovimentacaoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      patrimMovimentacaoBemModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    patrimTipoMovimentacaoModelController.dispose();
    dataMovimentacaoController.dispose();
    responsavelController.dispose();
  }

}