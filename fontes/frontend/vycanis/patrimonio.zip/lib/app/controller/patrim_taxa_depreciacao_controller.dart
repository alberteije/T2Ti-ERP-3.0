import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_taxa_depreciacao_repository.dart';

class PatrimTaxaDepreciacaoController extends ControllerBase<PatrimTaxaDepreciacaoModel, PatrimTaxaDepreciacaoRepository> {

  PatrimTaxaDepreciacaoController({required super.repository}) {
    dbColumns = PatrimTaxaDepreciacaoModel.dbColumns;
    aliasColumns = PatrimTaxaDepreciacaoModel.aliasColumns;
    gridColumns = patrimTaxaDepreciacaoGridColumns();
    functionName = "patrim_taxa_depreciacao";
    screenTitle = "Taxas de Depreciação";
  }

  @override
  PatrimTaxaDepreciacaoModel createNewModel() => PatrimTaxaDepreciacaoModel();

  @override
  final standardFieldForFilter = PatrimTaxaDepreciacaoModel.aliasColumns[PatrimTaxaDepreciacaoModel.dbColumns.indexOf('ncm')];

  final ncmController = TextEditingController();
  final bemController = TextEditingController();
  final vidaController = MoneyMaskedTextController();
  final taxaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['ncm'],
    'secondaryColumns': ['bem'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimTaxaDepreciacao) => patrimTaxaDepreciacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.patrimTaxaDepreciacaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    ncmController.text = '';
    bemController.text = '';
    vidaController.updateValue(0);
    taxaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.patrimTaxaDepreciacaoEditPage);
  }

  void updateControllersFromModel() {
    ncmController.text = currentModel.ncm ?? '';
    bemController.text = currentModel.bem ?? '';
    vidaController.updateValue(currentModel.vida ?? 0);
    taxaController.updateValue(currentModel.taxa ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(patrimTaxaDepreciacaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    ncmController.dispose();
    bemController.dispose();
    vidaController.dispose();
    taxaController.dispose();
    super.onClose();
  }

}