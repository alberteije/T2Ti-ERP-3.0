import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:patrimonio/app/page/page_imports.dart';
import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_bem_repository.dart';

class PatrimBemController extends ControllerBase<PatrimBemModel, PatrimBemRepository> 
with GetSingleTickerProviderStateMixin {

  PatrimBemController({required super.repository}) {
    dbColumns = PatrimBemModel.dbColumns;
    aliasColumns = PatrimBemModel.aliasColumns;
    gridColumns = patrimBemGridColumns();
    functionName = "patrim_bem";
    screenTitle = "Bem";
  }

  final patrimBemScaffoldKey = GlobalKey<ScaffoldState>();
  final patrimBemTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final patrimBemFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PatrimBemModel createNewModel() => PatrimBemModel();

  @override
  final standardFieldForFilter = PatrimBemModel.aliasColumns[PatrimBemModel.dbColumns.indexOf('numero_nb')];

  final centroResultadoModelController = TextEditingController();
  final viewPessoaFornecedorModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final patrimTipoAquisicaoBemModelController = TextEditingController();
  final patrimEstadoConservacaoModelController = TextEditingController();
  final patrimGrupoBemModelController = TextEditingController();
  final setorModelController = TextEditingController();
  final numeroNbController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final dataAquisicaoController = DatePickerItemController(null);
  final dataAceiteController = DatePickerItemController(null);
  final dataCadastroController = DatePickerItemController(null);
  final dataContabilizadoController = DatePickerItemController(null);
  final dataVistoriaController = DatePickerItemController(null);
  final dataMarcacaoController = DatePickerItemController(null);
  final dataBaixaController = DatePickerItemController(null);
  final vencimentoGarantiaController = DatePickerItemController(null);
  final numeroNotaFiscalController = TextEditingController();
  final numeroSerieController = TextEditingController();
  final chaveNfeController = TextEditingController();
  final valorOriginalController = MoneyMaskedTextController();
  final valorCompraController = MoneyMaskedTextController();
  final valorAtualizadoController = MoneyMaskedTextController();
  final valorBaixaController = MoneyMaskedTextController();
  final depreciaController = CustomDropdownButtonController('Sim');
  final metodoDepreciacaoController = CustomDropdownButtonController('1=Linear');
  final inicioDepreciacaoController = DatePickerItemController(null);
  final ultimaDepreciacaoController = DatePickerItemController(null);
  final tipoDepreciacaoController = CustomDropdownButtonController('Normal');
  final taxaAnualDepreciacaoController = MoneyMaskedTextController();
  final taxaMensalDepreciacaoController = MoneyMaskedTextController();
  final taxaDepreciacaoAceleradaController = MoneyMaskedTextController();
  final taxaDepreciacaoIncentivadaController = MoneyMaskedTextController();
  final funcaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_nb'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimBem) => patrimBem.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.patrimBemTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    centroResultadoModelController.text = '';
    viewPessoaFornecedorModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    patrimTipoAquisicaoBemModelController.text = '';
    patrimEstadoConservacaoModelController.text = '';
    patrimGrupoBemModelController.text = '';
    setorModelController.text = '';
    numeroNbController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    dataAquisicaoController.date = null;
    dataAceiteController.date = null;
    dataCadastroController.date = null;
    dataContabilizadoController.date = null;
    dataVistoriaController.date = null;
    dataMarcacaoController.date = null;
    dataBaixaController.date = null;
    vencimentoGarantiaController.date = null;
    numeroNotaFiscalController.text = '';
    numeroSerieController.text = '';
    chaveNfeController.text = '';
    valorOriginalController.updateValue(0);
    valorCompraController.updateValue(0);
    valorAtualizadoController.updateValue(0);
    valorBaixaController.updateValue(0);
    depreciaController.selected = 'Sim';
    metodoDepreciacaoController.selected = '1=Linear';
    inicioDepreciacaoController.date = null;
    ultimaDepreciacaoController.date = null;
    tipoDepreciacaoController.selected = 'Normal';
    taxaAnualDepreciacaoController.updateValue(0);
    taxaMensalDepreciacaoController.updateValue(0);
    taxaDepreciacaoAceleradaController.updateValue(0);
    taxaDepreciacaoIncentivadaController.updateValue(0);
    funcaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.patrimBemTabPage);
  }

  _configureChildrenControllers() {
    //Documentos
		Get.put<PatrimDocumentoBemController>(PatrimDocumentoBemController()); 

    //Depreciação
		Get.put<PatrimDepreciacaoBemController>(PatrimDepreciacaoBemController()); 

    //Movimentação
		Get.put<PatrimMovimentacaoBemController>(PatrimMovimentacaoBemController()); 

    //Apólices
		Get.put<PatrimApoliceSeguroController>(PatrimApoliceSeguroController()); 

  }
	
	_releaseChildrenControllers() {
    //Documentos
		Get.delete<PatrimDocumentoBemController>(); 

    //Depreciação
		Get.delete<PatrimDepreciacaoBemController>(); 

    //Movimentação
		Get.delete<PatrimMovimentacaoBemController>(); 

    //Apólices
		Get.delete<PatrimApoliceSeguroController>(); 

	}
  
  void updateControllersFromModel() {
    centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao?.toString() ?? '';
    viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    patrimTipoAquisicaoBemModelController.text = currentModel.patrimTipoAquisicaoBemModel?.nome?.toString() ?? '';
    patrimEstadoConservacaoModelController.text = currentModel.patrimEstadoConservacaoModel?.nome?.toString() ?? '';
    patrimGrupoBemModelController.text = currentModel.patrimGrupoBemModel?.nome?.toString() ?? '';
    setorModelController.text = currentModel.setorModel?.nome?.toString() ?? '';
    numeroNbController.text = currentModel.numeroNb ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    dataAquisicaoController.date = currentModel.dataAquisicao;
    dataAceiteController.date = currentModel.dataAceite;
    dataCadastroController.date = currentModel.dataCadastro;
    dataContabilizadoController.date = currentModel.dataContabilizado;
    dataVistoriaController.date = currentModel.dataVistoria;
    dataMarcacaoController.date = currentModel.dataMarcacao;
    dataBaixaController.date = currentModel.dataBaixa;
    vencimentoGarantiaController.date = currentModel.vencimentoGarantia;
    numeroNotaFiscalController.text = currentModel.numeroNotaFiscal ?? '';
    numeroSerieController.text = currentModel.numeroSerie ?? '';
    chaveNfeController.text = currentModel.chaveNfe ?? '';
    valorOriginalController.updateValue(currentModel.valorOriginal ?? 0);
    valorCompraController.updateValue(currentModel.valorCompra ?? 0);
    valorAtualizadoController.updateValue(currentModel.valorAtualizado ?? 0);
    valorBaixaController.updateValue(currentModel.valorBaixa ?? 0);
    depreciaController.selected = currentModel.deprecia ?? 'Sim';
    metodoDepreciacaoController.selected = currentModel.metodoDepreciacao ?? '1=Linear';
    inicioDepreciacaoController.date = currentModel.inicioDepreciacao;
    ultimaDepreciacaoController.date = currentModel.ultimaDepreciacao;
    tipoDepreciacaoController.selected = currentModel.tipoDepreciacao ?? 'Normal';
    taxaAnualDepreciacaoController.updateValue(currentModel.taxaAnualDepreciacao ?? 0);
    taxaMensalDepreciacaoController.updateValue(currentModel.taxaMensalDepreciacao ?? 0);
    taxaDepreciacaoAceleradaController.updateValue(currentModel.taxaDepreciacaoAcelerada ?? 0);
    taxaDepreciacaoIncentivadaController.updateValue(currentModel.taxaDepreciacaoIncentivada ?? 0);
    funcaoController.text = currentModel.funcao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Documentos
		final patrimDocumentoBemController = Get.find<PatrimDocumentoBemController>(); 
		patrimDocumentoBemController.userMadeChanges = false; 

    //Depreciação
		final patrimDepreciacaoBemController = Get.find<PatrimDepreciacaoBemController>(); 
		patrimDepreciacaoBemController.userMadeChanges = false; 

    //Movimentação
		final patrimMovimentacaoBemController = Get.find<PatrimMovimentacaoBemController>(); 
		patrimMovimentacaoBemController.userMadeChanges = false; 

    //Apólices
		final patrimApoliceSeguroController = Get.find<PatrimApoliceSeguroController>(); 
		patrimApoliceSeguroController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(patrimBemModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Centro Resultado]'; 
		lookupController.route = '/centro-resultado/'; 
		lookupController.gridColumns = centroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = CentroResultadoModel.dbColumns; 
		lookupController.standardColumn = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.centroResultadoModel = CentroResultadoModel.fromPlutoRow(plutoRowResult); 
			centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaFornecedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Fornecedor]'; 
		lookupController.route = '/view-pessoa-fornecedor/'; 
		lookupController.gridColumns = viewPessoaFornecedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaFornecedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaFornecedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaFornecedorModel.aliasColumns[ViewPessoaFornecedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFornecedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaFornecedorModel = ViewPessoaFornecedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callPatrimTipoAquisicaoBemLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Aquisicao]'; 
		lookupController.route = '/patrim-tipo-aquisicao-bem/'; 
		lookupController.gridColumns = patrimTipoAquisicaoBemGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PatrimTipoAquisicaoBemModel.aliasColumns; 
		lookupController.dbColumns = PatrimTipoAquisicaoBemModel.dbColumns; 
		lookupController.standardColumn = PatrimTipoAquisicaoBemModel.aliasColumns[PatrimTipoAquisicaoBemModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPatrimTipoAquisicaoBem = plutoRowResult.cells['id']!.value; 
			currentModel.patrimTipoAquisicaoBemModel = PatrimTipoAquisicaoBemModel.fromPlutoRow(plutoRowResult); 
			patrimTipoAquisicaoBemModelController.text = currentModel.patrimTipoAquisicaoBemModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callPatrimEstadoConservacaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Estado Conservacao]'; 
		lookupController.route = '/patrim-estado-conservacao/'; 
		lookupController.gridColumns = patrimEstadoConservacaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PatrimEstadoConservacaoModel.aliasColumns; 
		lookupController.dbColumns = PatrimEstadoConservacaoModel.dbColumns; 
		lookupController.standardColumn = PatrimEstadoConservacaoModel.aliasColumns[PatrimEstadoConservacaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPatrimEstadoConservacao = plutoRowResult.cells['id']!.value; 
			currentModel.patrimEstadoConservacaoModel = PatrimEstadoConservacaoModel.fromPlutoRow(plutoRowResult); 
			patrimEstadoConservacaoModelController.text = currentModel.patrimEstadoConservacaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callPatrimGrupoBemLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Grupo]'; 
		lookupController.route = '/patrim-grupo-bem/'; 
		lookupController.gridColumns = patrimGrupoBemGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PatrimGrupoBemModel.aliasColumns; 
		lookupController.dbColumns = PatrimGrupoBemModel.dbColumns; 
		lookupController.standardColumn = PatrimGrupoBemModel.aliasColumns[PatrimGrupoBemModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPatrimGrupoBem = plutoRowResult.cells['id']!.value; 
			currentModel.patrimGrupoBemModel = PatrimGrupoBemModel.fromPlutoRow(plutoRowResult); 
			patrimGrupoBemModelController.text = currentModel.patrimGrupoBemModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callSetorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Setor]'; 
		lookupController.route = '/setor/'; 
		lookupController.gridColumns = setorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = SetorModel.aliasColumns; 
		lookupController.dbColumns = SetorModel.dbColumns; 
		lookupController.standardColumn = SetorModel.aliasColumns[SetorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idSetor = plutoRowResult.cells['id']!.value; 
			currentModel.setorModel = SetorModel.fromPlutoRow(plutoRowResult); 
			setorModelController.text = currentModel.setorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Bem', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Documentos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Depreciação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Movimentação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Apólices', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PatrimBemEditPage(),
      const PatrimDocumentoBemListPage(),
      const PatrimDepreciacaoBemListPage(),
      const PatrimMovimentacaoBemListPage(),
      const PatrimApoliceSeguroListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PatrimDocumentoBemController>().userMadeChanges
    || 
		Get.find<PatrimDepreciacaoBemController>().userMadeChanges
    || 
		Get.find<PatrimMovimentacaoBemController>().userMadeChanges
    || 
		Get.find<PatrimApoliceSeguroController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.centroResultadoModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Centro Resultado]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaFornecedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Fornecedor]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.patrimTipoAquisicaoBemModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Aquisicao]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.patrimEstadoConservacaoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Estado Conservacao]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.patrimGrupoBemModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Grupo]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.setorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Setor]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    centroResultadoModelController.dispose();
    viewPessoaFornecedorModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    patrimTipoAquisicaoBemModelController.dispose();
    patrimEstadoConservacaoModelController.dispose();
    patrimGrupoBemModelController.dispose();
    setorModelController.dispose();
    numeroNbController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    dataAquisicaoController.dispose();
    dataAceiteController.dispose();
    dataCadastroController.dispose();
    dataContabilizadoController.dispose();
    dataVistoriaController.dispose();
    dataMarcacaoController.dispose();
    dataBaixaController.dispose();
    vencimentoGarantiaController.dispose();
    numeroNotaFiscalController.dispose();
    numeroSerieController.dispose();
    chaveNfeController.dispose();
    valorOriginalController.dispose();
    valorCompraController.dispose();
    valorAtualizadoController.dispose();
    valorBaixaController.dispose();
    depreciaController.dispose();
    metodoDepreciacaoController.dispose();
    inicioDepreciacaoController.dispose();
    ultimaDepreciacaoController.dispose();
    tipoDepreciacaoController.dispose();
    taxaAnualDepreciacaoController.dispose();
    taxaMensalDepreciacaoController.dispose();
    taxaDepreciacaoAceleradaController.dispose();
    taxaDepreciacaoIncentivadaController.dispose();
    funcaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}