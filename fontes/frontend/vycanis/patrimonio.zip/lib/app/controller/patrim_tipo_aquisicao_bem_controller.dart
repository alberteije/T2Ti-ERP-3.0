import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';
import 'package:patrimonio/app/data/repository/patrim_tipo_aquisicao_bem_repository.dart';

class PatrimTipoAquisicaoBemController extends ControllerBase<PatrimTipoAquisicaoBemModel, PatrimTipoAquisicaoBemRepository> {

  PatrimTipoAquisicaoBemController({required super.repository}) {
    dbColumns = PatrimTipoAquisicaoBemModel.dbColumns;
    aliasColumns = PatrimTipoAquisicaoBemModel.aliasColumns;
    gridColumns = patrimTipoAquisicaoBemGridColumns();
    functionName = "patrim_tipo_aquisicao_bem";
    screenTitle = "Tipo Aquisição Bem";
  }

  @override
  PatrimTipoAquisicaoBemModel createNewModel() => PatrimTipoAquisicaoBemModel();

  @override
  final standardFieldForFilter = PatrimTipoAquisicaoBemModel.aliasColumns[PatrimTipoAquisicaoBemModel.dbColumns.indexOf('tipo')];

  final tipoController = CustomDropdownButtonController('1=Compra');
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimTipoAquisicaoBem) => patrimTipoAquisicaoBem.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.patrimTipoAquisicaoBemEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    tipoController.selected = '1=Compra';
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.patrimTipoAquisicaoBemEditPage);
  }

  void updateControllersFromModel() {
    tipoController.selected = currentModel.tipo ?? '1=Compra';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(patrimTipoAquisicaoBemModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    tipoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}