import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';
import 'package:patrimonio/app/routes/app_routes.dart';

import 'package:patrimonio/app/page/page_imports.dart';
import 'package:patrimonio/app/page/shared_widget/message_dialog.dart';
import 'package:patrimonio/app/page/grid_columns/grid_columns_imports.dart';
import 'package:patrimonio/app/controller/controller_imports.dart';
import 'package:patrimonio/app/data/model/model_imports.dart';

class PatrimApoliceSeguroController extends ControllerBase<PatrimApoliceSeguroModel, void> {

  PatrimApoliceSeguroController() : super(repository: null) {
    dbColumns = PatrimApoliceSeguroModel.dbColumns;
    aliasColumns = PatrimApoliceSeguroModel.aliasColumns;
    gridColumns = patrimApoliceSeguroGridColumns();
    functionName = "patrim_apolice_seguro";
    screenTitle = "Apólices";
  }

  final _patrimApoliceSeguroModel = PatrimApoliceSeguroModel().obs;
  PatrimApoliceSeguroModel get patrimApoliceSeguroModel => _patrimApoliceSeguroModel.value;
  set patrimApoliceSeguroModel(value) => _patrimApoliceSeguroModel.value = value ?? PatrimApoliceSeguroModel();

  List<PatrimApoliceSeguroModel> get patrimApoliceSeguroModelList => Get.find<PatrimBemController>().currentModel.patrimApoliceSeguroModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final patrimApoliceSeguroScaffoldKey = GlobalKey<ScaffoldState>();
  final patrimApoliceSeguroFormKey = GlobalKey<FormState>();

  @override
  PatrimApoliceSeguroModel createNewModel() => PatrimApoliceSeguroModel();

  @override
  final standardFieldForFilter = PatrimApoliceSeguroModel.aliasColumns[PatrimApoliceSeguroModel.dbColumns.indexOf('numero')];

  final seguradoraModelController = TextEditingController();
  final numeroController = TextEditingController();
  final dataContratacaoController = DatePickerItemController(null);
  final dataVencimentoController = DatePickerItemController(null);
  final valorPremioController = MoneyMaskedTextController();
  final valorSeguradoController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();
  final imagemController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['data_contratacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((patrimApoliceSeguro) => patrimApoliceSeguro.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(patrimApoliceSeguroModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    patrimApoliceSeguroModel = createNewModel();
    _resetForm();
    Get.to(() => PatrimApoliceSeguroEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    seguradoraModelController.text = '';
    numeroController.text = '';
    dataContratacaoController.date = null;
    dataVencimentoController.date = null;
    valorPremioController.updateValue(0);
    valorSeguradoController.updateValue(0);
    observacaoController.text = '';
    imagemController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = patrimApoliceSeguroModelList.firstWhere((m) => m.tempId == tempId);
    patrimApoliceSeguroModel = model.clone();
		patrimApoliceSeguroModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PatrimApoliceSeguroEditPage());
  }

  void updateControllersFromModel() {
    seguradoraModelController.text = patrimApoliceSeguroModel.seguradoraModel?.nome?.toString() ?? '';
    numeroController.text = patrimApoliceSeguroModel.numero ?? '';
    dataContratacaoController.date = patrimApoliceSeguroModel.dataContratacao;
    dataVencimentoController.date = patrimApoliceSeguroModel.dataVencimento;
    valorPremioController.updateValue(patrimApoliceSeguroModel.valorPremio ?? 0);
    valorSeguradoController.updateValue(patrimApoliceSeguroModel.valorSegurado ?? 0);
    observacaoController.text = patrimApoliceSeguroModel.observacao ?? '';
    imagemController.text = patrimApoliceSeguroModel.imagem ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!patrimApoliceSeguroFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        patrimApoliceSeguroModelList.insert(0, patrimApoliceSeguroModel.clone());
      } else {
        final index = patrimApoliceSeguroModelList.indexWhere((m) => m.tempId == patrimApoliceSeguroModel.tempId);
        if (index >= 0) {
          patrimApoliceSeguroModelList[index] = patrimApoliceSeguroModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callSeguradoraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Seguradora]'; 
		lookupController.route = '/seguradora/'; 
		lookupController.gridColumns = seguradoraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = SeguradoraModel.aliasColumns; 
		lookupController.dbColumns = SeguradoraModel.dbColumns; 
		lookupController.standardColumn = SeguradoraModel.aliasColumns[SeguradoraModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			patrimApoliceSeguroModel.idSeguradora = plutoRowResult.cells['id']!.value; 
			patrimApoliceSeguroModel.seguradoraModel = SeguradoraModel.fromPlutoRow(plutoRowResult); 
			seguradoraModelController.text = patrimApoliceSeguroModel.seguradoraModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      patrimApoliceSeguroModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    seguradoraModelController.dispose();
    numeroController.dispose();
    dataContratacaoController.dispose();
    dataVencimentoController.dispose();
    valorPremioController.dispose();
    valorSeguradoController.dispose();
    observacaoController.dispose();
    imagemController.dispose();
  }

}