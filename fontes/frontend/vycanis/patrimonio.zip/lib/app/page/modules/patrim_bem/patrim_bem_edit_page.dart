import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:patrimonio/app/page/shared_widget/shared_widget_imports.dart';
import 'package:patrimonio/app/data/domain/domain_imports.dart';
import 'package:patrimonio/app/controller/patrim_bem_controller.dart';
import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:patrimonio/app/page/shared_widget/input/input_imports.dart';

class PatrimBemEditPage extends StatelessWidget {
	PatrimBemEditPage({Key? key}) : super(key: key);
	final patrimBemController = Get.find<PatrimBemController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: patrimBemController.patrimBemScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: patrimBemController.patrimBemFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: patrimBemController.scrollController,
							child: SingleChildScrollView(
								controller: patrimBemController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.centroResultadoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Centro Resultado',
																			labelText: 'Centro Resultado *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callCentroResultadoLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.viewPessoaFornecedorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Formecedor',
																			labelText: 'Fornecedor *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callViewPessoaFornecedorLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.viewPessoaColaboradorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Colaborador',
																			labelText: 'Colaborador *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callViewPessoaColaboradorLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.patrimTipoAquisicaoBemModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Tipo Aquisicao',
																			labelText: 'Tipo Aquisicao *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callPatrimTipoAquisicaoBemLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.patrimEstadoConservacaoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Estado Conservacao',
																			labelText: 'Estado Conservacao *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callPatrimEstadoConservacaoLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.patrimGrupoBemModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Grupo',
																			labelText: 'Grupo *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callPatrimGrupoBemLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: patrimBemController.setorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Setor',
																			labelText: 'Setor *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: patrimBemController.callSetorLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: patrimBemController.numeroNbController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Bem',
																labelText: 'Numero Bem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.numeroNb = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: patrimBemController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.nome = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: patrimBemController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.descricao = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Aquisicao',
																labelText: 'Data Aquisicao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataAquisicaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataAquisicao = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Aceite',
																labelText: 'Data Aceite',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataAceiteController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataAceite = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Cadastro',
																labelText: 'Data Cadastro',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataCadastroController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataCadastro = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Contabilizado',
																labelText: 'Data Contabilizado',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataContabilizadoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataContabilizado = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Vistoria',
																labelText: 'Data Vistoria',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataVistoriaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataVistoria = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Marcacao',
																labelText: 'Data Marcacao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataMarcacaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataMarcacao = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Baixa',
																labelText: 'Data Baixa',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.dataBaixaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.dataBaixa = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Vencimento Garantia',
																labelText: 'Vencimento Garantia',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.vencimentoGarantiaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.vencimentoGarantia = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 50,
															controller: patrimBemController.numeroNotaFiscalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Nota Fiscal',
																labelText: 'Numero Nota Fiscal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.numeroNotaFiscal = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 50,
															controller: patrimBemController.numeroSerieController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Serie',
																labelText: 'Numero Serie',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.numeroSerie = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: patrimBemController.chaveNfeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Nfe',
																labelText: 'Chave Nfe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.chaveNfe = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.valorOriginalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Original',
																labelText: 'Valor Original',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.valorOriginal = patrimBemController.valorOriginalController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.valorCompraController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Compra',
																labelText: 'Valor Compra',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.valorCompra = patrimBemController.valorCompraController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.valorAtualizadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Atualizado',
																labelText: 'Valor Atualizado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.valorAtualizado = patrimBemController.valorAtualizadoController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.valorBaixaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Baixa',
																labelText: 'Valor Baixa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.valorBaixa = patrimBemController.valorBaixaController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: patrimBemController.depreciaController,
															labelText: 'Deprecia',
															hintText: 'Informe os dados para o campo Deprecia',
															items: PatrimBemDomain.depreciaListDropdown,
															onChanged: (dynamic newValue) {
																patrimBemController.currentModel.deprecia = newValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: patrimBemController.metodoDepreciacaoController,
															labelText: 'Metodo Depreciacao',
															hintText: 'Informe os dados para o campo Metodo Depreciacao',
															items: PatrimBemDomain.metodoDepreciacaoListDropdown,
															onChanged: (dynamic newValue) {
																patrimBemController.currentModel.metodoDepreciacao = newValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Inicio Depreciacao',
																labelText: 'Inicio Depreciacao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.inicioDepreciacaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.inicioDepreciacao = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Ultima Depreciacao',
																labelText: 'Ultima Depreciacao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: patrimBemController.ultimaDepreciacaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	patrimBemController.currentModel.ultimaDepreciacao = value;
																	patrimBemController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: patrimBemController.tipoDepreciacaoController,
															labelText: 'Tipo Depreciacao',
															hintText: 'Informe os dados para o campo Tipo Depreciacao',
															items: PatrimBemDomain.tipoDepreciacaoListDropdown,
															onChanged: (dynamic newValue) {
																patrimBemController.currentModel.tipoDepreciacao = newValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.taxaAnualDepreciacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Anual Depreciacao',
																labelText: 'Taxa Anual Depreciacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.taxaAnualDepreciacao = patrimBemController.taxaAnualDepreciacaoController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.taxaMensalDepreciacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Mensal Depreciacao',
																labelText: 'Taxa Mensal Depreciacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.taxaMensalDepreciacao = patrimBemController.taxaMensalDepreciacaoController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.taxaDepreciacaoAceleradaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Depreciacao Acelerada',
																labelText: 'Taxa Depreciacao Acelerada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.taxaDepreciacaoAcelerada = patrimBemController.taxaDepreciacaoAceleradaController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: patrimBemController.taxaDepreciacaoIncentivadaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Taxa Depreciacao Incentivada',
																labelText: 'Taxa Depreciacao Incentivada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.taxaDepreciacaoIncentivada = patrimBemController.taxaDepreciacaoIncentivadaController.numberValue;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: patrimBemController.funcaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Funcao',
																labelText: 'Funcao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																patrimBemController.currentModel.funcao = text;
																patrimBemController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
