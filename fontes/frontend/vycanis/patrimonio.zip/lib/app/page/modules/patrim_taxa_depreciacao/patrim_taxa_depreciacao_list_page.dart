import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:patrimonio/app/page/responsive_list_view.dart';
import 'package:patrimonio/app/controller/patrim_taxa_depreciacao_controller.dart';
import 'package:patrimonio/app/infra/infra_imports.dart';
import 'package:patrimonio/app/page/shared_page/list_page_base.dart';
import 'package:patrimonio/app/page/shared_widget/shared_widget_imports.dart';

class PatrimTaxaDepreciacaoListPage extends ListPageBase<PatrimTaxaDepreciacaoController> {
  const PatrimTaxaDepreciacaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  Widget buildMobileView() {
    final additionalContentTop = buildAdditionalContentTop();
    final additionalContentBottom = buildAdditionalContentBottom();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(controller.screenTitle),
        actions: [
          ...?additionalMobileActions(),
          exitButton(),
        ],
      ),
      body: Column(
        children: [
          if (additionalContentTop != null) additionalContentTop,
          Expanded(
            child: ResponsiveListView(
              items: mobileItems,
              primaryColumns: mobileConfig['primaryColumns'],
              secondaryColumns: mobileConfig['secondaryColumns'],
              onItemTap: (item) => {},
              onDelete: (item) => {},
            ),
          ),
          if (additionalContentBottom != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 60),
              child: additionalContentBottom,
            ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.black26,
        shape: const CircularNotchedRectangle(),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.print),
              onPressed: controller.printReport,
            ),
            IconButton(
              icon: const Icon(Icons.filter_list),
              onPressed: () => controller.callFilter(),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildDesktopView() {
    final additionalContentTop = buildAdditionalContentTop();
    final additionalContentBottom = buildAdditionalContentBottom();

    return Scaffold(
      appBar: appBar(),
      bottomNavigationBar: BottomAppBar(
        color: Colors.black26,
        shape: const CircularNotchedRectangle(),
        child: Row(children: [
          ...standardBottomActions(),
          ...?additionalBottomActions(),
        ]),
      ),
      body: Padding(
        padding: const EdgeInsets.all(5),
        child: Column(
          children: [
            if (additionalContentTop != null) additionalContentTop,
            Expanded(
              child: PlutoGrid(
                configuration: gridConfiguration(),
                noRowsWidget: controller.isLoading.value ? const Center(child: CircularProgressIndicator()) : Text('grid_no_rows'.tr),
                createFooter: (stateManager) {
                  stateManager.setPageSize(Constants.gridRowsPerPage, notify: false);
                  return PlutoPagination(stateManager);
                },
                columns: controller.gridColumns,
                rows: controller.plutoRows(),
                onLoaded: (event) {
                  controller.plutoGridStateManager = event.stateManager;
                  controller.plutoGridStateManager.setSelectingMode(PlutoGridSelectingMode.row);
                  controller.keyboardListener = controller.plutoGridStateManager.keyManager!.subject.stream.listen(controller.handleKeyboard);
                  controller.loadData();
                },
                mode: PlutoGridMode.selectWithOneTap,
              ),
            ),
            if (additionalContentBottom != null) additionalContentBottom,
          ],
        ),
      ),
    );
  }

  @override
  List<Widget> standardAppBarActions() {
    return [
      exitButton(),
      const SizedBox(
        height: 10,
        width: 5,
      ),
    ];
  }

  @override
  List<Widget> standardBottomActions() {
    return [
      printButton(onPressed: controller.printReport),
      filterButton(
        onPressed: () => controller.callFilter(),
      ),
    ];
  }

}
