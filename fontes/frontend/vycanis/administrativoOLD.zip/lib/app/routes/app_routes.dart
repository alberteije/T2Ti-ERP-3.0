abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const papelListPage = '/papelListPage'; 
	static const papelTabPage = '/papelTabPage';
	static const empresaListPage = '/empresaListPage'; 
	static const empresaTabPage = '/empresaTabPage';
	static const auditoriaListPage = '/auditoriaListPage'; 
	static const auditoriaEditPage = '/auditoriaEditPage';
	static const funcaoListPage = '/funcaoListPage'; 
	static const funcaoEditPage = '/funcaoEditPage';
	static const usuarioListPage = '/usuarioListPage'; 
	static const usuarioEditPage = '/usuarioEditPage';
}