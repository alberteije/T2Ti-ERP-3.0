import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/controller/controller_imports.dart';
import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:administrativo/app/page/grid_columns/grid_columns_imports.dart';

import 'package:administrativo/app/routes/app_routes.dart';
import 'package:administrativo/app/data/repository/auditoria_repository.dart';
import 'package:administrativo/app/page/shared_page/shared_page_imports.dart';
import 'package:administrativo/app/page/shared_widget/message_dialog.dart';
import 'package:administrativo/app/mixin/controller_base_mixin.dart';

class AuditoriaController extends GetxController with ControllerBaseMixin {
  final AuditoriaRepository auditoriaRepository;
  AuditoriaController({required this.auditoriaRepository});

  // general
  final _dbColumns = AuditoriaModel.dbColumns;
  get dbColumns => _dbColumns;

  final _aliasColumns = AuditoriaModel.aliasColumns;
  get aliasColumns => _aliasColumns;

  final gridColumns = auditoriaGridColumns();
  
  var _auditoriaModelList = <AuditoriaModel>[];

  final _auditoriaModel = AuditoriaModel().obs;
  AuditoriaModel get auditoriaModel => _auditoriaModel.value;
  set auditoriaModel(value) => _auditoriaModel.value = value ?? AuditoriaModel();

  final _filter = Filter().obs;
  Filter get filter => _filter.value;
  set filter(value) => _filter.value = value ?? Filter(); 

  var _isInserting = false;

  // list page
  late StreamSubscription _keyboardListener;
  get keyboardListener => _keyboardListener;
  set keyboardListener(value) => _keyboardListener = value;

  late PlutoGridStateManager _plutoGridStateManager;
  get plutoGridStateManager => _plutoGridStateManager;
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final _plutoRow = PlutoRow(cells: {}).obs;
  get plutoRow => _plutoRow.value;
  set plutoRow(value) => _plutoRow.value = value;

  List<PlutoRow> plutoRows() {
    List<PlutoRow> plutoRowList = <PlutoRow>[];
    for (var auditoriaModel in _auditoriaModelList) {
      plutoRowList.add(_getPlutoRow(auditoriaModel));
    }
    return plutoRowList;
  }

  PlutoRow _getPlutoRow(AuditoriaModel auditoriaModel) {
    return PlutoRow(
      cells: _getPlutoCells(auditoriaModel: auditoriaModel),
    );
  }

  Map<String, PlutoCell> _getPlutoCells({ AuditoriaModel? auditoriaModel}) {
    return {
			"id": PlutoCell(value: auditoriaModel?.id ?? 0),
			"dataRegistro": PlutoCell(value: auditoriaModel?.dataRegistro ?? ''),
			"horaRegistro": PlutoCell(value: auditoriaModel?.horaRegistro ?? ''),
			"janelaController": PlutoCell(value: auditoriaModel?.janelaController ?? ''),
			"acao": PlutoCell(value: auditoriaModel?.acao ?? ''),
			"conteudo": PlutoCell(value: auditoriaModel?.conteudo ?? ''),
			"tokenJwt": PlutoCell(value: auditoriaModel?.tokenJwt ?? ''),
    };
  }

  void plutoRowToObject() {
    final modelFromRow = _auditoriaModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
    if (modelFromRow.isEmpty) {
      auditoriaModel.plutoRowToObject(plutoRow);
    } else {
      auditoriaModel = modelFromRow[0];
    }      
  }

  Future callFilter() async {
    final filterController = Get.find<FilterController>();
    filterController.title = '${'filter_page_title'.tr} [Auditoria]';
    filterController.standardFilter = true;
    filterController.aliasColumns = aliasColumns;
    filterController.dbColumns = dbColumns;
    filterController.filter.field = 'Id';

    filter = await Get.toNamed(Routes.filterPage);
    await loadData();
  }

  Future loadData() async {
    _plutoGridStateManager.setShowLoading(true);
    _plutoGridStateManager.removeAllRows();
    await Get.find<AuditoriaController>().getList(filter: filter);
    _plutoGridStateManager.appendRows(plutoRows());
    _plutoGridStateManager.setShowLoading(false);
  }

  Future getList({Filter? filter}) async {
    await auditoriaRepository.getList(filter: filter).then( (data){ _auditoriaModelList = data; } );
  }

  void printReport() {
    Get.dialog(AlertDialog(
      content: ReportPage(
        title: 'Auditoria',
        columns: gridColumns.map((column) => column.title).toList(),
        plutoRows: plutoRows(),
      ),
    ));
  }

  void callEditPage() {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
			horaRegistroController.text = currentRow.cells['horaRegistro']?.value ?? '';
			janelaControllerController.text = currentRow.cells['janelaController']?.value ?? '';
			acaoController.text = currentRow.cells['acao']?.value ?? '';
			conteudoController.text = currentRow.cells['conteudo']?.value ?? '';
			tokenJwtController.text = currentRow.cells['tokenJwt']?.value ?? '';

      plutoRow = currentRow;
      formWasChanged = false;
      plutoRowToObject();
      Get.toNamed(Routes.auditoriaEditPage)!.then((value) {
        if (auditoriaModel.id == 0) {
          _plutoGridStateManager.removeCurrentRow();
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
    }
  }

  void callEditPageToInsert() {
    _plutoGridStateManager.prependNewRows(); 
    final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
    _plutoGridStateManager.setCurrentCell(cell, 0); 
    _isInserting = true;
    auditoriaModel = AuditoriaModel();
    callEditPage();   
  }

  void handleKeyboard(PlutoKeyManagerEvent event) {
    // if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
    //   if (canUpdate) {
    //     callEditPage();
    //   } else {
    //     noPrivilegeMessage();
    //   }
    // }
  }  

  Future delete() async {
    final currentRow = _plutoGridStateManager.currentRow;
    if (currentRow != null) {
      showDeleteDialog(() async {
        if (await auditoriaRepository.delete(id: currentRow.cells['id']!.value)) {
          _auditoriaModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
          _plutoGridStateManager.removeCurrentRow();
        } else {
          showErrorSnackBar(message: 'message_error_delete'.tr);
        }
      });
    } else {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
    }
  }


  // edit page
  final scrollController = ScrollController();
	final horaRegistroController = TextEditingController();
	final janelaControllerController = TextEditingController();
	final acaoController = TextEditingController();
	final conteudoController = TextEditingController();
	final tokenJwtController = TextEditingController();

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  final _formWasChanged = false.obs;
  get formWasChanged => _formWasChanged.value;
  set formWasChanged(value) => _formWasChanged.value = value; 

  void objectToPlutoRow() {
		plutoRow.cells['id']?.value = auditoriaModel.id;
		plutoRow.cells['dataRegistro']?.value = Util.formatDate(auditoriaModel.dataRegistro);
		plutoRow.cells['horaRegistro']?.value = auditoriaModel.horaRegistro;
		plutoRow.cells['janelaController']?.value = auditoriaModel.janelaController;
		plutoRow.cells['acao']?.value = auditoriaModel.acao;
		plutoRow.cells['conteudo']?.value = auditoriaModel.conteudo;
		plutoRow.cells['tokenJwt']?.value = auditoriaModel.tokenJwt;
  }

  Future<void> save() async {
    final FormState form = formKey.currentState!;
    if (!form.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
    } else {
      if (formWasChanged) {
        final result = await auditoriaRepository.save(auditoriaModel: auditoriaModel); 
        if (result != null) {
          auditoriaModel = result;
          if (_isInserting) {
            _auditoriaModelList.add(result);
            _isInserting = false;
          }
          objectToPlutoRow();
          Get.back();
        }
      } else {
        Get.back();
      }
    }
  }

  void preventDataLoss() {
    if (formWasChanged) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      Get.back();
    }
  }  

  String processarConteudo(String acao, String conteudo) {
    if (acao == 'GET') {
      final uri = Uri.tryParse(conteudo);
      if (uri != null && uri.queryParameters.containsKey('filter')) {
        return 'Consulta com filtro: \n - Rota: ${uri.path} \n - Filtro: ${uri.queryParameters['filter']}';
      }
      return 'Consulta sem filtro: \n - Rota: $conteudo';
    } else if (acao == 'PUT' || acao == 'POST') {
      try {
        final decoded = json.decode(conteudo);
        final tipoOperacao = acao == 'PUT' ? 'Alteração' : 'Inclusão'; 
        return '$tipoOperacao: \n - Dados enviados:\n${const JsonEncoder.withIndent('  ').convert(decoded)}';
      } catch (e) {
        return 'Conteúdo inválido para $acao.';
      }
    } else if (acao == 'DELETE') {
      return 'Exclusão: \n - Rota: $conteudo';
    }
    return 'Ação desconhecida.';
  }

  void mostrarDetalhes() {
    final usuarioLogin = auditoriaModel.usuarioTokenModel?.login ?? 'Desconhecido';
    final conteudoDetalhes = processarConteudo(auditoriaModel.acao ?? '', auditoriaModel.conteudo ?? '');

    Get.dialog(
      AlertDialog(
        title: const Text('Detalhes da Auditoria'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Usuário: $usuarioLogin', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Text('Detalhes da Ação', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(conteudoDetalhes),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(Get.context!).pop(); // Fecha apenas o diálogo
            },
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  // override
  @override
  void onInit() {
    bootstrapGridParameters(
      gutterSize: Constants.flutterBootstrapGutterSize,
    );
		functionName = "auditoria";
    setPrivilege();		
    super.onInit();
  }

  @override
  void onClose() {
		horaRegistroController.dispose();
		janelaControllerController.dispose();
		acaoController.dispose();
		conteudoController.dispose();
		tokenJwtController.dispose();
    keyboardListener.cancel();
    scrollController.dispose(); 
    super.onClose();
  }
}