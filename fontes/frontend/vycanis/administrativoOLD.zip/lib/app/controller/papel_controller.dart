import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/controller/controller_imports.dart';
import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:administrativo/app/page/grid_columns/grid_columns_imports.dart';
import 'package:administrativo/app/page/page_imports.dart';

import 'package:administrativo/app/routes/app_routes.dart';
import 'package:administrativo/app/data/repository/papel_repository.dart';
import 'package:administrativo/app/page/shared_page/shared_page_imports.dart';
import 'package:administrativo/app/page/shared_widget/message_dialog.dart';
import 'package:administrativo/app/mixin/controller_base_mixin.dart';

class PapelController extends GetxController with GetSingleTickerProviderStateMixin, ControllerBaseMixin {
	final PapelRepository papelRepository;
	PapelController({required this.papelRepository});

	// general
	final _dbColumns = PapelModel.dbColumns;
	get dbColumns => _dbColumns;

	final _aliasColumns = PapelModel.aliasColumns;
	get aliasColumns => _aliasColumns;

	final gridColumns = papelGridColumns();
	
	var _papelModelList = <PapelModel>[];

	var _papelModelOld = PapelModel();

	final _papelModel = PapelModel().obs;
	PapelModel get papelModel => _papelModel.value;
	set papelModel(value) => _papelModel.value = value ?? PapelModel();

	final _filter = Filter().obs;
	Filter get filter => _filter.value;
	set filter(value) => _filter.value = value ?? Filter(); 
	
	var _isInserting = false;

	// tab page
	late TabController tabController;

	List<Tab> tabItems = [
		Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Papel', 
		),
		Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Controle de Acesso', 
		),
	];

	List<Widget> tabPages() {
		return [
			PapelEditPage(),
			const PapelFuncaoListPage(),
		];
	}

	// list page
	late StreamSubscription _keyboardListener;
	get keyboardListener => _keyboardListener;
	set keyboardListener(value) => _keyboardListener = value;

	late PlutoGridStateManager _plutoGridStateManager;
	get plutoGridStateManager => _plutoGridStateManager;
	set plutoGridStateManager(value) => _plutoGridStateManager = value;

	final _plutoRow = PlutoRow(cells: {}).obs;
	get plutoRow => _plutoRow.value;
	set plutoRow(value) => _plutoRow.value = value;

	List<PlutoRow> plutoRows() {
		List<PlutoRow> plutoRowList = <PlutoRow>[];
		for (var papelModel in _papelModelList) {
			plutoRowList.add(_getPlutoRow(papelModel));
		}
		return plutoRowList;
	}

	PlutoRow _getPlutoRow(PapelModel papelModel) {
		return PlutoRow(
			cells: _getPlutoCells(papelModel: papelModel),
		);
	}

	Map<String, PlutoCell> _getPlutoCells({ PapelModel? papelModel}) {
		return {
			"id": PlutoCell(value: papelModel?.id ?? 0),
			"nome": PlutoCell(value: papelModel?.nome ?? ''),
			"descricao": PlutoCell(value: papelModel?.descricao ?? ''),
		};
	}

	void plutoRowToObject() {
		final modelFromRow = _papelModelList.where( ((t) => t.id == plutoRow.cells['id']!.value) ).toList();
		if (modelFromRow.isEmpty) {
			papelModel.plutoRowToObject(plutoRow);
		} else {
			papelModel = modelFromRow[0];
			_papelModelOld = papelModel.clone();
		}		
	}

	Future callFilter() async {
		final filterController = Get.find<FilterController>();
		filterController.title = '${'filter_page_title'.tr} [Papel]';
		filterController.standardFilter = true;
		filterController.aliasColumns = aliasColumns;
		filterController.dbColumns = dbColumns;
		filterController.filter.field = 'Id';

		filter = await Get.toNamed(Routes.filterPage);
		await loadData();
	}

	Future loadData() async {
		_plutoGridStateManager.setShowLoading(true);
		_plutoGridStateManager.removeAllRows();
		await Get.find<PapelController>().getList(filter: filter);
		_plutoGridStateManager.appendRows(plutoRows());
		_plutoGridStateManager.setShowLoading(false);
	}

	Future getList({Filter? filter}) async {
		await papelRepository.getList(filter: filter).then( (data){ _papelModelList = data; } );
	}

	void printReport() {
		Get.dialog(AlertDialog(
			content: ReportPage(
				title: 'Papel',
				columns: gridColumns.map((column) => column.title).toList(),
				plutoRows: plutoRows(),
			),
		));
	}

	void callEditPage() {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			nomeController.text = currentRow.cells['nome']?.value ?? '';
			descricaoController.text = currentRow.cells['descricao']?.value ?? '';
			plutoRow = currentRow;
			formWasChanged = false;
			plutoRowToObject();

			tabController.animateTo(0);
			
			//Controle de Acesso
			Get.put<PapelFuncaoController>(PapelFuncaoController()); 
			final papelFuncaoController = Get.find<PapelFuncaoController>(); 
			papelFuncaoController.papelFuncaoModelList = papelModel.papelFuncaoModelList!; 
			papelFuncaoController.userMadeChanges = false; 


			Get.toNamed(Routes.papelTabPage)!.then((value) {
				if (papelModel.id == 0) {
					_plutoGridStateManager.removeCurrentRow();
				}
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
		}
	}

	void callEditPageToInsert() {
		_plutoGridStateManager.prependNewRows(); 
		final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
		_plutoGridStateManager.setCurrentCell(cell, 0); 
		_isInserting = true;
		papelModel = PapelModel();
		callEditPage();	 
	}

  void handleKeyboard(PlutoKeyManagerEvent event) {
    if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
      if (canUpdate) {
        callEditPage();
      } else {
        noPrivilegeMessage();
      }
    }
  }  

	Future delete() async {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			showDeleteDialog(() async {
				if (await papelRepository.delete(id: currentRow.cells['id']!.value)) {
					_papelModelList.removeWhere( ((t) => t.id == currentRow.cells['id']!.value) );
					_plutoGridStateManager.removeCurrentRow();
				} else {
					showErrorSnackBar(message: 'message_error_delete'.tr);
				}
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
		}
	}


	// edit page
	String? mandatoryMessage;
	
	final scrollController = ScrollController();
	final nomeController = TextEditingController();
	final descricaoController = TextEditingController();

	final papelTabPageScaffoldKey = GlobalKey<ScaffoldState>();

	final papelEditPageScaffoldKey = GlobalKey<ScaffoldState>();
	final papelEditPageFormKey = GlobalKey<FormState>();

	final _formWasChanged = false.obs;
	get formWasChanged => _formWasChanged.value;
	set formWasChanged(value) => _formWasChanged.value = value; 

	void objectToPlutoRow() {
		plutoRow.cells['id']?.value = papelModel.id;
		plutoRow.cells['nome']?.value = papelModel.nome;
		plutoRow.cells['descricao']?.value = papelModel.descricao;
	}

	Future<void> save() async {
		if (validateForms()) {
			if (userMadeChanges()) {
				final result = await papelRepository.save(papelModel: papelModel); 
				if (result != null) {
					papelModel = result;
					if (_isInserting) {
						_papelModelList.add(papelModel);
						_isInserting = false;
					} else {
            _papelModelList.removeWhere( ((t) => t.id == plutoRow.cells['id']!.value) );
            _papelModelList.add(papelModel);
          }
					objectToPlutoRow();
					Get.back();
				}
			} else {
				Get.back();
			}
		} 
	}

	void preventDataLoss() {
		if (userMadeChanges()) {
			showQuestionDialog('message_data_loss'.tr, () { 
				clearUserChanges();
				Get.back(); 
			});
		} else {
			clearUserChanges();
			Get.back();
		}
	}	

	bool userMadeChanges() {
		return
		formWasChanged 
		|| 
		Get.find<PapelFuncaoController>().userMadeChanges
		;
	}

	void clearUserChanges() {
		_papelModelList.removeWhere( ((t) => t.id == plutoRow.cells['id']!.value) );
		_papelModelList.add(_papelModelOld);
	}

	void tabChange(int index) {
		validateForms();
	}

	bool validateForms() {
		return true;
	}


	// override
	@override
	void onInit() {
		bootstrapGridParameters(
			gutterSize: Constants.flutterBootstrapGutterSize,
		);
		tabController = TabController(vsync: this, length: tabItems.length);
		functionName = "papel";
    setPrivilege();		
		super.onInit();
	}

	@override
	void onClose() {
		keyboardListener.cancel();
		scrollController.dispose(); 
		tabController.dispose();
		nomeController.dispose();
		descricaoController.dispose();
		super.onClose();
	}
}