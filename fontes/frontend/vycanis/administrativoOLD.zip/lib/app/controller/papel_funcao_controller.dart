import 'dart:async';

import 'package:administrativo/app/data/provider/api/funcao_api_provider.dart';
import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:administrativo/app/controller/controller_imports.dart';
import 'package:administrativo/app/routes/app_routes.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:administrativo/app/page/page_imports.dart';
import 'package:administrativo/app/page/grid_columns/grid_columns_imports.dart';
import 'package:administrativo/app/page/shared_widget/message_dialog.dart';

class PapelFuncaoController extends GetxController {

	// general
	final gridColumns = papelFuncaoGridColumns();
	
	var papelFuncaoModelList = <PapelFuncaoModel>[];

	final _papelFuncaoModel = PapelFuncaoModel().obs;
	PapelFuncaoModel get papelFuncaoModel => _papelFuncaoModel.value;
	set papelFuncaoModel(value) => _papelFuncaoModel.value = value ?? PapelFuncaoModel();
	
	// list page
	late StreamSubscription _keyboardListener;
	get keyboardListener => _keyboardListener;
	set keyboardListener(value) => _keyboardListener = value;

	late PlutoGridStateManager _plutoGridStateManager;
	get plutoGridStateManager => _plutoGridStateManager;
	set plutoGridStateManager(value) => _plutoGridStateManager = value;

	final _plutoRow = PlutoRow(cells: {}).obs;
	get plutoRow => _plutoRow.value;
	set plutoRow(value) => _plutoRow.value = value;

	List<PlutoRow> plutoRows() {
		List<PlutoRow> plutoRowList = <PlutoRow>[];
		for (var papelFuncaoModel in papelFuncaoModelList) {
			plutoRowList.add(_getPlutoRow(papelFuncaoModel));
		}
		return plutoRowList;
	}

	PlutoRow _getPlutoRow(PapelFuncaoModel papelFuncaoModel) {
		return PlutoRow(
			cells: _getPlutoCells(papelFuncaoModel: papelFuncaoModel),
		);
	}

	Map<String, PlutoCell> _getPlutoCells({ PapelFuncaoModel? papelFuncaoModel}) {
		return {
			"id": PlutoCell(value: papelFuncaoModel?.id ?? 0),
			"funcao": PlutoCell(value: papelFuncaoModel?.funcaoModel?.nome ?? ''),
			"funcao_descricao": PlutoCell(value: papelFuncaoModel?.funcaoModel?.descricao ?? ''),
			"habilitado": PlutoCell(value: papelFuncaoModel?.habilitado ?? ''),
			"podeInserir": PlutoCell(value: papelFuncaoModel?.podeInserir ?? ''),
			"podeAlterar": PlutoCell(value: papelFuncaoModel?.podeAlterar ?? ''),
			"podeExcluir": PlutoCell(value: papelFuncaoModel?.podeExcluir ?? ''),
			"idPapel": PlutoCell(value: papelFuncaoModel?.idPapel ?? 0),
			"idFuncao": PlutoCell(value: papelFuncaoModel?.idFuncao ?? 0),
		};
	}

	void plutoRowToObject() {
		papelFuncaoModel.plutoRowToObject(plutoRow);
	}

	Future loadData() async {
		_plutoGridStateManager.setShowLoading(true);
		_plutoGridStateManager.removeAllRows();
		_plutoGridStateManager.appendRows(plutoRows());
		_plutoGridStateManager.setShowLoading(false);
	}

	Future getList({Filter? filter}) async {
		return papelFuncaoModelList;
	}

	void callEditPage() {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			funcaoModelController.text = currentRow.cells['funcao']?.value ?? '';
			plutoRow = currentRow;
			formWasChanged = false;
			plutoRowToObject();
			Get.to(() => PapelFuncaoEditPage());
		} else {
			showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
		}
	}

	void callEditPageToInsert() {
		_plutoGridStateManager.prependNewRows(); 
		final cell = _plutoGridStateManager.rows.first.cells.entries.elementAt(0).value;
		_plutoGridStateManager.setCurrentCell(cell, 0); 
		callEditPage();	 
	}

	void handleKeyboard(PlutoKeyManagerEvent event) {
		// if (event.isKeyDownEvent && event.event.logicalKey.keyId == LogicalKeyboardKey.enter.keyId) {
		// 	callEditPage();
		// }
	} 

	Future delete() async {
		final currentRow = _plutoGridStateManager.currentRow;
		if (currentRow != null) {
			showDeleteDialog(() async {
				_plutoGridStateManager.removeCurrentRow();
				userMadeChanges = true;
				refreshList();
			});
		} else {
			showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
		}
	}

	// edit page
	final scrollController = ScrollController();
	final funcaoModelController = TextEditingController();

	final scaffoldKey = GlobalKey<ScaffoldState>();
	final formKey = GlobalKey<FormState>();

	final _formWasChanged = false.obs;
	get formWasChanged => _formWasChanged.value;
	set formWasChanged(value) => _formWasChanged.value = value; 

	final _userMadeChanges = false.obs;
	get userMadeChanges => _userMadeChanges.value;
	set userMadeChanges(value) => _userMadeChanges.value = value; 

	void objectToPlutoRow() {
		plutoRow.cells['id']?.value = papelFuncaoModel.id;
		plutoRow.cells['idPapel']?.value = papelFuncaoModel.idPapel;
		plutoRow.cells['idFuncao']?.value = papelFuncaoModel.idFuncao;
		plutoRow.cells['funcao']?.value = papelFuncaoModel.funcaoModel?.nome;
    plutoRow.cells['funcao_descricao']?.value = papelFuncaoModel.funcaoModel?.descricao;
		plutoRow.cells['habilitado']?.value = papelFuncaoModel.habilitado;
		plutoRow.cells['podeInserir']?.value = papelFuncaoModel.podeInserir;
		plutoRow.cells['podeAlterar']?.value = papelFuncaoModel.podeAlterar;
		plutoRow.cells['podeExcluir']?.value = papelFuncaoModel.podeExcluir;
	}

	Future<void> save() async {
		final FormState form = formKey.currentState!;
		if (!form.validate()) {
			showErrorSnackBar(message: 'validator_form_message'.tr);
		} else {
			if (formWasChanged) {
				userMadeChanges = true;		 
				objectToPlutoRow();
				refreshList();
				Get.back();
			} else {
				Get.back();
			}
		}
	}

  void refreshList() {
		papelFuncaoModelList.clear();
		for (var plutoRow in _plutoGridStateManager.rows) {
			var model = PapelFuncaoModel();
			model.plutoRowToObject(plutoRow);
			papelFuncaoModelList.add(model);
		}
  }

	void preventDataLoss() {
		if (formWasChanged) {
			showQuestionDialog('message_data_loss'.tr, () => Get.back());
		} else {
			formWasChanged = false;
			Get.back();
		}
	}	

	Future callFuncaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Função]'; 
		lookupController.route = '/funcao/'; 
		lookupController.gridColumns = funcaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FuncaoModel.aliasColumns; 
		lookupController.dbColumns = FuncaoModel.dbColumns; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			papelFuncaoModel.idFuncao = plutoRowResult.cells['id']!.value; 
			papelFuncaoModel.funcaoModel!.plutoRowToObject(plutoRowResult); 
			funcaoModelController.text = papelFuncaoModel.funcaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  void gerarFuncoes() {
    showQuestionDialog("Deseja gerar as funções? O conteúdo atual será apagado.", () 
      async {
        _plutoGridStateManager.setShowLoading(true);

        papelFuncaoModelList.clear();
        _plutoGridStateManager.removeAllRows();
        
        FuncaoApiProvider funcaoApiProvider = FuncaoApiProvider();
        final listaFuncoes = await funcaoApiProvider.getList();
        if (listaFuncoes != null) {
          for (var funcao in listaFuncoes) {
            final papelFuncao = PapelFuncaoModel(
              idFuncao: funcao.id,
              funcaoModel: FuncaoModel(
                id: funcao.id,
                nome: funcao.nome,
                descricao: funcao.descricao,
              )
            );
            papelFuncaoModelList.add(papelFuncao);
          }
        }

        _plutoGridStateManager.appendRows(plutoRows());
        _plutoGridStateManager.setShowLoading(false);

        userMadeChanges = true;
      }
    ); 
  }

  void atualizarValorDaCelula(PlutoGridOnRowDoubleTapEvent event) {
    // Obtenha a célula clicada
    final celulaPressionada = event.cell;

    const camposAlvo = ['habilitado', 'podeInserir', 'podeAlterar', 'podeExcluir'];  
    
    // Atualiza dados visuais na celula
    final currentValue = celulaPressionada.value as String?;
    String? newValue;

    if (camposAlvo.contains(celulaPressionada.column.field)) {
      // Aplique a lógica de alternância
      if (currentValue == null || currentValue.isEmpty) {
        newValue = 'Sim';
      } else if (currentValue == 'Sim') {
        newValue = 'Não';
      } else if (currentValue == 'Não') {
        newValue = 'Sim';
      }

      // Atualize o valor da célula
      celulaPressionada.value = newValue;

      // Notifique o estado do PlutoGrid para atualizar a UI
      _plutoGridStateManager.notifyListeners();    

      // pega o objeto da lista papelFuncaoModelList
      final idFuncao = event.row.cells['idFuncao']?.value as int;
      final objetoPapelFuncao = papelFuncaoModelList.firstWhere(
        (model) => model.idFuncao == idFuncao,
      );
      switch (celulaPressionada.column.field) {
        case 'habilitado':
          objetoPapelFuncao.habilitado = newValue;
          break;
        case 'podeInserir':
          objetoPapelFuncao.podeInserir = newValue;
          break;
        case 'podeAlterar':
          objetoPapelFuncao.podeAlterar = newValue;
          break;
        case 'podeExcluir':
          objetoPapelFuncao.podeExcluir = newValue;
          break;
      }  
      
      // marca que o usuário fez alterações para salvar a lista
      userMadeChanges = true;
    }
  }
    
	// override
	@override
	void onInit() {
		bootstrapGridParameters(
			gutterSize: Constants.flutterBootstrapGutterSize,
		);
		keyboardListener = const Stream.empty().listen((event) { });
		super.onInit();
	}

	@override
	void onClose() {
		keyboardListener.cancel();
		scrollController.dispose();		 
		funcaoModelController.dispose();
		super.onClose();
	}
}