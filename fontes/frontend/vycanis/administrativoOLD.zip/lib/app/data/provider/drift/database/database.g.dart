// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PapelFuncaosTable extends PapelFuncaos
    with TableInfo<$PapelFuncaosTable, PapelFuncao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PapelFuncaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPapel,
        idFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'papel_funcao';
  @override
  VerificationContext validateIntegrity(Insertable<PapelFuncao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PapelFuncao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PapelFuncao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $PapelFuncaosTable createAlias(String alias) {
    return $PapelFuncaosTable(attachedDatabase, alias);
  }
}

class PapelFuncao extends DataClass implements Insertable<PapelFuncao> {
  final int? id;
  final int? idPapel;
  final int? idFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const PapelFuncao(
      {this.id,
      this.idPapel,
      this.idFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory PapelFuncao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PapelFuncao(
      id: serializer.fromJson<int?>(json['id']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPapel': serializer.toJson<int?>(idPapel),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  PapelFuncao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      PapelFuncao(
        id: id.present ? id.value : this.id,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('PapelFuncao(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPapel, idFuncao, habilitado, podeInserir, podeAlterar, podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PapelFuncao &&
          other.id == this.id &&
          other.idPapel == this.idPapel &&
          other.idFuncao == this.idFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class PapelFuncaosCompanion extends UpdateCompanion<PapelFuncao> {
  final Value<int?> id;
  final Value<int?> idPapel;
  final Value<int?> idFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const PapelFuncaosCompanion({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  PapelFuncaosCompanion.insert({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<PapelFuncao> custom({
    Expression<int>? id,
    Expression<int>? idPapel,
    Expression<int>? idFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPapel != null) 'id_papel': idPapel,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  PapelFuncaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPapel,
      Value<int?>? idFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return PapelFuncaosCompanion(
      id: id ?? this.id,
      idPapel: idPapel ?? this.idPapel,
      idFuncao: idFuncao ?? this.idFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PapelFuncaosCompanion(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $EmpresaEnderecosTable extends EmpresaEnderecos
    with TableInfo<$EmpresaEnderecosTable, EmpresaEndereco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaEnderecosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaMeta =
      const VerificationMeta('idEmpresa');
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
      'id_empresa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<int> municipioIbge = GeneratedColumn<int>(
      'municipio_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _principalMeta =
      const VerificationMeta('principal');
  @override
  late final GeneratedColumn<String> principal = GeneratedColumn<String>(
      'principal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entregaMeta =
      const VerificationMeta('entrega');
  @override
  late final GeneratedColumn<String> entrega = GeneratedColumn<String>(
      'entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cobrancaMeta =
      const VerificationMeta('cobranca');
  @override
  late final GeneratedColumn<String> cobranca = GeneratedColumn<String>(
      'cobranca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _correspondenciaMeta =
      const VerificationMeta('correspondencia');
  @override
  late final GeneratedColumn<String> correspondencia = GeneratedColumn<String>(
      'correspondencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idEmpresa,
        logradouro,
        numero,
        bairro,
        cidade,
        uf,
        cep,
        municipioIbge,
        complemento,
        principal,
        entrega,
        cobranca,
        correspondencia
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_endereco';
  @override
  VerificationContext validateIntegrity(Insertable<EmpresaEndereco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_empresa')) {
      context.handle(_idEmpresaMeta,
          idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('principal')) {
      context.handle(_principalMeta,
          principal.isAcceptableOrUnknown(data['principal']!, _principalMeta));
    }
    if (data.containsKey('entrega')) {
      context.handle(_entregaMeta,
          entrega.isAcceptableOrUnknown(data['entrega']!, _entregaMeta));
    }
    if (data.containsKey('cobranca')) {
      context.handle(_cobrancaMeta,
          cobranca.isAcceptableOrUnknown(data['cobranca']!, _cobrancaMeta));
    }
    if (data.containsKey('correspondencia')) {
      context.handle(
          _correspondenciaMeta,
          correspondencia.isAcceptableOrUnknown(
              data['correspondencia']!, _correspondenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaEndereco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaEndereco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEmpresa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_empresa']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}municipio_ibge']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      principal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}principal']),
      entrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrega']),
      cobranca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cobranca']),
      correspondencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}correspondencia']),
    );
  }

  @override
  $EmpresaEnderecosTable createAlias(String alias) {
    return $EmpresaEnderecosTable(attachedDatabase, alias);
  }
}

class EmpresaEndereco extends DataClass implements Insertable<EmpresaEndereco> {
  final int? id;
  final int? idEmpresa;
  final String? logradouro;
  final String? numero;
  final String? bairro;
  final String? cidade;
  final String? uf;
  final String? cep;
  final int? municipioIbge;
  final String? complemento;
  final String? principal;
  final String? entrega;
  final String? cobranca;
  final String? correspondencia;
  const EmpresaEndereco(
      {this.id,
      this.idEmpresa,
      this.logradouro,
      this.numero,
      this.bairro,
      this.cidade,
      this.uf,
      this.cep,
      this.municipioIbge,
      this.complemento,
      this.principal,
      this.entrega,
      this.cobranca,
      this.correspondencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<int>(municipioIbge);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || principal != null) {
      map['principal'] = Variable<String>(principal);
    }
    if (!nullToAbsent || entrega != null) {
      map['entrega'] = Variable<String>(entrega);
    }
    if (!nullToAbsent || cobranca != null) {
      map['cobranca'] = Variable<String>(cobranca);
    }
    if (!nullToAbsent || correspondencia != null) {
      map['correspondencia'] = Variable<String>(correspondencia);
    }
    return map;
  }

  factory EmpresaEndereco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaEndereco(
      id: serializer.fromJson<int?>(json['id']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<int?>(json['municipioIbge']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      principal: serializer.fromJson<String?>(json['principal']),
      entrega: serializer.fromJson<String?>(json['entrega']),
      cobranca: serializer.fromJson<String?>(json['cobranca']),
      correspondencia: serializer.fromJson<String?>(json['correspondencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<int?>(municipioIbge),
      'complemento': serializer.toJson<String?>(complemento),
      'principal': serializer.toJson<String?>(principal),
      'entrega': serializer.toJson<String?>(entrega),
      'cobranca': serializer.toJson<String?>(cobranca),
      'correspondencia': serializer.toJson<String?>(correspondencia),
    };
  }

  EmpresaEndereco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEmpresa = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> municipioIbge = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> principal = const Value.absent(),
          Value<String?> entrega = const Value.absent(),
          Value<String?> cobranca = const Value.absent(),
          Value<String?> correspondencia = const Value.absent()}) =>
      EmpresaEndereco(
        id: id.present ? id.value : this.id,
        idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        complemento: complemento.present ? complemento.value : this.complemento,
        principal: principal.present ? principal.value : this.principal,
        entrega: entrega.present ? entrega.value : this.entrega,
        cobranca: cobranca.present ? cobranca.value : this.cobranca,
        correspondencia: correspondencia.present
            ? correspondencia.value
            : this.correspondencia,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaEndereco(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('complemento: $complemento, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idEmpresa,
      logradouro,
      numero,
      bairro,
      cidade,
      uf,
      cep,
      municipioIbge,
      complemento,
      principal,
      entrega,
      cobranca,
      correspondencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaEndereco &&
          other.id == this.id &&
          other.idEmpresa == this.idEmpresa &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.complemento == this.complemento &&
          other.principal == this.principal &&
          other.entrega == this.entrega &&
          other.cobranca == this.cobranca &&
          other.correspondencia == this.correspondencia);
}

class EmpresaEnderecosCompanion extends UpdateCompanion<EmpresaEndereco> {
  final Value<int?> id;
  final Value<int?> idEmpresa;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> municipioIbge;
  final Value<String?> complemento;
  final Value<String?> principal;
  final Value<String?> entrega;
  final Value<String?> cobranca;
  final Value<String?> correspondencia;
  const EmpresaEnderecosCompanion({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.complemento = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  EmpresaEnderecosCompanion.insert({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.complemento = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  static Insertable<EmpresaEndereco> custom({
    Expression<int>? id,
    Expression<int>? idEmpresa,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? municipioIbge,
    Expression<String>? complemento,
    Expression<String>? principal,
    Expression<String>? entrega,
    Expression<String>? cobranca,
    Expression<String>? correspondencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (complemento != null) 'complemento': complemento,
      if (principal != null) 'principal': principal,
      if (entrega != null) 'entrega': entrega,
      if (cobranca != null) 'cobranca': cobranca,
      if (correspondencia != null) 'correspondencia': correspondencia,
    });
  }

  EmpresaEnderecosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEmpresa,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? municipioIbge,
      Value<String?>? complemento,
      Value<String?>? principal,
      Value<String?>? entrega,
      Value<String?>? cobranca,
      Value<String?>? correspondencia}) {
    return EmpresaEnderecosCompanion(
      id: id ?? this.id,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      complemento: complemento ?? this.complemento,
      principal: principal ?? this.principal,
      entrega: entrega ?? this.entrega,
      cobranca: cobranca ?? this.cobranca,
      correspondencia: correspondencia ?? this.correspondencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<int>(municipioIbge.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (principal.present) {
      map['principal'] = Variable<String>(principal.value);
    }
    if (entrega.present) {
      map['entrega'] = Variable<String>(entrega.value);
    }
    if (cobranca.present) {
      map['cobranca'] = Variable<String>(cobranca.value);
    }
    if (correspondencia.present) {
      map['correspondencia'] = Variable<String>(correspondencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaEnderecosCompanion(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('complemento: $complemento, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }
}

class $EmpresaContatosTable extends EmpresaContatos
    with TableInfo<$EmpresaContatosTable, EmpresaContato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaContatosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaMeta =
      const VerificationMeta('idEmpresa');
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
      'id_empresa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idEmpresa, nome, email, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_contato';
  @override
  VerificationContext validateIntegrity(Insertable<EmpresaContato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_empresa')) {
      context.handle(_idEmpresaMeta,
          idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaContato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaContato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEmpresa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_empresa']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $EmpresaContatosTable createAlias(String alias) {
    return $EmpresaContatosTable(attachedDatabase, alias);
  }
}

class EmpresaContato extends DataClass implements Insertable<EmpresaContato> {
  final int? id;
  final int? idEmpresa;
  final String? nome;
  final String? email;
  final String? observacao;
  const EmpresaContato(
      {this.id, this.idEmpresa, this.nome, this.email, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory EmpresaContato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaContato(
      id: serializer.fromJson<int?>(json['id']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      nome: serializer.fromJson<String?>(json['nome']),
      email: serializer.fromJson<String?>(json['email']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'nome': serializer.toJson<String?>(nome),
      'email': serializer.toJson<String?>(email),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  EmpresaContato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEmpresa = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      EmpresaContato(
        id: id.present ? id.value : this.id,
        idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
        nome: nome.present ? nome.value : this.nome,
        email: email.present ? email.value : this.email,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaContato(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idEmpresa, nome, email, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaContato &&
          other.id == this.id &&
          other.idEmpresa == this.idEmpresa &&
          other.nome == this.nome &&
          other.email == this.email &&
          other.observacao == this.observacao);
}

class EmpresaContatosCompanion extends UpdateCompanion<EmpresaContato> {
  final Value<int?> id;
  final Value<int?> idEmpresa;
  final Value<String?> nome;
  final Value<String?> email;
  final Value<String?> observacao;
  const EmpresaContatosCompanion({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  EmpresaContatosCompanion.insert({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<EmpresaContato> custom({
    Expression<int>? id,
    Expression<int>? idEmpresa,
    Expression<String>? nome,
    Expression<String>? email,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (nome != null) 'nome': nome,
      if (email != null) 'email': email,
      if (observacao != null) 'observacao': observacao,
    });
  }

  EmpresaContatosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEmpresa,
      Value<String?>? nome,
      Value<String?>? email,
      Value<String?>? observacao}) {
    return EmpresaContatosCompanion(
      id: id ?? this.id,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      nome: nome ?? this.nome,
      email: email ?? this.email,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaContatosCompanion(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $EmpresaTelefonesTable extends EmpresaTelefones
    with TableInfo<$EmpresaTelefonesTable, EmpresaTelefone> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaTelefonesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaMeta =
      const VerificationMeta('idEmpresa');
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
      'id_empresa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idEmpresa, tipo, numero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_telefone';
  @override
  VerificationContext validateIntegrity(Insertable<EmpresaTelefone> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_empresa')) {
      context.handle(_idEmpresaMeta,
          idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaTelefone map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaTelefone(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEmpresa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_empresa']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
    );
  }

  @override
  $EmpresaTelefonesTable createAlias(String alias) {
    return $EmpresaTelefonesTable(attachedDatabase, alias);
  }
}

class EmpresaTelefone extends DataClass implements Insertable<EmpresaTelefone> {
  final int? id;
  final int? idEmpresa;
  final String? tipo;
  final String? numero;
  const EmpresaTelefone({this.id, this.idEmpresa, this.tipo, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory EmpresaTelefone.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaTelefone(
      id: serializer.fromJson<int?>(json['id']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'tipo': serializer.toJson<String?>(tipo),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  EmpresaTelefone copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEmpresa = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> numero = const Value.absent()}) =>
      EmpresaTelefone(
        id: id.present ? id.value : this.id,
        idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
        tipo: tipo.present ? tipo.value : this.tipo,
        numero: numero.present ? numero.value : this.numero,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaTelefone(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idEmpresa, tipo, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaTelefone &&
          other.id == this.id &&
          other.idEmpresa == this.idEmpresa &&
          other.tipo == this.tipo &&
          other.numero == this.numero);
}

class EmpresaTelefonesCompanion extends UpdateCompanion<EmpresaTelefone> {
  final Value<int?> id;
  final Value<int?> idEmpresa;
  final Value<String?> tipo;
  final Value<String?> numero;
  const EmpresaTelefonesCompanion({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  EmpresaTelefonesCompanion.insert({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<EmpresaTelefone> custom({
    Expression<int>? id,
    Expression<int>? idEmpresa,
    Expression<String>? tipo,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (tipo != null) 'tipo': tipo,
      if (numero != null) 'numero': numero,
    });
  }

  EmpresaTelefonesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEmpresa,
      Value<String?>? tipo,
      Value<String?>? numero}) {
    return EmpresaTelefonesCompanion(
      id: id ?? this.id,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      tipo: tipo ?? this.tipo,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaTelefonesCompanion(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $EmpresaCnaesTable extends EmpresaCnaes
    with TableInfo<$EmpresaCnaesTable, EmpresaCnae> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaCnaesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaMeta =
      const VerificationMeta('idEmpresa');
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
      'id_empresa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCnaeMeta = const VerificationMeta('idCnae');
  @override
  late final GeneratedColumn<int> idCnae = GeneratedColumn<int>(
      'id_cnae', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _principalMeta =
      const VerificationMeta('principal');
  @override
  late final GeneratedColumn<String> principal = GeneratedColumn<String>(
      'principal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ramoAtividadeMeta =
      const VerificationMeta('ramoAtividade');
  @override
  late final GeneratedColumn<String> ramoAtividade = GeneratedColumn<String>(
      'ramo_atividade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _objetoSocialMeta =
      const VerificationMeta('objetoSocial');
  @override
  late final GeneratedColumn<String> objetoSocial = GeneratedColumn<String>(
      'objeto_social', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idEmpresa, idCnae, principal, ramoAtividade, objetoSocial];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_cnae';
  @override
  VerificationContext validateIntegrity(Insertable<EmpresaCnae> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_empresa')) {
      context.handle(_idEmpresaMeta,
          idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta));
    }
    if (data.containsKey('id_cnae')) {
      context.handle(_idCnaeMeta,
          idCnae.isAcceptableOrUnknown(data['id_cnae']!, _idCnaeMeta));
    }
    if (data.containsKey('principal')) {
      context.handle(_principalMeta,
          principal.isAcceptableOrUnknown(data['principal']!, _principalMeta));
    }
    if (data.containsKey('ramo_atividade')) {
      context.handle(
          _ramoAtividadeMeta,
          ramoAtividade.isAcceptableOrUnknown(
              data['ramo_atividade']!, _ramoAtividadeMeta));
    }
    if (data.containsKey('objeto_social')) {
      context.handle(
          _objetoSocialMeta,
          objetoSocial.isAcceptableOrUnknown(
              data['objeto_social']!, _objetoSocialMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaCnae map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaCnae(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEmpresa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_empresa']),
      idCnae: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cnae']),
      principal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}principal']),
      ramoAtividade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ramo_atividade']),
      objetoSocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}objeto_social']),
    );
  }

  @override
  $EmpresaCnaesTable createAlias(String alias) {
    return $EmpresaCnaesTable(attachedDatabase, alias);
  }
}

class EmpresaCnae extends DataClass implements Insertable<EmpresaCnae> {
  final int? id;
  final int? idEmpresa;
  final int? idCnae;
  final String? principal;
  final String? ramoAtividade;
  final String? objetoSocial;
  const EmpresaCnae(
      {this.id,
      this.idEmpresa,
      this.idCnae,
      this.principal,
      this.ramoAtividade,
      this.objetoSocial});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idCnae != null) {
      map['id_cnae'] = Variable<int>(idCnae);
    }
    if (!nullToAbsent || principal != null) {
      map['principal'] = Variable<String>(principal);
    }
    if (!nullToAbsent || ramoAtividade != null) {
      map['ramo_atividade'] = Variable<String>(ramoAtividade);
    }
    if (!nullToAbsent || objetoSocial != null) {
      map['objeto_social'] = Variable<String>(objetoSocial);
    }
    return map;
  }

  factory EmpresaCnae.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaCnae(
      id: serializer.fromJson<int?>(json['id']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idCnae: serializer.fromJson<int?>(json['idCnae']),
      principal: serializer.fromJson<String?>(json['principal']),
      ramoAtividade: serializer.fromJson<String?>(json['ramoAtividade']),
      objetoSocial: serializer.fromJson<String?>(json['objetoSocial']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idCnae': serializer.toJson<int?>(idCnae),
      'principal': serializer.toJson<String?>(principal),
      'ramoAtividade': serializer.toJson<String?>(ramoAtividade),
      'objetoSocial': serializer.toJson<String?>(objetoSocial),
    };
  }

  EmpresaCnae copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEmpresa = const Value.absent(),
          Value<int?> idCnae = const Value.absent(),
          Value<String?> principal = const Value.absent(),
          Value<String?> ramoAtividade = const Value.absent(),
          Value<String?> objetoSocial = const Value.absent()}) =>
      EmpresaCnae(
        id: id.present ? id.value : this.id,
        idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
        idCnae: idCnae.present ? idCnae.value : this.idCnae,
        principal: principal.present ? principal.value : this.principal,
        ramoAtividade:
            ramoAtividade.present ? ramoAtividade.value : this.ramoAtividade,
        objetoSocial:
            objetoSocial.present ? objetoSocial.value : this.objetoSocial,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaCnae(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idCnae: $idCnae, ')
          ..write('principal: $principal, ')
          ..write('ramoAtividade: $ramoAtividade, ')
          ..write('objetoSocial: $objetoSocial')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idEmpresa, idCnae, principal, ramoAtividade, objetoSocial);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaCnae &&
          other.id == this.id &&
          other.idEmpresa == this.idEmpresa &&
          other.idCnae == this.idCnae &&
          other.principal == this.principal &&
          other.ramoAtividade == this.ramoAtividade &&
          other.objetoSocial == this.objetoSocial);
}

class EmpresaCnaesCompanion extends UpdateCompanion<EmpresaCnae> {
  final Value<int?> id;
  final Value<int?> idEmpresa;
  final Value<int?> idCnae;
  final Value<String?> principal;
  final Value<String?> ramoAtividade;
  final Value<String?> objetoSocial;
  const EmpresaCnaesCompanion({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idCnae = const Value.absent(),
    this.principal = const Value.absent(),
    this.ramoAtividade = const Value.absent(),
    this.objetoSocial = const Value.absent(),
  });
  EmpresaCnaesCompanion.insert({
    this.id = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idCnae = const Value.absent(),
    this.principal = const Value.absent(),
    this.ramoAtividade = const Value.absent(),
    this.objetoSocial = const Value.absent(),
  });
  static Insertable<EmpresaCnae> custom({
    Expression<int>? id,
    Expression<int>? idEmpresa,
    Expression<int>? idCnae,
    Expression<String>? principal,
    Expression<String>? ramoAtividade,
    Expression<String>? objetoSocial,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idCnae != null) 'id_cnae': idCnae,
      if (principal != null) 'principal': principal,
      if (ramoAtividade != null) 'ramo_atividade': ramoAtividade,
      if (objetoSocial != null) 'objeto_social': objetoSocial,
    });
  }

  EmpresaCnaesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEmpresa,
      Value<int?>? idCnae,
      Value<String?>? principal,
      Value<String?>? ramoAtividade,
      Value<String?>? objetoSocial}) {
    return EmpresaCnaesCompanion(
      id: id ?? this.id,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idCnae: idCnae ?? this.idCnae,
      principal: principal ?? this.principal,
      ramoAtividade: ramoAtividade ?? this.ramoAtividade,
      objetoSocial: objetoSocial ?? this.objetoSocial,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idCnae.present) {
      map['id_cnae'] = Variable<int>(idCnae.value);
    }
    if (principal.present) {
      map['principal'] = Variable<String>(principal.value);
    }
    if (ramoAtividade.present) {
      map['ramo_atividade'] = Variable<String>(ramoAtividade.value);
    }
    if (objetoSocial.present) {
      map['objeto_social'] = Variable<String>(objetoSocial.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaCnaesCompanion(')
          ..write('id: $id, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idCnae: $idCnae, ')
          ..write('principal: $principal, ')
          ..write('ramoAtividade: $ramoAtividade, ')
          ..write('objetoSocial: $objetoSocial')
          ..write(')'))
        .toString();
  }
}

class $PapelsTable extends Papels with TableInfo<$PapelsTable, Papel> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PapelsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'papel';
  @override
  VerificationContext validateIntegrity(Insertable<Papel> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Papel map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Papel(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $PapelsTable createAlias(String alias) {
    return $PapelsTable(attachedDatabase, alias);
  }
}

class Papel extends DataClass implements Insertable<Papel> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Papel({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Papel.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Papel(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Papel copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Papel(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('Papel(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Papel &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class PapelsCompanion extends UpdateCompanion<Papel> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const PapelsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  PapelsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Papel> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  PapelsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return PapelsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PapelsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $EmpresasTable extends Empresas with TableInfo<$EmpresasTable, Empresa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _razaoSocialMeta =
      const VerificationMeta('razaoSocial');
  @override
  late final GeneratedColumn<String> razaoSocial = GeneratedColumn<String>(
      'razao_social', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeFantasiaMeta =
      const VerificationMeta('nomeFantasia');
  @override
  late final GeneratedColumn<String> nomeFantasia = GeneratedColumn<String>(
      'nome_fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoEstadualMeta =
      const VerificationMeta('inscricaoEstadual');
  @override
  late final GeneratedColumn<String> inscricaoEstadual =
      GeneratedColumn<String>('inscricao_estadual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inscricaoMunicipalMeta =
      const VerificationMeta('inscricaoMunicipal');
  @override
  late final GeneratedColumn<String> inscricaoMunicipal =
      GeneratedColumn<String>('inscricao_municipal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tipoRegimeMeta =
      const VerificationMeta('tipoRegime');
  @override
  late final GeneratedColumn<String> tipoRegime = GeneratedColumn<String>(
      'tipo_regime', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _crtMeta = const VerificationMeta('crt');
  @override
  late final GeneratedColumn<String> crt = GeneratedColumn<String>(
      'crt', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataConstituicaoMeta =
      const VerificationMeta('dataConstituicao');
  @override
  late final GeneratedColumn<DateTime> dataConstituicao =
      GeneratedColumn<DateTime>('data_constituicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoJuntaComercialMeta =
      const VerificationMeta('inscricaoJuntaComercial');
  @override
  late final GeneratedColumn<String> inscricaoJuntaComercial =
      GeneratedColumn<String>('inscricao_junta_comercial', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataInscJuntaComercialMeta =
      const VerificationMeta('dataInscJuntaComercial');
  @override
  late final GeneratedColumn<DateTime> dataInscJuntaComercial =
      GeneratedColumn<DateTime>('data_insc_junta_comercial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeCidadeMeta =
      const VerificationMeta('codigoIbgeCidade');
  @override
  late final GeneratedColumn<int> codigoIbgeCidade = GeneratedColumn<int>(
      'codigo_ibge_cidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeUfMeta =
      const VerificationMeta('codigoIbgeUf');
  @override
  late final GeneratedColumn<int> codigoIbgeUf = GeneratedColumn<int>(
      'codigo_ibge_uf', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ceiMeta = const VerificationMeta('cei');
  @override
  late final GeneratedColumn<String> cei = GeneratedColumn<String>(
      'cei', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 12),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoCnaePrincipalMeta =
      const VerificationMeta('codigoCnaePrincipal');
  @override
  late final GeneratedColumn<String> codigoCnaePrincipal =
      GeneratedColumn<String>('codigo_cnae_principal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 7),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _imagemLogotipoMeta =
      const VerificationMeta('imagemLogotipo');
  @override
  late final GeneratedColumn<String> imagemLogotipo = GeneratedColumn<String>(
      'imagem_logotipo', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        razaoSocial,
        nomeFantasia,
        cnpj,
        inscricaoEstadual,
        inscricaoMunicipal,
        tipoRegime,
        crt,
        email,
        site,
        contato,
        dataConstituicao,
        tipo,
        inscricaoJuntaComercial,
        dataInscJuntaComercial,
        codigoIbgeCidade,
        codigoIbgeUf,
        cei,
        codigoCnaePrincipal,
        imagemLogotipo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa';
  @override
  VerificationContext validateIntegrity(Insertable<Empresa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('razao_social')) {
      context.handle(
          _razaoSocialMeta,
          razaoSocial.isAcceptableOrUnknown(
              data['razao_social']!, _razaoSocialMeta));
    }
    if (data.containsKey('nome_fantasia')) {
      context.handle(
          _nomeFantasiaMeta,
          nomeFantasia.isAcceptableOrUnknown(
              data['nome_fantasia']!, _nomeFantasiaMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('inscricao_estadual')) {
      context.handle(
          _inscricaoEstadualMeta,
          inscricaoEstadual.isAcceptableOrUnknown(
              data['inscricao_estadual']!, _inscricaoEstadualMeta));
    }
    if (data.containsKey('inscricao_municipal')) {
      context.handle(
          _inscricaoMunicipalMeta,
          inscricaoMunicipal.isAcceptableOrUnknown(
              data['inscricao_municipal']!, _inscricaoMunicipalMeta));
    }
    if (data.containsKey('tipo_regime')) {
      context.handle(
          _tipoRegimeMeta,
          tipoRegime.isAcceptableOrUnknown(
              data['tipo_regime']!, _tipoRegimeMeta));
    }
    if (data.containsKey('crt')) {
      context.handle(
          _crtMeta, crt.isAcceptableOrUnknown(data['crt']!, _crtMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('data_constituicao')) {
      context.handle(
          _dataConstituicaoMeta,
          dataConstituicao.isAcceptableOrUnknown(
              data['data_constituicao']!, _dataConstituicaoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('inscricao_junta_comercial')) {
      context.handle(
          _inscricaoJuntaComercialMeta,
          inscricaoJuntaComercial.isAcceptableOrUnknown(
              data['inscricao_junta_comercial']!,
              _inscricaoJuntaComercialMeta));
    }
    if (data.containsKey('data_insc_junta_comercial')) {
      context.handle(
          _dataInscJuntaComercialMeta,
          dataInscJuntaComercial.isAcceptableOrUnknown(
              data['data_insc_junta_comercial']!, _dataInscJuntaComercialMeta));
    }
    if (data.containsKey('codigo_ibge_cidade')) {
      context.handle(
          _codigoIbgeCidadeMeta,
          codigoIbgeCidade.isAcceptableOrUnknown(
              data['codigo_ibge_cidade']!, _codigoIbgeCidadeMeta));
    }
    if (data.containsKey('codigo_ibge_uf')) {
      context.handle(
          _codigoIbgeUfMeta,
          codigoIbgeUf.isAcceptableOrUnknown(
              data['codigo_ibge_uf']!, _codigoIbgeUfMeta));
    }
    if (data.containsKey('cei')) {
      context.handle(
          _ceiMeta, cei.isAcceptableOrUnknown(data['cei']!, _ceiMeta));
    }
    if (data.containsKey('codigo_cnae_principal')) {
      context.handle(
          _codigoCnaePrincipalMeta,
          codigoCnaePrincipal.isAcceptableOrUnknown(
              data['codigo_cnae_principal']!, _codigoCnaePrincipalMeta));
    }
    if (data.containsKey('imagem_logotipo')) {
      context.handle(
          _imagemLogotipoMeta,
          imagemLogotipo.isAcceptableOrUnknown(
              data['imagem_logotipo']!, _imagemLogotipoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Empresa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Empresa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      razaoSocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}razao_social']),
      nomeFantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_fantasia']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      inscricaoEstadual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_estadual']),
      inscricaoMunicipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_municipal']),
      tipoRegime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_regime']),
      crt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crt']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      dataConstituicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_constituicao']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      inscricaoJuntaComercial: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}inscricao_junta_comercial']),
      dataInscJuntaComercial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_insc_junta_comercial']),
      codigoIbgeCidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge_cidade']),
      codigoIbgeUf: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge_uf']),
      cei: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cei']),
      codigoCnaePrincipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_cnae_principal']),
      imagemLogotipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}imagem_logotipo']),
    );
  }

  @override
  $EmpresasTable createAlias(String alias) {
    return $EmpresasTable(attachedDatabase, alias);
  }
}

class Empresa extends DataClass implements Insertable<Empresa> {
  final int? id;
  final String? razaoSocial;
  final String? nomeFantasia;
  final String? cnpj;
  final String? inscricaoEstadual;
  final String? inscricaoMunicipal;
  final String? tipoRegime;
  final String? crt;
  final String? email;
  final String? site;
  final String? contato;
  final DateTime? dataConstituicao;
  final String? tipo;
  final String? inscricaoJuntaComercial;
  final DateTime? dataInscJuntaComercial;
  final int? codigoIbgeCidade;
  final int? codigoIbgeUf;
  final String? cei;
  final String? codigoCnaePrincipal;
  final String? imagemLogotipo;
  const Empresa(
      {this.id,
      this.razaoSocial,
      this.nomeFantasia,
      this.cnpj,
      this.inscricaoEstadual,
      this.inscricaoMunicipal,
      this.tipoRegime,
      this.crt,
      this.email,
      this.site,
      this.contato,
      this.dataConstituicao,
      this.tipo,
      this.inscricaoJuntaComercial,
      this.dataInscJuntaComercial,
      this.codigoIbgeCidade,
      this.codigoIbgeUf,
      this.cei,
      this.codigoCnaePrincipal,
      this.imagemLogotipo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || razaoSocial != null) {
      map['razao_social'] = Variable<String>(razaoSocial);
    }
    if (!nullToAbsent || nomeFantasia != null) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || inscricaoEstadual != null) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual);
    }
    if (!nullToAbsent || inscricaoMunicipal != null) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal);
    }
    if (!nullToAbsent || tipoRegime != null) {
      map['tipo_regime'] = Variable<String>(tipoRegime);
    }
    if (!nullToAbsent || crt != null) {
      map['crt'] = Variable<String>(crt);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || dataConstituicao != null) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || inscricaoJuntaComercial != null) {
      map['inscricao_junta_comercial'] =
          Variable<String>(inscricaoJuntaComercial);
    }
    if (!nullToAbsent || dataInscJuntaComercial != null) {
      map['data_insc_junta_comercial'] =
          Variable<DateTime>(dataInscJuntaComercial);
    }
    if (!nullToAbsent || codigoIbgeCidade != null) {
      map['codigo_ibge_cidade'] = Variable<int>(codigoIbgeCidade);
    }
    if (!nullToAbsent || codigoIbgeUf != null) {
      map['codigo_ibge_uf'] = Variable<int>(codigoIbgeUf);
    }
    if (!nullToAbsent || cei != null) {
      map['cei'] = Variable<String>(cei);
    }
    if (!nullToAbsent || codigoCnaePrincipal != null) {
      map['codigo_cnae_principal'] = Variable<String>(codigoCnaePrincipal);
    }
    if (!nullToAbsent || imagemLogotipo != null) {
      map['imagem_logotipo'] = Variable<String>(imagemLogotipo);
    }
    return map;
  }

  factory Empresa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Empresa(
      id: serializer.fromJson<int?>(json['id']),
      razaoSocial: serializer.fromJson<String?>(json['razaoSocial']),
      nomeFantasia: serializer.fromJson<String?>(json['nomeFantasia']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      inscricaoEstadual:
          serializer.fromJson<String?>(json['inscricaoEstadual']),
      inscricaoMunicipal:
          serializer.fromJson<String?>(json['inscricaoMunicipal']),
      tipoRegime: serializer.fromJson<String?>(json['tipoRegime']),
      crt: serializer.fromJson<String?>(json['crt']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      contato: serializer.fromJson<String?>(json['contato']),
      dataConstituicao:
          serializer.fromJson<DateTime?>(json['dataConstituicao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      inscricaoJuntaComercial:
          serializer.fromJson<String?>(json['inscricaoJuntaComercial']),
      dataInscJuntaComercial:
          serializer.fromJson<DateTime?>(json['dataInscJuntaComercial']),
      codigoIbgeCidade: serializer.fromJson<int?>(json['codigoIbgeCidade']),
      codigoIbgeUf: serializer.fromJson<int?>(json['codigoIbgeUf']),
      cei: serializer.fromJson<String?>(json['cei']),
      codigoCnaePrincipal:
          serializer.fromJson<String?>(json['codigoCnaePrincipal']),
      imagemLogotipo: serializer.fromJson<String?>(json['imagemLogotipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'razaoSocial': serializer.toJson<String?>(razaoSocial),
      'nomeFantasia': serializer.toJson<String?>(nomeFantasia),
      'cnpj': serializer.toJson<String?>(cnpj),
      'inscricaoEstadual': serializer.toJson<String?>(inscricaoEstadual),
      'inscricaoMunicipal': serializer.toJson<String?>(inscricaoMunicipal),
      'tipoRegime': serializer.toJson<String?>(tipoRegime),
      'crt': serializer.toJson<String?>(crt),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'contato': serializer.toJson<String?>(contato),
      'dataConstituicao': serializer.toJson<DateTime?>(dataConstituicao),
      'tipo': serializer.toJson<String?>(tipo),
      'inscricaoJuntaComercial':
          serializer.toJson<String?>(inscricaoJuntaComercial),
      'dataInscJuntaComercial':
          serializer.toJson<DateTime?>(dataInscJuntaComercial),
      'codigoIbgeCidade': serializer.toJson<int?>(codigoIbgeCidade),
      'codigoIbgeUf': serializer.toJson<int?>(codigoIbgeUf),
      'cei': serializer.toJson<String?>(cei),
      'codigoCnaePrincipal': serializer.toJson<String?>(codigoCnaePrincipal),
      'imagemLogotipo': serializer.toJson<String?>(imagemLogotipo),
    };
  }

  Empresa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> razaoSocial = const Value.absent(),
          Value<String?> nomeFantasia = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> inscricaoEstadual = const Value.absent(),
          Value<String?> inscricaoMunicipal = const Value.absent(),
          Value<String?> tipoRegime = const Value.absent(),
          Value<String?> crt = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<DateTime?> dataConstituicao = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> inscricaoJuntaComercial = const Value.absent(),
          Value<DateTime?> dataInscJuntaComercial = const Value.absent(),
          Value<int?> codigoIbgeCidade = const Value.absent(),
          Value<int?> codigoIbgeUf = const Value.absent(),
          Value<String?> cei = const Value.absent(),
          Value<String?> codigoCnaePrincipal = const Value.absent(),
          Value<String?> imagemLogotipo = const Value.absent()}) =>
      Empresa(
        id: id.present ? id.value : this.id,
        razaoSocial: razaoSocial.present ? razaoSocial.value : this.razaoSocial,
        nomeFantasia:
            nomeFantasia.present ? nomeFantasia.value : this.nomeFantasia,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        inscricaoEstadual: inscricaoEstadual.present
            ? inscricaoEstadual.value
            : this.inscricaoEstadual,
        inscricaoMunicipal: inscricaoMunicipal.present
            ? inscricaoMunicipal.value
            : this.inscricaoMunicipal,
        tipoRegime: tipoRegime.present ? tipoRegime.value : this.tipoRegime,
        crt: crt.present ? crt.value : this.crt,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        contato: contato.present ? contato.value : this.contato,
        dataConstituicao: dataConstituicao.present
            ? dataConstituicao.value
            : this.dataConstituicao,
        tipo: tipo.present ? tipo.value : this.tipo,
        inscricaoJuntaComercial: inscricaoJuntaComercial.present
            ? inscricaoJuntaComercial.value
            : this.inscricaoJuntaComercial,
        dataInscJuntaComercial: dataInscJuntaComercial.present
            ? dataInscJuntaComercial.value
            : this.dataInscJuntaComercial,
        codigoIbgeCidade: codigoIbgeCidade.present
            ? codigoIbgeCidade.value
            : this.codigoIbgeCidade,
        codigoIbgeUf:
            codigoIbgeUf.present ? codigoIbgeUf.value : this.codigoIbgeUf,
        cei: cei.present ? cei.value : this.cei,
        codigoCnaePrincipal: codigoCnaePrincipal.present
            ? codigoCnaePrincipal.value
            : this.codigoCnaePrincipal,
        imagemLogotipo:
            imagemLogotipo.present ? imagemLogotipo.value : this.imagemLogotipo,
      );
  @override
  String toString() {
    return (StringBuffer('Empresa(')
          ..write('id: $id, ')
          ..write('razaoSocial: $razaoSocial, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('contato: $contato, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipo: $tipo, ')
          ..write('inscricaoJuntaComercial: $inscricaoJuntaComercial, ')
          ..write('dataInscJuntaComercial: $dataInscJuntaComercial, ')
          ..write('codigoIbgeCidade: $codigoIbgeCidade, ')
          ..write('codigoIbgeUf: $codigoIbgeUf, ')
          ..write('cei: $cei, ')
          ..write('codigoCnaePrincipal: $codigoCnaePrincipal, ')
          ..write('imagemLogotipo: $imagemLogotipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      razaoSocial,
      nomeFantasia,
      cnpj,
      inscricaoEstadual,
      inscricaoMunicipal,
      tipoRegime,
      crt,
      email,
      site,
      contato,
      dataConstituicao,
      tipo,
      inscricaoJuntaComercial,
      dataInscJuntaComercial,
      codigoIbgeCidade,
      codigoIbgeUf,
      cei,
      codigoCnaePrincipal,
      imagemLogotipo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Empresa &&
          other.id == this.id &&
          other.razaoSocial == this.razaoSocial &&
          other.nomeFantasia == this.nomeFantasia &&
          other.cnpj == this.cnpj &&
          other.inscricaoEstadual == this.inscricaoEstadual &&
          other.inscricaoMunicipal == this.inscricaoMunicipal &&
          other.tipoRegime == this.tipoRegime &&
          other.crt == this.crt &&
          other.email == this.email &&
          other.site == this.site &&
          other.contato == this.contato &&
          other.dataConstituicao == this.dataConstituicao &&
          other.tipo == this.tipo &&
          other.inscricaoJuntaComercial == this.inscricaoJuntaComercial &&
          other.dataInscJuntaComercial == this.dataInscJuntaComercial &&
          other.codigoIbgeCidade == this.codigoIbgeCidade &&
          other.codigoIbgeUf == this.codigoIbgeUf &&
          other.cei == this.cei &&
          other.codigoCnaePrincipal == this.codigoCnaePrincipal &&
          other.imagemLogotipo == this.imagemLogotipo);
}

class EmpresasCompanion extends UpdateCompanion<Empresa> {
  final Value<int?> id;
  final Value<String?> razaoSocial;
  final Value<String?> nomeFantasia;
  final Value<String?> cnpj;
  final Value<String?> inscricaoEstadual;
  final Value<String?> inscricaoMunicipal;
  final Value<String?> tipoRegime;
  final Value<String?> crt;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> contato;
  final Value<DateTime?> dataConstituicao;
  final Value<String?> tipo;
  final Value<String?> inscricaoJuntaComercial;
  final Value<DateTime?> dataInscJuntaComercial;
  final Value<int?> codigoIbgeCidade;
  final Value<int?> codigoIbgeUf;
  final Value<String?> cei;
  final Value<String?> codigoCnaePrincipal;
  final Value<String?> imagemLogotipo;
  const EmpresasCompanion({
    this.id = const Value.absent(),
    this.razaoSocial = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.contato = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.inscricaoJuntaComercial = const Value.absent(),
    this.dataInscJuntaComercial = const Value.absent(),
    this.codigoIbgeCidade = const Value.absent(),
    this.codigoIbgeUf = const Value.absent(),
    this.cei = const Value.absent(),
    this.codigoCnaePrincipal = const Value.absent(),
    this.imagemLogotipo = const Value.absent(),
  });
  EmpresasCompanion.insert({
    this.id = const Value.absent(),
    this.razaoSocial = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.contato = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.inscricaoJuntaComercial = const Value.absent(),
    this.dataInscJuntaComercial = const Value.absent(),
    this.codigoIbgeCidade = const Value.absent(),
    this.codigoIbgeUf = const Value.absent(),
    this.cei = const Value.absent(),
    this.codigoCnaePrincipal = const Value.absent(),
    this.imagemLogotipo = const Value.absent(),
  });
  static Insertable<Empresa> custom({
    Expression<int>? id,
    Expression<String>? razaoSocial,
    Expression<String>? nomeFantasia,
    Expression<String>? cnpj,
    Expression<String>? inscricaoEstadual,
    Expression<String>? inscricaoMunicipal,
    Expression<String>? tipoRegime,
    Expression<String>? crt,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? contato,
    Expression<DateTime>? dataConstituicao,
    Expression<String>? tipo,
    Expression<String>? inscricaoJuntaComercial,
    Expression<DateTime>? dataInscJuntaComercial,
    Expression<int>? codigoIbgeCidade,
    Expression<int>? codigoIbgeUf,
    Expression<String>? cei,
    Expression<String>? codigoCnaePrincipal,
    Expression<String>? imagemLogotipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (razaoSocial != null) 'razao_social': razaoSocial,
      if (nomeFantasia != null) 'nome_fantasia': nomeFantasia,
      if (cnpj != null) 'cnpj': cnpj,
      if (inscricaoEstadual != null) 'inscricao_estadual': inscricaoEstadual,
      if (inscricaoMunicipal != null) 'inscricao_municipal': inscricaoMunicipal,
      if (tipoRegime != null) 'tipo_regime': tipoRegime,
      if (crt != null) 'crt': crt,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (contato != null) 'contato': contato,
      if (dataConstituicao != null) 'data_constituicao': dataConstituicao,
      if (tipo != null) 'tipo': tipo,
      if (inscricaoJuntaComercial != null)
        'inscricao_junta_comercial': inscricaoJuntaComercial,
      if (dataInscJuntaComercial != null)
        'data_insc_junta_comercial': dataInscJuntaComercial,
      if (codigoIbgeCidade != null) 'codigo_ibge_cidade': codigoIbgeCidade,
      if (codigoIbgeUf != null) 'codigo_ibge_uf': codigoIbgeUf,
      if (cei != null) 'cei': cei,
      if (codigoCnaePrincipal != null)
        'codigo_cnae_principal': codigoCnaePrincipal,
      if (imagemLogotipo != null) 'imagem_logotipo': imagemLogotipo,
    });
  }

  EmpresasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? razaoSocial,
      Value<String?>? nomeFantasia,
      Value<String?>? cnpj,
      Value<String?>? inscricaoEstadual,
      Value<String?>? inscricaoMunicipal,
      Value<String?>? tipoRegime,
      Value<String?>? crt,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? contato,
      Value<DateTime?>? dataConstituicao,
      Value<String?>? tipo,
      Value<String?>? inscricaoJuntaComercial,
      Value<DateTime?>? dataInscJuntaComercial,
      Value<int?>? codigoIbgeCidade,
      Value<int?>? codigoIbgeUf,
      Value<String?>? cei,
      Value<String?>? codigoCnaePrincipal,
      Value<String?>? imagemLogotipo}) {
    return EmpresasCompanion(
      id: id ?? this.id,
      razaoSocial: razaoSocial ?? this.razaoSocial,
      nomeFantasia: nomeFantasia ?? this.nomeFantasia,
      cnpj: cnpj ?? this.cnpj,
      inscricaoEstadual: inscricaoEstadual ?? this.inscricaoEstadual,
      inscricaoMunicipal: inscricaoMunicipal ?? this.inscricaoMunicipal,
      tipoRegime: tipoRegime ?? this.tipoRegime,
      crt: crt ?? this.crt,
      email: email ?? this.email,
      site: site ?? this.site,
      contato: contato ?? this.contato,
      dataConstituicao: dataConstituicao ?? this.dataConstituicao,
      tipo: tipo ?? this.tipo,
      inscricaoJuntaComercial:
          inscricaoJuntaComercial ?? this.inscricaoJuntaComercial,
      dataInscJuntaComercial:
          dataInscJuntaComercial ?? this.dataInscJuntaComercial,
      codigoIbgeCidade: codigoIbgeCidade ?? this.codigoIbgeCidade,
      codigoIbgeUf: codigoIbgeUf ?? this.codigoIbgeUf,
      cei: cei ?? this.cei,
      codigoCnaePrincipal: codigoCnaePrincipal ?? this.codigoCnaePrincipal,
      imagemLogotipo: imagemLogotipo ?? this.imagemLogotipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (razaoSocial.present) {
      map['razao_social'] = Variable<String>(razaoSocial.value);
    }
    if (nomeFantasia.present) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (inscricaoEstadual.present) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual.value);
    }
    if (inscricaoMunicipal.present) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal.value);
    }
    if (tipoRegime.present) {
      map['tipo_regime'] = Variable<String>(tipoRegime.value);
    }
    if (crt.present) {
      map['crt'] = Variable<String>(crt.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (dataConstituicao.present) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (inscricaoJuntaComercial.present) {
      map['inscricao_junta_comercial'] =
          Variable<String>(inscricaoJuntaComercial.value);
    }
    if (dataInscJuntaComercial.present) {
      map['data_insc_junta_comercial'] =
          Variable<DateTime>(dataInscJuntaComercial.value);
    }
    if (codigoIbgeCidade.present) {
      map['codigo_ibge_cidade'] = Variable<int>(codigoIbgeCidade.value);
    }
    if (codigoIbgeUf.present) {
      map['codigo_ibge_uf'] = Variable<int>(codigoIbgeUf.value);
    }
    if (cei.present) {
      map['cei'] = Variable<String>(cei.value);
    }
    if (codigoCnaePrincipal.present) {
      map['codigo_cnae_principal'] =
          Variable<String>(codigoCnaePrincipal.value);
    }
    if (imagemLogotipo.present) {
      map['imagem_logotipo'] = Variable<String>(imagemLogotipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresasCompanion(')
          ..write('id: $id, ')
          ..write('razaoSocial: $razaoSocial, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('contato: $contato, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipo: $tipo, ')
          ..write('inscricaoJuntaComercial: $inscricaoJuntaComercial, ')
          ..write('dataInscJuntaComercial: $dataInscJuntaComercial, ')
          ..write('codigoIbgeCidade: $codigoIbgeCidade, ')
          ..write('codigoIbgeUf: $codigoIbgeUf, ')
          ..write('cei: $cei, ')
          ..write('codigoCnaePrincipal: $codigoCnaePrincipal, ')
          ..write('imagemLogotipo: $imagemLogotipo')
          ..write(')'))
        .toString();
  }
}

class $AuditoriasTable extends Auditorias
    with TableInfo<$AuditoriasTable, Auditoria> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AuditoriasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataRegistroMeta =
      const VerificationMeta('dataRegistro');
  @override
  late final GeneratedColumn<DateTime> dataRegistro = GeneratedColumn<DateTime>(
      'data_registro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaRegistroMeta =
      const VerificationMeta('horaRegistro');
  @override
  late final GeneratedColumn<String> horaRegistro = GeneratedColumn<String>(
      'hora_registro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _janelaControllerMeta =
      const VerificationMeta('janelaController');
  @override
  late final GeneratedColumn<String> janelaController = GeneratedColumn<String>(
      'janela_controller', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _acaoMeta = const VerificationMeta('acao');
  @override
  late final GeneratedColumn<String> acao = GeneratedColumn<String>(
      'acao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _conteudoMeta =
      const VerificationMeta('conteudo');
  @override
  late final GeneratedColumn<String> conteudo = GeneratedColumn<String>(
      'conteudo', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _tokenJwtMeta =
      const VerificationMeta('tokenJwt');
  @override
  late final GeneratedColumn<String> tokenJwt = GeneratedColumn<String>(
      'token_jwt', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dataRegistro,
        horaRegistro,
        janelaController,
        acao,
        conteudo,
        tokenJwt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'auditoria';
  @override
  VerificationContext validateIntegrity(Insertable<Auditoria> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_registro')) {
      context.handle(
          _dataRegistroMeta,
          dataRegistro.isAcceptableOrUnknown(
              data['data_registro']!, _dataRegistroMeta));
    }
    if (data.containsKey('hora_registro')) {
      context.handle(
          _horaRegistroMeta,
          horaRegistro.isAcceptableOrUnknown(
              data['hora_registro']!, _horaRegistroMeta));
    }
    if (data.containsKey('janela_controller')) {
      context.handle(
          _janelaControllerMeta,
          janelaController.isAcceptableOrUnknown(
              data['janela_controller']!, _janelaControllerMeta));
    }
    if (data.containsKey('acao')) {
      context.handle(
          _acaoMeta, acao.isAcceptableOrUnknown(data['acao']!, _acaoMeta));
    }
    if (data.containsKey('conteudo')) {
      context.handle(_conteudoMeta,
          conteudo.isAcceptableOrUnknown(data['conteudo']!, _conteudoMeta));
    }
    if (data.containsKey('token_jwt')) {
      context.handle(_tokenJwtMeta,
          tokenJwt.isAcceptableOrUnknown(data['token_jwt']!, _tokenJwtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Auditoria map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Auditoria(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_registro']),
      horaRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_registro']),
      janelaController: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}janela_controller']),
      acao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}acao']),
      conteudo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conteudo']),
      tokenJwt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}token_jwt']),
    );
  }

  @override
  $AuditoriasTable createAlias(String alias) {
    return $AuditoriasTable(attachedDatabase, alias);
  }
}

class Auditoria extends DataClass implements Insertable<Auditoria> {
  final int? id;
  final DateTime? dataRegistro;
  final String? horaRegistro;
  final String? janelaController;
  final String? acao;
  final String? conteudo;
  final String? tokenJwt;
  const Auditoria(
      {this.id,
      this.dataRegistro,
      this.horaRegistro,
      this.janelaController,
      this.acao,
      this.conteudo,
      this.tokenJwt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataRegistro != null) {
      map['data_registro'] = Variable<DateTime>(dataRegistro);
    }
    if (!nullToAbsent || horaRegistro != null) {
      map['hora_registro'] = Variable<String>(horaRegistro);
    }
    if (!nullToAbsent || janelaController != null) {
      map['janela_controller'] = Variable<String>(janelaController);
    }
    if (!nullToAbsent || acao != null) {
      map['acao'] = Variable<String>(acao);
    }
    if (!nullToAbsent || conteudo != null) {
      map['conteudo'] = Variable<String>(conteudo);
    }
    if (!nullToAbsent || tokenJwt != null) {
      map['token_jwt'] = Variable<String>(tokenJwt);
    }
    return map;
  }

  factory Auditoria.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Auditoria(
      id: serializer.fromJson<int?>(json['id']),
      dataRegistro: serializer.fromJson<DateTime?>(json['dataRegistro']),
      horaRegistro: serializer.fromJson<String?>(json['horaRegistro']),
      janelaController: serializer.fromJson<String?>(json['janelaController']),
      acao: serializer.fromJson<String?>(json['acao']),
      conteudo: serializer.fromJson<String?>(json['conteudo']),
      tokenJwt: serializer.fromJson<String?>(json['tokenJwt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataRegistro': serializer.toJson<DateTime?>(dataRegistro),
      'horaRegistro': serializer.toJson<String?>(horaRegistro),
      'janelaController': serializer.toJson<String?>(janelaController),
      'acao': serializer.toJson<String?>(acao),
      'conteudo': serializer.toJson<String?>(conteudo),
      'tokenJwt': serializer.toJson<String?>(tokenJwt),
    };
  }

  Auditoria copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataRegistro = const Value.absent(),
          Value<String?> horaRegistro = const Value.absent(),
          Value<String?> janelaController = const Value.absent(),
          Value<String?> acao = const Value.absent(),
          Value<String?> conteudo = const Value.absent(),
          Value<String?> tokenJwt = const Value.absent()}) =>
      Auditoria(
        id: id.present ? id.value : this.id,
        dataRegistro:
            dataRegistro.present ? dataRegistro.value : this.dataRegistro,
        horaRegistro:
            horaRegistro.present ? horaRegistro.value : this.horaRegistro,
        janelaController: janelaController.present
            ? janelaController.value
            : this.janelaController,
        acao: acao.present ? acao.value : this.acao,
        conteudo: conteudo.present ? conteudo.value : this.conteudo,
        tokenJwt: tokenJwt.present ? tokenJwt.value : this.tokenJwt,
      );
  @override
  String toString() {
    return (StringBuffer('Auditoria(')
          ..write('id: $id, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('horaRegistro: $horaRegistro, ')
          ..write('janelaController: $janelaController, ')
          ..write('acao: $acao, ')
          ..write('conteudo: $conteudo, ')
          ..write('tokenJwt: $tokenJwt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataRegistro, horaRegistro,
      janelaController, acao, conteudo, tokenJwt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Auditoria &&
          other.id == this.id &&
          other.dataRegistro == this.dataRegistro &&
          other.horaRegistro == this.horaRegistro &&
          other.janelaController == this.janelaController &&
          other.acao == this.acao &&
          other.conteudo == this.conteudo &&
          other.tokenJwt == this.tokenJwt);
}

class AuditoriasCompanion extends UpdateCompanion<Auditoria> {
  final Value<int?> id;
  final Value<DateTime?> dataRegistro;
  final Value<String?> horaRegistro;
  final Value<String?> janelaController;
  final Value<String?> acao;
  final Value<String?> conteudo;
  final Value<String?> tokenJwt;
  const AuditoriasCompanion({
    this.id = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.horaRegistro = const Value.absent(),
    this.janelaController = const Value.absent(),
    this.acao = const Value.absent(),
    this.conteudo = const Value.absent(),
    this.tokenJwt = const Value.absent(),
  });
  AuditoriasCompanion.insert({
    this.id = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.horaRegistro = const Value.absent(),
    this.janelaController = const Value.absent(),
    this.acao = const Value.absent(),
    this.conteudo = const Value.absent(),
    this.tokenJwt = const Value.absent(),
  });
  static Insertable<Auditoria> custom({
    Expression<int>? id,
    Expression<DateTime>? dataRegistro,
    Expression<String>? horaRegistro,
    Expression<String>? janelaController,
    Expression<String>? acao,
    Expression<String>? conteudo,
    Expression<String>? tokenJwt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataRegistro != null) 'data_registro': dataRegistro,
      if (horaRegistro != null) 'hora_registro': horaRegistro,
      if (janelaController != null) 'janela_controller': janelaController,
      if (acao != null) 'acao': acao,
      if (conteudo != null) 'conteudo': conteudo,
      if (tokenJwt != null) 'token_jwt': tokenJwt,
    });
  }

  AuditoriasCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataRegistro,
      Value<String?>? horaRegistro,
      Value<String?>? janelaController,
      Value<String?>? acao,
      Value<String?>? conteudo,
      Value<String?>? tokenJwt}) {
    return AuditoriasCompanion(
      id: id ?? this.id,
      dataRegistro: dataRegistro ?? this.dataRegistro,
      horaRegistro: horaRegistro ?? this.horaRegistro,
      janelaController: janelaController ?? this.janelaController,
      acao: acao ?? this.acao,
      conteudo: conteudo ?? this.conteudo,
      tokenJwt: tokenJwt ?? this.tokenJwt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataRegistro.present) {
      map['data_registro'] = Variable<DateTime>(dataRegistro.value);
    }
    if (horaRegistro.present) {
      map['hora_registro'] = Variable<String>(horaRegistro.value);
    }
    if (janelaController.present) {
      map['janela_controller'] = Variable<String>(janelaController.value);
    }
    if (acao.present) {
      map['acao'] = Variable<String>(acao.value);
    }
    if (conteudo.present) {
      map['conteudo'] = Variable<String>(conteudo.value);
    }
    if (tokenJwt.present) {
      map['token_jwt'] = Variable<String>(tokenJwt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AuditoriasCompanion(')
          ..write('id: $id, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('horaRegistro: $horaRegistro, ')
          ..write('janelaController: $janelaController, ')
          ..write('acao: $acao, ')
          ..write('conteudo: $conteudo, ')
          ..write('tokenJwt: $tokenJwt')
          ..write(')'))
        .toString();
  }
}

class $UsuarioTokensTable extends UsuarioTokens
    with TableInfo<$UsuarioTokensTable, UsuarioToken> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UsuarioTokensTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tokenMeta = const VerificationMeta('token');
  @override
  late final GeneratedColumn<String> token = GeneratedColumn<String>(
      'token', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _dataCriacaoMeta =
      const VerificationMeta('dataCriacao');
  @override
  late final GeneratedColumn<DateTime> dataCriacao = GeneratedColumn<DateTime>(
      'data_criacao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaCriacaoMeta =
      const VerificationMeta('horaCriacao');
  @override
  late final GeneratedColumn<String> horaCriacao = GeneratedColumn<String>(
      'hora_criacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataExpiracaoMeta =
      const VerificationMeta('dataExpiracao');
  @override
  late final GeneratedColumn<DateTime> dataExpiracao =
      GeneratedColumn<DateTime>('data_expiracao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaExpiracaoMeta =
      const VerificationMeta('horaExpiracao');
  @override
  late final GeneratedColumn<String> horaExpiracao = GeneratedColumn<String>(
      'hora_expiracao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        login,
        token,
        dataCriacao,
        horaCriacao,
        dataExpiracao,
        horaExpiracao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'usuario_token';
  @override
  VerificationContext validateIntegrity(Insertable<UsuarioToken> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('token')) {
      context.handle(
          _tokenMeta, token.isAcceptableOrUnknown(data['token']!, _tokenMeta));
    }
    if (data.containsKey('data_criacao')) {
      context.handle(
          _dataCriacaoMeta,
          dataCriacao.isAcceptableOrUnknown(
              data['data_criacao']!, _dataCriacaoMeta));
    }
    if (data.containsKey('hora_criacao')) {
      context.handle(
          _horaCriacaoMeta,
          horaCriacao.isAcceptableOrUnknown(
              data['hora_criacao']!, _horaCriacaoMeta));
    }
    if (data.containsKey('data_expiracao')) {
      context.handle(
          _dataExpiracaoMeta,
          dataExpiracao.isAcceptableOrUnknown(
              data['data_expiracao']!, _dataExpiracaoMeta));
    }
    if (data.containsKey('hora_expiracao')) {
      context.handle(
          _horaExpiracaoMeta,
          horaExpiracao.isAcceptableOrUnknown(
              data['hora_expiracao']!, _horaExpiracaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  UsuarioToken map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return UsuarioToken(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      token: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}token']),
      dataCriacao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_criacao']),
      horaCriacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_criacao']),
      dataExpiracao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_expiracao']),
      horaExpiracao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_expiracao']),
    );
  }

  @override
  $UsuarioTokensTable createAlias(String alias) {
    return $UsuarioTokensTable(attachedDatabase, alias);
  }
}

class UsuarioToken extends DataClass implements Insertable<UsuarioToken> {
  final int? id;
  final String? login;
  final String? token;
  final DateTime? dataCriacao;
  final String? horaCriacao;
  final DateTime? dataExpiracao;
  final String? horaExpiracao;
  const UsuarioToken(
      {this.id,
      this.login,
      this.token,
      this.dataCriacao,
      this.horaCriacao,
      this.dataExpiracao,
      this.horaExpiracao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || token != null) {
      map['token'] = Variable<String>(token);
    }
    if (!nullToAbsent || dataCriacao != null) {
      map['data_criacao'] = Variable<DateTime>(dataCriacao);
    }
    if (!nullToAbsent || horaCriacao != null) {
      map['hora_criacao'] = Variable<String>(horaCriacao);
    }
    if (!nullToAbsent || dataExpiracao != null) {
      map['data_expiracao'] = Variable<DateTime>(dataExpiracao);
    }
    if (!nullToAbsent || horaExpiracao != null) {
      map['hora_expiracao'] = Variable<String>(horaExpiracao);
    }
    return map;
  }

  factory UsuarioToken.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return UsuarioToken(
      id: serializer.fromJson<int?>(json['id']),
      login: serializer.fromJson<String?>(json['login']),
      token: serializer.fromJson<String?>(json['token']),
      dataCriacao: serializer.fromJson<DateTime?>(json['dataCriacao']),
      horaCriacao: serializer.fromJson<String?>(json['horaCriacao']),
      dataExpiracao: serializer.fromJson<DateTime?>(json['dataExpiracao']),
      horaExpiracao: serializer.fromJson<String?>(json['horaExpiracao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'login': serializer.toJson<String?>(login),
      'token': serializer.toJson<String?>(token),
      'dataCriacao': serializer.toJson<DateTime?>(dataCriacao),
      'horaCriacao': serializer.toJson<String?>(horaCriacao),
      'dataExpiracao': serializer.toJson<DateTime?>(dataExpiracao),
      'horaExpiracao': serializer.toJson<String?>(horaExpiracao),
    };
  }

  UsuarioToken copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> token = const Value.absent(),
          Value<DateTime?> dataCriacao = const Value.absent(),
          Value<String?> horaCriacao = const Value.absent(),
          Value<DateTime?> dataExpiracao = const Value.absent(),
          Value<String?> horaExpiracao = const Value.absent()}) =>
      UsuarioToken(
        id: id.present ? id.value : this.id,
        login: login.present ? login.value : this.login,
        token: token.present ? token.value : this.token,
        dataCriacao: dataCriacao.present ? dataCriacao.value : this.dataCriacao,
        horaCriacao: horaCriacao.present ? horaCriacao.value : this.horaCriacao,
        dataExpiracao:
            dataExpiracao.present ? dataExpiracao.value : this.dataExpiracao,
        horaExpiracao:
            horaExpiracao.present ? horaExpiracao.value : this.horaExpiracao,
      );
  @override
  String toString() {
    return (StringBuffer('UsuarioToken(')
          ..write('id: $id, ')
          ..write('login: $login, ')
          ..write('token: $token, ')
          ..write('dataCriacao: $dataCriacao, ')
          ..write('horaCriacao: $horaCriacao, ')
          ..write('dataExpiracao: $dataExpiracao, ')
          ..write('horaExpiracao: $horaExpiracao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, login, token, dataCriacao, horaCriacao, dataExpiracao, horaExpiracao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is UsuarioToken &&
          other.id == this.id &&
          other.login == this.login &&
          other.token == this.token &&
          other.dataCriacao == this.dataCriacao &&
          other.horaCriacao == this.horaCriacao &&
          other.dataExpiracao == this.dataExpiracao &&
          other.horaExpiracao == this.horaExpiracao);
}

class UsuarioTokensCompanion extends UpdateCompanion<UsuarioToken> {
  final Value<int?> id;
  final Value<String?> login;
  final Value<String?> token;
  final Value<DateTime?> dataCriacao;
  final Value<String?> horaCriacao;
  final Value<DateTime?> dataExpiracao;
  final Value<String?> horaExpiracao;
  const UsuarioTokensCompanion({
    this.id = const Value.absent(),
    this.login = const Value.absent(),
    this.token = const Value.absent(),
    this.dataCriacao = const Value.absent(),
    this.horaCriacao = const Value.absent(),
    this.dataExpiracao = const Value.absent(),
    this.horaExpiracao = const Value.absent(),
  });
  UsuarioTokensCompanion.insert({
    this.id = const Value.absent(),
    this.login = const Value.absent(),
    this.token = const Value.absent(),
    this.dataCriacao = const Value.absent(),
    this.horaCriacao = const Value.absent(),
    this.dataExpiracao = const Value.absent(),
    this.horaExpiracao = const Value.absent(),
  });
  static Insertable<UsuarioToken> custom({
    Expression<int>? id,
    Expression<String>? login,
    Expression<String>? token,
    Expression<DateTime>? dataCriacao,
    Expression<String>? horaCriacao,
    Expression<DateTime>? dataExpiracao,
    Expression<String>? horaExpiracao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (login != null) 'login': login,
      if (token != null) 'token': token,
      if (dataCriacao != null) 'data_criacao': dataCriacao,
      if (horaCriacao != null) 'hora_criacao': horaCriacao,
      if (dataExpiracao != null) 'data_expiracao': dataExpiracao,
      if (horaExpiracao != null) 'hora_expiracao': horaExpiracao,
    });
  }

  UsuarioTokensCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? login,
      Value<String?>? token,
      Value<DateTime?>? dataCriacao,
      Value<String?>? horaCriacao,
      Value<DateTime?>? dataExpiracao,
      Value<String?>? horaExpiracao}) {
    return UsuarioTokensCompanion(
      id: id ?? this.id,
      login: login ?? this.login,
      token: token ?? this.token,
      dataCriacao: dataCriacao ?? this.dataCriacao,
      horaCriacao: horaCriacao ?? this.horaCriacao,
      dataExpiracao: dataExpiracao ?? this.dataExpiracao,
      horaExpiracao: horaExpiracao ?? this.horaExpiracao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (token.present) {
      map['token'] = Variable<String>(token.value);
    }
    if (dataCriacao.present) {
      map['data_criacao'] = Variable<DateTime>(dataCriacao.value);
    }
    if (horaCriacao.present) {
      map['hora_criacao'] = Variable<String>(horaCriacao.value);
    }
    if (dataExpiracao.present) {
      map['data_expiracao'] = Variable<DateTime>(dataExpiracao.value);
    }
    if (horaExpiracao.present) {
      map['hora_expiracao'] = Variable<String>(horaExpiracao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UsuarioTokensCompanion(')
          ..write('id: $id, ')
          ..write('login: $login, ')
          ..write('token: $token, ')
          ..write('dataCriacao: $dataCriacao, ')
          ..write('horaCriacao: $horaCriacao, ')
          ..write('dataExpiracao: $dataExpiracao, ')
          ..write('horaExpiracao: $horaExpiracao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

class $FuncaosTable extends Funcaos with TableInfo<$FuncaosTable, Funcao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FuncaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'funcao';
  @override
  VerificationContext validateIntegrity(Insertable<Funcao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Funcao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Funcao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $FuncaosTable createAlias(String alias) {
    return $FuncaosTable(attachedDatabase, alias);
  }
}

class Funcao extends DataClass implements Insertable<Funcao> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Funcao({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Funcao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Funcao(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Funcao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Funcao(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('Funcao(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Funcao &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class FuncaosCompanion extends UpdateCompanion<Funcao> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const FuncaosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FuncaosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Funcao> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FuncaosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return FuncaosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FuncaosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $UsuariosTable extends Usuarios with TableInfo<$UsuariosTable, Usuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, idPapel, login, senha, administrador, dataCadastro];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'usuario';
  @override
  VerificationContext validateIntegrity(Insertable<Usuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Usuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Usuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
    );
  }

  @override
  $UsuariosTable createAlias(String alias) {
    return $UsuariosTable(attachedDatabase, alias);
  }
}

class Usuario extends DataClass implements Insertable<Usuario> {
  final int? id;
  final int? idColaborador;
  final int? idPapel;
  final String? login;
  final String? senha;
  final String? administrador;
  final DateTime? dataCadastro;
  const Usuario(
      {this.id,
      this.idColaborador,
      this.idPapel,
      this.login,
      this.senha,
      this.administrador,
      this.dataCadastro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Usuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Usuario(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'administrador': serializer.toJson<String?>(administrador),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Usuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent()}) =>
      Usuario(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
      );
  @override
  String toString() {
    return (StringBuffer('Usuario(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPapel: $idPapel, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('administrador: $administrador, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idColaborador, idPapel, login, senha, administrador, dataCadastro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Usuario &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idPapel == this.idPapel &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.administrador == this.administrador &&
          other.dataCadastro == this.dataCadastro);
}

class UsuariosCompanion extends UpdateCompanion<Usuario> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idPapel;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<String?> administrador;
  final Value<DateTime?> dataCadastro;
  const UsuariosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.administrador = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  UsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.administrador = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Usuario> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idPapel,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<String>? administrador,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idPapel != null) 'id_papel': idPapel,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (administrador != null) 'administrador': administrador,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  UsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? idPapel,
      Value<String?>? login,
      Value<String?>? senha,
      Value<String?>? administrador,
      Value<DateTime?>? dataCadastro}) {
    return UsuariosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idPapel: idPapel ?? this.idPapel,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      administrador: administrador ?? this.administrador,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPapel: $idPapel, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('administrador: $administrador, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $CnaesTable extends Cnaes with TableInfo<$CnaesTable, Cnae> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CnaesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _denominacaoMeta =
      const VerificationMeta('denominacao');
  @override
  late final GeneratedColumn<String> denominacao = GeneratedColumn<String>(
      'denominacao', aliasedName, true,
      additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0, maxTextLength: 1000),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, denominacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cnae';
  @override
  VerificationContext validateIntegrity(Insertable<Cnae> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('denominacao')) {
      context.handle(
          _denominacaoMeta,
          denominacao.isAcceptableOrUnknown(
              data['denominacao']!, _denominacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cnae map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cnae(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      denominacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}denominacao']),
    );
  }

  @override
  $CnaesTable createAlias(String alias) {
    return $CnaesTable(attachedDatabase, alias);
  }
}

class Cnae extends DataClass implements Insertable<Cnae> {
  final int? id;
  final String? codigo;
  final String? denominacao;
  const Cnae({this.id, this.codigo, this.denominacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || denominacao != null) {
      map['denominacao'] = Variable<String>(denominacao);
    }
    return map;
  }

  factory Cnae.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cnae(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      denominacao: serializer.fromJson<String?>(json['denominacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'denominacao': serializer.toJson<String?>(denominacao),
    };
  }

  Cnae copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> denominacao = const Value.absent()}) =>
      Cnae(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        denominacao: denominacao.present ? denominacao.value : this.denominacao,
      );
  @override
  String toString() {
    return (StringBuffer('Cnae(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('denominacao: $denominacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, denominacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cnae &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.denominacao == this.denominacao);
}

class CnaesCompanion extends UpdateCompanion<Cnae> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> denominacao;
  const CnaesCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.denominacao = const Value.absent(),
  });
  CnaesCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.denominacao = const Value.absent(),
  });
  static Insertable<Cnae> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? denominacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (denominacao != null) 'denominacao': denominacao,
    });
  }

  CnaesCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? denominacao}) {
    return CnaesCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      denominacao: denominacao ?? this.denominacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (denominacao.present) {
      map['denominacao'] = Variable<String>(denominacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CnaesCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('denominacao: $denominacao')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  _$AppDatabaseManager get managers => _$AppDatabaseManager(this);
  late final $PapelFuncaosTable papelFuncaos = $PapelFuncaosTable(this);
  late final $EmpresaEnderecosTable empresaEnderecos =
      $EmpresaEnderecosTable(this);
  late final $EmpresaContatosTable empresaContatos =
      $EmpresaContatosTable(this);
  late final $EmpresaTelefonesTable empresaTelefones =
      $EmpresaTelefonesTable(this);
  late final $EmpresaCnaesTable empresaCnaes = $EmpresaCnaesTable(this);
  late final $PapelsTable papels = $PapelsTable(this);
  late final $EmpresasTable empresas = $EmpresasTable(this);
  late final $AuditoriasTable auditorias = $AuditoriasTable(this);
  late final $UsuarioTokensTable usuarioTokens = $UsuarioTokensTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final $FuncaosTable funcaos = $FuncaosTable(this);
  late final $UsuariosTable usuarios = $UsuariosTable(this);
  late final $CnaesTable cnaes = $CnaesTable(this);
  late final PapelDao papelDao = PapelDao(this as AppDatabase);
  late final EmpresaDao empresaDao = EmpresaDao(this as AppDatabase);
  late final AuditoriaDao auditoriaDao = AuditoriaDao(this as AppDatabase);
  late final UsuarioTokenDao usuarioTokenDao =
      UsuarioTokenDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  late final FuncaoDao funcaoDao = FuncaoDao(this as AppDatabase);
  late final UsuarioDao usuarioDao = UsuarioDao(this as AppDatabase);
  late final CnaeDao cnaeDao = CnaeDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        papelFuncaos,
        empresaEnderecos,
        empresaContatos,
        empresaTelefones,
        empresaCnaes,
        papels,
        empresas,
        auditorias,
        usuarioTokens,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaColaboradors,
        funcaos,
        usuarios,
        cnaes
      ];
}

typedef $$PapelFuncaosTableInsertCompanionBuilder = PapelFuncaosCompanion
    Function({
  Value<int?> id,
  Value<int?> idPapel,
  Value<int?> idFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$PapelFuncaosTableUpdateCompanionBuilder = PapelFuncaosCompanion
    Function({
  Value<int?> id,
  Value<int?> idPapel,
  Value<int?> idFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$PapelFuncaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PapelFuncaosTable,
    PapelFuncao,
    $$PapelFuncaosTableFilterComposer,
    $$PapelFuncaosTableOrderingComposer,
    $$PapelFuncaosTableProcessedTableManager,
    $$PapelFuncaosTableInsertCompanionBuilder,
    $$PapelFuncaosTableUpdateCompanionBuilder> {
  $$PapelFuncaosTableTableManager(_$AppDatabase db, $PapelFuncaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PapelFuncaosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PapelFuncaosTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$PapelFuncaosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              PapelFuncaosCompanion(
            id: id,
            idPapel: idPapel,
            idFuncao: idFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              PapelFuncaosCompanion.insert(
            id: id,
            idPapel: idPapel,
            idFuncao: idFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$PapelFuncaosTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $PapelFuncaosTable,
    PapelFuncao,
    $$PapelFuncaosTableFilterComposer,
    $$PapelFuncaosTableOrderingComposer,
    $$PapelFuncaosTableProcessedTableManager,
    $$PapelFuncaosTableInsertCompanionBuilder,
    $$PapelFuncaosTableUpdateCompanionBuilder> {
  $$PapelFuncaosTableProcessedTableManager(super.$state);
}

class $$PapelFuncaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PapelFuncaosTable> {
  $$PapelFuncaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PapelFuncaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PapelFuncaosTable> {
  $$PapelFuncaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EmpresaEnderecosTableInsertCompanionBuilder
    = EmpresaEnderecosCompanion Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> uf,
  Value<String?> cep,
  Value<int?> municipioIbge,
  Value<String?> complemento,
  Value<String?> principal,
  Value<String?> entrega,
  Value<String?> cobranca,
  Value<String?> correspondencia,
});
typedef $$EmpresaEnderecosTableUpdateCompanionBuilder
    = EmpresaEnderecosCompanion Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> uf,
  Value<String?> cep,
  Value<int?> municipioIbge,
  Value<String?> complemento,
  Value<String?> principal,
  Value<String?> entrega,
  Value<String?> cobranca,
  Value<String?> correspondencia,
});

class $$EmpresaEnderecosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EmpresaEnderecosTable,
    EmpresaEndereco,
    $$EmpresaEnderecosTableFilterComposer,
    $$EmpresaEnderecosTableOrderingComposer,
    $$EmpresaEnderecosTableProcessedTableManager,
    $$EmpresaEnderecosTableInsertCompanionBuilder,
    $$EmpresaEnderecosTableUpdateCompanionBuilder> {
  $$EmpresaEnderecosTableTableManager(
      _$AppDatabase db, $EmpresaEnderecosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EmpresaEnderecosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EmpresaEnderecosTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$EmpresaEnderecosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<int?> municipioIbge = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> principal = const Value.absent(),
            Value<String?> entrega = const Value.absent(),
            Value<String?> cobranca = const Value.absent(),
            Value<String?> correspondencia = const Value.absent(),
          }) =>
              EmpresaEnderecosCompanion(
            id: id,
            idEmpresa: idEmpresa,
            logradouro: logradouro,
            numero: numero,
            bairro: bairro,
            cidade: cidade,
            uf: uf,
            cep: cep,
            municipioIbge: municipioIbge,
            complemento: complemento,
            principal: principal,
            entrega: entrega,
            cobranca: cobranca,
            correspondencia: correspondencia,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<int?> municipioIbge = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> principal = const Value.absent(),
            Value<String?> entrega = const Value.absent(),
            Value<String?> cobranca = const Value.absent(),
            Value<String?> correspondencia = const Value.absent(),
          }) =>
              EmpresaEnderecosCompanion.insert(
            id: id,
            idEmpresa: idEmpresa,
            logradouro: logradouro,
            numero: numero,
            bairro: bairro,
            cidade: cidade,
            uf: uf,
            cep: cep,
            municipioIbge: municipioIbge,
            complemento: complemento,
            principal: principal,
            entrega: entrega,
            cobranca: cobranca,
            correspondencia: correspondencia,
          ),
        ));
}

class $$EmpresaEnderecosTableProcessedTableManager
    extends ProcessedTableManager<
        _$AppDatabase,
        $EmpresaEnderecosTable,
        EmpresaEndereco,
        $$EmpresaEnderecosTableFilterComposer,
        $$EmpresaEnderecosTableOrderingComposer,
        $$EmpresaEnderecosTableProcessedTableManager,
        $$EmpresaEnderecosTableInsertCompanionBuilder,
        $$EmpresaEnderecosTableUpdateCompanionBuilder> {
  $$EmpresaEnderecosTableProcessedTableManager(super.$state);
}

class $$EmpresaEnderecosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EmpresaEnderecosTable> {
  $$EmpresaEnderecosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get principal => $state.composableBuilder(
      column: $state.table.principal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get entrega => $state.composableBuilder(
      column: $state.table.entrega,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cobranca => $state.composableBuilder(
      column: $state.table.cobranca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get correspondencia => $state.composableBuilder(
      column: $state.table.correspondencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EmpresaEnderecosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EmpresaEnderecosTable> {
  $$EmpresaEnderecosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get principal => $state.composableBuilder(
      column: $state.table.principal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get entrega => $state.composableBuilder(
      column: $state.table.entrega,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cobranca => $state.composableBuilder(
      column: $state.table.cobranca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get correspondencia => $state.composableBuilder(
      column: $state.table.correspondencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EmpresaContatosTableInsertCompanionBuilder = EmpresaContatosCompanion
    Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> nome,
  Value<String?> email,
  Value<String?> observacao,
});
typedef $$EmpresaContatosTableUpdateCompanionBuilder = EmpresaContatosCompanion
    Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> nome,
  Value<String?> email,
  Value<String?> observacao,
});

class $$EmpresaContatosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EmpresaContatosTable,
    EmpresaContato,
    $$EmpresaContatosTableFilterComposer,
    $$EmpresaContatosTableOrderingComposer,
    $$EmpresaContatosTableProcessedTableManager,
    $$EmpresaContatosTableInsertCompanionBuilder,
    $$EmpresaContatosTableUpdateCompanionBuilder> {
  $$EmpresaContatosTableTableManager(
      _$AppDatabase db, $EmpresaContatosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EmpresaContatosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EmpresaContatosTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$EmpresaContatosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              EmpresaContatosCompanion(
            id: id,
            idEmpresa: idEmpresa,
            nome: nome,
            email: email,
            observacao: observacao,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              EmpresaContatosCompanion.insert(
            id: id,
            idEmpresa: idEmpresa,
            nome: nome,
            email: email,
            observacao: observacao,
          ),
        ));
}

class $$EmpresaContatosTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $EmpresaContatosTable,
    EmpresaContato,
    $$EmpresaContatosTableFilterComposer,
    $$EmpresaContatosTableOrderingComposer,
    $$EmpresaContatosTableProcessedTableManager,
    $$EmpresaContatosTableInsertCompanionBuilder,
    $$EmpresaContatosTableUpdateCompanionBuilder> {
  $$EmpresaContatosTableProcessedTableManager(super.$state);
}

class $$EmpresaContatosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EmpresaContatosTable> {
  $$EmpresaContatosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EmpresaContatosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EmpresaContatosTable> {
  $$EmpresaContatosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EmpresaTelefonesTableInsertCompanionBuilder
    = EmpresaTelefonesCompanion Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> tipo,
  Value<String?> numero,
});
typedef $$EmpresaTelefonesTableUpdateCompanionBuilder
    = EmpresaTelefonesCompanion Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<String?> tipo,
  Value<String?> numero,
});

class $$EmpresaTelefonesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EmpresaTelefonesTable,
    EmpresaTelefone,
    $$EmpresaTelefonesTableFilterComposer,
    $$EmpresaTelefonesTableOrderingComposer,
    $$EmpresaTelefonesTableProcessedTableManager,
    $$EmpresaTelefonesTableInsertCompanionBuilder,
    $$EmpresaTelefonesTableUpdateCompanionBuilder> {
  $$EmpresaTelefonesTableTableManager(
      _$AppDatabase db, $EmpresaTelefonesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EmpresaTelefonesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EmpresaTelefonesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$EmpresaTelefonesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> numero = const Value.absent(),
          }) =>
              EmpresaTelefonesCompanion(
            id: id,
            idEmpresa: idEmpresa,
            tipo: tipo,
            numero: numero,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> numero = const Value.absent(),
          }) =>
              EmpresaTelefonesCompanion.insert(
            id: id,
            idEmpresa: idEmpresa,
            tipo: tipo,
            numero: numero,
          ),
        ));
}

class $$EmpresaTelefonesTableProcessedTableManager
    extends ProcessedTableManager<
        _$AppDatabase,
        $EmpresaTelefonesTable,
        EmpresaTelefone,
        $$EmpresaTelefonesTableFilterComposer,
        $$EmpresaTelefonesTableOrderingComposer,
        $$EmpresaTelefonesTableProcessedTableManager,
        $$EmpresaTelefonesTableInsertCompanionBuilder,
        $$EmpresaTelefonesTableUpdateCompanionBuilder> {
  $$EmpresaTelefonesTableProcessedTableManager(super.$state);
}

class $$EmpresaTelefonesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EmpresaTelefonesTable> {
  $$EmpresaTelefonesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EmpresaTelefonesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EmpresaTelefonesTable> {
  $$EmpresaTelefonesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EmpresaCnaesTableInsertCompanionBuilder = EmpresaCnaesCompanion
    Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<int?> idCnae,
  Value<String?> principal,
  Value<String?> ramoAtividade,
  Value<String?> objetoSocial,
});
typedef $$EmpresaCnaesTableUpdateCompanionBuilder = EmpresaCnaesCompanion
    Function({
  Value<int?> id,
  Value<int?> idEmpresa,
  Value<int?> idCnae,
  Value<String?> principal,
  Value<String?> ramoAtividade,
  Value<String?> objetoSocial,
});

class $$EmpresaCnaesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EmpresaCnaesTable,
    EmpresaCnae,
    $$EmpresaCnaesTableFilterComposer,
    $$EmpresaCnaesTableOrderingComposer,
    $$EmpresaCnaesTableProcessedTableManager,
    $$EmpresaCnaesTableInsertCompanionBuilder,
    $$EmpresaCnaesTableUpdateCompanionBuilder> {
  $$EmpresaCnaesTableTableManager(_$AppDatabase db, $EmpresaCnaesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EmpresaCnaesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EmpresaCnaesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$EmpresaCnaesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<int?> idCnae = const Value.absent(),
            Value<String?> principal = const Value.absent(),
            Value<String?> ramoAtividade = const Value.absent(),
            Value<String?> objetoSocial = const Value.absent(),
          }) =>
              EmpresaCnaesCompanion(
            id: id,
            idEmpresa: idEmpresa,
            idCnae: idCnae,
            principal: principal,
            ramoAtividade: ramoAtividade,
            objetoSocial: objetoSocial,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idEmpresa = const Value.absent(),
            Value<int?> idCnae = const Value.absent(),
            Value<String?> principal = const Value.absent(),
            Value<String?> ramoAtividade = const Value.absent(),
            Value<String?> objetoSocial = const Value.absent(),
          }) =>
              EmpresaCnaesCompanion.insert(
            id: id,
            idEmpresa: idEmpresa,
            idCnae: idCnae,
            principal: principal,
            ramoAtividade: ramoAtividade,
            objetoSocial: objetoSocial,
          ),
        ));
}

class $$EmpresaCnaesTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $EmpresaCnaesTable,
    EmpresaCnae,
    $$EmpresaCnaesTableFilterComposer,
    $$EmpresaCnaesTableOrderingComposer,
    $$EmpresaCnaesTableProcessedTableManager,
    $$EmpresaCnaesTableInsertCompanionBuilder,
    $$EmpresaCnaesTableUpdateCompanionBuilder> {
  $$EmpresaCnaesTableProcessedTableManager(super.$state);
}

class $$EmpresaCnaesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EmpresaCnaesTable> {
  $$EmpresaCnaesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCnae => $state.composableBuilder(
      column: $state.table.idCnae,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get principal => $state.composableBuilder(
      column: $state.table.principal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ramoAtividade => $state.composableBuilder(
      column: $state.table.ramoAtividade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get objetoSocial => $state.composableBuilder(
      column: $state.table.objetoSocial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EmpresaCnaesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EmpresaCnaesTable> {
  $$EmpresaCnaesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idEmpresa => $state.composableBuilder(
      column: $state.table.idEmpresa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCnae => $state.composableBuilder(
      column: $state.table.idCnae,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get principal => $state.composableBuilder(
      column: $state.table.principal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ramoAtividade => $state.composableBuilder(
      column: $state.table.ramoAtividade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get objetoSocial => $state.composableBuilder(
      column: $state.table.objetoSocial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PapelsTableInsertCompanionBuilder = PapelsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$PapelsTableUpdateCompanionBuilder = PapelsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$PapelsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PapelsTable,
    Papel,
    $$PapelsTableFilterComposer,
    $$PapelsTableOrderingComposer,
    $$PapelsTableProcessedTableManager,
    $$PapelsTableInsertCompanionBuilder,
    $$PapelsTableUpdateCompanionBuilder> {
  $$PapelsTableTableManager(_$AppDatabase db, $PapelsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PapelsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PapelsTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$PapelsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PapelsCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              PapelsCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$PapelsTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $PapelsTable,
    Papel,
    $$PapelsTableFilterComposer,
    $$PapelsTableOrderingComposer,
    $$PapelsTableProcessedTableManager,
    $$PapelsTableInsertCompanionBuilder,
    $$PapelsTableUpdateCompanionBuilder> {
  $$PapelsTableProcessedTableManager(super.$state);
}

class $$PapelsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PapelsTable> {
  $$PapelsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PapelsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PapelsTable> {
  $$PapelsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EmpresasTableInsertCompanionBuilder = EmpresasCompanion Function({
  Value<int?> id,
  Value<String?> razaoSocial,
  Value<String?> nomeFantasia,
  Value<String?> cnpj,
  Value<String?> inscricaoEstadual,
  Value<String?> inscricaoMunicipal,
  Value<String?> tipoRegime,
  Value<String?> crt,
  Value<String?> email,
  Value<String?> site,
  Value<String?> contato,
  Value<DateTime?> dataConstituicao,
  Value<String?> tipo,
  Value<String?> inscricaoJuntaComercial,
  Value<DateTime?> dataInscJuntaComercial,
  Value<int?> codigoIbgeCidade,
  Value<int?> codigoIbgeUf,
  Value<String?> cei,
  Value<String?> codigoCnaePrincipal,
  Value<String?> imagemLogotipo,
});
typedef $$EmpresasTableUpdateCompanionBuilder = EmpresasCompanion Function({
  Value<int?> id,
  Value<String?> razaoSocial,
  Value<String?> nomeFantasia,
  Value<String?> cnpj,
  Value<String?> inscricaoEstadual,
  Value<String?> inscricaoMunicipal,
  Value<String?> tipoRegime,
  Value<String?> crt,
  Value<String?> email,
  Value<String?> site,
  Value<String?> contato,
  Value<DateTime?> dataConstituicao,
  Value<String?> tipo,
  Value<String?> inscricaoJuntaComercial,
  Value<DateTime?> dataInscJuntaComercial,
  Value<int?> codigoIbgeCidade,
  Value<int?> codigoIbgeUf,
  Value<String?> cei,
  Value<String?> codigoCnaePrincipal,
  Value<String?> imagemLogotipo,
});

class $$EmpresasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EmpresasTable,
    Empresa,
    $$EmpresasTableFilterComposer,
    $$EmpresasTableOrderingComposer,
    $$EmpresasTableProcessedTableManager,
    $$EmpresasTableInsertCompanionBuilder,
    $$EmpresasTableUpdateCompanionBuilder> {
  $$EmpresasTableTableManager(_$AppDatabase db, $EmpresasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EmpresasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EmpresasTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$EmpresasTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> razaoSocial = const Value.absent(),
            Value<String?> nomeFantasia = const Value.absent(),
            Value<String?> cnpj = const Value.absent(),
            Value<String?> inscricaoEstadual = const Value.absent(),
            Value<String?> inscricaoMunicipal = const Value.absent(),
            Value<String?> tipoRegime = const Value.absent(),
            Value<String?> crt = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> contato = const Value.absent(),
            Value<DateTime?> dataConstituicao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> inscricaoJuntaComercial = const Value.absent(),
            Value<DateTime?> dataInscJuntaComercial = const Value.absent(),
            Value<int?> codigoIbgeCidade = const Value.absent(),
            Value<int?> codigoIbgeUf = const Value.absent(),
            Value<String?> cei = const Value.absent(),
            Value<String?> codigoCnaePrincipal = const Value.absent(),
            Value<String?> imagemLogotipo = const Value.absent(),
          }) =>
              EmpresasCompanion(
            id: id,
            razaoSocial: razaoSocial,
            nomeFantasia: nomeFantasia,
            cnpj: cnpj,
            inscricaoEstadual: inscricaoEstadual,
            inscricaoMunicipal: inscricaoMunicipal,
            tipoRegime: tipoRegime,
            crt: crt,
            email: email,
            site: site,
            contato: contato,
            dataConstituicao: dataConstituicao,
            tipo: tipo,
            inscricaoJuntaComercial: inscricaoJuntaComercial,
            dataInscJuntaComercial: dataInscJuntaComercial,
            codigoIbgeCidade: codigoIbgeCidade,
            codigoIbgeUf: codigoIbgeUf,
            cei: cei,
            codigoCnaePrincipal: codigoCnaePrincipal,
            imagemLogotipo: imagemLogotipo,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> razaoSocial = const Value.absent(),
            Value<String?> nomeFantasia = const Value.absent(),
            Value<String?> cnpj = const Value.absent(),
            Value<String?> inscricaoEstadual = const Value.absent(),
            Value<String?> inscricaoMunicipal = const Value.absent(),
            Value<String?> tipoRegime = const Value.absent(),
            Value<String?> crt = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> contato = const Value.absent(),
            Value<DateTime?> dataConstituicao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> inscricaoJuntaComercial = const Value.absent(),
            Value<DateTime?> dataInscJuntaComercial = const Value.absent(),
            Value<int?> codigoIbgeCidade = const Value.absent(),
            Value<int?> codigoIbgeUf = const Value.absent(),
            Value<String?> cei = const Value.absent(),
            Value<String?> codigoCnaePrincipal = const Value.absent(),
            Value<String?> imagemLogotipo = const Value.absent(),
          }) =>
              EmpresasCompanion.insert(
            id: id,
            razaoSocial: razaoSocial,
            nomeFantasia: nomeFantasia,
            cnpj: cnpj,
            inscricaoEstadual: inscricaoEstadual,
            inscricaoMunicipal: inscricaoMunicipal,
            tipoRegime: tipoRegime,
            crt: crt,
            email: email,
            site: site,
            contato: contato,
            dataConstituicao: dataConstituicao,
            tipo: tipo,
            inscricaoJuntaComercial: inscricaoJuntaComercial,
            dataInscJuntaComercial: dataInscJuntaComercial,
            codigoIbgeCidade: codigoIbgeCidade,
            codigoIbgeUf: codigoIbgeUf,
            cei: cei,
            codigoCnaePrincipal: codigoCnaePrincipal,
            imagemLogotipo: imagemLogotipo,
          ),
        ));
}

class $$EmpresasTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $EmpresasTable,
    Empresa,
    $$EmpresasTableFilterComposer,
    $$EmpresasTableOrderingComposer,
    $$EmpresasTableProcessedTableManager,
    $$EmpresasTableInsertCompanionBuilder,
    $$EmpresasTableUpdateCompanionBuilder> {
  $$EmpresasTableProcessedTableManager(super.$state);
}

class $$EmpresasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EmpresasTable> {
  $$EmpresasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get razaoSocial => $state.composableBuilder(
      column: $state.table.razaoSocial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nomeFantasia => $state.composableBuilder(
      column: $state.table.nomeFantasia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cnpj => $state.composableBuilder(
      column: $state.table.cnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get inscricaoEstadual => $state.composableBuilder(
      column: $state.table.inscricaoEstadual,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get inscricaoMunicipal => $state.composableBuilder(
      column: $state.table.inscricaoMunicipal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoRegime => $state.composableBuilder(
      column: $state.table.tipoRegime,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get crt => $state.composableBuilder(
      column: $state.table.crt,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contato => $state.composableBuilder(
      column: $state.table.contato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataConstituicao => $state.composableBuilder(
      column: $state.table.dataConstituicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get inscricaoJuntaComercial => $state.composableBuilder(
      column: $state.table.inscricaoJuntaComercial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInscJuntaComercial =>
      $state.composableBuilder(
          column: $state.table.dataInscJuntaComercial,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get codigoIbgeCidade => $state.composableBuilder(
      column: $state.table.codigoIbgeCidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get codigoIbgeUf => $state.composableBuilder(
      column: $state.table.codigoIbgeUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cei => $state.composableBuilder(
      column: $state.table.cei,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoCnaePrincipal => $state.composableBuilder(
      column: $state.table.codigoCnaePrincipal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get imagemLogotipo => $state.composableBuilder(
      column: $state.table.imagemLogotipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EmpresasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EmpresasTable> {
  $$EmpresasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get razaoSocial => $state.composableBuilder(
      column: $state.table.razaoSocial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nomeFantasia => $state.composableBuilder(
      column: $state.table.nomeFantasia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cnpj => $state.composableBuilder(
      column: $state.table.cnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get inscricaoEstadual => $state.composableBuilder(
      column: $state.table.inscricaoEstadual,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get inscricaoMunicipal => $state.composableBuilder(
      column: $state.table.inscricaoMunicipal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoRegime => $state.composableBuilder(
      column: $state.table.tipoRegime,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get crt => $state.composableBuilder(
      column: $state.table.crt,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contato => $state.composableBuilder(
      column: $state.table.contato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataConstituicao => $state.composableBuilder(
      column: $state.table.dataConstituicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get inscricaoJuntaComercial =>
      $state.composableBuilder(
          column: $state.table.inscricaoJuntaComercial,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInscJuntaComercial =>
      $state.composableBuilder(
          column: $state.table.dataInscJuntaComercial,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get codigoIbgeCidade => $state.composableBuilder(
      column: $state.table.codigoIbgeCidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get codigoIbgeUf => $state.composableBuilder(
      column: $state.table.codigoIbgeUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cei => $state.composableBuilder(
      column: $state.table.cei,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoCnaePrincipal => $state.composableBuilder(
      column: $state.table.codigoCnaePrincipal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get imagemLogotipo => $state.composableBuilder(
      column: $state.table.imagemLogotipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$AuditoriasTableInsertCompanionBuilder = AuditoriasCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataRegistro,
  Value<String?> horaRegistro,
  Value<String?> janelaController,
  Value<String?> acao,
  Value<String?> conteudo,
  Value<String?> tokenJwt,
});
typedef $$AuditoriasTableUpdateCompanionBuilder = AuditoriasCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataRegistro,
  Value<String?> horaRegistro,
  Value<String?> janelaController,
  Value<String?> acao,
  Value<String?> conteudo,
  Value<String?> tokenJwt,
});

class $$AuditoriasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AuditoriasTable,
    Auditoria,
    $$AuditoriasTableFilterComposer,
    $$AuditoriasTableOrderingComposer,
    $$AuditoriasTableProcessedTableManager,
    $$AuditoriasTableInsertCompanionBuilder,
    $$AuditoriasTableUpdateCompanionBuilder> {
  $$AuditoriasTableTableManager(_$AppDatabase db, $AuditoriasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$AuditoriasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$AuditoriasTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$AuditoriasTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataRegistro = const Value.absent(),
            Value<String?> horaRegistro = const Value.absent(),
            Value<String?> janelaController = const Value.absent(),
            Value<String?> acao = const Value.absent(),
            Value<String?> conteudo = const Value.absent(),
            Value<String?> tokenJwt = const Value.absent(),
          }) =>
              AuditoriasCompanion(
            id: id,
            dataRegistro: dataRegistro,
            horaRegistro: horaRegistro,
            janelaController: janelaController,
            acao: acao,
            conteudo: conteudo,
            tokenJwt: tokenJwt,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataRegistro = const Value.absent(),
            Value<String?> horaRegistro = const Value.absent(),
            Value<String?> janelaController = const Value.absent(),
            Value<String?> acao = const Value.absent(),
            Value<String?> conteudo = const Value.absent(),
            Value<String?> tokenJwt = const Value.absent(),
          }) =>
              AuditoriasCompanion.insert(
            id: id,
            dataRegistro: dataRegistro,
            horaRegistro: horaRegistro,
            janelaController: janelaController,
            acao: acao,
            conteudo: conteudo,
            tokenJwt: tokenJwt,
          ),
        ));
}

class $$AuditoriasTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $AuditoriasTable,
    Auditoria,
    $$AuditoriasTableFilterComposer,
    $$AuditoriasTableOrderingComposer,
    $$AuditoriasTableProcessedTableManager,
    $$AuditoriasTableInsertCompanionBuilder,
    $$AuditoriasTableUpdateCompanionBuilder> {
  $$AuditoriasTableProcessedTableManager(super.$state);
}

class $$AuditoriasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $AuditoriasTable> {
  $$AuditoriasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataRegistro => $state.composableBuilder(
      column: $state.table.dataRegistro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaRegistro => $state.composableBuilder(
      column: $state.table.horaRegistro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get janelaController => $state.composableBuilder(
      column: $state.table.janelaController,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get acao => $state.composableBuilder(
      column: $state.table.acao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get conteudo => $state.composableBuilder(
      column: $state.table.conteudo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tokenJwt => $state.composableBuilder(
      column: $state.table.tokenJwt,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$AuditoriasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $AuditoriasTable> {
  $$AuditoriasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataRegistro => $state.composableBuilder(
      column: $state.table.dataRegistro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaRegistro => $state.composableBuilder(
      column: $state.table.horaRegistro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get janelaController => $state.composableBuilder(
      column: $state.table.janelaController,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get acao => $state.composableBuilder(
      column: $state.table.acao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get conteudo => $state.composableBuilder(
      column: $state.table.conteudo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tokenJwt => $state.composableBuilder(
      column: $state.table.tokenJwt,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$UsuarioTokensTableInsertCompanionBuilder = UsuarioTokensCompanion
    Function({
  Value<int?> id,
  Value<String?> login,
  Value<String?> token,
  Value<DateTime?> dataCriacao,
  Value<String?> horaCriacao,
  Value<DateTime?> dataExpiracao,
  Value<String?> horaExpiracao,
});
typedef $$UsuarioTokensTableUpdateCompanionBuilder = UsuarioTokensCompanion
    Function({
  Value<int?> id,
  Value<String?> login,
  Value<String?> token,
  Value<DateTime?> dataCriacao,
  Value<String?> horaCriacao,
  Value<DateTime?> dataExpiracao,
  Value<String?> horaExpiracao,
});

class $$UsuarioTokensTableTableManager extends RootTableManager<
    _$AppDatabase,
    $UsuarioTokensTable,
    UsuarioToken,
    $$UsuarioTokensTableFilterComposer,
    $$UsuarioTokensTableOrderingComposer,
    $$UsuarioTokensTableProcessedTableManager,
    $$UsuarioTokensTableInsertCompanionBuilder,
    $$UsuarioTokensTableUpdateCompanionBuilder> {
  $$UsuarioTokensTableTableManager(_$AppDatabase db, $UsuarioTokensTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$UsuarioTokensTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$UsuarioTokensTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$UsuarioTokensTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> token = const Value.absent(),
            Value<DateTime?> dataCriacao = const Value.absent(),
            Value<String?> horaCriacao = const Value.absent(),
            Value<DateTime?> dataExpiracao = const Value.absent(),
            Value<String?> horaExpiracao = const Value.absent(),
          }) =>
              UsuarioTokensCompanion(
            id: id,
            login: login,
            token: token,
            dataCriacao: dataCriacao,
            horaCriacao: horaCriacao,
            dataExpiracao: dataExpiracao,
            horaExpiracao: horaExpiracao,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> token = const Value.absent(),
            Value<DateTime?> dataCriacao = const Value.absent(),
            Value<String?> horaCriacao = const Value.absent(),
            Value<DateTime?> dataExpiracao = const Value.absent(),
            Value<String?> horaExpiracao = const Value.absent(),
          }) =>
              UsuarioTokensCompanion.insert(
            id: id,
            login: login,
            token: token,
            dataCriacao: dataCriacao,
            horaCriacao: horaCriacao,
            dataExpiracao: dataExpiracao,
            horaExpiracao: horaExpiracao,
          ),
        ));
}

class $$UsuarioTokensTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $UsuarioTokensTable,
    UsuarioToken,
    $$UsuarioTokensTableFilterComposer,
    $$UsuarioTokensTableOrderingComposer,
    $$UsuarioTokensTableProcessedTableManager,
    $$UsuarioTokensTableInsertCompanionBuilder,
    $$UsuarioTokensTableUpdateCompanionBuilder> {
  $$UsuarioTokensTableProcessedTableManager(super.$state);
}

class $$UsuarioTokensTableFilterComposer
    extends FilterComposer<_$AppDatabase, $UsuarioTokensTable> {
  $$UsuarioTokensTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get token => $state.composableBuilder(
      column: $state.table.token,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCriacao => $state.composableBuilder(
      column: $state.table.dataCriacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaCriacao => $state.composableBuilder(
      column: $state.table.horaCriacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataExpiracao => $state.composableBuilder(
      column: $state.table.dataExpiracao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaExpiracao => $state.composableBuilder(
      column: $state.table.horaExpiracao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$UsuarioTokensTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $UsuarioTokensTable> {
  $$UsuarioTokensTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get token => $state.composableBuilder(
      column: $state.table.token,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCriacao => $state.composableBuilder(
      column: $state.table.dataCriacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaCriacao => $state.composableBuilder(
      column: $state.table.horaCriacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataExpiracao => $state.composableBuilder(
      column: $state.table.dataExpiracao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaExpiracao => $state.composableBuilder(
      column: $state.table.horaExpiracao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableInsertCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableProcessedTableManager,
    $$ViewControleAcessosTableInsertCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ViewControleAcessosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableProcessedTableManager
    extends ProcessedTableManager<
        _$AppDatabase,
        $ViewControleAcessosTable,
        ViewControleAcesso,
        $$ViewControleAcessosTableFilterComposer,
        $$ViewControleAcessosTableOrderingComposer,
        $$ViewControleAcessosTableProcessedTableManager,
        $$ViewControleAcessosTableInsertCompanionBuilder,
        $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableProcessedTableManager(super.$state);
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableInsertCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableProcessedTableManager,
    $$ViewPessoaUsuariosTableInsertCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ViewPessoaUsuariosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableProcessedTableManager
    extends ProcessedTableManager<
        _$AppDatabase,
        $ViewPessoaUsuariosTable,
        ViewPessoaUsuario,
        $$ViewPessoaUsuariosTableFilterComposer,
        $$ViewPessoaUsuariosTableOrderingComposer,
        $$ViewPessoaUsuariosTableProcessedTableManager,
        $$ViewPessoaUsuariosTableInsertCompanionBuilder,
        $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableProcessedTableManager(super.$state);
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaColaboradorsTableInsertCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});

class $$ViewPessoaColaboradorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaColaboradorsTable,
    ViewPessoaColaborador,
    $$ViewPessoaColaboradorsTableFilterComposer,
    $$ViewPessoaColaboradorsTableOrderingComposer,
    $$ViewPessoaColaboradorsTableProcessedTableManager,
    $$ViewPessoaColaboradorsTableInsertCompanionBuilder,
    $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableTableManager(
      _$AppDatabase db, $ViewPessoaColaboradorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaColaboradorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaColaboradorsTableOrderingComposer(
              ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$ViewPessoaColaboradorsTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
        ));
}

class $$ViewPessoaColaboradorsTableProcessedTableManager
    extends ProcessedTableManager<
        _$AppDatabase,
        $ViewPessoaColaboradorsTable,
        ViewPessoaColaborador,
        $$ViewPessoaColaboradorsTableFilterComposer,
        $$ViewPessoaColaboradorsTableOrderingComposer,
        $$ViewPessoaColaboradorsTableProcessedTableManager,
        $$ViewPessoaColaboradorsTableInsertCompanionBuilder,
        $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableProcessedTableManager(super.$state);
}

class $$ViewPessoaColaboradorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FuncaosTableInsertCompanionBuilder = FuncaosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$FuncaosTableUpdateCompanionBuilder = FuncaosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$FuncaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FuncaosTable,
    Funcao,
    $$FuncaosTableFilterComposer,
    $$FuncaosTableOrderingComposer,
    $$FuncaosTableProcessedTableManager,
    $$FuncaosTableInsertCompanionBuilder,
    $$FuncaosTableUpdateCompanionBuilder> {
  $$FuncaosTableTableManager(_$AppDatabase db, $FuncaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FuncaosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$FuncaosTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$FuncaosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              FuncaosCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              FuncaosCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$FuncaosTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $FuncaosTable,
    Funcao,
    $$FuncaosTableFilterComposer,
    $$FuncaosTableOrderingComposer,
    $$FuncaosTableProcessedTableManager,
    $$FuncaosTableInsertCompanionBuilder,
    $$FuncaosTableUpdateCompanionBuilder> {
  $$FuncaosTableProcessedTableManager(super.$state);
}

class $$FuncaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FuncaosTable> {
  $$FuncaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FuncaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FuncaosTable> {
  $$FuncaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$UsuariosTableInsertCompanionBuilder = UsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idColaborador,
  Value<int?> idPapel,
  Value<String?> login,
  Value<String?> senha,
  Value<String?> administrador,
  Value<DateTime?> dataCadastro,
});
typedef $$UsuariosTableUpdateCompanionBuilder = UsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idColaborador,
  Value<int?> idPapel,
  Value<String?> login,
  Value<String?> senha,
  Value<String?> administrador,
  Value<DateTime?> dataCadastro,
});

class $$UsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $UsuariosTable,
    Usuario,
    $$UsuariosTableFilterComposer,
    $$UsuariosTableOrderingComposer,
    $$UsuariosTableProcessedTableManager,
    $$UsuariosTableInsertCompanionBuilder,
    $$UsuariosTableUpdateCompanionBuilder> {
  $$UsuariosTableTableManager(_$AppDatabase db, $UsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$UsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$UsuariosTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) =>
              $$UsuariosTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
          }) =>
              UsuariosCompanion(
            id: id,
            idColaborador: idColaborador,
            idPapel: idPapel,
            login: login,
            senha: senha,
            administrador: administrador,
            dataCadastro: dataCadastro,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
          }) =>
              UsuariosCompanion.insert(
            id: id,
            idColaborador: idColaborador,
            idPapel: idPapel,
            login: login,
            senha: senha,
            administrador: administrador,
            dataCadastro: dataCadastro,
          ),
        ));
}

class $$UsuariosTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $UsuariosTable,
    Usuario,
    $$UsuariosTableFilterComposer,
    $$UsuariosTableOrderingComposer,
    $$UsuariosTableProcessedTableManager,
    $$UsuariosTableInsertCompanionBuilder,
    $$UsuariosTableUpdateCompanionBuilder> {
  $$UsuariosTableProcessedTableManager(super.$state);
}

class $$UsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $UsuariosTable> {
  $$UsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$UsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $UsuariosTable> {
  $$UsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CnaesTableInsertCompanionBuilder = CnaesCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> denominacao,
});
typedef $$CnaesTableUpdateCompanionBuilder = CnaesCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> denominacao,
});

class $$CnaesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CnaesTable,
    Cnae,
    $$CnaesTableFilterComposer,
    $$CnaesTableOrderingComposer,
    $$CnaesTableProcessedTableManager,
    $$CnaesTableInsertCompanionBuilder,
    $$CnaesTableUpdateCompanionBuilder> {
  $$CnaesTableTableManager(_$AppDatabase db, $CnaesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CnaesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CnaesTableOrderingComposer(ComposerState(db, table)),
          getChildManagerBuilder: (p) => $$CnaesTableProcessedTableManager(p),
          getUpdateCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> denominacao = const Value.absent(),
          }) =>
              CnaesCompanion(
            id: id,
            codigo: codigo,
            denominacao: denominacao,
          ),
          getInsertCompanionBuilder: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> denominacao = const Value.absent(),
          }) =>
              CnaesCompanion.insert(
            id: id,
            codigo: codigo,
            denominacao: denominacao,
          ),
        ));
}

class $$CnaesTableProcessedTableManager extends ProcessedTableManager<
    _$AppDatabase,
    $CnaesTable,
    Cnae,
    $$CnaesTableFilterComposer,
    $$CnaesTableOrderingComposer,
    $$CnaesTableProcessedTableManager,
    $$CnaesTableInsertCompanionBuilder,
    $$CnaesTableUpdateCompanionBuilder> {
  $$CnaesTableProcessedTableManager(super.$state);
}

class $$CnaesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $CnaesTable> {
  $$CnaesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get denominacao => $state.composableBuilder(
      column: $state.table.denominacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CnaesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $CnaesTable> {
  $$CnaesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get denominacao => $state.composableBuilder(
      column: $state.table.denominacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class _$AppDatabaseManager {
  final _$AppDatabase _db;
  _$AppDatabaseManager(this._db);
  $$PapelFuncaosTableTableManager get papelFuncaos =>
      $$PapelFuncaosTableTableManager(_db, _db.papelFuncaos);
  $$EmpresaEnderecosTableTableManager get empresaEnderecos =>
      $$EmpresaEnderecosTableTableManager(_db, _db.empresaEnderecos);
  $$EmpresaContatosTableTableManager get empresaContatos =>
      $$EmpresaContatosTableTableManager(_db, _db.empresaContatos);
  $$EmpresaTelefonesTableTableManager get empresaTelefones =>
      $$EmpresaTelefonesTableTableManager(_db, _db.empresaTelefones);
  $$EmpresaCnaesTableTableManager get empresaCnaes =>
      $$EmpresaCnaesTableTableManager(_db, _db.empresaCnaes);
  $$PapelsTableTableManager get papels =>
      $$PapelsTableTableManager(_db, _db.papels);
  $$EmpresasTableTableManager get empresas =>
      $$EmpresasTableTableManager(_db, _db.empresas);
  $$AuditoriasTableTableManager get auditorias =>
      $$AuditoriasTableTableManager(_db, _db.auditorias);
  $$UsuarioTokensTableTableManager get usuarioTokens =>
      $$UsuarioTokensTableTableManager(_db, _db.usuarioTokens);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
          _db, _db.viewPessoaColaboradors);
  $$FuncaosTableTableManager get funcaos =>
      $$FuncaosTableTableManager(_db, _db.funcaos);
  $$UsuariosTableTableManager get usuarios =>
      $$UsuariosTableTableManager(_db, _db.usuarios);
  $$CnaesTableTableManager get cnaes =>
      $$CnaesTableTableManager(_db, _db.cnaes);
}
