// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'papel_dao.dart';

// ignore_for_file: type=lint
mixin _$PapelDaoMixin on DatabaseAccessor<AppDatabase> {
  $PapelsTable get papels => attachedDatabase.papels;
  $PapelFuncaosTable get papelFuncaos => attachedDatabase.papelFuncaos;
  $FuncaosTable get funcaos => attachedDatabase.funcaos;
}
