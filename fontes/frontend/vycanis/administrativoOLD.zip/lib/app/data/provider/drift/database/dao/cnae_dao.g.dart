// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cnae_dao.dart';

// ignore_for_file: type=lint
mixin _$CnaeDaoMixin on DatabaseAccessor<AppDatabase> {
  $CnaesTable get cnaes => attachedDatabase.cnaes;
}
