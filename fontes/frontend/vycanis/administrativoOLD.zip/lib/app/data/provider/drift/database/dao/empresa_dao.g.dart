// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'empresa_dao.dart';

// ignore_for_file: type=lint
mixin _$EmpresaDaoMixin on DatabaseAccessor<AppDatabase> {
  $EmpresasTable get empresas => attachedDatabase.empresas;
  $EmpresaEnderecosTable get empresaEnderecos =>
      attachedDatabase.empresaEnderecos;
  $EmpresaContatosTable get empresaContatos => attachedDatabase.empresaContatos;
  $EmpresaTelefonesTable get empresaTelefones =>
      attachedDatabase.empresaTelefones;
  $EmpresaCnaesTable get empresaCnaes => attachedDatabase.empresaCnaes;
  $CnaesTable get cnaes => attachedDatabase.cnaes;
}
