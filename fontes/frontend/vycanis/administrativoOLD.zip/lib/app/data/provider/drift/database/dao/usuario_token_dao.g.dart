// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'usuario_token_dao.dart';

// ignore_for_file: type=lint
mixin _$UsuarioTokenDaoMixin on DatabaseAccessor<AppDatabase> {
  $UsuarioTokensTable get usuarioTokens => attachedDatabase.usuarioTokens;
}
