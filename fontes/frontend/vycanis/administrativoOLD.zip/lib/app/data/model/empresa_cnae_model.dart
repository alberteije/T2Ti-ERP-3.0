import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:administrativo/app/data/domain/domain_imports.dart';

class EmpresaCnaeModel {
	int? id;
	int? idEmpresa;
	int? idCnae;
	String? principal;
	String? ramoAtividade;
	String? objetoSocial;
	CnaeModel? cnaeModel;

	EmpresaCnaeModel({
		this.id,
		this.idEmpresa,
		this.idCnae,
		this.principal,
		this.ramoAtividade,
		this.objetoSocial,
		this.cnaeModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'principal',
		'ramo_atividade',
		'objeto_social',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Principal',
		'Ramo Atividade',
		'Objeto Social',
	];

	EmpresaCnaeModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idEmpresa = jsonData['idEmpresa'];
		principal = EmpresaCnaeDomain.getPrincipal(jsonData['principal']);
		ramoAtividade = jsonData['ramoAtividade'];
		objetoSocial = jsonData['objetoSocial'];
		cnaeModel = jsonData['cnaeModel'] == null ? CnaeModel() : CnaeModel.fromJson(jsonData['cnaeModel']);
		idCnae = cnaeModel!.id;
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idEmpresa'] = idEmpresa != 0 ? idEmpresa : null;
		jsonData['idCnae'] = idCnae != 0 ? idCnae : null;
		jsonData['principal'] = EmpresaCnaeDomain.setPrincipal(principal);
		jsonData['ramoAtividade'] = ramoAtividade;
		jsonData['objetoSocial'] = objetoSocial;
		jsonData['cnaeModel'] = cnaeModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idEmpresa = plutoRow.cells['idEmpresa']?.value;
		idCnae = plutoRow.cells['idCnae']?.value;
		principal = plutoRow.cells['principal']?.value != '' ? plutoRow.cells['principal']?.value : 'Não';
		ramoAtividade = plutoRow.cells['ramoAtividade']?.value;
		objetoSocial = plutoRow.cells['objetoSocial']?.value;
		cnaeModel = CnaeModel();
		cnaeModel?.codigo = plutoRow.cells['cnae']?.value;
		cnaeModel?.id = plutoRow.cells['idCnae']?.value;
	}	

	EmpresaCnaeModel clone() {
		return EmpresaCnaeModel(
			id: id,
			idEmpresa: idEmpresa,
			idCnae: idCnae,
			principal: principal,
			ramoAtividade: ramoAtividade,
			objetoSocial: objetoSocial,
		);			
	}

	
}