import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/data/domain/domain_imports.dart';

class EmpresaTelefoneModel {
	int? id;
	int? idEmpresa;
	String? tipo;
	String? numero;

	EmpresaTelefoneModel({
		this.id,
		this.idEmpresa,
		this.tipo,
		this.numero,
	});

	static List<String> dbColumns = <String>[
		'id',
		'tipo',
		'numero',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Tipo',
		'Numero',
	];

	EmpresaTelefoneModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idEmpresa = jsonData['idEmpresa'];
		tipo = EmpresaTelefoneDomain.getTipo(jsonData['tipo']);
		numero = jsonData['numero'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idEmpresa'] = idEmpresa != 0 ? idEmpresa : null;
		jsonData['tipo'] = EmpresaTelefoneDomain.setTipo(tipo);
		jsonData['numero'] = Util.removeMask(numero);
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idEmpresa = plutoRow.cells['idEmpresa']?.value;
		tipo = plutoRow.cells['tipo']?.value != '' ? plutoRow.cells['tipo']?.value : 'Fixo';
		numero = plutoRow.cells['numero']?.value;
	}	

	EmpresaTelefoneModel clone() {
		return EmpresaTelefoneModel(
			id: id,
			idEmpresa: idEmpresa,
			tipo: tipo,
			numero: numero,
		);			
	}

	
}