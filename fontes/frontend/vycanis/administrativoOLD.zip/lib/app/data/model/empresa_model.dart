import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:intl/intl.dart';
import 'package:administrativo/app/data/domain/domain_imports.dart';

class EmpresaModel {
	int? id;
	String? razaoSocial;
	String? nomeFantasia;
	String? cnpj;
	String? inscricaoEstadual;
	String? inscricaoMunicipal;
	String? tipoRegime;
	String? crt;
	String? email;
	String? site;
	String? contato;
	DateTime? dataConstituicao;
	String? tipo;
	String? inscricaoJuntaComercial;
	DateTime? dataInscJuntaComercial;
	int? codigoIbgeCidade;
	int? codigoIbgeUf;
	String? cei;
	String? codigoCnaePrincipal;
	String? imagemLogotipo;
	List<EmpresaEnderecoModel>? empresaEnderecoModelList;
	List<EmpresaContatoModel>? empresaContatoModelList;
	List<EmpresaTelefoneModel>? empresaTelefoneModelList;
	List<EmpresaCnaeModel>? empresaCnaeModelList;

	EmpresaModel({
		this.id,
		this.razaoSocial,
		this.nomeFantasia,
		this.cnpj,
		this.inscricaoEstadual,
		this.inscricaoMunicipal,
		this.tipoRegime,
		this.crt,
		this.email,
		this.site,
		this.contato,
		this.dataConstituicao,
		this.tipo,
		this.inscricaoJuntaComercial,
		this.dataInscJuntaComercial,
		this.codigoIbgeCidade,
		this.codigoIbgeUf,
		this.cei,
		this.codigoCnaePrincipal,
		this.imagemLogotipo,
		this.empresaEnderecoModelList,
		this.empresaContatoModelList,
		this.empresaTelefoneModelList,
		this.empresaCnaeModelList,
	});

	static List<String> dbColumns = <String>[
		'id',
		'razao_social',
		'nome_fantasia',
		'cnpj',
		'inscricao_estadual',
		'inscricao_municipal',
		'tipo_regime',
		'crt',
		'email',
		'site',
		'contato',
		'data_constituicao',
		'tipo',
		'inscricao_junta_comercial',
		'data_insc_junta_comercial',
		'codigo_ibge_cidade',
		'codigo_ibge_uf',
		'cei',
		'codigo_cnae_principal',
		'imagem_logotipo',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Razao Social',
		'Nome Fantasia',
		'Cnpj',
		'Inscricao Estadual',
		'Inscricao Municipal',
		'Tipo Regime',
		'Crt',
		'Email',
		'Site',
		'Contato',
		'Data Constituicao',
		'Tipo',
		'Inscricao Junta Comercial',
		'Data Insc Junta Comercial',
		'Codigo Ibge Cidade',
		'Codigo Ibge Uf',
		'Cei',
		'Codigo Cnae Principal',
		'Imagem Logotipo',
	];

	EmpresaModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		razaoSocial = jsonData['razaoSocial'];
		nomeFantasia = jsonData['nomeFantasia'];
		cnpj = jsonData['cnpj'];
		inscricaoEstadual = jsonData['inscricaoEstadual'];
		inscricaoMunicipal = jsonData['inscricaoMunicipal'];
		tipoRegime = EmpresaDomain.getTipoRegime(jsonData['tipoRegime']);
		crt = EmpresaDomain.getCrt(jsonData['crt']);
		email = jsonData['email'];
		site = jsonData['site'];
		contato = jsonData['contato'];
		dataConstituicao = jsonData['dataConstituicao'] != null ? DateTime.tryParse(jsonData['dataConstituicao']) : null;
		tipo = EmpresaDomain.getTipo(jsonData['tipo']);
		inscricaoJuntaComercial = jsonData['inscricaoJuntaComercial'];
		dataInscJuntaComercial = jsonData['dataInscJuntaComercial'] != null ? DateTime.tryParse(jsonData['dataInscJuntaComercial']) : null;
		codigoIbgeCidade = jsonData['codigoIbgeCidade'];
		codigoIbgeUf = jsonData['codigoIbgeUf'];
		cei = jsonData['cei'];
		codigoCnaePrincipal = jsonData['codigoCnaePrincipal'];
		imagemLogotipo = jsonData['imagemLogotipo'];
		empresaEnderecoModelList = (jsonData['empresaEnderecoModelList'] as Iterable?)?.map((m) => EmpresaEnderecoModel.fromJson(m)).toList() ?? [];
		empresaContatoModelList = (jsonData['empresaContatoModelList'] as Iterable?)?.map((m) => EmpresaContatoModel.fromJson(m)).toList() ?? [];
		empresaTelefoneModelList = (jsonData['empresaTelefoneModelList'] as Iterable?)?.map((m) => EmpresaTelefoneModel.fromJson(m)).toList() ?? [];
		empresaCnaeModelList = (jsonData['empresaCnaeModelList'] as Iterable?)?.map((m) => EmpresaCnaeModel.fromJson(m)).toList() ?? [];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['razaoSocial'] = razaoSocial;
		jsonData['nomeFantasia'] = nomeFantasia;
		jsonData['cnpj'] = Util.removeMask(cnpj);
		jsonData['inscricaoEstadual'] = inscricaoEstadual;
		jsonData['inscricaoMunicipal'] = inscricaoMunicipal;
		jsonData['tipoRegime'] = EmpresaDomain.setTipoRegime(tipoRegime);
		jsonData['crt'] = EmpresaDomain.setCrt(crt);
		jsonData['email'] = email;
		jsonData['site'] = site;
		jsonData['contato'] = contato;
		jsonData['dataConstituicao'] = dataConstituicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataConstituicao!) : null;
		jsonData['tipo'] = EmpresaDomain.setTipo(tipo);
		jsonData['inscricaoJuntaComercial'] = inscricaoJuntaComercial;
		jsonData['dataInscJuntaComercial'] = dataInscJuntaComercial != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInscJuntaComercial!) : null;
		jsonData['codigoIbgeCidade'] = codigoIbgeCidade;
		jsonData['codigoIbgeUf'] = codigoIbgeUf;
		jsonData['cei'] = cei;
		jsonData['codigoCnaePrincipal'] = codigoCnaePrincipal;
		jsonData['imagemLogotipo'] = imagemLogotipo;
		
		var empresaEnderecoModelLocalList = []; 
		for (EmpresaEnderecoModel object in empresaEnderecoModelList ?? []) { 
			empresaEnderecoModelLocalList.add(object.toJson); 
		}
		jsonData['empresaEnderecoModelList'] = empresaEnderecoModelLocalList;
		
		var empresaContatoModelLocalList = []; 
		for (EmpresaContatoModel object in empresaContatoModelList ?? []) { 
			empresaContatoModelLocalList.add(object.toJson); 
		}
		jsonData['empresaContatoModelList'] = empresaContatoModelLocalList;
		
		var empresaTelefoneModelLocalList = []; 
		for (EmpresaTelefoneModel object in empresaTelefoneModelList ?? []) { 
			empresaTelefoneModelLocalList.add(object.toJson); 
		}
		jsonData['empresaTelefoneModelList'] = empresaTelefoneModelLocalList;
		
		var empresaCnaeModelLocalList = []; 
		for (EmpresaCnaeModel object in empresaCnaeModelList ?? []) { 
			empresaCnaeModelLocalList.add(object.toJson); 
		}
		jsonData['empresaCnaeModelList'] = empresaCnaeModelLocalList;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		razaoSocial = plutoRow.cells['razaoSocial']?.value;
		nomeFantasia = plutoRow.cells['nomeFantasia']?.value;
		cnpj = plutoRow.cells['cnpj']?.value;
		inscricaoEstadual = plutoRow.cells['inscricaoEstadual']?.value;
		inscricaoMunicipal = plutoRow.cells['inscricaoMunicipal']?.value;
		tipoRegime = plutoRow.cells['tipoRegime']?.value != '' ? plutoRow.cells['tipoRegime']?.value : '1-Lucro Real';
		crt = plutoRow.cells['crt']?.value != '' ? plutoRow.cells['crt']?.value : '1-Simples Nacional';
		email = plutoRow.cells['email']?.value;
		site = plutoRow.cells['site']?.value;
		contato = plutoRow.cells['contato']?.value;
		dataConstituicao = Util.stringToDate(plutoRow.cells['dataConstituicao']?.value);
		tipo = plutoRow.cells['tipo']?.value != '' ? plutoRow.cells['tipo']?.value : 'Matriz';
		inscricaoJuntaComercial = plutoRow.cells['inscricaoJuntaComercial']?.value;
		dataInscJuntaComercial = Util.stringToDate(plutoRow.cells['dataInscJuntaComercial']?.value);
		codigoIbgeCidade = plutoRow.cells['codigoIbgeCidade']?.value;
		codigoIbgeUf = plutoRow.cells['codigoIbgeUf']?.value;
		cei = plutoRow.cells['cei']?.value;
		codigoCnaePrincipal = plutoRow.cells['codigoCnaePrincipal']?.value;
		imagemLogotipo = plutoRow.cells['imagemLogotipo']?.value;
		empresaEnderecoModelList = [];
		empresaContatoModelList = [];
		empresaTelefoneModelList = [];
		empresaCnaeModelList = [];
	}	

	EmpresaModel clone() {
		return EmpresaModel(
			id: id,
			razaoSocial: razaoSocial,
			nomeFantasia: nomeFantasia,
			cnpj: cnpj,
			inscricaoEstadual: inscricaoEstadual,
			inscricaoMunicipal: inscricaoMunicipal,
			tipoRegime: tipoRegime,
			crt: crt,
			email: email,
			site: site,
			contato: contato,
			dataConstituicao: dataConstituicao,
			tipo: tipo,
			inscricaoJuntaComercial: inscricaoJuntaComercial,
			dataInscJuntaComercial: dataInscJuntaComercial,
			codigoIbgeCidade: codigoIbgeCidade,
			codigoIbgeUf: codigoIbgeUf,
			cei: cei,
			codigoCnaePrincipal: codigoCnaePrincipal,
			imagemLogotipo: imagemLogotipo,
			empresaEnderecoModelList: empresaEnderecoModelListClone(empresaEnderecoModelList!),
			empresaContatoModelList: empresaContatoModelListClone(empresaContatoModelList!),
			empresaTelefoneModelList: empresaTelefoneModelListClone(empresaTelefoneModelList!),
			empresaCnaeModelList: empresaCnaeModelListClone(empresaCnaeModelList!),
		);			
	}

	empresaEnderecoModelListClone(List<EmpresaEnderecoModel> empresaEnderecoModelList) { 
		List<EmpresaEnderecoModel> resultList = [];
		for (var empresaEnderecoModel in empresaEnderecoModelList) {
			resultList.add(
				EmpresaEnderecoModel(
					id: empresaEnderecoModel.id,
					idEmpresa: empresaEnderecoModel.idEmpresa,
					logradouro: empresaEnderecoModel.logradouro,
					numero: empresaEnderecoModel.numero,
					bairro: empresaEnderecoModel.bairro,
					cidade: empresaEnderecoModel.cidade,
					uf: empresaEnderecoModel.uf,
					cep: empresaEnderecoModel.cep,
					municipioIbge: empresaEnderecoModel.municipioIbge,
					complemento: empresaEnderecoModel.complemento,
					principal: empresaEnderecoModel.principal,
					entrega: empresaEnderecoModel.entrega,
					cobranca: empresaEnderecoModel.cobranca,
					correspondencia: empresaEnderecoModel.correspondencia,
				)
			);
		}
		return resultList;
	}

	empresaContatoModelListClone(List<EmpresaContatoModel> empresaContatoModelList) { 
		List<EmpresaContatoModel> resultList = [];
		for (var empresaContatoModel in empresaContatoModelList) {
			resultList.add(
				EmpresaContatoModel(
					id: empresaContatoModel.id,
					idEmpresa: empresaContatoModel.idEmpresa,
					nome: empresaContatoModel.nome,
					email: empresaContatoModel.email,
					observacao: empresaContatoModel.observacao,
				)
			);
		}
		return resultList;
	}

	empresaTelefoneModelListClone(List<EmpresaTelefoneModel> empresaTelefoneModelList) { 
		List<EmpresaTelefoneModel> resultList = [];
		for (var empresaTelefoneModel in empresaTelefoneModelList) {
			resultList.add(
				EmpresaTelefoneModel(
					id: empresaTelefoneModel.id,
					idEmpresa: empresaTelefoneModel.idEmpresa,
					tipo: empresaTelefoneModel.tipo,
					numero: empresaTelefoneModel.numero,
				)
			);
		}
		return resultList;
	}

	empresaCnaeModelListClone(List<EmpresaCnaeModel> empresaCnaeModelList) { 
		List<EmpresaCnaeModel> resultList = [];
		for (var empresaCnaeModel in empresaCnaeModelList) {
			resultList.add(
				EmpresaCnaeModel(
					id: empresaCnaeModel.id,
					idEmpresa: empresaCnaeModel.idEmpresa,
					idCnae: empresaCnaeModel.idCnae,
					principal: empresaCnaeModel.principal,
					ramoAtividade: empresaCnaeModel.ramoAtividade,
					objetoSocial: empresaCnaeModel.objetoSocial,
				)
			);
		}
		return resultList;
	}

	
}