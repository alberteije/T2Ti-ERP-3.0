import 'dart:convert';
import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class AuditoriaModel {
	int? id;
	DateTime? dataRegistro;
	String? horaRegistro;
	String? janelaController;
	String? acao;
	String? conteudo;
	String? tokenJwt;
	UsuarioTokenModel? usuarioTokenModel;

	AuditoriaModel({
		this.id,
		this.dataRegistro,
		this.horaRegistro,
		this.janelaController,
		this.acao,
		this.conteudo,
		this.tokenJwt,
    this.usuarioTokenModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'data_registro',
		'hora_registro',
		'janela_controller',
		'acao',
		'conteudo',
		'token_jwt',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Data Registro',
		'Hora Registro',
		'Janela Controller',
		'Acao',
		'Conteudo',
		'Token Jwt',
	];

	AuditoriaModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		dataRegistro = jsonData['dataRegistro'] != null ? DateTime.tryParse(jsonData['dataRegistro']) : null;
		horaRegistro = jsonData['horaRegistro'];
		janelaController = jsonData['janelaController'];
		acao = jsonData['acao'];
		conteudo = jsonData['conteudo'];
		tokenJwt = jsonData['tokenJwt'];
    usuarioTokenModel = jsonData['usuarioTokenModel'] == null ? UsuarioTokenModel() : UsuarioTokenModel.fromJson(jsonData['usuarioTokenModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['dataRegistro'] = dataRegistro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRegistro!) : null;
		jsonData['horaRegistro'] = horaRegistro;
		jsonData['janelaController'] = janelaController;
		jsonData['acao'] = acao;
		jsonData['conteudo'] = conteudo;
		jsonData['tokenJwt'] = tokenJwt;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		dataRegistro = Util.stringToDate(plutoRow.cells['dataRegistro']?.value);
		horaRegistro = plutoRow.cells['horaRegistro']?.value;
		janelaController = plutoRow.cells['janelaController']?.value;
		acao = plutoRow.cells['acao']?.value;
		conteudo = plutoRow.cells['conteudo']?.value;
		tokenJwt = plutoRow.cells['tokenJwt']?.value;
	}	

	AuditoriaModel clone() {
		return AuditoriaModel(
			id: id,
			dataRegistro: dataRegistro,
			horaRegistro: horaRegistro,
			janelaController: janelaController,
			acao: acao,
			conteudo: conteudo,
			tokenJwt: tokenJwt,
		);			
	}

	
}