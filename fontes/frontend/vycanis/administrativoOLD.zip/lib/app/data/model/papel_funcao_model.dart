import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/data/model/model_imports.dart';
import 'package:administrativo/app/data/domain/domain_imports.dart';

class PapelFuncaoModel {
	int? id;
	int? idPapel;
	int? idFuncao;
	String? habilitado;
	String? podeInserir;
	String? podeAlterar;
	String? podeExcluir;
	FuncaoModel? funcaoModel;

	PapelFuncaoModel({
		this.id,
		this.idPapel,
		this.idFuncao,
		this.habilitado,
		this.podeInserir,
		this.podeAlterar,
		this.podeExcluir,
		this.funcaoModel,
	});

	static List<String> dbColumns = <String>[
		'id',
		'habilitado',
		'pode_inserir',
		'pode_alterar',
		'pode_excluir',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Habilitado',
		'Pode Inserir',
		'Pode Alterar',
		'Pode Excluir',
	];

	PapelFuncaoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idPapel = jsonData['idPapel'];
		idFuncao = jsonData['funcaoModel']['id'];
		habilitado = PapelFuncaoDomain.getHabilitado(jsonData['habilitado']);
		podeInserir = PapelFuncaoDomain.getPodeInserir(jsonData['podeInserir']);
		podeAlterar = PapelFuncaoDomain.getPodeAlterar(jsonData['podeAlterar']);
		podeExcluir = PapelFuncaoDomain.getPodeExcluir(jsonData['podeExcluir']);
		funcaoModel = jsonData['funcaoModel'] == null ? FuncaoModel() : FuncaoModel.fromJson(jsonData['funcaoModel']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idPapel'] = idPapel != 0 ? idPapel : null;
		jsonData['idFuncao'] = idFuncao != 0 ? idFuncao : null;
		jsonData['habilitado'] = PapelFuncaoDomain.setHabilitado(habilitado);
		jsonData['podeInserir'] = PapelFuncaoDomain.setPodeInserir(podeInserir);
		jsonData['podeAlterar'] = PapelFuncaoDomain.setPodeAlterar(podeAlterar);
		jsonData['podeExcluir'] = PapelFuncaoDomain.setPodeExcluir(podeExcluir);
		jsonData['funcaoModel'] = funcaoModel?.toJson;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idPapel = plutoRow.cells['idPapel']?.value;
		idFuncao = plutoRow.cells['idFuncao']?.value;
		habilitado = plutoRow.cells['habilitado']?.value != '' ? plutoRow.cells['habilitado']?.value : 'Sim';
		podeInserir = plutoRow.cells['podeInserir']?.value != '' ? plutoRow.cells['podeInserir']?.value : 'Sim';
		podeAlterar = plutoRow.cells['podeAlterar']?.value != '' ? plutoRow.cells['podeAlterar']?.value : 'Sim';
		podeExcluir = plutoRow.cells['podeExcluir']?.value != '' ? plutoRow.cells['podeExcluir']?.value : 'Sim';
		funcaoModel = FuncaoModel();
		funcaoModel?.nome = plutoRow.cells['funcaoModel']?.value;
	}	

	PapelFuncaoModel clone() {
		return PapelFuncaoModel(
			id: id,
			idPapel: idPapel,
			idFuncao: idFuncao,
			habilitado: habilitado,
			podeInserir: podeInserir,
			podeAlterar: podeAlterar,
			podeExcluir: podeExcluir,
		);			
	}

	
}