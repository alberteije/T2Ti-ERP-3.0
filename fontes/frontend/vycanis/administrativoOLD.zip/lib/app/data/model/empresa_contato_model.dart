import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';


class EmpresaContatoModel {
	int? id;
	int? idEmpresa;
	String? nome;
	String? email;
	String? observacao;

	EmpresaContatoModel({
		this.id,
		this.idEmpresa,
		this.nome,
		this.email,
		this.observacao,
	});

	static List<String> dbColumns = <String>[
		'id',
		'nome',
		'email',
		'observacao',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Nome',
		'Email',
		'Observacao',
	];

	EmpresaContatoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idEmpresa = jsonData['idEmpresa'];
		nome = jsonData['nome'];
		email = jsonData['email'];
		observacao = jsonData['observacao'];
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idEmpresa'] = idEmpresa != 0 ? idEmpresa : null;
		jsonData['nome'] = nome;
		jsonData['email'] = email;
		jsonData['observacao'] = observacao;
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idEmpresa = plutoRow.cells['idEmpresa']?.value;
		nome = plutoRow.cells['nome']?.value;
		email = plutoRow.cells['email']?.value;
		observacao = plutoRow.cells['observacao']?.value;
	}	

	EmpresaContatoModel clone() {
		return EmpresaContatoModel(
			id: id,
			idEmpresa: idEmpresa,
			nome: nome,
			email: email,
			observacao: observacao,
		);			
	}

	
}