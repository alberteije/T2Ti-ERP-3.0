import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/data/domain/domain_imports.dart';

class EmpresaEnderecoModel {
	int? id;
	int? idEmpresa;
	String? logradouro;
	String? numero;
	String? bairro;
	String? cidade;
	String? uf;
	String? cep;
	int? municipioIbge;
	String? complemento;
	String? principal;
	String? entrega;
	String? cobranca;
	String? correspondencia;

	EmpresaEnderecoModel({
		this.id,
		this.idEmpresa,
		this.logradouro,
		this.numero,
		this.bairro,
		this.cidade,
		this.uf,
		this.cep,
		this.municipioIbge,
		this.complemento,
		this.principal,
		this.entrega,
		this.cobranca,
		this.correspondencia,
	});

	static List<String> dbColumns = <String>[
		'id',
		'logradouro',
		'numero',
		'bairro',
		'cidade',
		'uf',
		'cep',
		'municipio_ibge',
		'complemento',
		'principal',
		'entrega',
		'cobranca',
		'correspondencia',
	];
	
	static List<String> aliasColumns = <String>[
		'Id',
		'Logradouro',
		'Numero',
		'Bairro',
		'Cidade',
		'Uf',
		'Cep',
		'Municipio Ibge',
		'Complemento',
		'Principal',
		'Entrega',
		'Cobranca',
		'Correspondencia',
	];

	EmpresaEnderecoModel.fromJson(Map<String, dynamic> jsonData) {
		id = jsonData['id'];
		idEmpresa = jsonData['idEmpresa'];
		logradouro = jsonData['logradouro'];
		numero = jsonData['numero'];
		bairro = jsonData['bairro'];
		cidade = jsonData['cidade'];
		uf = EmpresaEnderecoDomain.getUf(jsonData['uf']);
		cep = jsonData['cep'];
		municipioIbge = jsonData['municipioIbge'];
		complemento = jsonData['complemento'];
		principal = EmpresaEnderecoDomain.getPrincipal(jsonData['principal']);
		entrega = EmpresaEnderecoDomain.getEntrega(jsonData['entrega']);
		cobranca = EmpresaEnderecoDomain.getCobranca(jsonData['cobranca']);
		correspondencia = EmpresaEnderecoDomain.getCorrespondencia(jsonData['correspondencia']);
	}

	Map<String, dynamic> get toJson {
		Map<String, dynamic> jsonData = <String, dynamic>{};

		jsonData['id'] = id != 0 ? id : null;
		jsonData['idEmpresa'] = idEmpresa != 0 ? idEmpresa : null;
		jsonData['logradouro'] = logradouro;
		jsonData['numero'] = numero;
		jsonData['bairro'] = bairro;
		jsonData['cidade'] = cidade;
		jsonData['uf'] = EmpresaEnderecoDomain.setUf(uf);
		jsonData['cep'] = Util.removeMask(cep);
		jsonData['municipioIbge'] = municipioIbge;
		jsonData['complemento'] = complemento;
		jsonData['principal'] = EmpresaEnderecoDomain.setPrincipal(principal);
		jsonData['entrega'] = EmpresaEnderecoDomain.setEntrega(entrega);
		jsonData['cobranca'] = EmpresaEnderecoDomain.setCobranca(cobranca);
		jsonData['correspondencia'] = EmpresaEnderecoDomain.setCorrespondencia(correspondencia);
	
		return jsonData;
	}
	
	String objectEncodeJson() {
		final jsonData = toJson;
		return json.encode(jsonData);
	}

	plutoRowToObject(PlutoRow plutoRow) {
		id = plutoRow.cells['id']?.value;
		idEmpresa = plutoRow.cells['idEmpresa']?.value;
		logradouro = plutoRow.cells['logradouro']?.value;
		numero = plutoRow.cells['numero']?.value;
		bairro = plutoRow.cells['bairro']?.value;
		cidade = plutoRow.cells['cidade']?.value;
		uf = plutoRow.cells['uf']?.value != '' ? plutoRow.cells['uf']?.value : 'AC';
		cep = plutoRow.cells['cep']?.value;
		municipioIbge = plutoRow.cells['municipioIbge']?.value;
		complemento = plutoRow.cells['complemento']?.value;
		principal = plutoRow.cells['principal']?.value != '' ? plutoRow.cells['principal']?.value : 'Sim';
		entrega = plutoRow.cells['entrega']?.value != '' ? plutoRow.cells['entrega']?.value : 'Sim';
		cobranca = plutoRow.cells['cobranca']?.value != '' ? plutoRow.cells['cobranca']?.value : 'Sim';
		correspondencia = plutoRow.cells['correspondencia']?.value != '' ? plutoRow.cells['correspondencia']?.value : 'Sim';
	}	

	EmpresaEnderecoModel clone() {
		return EmpresaEnderecoModel(
			id: id,
			idEmpresa: idEmpresa,
			logradouro: logradouro,
			numero: numero,
			bairro: bairro,
			cidade: cidade,
			uf: uf,
			cep: cep,
			municipioIbge: municipioIbge,
			complemento: complemento,
			principal: principal,
			entrega: entrega,
			cobranca: cobranca,
			correspondencia: correspondencia,
		);			
	}

	
}