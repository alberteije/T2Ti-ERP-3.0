import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:administrativo/app/page/shared_widget/shared_widget_imports.dart';
import 'package:administrativo/app/controller/papel_funcao_controller.dart';
import 'package:administrativo/app/infra/infra_imports.dart';
import 'package:administrativo/app/page/shared_widget/input/input_imports.dart';

class PapelFuncaoEditPage extends StatelessWidget {
	PapelFuncaoEditPage({Key? key}) : super(key: key);
	final papelFuncaoController = Get.find<PapelFuncaoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: papelFuncaoController.scaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('Controle de Acesso - ${'editing'.tr}'),
					actions: [
						saveButton(onPressed: papelFuncaoController.save),
						cancelAndExitButton(onPressed: papelFuncaoController.preventDataLoss),
					]
				),				
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: papelFuncaoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: papelFuncaoController.scrollController,
							child: SingleChildScrollView(
								controller: papelFuncaoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: papelFuncaoController.funcaoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Funcao',
																			labelText: 'Função *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: papelFuncaoController.callFuncaoLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: papelFuncaoController.papelFuncaoModel.habilitado ?? 'Sim',
															labelText: 'Habilitado',
															hintText: 'Informe os dados para o campo Habilitado',
															items: const ['Sim','Não'],
															onChanged: (dynamic newValue) {
																papelFuncaoController.papelFuncaoModel.habilitado = newValue;
																papelFuncaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: papelFuncaoController.papelFuncaoModel.podeInserir ?? 'Sim',
															labelText: 'Pode Inserir',
															hintText: 'Informe os dados para o campo Pode Inserir',
															items: const ['Sim','Não'],
															onChanged: (dynamic newValue) {
																papelFuncaoController.papelFuncaoModel.podeInserir = newValue;
																papelFuncaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: papelFuncaoController.papelFuncaoModel.podeAlterar ?? 'Sim',
															labelText: 'Pode Alterar',
															hintText: 'Informe os dados para o campo Pode Alterar',
															items: const ['Sim','Não'],
															onChanged: (dynamic newValue) {
																papelFuncaoController.papelFuncaoModel.podeAlterar = newValue;
																papelFuncaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButtonFormField(
															value: papelFuncaoController.papelFuncaoModel.podeExcluir ?? 'Sim',
															labelText: 'Pode Excluir',
															hintText: 'Informe os dados para o campo Pode Excluir',
															items: const ['Sim','Não'],
															onChanged: (dynamic newValue) {
																papelFuncaoController.papelFuncaoModel.podeExcluir = newValue;
																papelFuncaoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
