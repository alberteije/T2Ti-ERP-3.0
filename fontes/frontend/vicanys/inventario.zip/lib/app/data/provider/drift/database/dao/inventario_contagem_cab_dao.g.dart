// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'inventario_contagem_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$InventarioContagemCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $InventarioContagemCabsTable get inventarioContagemCabs =>
      attachedDatabase.inventarioContagemCabs;
  $InventarioContagemDetsTable get inventarioContagemDets =>
      attachedDatabase.inventarioContagemDets;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
