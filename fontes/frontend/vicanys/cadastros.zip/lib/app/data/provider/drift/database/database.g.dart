// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PessoaFisicasTable extends PessoaFisicas
    with TableInfo<$PessoaFisicasTable, PessoaFisica> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaFisicasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNivelFormacaoMeta =
      const VerificationMeta('idNivelFormacao');
  @override
  late final GeneratedColumn<int> idNivelFormacao = GeneratedColumn<int>(
      'id_nivel_formacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstadoCivilMeta =
      const VerificationMeta('idEstadoCivil');
  @override
  late final GeneratedColumn<int> idEstadoCivil = GeneratedColumn<int>(
      'id_estado_civil', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgMeta = const VerificationMeta('rg');
  @override
  late final GeneratedColumn<String> rg = GeneratedColumn<String>(
      'rg', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _orgaoRgMeta =
      const VerificationMeta('orgaoRg');
  @override
  late final GeneratedColumn<String> orgaoRg = GeneratedColumn<String>(
      'orgao_rg', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoRgMeta =
      const VerificationMeta('dataEmissaoRg');
  @override
  late final GeneratedColumn<DateTime> dataEmissaoRg =
      GeneratedColumn<DateTime>('data_emissao_rg', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataNascimentoMeta =
      const VerificationMeta('dataNascimento');
  @override
  late final GeneratedColumn<DateTime> dataNascimento =
      GeneratedColumn<DateTime>('data_nascimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _sexoMeta = const VerificationMeta('sexo');
  @override
  late final GeneratedColumn<String> sexo = GeneratedColumn<String>(
      'sexo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _racaMeta = const VerificationMeta('raca');
  @override
  late final GeneratedColumn<String> raca = GeneratedColumn<String>(
      'raca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nacionalidadeMeta =
      const VerificationMeta('nacionalidade');
  @override
  late final GeneratedColumn<String> nacionalidade = GeneratedColumn<String>(
      'nacionalidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturalidadeMeta =
      const VerificationMeta('naturalidade');
  @override
  late final GeneratedColumn<String> naturalidade = GeneratedColumn<String>(
      'naturalidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomePaiMeta =
      const VerificationMeta('nomePai');
  @override
  late final GeneratedColumn<String> nomePai = GeneratedColumn<String>(
      'nome_pai', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 200),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMaeMeta =
      const VerificationMeta('nomeMae');
  @override
  late final GeneratedColumn<String> nomeMae = GeneratedColumn<String>(
      'nome_mae', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 200),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idNivelFormacao,
        idEstadoCivil,
        cpf,
        rg,
        orgaoRg,
        dataEmissaoRg,
        dataNascimento,
        sexo,
        raca,
        nacionalidade,
        naturalidade,
        nomePai,
        nomeMae
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa_fisica';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaFisica> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_nivel_formacao')) {
      context.handle(
          _idNivelFormacaoMeta,
          idNivelFormacao.isAcceptableOrUnknown(
              data['id_nivel_formacao']!, _idNivelFormacaoMeta));
    }
    if (data.containsKey('id_estado_civil')) {
      context.handle(
          _idEstadoCivilMeta,
          idEstadoCivil.isAcceptableOrUnknown(
              data['id_estado_civil']!, _idEstadoCivilMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('rg')) {
      context.handle(_rgMeta, rg.isAcceptableOrUnknown(data['rg']!, _rgMeta));
    }
    if (data.containsKey('orgao_rg')) {
      context.handle(_orgaoRgMeta,
          orgaoRg.isAcceptableOrUnknown(data['orgao_rg']!, _orgaoRgMeta));
    }
    if (data.containsKey('data_emissao_rg')) {
      context.handle(
          _dataEmissaoRgMeta,
          dataEmissaoRg.isAcceptableOrUnknown(
              data['data_emissao_rg']!, _dataEmissaoRgMeta));
    }
    if (data.containsKey('data_nascimento')) {
      context.handle(
          _dataNascimentoMeta,
          dataNascimento.isAcceptableOrUnknown(
              data['data_nascimento']!, _dataNascimentoMeta));
    }
    if (data.containsKey('sexo')) {
      context.handle(
          _sexoMeta, sexo.isAcceptableOrUnknown(data['sexo']!, _sexoMeta));
    }
    if (data.containsKey('raca')) {
      context.handle(
          _racaMeta, raca.isAcceptableOrUnknown(data['raca']!, _racaMeta));
    }
    if (data.containsKey('nacionalidade')) {
      context.handle(
          _nacionalidadeMeta,
          nacionalidade.isAcceptableOrUnknown(
              data['nacionalidade']!, _nacionalidadeMeta));
    }
    if (data.containsKey('naturalidade')) {
      context.handle(
          _naturalidadeMeta,
          naturalidade.isAcceptableOrUnknown(
              data['naturalidade']!, _naturalidadeMeta));
    }
    if (data.containsKey('nome_pai')) {
      context.handle(_nomePaiMeta,
          nomePai.isAcceptableOrUnknown(data['nome_pai']!, _nomePaiMeta));
    }
    if (data.containsKey('nome_mae')) {
      context.handle(_nomeMaeMeta,
          nomeMae.isAcceptableOrUnknown(data['nome_mae']!, _nomeMaeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaFisica map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaFisica(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idNivelFormacao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nivel_formacao']),
      idEstadoCivil: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estado_civil']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      rg: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg']),
      orgaoRg: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}orgao_rg']),
      dataEmissaoRg: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_emissao_rg']),
      dataNascimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_nascimento']),
      sexo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sexo']),
      raca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}raca']),
      nacionalidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nacionalidade']),
      naturalidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}naturalidade']),
      nomePai: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pai']),
      nomeMae: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_mae']),
    );
  }

  @override
  $PessoaFisicasTable createAlias(String alias) {
    return $PessoaFisicasTable(attachedDatabase, alias);
  }
}

class PessoaFisica extends DataClass implements Insertable<PessoaFisica> {
  final int? id;
  final int? idPessoa;
  final int? idNivelFormacao;
  final int? idEstadoCivil;
  final String? cpf;
  final String? rg;
  final String? orgaoRg;
  final DateTime? dataEmissaoRg;
  final DateTime? dataNascimento;
  final String? sexo;
  final String? raca;
  final String? nacionalidade;
  final String? naturalidade;
  final String? nomePai;
  final String? nomeMae;
  const PessoaFisica(
      {this.id,
      this.idPessoa,
      this.idNivelFormacao,
      this.idEstadoCivil,
      this.cpf,
      this.rg,
      this.orgaoRg,
      this.dataEmissaoRg,
      this.dataNascimento,
      this.sexo,
      this.raca,
      this.nacionalidade,
      this.naturalidade,
      this.nomePai,
      this.nomeMae});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idNivelFormacao != null) {
      map['id_nivel_formacao'] = Variable<int>(idNivelFormacao);
    }
    if (!nullToAbsent || idEstadoCivil != null) {
      map['id_estado_civil'] = Variable<int>(idEstadoCivil);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || rg != null) {
      map['rg'] = Variable<String>(rg);
    }
    if (!nullToAbsent || orgaoRg != null) {
      map['orgao_rg'] = Variable<String>(orgaoRg);
    }
    if (!nullToAbsent || dataEmissaoRg != null) {
      map['data_emissao_rg'] = Variable<DateTime>(dataEmissaoRg);
    }
    if (!nullToAbsent || dataNascimento != null) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento);
    }
    if (!nullToAbsent || sexo != null) {
      map['sexo'] = Variable<String>(sexo);
    }
    if (!nullToAbsent || raca != null) {
      map['raca'] = Variable<String>(raca);
    }
    if (!nullToAbsent || nacionalidade != null) {
      map['nacionalidade'] = Variable<String>(nacionalidade);
    }
    if (!nullToAbsent || naturalidade != null) {
      map['naturalidade'] = Variable<String>(naturalidade);
    }
    if (!nullToAbsent || nomePai != null) {
      map['nome_pai'] = Variable<String>(nomePai);
    }
    if (!nullToAbsent || nomeMae != null) {
      map['nome_mae'] = Variable<String>(nomeMae);
    }
    return map;
  }

  factory PessoaFisica.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaFisica(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idNivelFormacao: serializer.fromJson<int?>(json['idNivelFormacao']),
      idEstadoCivil: serializer.fromJson<int?>(json['idEstadoCivil']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      rg: serializer.fromJson<String?>(json['rg']),
      orgaoRg: serializer.fromJson<String?>(json['orgaoRg']),
      dataEmissaoRg: serializer.fromJson<DateTime?>(json['dataEmissaoRg']),
      dataNascimento: serializer.fromJson<DateTime?>(json['dataNascimento']),
      sexo: serializer.fromJson<String?>(json['sexo']),
      raca: serializer.fromJson<String?>(json['raca']),
      nacionalidade: serializer.fromJson<String?>(json['nacionalidade']),
      naturalidade: serializer.fromJson<String?>(json['naturalidade']),
      nomePai: serializer.fromJson<String?>(json['nomePai']),
      nomeMae: serializer.fromJson<String?>(json['nomeMae']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idNivelFormacao': serializer.toJson<int?>(idNivelFormacao),
      'idEstadoCivil': serializer.toJson<int?>(idEstadoCivil),
      'cpf': serializer.toJson<String?>(cpf),
      'rg': serializer.toJson<String?>(rg),
      'orgaoRg': serializer.toJson<String?>(orgaoRg),
      'dataEmissaoRg': serializer.toJson<DateTime?>(dataEmissaoRg),
      'dataNascimento': serializer.toJson<DateTime?>(dataNascimento),
      'sexo': serializer.toJson<String?>(sexo),
      'raca': serializer.toJson<String?>(raca),
      'nacionalidade': serializer.toJson<String?>(nacionalidade),
      'naturalidade': serializer.toJson<String?>(naturalidade),
      'nomePai': serializer.toJson<String?>(nomePai),
      'nomeMae': serializer.toJson<String?>(nomeMae),
    };
  }

  PessoaFisica copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idNivelFormacao = const Value.absent(),
          Value<int?> idEstadoCivil = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> rg = const Value.absent(),
          Value<String?> orgaoRg = const Value.absent(),
          Value<DateTime?> dataEmissaoRg = const Value.absent(),
          Value<DateTime?> dataNascimento = const Value.absent(),
          Value<String?> sexo = const Value.absent(),
          Value<String?> raca = const Value.absent(),
          Value<String?> nacionalidade = const Value.absent(),
          Value<String?> naturalidade = const Value.absent(),
          Value<String?> nomePai = const Value.absent(),
          Value<String?> nomeMae = const Value.absent()}) =>
      PessoaFisica(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idNivelFormacao: idNivelFormacao.present
            ? idNivelFormacao.value
            : this.idNivelFormacao,
        idEstadoCivil:
            idEstadoCivil.present ? idEstadoCivil.value : this.idEstadoCivil,
        cpf: cpf.present ? cpf.value : this.cpf,
        rg: rg.present ? rg.value : this.rg,
        orgaoRg: orgaoRg.present ? orgaoRg.value : this.orgaoRg,
        dataEmissaoRg:
            dataEmissaoRg.present ? dataEmissaoRg.value : this.dataEmissaoRg,
        dataNascimento:
            dataNascimento.present ? dataNascimento.value : this.dataNascimento,
        sexo: sexo.present ? sexo.value : this.sexo,
        raca: raca.present ? raca.value : this.raca,
        nacionalidade:
            nacionalidade.present ? nacionalidade.value : this.nacionalidade,
        naturalidade:
            naturalidade.present ? naturalidade.value : this.naturalidade,
        nomePai: nomePai.present ? nomePai.value : this.nomePai,
        nomeMae: nomeMae.present ? nomeMae.value : this.nomeMae,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaFisica(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idNivelFormacao: $idNivelFormacao, ')
          ..write('idEstadoCivil: $idEstadoCivil, ')
          ..write('cpf: $cpf, ')
          ..write('rg: $rg, ')
          ..write('orgaoRg: $orgaoRg, ')
          ..write('dataEmissaoRg: $dataEmissaoRg, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('sexo: $sexo, ')
          ..write('raca: $raca, ')
          ..write('nacionalidade: $nacionalidade, ')
          ..write('naturalidade: $naturalidade, ')
          ..write('nomePai: $nomePai, ')
          ..write('nomeMae: $nomeMae')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      idNivelFormacao,
      idEstadoCivil,
      cpf,
      rg,
      orgaoRg,
      dataEmissaoRg,
      dataNascimento,
      sexo,
      raca,
      nacionalidade,
      naturalidade,
      nomePai,
      nomeMae);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaFisica &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idNivelFormacao == this.idNivelFormacao &&
          other.idEstadoCivil == this.idEstadoCivil &&
          other.cpf == this.cpf &&
          other.rg == this.rg &&
          other.orgaoRg == this.orgaoRg &&
          other.dataEmissaoRg == this.dataEmissaoRg &&
          other.dataNascimento == this.dataNascimento &&
          other.sexo == this.sexo &&
          other.raca == this.raca &&
          other.nacionalidade == this.nacionalidade &&
          other.naturalidade == this.naturalidade &&
          other.nomePai == this.nomePai &&
          other.nomeMae == this.nomeMae);
}

class PessoaFisicasCompanion extends UpdateCompanion<PessoaFisica> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idNivelFormacao;
  final Value<int?> idEstadoCivil;
  final Value<String?> cpf;
  final Value<String?> rg;
  final Value<String?> orgaoRg;
  final Value<DateTime?> dataEmissaoRg;
  final Value<DateTime?> dataNascimento;
  final Value<String?> sexo;
  final Value<String?> raca;
  final Value<String?> nacionalidade;
  final Value<String?> naturalidade;
  final Value<String?> nomePai;
  final Value<String?> nomeMae;
  const PessoaFisicasCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idNivelFormacao = const Value.absent(),
    this.idEstadoCivil = const Value.absent(),
    this.cpf = const Value.absent(),
    this.rg = const Value.absent(),
    this.orgaoRg = const Value.absent(),
    this.dataEmissaoRg = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.sexo = const Value.absent(),
    this.raca = const Value.absent(),
    this.nacionalidade = const Value.absent(),
    this.naturalidade = const Value.absent(),
    this.nomePai = const Value.absent(),
    this.nomeMae = const Value.absent(),
  });
  PessoaFisicasCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idNivelFormacao = const Value.absent(),
    this.idEstadoCivil = const Value.absent(),
    this.cpf = const Value.absent(),
    this.rg = const Value.absent(),
    this.orgaoRg = const Value.absent(),
    this.dataEmissaoRg = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.sexo = const Value.absent(),
    this.raca = const Value.absent(),
    this.nacionalidade = const Value.absent(),
    this.naturalidade = const Value.absent(),
    this.nomePai = const Value.absent(),
    this.nomeMae = const Value.absent(),
  });
  static Insertable<PessoaFisica> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idNivelFormacao,
    Expression<int>? idEstadoCivil,
    Expression<String>? cpf,
    Expression<String>? rg,
    Expression<String>? orgaoRg,
    Expression<DateTime>? dataEmissaoRg,
    Expression<DateTime>? dataNascimento,
    Expression<String>? sexo,
    Expression<String>? raca,
    Expression<String>? nacionalidade,
    Expression<String>? naturalidade,
    Expression<String>? nomePai,
    Expression<String>? nomeMae,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idNivelFormacao != null) 'id_nivel_formacao': idNivelFormacao,
      if (idEstadoCivil != null) 'id_estado_civil': idEstadoCivil,
      if (cpf != null) 'cpf': cpf,
      if (rg != null) 'rg': rg,
      if (orgaoRg != null) 'orgao_rg': orgaoRg,
      if (dataEmissaoRg != null) 'data_emissao_rg': dataEmissaoRg,
      if (dataNascimento != null) 'data_nascimento': dataNascimento,
      if (sexo != null) 'sexo': sexo,
      if (raca != null) 'raca': raca,
      if (nacionalidade != null) 'nacionalidade': nacionalidade,
      if (naturalidade != null) 'naturalidade': naturalidade,
      if (nomePai != null) 'nome_pai': nomePai,
      if (nomeMae != null) 'nome_mae': nomeMae,
    });
  }

  PessoaFisicasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idNivelFormacao,
      Value<int?>? idEstadoCivil,
      Value<String?>? cpf,
      Value<String?>? rg,
      Value<String?>? orgaoRg,
      Value<DateTime?>? dataEmissaoRg,
      Value<DateTime?>? dataNascimento,
      Value<String?>? sexo,
      Value<String?>? raca,
      Value<String?>? nacionalidade,
      Value<String?>? naturalidade,
      Value<String?>? nomePai,
      Value<String?>? nomeMae}) {
    return PessoaFisicasCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idNivelFormacao: idNivelFormacao ?? this.idNivelFormacao,
      idEstadoCivil: idEstadoCivil ?? this.idEstadoCivil,
      cpf: cpf ?? this.cpf,
      rg: rg ?? this.rg,
      orgaoRg: orgaoRg ?? this.orgaoRg,
      dataEmissaoRg: dataEmissaoRg ?? this.dataEmissaoRg,
      dataNascimento: dataNascimento ?? this.dataNascimento,
      sexo: sexo ?? this.sexo,
      raca: raca ?? this.raca,
      nacionalidade: nacionalidade ?? this.nacionalidade,
      naturalidade: naturalidade ?? this.naturalidade,
      nomePai: nomePai ?? this.nomePai,
      nomeMae: nomeMae ?? this.nomeMae,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idNivelFormacao.present) {
      map['id_nivel_formacao'] = Variable<int>(idNivelFormacao.value);
    }
    if (idEstadoCivil.present) {
      map['id_estado_civil'] = Variable<int>(idEstadoCivil.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (rg.present) {
      map['rg'] = Variable<String>(rg.value);
    }
    if (orgaoRg.present) {
      map['orgao_rg'] = Variable<String>(orgaoRg.value);
    }
    if (dataEmissaoRg.present) {
      map['data_emissao_rg'] = Variable<DateTime>(dataEmissaoRg.value);
    }
    if (dataNascimento.present) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento.value);
    }
    if (sexo.present) {
      map['sexo'] = Variable<String>(sexo.value);
    }
    if (raca.present) {
      map['raca'] = Variable<String>(raca.value);
    }
    if (nacionalidade.present) {
      map['nacionalidade'] = Variable<String>(nacionalidade.value);
    }
    if (naturalidade.present) {
      map['naturalidade'] = Variable<String>(naturalidade.value);
    }
    if (nomePai.present) {
      map['nome_pai'] = Variable<String>(nomePai.value);
    }
    if (nomeMae.present) {
      map['nome_mae'] = Variable<String>(nomeMae.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaFisicasCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idNivelFormacao: $idNivelFormacao, ')
          ..write('idEstadoCivil: $idEstadoCivil, ')
          ..write('cpf: $cpf, ')
          ..write('rg: $rg, ')
          ..write('orgaoRg: $orgaoRg, ')
          ..write('dataEmissaoRg: $dataEmissaoRg, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('sexo: $sexo, ')
          ..write('raca: $raca, ')
          ..write('nacionalidade: $nacionalidade, ')
          ..write('naturalidade: $naturalidade, ')
          ..write('nomePai: $nomePai, ')
          ..write('nomeMae: $nomeMae')
          ..write(')'))
        .toString();
  }
}

class $PessoaJuridicasTable extends PessoaJuridicas
    with TableInfo<$PessoaJuridicasTable, PessoaJuridica> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaJuridicasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeFantasiaMeta =
      const VerificationMeta('nomeFantasia');
  @override
  late final GeneratedColumn<String> nomeFantasia = GeneratedColumn<String>(
      'nome_fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoEstadualMeta =
      const VerificationMeta('inscricaoEstadual');
  @override
  late final GeneratedColumn<String> inscricaoEstadual =
      GeneratedColumn<String>('inscricao_estadual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inscricaoMunicipalMeta =
      const VerificationMeta('inscricaoMunicipal');
  @override
  late final GeneratedColumn<String> inscricaoMunicipal =
      GeneratedColumn<String>('inscricao_municipal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 45),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataConstituicaoMeta =
      const VerificationMeta('dataConstituicao');
  @override
  late final GeneratedColumn<DateTime> dataConstituicao =
      GeneratedColumn<DateTime>('data_constituicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoRegimeMeta =
      const VerificationMeta('tipoRegime');
  @override
  late final GeneratedColumn<String> tipoRegime = GeneratedColumn<String>(
      'tipo_regime', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _crtMeta = const VerificationMeta('crt');
  @override
  late final GeneratedColumn<String> crt = GeneratedColumn<String>(
      'crt', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        cnpj,
        nomeFantasia,
        inscricaoEstadual,
        inscricaoMunicipal,
        dataConstituicao,
        tipoRegime,
        crt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa_juridica';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaJuridica> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('nome_fantasia')) {
      context.handle(
          _nomeFantasiaMeta,
          nomeFantasia.isAcceptableOrUnknown(
              data['nome_fantasia']!, _nomeFantasiaMeta));
    }
    if (data.containsKey('inscricao_estadual')) {
      context.handle(
          _inscricaoEstadualMeta,
          inscricaoEstadual.isAcceptableOrUnknown(
              data['inscricao_estadual']!, _inscricaoEstadualMeta));
    }
    if (data.containsKey('inscricao_municipal')) {
      context.handle(
          _inscricaoMunicipalMeta,
          inscricaoMunicipal.isAcceptableOrUnknown(
              data['inscricao_municipal']!, _inscricaoMunicipalMeta));
    }
    if (data.containsKey('data_constituicao')) {
      context.handle(
          _dataConstituicaoMeta,
          dataConstituicao.isAcceptableOrUnknown(
              data['data_constituicao']!, _dataConstituicaoMeta));
    }
    if (data.containsKey('tipo_regime')) {
      context.handle(
          _tipoRegimeMeta,
          tipoRegime.isAcceptableOrUnknown(
              data['tipo_regime']!, _tipoRegimeMeta));
    }
    if (data.containsKey('crt')) {
      context.handle(
          _crtMeta, crt.isAcceptableOrUnknown(data['crt']!, _crtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaJuridica map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaJuridica(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      nomeFantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_fantasia']),
      inscricaoEstadual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_estadual']),
      inscricaoMunicipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_municipal']),
      dataConstituicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_constituicao']),
      tipoRegime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_regime']),
      crt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crt']),
    );
  }

  @override
  $PessoaJuridicasTable createAlias(String alias) {
    return $PessoaJuridicasTable(attachedDatabase, alias);
  }
}

class PessoaJuridica extends DataClass implements Insertable<PessoaJuridica> {
  final int? id;
  final int? idPessoa;
  final String? cnpj;
  final String? nomeFantasia;
  final String? inscricaoEstadual;
  final String? inscricaoMunicipal;
  final DateTime? dataConstituicao;
  final String? tipoRegime;
  final String? crt;
  const PessoaJuridica(
      {this.id,
      this.idPessoa,
      this.cnpj,
      this.nomeFantasia,
      this.inscricaoEstadual,
      this.inscricaoMunicipal,
      this.dataConstituicao,
      this.tipoRegime,
      this.crt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || nomeFantasia != null) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia);
    }
    if (!nullToAbsent || inscricaoEstadual != null) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual);
    }
    if (!nullToAbsent || inscricaoMunicipal != null) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal);
    }
    if (!nullToAbsent || dataConstituicao != null) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao);
    }
    if (!nullToAbsent || tipoRegime != null) {
      map['tipo_regime'] = Variable<String>(tipoRegime);
    }
    if (!nullToAbsent || crt != null) {
      map['crt'] = Variable<String>(crt);
    }
    return map;
  }

  factory PessoaJuridica.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaJuridica(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      nomeFantasia: serializer.fromJson<String?>(json['nomeFantasia']),
      inscricaoEstadual:
          serializer.fromJson<String?>(json['inscricaoEstadual']),
      inscricaoMunicipal:
          serializer.fromJson<String?>(json['inscricaoMunicipal']),
      dataConstituicao:
          serializer.fromJson<DateTime?>(json['dataConstituicao']),
      tipoRegime: serializer.fromJson<String?>(json['tipoRegime']),
      crt: serializer.fromJson<String?>(json['crt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'cnpj': serializer.toJson<String?>(cnpj),
      'nomeFantasia': serializer.toJson<String?>(nomeFantasia),
      'inscricaoEstadual': serializer.toJson<String?>(inscricaoEstadual),
      'inscricaoMunicipal': serializer.toJson<String?>(inscricaoMunicipal),
      'dataConstituicao': serializer.toJson<DateTime?>(dataConstituicao),
      'tipoRegime': serializer.toJson<String?>(tipoRegime),
      'crt': serializer.toJson<String?>(crt),
    };
  }

  PessoaJuridica copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> nomeFantasia = const Value.absent(),
          Value<String?> inscricaoEstadual = const Value.absent(),
          Value<String?> inscricaoMunicipal = const Value.absent(),
          Value<DateTime?> dataConstituicao = const Value.absent(),
          Value<String?> tipoRegime = const Value.absent(),
          Value<String?> crt = const Value.absent()}) =>
      PessoaJuridica(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        nomeFantasia:
            nomeFantasia.present ? nomeFantasia.value : this.nomeFantasia,
        inscricaoEstadual: inscricaoEstadual.present
            ? inscricaoEstadual.value
            : this.inscricaoEstadual,
        inscricaoMunicipal: inscricaoMunicipal.present
            ? inscricaoMunicipal.value
            : this.inscricaoMunicipal,
        dataConstituicao: dataConstituicao.present
            ? dataConstituicao.value
            : this.dataConstituicao,
        tipoRegime: tipoRegime.present ? tipoRegime.value : this.tipoRegime,
        crt: crt.present ? crt.value : this.crt,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaJuridica(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('cnpj: $cnpj, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, cnpj, nomeFantasia,
      inscricaoEstadual, inscricaoMunicipal, dataConstituicao, tipoRegime, crt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaJuridica &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.cnpj == this.cnpj &&
          other.nomeFantasia == this.nomeFantasia &&
          other.inscricaoEstadual == this.inscricaoEstadual &&
          other.inscricaoMunicipal == this.inscricaoMunicipal &&
          other.dataConstituicao == this.dataConstituicao &&
          other.tipoRegime == this.tipoRegime &&
          other.crt == this.crt);
}

class PessoaJuridicasCompanion extends UpdateCompanion<PessoaJuridica> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> cnpj;
  final Value<String?> nomeFantasia;
  final Value<String?> inscricaoEstadual;
  final Value<String?> inscricaoMunicipal;
  final Value<DateTime?> dataConstituicao;
  final Value<String?> tipoRegime;
  final Value<String?> crt;
  const PessoaJuridicasCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
  });
  PessoaJuridicasCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nomeFantasia = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.dataConstituicao = const Value.absent(),
    this.tipoRegime = const Value.absent(),
    this.crt = const Value.absent(),
  });
  static Insertable<PessoaJuridica> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? cnpj,
    Expression<String>? nomeFantasia,
    Expression<String>? inscricaoEstadual,
    Expression<String>? inscricaoMunicipal,
    Expression<DateTime>? dataConstituicao,
    Expression<String>? tipoRegime,
    Expression<String>? crt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (cnpj != null) 'cnpj': cnpj,
      if (nomeFantasia != null) 'nome_fantasia': nomeFantasia,
      if (inscricaoEstadual != null) 'inscricao_estadual': inscricaoEstadual,
      if (inscricaoMunicipal != null) 'inscricao_municipal': inscricaoMunicipal,
      if (dataConstituicao != null) 'data_constituicao': dataConstituicao,
      if (tipoRegime != null) 'tipo_regime': tipoRegime,
      if (crt != null) 'crt': crt,
    });
  }

  PessoaJuridicasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? cnpj,
      Value<String?>? nomeFantasia,
      Value<String?>? inscricaoEstadual,
      Value<String?>? inscricaoMunicipal,
      Value<DateTime?>? dataConstituicao,
      Value<String?>? tipoRegime,
      Value<String?>? crt}) {
    return PessoaJuridicasCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      cnpj: cnpj ?? this.cnpj,
      nomeFantasia: nomeFantasia ?? this.nomeFantasia,
      inscricaoEstadual: inscricaoEstadual ?? this.inscricaoEstadual,
      inscricaoMunicipal: inscricaoMunicipal ?? this.inscricaoMunicipal,
      dataConstituicao: dataConstituicao ?? this.dataConstituicao,
      tipoRegime: tipoRegime ?? this.tipoRegime,
      crt: crt ?? this.crt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (nomeFantasia.present) {
      map['nome_fantasia'] = Variable<String>(nomeFantasia.value);
    }
    if (inscricaoEstadual.present) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual.value);
    }
    if (inscricaoMunicipal.present) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal.value);
    }
    if (dataConstituicao.present) {
      map['data_constituicao'] = Variable<DateTime>(dataConstituicao.value);
    }
    if (tipoRegime.present) {
      map['tipo_regime'] = Variable<String>(tipoRegime.value);
    }
    if (crt.present) {
      map['crt'] = Variable<String>(crt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaJuridicasCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('cnpj: $cnpj, ')
          ..write('nomeFantasia: $nomeFantasia, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('dataConstituicao: $dataConstituicao, ')
          ..write('tipoRegime: $tipoRegime, ')
          ..write('crt: $crt')
          ..write(')'))
        .toString();
  }
}

class $ClientesTable extends Clientes with TableInfo<$ClientesTable, Cliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTabelaPrecoMeta =
      const VerificationMeta('idTabelaPreco');
  @override
  late final GeneratedColumn<int> idTabelaPreco = GeneratedColumn<int>(
      'id_tabela_preco', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _limiteCreditoMeta =
      const VerificationMeta('limiteCredito');
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
      'limite_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idTabelaPreco,
        desde,
        dataCadastro,
        taxaDesconto,
        limiteCredito,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cliente';
  @override
  VerificationContext validateIntegrity(Insertable<Cliente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_tabela_preco')) {
      context.handle(
          _idTabelaPrecoMeta,
          idTabelaPreco.isAcceptableOrUnknown(
              data['id_tabela_preco']!, _idTabelaPrecoMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
          _limiteCreditoMeta,
          limiteCredito.isAcceptableOrUnknown(
              data['limite_credito']!, _limiteCreditoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cliente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idTabelaPreco: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_tabela_preco']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      limiteCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}limite_credito']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ClientesTable createAlias(String alias) {
    return $ClientesTable(attachedDatabase, alias);
  }
}

class Cliente extends DataClass implements Insertable<Cliente> {
  final int? id;
  final int? idPessoa;
  final int? idTabelaPreco;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final double? taxaDesconto;
  final double? limiteCredito;
  final String? observacao;
  const Cliente(
      {this.id,
      this.idPessoa,
      this.idTabelaPreco,
      this.desde,
      this.dataCadastro,
      this.taxaDesconto,
      this.limiteCredito,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idTabelaPreco != null) {
      map['id_tabela_preco'] = Variable<int>(idTabelaPreco);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Cliente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cliente(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idTabelaPreco: serializer.fromJson<int?>(json['idTabelaPreco']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idTabelaPreco': serializer.toJson<int?>(idTabelaPreco),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Cliente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idTabelaPreco = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> limiteCredito = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Cliente(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idTabelaPreco:
            idTabelaPreco.present ? idTabelaPreco.value : this.idTabelaPreco,
        desde: desde.present ? desde.value : this.desde,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        limiteCredito:
            limiteCredito.present ? limiteCredito.value : this.limiteCredito,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Cliente(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idTabelaPreco: $idTabelaPreco, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, idTabelaPreco, desde,
      dataCadastro, taxaDesconto, limiteCredito, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cliente &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idTabelaPreco == this.idTabelaPreco &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.observacao == this.observacao);
}

class ClientesCompanion extends UpdateCompanion<Cliente> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idTabelaPreco;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<String?> observacao;
  const ClientesCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idTabelaPreco = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ClientesCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idTabelaPreco = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Cliente> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idTabelaPreco,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idTabelaPreco != null) 'id_tabela_preco': idTabelaPreco,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ClientesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idTabelaPreco,
      Value<DateTime?>? desde,
      Value<DateTime?>? dataCadastro,
      Value<double?>? taxaDesconto,
      Value<double?>? limiteCredito,
      Value<String?>? observacao}) {
    return ClientesCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idTabelaPreco: idTabelaPreco ?? this.idTabelaPreco,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idTabelaPreco.present) {
      map['id_tabela_preco'] = Variable<int>(idTabelaPreco.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ClientesCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idTabelaPreco: $idTabelaPreco, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FornecedorsTable extends Fornecedors
    with TableInfo<$FornecedorsTable, Fornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPessoa, desde, dataCadastro, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fornecedor';
  @override
  VerificationContext validateIntegrity(Insertable<Fornecedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Fornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Fornecedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FornecedorsTable createAlias(String alias) {
    return $FornecedorsTable(attachedDatabase, alias);
  }
}

class Fornecedor extends DataClass implements Insertable<Fornecedor> {
  final int? id;
  final int? idPessoa;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final String? observacao;
  const Fornecedor(
      {this.id, this.idPessoa, this.desde, this.dataCadastro, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Fornecedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Fornecedor(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Fornecedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Fornecedor(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        desde: desde.present ? desde.value : this.desde,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Fornecedor(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idPessoa, desde, dataCadastro, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Fornecedor &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao);
}

class FornecedorsCompanion extends UpdateCompanion<Fornecedor> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  const FornecedorsCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Fornecedor> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FornecedorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<DateTime?>? desde,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao}) {
    return FornecedorsCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $TransportadorasTable extends Transportadoras
    with TableInfo<$TransportadorasTable, Transportadora> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TransportadorasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPessoa, dataCadastro, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'transportadora';
  @override
  VerificationContext validateIntegrity(Insertable<Transportadora> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Transportadora map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Transportadora(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $TransportadorasTable createAlias(String alias) {
    return $TransportadorasTable(attachedDatabase, alias);
  }
}

class Transportadora extends DataClass implements Insertable<Transportadora> {
  final int? id;
  final int? idPessoa;
  final DateTime? dataCadastro;
  final String? observacao;
  const Transportadora(
      {this.id, this.idPessoa, this.dataCadastro, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Transportadora.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Transportadora(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Transportadora copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Transportadora(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Transportadora(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, dataCadastro, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Transportadora &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao);
}

class TransportadorasCompanion extends UpdateCompanion<Transportadora> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  const TransportadorasCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  TransportadorasCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Transportadora> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
    });
  }

  TransportadorasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao}) {
    return TransportadorasCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TransportadorasCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ContadorsTable extends Contadors
    with TableInfo<$ContadorsTable, Contador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContadorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _crcInscricaoMeta =
      const VerificationMeta('crcInscricao');
  @override
  late final GeneratedColumn<String> crcInscricao = GeneratedColumn<String>(
      'crc_inscricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _crcUfMeta = const VerificationMeta('crcUf');
  @override
  late final GeneratedColumn<String> crcUf = GeneratedColumn<String>(
      'crc_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, crcInscricao, crcUf];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contador';
  @override
  VerificationContext validateIntegrity(Insertable<Contador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('crc_inscricao')) {
      context.handle(
          _crcInscricaoMeta,
          crcInscricao.isAcceptableOrUnknown(
              data['crc_inscricao']!, _crcInscricaoMeta));
    }
    if (data.containsKey('crc_uf')) {
      context.handle(
          _crcUfMeta, crcUf.isAcceptableOrUnknown(data['crc_uf']!, _crcUfMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Contador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Contador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      crcInscricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crc_inscricao']),
      crcUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}crc_uf']),
    );
  }

  @override
  $ContadorsTable createAlias(String alias) {
    return $ContadorsTable(attachedDatabase, alias);
  }
}

class Contador extends DataClass implements Insertable<Contador> {
  final int? id;
  final int? idPessoa;
  final String? crcInscricao;
  final String? crcUf;
  const Contador({this.id, this.idPessoa, this.crcInscricao, this.crcUf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || crcInscricao != null) {
      map['crc_inscricao'] = Variable<String>(crcInscricao);
    }
    if (!nullToAbsent || crcUf != null) {
      map['crc_uf'] = Variable<String>(crcUf);
    }
    return map;
  }

  factory Contador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Contador(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      crcInscricao: serializer.fromJson<String?>(json['crcInscricao']),
      crcUf: serializer.fromJson<String?>(json['crcUf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'crcInscricao': serializer.toJson<String?>(crcInscricao),
      'crcUf': serializer.toJson<String?>(crcUf),
    };
  }

  Contador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> crcInscricao = const Value.absent(),
          Value<String?> crcUf = const Value.absent()}) =>
      Contador(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        crcInscricao:
            crcInscricao.present ? crcInscricao.value : this.crcInscricao,
        crcUf: crcUf.present ? crcUf.value : this.crcUf,
      );
  @override
  String toString() {
    return (StringBuffer('Contador(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('crcInscricao: $crcInscricao, ')
          ..write('crcUf: $crcUf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, crcInscricao, crcUf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Contador &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.crcInscricao == this.crcInscricao &&
          other.crcUf == this.crcUf);
}

class ContadorsCompanion extends UpdateCompanion<Contador> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> crcInscricao;
  final Value<String?> crcUf;
  const ContadorsCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.crcInscricao = const Value.absent(),
    this.crcUf = const Value.absent(),
  });
  ContadorsCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.crcInscricao = const Value.absent(),
    this.crcUf = const Value.absent(),
  });
  static Insertable<Contador> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? crcInscricao,
    Expression<String>? crcUf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (crcInscricao != null) 'crc_inscricao': crcInscricao,
      if (crcUf != null) 'crc_uf': crcUf,
    });
  }

  ContadorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? crcInscricao,
      Value<String?>? crcUf}) {
    return ContadorsCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      crcInscricao: crcInscricao ?? this.crcInscricao,
      crcUf: crcUf ?? this.crcUf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (crcInscricao.present) {
      map['crc_inscricao'] = Variable<String>(crcInscricao.value);
    }
    if (crcUf.present) {
      map['crc_uf'] = Variable<String>(crcUf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContadorsCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('crcInscricao: $crcInscricao, ')
          ..write('crcUf: $crcUf')
          ..write(')'))
        .toString();
  }
}

class $VendedorsTable extends Vendedors
    with TableInfo<$VendedorsTable, Vendedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idComissaoPerfilMeta =
      const VerificationMeta('idComissaoPerfil');
  @override
  late final GeneratedColumn<int> idComissaoPerfil = GeneratedColumn<int>(
      'id_comissao_perfil', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _comissaoMeta =
      const VerificationMeta('comissao');
  @override
  late final GeneratedColumn<double> comissao = GeneratedColumn<double>(
      'comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _metaVendaMeta =
      const VerificationMeta('metaVenda');
  @override
  late final GeneratedColumn<double> metaVenda = GeneratedColumn<double>(
      'meta_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, idComissaoPerfil, comissao, metaVenda];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'vendedor';
  @override
  VerificationContext validateIntegrity(Insertable<Vendedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_comissao_perfil')) {
      context.handle(
          _idComissaoPerfilMeta,
          idComissaoPerfil.isAcceptableOrUnknown(
              data['id_comissao_perfil']!, _idComissaoPerfilMeta));
    }
    if (data.containsKey('comissao')) {
      context.handle(_comissaoMeta,
          comissao.isAcceptableOrUnknown(data['comissao']!, _comissaoMeta));
    }
    if (data.containsKey('meta_venda')) {
      context.handle(_metaVendaMeta,
          metaVenda.isAcceptableOrUnknown(data['meta_venda']!, _metaVendaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Vendedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Vendedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idComissaoPerfil: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_comissao_perfil']),
      comissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}comissao']),
      metaVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}meta_venda']),
    );
  }

  @override
  $VendedorsTable createAlias(String alias) {
    return $VendedorsTable(attachedDatabase, alias);
  }
}

class Vendedor extends DataClass implements Insertable<Vendedor> {
  final int? id;
  final int? idColaborador;
  final int? idComissaoPerfil;
  final double? comissao;
  final double? metaVenda;
  const Vendedor(
      {this.id,
      this.idColaborador,
      this.idComissaoPerfil,
      this.comissao,
      this.metaVenda});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idComissaoPerfil != null) {
      map['id_comissao_perfil'] = Variable<int>(idComissaoPerfil);
    }
    if (!nullToAbsent || comissao != null) {
      map['comissao'] = Variable<double>(comissao);
    }
    if (!nullToAbsent || metaVenda != null) {
      map['meta_venda'] = Variable<double>(metaVenda);
    }
    return map;
  }

  factory Vendedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Vendedor(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idComissaoPerfil: serializer.fromJson<int?>(json['idComissaoPerfil']),
      comissao: serializer.fromJson<double?>(json['comissao']),
      metaVenda: serializer.fromJson<double?>(json['metaVenda']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idComissaoPerfil': serializer.toJson<int?>(idComissaoPerfil),
      'comissao': serializer.toJson<double?>(comissao),
      'metaVenda': serializer.toJson<double?>(metaVenda),
    };
  }

  Vendedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idComissaoPerfil = const Value.absent(),
          Value<double?> comissao = const Value.absent(),
          Value<double?> metaVenda = const Value.absent()}) =>
      Vendedor(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idComissaoPerfil: idComissaoPerfil.present
            ? idComissaoPerfil.value
            : this.idComissaoPerfil,
        comissao: comissao.present ? comissao.value : this.comissao,
        metaVenda: metaVenda.present ? metaVenda.value : this.metaVenda,
      );
  @override
  String toString() {
    return (StringBuffer('Vendedor(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idComissaoPerfil: $idComissaoPerfil, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idColaborador, idComissaoPerfil, comissao, metaVenda);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Vendedor &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idComissaoPerfil == this.idComissaoPerfil &&
          other.comissao == this.comissao &&
          other.metaVenda == this.metaVenda);
}

class VendedorsCompanion extends UpdateCompanion<Vendedor> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idComissaoPerfil;
  final Value<double?> comissao;
  final Value<double?> metaVenda;
  const VendedorsCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idComissaoPerfil = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  VendedorsCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idComissaoPerfil = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  static Insertable<Vendedor> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idComissaoPerfil,
    Expression<double>? comissao,
    Expression<double>? metaVenda,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idComissaoPerfil != null) 'id_comissao_perfil': idComissaoPerfil,
      if (comissao != null) 'comissao': comissao,
      if (metaVenda != null) 'meta_venda': metaVenda,
    });
  }

  VendedorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? idComissaoPerfil,
      Value<double?>? comissao,
      Value<double?>? metaVenda}) {
    return VendedorsCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idComissaoPerfil: idComissaoPerfil ?? this.idComissaoPerfil,
      comissao: comissao ?? this.comissao,
      metaVenda: metaVenda ?? this.metaVenda,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idComissaoPerfil.present) {
      map['id_comissao_perfil'] = Variable<int>(idComissaoPerfil.value);
    }
    if (comissao.present) {
      map['comissao'] = Variable<double>(comissao.value);
    }
    if (metaVenda.present) {
      map['meta_venda'] = Variable<double>(metaVenda.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendedorsCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idComissaoPerfil: $idComissaoPerfil, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }
}

class $PessoaEnderecosTable extends PessoaEnderecos
    with TableInfo<$PessoaEnderecosTable, PessoaEndereco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaEnderecosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<int> municipioIbge = GeneratedColumn<int>(
      'municipio_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _principalMeta =
      const VerificationMeta('principal');
  @override
  late final GeneratedColumn<String> principal = GeneratedColumn<String>(
      'principal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entregaMeta =
      const VerificationMeta('entrega');
  @override
  late final GeneratedColumn<String> entrega = GeneratedColumn<String>(
      'entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cobrancaMeta =
      const VerificationMeta('cobranca');
  @override
  late final GeneratedColumn<String> cobranca = GeneratedColumn<String>(
      'cobranca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _correspondenciaMeta =
      const VerificationMeta('correspondencia');
  @override
  late final GeneratedColumn<String> correspondencia = GeneratedColumn<String>(
      'correspondencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        uf,
        cep,
        municipioIbge,
        principal,
        entrega,
        cobranca,
        correspondencia
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa_endereco';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaEndereco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('principal')) {
      context.handle(_principalMeta,
          principal.isAcceptableOrUnknown(data['principal']!, _principalMeta));
    }
    if (data.containsKey('entrega')) {
      context.handle(_entregaMeta,
          entrega.isAcceptableOrUnknown(data['entrega']!, _entregaMeta));
    }
    if (data.containsKey('cobranca')) {
      context.handle(_cobrancaMeta,
          cobranca.isAcceptableOrUnknown(data['cobranca']!, _cobrancaMeta));
    }
    if (data.containsKey('correspondencia')) {
      context.handle(
          _correspondenciaMeta,
          correspondencia.isAcceptableOrUnknown(
              data['correspondencia']!, _correspondenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaEndereco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaEndereco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}municipio_ibge']),
      principal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}principal']),
      entrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrega']),
      cobranca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cobranca']),
      correspondencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}correspondencia']),
    );
  }

  @override
  $PessoaEnderecosTable createAlias(String alias) {
    return $PessoaEnderecosTable(attachedDatabase, alias);
  }
}

class PessoaEndereco extends DataClass implements Insertable<PessoaEndereco> {
  final int? id;
  final int? idPessoa;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? uf;
  final String? cep;
  final int? municipioIbge;
  final String? principal;
  final String? entrega;
  final String? cobranca;
  final String? correspondencia;
  const PessoaEndereco(
      {this.id,
      this.idPessoa,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.uf,
      this.cep,
      this.municipioIbge,
      this.principal,
      this.entrega,
      this.cobranca,
      this.correspondencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<int>(municipioIbge);
    }
    if (!nullToAbsent || principal != null) {
      map['principal'] = Variable<String>(principal);
    }
    if (!nullToAbsent || entrega != null) {
      map['entrega'] = Variable<String>(entrega);
    }
    if (!nullToAbsent || cobranca != null) {
      map['cobranca'] = Variable<String>(cobranca);
    }
    if (!nullToAbsent || correspondencia != null) {
      map['correspondencia'] = Variable<String>(correspondencia);
    }
    return map;
  }

  factory PessoaEndereco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaEndereco(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<int?>(json['municipioIbge']),
      principal: serializer.fromJson<String?>(json['principal']),
      entrega: serializer.fromJson<String?>(json['entrega']),
      cobranca: serializer.fromJson<String?>(json['cobranca']),
      correspondencia: serializer.fromJson<String?>(json['correspondencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<int?>(municipioIbge),
      'principal': serializer.toJson<String?>(principal),
      'entrega': serializer.toJson<String?>(entrega),
      'cobranca': serializer.toJson<String?>(cobranca),
      'correspondencia': serializer.toJson<String?>(correspondencia),
    };
  }

  PessoaEndereco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> municipioIbge = const Value.absent(),
          Value<String?> principal = const Value.absent(),
          Value<String?> entrega = const Value.absent(),
          Value<String?> cobranca = const Value.absent(),
          Value<String?> correspondencia = const Value.absent()}) =>
      PessoaEndereco(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        principal: principal.present ? principal.value : this.principal,
        entrega: entrega.present ? entrega.value : this.entrega,
        cobranca: cobranca.present ? cobranca.value : this.cobranca,
        correspondencia: correspondencia.present
            ? correspondencia.value
            : this.correspondencia,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaEndereco(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      logradouro,
      numero,
      complemento,
      bairro,
      cidade,
      uf,
      cep,
      municipioIbge,
      principal,
      entrega,
      cobranca,
      correspondencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaEndereco &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.principal == this.principal &&
          other.entrega == this.entrega &&
          other.cobranca == this.cobranca &&
          other.correspondencia == this.correspondencia);
}

class PessoaEnderecosCompanion extends UpdateCompanion<PessoaEndereco> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> municipioIbge;
  final Value<String?> principal;
  final Value<String?> entrega;
  final Value<String?> cobranca;
  final Value<String?> correspondencia;
  const PessoaEnderecosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  PessoaEnderecosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.principal = const Value.absent(),
    this.entrega = const Value.absent(),
    this.cobranca = const Value.absent(),
    this.correspondencia = const Value.absent(),
  });
  static Insertable<PessoaEndereco> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? municipioIbge,
    Expression<String>? principal,
    Expression<String>? entrega,
    Expression<String>? cobranca,
    Expression<String>? correspondencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (principal != null) 'principal': principal,
      if (entrega != null) 'entrega': entrega,
      if (cobranca != null) 'cobranca': cobranca,
      if (correspondencia != null) 'correspondencia': correspondencia,
    });
  }

  PessoaEnderecosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? municipioIbge,
      Value<String?>? principal,
      Value<String?>? entrega,
      Value<String?>? cobranca,
      Value<String?>? correspondencia}) {
    return PessoaEnderecosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      principal: principal ?? this.principal,
      entrega: entrega ?? this.entrega,
      cobranca: cobranca ?? this.cobranca,
      correspondencia: correspondencia ?? this.correspondencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<int>(municipioIbge.value);
    }
    if (principal.present) {
      map['principal'] = Variable<String>(principal.value);
    }
    if (entrega.present) {
      map['entrega'] = Variable<String>(entrega.value);
    }
    if (cobranca.present) {
      map['cobranca'] = Variable<String>(cobranca.value);
    }
    if (correspondencia.present) {
      map['correspondencia'] = Variable<String>(correspondencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaEnderecosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('principal: $principal, ')
          ..write('entrega: $entrega, ')
          ..write('cobranca: $cobranca, ')
          ..write('correspondencia: $correspondencia')
          ..write(')'))
        .toString();
  }
}

class $PessoaContatosTable extends PessoaContatos
    with TableInfo<$PessoaContatosTable, PessoaContato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaContatosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, nome, email, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa_contato';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaContato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaContato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaContato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PessoaContatosTable createAlias(String alias) {
    return $PessoaContatosTable(attachedDatabase, alias);
  }
}

class PessoaContato extends DataClass implements Insertable<PessoaContato> {
  final int? id;
  final int? idPessoa;
  final String? nome;
  final String? email;
  final String? observacao;
  const PessoaContato(
      {this.id, this.idPessoa, this.nome, this.email, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PessoaContato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaContato(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      nome: serializer.fromJson<String?>(json['nome']),
      email: serializer.fromJson<String?>(json['email']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'nome': serializer.toJson<String?>(nome),
      'email': serializer.toJson<String?>(email),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PessoaContato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PessoaContato(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        nome: nome.present ? nome.value : this.nome,
        email: email.present ? email.value : this.email,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaContato(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, nome, email, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaContato &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.nome == this.nome &&
          other.email == this.email &&
          other.observacao == this.observacao);
}

class PessoaContatosCompanion extends UpdateCompanion<PessoaContato> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> nome;
  final Value<String?> email;
  final Value<String?> observacao;
  const PessoaContatosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PessoaContatosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.nome = const Value.absent(),
    this.email = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PessoaContato> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? nome,
    Expression<String>? email,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (nome != null) 'nome': nome,
      if (email != null) 'email': email,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PessoaContatosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? nome,
      Value<String?>? email,
      Value<String?>? observacao}) {
    return PessoaContatosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      nome: nome ?? this.nome,
      email: email ?? this.email,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaContatosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('nome: $nome, ')
          ..write('email: $email, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PessoaTelefonesTable extends PessoaTelefones
    with TableInfo<$PessoaTelefonesTable, PessoaTelefone> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoaTelefonesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPessoa, tipo, numero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa_telefone';
  @override
  VerificationContext validateIntegrity(Insertable<PessoaTelefone> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PessoaTelefone map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PessoaTelefone(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
    );
  }

  @override
  $PessoaTelefonesTable createAlias(String alias) {
    return $PessoaTelefonesTable(attachedDatabase, alias);
  }
}

class PessoaTelefone extends DataClass implements Insertable<PessoaTelefone> {
  final int? id;
  final int? idPessoa;
  final String? tipo;
  final String? numero;
  const PessoaTelefone({this.id, this.idPessoa, this.tipo, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory PessoaTelefone.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PessoaTelefone(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'tipo': serializer.toJson<String?>(tipo),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  PessoaTelefone copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> numero = const Value.absent()}) =>
      PessoaTelefone(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        tipo: tipo.present ? tipo.value : this.tipo,
        numero: numero.present ? numero.value : this.numero,
      );
  @override
  String toString() {
    return (StringBuffer('PessoaTelefone(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, tipo, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PessoaTelefone &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.tipo == this.tipo &&
          other.numero == this.numero);
}

class PessoaTelefonesCompanion extends UpdateCompanion<PessoaTelefone> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> tipo;
  final Value<String?> numero;
  const PessoaTelefonesCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  PessoaTelefonesCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.tipo = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<PessoaTelefone> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? tipo,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (tipo != null) 'tipo': tipo,
      if (numero != null) 'numero': numero,
    });
  }

  PessoaTelefonesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? tipo,
      Value<String?>? numero}) {
    return PessoaTelefonesCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      tipo: tipo ?? this.tipo,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoaTelefonesCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('tipo: $tipo, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $ColaboradorRelacionamentosTable extends ColaboradorRelacionamentos
    with
        TableInfo<$ColaboradorRelacionamentosTable, ColaboradorRelacionamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ColaboradorRelacionamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTipoRelacionamentoMeta =
      const VerificationMeta('idTipoRelacionamento');
  @override
  late final GeneratedColumn<int> idTipoRelacionamento = GeneratedColumn<int>(
      'id_tipo_relacionamento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataNascimentoMeta =
      const VerificationMeta('dataNascimento');
  @override
  late final GeneratedColumn<DateTime> dataNascimento =
      GeneratedColumn<DateTime>('data_nascimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _registroMatriculaMeta =
      const VerificationMeta('registroMatricula');
  @override
  late final GeneratedColumn<String> registroMatricula =
      GeneratedColumn<String>('registro_matricula', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 50),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _registroCartorioMeta =
      const VerificationMeta('registroCartorio');
  @override
  late final GeneratedColumn<String> registroCartorio = GeneratedColumn<String>(
      'registro_cartorio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _registroCartorioNumeroMeta =
      const VerificationMeta('registroCartorioNumero');
  @override
  late final GeneratedColumn<String> registroCartorioNumero =
      GeneratedColumn<String>('registro_cartorio_numero', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 50),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _registroNumeroLivroMeta =
      const VerificationMeta('registroNumeroLivro');
  @override
  late final GeneratedColumn<String> registroNumeroLivro =
      GeneratedColumn<String>('registro_numero_livro', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 10),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _registroNumeroFolhaMeta =
      const VerificationMeta('registroNumeroFolha');
  @override
  late final GeneratedColumn<String> registroNumeroFolha =
      GeneratedColumn<String>('registro_numero_folha', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 10),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataEntregaDocumentoMeta =
      const VerificationMeta('dataEntregaDocumento');
  @override
  late final GeneratedColumn<DateTime> dataEntregaDocumento =
      GeneratedColumn<DateTime>('data_entrega_documento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _salarioFamiliaMeta =
      const VerificationMeta('salarioFamilia');
  @override
  late final GeneratedColumn<String> salarioFamilia = GeneratedColumn<String>(
      'salario_familia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _salarioFamiliaIdadeLimiteMeta =
      const VerificationMeta('salarioFamiliaIdadeLimite');
  @override
  late final GeneratedColumn<int> salarioFamiliaIdadeLimite =
      GeneratedColumn<int>('salario_familia_idade_limite', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _salarioFamiliaDataFimMeta =
      const VerificationMeta('salarioFamiliaDataFim');
  @override
  late final GeneratedColumn<DateTime> salarioFamiliaDataFim =
      GeneratedColumn<DateTime>('salario_familia_data_fim', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _impostoRendaIdadeLimiteMeta =
      const VerificationMeta('impostoRendaIdadeLimite');
  @override
  late final GeneratedColumn<int> impostoRendaIdadeLimite =
      GeneratedColumn<int>('imposto_renda_idade_limite', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _impostoRendaDataFimMeta =
      const VerificationMeta('impostoRendaDataFim');
  @override
  late final GeneratedColumn<int> impostoRendaDataFim = GeneratedColumn<int>(
      'imposto_renda_data_fim', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        idTipoRelacionamento,
        nome,
        dataNascimento,
        cpf,
        registroMatricula,
        registroCartorio,
        registroCartorioNumero,
        registroNumeroLivro,
        registroNumeroFolha,
        dataEntregaDocumento,
        salarioFamilia,
        salarioFamiliaIdadeLimite,
        salarioFamiliaDataFim,
        impostoRendaIdadeLimite,
        impostoRendaDataFim
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'colaborador_relacionamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<ColaboradorRelacionamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_tipo_relacionamento')) {
      context.handle(
          _idTipoRelacionamentoMeta,
          idTipoRelacionamento.isAcceptableOrUnknown(
              data['id_tipo_relacionamento']!, _idTipoRelacionamentoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('data_nascimento')) {
      context.handle(
          _dataNascimentoMeta,
          dataNascimento.isAcceptableOrUnknown(
              data['data_nascimento']!, _dataNascimentoMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('registro_matricula')) {
      context.handle(
          _registroMatriculaMeta,
          registroMatricula.isAcceptableOrUnknown(
              data['registro_matricula']!, _registroMatriculaMeta));
    }
    if (data.containsKey('registro_cartorio')) {
      context.handle(
          _registroCartorioMeta,
          registroCartorio.isAcceptableOrUnknown(
              data['registro_cartorio']!, _registroCartorioMeta));
    }
    if (data.containsKey('registro_cartorio_numero')) {
      context.handle(
          _registroCartorioNumeroMeta,
          registroCartorioNumero.isAcceptableOrUnknown(
              data['registro_cartorio_numero']!, _registroCartorioNumeroMeta));
    }
    if (data.containsKey('registro_numero_livro')) {
      context.handle(
          _registroNumeroLivroMeta,
          registroNumeroLivro.isAcceptableOrUnknown(
              data['registro_numero_livro']!, _registroNumeroLivroMeta));
    }
    if (data.containsKey('registro_numero_folha')) {
      context.handle(
          _registroNumeroFolhaMeta,
          registroNumeroFolha.isAcceptableOrUnknown(
              data['registro_numero_folha']!, _registroNumeroFolhaMeta));
    }
    if (data.containsKey('data_entrega_documento')) {
      context.handle(
          _dataEntregaDocumentoMeta,
          dataEntregaDocumento.isAcceptableOrUnknown(
              data['data_entrega_documento']!, _dataEntregaDocumentoMeta));
    }
    if (data.containsKey('salario_familia')) {
      context.handle(
          _salarioFamiliaMeta,
          salarioFamilia.isAcceptableOrUnknown(
              data['salario_familia']!, _salarioFamiliaMeta));
    }
    if (data.containsKey('salario_familia_idade_limite')) {
      context.handle(
          _salarioFamiliaIdadeLimiteMeta,
          salarioFamiliaIdadeLimite.isAcceptableOrUnknown(
              data['salario_familia_idade_limite']!,
              _salarioFamiliaIdadeLimiteMeta));
    }
    if (data.containsKey('salario_familia_data_fim')) {
      context.handle(
          _salarioFamiliaDataFimMeta,
          salarioFamiliaDataFim.isAcceptableOrUnknown(
              data['salario_familia_data_fim']!, _salarioFamiliaDataFimMeta));
    }
    if (data.containsKey('imposto_renda_idade_limite')) {
      context.handle(
          _impostoRendaIdadeLimiteMeta,
          impostoRendaIdadeLimite.isAcceptableOrUnknown(
              data['imposto_renda_idade_limite']!,
              _impostoRendaIdadeLimiteMeta));
    }
    if (data.containsKey('imposto_renda_data_fim')) {
      context.handle(
          _impostoRendaDataFimMeta,
          impostoRendaDataFim.isAcceptableOrUnknown(
              data['imposto_renda_data_fim']!, _impostoRendaDataFimMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ColaboradorRelacionamento map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ColaboradorRelacionamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idTipoRelacionamento: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_tipo_relacionamento']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      dataNascimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_nascimento']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      registroMatricula: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}registro_matricula']),
      registroCartorio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}registro_cartorio']),
      registroCartorioNumero: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}registro_cartorio_numero']),
      registroNumeroLivro: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}registro_numero_livro']),
      registroNumeroFolha: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}registro_numero_folha']),
      dataEntregaDocumento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_entrega_documento']),
      salarioFamilia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}salario_familia']),
      salarioFamiliaIdadeLimite: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}salario_familia_idade_limite']),
      salarioFamiliaDataFim: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}salario_familia_data_fim']),
      impostoRendaIdadeLimite: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}imposto_renda_idade_limite']),
      impostoRendaDataFim: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}imposto_renda_data_fim']),
    );
  }

  @override
  $ColaboradorRelacionamentosTable createAlias(String alias) {
    return $ColaboradorRelacionamentosTable(attachedDatabase, alias);
  }
}

class ColaboradorRelacionamento extends DataClass
    implements Insertable<ColaboradorRelacionamento> {
  final int? id;
  final int? idColaborador;
  final int? idTipoRelacionamento;
  final String? nome;
  final DateTime? dataNascimento;
  final String? cpf;
  final String? registroMatricula;
  final String? registroCartorio;
  final String? registroCartorioNumero;
  final String? registroNumeroLivro;
  final String? registroNumeroFolha;
  final DateTime? dataEntregaDocumento;
  final String? salarioFamilia;
  final int? salarioFamiliaIdadeLimite;
  final DateTime? salarioFamiliaDataFim;
  final int? impostoRendaIdadeLimite;
  final int? impostoRendaDataFim;
  const ColaboradorRelacionamento(
      {this.id,
      this.idColaborador,
      this.idTipoRelacionamento,
      this.nome,
      this.dataNascimento,
      this.cpf,
      this.registroMatricula,
      this.registroCartorio,
      this.registroCartorioNumero,
      this.registroNumeroLivro,
      this.registroNumeroFolha,
      this.dataEntregaDocumento,
      this.salarioFamilia,
      this.salarioFamiliaIdadeLimite,
      this.salarioFamiliaDataFim,
      this.impostoRendaIdadeLimite,
      this.impostoRendaDataFim});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idTipoRelacionamento != null) {
      map['id_tipo_relacionamento'] = Variable<int>(idTipoRelacionamento);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataNascimento != null) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || registroMatricula != null) {
      map['registro_matricula'] = Variable<String>(registroMatricula);
    }
    if (!nullToAbsent || registroCartorio != null) {
      map['registro_cartorio'] = Variable<String>(registroCartorio);
    }
    if (!nullToAbsent || registroCartorioNumero != null) {
      map['registro_cartorio_numero'] =
          Variable<String>(registroCartorioNumero);
    }
    if (!nullToAbsent || registroNumeroLivro != null) {
      map['registro_numero_livro'] = Variable<String>(registroNumeroLivro);
    }
    if (!nullToAbsent || registroNumeroFolha != null) {
      map['registro_numero_folha'] = Variable<String>(registroNumeroFolha);
    }
    if (!nullToAbsent || dataEntregaDocumento != null) {
      map['data_entrega_documento'] = Variable<DateTime>(dataEntregaDocumento);
    }
    if (!nullToAbsent || salarioFamilia != null) {
      map['salario_familia'] = Variable<String>(salarioFamilia);
    }
    if (!nullToAbsent || salarioFamiliaIdadeLimite != null) {
      map['salario_familia_idade_limite'] =
          Variable<int>(salarioFamiliaIdadeLimite);
    }
    if (!nullToAbsent || salarioFamiliaDataFim != null) {
      map['salario_familia_data_fim'] =
          Variable<DateTime>(salarioFamiliaDataFim);
    }
    if (!nullToAbsent || impostoRendaIdadeLimite != null) {
      map['imposto_renda_idade_limite'] =
          Variable<int>(impostoRendaIdadeLimite);
    }
    if (!nullToAbsent || impostoRendaDataFim != null) {
      map['imposto_renda_data_fim'] = Variable<int>(impostoRendaDataFim);
    }
    return map;
  }

  factory ColaboradorRelacionamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ColaboradorRelacionamento(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idTipoRelacionamento:
          serializer.fromJson<int?>(json['idTipoRelacionamento']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataNascimento: serializer.fromJson<DateTime?>(json['dataNascimento']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      registroMatricula:
          serializer.fromJson<String?>(json['registroMatricula']),
      registroCartorio: serializer.fromJson<String?>(json['registroCartorio']),
      registroCartorioNumero:
          serializer.fromJson<String?>(json['registroCartorioNumero']),
      registroNumeroLivro:
          serializer.fromJson<String?>(json['registroNumeroLivro']),
      registroNumeroFolha:
          serializer.fromJson<String?>(json['registroNumeroFolha']),
      dataEntregaDocumento:
          serializer.fromJson<DateTime?>(json['dataEntregaDocumento']),
      salarioFamilia: serializer.fromJson<String?>(json['salarioFamilia']),
      salarioFamiliaIdadeLimite:
          serializer.fromJson<int?>(json['salarioFamiliaIdadeLimite']),
      salarioFamiliaDataFim:
          serializer.fromJson<DateTime?>(json['salarioFamiliaDataFim']),
      impostoRendaIdadeLimite:
          serializer.fromJson<int?>(json['impostoRendaIdadeLimite']),
      impostoRendaDataFim:
          serializer.fromJson<int?>(json['impostoRendaDataFim']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idTipoRelacionamento': serializer.toJson<int?>(idTipoRelacionamento),
      'nome': serializer.toJson<String?>(nome),
      'dataNascimento': serializer.toJson<DateTime?>(dataNascimento),
      'cpf': serializer.toJson<String?>(cpf),
      'registroMatricula': serializer.toJson<String?>(registroMatricula),
      'registroCartorio': serializer.toJson<String?>(registroCartorio),
      'registroCartorioNumero':
          serializer.toJson<String?>(registroCartorioNumero),
      'registroNumeroLivro': serializer.toJson<String?>(registroNumeroLivro),
      'registroNumeroFolha': serializer.toJson<String?>(registroNumeroFolha),
      'dataEntregaDocumento':
          serializer.toJson<DateTime?>(dataEntregaDocumento),
      'salarioFamilia': serializer.toJson<String?>(salarioFamilia),
      'salarioFamiliaIdadeLimite':
          serializer.toJson<int?>(salarioFamiliaIdadeLimite),
      'salarioFamiliaDataFim':
          serializer.toJson<DateTime?>(salarioFamiliaDataFim),
      'impostoRendaIdadeLimite':
          serializer.toJson<int?>(impostoRendaIdadeLimite),
      'impostoRendaDataFim': serializer.toJson<int?>(impostoRendaDataFim),
    };
  }

  ColaboradorRelacionamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idTipoRelacionamento = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<DateTime?> dataNascimento = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> registroMatricula = const Value.absent(),
          Value<String?> registroCartorio = const Value.absent(),
          Value<String?> registroCartorioNumero = const Value.absent(),
          Value<String?> registroNumeroLivro = const Value.absent(),
          Value<String?> registroNumeroFolha = const Value.absent(),
          Value<DateTime?> dataEntregaDocumento = const Value.absent(),
          Value<String?> salarioFamilia = const Value.absent(),
          Value<int?> salarioFamiliaIdadeLimite = const Value.absent(),
          Value<DateTime?> salarioFamiliaDataFim = const Value.absent(),
          Value<int?> impostoRendaIdadeLimite = const Value.absent(),
          Value<int?> impostoRendaDataFim = const Value.absent()}) =>
      ColaboradorRelacionamento(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idTipoRelacionamento: idTipoRelacionamento.present
            ? idTipoRelacionamento.value
            : this.idTipoRelacionamento,
        nome: nome.present ? nome.value : this.nome,
        dataNascimento:
            dataNascimento.present ? dataNascimento.value : this.dataNascimento,
        cpf: cpf.present ? cpf.value : this.cpf,
        registroMatricula: registroMatricula.present
            ? registroMatricula.value
            : this.registroMatricula,
        registroCartorio: registroCartorio.present
            ? registroCartorio.value
            : this.registroCartorio,
        registroCartorioNumero: registroCartorioNumero.present
            ? registroCartorioNumero.value
            : this.registroCartorioNumero,
        registroNumeroLivro: registroNumeroLivro.present
            ? registroNumeroLivro.value
            : this.registroNumeroLivro,
        registroNumeroFolha: registroNumeroFolha.present
            ? registroNumeroFolha.value
            : this.registroNumeroFolha,
        dataEntregaDocumento: dataEntregaDocumento.present
            ? dataEntregaDocumento.value
            : this.dataEntregaDocumento,
        salarioFamilia:
            salarioFamilia.present ? salarioFamilia.value : this.salarioFamilia,
        salarioFamiliaIdadeLimite: salarioFamiliaIdadeLimite.present
            ? salarioFamiliaIdadeLimite.value
            : this.salarioFamiliaIdadeLimite,
        salarioFamiliaDataFim: salarioFamiliaDataFim.present
            ? salarioFamiliaDataFim.value
            : this.salarioFamiliaDataFim,
        impostoRendaIdadeLimite: impostoRendaIdadeLimite.present
            ? impostoRendaIdadeLimite.value
            : this.impostoRendaIdadeLimite,
        impostoRendaDataFim: impostoRendaDataFim.present
            ? impostoRendaDataFim.value
            : this.impostoRendaDataFim,
      );
  @override
  String toString() {
    return (StringBuffer('ColaboradorRelacionamento(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idTipoRelacionamento: $idTipoRelacionamento, ')
          ..write('nome: $nome, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('cpf: $cpf, ')
          ..write('registroMatricula: $registroMatricula, ')
          ..write('registroCartorio: $registroCartorio, ')
          ..write('registroCartorioNumero: $registroCartorioNumero, ')
          ..write('registroNumeroLivro: $registroNumeroLivro, ')
          ..write('registroNumeroFolha: $registroNumeroFolha, ')
          ..write('dataEntregaDocumento: $dataEntregaDocumento, ')
          ..write('salarioFamilia: $salarioFamilia, ')
          ..write('salarioFamiliaIdadeLimite: $salarioFamiliaIdadeLimite, ')
          ..write('salarioFamiliaDataFim: $salarioFamiliaDataFim, ')
          ..write('impostoRendaIdadeLimite: $impostoRendaIdadeLimite, ')
          ..write('impostoRendaDataFim: $impostoRendaDataFim')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idColaborador,
      idTipoRelacionamento,
      nome,
      dataNascimento,
      cpf,
      registroMatricula,
      registroCartorio,
      registroCartorioNumero,
      registroNumeroLivro,
      registroNumeroFolha,
      dataEntregaDocumento,
      salarioFamilia,
      salarioFamiliaIdadeLimite,
      salarioFamiliaDataFim,
      impostoRendaIdadeLimite,
      impostoRendaDataFim);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ColaboradorRelacionamento &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idTipoRelacionamento == this.idTipoRelacionamento &&
          other.nome == this.nome &&
          other.dataNascimento == this.dataNascimento &&
          other.cpf == this.cpf &&
          other.registroMatricula == this.registroMatricula &&
          other.registroCartorio == this.registroCartorio &&
          other.registroCartorioNumero == this.registroCartorioNumero &&
          other.registroNumeroLivro == this.registroNumeroLivro &&
          other.registroNumeroFolha == this.registroNumeroFolha &&
          other.dataEntregaDocumento == this.dataEntregaDocumento &&
          other.salarioFamilia == this.salarioFamilia &&
          other.salarioFamiliaIdadeLimite == this.salarioFamiliaIdadeLimite &&
          other.salarioFamiliaDataFim == this.salarioFamiliaDataFim &&
          other.impostoRendaIdadeLimite == this.impostoRendaIdadeLimite &&
          other.impostoRendaDataFim == this.impostoRendaDataFim);
}

class ColaboradorRelacionamentosCompanion
    extends UpdateCompanion<ColaboradorRelacionamento> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idTipoRelacionamento;
  final Value<String?> nome;
  final Value<DateTime?> dataNascimento;
  final Value<String?> cpf;
  final Value<String?> registroMatricula;
  final Value<String?> registroCartorio;
  final Value<String?> registroCartorioNumero;
  final Value<String?> registroNumeroLivro;
  final Value<String?> registroNumeroFolha;
  final Value<DateTime?> dataEntregaDocumento;
  final Value<String?> salarioFamilia;
  final Value<int?> salarioFamiliaIdadeLimite;
  final Value<DateTime?> salarioFamiliaDataFim;
  final Value<int?> impostoRendaIdadeLimite;
  final Value<int?> impostoRendaDataFim;
  const ColaboradorRelacionamentosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idTipoRelacionamento = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.cpf = const Value.absent(),
    this.registroMatricula = const Value.absent(),
    this.registroCartorio = const Value.absent(),
    this.registroCartorioNumero = const Value.absent(),
    this.registroNumeroLivro = const Value.absent(),
    this.registroNumeroFolha = const Value.absent(),
    this.dataEntregaDocumento = const Value.absent(),
    this.salarioFamilia = const Value.absent(),
    this.salarioFamiliaIdadeLimite = const Value.absent(),
    this.salarioFamiliaDataFim = const Value.absent(),
    this.impostoRendaIdadeLimite = const Value.absent(),
    this.impostoRendaDataFim = const Value.absent(),
  });
  ColaboradorRelacionamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idTipoRelacionamento = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.cpf = const Value.absent(),
    this.registroMatricula = const Value.absent(),
    this.registroCartorio = const Value.absent(),
    this.registroCartorioNumero = const Value.absent(),
    this.registroNumeroLivro = const Value.absent(),
    this.registroNumeroFolha = const Value.absent(),
    this.dataEntregaDocumento = const Value.absent(),
    this.salarioFamilia = const Value.absent(),
    this.salarioFamiliaIdadeLimite = const Value.absent(),
    this.salarioFamiliaDataFim = const Value.absent(),
    this.impostoRendaIdadeLimite = const Value.absent(),
    this.impostoRendaDataFim = const Value.absent(),
  });
  static Insertable<ColaboradorRelacionamento> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idTipoRelacionamento,
    Expression<String>? nome,
    Expression<DateTime>? dataNascimento,
    Expression<String>? cpf,
    Expression<String>? registroMatricula,
    Expression<String>? registroCartorio,
    Expression<String>? registroCartorioNumero,
    Expression<String>? registroNumeroLivro,
    Expression<String>? registroNumeroFolha,
    Expression<DateTime>? dataEntregaDocumento,
    Expression<String>? salarioFamilia,
    Expression<int>? salarioFamiliaIdadeLimite,
    Expression<DateTime>? salarioFamiliaDataFim,
    Expression<int>? impostoRendaIdadeLimite,
    Expression<int>? impostoRendaDataFim,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idTipoRelacionamento != null)
        'id_tipo_relacionamento': idTipoRelacionamento,
      if (nome != null) 'nome': nome,
      if (dataNascimento != null) 'data_nascimento': dataNascimento,
      if (cpf != null) 'cpf': cpf,
      if (registroMatricula != null) 'registro_matricula': registroMatricula,
      if (registroCartorio != null) 'registro_cartorio': registroCartorio,
      if (registroCartorioNumero != null)
        'registro_cartorio_numero': registroCartorioNumero,
      if (registroNumeroLivro != null)
        'registro_numero_livro': registroNumeroLivro,
      if (registroNumeroFolha != null)
        'registro_numero_folha': registroNumeroFolha,
      if (dataEntregaDocumento != null)
        'data_entrega_documento': dataEntregaDocumento,
      if (salarioFamilia != null) 'salario_familia': salarioFamilia,
      if (salarioFamiliaIdadeLimite != null)
        'salario_familia_idade_limite': salarioFamiliaIdadeLimite,
      if (salarioFamiliaDataFim != null)
        'salario_familia_data_fim': salarioFamiliaDataFim,
      if (impostoRendaIdadeLimite != null)
        'imposto_renda_idade_limite': impostoRendaIdadeLimite,
      if (impostoRendaDataFim != null)
        'imposto_renda_data_fim': impostoRendaDataFim,
    });
  }

  ColaboradorRelacionamentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? idTipoRelacionamento,
      Value<String?>? nome,
      Value<DateTime?>? dataNascimento,
      Value<String?>? cpf,
      Value<String?>? registroMatricula,
      Value<String?>? registroCartorio,
      Value<String?>? registroCartorioNumero,
      Value<String?>? registroNumeroLivro,
      Value<String?>? registroNumeroFolha,
      Value<DateTime?>? dataEntregaDocumento,
      Value<String?>? salarioFamilia,
      Value<int?>? salarioFamiliaIdadeLimite,
      Value<DateTime?>? salarioFamiliaDataFim,
      Value<int?>? impostoRendaIdadeLimite,
      Value<int?>? impostoRendaDataFim}) {
    return ColaboradorRelacionamentosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idTipoRelacionamento: idTipoRelacionamento ?? this.idTipoRelacionamento,
      nome: nome ?? this.nome,
      dataNascimento: dataNascimento ?? this.dataNascimento,
      cpf: cpf ?? this.cpf,
      registroMatricula: registroMatricula ?? this.registroMatricula,
      registroCartorio: registroCartorio ?? this.registroCartorio,
      registroCartorioNumero:
          registroCartorioNumero ?? this.registroCartorioNumero,
      registroNumeroLivro: registroNumeroLivro ?? this.registroNumeroLivro,
      registroNumeroFolha: registroNumeroFolha ?? this.registroNumeroFolha,
      dataEntregaDocumento: dataEntregaDocumento ?? this.dataEntregaDocumento,
      salarioFamilia: salarioFamilia ?? this.salarioFamilia,
      salarioFamiliaIdadeLimite:
          salarioFamiliaIdadeLimite ?? this.salarioFamiliaIdadeLimite,
      salarioFamiliaDataFim:
          salarioFamiliaDataFim ?? this.salarioFamiliaDataFim,
      impostoRendaIdadeLimite:
          impostoRendaIdadeLimite ?? this.impostoRendaIdadeLimite,
      impostoRendaDataFim: impostoRendaDataFim ?? this.impostoRendaDataFim,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idTipoRelacionamento.present) {
      map['id_tipo_relacionamento'] = Variable<int>(idTipoRelacionamento.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataNascimento.present) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (registroMatricula.present) {
      map['registro_matricula'] = Variable<String>(registroMatricula.value);
    }
    if (registroCartorio.present) {
      map['registro_cartorio'] = Variable<String>(registroCartorio.value);
    }
    if (registroCartorioNumero.present) {
      map['registro_cartorio_numero'] =
          Variable<String>(registroCartorioNumero.value);
    }
    if (registroNumeroLivro.present) {
      map['registro_numero_livro'] =
          Variable<String>(registroNumeroLivro.value);
    }
    if (registroNumeroFolha.present) {
      map['registro_numero_folha'] =
          Variable<String>(registroNumeroFolha.value);
    }
    if (dataEntregaDocumento.present) {
      map['data_entrega_documento'] =
          Variable<DateTime>(dataEntregaDocumento.value);
    }
    if (salarioFamilia.present) {
      map['salario_familia'] = Variable<String>(salarioFamilia.value);
    }
    if (salarioFamiliaIdadeLimite.present) {
      map['salario_familia_idade_limite'] =
          Variable<int>(salarioFamiliaIdadeLimite.value);
    }
    if (salarioFamiliaDataFim.present) {
      map['salario_familia_data_fim'] =
          Variable<DateTime>(salarioFamiliaDataFim.value);
    }
    if (impostoRendaIdadeLimite.present) {
      map['imposto_renda_idade_limite'] =
          Variable<int>(impostoRendaIdadeLimite.value);
    }
    if (impostoRendaDataFim.present) {
      map['imposto_renda_data_fim'] = Variable<int>(impostoRendaDataFim.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ColaboradorRelacionamentosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idTipoRelacionamento: $idTipoRelacionamento, ')
          ..write('nome: $nome, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('cpf: $cpf, ')
          ..write('registroMatricula: $registroMatricula, ')
          ..write('registroCartorio: $registroCartorio, ')
          ..write('registroCartorioNumero: $registroCartorioNumero, ')
          ..write('registroNumeroLivro: $registroNumeroLivro, ')
          ..write('registroNumeroFolha: $registroNumeroFolha, ')
          ..write('dataEntregaDocumento: $dataEntregaDocumento, ')
          ..write('salarioFamilia: $salarioFamilia, ')
          ..write('salarioFamiliaIdadeLimite: $salarioFamiliaIdadeLimite, ')
          ..write('salarioFamiliaDataFim: $salarioFamiliaDataFim, ')
          ..write('impostoRendaIdadeLimite: $impostoRendaIdadeLimite, ')
          ..write('impostoRendaDataFim: $impostoRendaDataFim')
          ..write(')'))
        .toString();
  }
}

class $PapelFuncaosTable extends PapelFuncaos
    with TableInfo<$PapelFuncaosTable, PapelFuncao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PapelFuncaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPapel,
        idFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'papel_funcao';
  @override
  VerificationContext validateIntegrity(Insertable<PapelFuncao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PapelFuncao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PapelFuncao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $PapelFuncaosTable createAlias(String alias) {
    return $PapelFuncaosTable(attachedDatabase, alias);
  }
}

class PapelFuncao extends DataClass implements Insertable<PapelFuncao> {
  final int? id;
  final int? idPapel;
  final int? idFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const PapelFuncao(
      {this.id,
      this.idPapel,
      this.idFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory PapelFuncao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PapelFuncao(
      id: serializer.fromJson<int?>(json['id']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPapel': serializer.toJson<int?>(idPapel),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  PapelFuncao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      PapelFuncao(
        id: id.present ? id.value : this.id,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('PapelFuncao(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPapel, idFuncao, habilitado, podeInserir, podeAlterar, podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PapelFuncao &&
          other.id == this.id &&
          other.idPapel == this.idPapel &&
          other.idFuncao == this.idFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class PapelFuncaosCompanion extends UpdateCompanion<PapelFuncao> {
  final Value<int?> id;
  final Value<int?> idPapel;
  final Value<int?> idFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const PapelFuncaosCompanion({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  PapelFuncaosCompanion.insert({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<PapelFuncao> custom({
    Expression<int>? id,
    Expression<int>? idPapel,
    Expression<int>? idFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPapel != null) 'id_papel': idPapel,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  PapelFuncaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPapel,
      Value<int?>? idFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return PapelFuncaosCompanion(
      id: id ?? this.id,
      idPapel: idPapel ?? this.idPapel,
      idFuncao: idFuncao ?? this.idFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PapelFuncaosCompanion(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $UsuariosTable extends Usuarios with TableInfo<$UsuariosTable, Usuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPapel, idColaborador, login, senha, administrador, dataCadastro];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'usuario';
  @override
  VerificationContext validateIntegrity(Insertable<Usuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Usuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Usuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
    );
  }

  @override
  $UsuariosTable createAlias(String alias) {
    return $UsuariosTable(attachedDatabase, alias);
  }
}

class Usuario extends DataClass implements Insertable<Usuario> {
  final int? id;
  final int? idPapel;
  final int? idColaborador;
  final String? login;
  final String? senha;
  final String? administrador;
  final DateTime? dataCadastro;
  const Usuario(
      {this.id,
      this.idPapel,
      this.idColaborador,
      this.login,
      this.senha,
      this.administrador,
      this.dataCadastro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Usuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Usuario(
      id: serializer.fromJson<int?>(json['id']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPapel': serializer.toJson<int?>(idPapel),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'administrador': serializer.toJson<String?>(administrador),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Usuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent()}) =>
      Usuario(
        id: id.present ? id.value : this.id,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
      );
  @override
  String toString() {
    return (StringBuffer('Usuario(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('administrador: $administrador, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPapel, idColaborador, login, senha, administrador, dataCadastro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Usuario &&
          other.id == this.id &&
          other.idPapel == this.idPapel &&
          other.idColaborador == this.idColaborador &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.administrador == this.administrador &&
          other.dataCadastro == this.dataCadastro);
}

class UsuariosCompanion extends UpdateCompanion<Usuario> {
  final Value<int?> id;
  final Value<int?> idPapel;
  final Value<int?> idColaborador;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<String?> administrador;
  final Value<DateTime?> dataCadastro;
  const UsuariosCompanion({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.administrador = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  UsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.administrador = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Usuario> custom({
    Expression<int>? id,
    Expression<int>? idPapel,
    Expression<int>? idColaborador,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<String>? administrador,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPapel != null) 'id_papel': idPapel,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (administrador != null) 'administrador': administrador,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  UsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPapel,
      Value<int?>? idColaborador,
      Value<String?>? login,
      Value<String?>? senha,
      Value<String?>? administrador,
      Value<DateTime?>? dataCadastro}) {
    return UsuariosCompanion(
      id: id ?? this.id,
      idPapel: idPapel ?? this.idPapel,
      idColaborador: idColaborador ?? this.idColaborador,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      administrador: administrador ?? this.administrador,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPapel: $idPapel, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('administrador: $administrador, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $PessoasTable extends Pessoas with TableInfo<$PessoasTable, Pessoa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PessoasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehClienteMeta =
      const VerificationMeta('ehCliente');
  @override
  late final GeneratedColumn<String> ehCliente = GeneratedColumn<String>(
      'eh_cliente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehFornecedorMeta =
      const VerificationMeta('ehFornecedor');
  @override
  late final GeneratedColumn<String> ehFornecedor = GeneratedColumn<String>(
      'eh_fornecedor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehTransportadoraMeta =
      const VerificationMeta('ehTransportadora');
  @override
  late final GeneratedColumn<String> ehTransportadora = GeneratedColumn<String>(
      'eh_transportadora', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehColaboradorMeta =
      const VerificationMeta('ehColaborador');
  @override
  late final GeneratedColumn<String> ehColaborador = GeneratedColumn<String>(
      'eh_colaborador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ehContadorMeta =
      const VerificationMeta('ehContador');
  @override
  late final GeneratedColumn<String> ehContador = GeneratedColumn<String>(
      'eh_contador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        site,
        email,
        ehCliente,
        ehFornecedor,
        ehTransportadora,
        ehColaborador,
        ehContador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pessoa';
  @override
  VerificationContext validateIntegrity(Insertable<Pessoa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('eh_cliente')) {
      context.handle(_ehClienteMeta,
          ehCliente.isAcceptableOrUnknown(data['eh_cliente']!, _ehClienteMeta));
    }
    if (data.containsKey('eh_fornecedor')) {
      context.handle(
          _ehFornecedorMeta,
          ehFornecedor.isAcceptableOrUnknown(
              data['eh_fornecedor']!, _ehFornecedorMeta));
    }
    if (data.containsKey('eh_transportadora')) {
      context.handle(
          _ehTransportadoraMeta,
          ehTransportadora.isAcceptableOrUnknown(
              data['eh_transportadora']!, _ehTransportadoraMeta));
    }
    if (data.containsKey('eh_colaborador')) {
      context.handle(
          _ehColaboradorMeta,
          ehColaborador.isAcceptableOrUnknown(
              data['eh_colaborador']!, _ehColaboradorMeta));
    }
    if (data.containsKey('eh_contador')) {
      context.handle(
          _ehContadorMeta,
          ehContador.isAcceptableOrUnknown(
              data['eh_contador']!, _ehContadorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Pessoa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Pessoa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      ehCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_cliente']),
      ehFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_fornecedor']),
      ehTransportadora: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}eh_transportadora']),
      ehColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_colaborador']),
      ehContador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}eh_contador']),
    );
  }

  @override
  $PessoasTable createAlias(String alias) {
    return $PessoasTable(attachedDatabase, alias);
  }
}

class Pessoa extends DataClass implements Insertable<Pessoa> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? site;
  final String? email;
  final String? ehCliente;
  final String? ehFornecedor;
  final String? ehTransportadora;
  final String? ehColaborador;
  final String? ehContador;
  const Pessoa(
      {this.id,
      this.nome,
      this.tipo,
      this.site,
      this.email,
      this.ehCliente,
      this.ehFornecedor,
      this.ehTransportadora,
      this.ehColaborador,
      this.ehContador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || ehCliente != null) {
      map['eh_cliente'] = Variable<String>(ehCliente);
    }
    if (!nullToAbsent || ehFornecedor != null) {
      map['eh_fornecedor'] = Variable<String>(ehFornecedor);
    }
    if (!nullToAbsent || ehTransportadora != null) {
      map['eh_transportadora'] = Variable<String>(ehTransportadora);
    }
    if (!nullToAbsent || ehColaborador != null) {
      map['eh_colaborador'] = Variable<String>(ehColaborador);
    }
    if (!nullToAbsent || ehContador != null) {
      map['eh_contador'] = Variable<String>(ehContador);
    }
    return map;
  }

  factory Pessoa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Pessoa(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      site: serializer.fromJson<String?>(json['site']),
      email: serializer.fromJson<String?>(json['email']),
      ehCliente: serializer.fromJson<String?>(json['ehCliente']),
      ehFornecedor: serializer.fromJson<String?>(json['ehFornecedor']),
      ehTransportadora: serializer.fromJson<String?>(json['ehTransportadora']),
      ehColaborador: serializer.fromJson<String?>(json['ehColaborador']),
      ehContador: serializer.fromJson<String?>(json['ehContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'site': serializer.toJson<String?>(site),
      'email': serializer.toJson<String?>(email),
      'ehCliente': serializer.toJson<String?>(ehCliente),
      'ehFornecedor': serializer.toJson<String?>(ehFornecedor),
      'ehTransportadora': serializer.toJson<String?>(ehTransportadora),
      'ehColaborador': serializer.toJson<String?>(ehColaborador),
      'ehContador': serializer.toJson<String?>(ehContador),
    };
  }

  Pessoa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> ehCliente = const Value.absent(),
          Value<String?> ehFornecedor = const Value.absent(),
          Value<String?> ehTransportadora = const Value.absent(),
          Value<String?> ehColaborador = const Value.absent(),
          Value<String?> ehContador = const Value.absent()}) =>
      Pessoa(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        site: site.present ? site.value : this.site,
        email: email.present ? email.value : this.email,
        ehCliente: ehCliente.present ? ehCliente.value : this.ehCliente,
        ehFornecedor:
            ehFornecedor.present ? ehFornecedor.value : this.ehFornecedor,
        ehTransportadora: ehTransportadora.present
            ? ehTransportadora.value
            : this.ehTransportadora,
        ehColaborador:
            ehColaborador.present ? ehColaborador.value : this.ehColaborador,
        ehContador: ehContador.present ? ehContador.value : this.ehContador,
      );
  @override
  String toString() {
    return (StringBuffer('Pessoa(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('site: $site, ')
          ..write('email: $email, ')
          ..write('ehCliente: $ehCliente, ')
          ..write('ehFornecedor: $ehFornecedor, ')
          ..write('ehTransportadora: $ehTransportadora, ')
          ..write('ehColaborador: $ehColaborador, ')
          ..write('ehContador: $ehContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, site, email, ehCliente,
      ehFornecedor, ehTransportadora, ehColaborador, ehContador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Pessoa &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.site == this.site &&
          other.email == this.email &&
          other.ehCliente == this.ehCliente &&
          other.ehFornecedor == this.ehFornecedor &&
          other.ehTransportadora == this.ehTransportadora &&
          other.ehColaborador == this.ehColaborador &&
          other.ehContador == this.ehContador);
}

class PessoasCompanion extends UpdateCompanion<Pessoa> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> site;
  final Value<String?> email;
  final Value<String?> ehCliente;
  final Value<String?> ehFornecedor;
  final Value<String?> ehTransportadora;
  final Value<String?> ehColaborador;
  final Value<String?> ehContador;
  const PessoasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.site = const Value.absent(),
    this.email = const Value.absent(),
    this.ehCliente = const Value.absent(),
    this.ehFornecedor = const Value.absent(),
    this.ehTransportadora = const Value.absent(),
    this.ehColaborador = const Value.absent(),
    this.ehContador = const Value.absent(),
  });
  PessoasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.site = const Value.absent(),
    this.email = const Value.absent(),
    this.ehCliente = const Value.absent(),
    this.ehFornecedor = const Value.absent(),
    this.ehTransportadora = const Value.absent(),
    this.ehColaborador = const Value.absent(),
    this.ehContador = const Value.absent(),
  });
  static Insertable<Pessoa> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? site,
    Expression<String>? email,
    Expression<String>? ehCliente,
    Expression<String>? ehFornecedor,
    Expression<String>? ehTransportadora,
    Expression<String>? ehColaborador,
    Expression<String>? ehContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (site != null) 'site': site,
      if (email != null) 'email': email,
      if (ehCliente != null) 'eh_cliente': ehCliente,
      if (ehFornecedor != null) 'eh_fornecedor': ehFornecedor,
      if (ehTransportadora != null) 'eh_transportadora': ehTransportadora,
      if (ehColaborador != null) 'eh_colaborador': ehColaborador,
      if (ehContador != null) 'eh_contador': ehContador,
    });
  }

  PessoasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? site,
      Value<String?>? email,
      Value<String?>? ehCliente,
      Value<String?>? ehFornecedor,
      Value<String?>? ehTransportadora,
      Value<String?>? ehColaborador,
      Value<String?>? ehContador}) {
    return PessoasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      site: site ?? this.site,
      email: email ?? this.email,
      ehCliente: ehCliente ?? this.ehCliente,
      ehFornecedor: ehFornecedor ?? this.ehFornecedor,
      ehTransportadora: ehTransportadora ?? this.ehTransportadora,
      ehColaborador: ehColaborador ?? this.ehColaborador,
      ehContador: ehContador ?? this.ehContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (ehCliente.present) {
      map['eh_cliente'] = Variable<String>(ehCliente.value);
    }
    if (ehFornecedor.present) {
      map['eh_fornecedor'] = Variable<String>(ehFornecedor.value);
    }
    if (ehTransportadora.present) {
      map['eh_transportadora'] = Variable<String>(ehTransportadora.value);
    }
    if (ehColaborador.present) {
      map['eh_colaborador'] = Variable<String>(ehColaborador.value);
    }
    if (ehContador.present) {
      map['eh_contador'] = Variable<String>(ehContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PessoasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('site: $site, ')
          ..write('email: $email, ')
          ..write('ehCliente: $ehCliente, ')
          ..write('ehFornecedor: $ehFornecedor, ')
          ..write('ehTransportadora: $ehTransportadora, ')
          ..write('ehColaborador: $ehColaborador, ')
          ..write('ehContador: $ehContador')
          ..write(')'))
        .toString();
  }
}

class $ColaboradorsTable extends Colaboradors
    with TableInfo<$ColaboradorsTable, Colaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorSituacaoMeta =
      const VerificationMeta('idColaboradorSituacao');
  @override
  late final GeneratedColumn<int> idColaboradorSituacao = GeneratedColumn<int>(
      'id_colaborador_situacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTipoAdmissaoMeta =
      const VerificationMeta('idTipoAdmissao');
  @override
  late final GeneratedColumn<int> idTipoAdmissao = GeneratedColumn<int>(
      'id_tipo_admissao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorTipoMeta =
      const VerificationMeta('idColaboradorTipo');
  @override
  late final GeneratedColumn<int> idColaboradorTipo = GeneratedColumn<int>(
      'id_colaborador_tipo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSindicatoMeta =
      const VerificationMeta('idSindicato');
  @override
  late final GeneratedColumn<int> idSindicato = GeneratedColumn<int>(
      'id_sindicato', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        idCargo,
        idSetor,
        idColaboradorSituacao,
        idTipoAdmissao,
        idColaboradorTipo,
        idSindicato,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'colaborador';
  @override
  VerificationContext validateIntegrity(Insertable<Colaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    if (data.containsKey('id_colaborador_situacao')) {
      context.handle(
          _idColaboradorSituacaoMeta,
          idColaboradorSituacao.isAcceptableOrUnknown(
              data['id_colaborador_situacao']!, _idColaboradorSituacaoMeta));
    }
    if (data.containsKey('id_tipo_admissao')) {
      context.handle(
          _idTipoAdmissaoMeta,
          idTipoAdmissao.isAcceptableOrUnknown(
              data['id_tipo_admissao']!, _idTipoAdmissaoMeta));
    }
    if (data.containsKey('id_colaborador_tipo')) {
      context.handle(
          _idColaboradorTipoMeta,
          idColaboradorTipo.isAcceptableOrUnknown(
              data['id_colaborador_tipo']!, _idColaboradorTipoMeta));
    }
    if (data.containsKey('id_sindicato')) {
      context.handle(
          _idSindicatoMeta,
          idSindicato.isAcceptableOrUnknown(
              data['id_sindicato']!, _idSindicatoMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Colaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Colaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
      idColaboradorSituacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_colaborador_situacao']),
      idTipoAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_tipo_admissao']),
      idColaboradorTipo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_colaborador_tipo']),
      idSindicato: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_sindicato']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ColaboradorsTable createAlias(String alias) {
    return $ColaboradorsTable(attachedDatabase, alias);
  }
}

class Colaborador extends DataClass implements Insertable<Colaborador> {
  final int? id;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  final int? idColaboradorSituacao;
  final int? idTipoAdmissao;
  final int? idColaboradorTipo;
  final int? idSindicato;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  const Colaborador(
      {this.id,
      this.idPessoa,
      this.idCargo,
      this.idSetor,
      this.idColaboradorSituacao,
      this.idTipoAdmissao,
      this.idColaboradorTipo,
      this.idSindicato,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || idColaboradorSituacao != null) {
      map['id_colaborador_situacao'] = Variable<int>(idColaboradorSituacao);
    }
    if (!nullToAbsent || idTipoAdmissao != null) {
      map['id_tipo_admissao'] = Variable<int>(idTipoAdmissao);
    }
    if (!nullToAbsent || idColaboradorTipo != null) {
      map['id_colaborador_tipo'] = Variable<int>(idColaboradorTipo);
    }
    if (!nullToAbsent || idSindicato != null) {
      map['id_sindicato'] = Variable<int>(idSindicato);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Colaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Colaborador(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      idColaboradorSituacao:
          serializer.fromJson<int?>(json['idColaboradorSituacao']),
      idTipoAdmissao: serializer.fromJson<int?>(json['idTipoAdmissao']),
      idColaboradorTipo: serializer.fromJson<int?>(json['idColaboradorTipo']),
      idSindicato: serializer.fromJson<int?>(json['idSindicato']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
      'idColaboradorSituacao': serializer.toJson<int?>(idColaboradorSituacao),
      'idTipoAdmissao': serializer.toJson<int?>(idTipoAdmissao),
      'idColaboradorTipo': serializer.toJson<int?>(idColaboradorTipo),
      'idSindicato': serializer.toJson<int?>(idSindicato),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Colaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent(),
          Value<int?> idColaboradorSituacao = const Value.absent(),
          Value<int?> idTipoAdmissao = const Value.absent(),
          Value<int?> idColaboradorTipo = const Value.absent(),
          Value<int?> idSindicato = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Colaborador(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
        idColaboradorSituacao: idColaboradorSituacao.present
            ? idColaboradorSituacao.value
            : this.idColaboradorSituacao,
        idTipoAdmissao:
            idTipoAdmissao.present ? idTipoAdmissao.value : this.idTipoAdmissao,
        idColaboradorTipo: idColaboradorTipo.present
            ? idColaboradorTipo.value
            : this.idColaboradorTipo,
        idSindicato: idSindicato.present ? idSindicato.value : this.idSindicato,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Colaborador(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('idColaboradorSituacao: $idColaboradorSituacao, ')
          ..write('idTipoAdmissao: $idTipoAdmissao, ')
          ..write('idColaboradorTipo: $idColaboradorTipo, ')
          ..write('idSindicato: $idSindicato, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      idCargo,
      idSetor,
      idColaboradorSituacao,
      idTipoAdmissao,
      idColaboradorTipo,
      idSindicato,
      matricula,
      dataCadastro,
      dataAdmissao,
      dataDemissao,
      ctpsNumero,
      ctpsSerie,
      ctpsDataExpedicao,
      ctpsUf,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Colaborador &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor &&
          other.idColaboradorSituacao == this.idColaboradorSituacao &&
          other.idTipoAdmissao == this.idTipoAdmissao &&
          other.idColaboradorTipo == this.idColaboradorTipo &&
          other.idSindicato == this.idSindicato &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao);
}

class ColaboradorsCompanion extends UpdateCompanion<Colaborador> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  final Value<int?> idColaboradorSituacao;
  final Value<int?> idTipoAdmissao;
  final Value<int?> idColaboradorTipo;
  final Value<int?> idSindicato;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  const ColaboradorsCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.idColaboradorSituacao = const Value.absent(),
    this.idTipoAdmissao = const Value.absent(),
    this.idColaboradorTipo = const Value.absent(),
    this.idSindicato = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.idColaboradorSituacao = const Value.absent(),
    this.idTipoAdmissao = const Value.absent(),
    this.idColaboradorTipo = const Value.absent(),
    this.idSindicato = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Colaborador> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
    Expression<int>? idColaboradorSituacao,
    Expression<int>? idTipoAdmissao,
    Expression<int>? idColaboradorTipo,
    Expression<int>? idSindicato,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
      if (idColaboradorSituacao != null)
        'id_colaborador_situacao': idColaboradorSituacao,
      if (idTipoAdmissao != null) 'id_tipo_admissao': idTipoAdmissao,
      if (idColaboradorTipo != null) 'id_colaborador_tipo': idColaboradorTipo,
      if (idSindicato != null) 'id_sindicato': idSindicato,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor,
      Value<int?>? idColaboradorSituacao,
      Value<int?>? idTipoAdmissao,
      Value<int?>? idColaboradorTipo,
      Value<int?>? idSindicato,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao}) {
    return ColaboradorsCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
      idColaboradorSituacao:
          idColaboradorSituacao ?? this.idColaboradorSituacao,
      idTipoAdmissao: idTipoAdmissao ?? this.idTipoAdmissao,
      idColaboradorTipo: idColaboradorTipo ?? this.idColaboradorTipo,
      idSindicato: idSindicato ?? this.idSindicato,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (idColaboradorSituacao.present) {
      map['id_colaborador_situacao'] =
          Variable<int>(idColaboradorSituacao.value);
    }
    if (idTipoAdmissao.present) {
      map['id_tipo_admissao'] = Variable<int>(idTipoAdmissao.value);
    }
    if (idColaboradorTipo.present) {
      map['id_colaborador_tipo'] = Variable<int>(idColaboradorTipo.value);
    }
    if (idSindicato.present) {
      map['id_sindicato'] = Variable<int>(idSindicato.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('idColaboradorSituacao: $idColaboradorSituacao, ')
          ..write('idTipoAdmissao: $idTipoAdmissao, ')
          ..write('idColaboradorTipo: $idColaboradorTipo, ')
          ..write('idSindicato: $idSindicato, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PapelsTable extends Papels with TableInfo<$PapelsTable, Papel> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PapelsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaMeta =
      const VerificationMeta('descrica');
  @override
  late final GeneratedColumn<String> descrica = GeneratedColumn<String>(
      'descrica', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descrica];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'papel';
  @override
  VerificationContext validateIntegrity(Insertable<Papel> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descrica')) {
      context.handle(_descricaMeta,
          descrica.isAcceptableOrUnknown(data['descrica']!, _descricaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Papel map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Papel(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descrica: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descrica']),
    );
  }

  @override
  $PapelsTable createAlias(String alias) {
    return $PapelsTable(attachedDatabase, alias);
  }
}

class Papel extends DataClass implements Insertable<Papel> {
  final int? id;
  final String? nome;
  final String? descrica;
  const Papel({this.id, this.nome, this.descrica});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descrica != null) {
      map['descrica'] = Variable<String>(descrica);
    }
    return map;
  }

  factory Papel.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Papel(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descrica: serializer.fromJson<String?>(json['descrica']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descrica': serializer.toJson<String?>(descrica),
    };
  }

  Papel copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descrica = const Value.absent()}) =>
      Papel(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descrica: descrica.present ? descrica.value : this.descrica,
      );
  @override
  String toString() {
    return (StringBuffer('Papel(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descrica: $descrica')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descrica);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Papel &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descrica == this.descrica);
}

class PapelsCompanion extends UpdateCompanion<Papel> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descrica;
  const PapelsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descrica = const Value.absent(),
  });
  PapelsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descrica = const Value.absent(),
  });
  static Insertable<Papel> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descrica,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descrica != null) 'descrica': descrica,
    });
  }

  PapelsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descrica}) {
    return PapelsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descrica: descrica ?? this.descrica,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descrica.present) {
      map['descrica'] = Variable<String>(descrica.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PapelsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descrica: $descrica')
          ..write(')'))
        .toString();
  }
}

class $FuncaosTable extends Funcaos with TableInfo<$FuncaosTable, Funcao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FuncaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'funcao';
  @override
  VerificationContext validateIntegrity(Insertable<Funcao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Funcao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Funcao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $FuncaosTable createAlias(String alias) {
    return $FuncaosTable(attachedDatabase, alias);
  }
}

class Funcao extends DataClass implements Insertable<Funcao> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Funcao({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Funcao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Funcao(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Funcao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Funcao(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('Funcao(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Funcao &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class FuncaosCompanion extends UpdateCompanion<Funcao> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const FuncaosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FuncaosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Funcao> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FuncaosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return FuncaosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FuncaosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $EstadoCivilsTable extends EstadoCivils
    with TableInfo<$EstadoCivilsTable, EstadoCivil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstadoCivilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estado_civil';
  @override
  VerificationContext validateIntegrity(Insertable<EstadoCivil> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstadoCivil map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstadoCivil(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $EstadoCivilsTable createAlias(String alias) {
    return $EstadoCivilsTable(attachedDatabase, alias);
  }
}

class EstadoCivil extends DataClass implements Insertable<EstadoCivil> {
  final int? id;
  final String? nome;
  final String? descricao;
  const EstadoCivil({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory EstadoCivil.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstadoCivil(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  EstadoCivil copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      EstadoCivil(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('EstadoCivil(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstadoCivil &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class EstadoCivilsCompanion extends UpdateCompanion<EstadoCivil> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const EstadoCivilsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  EstadoCivilsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<EstadoCivil> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  EstadoCivilsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return EstadoCivilsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstadoCivilsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $CargosTable extends Cargos with TableInfo<$CargosTable, Cargo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CargosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _salarioMeta =
      const VerificationMeta('salario');
  @override
  late final GeneratedColumn<double> salario = GeneratedColumn<double>(
      'salario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cbo1994Meta =
      const VerificationMeta('cbo1994');
  @override
  late final GeneratedColumn<String> cbo1994 = GeneratedColumn<String>(
      'cbo_1994', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cbo2002Meta =
      const VerificationMeta('cbo2002');
  @override
  late final GeneratedColumn<String> cbo2002 = GeneratedColumn<String>(
      'cbo_2002', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nome, descricao, salario, cbo1994, cbo2002];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cargo';
  @override
  VerificationContext validateIntegrity(Insertable<Cargo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('salario')) {
      context.handle(_salarioMeta,
          salario.isAcceptableOrUnknown(data['salario']!, _salarioMeta));
    }
    if (data.containsKey('cbo_1994')) {
      context.handle(_cbo1994Meta,
          cbo1994.isAcceptableOrUnknown(data['cbo_1994']!, _cbo1994Meta));
    }
    if (data.containsKey('cbo_2002')) {
      context.handle(_cbo2002Meta,
          cbo2002.isAcceptableOrUnknown(data['cbo_2002']!, _cbo2002Meta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cargo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cargo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      salario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}salario']),
      cbo1994: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cbo_1994']),
      cbo2002: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cbo_2002']),
    );
  }

  @override
  $CargosTable createAlias(String alias) {
    return $CargosTable(attachedDatabase, alias);
  }
}

class Cargo extends DataClass implements Insertable<Cargo> {
  final int? id;
  final String? nome;
  final String? descricao;
  final double? salario;
  final String? cbo1994;
  final String? cbo2002;
  const Cargo(
      {this.id,
      this.nome,
      this.descricao,
      this.salario,
      this.cbo1994,
      this.cbo2002});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || salario != null) {
      map['salario'] = Variable<double>(salario);
    }
    if (!nullToAbsent || cbo1994 != null) {
      map['cbo_1994'] = Variable<String>(cbo1994);
    }
    if (!nullToAbsent || cbo2002 != null) {
      map['cbo_2002'] = Variable<String>(cbo2002);
    }
    return map;
  }

  factory Cargo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cargo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      salario: serializer.fromJson<double?>(json['salario']),
      cbo1994: serializer.fromJson<String?>(json['cbo1994']),
      cbo2002: serializer.fromJson<String?>(json['cbo2002']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'salario': serializer.toJson<double?>(salario),
      'cbo1994': serializer.toJson<String?>(cbo1994),
      'cbo2002': serializer.toJson<String?>(cbo2002),
    };
  }

  Cargo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<double?> salario = const Value.absent(),
          Value<String?> cbo1994 = const Value.absent(),
          Value<String?> cbo2002 = const Value.absent()}) =>
      Cargo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        salario: salario.present ? salario.value : this.salario,
        cbo1994: cbo1994.present ? cbo1994.value : this.cbo1994,
        cbo2002: cbo2002.present ? cbo2002.value : this.cbo2002,
      );
  @override
  String toString() {
    return (StringBuffer('Cargo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('salario: $salario, ')
          ..write('cbo1994: $cbo1994, ')
          ..write('cbo2002: $cbo2002')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, nome, descricao, salario, cbo1994, cbo2002);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cargo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.salario == this.salario &&
          other.cbo1994 == this.cbo1994 &&
          other.cbo2002 == this.cbo2002);
}

class CargosCompanion extends UpdateCompanion<Cargo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<double?> salario;
  final Value<String?> cbo1994;
  final Value<String?> cbo2002;
  const CargosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.salario = const Value.absent(),
    this.cbo1994 = const Value.absent(),
    this.cbo2002 = const Value.absent(),
  });
  CargosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.salario = const Value.absent(),
    this.cbo1994 = const Value.absent(),
    this.cbo2002 = const Value.absent(),
  });
  static Insertable<Cargo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<double>? salario,
    Expression<String>? cbo1994,
    Expression<String>? cbo2002,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (salario != null) 'salario': salario,
      if (cbo1994 != null) 'cbo_1994': cbo1994,
      if (cbo2002 != null) 'cbo_2002': cbo2002,
    });
  }

  CargosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<double?>? salario,
      Value<String?>? cbo1994,
      Value<String?>? cbo2002}) {
    return CargosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      salario: salario ?? this.salario,
      cbo1994: cbo1994 ?? this.cbo1994,
      cbo2002: cbo2002 ?? this.cbo2002,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (salario.present) {
      map['salario'] = Variable<double>(salario.value);
    }
    if (cbo1994.present) {
      map['cbo_1994'] = Variable<String>(cbo1994.value);
    }
    if (cbo2002.present) {
      map['cbo_2002'] = Variable<String>(cbo2002.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CargosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('salario: $salario, ')
          ..write('cbo1994: $cbo1994, ')
          ..write('cbo2002: $cbo2002')
          ..write(')'))
        .toString();
  }
}

class $SetorsTable extends Setors with TableInfo<$SetorsTable, Setor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SetorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'setor';
  @override
  VerificationContext validateIntegrity(Insertable<Setor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Setor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Setor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $SetorsTable createAlias(String alias) {
    return $SetorsTable(attachedDatabase, alias);
  }
}

class Setor extends DataClass implements Insertable<Setor> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Setor({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Setor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Setor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Setor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Setor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('Setor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Setor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class SetorsCompanion extends UpdateCompanion<Setor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const SetorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  SetorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Setor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  SetorsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return SetorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SetorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ColaboradorSituacaosTable extends ColaboradorSituacaos
    with TableInfo<$ColaboradorSituacaosTable, ColaboradorSituacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ColaboradorSituacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'colaborador_situacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<ColaboradorSituacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ColaboradorSituacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ColaboradorSituacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ColaboradorSituacaosTable createAlias(String alias) {
    return $ColaboradorSituacaosTable(attachedDatabase, alias);
  }
}

class ColaboradorSituacao extends DataClass
    implements Insertable<ColaboradorSituacao> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const ColaboradorSituacao({this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ColaboradorSituacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ColaboradorSituacao(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ColaboradorSituacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ColaboradorSituacao(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ColaboradorSituacao(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ColaboradorSituacao &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ColaboradorSituacaosCompanion
    extends UpdateCompanion<ColaboradorSituacao> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ColaboradorSituacaosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ColaboradorSituacaosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ColaboradorSituacao> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ColaboradorSituacaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return ColaboradorSituacaosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ColaboradorSituacaosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $TipoAdmissaosTable extends TipoAdmissaos
    with TableInfo<$TipoAdmissaosTable, TipoAdmissao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TipoAdmissaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tipo_admissao';
  @override
  VerificationContext validateIntegrity(Insertable<TipoAdmissao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TipoAdmissao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TipoAdmissao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $TipoAdmissaosTable createAlias(String alias) {
    return $TipoAdmissaosTable(attachedDatabase, alias);
  }
}

class TipoAdmissao extends DataClass implements Insertable<TipoAdmissao> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const TipoAdmissao({this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory TipoAdmissao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TipoAdmissao(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  TipoAdmissao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      TipoAdmissao(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('TipoAdmissao(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TipoAdmissao &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class TipoAdmissaosCompanion extends UpdateCompanion<TipoAdmissao> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const TipoAdmissaosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  TipoAdmissaosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<TipoAdmissao> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  TipoAdmissaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return TipoAdmissaosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TipoAdmissaosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ColaboradorTiposTable extends ColaboradorTipos
    with TableInfo<$ColaboradorTiposTable, ColaboradorTipo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ColaboradorTiposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'colaborador_tipo';
  @override
  VerificationContext validateIntegrity(Insertable<ColaboradorTipo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ColaboradorTipo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ColaboradorTipo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ColaboradorTiposTable createAlias(String alias) {
    return $ColaboradorTiposTable(attachedDatabase, alias);
  }
}

class ColaboradorTipo extends DataClass implements Insertable<ColaboradorTipo> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ColaboradorTipo({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ColaboradorTipo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ColaboradorTipo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ColaboradorTipo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ColaboradorTipo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ColaboradorTipo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ColaboradorTipo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ColaboradorTiposCompanion extends UpdateCompanion<ColaboradorTipo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ColaboradorTiposCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ColaboradorTiposCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ColaboradorTipo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ColaboradorTiposCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ColaboradorTiposCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ColaboradorTiposCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoGruposTable extends ProdutoGrupos
    with TableInfo<$ProdutoGruposTable, ProdutoGrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoGruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_grupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoGrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoGrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoGrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoGruposTable createAlias(String alias) {
    return $ProdutoGruposTable(attachedDatabase, alias);
  }
}

class ProdutoGrupo extends DataClass implements Insertable<ProdutoGrupo> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoGrupo({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoGrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoGrupo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoGrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoGrupo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoGrupo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoGrupo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoGruposCompanion extends UpdateCompanion<ProdutoGrupo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoGruposCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoGruposCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoGrupo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoGruposCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoGruposCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoGruposCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoSubgruposTable extends ProdutoSubgrupos
    with TableInfo<$ProdutoSubgruposTable, ProdutoSubgrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoSubgruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoGrupoMeta =
      const VerificationMeta('idProdutoGrupo');
  @override
  late final GeneratedColumn<int> idProdutoGrupo = GeneratedColumn<int>(
      'id_produto_grupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idProdutoGrupo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_subgrupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoSubgrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_grupo')) {
      context.handle(
          _idProdutoGrupoMeta,
          idProdutoGrupo.isAcceptableOrUnknown(
              data['id_produto_grupo']!, _idProdutoGrupoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoSubgrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoSubgrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoGrupo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_grupo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoSubgruposTable createAlias(String alias) {
    return $ProdutoSubgruposTable(attachedDatabase, alias);
  }
}

class ProdutoSubgrupo extends DataClass implements Insertable<ProdutoSubgrupo> {
  final int? id;
  final int? idProdutoGrupo;
  final String? nome;
  final String? descricao;
  const ProdutoSubgrupo(
      {this.id, this.idProdutoGrupo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoGrupo != null) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoSubgrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoSubgrupo(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoGrupo: serializer.fromJson<int?>(json['idProdutoGrupo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoGrupo': serializer.toJson<int?>(idProdutoGrupo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoSubgrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoGrupo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoSubgrupo(
        id: id.present ? id.value : this.id,
        idProdutoGrupo:
            idProdutoGrupo.present ? idProdutoGrupo.value : this.idProdutoGrupo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoSubgrupo(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProdutoGrupo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoSubgrupo &&
          other.id == this.id &&
          other.idProdutoGrupo == this.idProdutoGrupo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoSubgruposCompanion extends UpdateCompanion<ProdutoSubgrupo> {
  final Value<int?> id;
  final Value<int?> idProdutoGrupo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoSubgruposCompanion({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoSubgruposCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoSubgrupo> custom({
    Expression<int>? id,
    Expression<int>? idProdutoGrupo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoGrupo != null) 'id_produto_grupo': idProdutoGrupo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoSubgruposCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoGrupo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return ProdutoSubgruposCompanion(
      id: id ?? this.id,
      idProdutoGrupo: idProdutoGrupo ?? this.idProdutoGrupo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoGrupo.present) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoSubgruposCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoMarcasTable extends ProdutoMarcas
    with TableInfo<$ProdutoMarcasTable, ProdutoMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_marca';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoMarcasTable createAlias(String alias) {
    return $ProdutoMarcasTable(attachedDatabase, alias);
  }
}

class ProdutoMarca extends DataClass implements Insertable<ProdutoMarca> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoMarca({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoMarca(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoMarca(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoMarca(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoMarca &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoMarcasCompanion extends UpdateCompanion<ProdutoMarca> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoMarcasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoMarca> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoMarcasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarcasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoUnidadesTable extends ProdutoUnidades
    with TableInfo<$ProdutoUnidadesTable, ProdutoUnidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoUnidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeFracionarMeta =
      const VerificationMeta('podeFracionar');
  @override
  late final GeneratedColumn<String> podeFracionar = GeneratedColumn<String>(
      'pode_fracionar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, sigla, podeFracionar, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_unidade';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoUnidade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('pode_fracionar')) {
      context.handle(
          _podeFracionarMeta,
          podeFracionar.isAcceptableOrUnknown(
              data['pode_fracionar']!, _podeFracionarMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoUnidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoUnidade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      podeFracionar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_fracionar']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoUnidadesTable createAlias(String alias) {
    return $ProdutoUnidadesTable(attachedDatabase, alias);
  }
}

class ProdutoUnidade extends DataClass implements Insertable<ProdutoUnidade> {
  final int? id;
  final String? sigla;
  final String? podeFracionar;
  final String? descricao;
  const ProdutoUnidade(
      {this.id, this.sigla, this.podeFracionar, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || podeFracionar != null) {
      map['pode_fracionar'] = Variable<String>(podeFracionar);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoUnidade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoUnidade(
      id: serializer.fromJson<int?>(json['id']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      podeFracionar: serializer.fromJson<String?>(json['podeFracionar']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'sigla': serializer.toJson<String?>(sigla),
      'podeFracionar': serializer.toJson<String?>(podeFracionar),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoUnidade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<String?> podeFracionar = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoUnidade(
        id: id.present ? id.value : this.id,
        sigla: sigla.present ? sigla.value : this.sigla,
        podeFracionar:
            podeFracionar.present ? podeFracionar.value : this.podeFracionar,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoUnidade(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('podeFracionar: $podeFracionar, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sigla, podeFracionar, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoUnidade &&
          other.id == this.id &&
          other.sigla == this.sigla &&
          other.podeFracionar == this.podeFracionar &&
          other.descricao == this.descricao);
}

class ProdutoUnidadesCompanion extends UpdateCompanion<ProdutoUnidade> {
  final Value<int?> id;
  final Value<String?> sigla;
  final Value<String?> podeFracionar;
  final Value<String?> descricao;
  const ProdutoUnidadesCompanion({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.podeFracionar = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoUnidadesCompanion.insert({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.podeFracionar = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoUnidade> custom({
    Expression<int>? id,
    Expression<String>? sigla,
    Expression<String>? podeFracionar,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sigla != null) 'sigla': sigla,
      if (podeFracionar != null) 'pode_fracionar': podeFracionar,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoUnidadesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? sigla,
      Value<String?>? podeFracionar,
      Value<String?>? descricao}) {
    return ProdutoUnidadesCompanion(
      id: id ?? this.id,
      sigla: sigla ?? this.sigla,
      podeFracionar: podeFracionar ?? this.podeFracionar,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (podeFracionar.present) {
      map['pode_fracionar'] = Variable<String>(podeFracionar.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidadesCompanion(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('podeFracionar: $podeFracionar, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoSubgrupoMeta =
      const VerificationMeta('idProdutoSubgrupo');
  @override
  late final GeneratedColumn<int> idProdutoSubgrupo = GeneratedColumn<int>(
      'id_produto_subgrupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMarcaMeta =
      const VerificationMeta('idProdutoMarca');
  @override
  late final GeneratedColumn<int> idProdutoMarca = GeneratedColumn<int>(
      'id_produto_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoUnidadeMeta =
      const VerificationMeta('idProdutoUnidade');
  @override
  late final GeneratedColumn<int> idProdutoUnidade = GeneratedColumn<int>(
      'id_produto_unidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
      'id_tribut_icms_custom_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>('id_tribut_grupo_tributario', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
      'gtin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _codigoNcmMeta =
      const VerificationMeta('codigoNcm');
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
      'codigo_ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMinimoMeta =
      const VerificationMeta('estoqueMinimo');
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
      'estoque_minimo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMaximoMeta =
      const VerificationMeta('estoqueMaximo');
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
      'estoque_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeEstoqueMeta =
      const VerificationMeta('quantidadeEstoque');
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>('quantidade_estoque', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProdutoSubgrupo,
        idProdutoMarca,
        idProdutoUnidade,
        idTributIcmsCustomCab,
        idTributGrupoTributario,
        nome,
        descricao,
        gtin,
        codigoInterno,
        valorCompra,
        valorVenda,
        codigoNcm,
        dataCadastro,
        estoqueMinimo,
        estoqueMaximo,
        quantidadeEstoque
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(Insertable<Produto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_subgrupo')) {
      context.handle(
          _idProdutoSubgrupoMeta,
          idProdutoSubgrupo.isAcceptableOrUnknown(
              data['id_produto_subgrupo']!, _idProdutoSubgrupoMeta));
    }
    if (data.containsKey('id_produto_marca')) {
      context.handle(
          _idProdutoMarcaMeta,
          idProdutoMarca.isAcceptableOrUnknown(
              data['id_produto_marca']!, _idProdutoMarcaMeta));
    }
    if (data.containsKey('id_produto_unidade')) {
      context.handle(
          _idProdutoUnidadeMeta,
          idProdutoUnidade.isAcceptableOrUnknown(
              data['id_produto_unidade']!, _idProdutoUnidadeMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
          _idTributIcmsCustomCabMeta,
          idTributIcmsCustomCab.isAcceptableOrUnknown(
              data['id_tribut_icms_custom_cab']!, _idTributIcmsCustomCabMeta));
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
          _idTributGrupoTributarioMeta,
          idTributGrupoTributario.isAcceptableOrUnknown(
              data['id_tribut_grupo_tributario']!,
              _idTributGrupoTributarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('gtin')) {
      context.handle(
          _gtinMeta, gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(_codigoNcmMeta,
          codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
          _estoqueMinimoMeta,
          estoqueMinimo.isAcceptableOrUnknown(
              data['estoque_minimo']!, _estoqueMinimoMeta));
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
          _estoqueMaximoMeta,
          estoqueMaximo.isAcceptableOrUnknown(
              data['estoque_maximo']!, _estoqueMaximoMeta));
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
          _quantidadeEstoqueMeta,
          quantidadeEstoque.isAcceptableOrUnknown(
              data['quantidade_estoque']!, _quantidadeEstoqueMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoSubgrupo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_produto_subgrupo']),
      idProdutoMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_marca']),
      idProdutoUnidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_unidade']),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_icms_custom_cab']),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_grupo_tributario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      gtin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gtin']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      codigoNcm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_ncm']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      estoqueMinimo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_minimo']),
      estoqueMaximo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_maximo']),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_estoque']),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idProdutoSubgrupo;
  final int? idProdutoMarca;
  final int? idProdutoUnidade;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final DateTime? dataCadastro;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  const Produto(
      {this.id,
      this.idProdutoSubgrupo,
      this.idProdutoMarca,
      this.idProdutoUnidade,
      this.idTributIcmsCustomCab,
      this.idTributGrupoTributario,
      this.nome,
      this.descricao,
      this.gtin,
      this.codigoInterno,
      this.valorCompra,
      this.valorVenda,
      this.codigoNcm,
      this.dataCadastro,
      this.estoqueMinimo,
      this.estoqueMaximo,
      this.quantidadeEstoque});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoSubgrupo != null) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo);
    }
    if (!nullToAbsent || idProdutoMarca != null) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca);
    }
    if (!nullToAbsent || idProdutoUnidade != null) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    return map;
  }

  factory Produto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoSubgrupo: serializer.fromJson<int?>(json['idProdutoSubgrupo']),
      idProdutoMarca: serializer.fromJson<int?>(json['idProdutoMarca']),
      idProdutoUnidade: serializer.fromJson<int?>(json['idProdutoUnidade']),
      idTributIcmsCustomCab:
          serializer.fromJson<int?>(json['idTributIcmsCustomCab']),
      idTributGrupoTributario:
          serializer.fromJson<int?>(json['idTributGrupoTributario']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque:
          serializer.fromJson<double?>(json['quantidadeEstoque']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoSubgrupo': serializer.toJson<int?>(idProdutoSubgrupo),
      'idProdutoMarca': serializer.toJson<int?>(idProdutoMarca),
      'idProdutoUnidade': serializer.toJson<int?>(idProdutoUnidade),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario':
          serializer.toJson<int?>(idTributGrupoTributario),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
    };
  }

  Produto copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoSubgrupo = const Value.absent(),
          Value<int?> idProdutoMarca = const Value.absent(),
          Value<int?> idProdutoUnidade = const Value.absent(),
          Value<int?> idTributIcmsCustomCab = const Value.absent(),
          Value<int?> idTributGrupoTributario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> gtin = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> codigoNcm = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<double?> estoqueMinimo = const Value.absent(),
          Value<double?> estoqueMaximo = const Value.absent(),
          Value<double?> quantidadeEstoque = const Value.absent()}) =>
      Produto(
        id: id.present ? id.value : this.id,
        idProdutoSubgrupo: idProdutoSubgrupo.present
            ? idProdutoSubgrupo.value
            : this.idProdutoSubgrupo,
        idProdutoMarca:
            idProdutoMarca.present ? idProdutoMarca.value : this.idProdutoMarca,
        idProdutoUnidade: idProdutoUnidade.present
            ? idProdutoUnidade.value
            : this.idProdutoUnidade,
        idTributIcmsCustomCab: idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
        idTributGrupoTributario: idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        gtin: gtin.present ? gtin.value : this.gtin,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        estoqueMinimo:
            estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
        estoqueMaximo:
            estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
        quantidadeEstoque: quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
      );
  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idProdutoSubgrupo,
      idProdutoMarca,
      idProdutoUnidade,
      idTributIcmsCustomCab,
      idTributGrupoTributario,
      nome,
      descricao,
      gtin,
      codigoInterno,
      valorCompra,
      valorVenda,
      codigoNcm,
      dataCadastro,
      estoqueMinimo,
      estoqueMaximo,
      quantidadeEstoque);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idProdutoSubgrupo == this.idProdutoSubgrupo &&
          other.idProdutoMarca == this.idProdutoMarca &&
          other.idProdutoUnidade == this.idProdutoUnidade &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.dataCadastro == this.dataCadastro &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idProdutoSubgrupo;
  final Value<int?> idProdutoMarca;
  final Value<int?> idProdutoUnidade;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<DateTime?> dataCadastro;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idProdutoSubgrupo,
    Expression<int>? idProdutoMarca,
    Expression<int>? idProdutoUnidade,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<DateTime>? dataCadastro,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoSubgrupo != null) 'id_produto_subgrupo': idProdutoSubgrupo,
      if (idProdutoMarca != null) 'id_produto_marca': idProdutoMarca,
      if (idProdutoUnidade != null) 'id_produto_unidade': idProdutoUnidade,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
    });
  }

  ProdutosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoSubgrupo,
      Value<int?>? idProdutoMarca,
      Value<int?>? idProdutoUnidade,
      Value<int?>? idTributIcmsCustomCab,
      Value<int?>? idTributGrupoTributario,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? gtin,
      Value<String?>? codigoInterno,
      Value<double?>? valorCompra,
      Value<double?>? valorVenda,
      Value<String?>? codigoNcm,
      Value<DateTime?>? dataCadastro,
      Value<double?>? estoqueMinimo,
      Value<double?>? estoqueMaximo,
      Value<double?>? quantidadeEstoque}) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idProdutoSubgrupo: idProdutoSubgrupo ?? this.idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca ?? this.idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade ?? this.idProdutoUnidade,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoSubgrupo.present) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo.value);
    }
    if (idProdutoMarca.present) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca.value);
    }
    if (idProdutoUnidade.present) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] =
          Variable<int>(idTributIcmsCustomCab.value);
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque')
          ..write(')'))
        .toString();
  }
}

class $BancosTable extends Bancos with TableInfo<$BancosTable, Banco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
      'url', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, url];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco';
  @override
  VerificationContext validateIntegrity(Insertable<Banco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('url')) {
      context.handle(
          _urlMeta, url.isAcceptableOrUnknown(data['url']!, _urlMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Banco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Banco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      url: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url']),
    );
  }

  @override
  $BancosTable createAlias(String alias) {
    return $BancosTable(attachedDatabase, alias);
  }
}

class Banco extends DataClass implements Insertable<Banco> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? url;
  const Banco({this.id, this.codigo, this.nome, this.url});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || url != null) {
      map['url'] = Variable<String>(url);
    }
    return map;
  }

  factory Banco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Banco(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      url: serializer.fromJson<String?>(json['url']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'url': serializer.toJson<String?>(url),
    };
  }

  Banco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> url = const Value.absent()}) =>
      Banco(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        url: url.present ? url.value : this.url,
      );
  @override
  String toString() {
    return (StringBuffer('Banco(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, url);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Banco &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.url == this.url);
}

class BancosCompanion extends UpdateCompanion<Banco> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> url;
  const BancosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  BancosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.url = const Value.absent(),
  });
  static Insertable<Banco> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? url,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (url != null) 'url': url,
    });
  }

  BancosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? url}) {
    return BancosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      url: url ?? this.url,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('url: $url')
          ..write(')'))
        .toString();
  }
}

class $BancoAgenciasTable extends BancoAgencias
    with TableInfo<$BancoAgenciasTable, BancoAgencia> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoAgenciasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoMeta =
      const VerificationMeta('idBanco');
  @override
  late final GeneratedColumn<int> idBanco = GeneratedColumn<int>(
      'id_banco', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
      'digito', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gerenteMeta =
      const VerificationMeta('gerente');
  @override
  late final GeneratedColumn<String> gerente = GeneratedColumn<String>(
      'gerente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idBanco,
        nome,
        numero,
        digito,
        telefone,
        contato,
        gerente,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco_agencia';
  @override
  VerificationContext validateIntegrity(Insertable<BancoAgencia> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco')) {
      context.handle(_idBancoMeta,
          idBanco.isAcceptableOrUnknown(data['id_banco']!, _idBancoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('digito')) {
      context.handle(_digitoMeta,
          digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('gerente')) {
      context.handle(_gerenteMeta,
          gerente.isAcceptableOrUnknown(data['gerente']!, _gerenteMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoAgencia map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoAgencia(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idBanco: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_banco']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      digito: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}digito']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      gerente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gerente']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $BancoAgenciasTable createAlias(String alias) {
    return $BancoAgenciasTable(attachedDatabase, alias);
  }
}

class BancoAgencia extends DataClass implements Insertable<BancoAgencia> {
  final int? id;
  final int? idBanco;
  final String? nome;
  final String? numero;
  final String? digito;
  final String? telefone;
  final String? contato;
  final String? gerente;
  final String? observacao;
  const BancoAgencia(
      {this.id,
      this.idBanco,
      this.nome,
      this.numero,
      this.digito,
      this.telefone,
      this.contato,
      this.gerente,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBanco != null) {
      map['id_banco'] = Variable<int>(idBanco);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || gerente != null) {
      map['gerente'] = Variable<String>(gerente);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory BancoAgencia.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoAgencia(
      id: serializer.fromJson<int?>(json['id']),
      idBanco: serializer.fromJson<int?>(json['idBanco']),
      nome: serializer.fromJson<String?>(json['nome']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      contato: serializer.fromJson<String?>(json['contato']),
      gerente: serializer.fromJson<String?>(json['gerente']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBanco': serializer.toJson<int?>(idBanco),
      'nome': serializer.toJson<String?>(nome),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'telefone': serializer.toJson<String?>(telefone),
      'contato': serializer.toJson<String?>(contato),
      'gerente': serializer.toJson<String?>(gerente),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  BancoAgencia copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idBanco = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> digito = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<String?> gerente = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      BancoAgencia(
        id: id.present ? id.value : this.id,
        idBanco: idBanco.present ? idBanco.value : this.idBanco,
        nome: nome.present ? nome.value : this.nome,
        numero: numero.present ? numero.value : this.numero,
        digito: digito.present ? digito.value : this.digito,
        telefone: telefone.present ? telefone.value : this.telefone,
        contato: contato.present ? contato.value : this.contato,
        gerente: gerente.present ? gerente.value : this.gerente,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('BancoAgencia(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('nome: $nome, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idBanco, nome, numero, digito, telefone,
      contato, gerente, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoAgencia &&
          other.id == this.id &&
          other.idBanco == this.idBanco &&
          other.nome == this.nome &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.telefone == this.telefone &&
          other.contato == this.contato &&
          other.gerente == this.gerente &&
          other.observacao == this.observacao);
}

class BancoAgenciasCompanion extends UpdateCompanion<BancoAgencia> {
  final Value<int?> id;
  final Value<int?> idBanco;
  final Value<String?> nome;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> telefone;
  final Value<String?> contato;
  final Value<String?> gerente;
  final Value<String?> observacao;
  const BancoAgenciasCompanion({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.nome = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  BancoAgenciasCompanion.insert({
    this.id = const Value.absent(),
    this.idBanco = const Value.absent(),
    this.nome = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.telefone = const Value.absent(),
    this.contato = const Value.absent(),
    this.gerente = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<BancoAgencia> custom({
    Expression<int>? id,
    Expression<int>? idBanco,
    Expression<String>? nome,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? telefone,
    Expression<String>? contato,
    Expression<String>? gerente,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBanco != null) 'id_banco': idBanco,
      if (nome != null) 'nome': nome,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (telefone != null) 'telefone': telefone,
      if (contato != null) 'contato': contato,
      if (gerente != null) 'gerente': gerente,
      if (observacao != null) 'observacao': observacao,
    });
  }

  BancoAgenciasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idBanco,
      Value<String?>? nome,
      Value<String?>? numero,
      Value<String?>? digito,
      Value<String?>? telefone,
      Value<String?>? contato,
      Value<String?>? gerente,
      Value<String?>? observacao}) {
    return BancoAgenciasCompanion(
      id: id ?? this.id,
      idBanco: idBanco ?? this.idBanco,
      nome: nome ?? this.nome,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      telefone: telefone ?? this.telefone,
      contato: contato ?? this.contato,
      gerente: gerente ?? this.gerente,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBanco.present) {
      map['id_banco'] = Variable<int>(idBanco.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (gerente.present) {
      map['gerente'] = Variable<String>(gerente.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoAgenciasCompanion(')
          ..write('id: $id, ')
          ..write('idBanco: $idBanco, ')
          ..write('nome: $nome, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('telefone: $telefone, ')
          ..write('contato: $contato, ')
          ..write('gerente: $gerente, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $BancoContaCaixasTable extends BancoContaCaixas
    with TableInfo<$BancoContaCaixasTable, BancoContaCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoContaCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoAgenciaMeta =
      const VerificationMeta('idBancoAgencia');
  @override
  late final GeneratedColumn<int> idBancoAgencia = GeneratedColumn<int>(
      'id_banco_agencia', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
      'digito', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idBancoAgencia, numero, digito, nome, tipo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco_conta_caixa';
  @override
  VerificationContext validateIntegrity(Insertable<BancoContaCaixa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_agencia')) {
      context.handle(
          _idBancoAgenciaMeta,
          idBancoAgencia.isAcceptableOrUnknown(
              data['id_banco_agencia']!, _idBancoAgenciaMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('digito')) {
      context.handle(_digitoMeta,
          digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoContaCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoContaCaixa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idBancoAgencia: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_banco_agencia']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      digito: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}digito']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $BancoContaCaixasTable createAlias(String alias) {
    return $BancoContaCaixasTable(attachedDatabase, alias);
  }
}

class BancoContaCaixa extends DataClass implements Insertable<BancoContaCaixa> {
  final int? id;
  final int? idBancoAgencia;
  final String? numero;
  final String? digito;
  final String? nome;
  final String? tipo;
  final String? descricao;
  const BancoContaCaixa(
      {this.id,
      this.idBancoAgencia,
      this.numero,
      this.digito,
      this.nome,
      this.tipo,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoAgencia != null) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory BancoContaCaixa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoContaCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idBancoAgencia: serializer.fromJson<int?>(json['idBancoAgencia']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoAgencia': serializer.toJson<int?>(idBancoAgencia),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  BancoContaCaixa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idBancoAgencia = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> digito = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      BancoContaCaixa(
        id: id.present ? id.value : this.id,
        idBancoAgencia:
            idBancoAgencia.present ? idBancoAgencia.value : this.idBancoAgencia,
        numero: numero.present ? numero.value : this.numero,
        digito: digito.present ? digito.value : this.digito,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('BancoContaCaixa(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idBancoAgencia, numero, digito, nome, tipo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoContaCaixa &&
          other.id == this.id &&
          other.idBancoAgencia == this.idBancoAgencia &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao);
}

class BancoContaCaixasCompanion extends UpdateCompanion<BancoContaCaixa> {
  final Value<int?> id;
  final Value<int?> idBancoAgencia;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> descricao;
  const BancoContaCaixasCompanion({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  BancoContaCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoAgencia = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<BancoContaCaixa> custom({
    Expression<int>? id,
    Expression<int>? idBancoAgencia,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoAgencia != null) 'id_banco_agencia': idBancoAgencia,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  BancoContaCaixasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idBancoAgencia,
      Value<String?>? numero,
      Value<String?>? digito,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? descricao}) {
    return BancoContaCaixasCompanion(
      id: id ?? this.id,
      idBancoAgencia: idBancoAgencia ?? this.idBancoAgencia,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoAgencia.present) {
      map['id_banco_agencia'] = Variable<int>(idBancoAgencia.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoContaCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idBancoAgencia: $idBancoAgencia, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $CepsTable extends Ceps with TableInfo<$CepsTable, Cep> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CepsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioMeta =
      const VerificationMeta('municipio');
  @override
  late final GeneratedColumn<String> municipio = GeneratedColumn<String>(
      'municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeMunicipioMeta =
      const VerificationMeta('codigoIbgeMunicipio');
  @override
  late final GeneratedColumn<int> codigoIbgeMunicipio = GeneratedColumn<int>(
      'codigo_ibge_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        numero,
        logradouro,
        complemento,
        bairro,
        municipio,
        uf,
        codigoIbgeMunicipio
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cep';
  @override
  VerificationContext validateIntegrity(Insertable<Cep> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('municipio')) {
      context.handle(_municipioMeta,
          municipio.isAcceptableOrUnknown(data['municipio']!, _municipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('codigo_ibge_municipio')) {
      context.handle(
          _codigoIbgeMunicipioMeta,
          codigoIbgeMunicipio.isAcceptableOrUnknown(
              data['codigo_ibge_municipio']!, _codigoIbgeMunicipioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cep map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cep(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      municipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      codigoIbgeMunicipio: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}codigo_ibge_municipio']),
    );
  }

  @override
  $CepsTable createAlias(String alias) {
    return $CepsTable(attachedDatabase, alias);
  }
}

class Cep extends DataClass implements Insertable<Cep> {
  final int? id;
  final String? numero;
  final String? logradouro;
  final String? complemento;
  final String? bairro;
  final String? municipio;
  final String? uf;
  final int? codigoIbgeMunicipio;
  const Cep(
      {this.id,
      this.numero,
      this.logradouro,
      this.complemento,
      this.bairro,
      this.municipio,
      this.uf,
      this.codigoIbgeMunicipio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || municipio != null) {
      map['municipio'] = Variable<String>(municipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || codigoIbgeMunicipio != null) {
      map['codigo_ibge_municipio'] = Variable<int>(codigoIbgeMunicipio);
    }
    return map;
  }

  factory Cep.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cep(
      id: serializer.fromJson<int?>(json['id']),
      numero: serializer.fromJson<String?>(json['numero']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      municipio: serializer.fromJson<String?>(json['municipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      codigoIbgeMunicipio:
          serializer.fromJson<int?>(json['codigoIbgeMunicipio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'numero': serializer.toJson<String?>(numero),
      'logradouro': serializer.toJson<String?>(logradouro),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'municipio': serializer.toJson<String?>(municipio),
      'uf': serializer.toJson<String?>(uf),
      'codigoIbgeMunicipio': serializer.toJson<int?>(codigoIbgeMunicipio),
    };
  }

  Cep copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> municipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> codigoIbgeMunicipio = const Value.absent()}) =>
      Cep(
        id: id.present ? id.value : this.id,
        numero: numero.present ? numero.value : this.numero,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        municipio: municipio.present ? municipio.value : this.municipio,
        uf: uf.present ? uf.value : this.uf,
        codigoIbgeMunicipio: codigoIbgeMunicipio.present
            ? codigoIbgeMunicipio.value
            : this.codigoIbgeMunicipio,
      );
  @override
  String toString() {
    return (StringBuffer('Cep(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('logradouro: $logradouro, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('municipio: $municipio, ')
          ..write('uf: $uf, ')
          ..write('codigoIbgeMunicipio: $codigoIbgeMunicipio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, numero, logradouro, complemento, bairro,
      municipio, uf, codigoIbgeMunicipio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cep &&
          other.id == this.id &&
          other.numero == this.numero &&
          other.logradouro == this.logradouro &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.municipio == this.municipio &&
          other.uf == this.uf &&
          other.codigoIbgeMunicipio == this.codigoIbgeMunicipio);
}

class CepsCompanion extends UpdateCompanion<Cep> {
  final Value<int?> id;
  final Value<String?> numero;
  final Value<String?> logradouro;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> municipio;
  final Value<String?> uf;
  final Value<int?> codigoIbgeMunicipio;
  const CepsCompanion({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.municipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigoIbgeMunicipio = const Value.absent(),
  });
  CepsCompanion.insert({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.municipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigoIbgeMunicipio = const Value.absent(),
  });
  static Insertable<Cep> custom({
    Expression<int>? id,
    Expression<String>? numero,
    Expression<String>? logradouro,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? municipio,
    Expression<String>? uf,
    Expression<int>? codigoIbgeMunicipio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (numero != null) 'numero': numero,
      if (logradouro != null) 'logradouro': logradouro,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (municipio != null) 'municipio': municipio,
      if (uf != null) 'uf': uf,
      if (codigoIbgeMunicipio != null)
        'codigo_ibge_municipio': codigoIbgeMunicipio,
    });
  }

  CepsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? numero,
      Value<String?>? logradouro,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? municipio,
      Value<String?>? uf,
      Value<int?>? codigoIbgeMunicipio}) {
    return CepsCompanion(
      id: id ?? this.id,
      numero: numero ?? this.numero,
      logradouro: logradouro ?? this.logradouro,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      municipio: municipio ?? this.municipio,
      uf: uf ?? this.uf,
      codigoIbgeMunicipio: codigoIbgeMunicipio ?? this.codigoIbgeMunicipio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (municipio.present) {
      map['municipio'] = Variable<String>(municipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (codigoIbgeMunicipio.present) {
      map['codigo_ibge_municipio'] = Variable<int>(codigoIbgeMunicipio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CepsCompanion(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('logradouro: $logradouro, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('municipio: $municipio, ')
          ..write('uf: $uf, ')
          ..write('codigoIbgeMunicipio: $codigoIbgeMunicipio')
          ..write(')'))
        .toString();
  }
}

class $UfsTable extends Ufs with TableInfo<$UfsTable, Uf> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $UfsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeMeta =
      const VerificationMeta('codigoIbge');
  @override
  late final GeneratedColumn<int> codigoIbge = GeneratedColumn<int>(
      'codigo_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, sigla, codigoIbge];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'uf';
  @override
  VerificationContext validateIntegrity(Insertable<Uf> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('codigo_ibge')) {
      context.handle(
          _codigoIbgeMeta,
          codigoIbge.isAcceptableOrUnknown(
              data['codigo_ibge']!, _codigoIbgeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Uf map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Uf(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      codigoIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge']),
    );
  }

  @override
  $UfsTable createAlias(String alias) {
    return $UfsTable(attachedDatabase, alias);
  }
}

class Uf extends DataClass implements Insertable<Uf> {
  final int? id;
  final String? nome;
  final String? sigla;
  final int? codigoIbge;
  const Uf({this.id, this.nome, this.sigla, this.codigoIbge});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || codigoIbge != null) {
      map['codigo_ibge'] = Variable<int>(codigoIbge);
    }
    return map;
  }

  factory Uf.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Uf(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      codigoIbge: serializer.fromJson<int?>(json['codigoIbge']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'sigla': serializer.toJson<String?>(sigla),
      'codigoIbge': serializer.toJson<int?>(codigoIbge),
    };
  }

  Uf copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<int?> codigoIbge = const Value.absent()}) =>
      Uf(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        sigla: sigla.present ? sigla.value : this.sigla,
        codigoIbge: codigoIbge.present ? codigoIbge.value : this.codigoIbge,
      );
  @override
  String toString() {
    return (StringBuffer('Uf(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('sigla: $sigla, ')
          ..write('codigoIbge: $codigoIbge')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, sigla, codigoIbge);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Uf &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.sigla == this.sigla &&
          other.codigoIbge == this.codigoIbge);
}

class UfsCompanion extends UpdateCompanion<Uf> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> sigla;
  final Value<int?> codigoIbge;
  const UfsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.sigla = const Value.absent(),
    this.codigoIbge = const Value.absent(),
  });
  UfsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.sigla = const Value.absent(),
    this.codigoIbge = const Value.absent(),
  });
  static Insertable<Uf> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? sigla,
    Expression<int>? codigoIbge,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (sigla != null) 'sigla': sigla,
      if (codigoIbge != null) 'codigo_ibge': codigoIbge,
    });
  }

  UfsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? sigla,
      Value<int?>? codigoIbge}) {
    return UfsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      sigla: sigla ?? this.sigla,
      codigoIbge: codigoIbge ?? this.codigoIbge,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (codigoIbge.present) {
      map['codigo_ibge'] = Variable<int>(codigoIbge.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('UfsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('sigla: $sigla, ')
          ..write('codigoIbge: $codigoIbge')
          ..write(')'))
        .toString();
  }
}

class $MunicipiosTable extends Municipios
    with TableInfo<$MunicipiosTable, Municipio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MunicipiosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUfMeta = const VerificationMeta('idUf');
  @override
  late final GeneratedColumn<int> idUf = GeneratedColumn<int>(
      'id_uf', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoIbgeMeta =
      const VerificationMeta('codigoIbge');
  @override
  late final GeneratedColumn<int> codigoIbge = GeneratedColumn<int>(
      'codigo_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoReceitaFederalMeta =
      const VerificationMeta('codigoReceitaFederal');
  @override
  late final GeneratedColumn<int> codigoReceitaFederal = GeneratedColumn<int>(
      'codigo_receita_federal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoEstadualMeta =
      const VerificationMeta('codigoEstadual');
  @override
  late final GeneratedColumn<int> codigoEstadual = GeneratedColumn<int>(
      'codigo_estadual', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idUf, nome, codigoIbge, codigoReceitaFederal, codigoEstadual];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'municipio';
  @override
  VerificationContext validateIntegrity(Insertable<Municipio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_uf')) {
      context.handle(
          _idUfMeta, idUf.isAcceptableOrUnknown(data['id_uf']!, _idUfMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('codigo_ibge')) {
      context.handle(
          _codigoIbgeMeta,
          codigoIbge.isAcceptableOrUnknown(
              data['codigo_ibge']!, _codigoIbgeMeta));
    }
    if (data.containsKey('codigo_receita_federal')) {
      context.handle(
          _codigoReceitaFederalMeta,
          codigoReceitaFederal.isAcceptableOrUnknown(
              data['codigo_receita_federal']!, _codigoReceitaFederalMeta));
    }
    if (data.containsKey('codigo_estadual')) {
      context.handle(
          _codigoEstadualMeta,
          codigoEstadual.isAcceptableOrUnknown(
              data['codigo_estadual']!, _codigoEstadualMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Municipio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Municipio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idUf: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_uf']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      codigoIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_ibge']),
      codigoReceitaFederal: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}codigo_receita_federal']),
      codigoEstadual: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_estadual']),
    );
  }

  @override
  $MunicipiosTable createAlias(String alias) {
    return $MunicipiosTable(attachedDatabase, alias);
  }
}

class Municipio extends DataClass implements Insertable<Municipio> {
  final int? id;
  final int? idUf;
  final String? nome;
  final int? codigoIbge;
  final int? codigoReceitaFederal;
  final int? codigoEstadual;
  const Municipio(
      {this.id,
      this.idUf,
      this.nome,
      this.codigoIbge,
      this.codigoReceitaFederal,
      this.codigoEstadual});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idUf != null) {
      map['id_uf'] = Variable<int>(idUf);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || codigoIbge != null) {
      map['codigo_ibge'] = Variable<int>(codigoIbge);
    }
    if (!nullToAbsent || codigoReceitaFederal != null) {
      map['codigo_receita_federal'] = Variable<int>(codigoReceitaFederal);
    }
    if (!nullToAbsent || codigoEstadual != null) {
      map['codigo_estadual'] = Variable<int>(codigoEstadual);
    }
    return map;
  }

  factory Municipio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Municipio(
      id: serializer.fromJson<int?>(json['id']),
      idUf: serializer.fromJson<int?>(json['idUf']),
      nome: serializer.fromJson<String?>(json['nome']),
      codigoIbge: serializer.fromJson<int?>(json['codigoIbge']),
      codigoReceitaFederal:
          serializer.fromJson<int?>(json['codigoReceitaFederal']),
      codigoEstadual: serializer.fromJson<int?>(json['codigoEstadual']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idUf': serializer.toJson<int?>(idUf),
      'nome': serializer.toJson<String?>(nome),
      'codigoIbge': serializer.toJson<int?>(codigoIbge),
      'codigoReceitaFederal': serializer.toJson<int?>(codigoReceitaFederal),
      'codigoEstadual': serializer.toJson<int?>(codigoEstadual),
    };
  }

  Municipio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idUf = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<int?> codigoIbge = const Value.absent(),
          Value<int?> codigoReceitaFederal = const Value.absent(),
          Value<int?> codigoEstadual = const Value.absent()}) =>
      Municipio(
        id: id.present ? id.value : this.id,
        idUf: idUf.present ? idUf.value : this.idUf,
        nome: nome.present ? nome.value : this.nome,
        codigoIbge: codigoIbge.present ? codigoIbge.value : this.codigoIbge,
        codigoReceitaFederal: codigoReceitaFederal.present
            ? codigoReceitaFederal.value
            : this.codigoReceitaFederal,
        codigoEstadual:
            codigoEstadual.present ? codigoEstadual.value : this.codigoEstadual,
      );
  @override
  String toString() {
    return (StringBuffer('Municipio(')
          ..write('id: $id, ')
          ..write('idUf: $idUf, ')
          ..write('nome: $nome, ')
          ..write('codigoIbge: $codigoIbge, ')
          ..write('codigoReceitaFederal: $codigoReceitaFederal, ')
          ..write('codigoEstadual: $codigoEstadual')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idUf, nome, codigoIbge, codigoReceitaFederal, codigoEstadual);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Municipio &&
          other.id == this.id &&
          other.idUf == this.idUf &&
          other.nome == this.nome &&
          other.codigoIbge == this.codigoIbge &&
          other.codigoReceitaFederal == this.codigoReceitaFederal &&
          other.codigoEstadual == this.codigoEstadual);
}

class MunicipiosCompanion extends UpdateCompanion<Municipio> {
  final Value<int?> id;
  final Value<int?> idUf;
  final Value<String?> nome;
  final Value<int?> codigoIbge;
  final Value<int?> codigoReceitaFederal;
  final Value<int?> codigoEstadual;
  const MunicipiosCompanion({
    this.id = const Value.absent(),
    this.idUf = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoIbge = const Value.absent(),
    this.codigoReceitaFederal = const Value.absent(),
    this.codigoEstadual = const Value.absent(),
  });
  MunicipiosCompanion.insert({
    this.id = const Value.absent(),
    this.idUf = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoIbge = const Value.absent(),
    this.codigoReceitaFederal = const Value.absent(),
    this.codigoEstadual = const Value.absent(),
  });
  static Insertable<Municipio> custom({
    Expression<int>? id,
    Expression<int>? idUf,
    Expression<String>? nome,
    Expression<int>? codigoIbge,
    Expression<int>? codigoReceitaFederal,
    Expression<int>? codigoEstadual,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idUf != null) 'id_uf': idUf,
      if (nome != null) 'nome': nome,
      if (codigoIbge != null) 'codigo_ibge': codigoIbge,
      if (codigoReceitaFederal != null)
        'codigo_receita_federal': codigoReceitaFederal,
      if (codigoEstadual != null) 'codigo_estadual': codigoEstadual,
    });
  }

  MunicipiosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idUf,
      Value<String?>? nome,
      Value<int?>? codigoIbge,
      Value<int?>? codigoReceitaFederal,
      Value<int?>? codigoEstadual}) {
    return MunicipiosCompanion(
      id: id ?? this.id,
      idUf: idUf ?? this.idUf,
      nome: nome ?? this.nome,
      codigoIbge: codigoIbge ?? this.codigoIbge,
      codigoReceitaFederal: codigoReceitaFederal ?? this.codigoReceitaFederal,
      codigoEstadual: codigoEstadual ?? this.codigoEstadual,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idUf.present) {
      map['id_uf'] = Variable<int>(idUf.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (codigoIbge.present) {
      map['codigo_ibge'] = Variable<int>(codigoIbge.value);
    }
    if (codigoReceitaFederal.present) {
      map['codigo_receita_federal'] = Variable<int>(codigoReceitaFederal.value);
    }
    if (codigoEstadual.present) {
      map['codigo_estadual'] = Variable<int>(codigoEstadual.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MunicipiosCompanion(')
          ..write('id: $id, ')
          ..write('idUf: $idUf, ')
          ..write('nome: $nome, ')
          ..write('codigoIbge: $codigoIbge, ')
          ..write('codigoReceitaFederal: $codigoReceitaFederal, ')
          ..write('codigoEstadual: $codigoEstadual')
          ..write(')'))
        .toString();
  }
}

class $NcmsTable extends Ncms with TableInfo<$NcmsTable, Ncm> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NcmsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ncm';
  @override
  VerificationContext validateIntegrity(Insertable<Ncm> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Ncm map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Ncm(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $NcmsTable createAlias(String alias) {
    return $NcmsTable(attachedDatabase, alias);
  }
}

class Ncm extends DataClass implements Insertable<Ncm> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const Ncm({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Ncm.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Ncm(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Ncm copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Ncm(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Ncm(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Ncm &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class NcmsCompanion extends UpdateCompanion<Ncm> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const NcmsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  NcmsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Ncm> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  NcmsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return NcmsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NcmsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CfopsTable extends Cfops with TableInfo<$CfopsTable, Cfop> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CfopsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<int> codigo = GeneratedColumn<int>(
      'codigo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aplicacaoMeta =
      const VerificationMeta('aplicacao');
  @override
  late final GeneratedColumn<String> aplicacao = GeneratedColumn<String>(
      'aplicacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, aplicacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cfop';
  @override
  VerificationContext validateIntegrity(Insertable<Cfop> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('aplicacao')) {
      context.handle(_aplicacaoMeta,
          aplicacao.isAcceptableOrUnknown(data['aplicacao']!, _aplicacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cfop map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cfop(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      aplicacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}aplicacao']),
    );
  }

  @override
  $CfopsTable createAlias(String alias) {
    return $CfopsTable(attachedDatabase, alias);
  }
}

class Cfop extends DataClass implements Insertable<Cfop> {
  final int? id;
  final int? codigo;
  final String? descricao;
  final String? aplicacao;
  const Cfop({this.id, this.codigo, this.descricao, this.aplicacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<int>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || aplicacao != null) {
      map['aplicacao'] = Variable<String>(aplicacao);
    }
    return map;
  }

  factory Cfop.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cfop(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<int?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      aplicacao: serializer.fromJson<String?>(json['aplicacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<int?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'aplicacao': serializer.toJson<String?>(aplicacao),
    };
  }

  Cfop copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> aplicacao = const Value.absent()}) =>
      Cfop(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        aplicacao: aplicacao.present ? aplicacao.value : this.aplicacao,
      );
  @override
  String toString() {
    return (StringBuffer('Cfop(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, aplicacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cfop &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.aplicacao == this.aplicacao);
}

class CfopsCompanion extends UpdateCompanion<Cfop> {
  final Value<int?> id;
  final Value<int?> codigo;
  final Value<String?> descricao;
  final Value<String?> aplicacao;
  const CfopsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  CfopsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  static Insertable<Cfop> custom({
    Expression<int>? id,
    Expression<int>? codigo,
    Expression<String>? descricao,
    Expression<String>? aplicacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (aplicacao != null) 'aplicacao': aplicacao,
    });
  }

  CfopsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? codigo,
      Value<String?>? descricao,
      Value<String?>? aplicacao}) {
    return CfopsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      aplicacao: aplicacao ?? this.aplicacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<int>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (aplicacao.present) {
      map['aplicacao'] = Variable<String>(aplicacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CfopsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }
}

class $CstIcmssTable extends CstIcmss with TableInfo<$CstIcmssTable, CstIcms> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CstIcmssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cst_icms';
  @override
  VerificationContext validateIntegrity(Insertable<CstIcms> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CstIcms map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CstIcms(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CstIcmssTable createAlias(String alias) {
    return $CstIcmssTable(attachedDatabase, alias);
  }
}

class CstIcms extends DataClass implements Insertable<CstIcms> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const CstIcms({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory CstIcms.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CstIcms(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  CstIcms copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      CstIcms(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('CstIcms(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CstIcms &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class CstIcmssCompanion extends UpdateCompanion<CstIcms> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const CstIcmssCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CstIcmssCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<CstIcms> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CstIcmssCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return CstIcmssCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CstIcmssCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CstIpisTable extends CstIpis with TableInfo<$CstIpisTable, CstIpi> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CstIpisTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cst_ipi';
  @override
  VerificationContext validateIntegrity(Insertable<CstIpi> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CstIpi map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CstIpi(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CstIpisTable createAlias(String alias) {
    return $CstIpisTable(attachedDatabase, alias);
  }
}

class CstIpi extends DataClass implements Insertable<CstIpi> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const CstIpi({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory CstIpi.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CstIpi(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  CstIpi copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      CstIpi(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('CstIpi(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CstIpi &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class CstIpisCompanion extends UpdateCompanion<CstIpi> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const CstIpisCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CstIpisCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<CstIpi> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CstIpisCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return CstIpisCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CstIpisCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CstCofinssTable extends CstCofinss
    with TableInfo<$CstCofinssTable, CstCofins> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CstCofinssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cst_cofins';
  @override
  VerificationContext validateIntegrity(Insertable<CstCofins> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CstCofins map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CstCofins(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CstCofinssTable createAlias(String alias) {
    return $CstCofinssTable(attachedDatabase, alias);
  }
}

class CstCofins extends DataClass implements Insertable<CstCofins> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const CstCofins({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory CstCofins.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CstCofins(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  CstCofins copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      CstCofins(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('CstCofins(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CstCofins &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class CstCofinssCompanion extends UpdateCompanion<CstCofins> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const CstCofinssCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CstCofinssCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<CstCofins> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CstCofinssCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return CstCofinssCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CstCofinssCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CstPissTable extends CstPiss with TableInfo<$CstPissTable, CstPis> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CstPissTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cst_pis';
  @override
  VerificationContext validateIntegrity(Insertable<CstPis> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CstPis map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CstPis(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CstPissTable createAlias(String alias) {
    return $CstPissTable(attachedDatabase, alias);
  }
}

class CstPis extends DataClass implements Insertable<CstPis> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const CstPis({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory CstPis.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CstPis(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  CstPis copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      CstPis(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('CstPis(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CstPis &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class CstPissCompanion extends UpdateCompanion<CstPis> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const CstPissCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CstPissCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<CstPis> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CstPissCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return CstPissCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CstPissCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CsosnsTable extends Csosns with TableInfo<$CsosnsTable, Csosn> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CsosnsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'csosn';
  @override
  VerificationContext validateIntegrity(Insertable<Csosn> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Csosn map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Csosn(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CsosnsTable createAlias(String alias) {
    return $CsosnsTable(attachedDatabase, alias);
  }
}

class Csosn extends DataClass implements Insertable<Csosn> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? observacao;
  const Csosn({this.id, this.codigo, this.descricao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Csosn.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Csosn(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Csosn copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Csosn(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('Csosn(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Csosn &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.observacao == this.observacao);
}

class CsosnsCompanion extends UpdateCompanion<Csosn> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> observacao;
  const CsosnsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CsosnsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Csosn> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CsosnsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? observacao}) {
    return CsosnsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CsosnsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CnaesTable extends Cnaes with TableInfo<$CnaesTable, Cnae> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CnaesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _denominacaoMeta =
      const VerificationMeta('denominacao');
  @override
  late final GeneratedColumn<String> denominacao = GeneratedColumn<String>(
      'denominacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, denominacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cnae';
  @override
  VerificationContext validateIntegrity(Insertable<Cnae> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('denominacao')) {
      context.handle(
          _denominacaoMeta,
          denominacao.isAcceptableOrUnknown(
              data['denominacao']!, _denominacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Cnae map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Cnae(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      denominacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}denominacao']),
    );
  }

  @override
  $CnaesTable createAlias(String alias) {
    return $CnaesTable(attachedDatabase, alias);
  }
}

class Cnae extends DataClass implements Insertable<Cnae> {
  final int? id;
  final String? codigo;
  final String? denominacao;
  const Cnae({this.id, this.codigo, this.denominacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || denominacao != null) {
      map['denominacao'] = Variable<String>(denominacao);
    }
    return map;
  }

  factory Cnae.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Cnae(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      denominacao: serializer.fromJson<String?>(json['denominacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'denominacao': serializer.toJson<String?>(denominacao),
    };
  }

  Cnae copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> denominacao = const Value.absent()}) =>
      Cnae(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        denominacao: denominacao.present ? denominacao.value : this.denominacao,
      );
  @override
  String toString() {
    return (StringBuffer('Cnae(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('denominacao: $denominacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, denominacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Cnae &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.denominacao == this.denominacao);
}

class CnaesCompanion extends UpdateCompanion<Cnae> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> denominacao;
  const CnaesCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.denominacao = const Value.absent(),
  });
  CnaesCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.denominacao = const Value.absent(),
  });
  static Insertable<Cnae> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? denominacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (denominacao != null) 'denominacao': denominacao,
    });
  }

  CnaesCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? denominacao}) {
    return CnaesCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      denominacao: denominacao ?? this.denominacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (denominacao.present) {
      map['denominacao'] = Variable<String>(denominacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CnaesCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('denominacao: $denominacao')
          ..write(')'))
        .toString();
  }
}

class $PaissTable extends Paiss with TableInfo<$PaissTable, Pais> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PaissTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePtbrMeta =
      const VerificationMeta('nomePtbr');
  @override
  late final GeneratedColumn<String> nomePtbr = GeneratedColumn<String>(
      'nome_ptbr', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeEnMeta = const VerificationMeta('nomeEn');
  @override
  late final GeneratedColumn<String> nomeEn = GeneratedColumn<String>(
      'nome_en', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<int> codigo = GeneratedColumn<int>(
      'codigo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _sigla2Meta = const VerificationMeta('sigla2');
  @override
  late final GeneratedColumn<String> sigla2 = GeneratedColumn<String>(
      'sigla2', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _sigla3Meta = const VerificationMeta('sigla3');
  @override
  late final GeneratedColumn<String> sigla3 = GeneratedColumn<String>(
      'sigla3', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoBacenMeta =
      const VerificationMeta('codigoBacen');
  @override
  late final GeneratedColumn<int> codigoBacen = GeneratedColumn<int>(
      'codigo_bacen', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nomePtbr, nomeEn, codigo, sigla2, sigla3, codigoBacen];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pais';
  @override
  VerificationContext validateIntegrity(Insertable<Pais> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome_ptbr')) {
      context.handle(_nomePtbrMeta,
          nomePtbr.isAcceptableOrUnknown(data['nome_ptbr']!, _nomePtbrMeta));
    }
    if (data.containsKey('nome_en')) {
      context.handle(_nomeEnMeta,
          nomeEn.isAcceptableOrUnknown(data['nome_en']!, _nomeEnMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('sigla2')) {
      context.handle(_sigla2Meta,
          sigla2.isAcceptableOrUnknown(data['sigla2']!, _sigla2Meta));
    }
    if (data.containsKey('sigla3')) {
      context.handle(_sigla3Meta,
          sigla3.isAcceptableOrUnknown(data['sigla3']!, _sigla3Meta));
    }
    if (data.containsKey('codigo_bacen')) {
      context.handle(
          _codigoBacenMeta,
          codigoBacen.isAcceptableOrUnknown(
              data['codigo_bacen']!, _codigoBacenMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Pais map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Pais(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nomePtbr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_ptbr']),
      nomeEn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_en']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo']),
      sigla2: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla2']),
      sigla3: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla3']),
      codigoBacen: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_bacen']),
    );
  }

  @override
  $PaissTable createAlias(String alias) {
    return $PaissTable(attachedDatabase, alias);
  }
}

class Pais extends DataClass implements Insertable<Pais> {
  final int? id;
  final String? nomePtbr;
  final String? nomeEn;
  final int? codigo;
  final String? sigla2;
  final String? sigla3;
  final int? codigoBacen;
  const Pais(
      {this.id,
      this.nomePtbr,
      this.nomeEn,
      this.codigo,
      this.sigla2,
      this.sigla3,
      this.codigoBacen});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nomePtbr != null) {
      map['nome_ptbr'] = Variable<String>(nomePtbr);
    }
    if (!nullToAbsent || nomeEn != null) {
      map['nome_en'] = Variable<String>(nomeEn);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<int>(codigo);
    }
    if (!nullToAbsent || sigla2 != null) {
      map['sigla2'] = Variable<String>(sigla2);
    }
    if (!nullToAbsent || sigla3 != null) {
      map['sigla3'] = Variable<String>(sigla3);
    }
    if (!nullToAbsent || codigoBacen != null) {
      map['codigo_bacen'] = Variable<int>(codigoBacen);
    }
    return map;
  }

  factory Pais.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Pais(
      id: serializer.fromJson<int?>(json['id']),
      nomePtbr: serializer.fromJson<String?>(json['nomePtbr']),
      nomeEn: serializer.fromJson<String?>(json['nomeEn']),
      codigo: serializer.fromJson<int?>(json['codigo']),
      sigla2: serializer.fromJson<String?>(json['sigla2']),
      sigla3: serializer.fromJson<String?>(json['sigla3']),
      codigoBacen: serializer.fromJson<int?>(json['codigoBacen']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nomePtbr': serializer.toJson<String?>(nomePtbr),
      'nomeEn': serializer.toJson<String?>(nomeEn),
      'codigo': serializer.toJson<int?>(codigo),
      'sigla2': serializer.toJson<String?>(sigla2),
      'sigla3': serializer.toJson<String?>(sigla3),
      'codigoBacen': serializer.toJson<int?>(codigoBacen),
    };
  }

  Pais copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nomePtbr = const Value.absent(),
          Value<String?> nomeEn = const Value.absent(),
          Value<int?> codigo = const Value.absent(),
          Value<String?> sigla2 = const Value.absent(),
          Value<String?> sigla3 = const Value.absent(),
          Value<int?> codigoBacen = const Value.absent()}) =>
      Pais(
        id: id.present ? id.value : this.id,
        nomePtbr: nomePtbr.present ? nomePtbr.value : this.nomePtbr,
        nomeEn: nomeEn.present ? nomeEn.value : this.nomeEn,
        codigo: codigo.present ? codigo.value : this.codigo,
        sigla2: sigla2.present ? sigla2.value : this.sigla2,
        sigla3: sigla3.present ? sigla3.value : this.sigla3,
        codigoBacen: codigoBacen.present ? codigoBacen.value : this.codigoBacen,
      );
  @override
  String toString() {
    return (StringBuffer('Pais(')
          ..write('id: $id, ')
          ..write('nomePtbr: $nomePtbr, ')
          ..write('nomeEn: $nomeEn, ')
          ..write('codigo: $codigo, ')
          ..write('sigla2: $sigla2, ')
          ..write('sigla3: $sigla3, ')
          ..write('codigoBacen: $codigoBacen')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, nomePtbr, nomeEn, codigo, sigla2, sigla3, codigoBacen);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Pais &&
          other.id == this.id &&
          other.nomePtbr == this.nomePtbr &&
          other.nomeEn == this.nomeEn &&
          other.codigo == this.codigo &&
          other.sigla2 == this.sigla2 &&
          other.sigla3 == this.sigla3 &&
          other.codigoBacen == this.codigoBacen);
}

class PaissCompanion extends UpdateCompanion<Pais> {
  final Value<int?> id;
  final Value<String?> nomePtbr;
  final Value<String?> nomeEn;
  final Value<int?> codigo;
  final Value<String?> sigla2;
  final Value<String?> sigla3;
  final Value<int?> codigoBacen;
  const PaissCompanion({
    this.id = const Value.absent(),
    this.nomePtbr = const Value.absent(),
    this.nomeEn = const Value.absent(),
    this.codigo = const Value.absent(),
    this.sigla2 = const Value.absent(),
    this.sigla3 = const Value.absent(),
    this.codigoBacen = const Value.absent(),
  });
  PaissCompanion.insert({
    this.id = const Value.absent(),
    this.nomePtbr = const Value.absent(),
    this.nomeEn = const Value.absent(),
    this.codigo = const Value.absent(),
    this.sigla2 = const Value.absent(),
    this.sigla3 = const Value.absent(),
    this.codigoBacen = const Value.absent(),
  });
  static Insertable<Pais> custom({
    Expression<int>? id,
    Expression<String>? nomePtbr,
    Expression<String>? nomeEn,
    Expression<int>? codigo,
    Expression<String>? sigla2,
    Expression<String>? sigla3,
    Expression<int>? codigoBacen,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nomePtbr != null) 'nome_ptbr': nomePtbr,
      if (nomeEn != null) 'nome_en': nomeEn,
      if (codigo != null) 'codigo': codigo,
      if (sigla2 != null) 'sigla2': sigla2,
      if (sigla3 != null) 'sigla3': sigla3,
      if (codigoBacen != null) 'codigo_bacen': codigoBacen,
    });
  }

  PaissCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nomePtbr,
      Value<String?>? nomeEn,
      Value<int?>? codigo,
      Value<String?>? sigla2,
      Value<String?>? sigla3,
      Value<int?>? codigoBacen}) {
    return PaissCompanion(
      id: id ?? this.id,
      nomePtbr: nomePtbr ?? this.nomePtbr,
      nomeEn: nomeEn ?? this.nomeEn,
      codigo: codigo ?? this.codigo,
      sigla2: sigla2 ?? this.sigla2,
      sigla3: sigla3 ?? this.sigla3,
      codigoBacen: codigoBacen ?? this.codigoBacen,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nomePtbr.present) {
      map['nome_ptbr'] = Variable<String>(nomePtbr.value);
    }
    if (nomeEn.present) {
      map['nome_en'] = Variable<String>(nomeEn.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<int>(codigo.value);
    }
    if (sigla2.present) {
      map['sigla2'] = Variable<String>(sigla2.value);
    }
    if (sigla3.present) {
      map['sigla3'] = Variable<String>(sigla3.value);
    }
    if (codigoBacen.present) {
      map['codigo_bacen'] = Variable<int>(codigoBacen.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PaissCompanion(')
          ..write('id: $id, ')
          ..write('nomePtbr: $nomePtbr, ')
          ..write('nomeEn: $nomeEn, ')
          ..write('codigo: $codigo, ')
          ..write('sigla2: $sigla2, ')
          ..write('sigla3: $sigla3, ')
          ..write('codigoBacen: $codigoBacen')
          ..write(')'))
        .toString();
  }
}

class $NivelFormacaosTable extends NivelFormacaos
    with TableInfo<$NivelFormacaosTable, NivelFormacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NivelFormacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nivel_formacao';
  @override
  VerificationContext validateIntegrity(Insertable<NivelFormacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NivelFormacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NivelFormacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $NivelFormacaosTable createAlias(String alias) {
    return $NivelFormacaosTable(attachedDatabase, alias);
  }
}

class NivelFormacao extends DataClass implements Insertable<NivelFormacao> {
  final int? id;
  final String? nome;
  final String? descricao;
  const NivelFormacao({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory NivelFormacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NivelFormacao(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  NivelFormacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      NivelFormacao(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('NivelFormacao(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NivelFormacao &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class NivelFormacaosCompanion extends UpdateCompanion<NivelFormacao> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const NivelFormacaosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  NivelFormacaosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<NivelFormacao> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  NivelFormacaosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return NivelFormacaosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NivelFormacaosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $TabelaPrecosTable extends TabelaPrecos
    with TableInfo<$TabelaPrecosTable, TabelaPreco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TabelaPrecosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _principalMeta =
      const VerificationMeta('principal');
  @override
  late final GeneratedColumn<String> principal = GeneratedColumn<String>(
      'principal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _coeficienteMeta =
      const VerificationMeta('coeficiente');
  @override
  late final GeneratedColumn<double> coeficiente = GeneratedColumn<double>(
      'coeficiente', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, principal, coeficiente];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tabela_preco';
  @override
  VerificationContext validateIntegrity(Insertable<TabelaPreco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('principal')) {
      context.handle(_principalMeta,
          principal.isAcceptableOrUnknown(data['principal']!, _principalMeta));
    }
    if (data.containsKey('coeficiente')) {
      context.handle(
          _coeficienteMeta,
          coeficiente.isAcceptableOrUnknown(
              data['coeficiente']!, _coeficienteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TabelaPreco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TabelaPreco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      principal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}principal']),
      coeficiente: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}coeficiente']),
    );
  }

  @override
  $TabelaPrecosTable createAlias(String alias) {
    return $TabelaPrecosTable(attachedDatabase, alias);
  }
}

class TabelaPreco extends DataClass implements Insertable<TabelaPreco> {
  final int? id;
  final String? nome;
  final String? principal;
  final double? coeficiente;
  const TabelaPreco({this.id, this.nome, this.principal, this.coeficiente});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || principal != null) {
      map['principal'] = Variable<String>(principal);
    }
    if (!nullToAbsent || coeficiente != null) {
      map['coeficiente'] = Variable<double>(coeficiente);
    }
    return map;
  }

  factory TabelaPreco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TabelaPreco(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      principal: serializer.fromJson<String?>(json['principal']),
      coeficiente: serializer.fromJson<double?>(json['coeficiente']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'principal': serializer.toJson<String?>(principal),
      'coeficiente': serializer.toJson<double?>(coeficiente),
    };
  }

  TabelaPreco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> principal = const Value.absent(),
          Value<double?> coeficiente = const Value.absent()}) =>
      TabelaPreco(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        principal: principal.present ? principal.value : this.principal,
        coeficiente: coeficiente.present ? coeficiente.value : this.coeficiente,
      );
  @override
  String toString() {
    return (StringBuffer('TabelaPreco(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('principal: $principal, ')
          ..write('coeficiente: $coeficiente')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, principal, coeficiente);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TabelaPreco &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.principal == this.principal &&
          other.coeficiente == this.coeficiente);
}

class TabelaPrecosCompanion extends UpdateCompanion<TabelaPreco> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> principal;
  final Value<double?> coeficiente;
  const TabelaPrecosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.principal = const Value.absent(),
    this.coeficiente = const Value.absent(),
  });
  TabelaPrecosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.principal = const Value.absent(),
    this.coeficiente = const Value.absent(),
  });
  static Insertable<TabelaPreco> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? principal,
    Expression<double>? coeficiente,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (principal != null) 'principal': principal,
      if (coeficiente != null) 'coeficiente': coeficiente,
    });
  }

  TabelaPrecosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? principal,
      Value<double?>? coeficiente}) {
    return TabelaPrecosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      principal: principal ?? this.principal,
      coeficiente: coeficiente ?? this.coeficiente,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (principal.present) {
      map['principal'] = Variable<String>(principal.value);
    }
    if (coeficiente.present) {
      map['coeficiente'] = Variable<double>(coeficiente.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TabelaPrecosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('principal: $principal, ')
          ..write('coeficiente: $coeficiente')
          ..write(')'))
        .toString();
  }
}

class $TipoRelacionamentosTable extends TipoRelacionamentos
    with TableInfo<$TipoRelacionamentosTable, TipoRelacionamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TipoRelacionamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tipo_relacionamento';
  @override
  VerificationContext validateIntegrity(Insertable<TipoRelacionamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TipoRelacionamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TipoRelacionamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $TipoRelacionamentosTable createAlias(String alias) {
    return $TipoRelacionamentosTable(attachedDatabase, alias);
  }
}

class TipoRelacionamento extends DataClass
    implements Insertable<TipoRelacionamento> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const TipoRelacionamento({this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory TipoRelacionamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TipoRelacionamento(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  TipoRelacionamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      TipoRelacionamento(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('TipoRelacionamento(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TipoRelacionamento &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class TipoRelacionamentosCompanion extends UpdateCompanion<TipoRelacionamento> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const TipoRelacionamentosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  TipoRelacionamentosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<TipoRelacionamento> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  TipoRelacionamentosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return TipoRelacionamentosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TipoRelacionamentosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ComissaoPerfilsTable extends ComissaoPerfils
    with TableInfo<$ComissaoPerfilsTable, ComissaoPerfil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ComissaoPerfilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'comissao_perfil';
  @override
  VerificationContext validateIntegrity(Insertable<ComissaoPerfil> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ComissaoPerfil map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ComissaoPerfil(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $ComissaoPerfilsTable createAlias(String alias) {
    return $ComissaoPerfilsTable(attachedDatabase, alias);
  }
}

class ComissaoPerfil extends DataClass implements Insertable<ComissaoPerfil> {
  final int? id;
  final String? codigo;
  final String? nome;
  const ComissaoPerfil({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory ComissaoPerfil.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ComissaoPerfil(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  ComissaoPerfil copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      ComissaoPerfil(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('ComissaoPerfil(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ComissaoPerfil &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class ComissaoPerfilsCompanion extends UpdateCompanion<ComissaoPerfil> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const ComissaoPerfilsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  ComissaoPerfilsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<ComissaoPerfil> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  ComissaoPerfilsCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return ComissaoPerfilsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ComissaoPerfilsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $SindicatosTable extends Sindicatos
    with TableInfo<$SindicatosTable, Sindicato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SindicatosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoBancoMeta =
      const VerificationMeta('codigoBanco');
  @override
  late final GeneratedColumn<int> codigoBanco = GeneratedColumn<int>(
      'codigo_banco', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoAgenciaMeta =
      const VerificationMeta('codigoAgencia');
  @override
  late final GeneratedColumn<int> codigoAgencia = GeneratedColumn<int>(
      'codigo_agencia', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _contaBancoMeta =
      const VerificationMeta('contaBanco');
  @override
  late final GeneratedColumn<String> contaBanco = GeneratedColumn<String>(
      'conta_banco', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoCedenteMeta =
      const VerificationMeta('codigoCedente');
  @override
  late final GeneratedColumn<String> codigoCedente = GeneratedColumn<String>(
      'codigo_cedente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<int> municipioIbge = GeneratedColumn<int>(
      'municipio_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fone1Meta = const VerificationMeta('fone1');
  @override
  late final GeneratedColumn<String> fone1 = GeneratedColumn<String>(
      'fone1', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fone2Meta = const VerificationMeta('fone2');
  @override
  late final GeneratedColumn<String> fone2 = GeneratedColumn<String>(
      'fone2', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoSindicatoMeta =
      const VerificationMeta('tipoSindicato');
  @override
  late final GeneratedColumn<String> tipoSindicato = GeneratedColumn<String>(
      'tipo_sindicato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataBaseMeta =
      const VerificationMeta('dataBase');
  @override
  late final GeneratedColumn<DateTime> dataBase = GeneratedColumn<DateTime>(
      'data_base', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _pisoSalarialMeta =
      const VerificationMeta('pisoSalarial');
  @override
  late final GeneratedColumn<double> pisoSalarial = GeneratedColumn<double>(
      'piso_salarial', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _classificacaoContabilContaMeta =
      const VerificationMeta('classificacaoContabilConta');
  @override
  late final GeneratedColumn<String> classificacaoContabilConta =
      GeneratedColumn<String>('classificacao_contabil_conta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        codigoBanco,
        codigoAgencia,
        contaBanco,
        codigoCedente,
        logradouro,
        numero,
        bairro,
        municipioIbge,
        uf,
        fone1,
        fone2,
        email,
        tipoSindicato,
        dataBase,
        pisoSalarial,
        cnpj,
        classificacaoContabilConta
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sindicato';
  @override
  VerificationContext validateIntegrity(Insertable<Sindicato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('codigo_banco')) {
      context.handle(
          _codigoBancoMeta,
          codigoBanco.isAcceptableOrUnknown(
              data['codigo_banco']!, _codigoBancoMeta));
    }
    if (data.containsKey('codigo_agencia')) {
      context.handle(
          _codigoAgenciaMeta,
          codigoAgencia.isAcceptableOrUnknown(
              data['codigo_agencia']!, _codigoAgenciaMeta));
    }
    if (data.containsKey('conta_banco')) {
      context.handle(
          _contaBancoMeta,
          contaBanco.isAcceptableOrUnknown(
              data['conta_banco']!, _contaBancoMeta));
    }
    if (data.containsKey('codigo_cedente')) {
      context.handle(
          _codigoCedenteMeta,
          codigoCedente.isAcceptableOrUnknown(
              data['codigo_cedente']!, _codigoCedenteMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('fone1')) {
      context.handle(
          _fone1Meta, fone1.isAcceptableOrUnknown(data['fone1']!, _fone1Meta));
    }
    if (data.containsKey('fone2')) {
      context.handle(
          _fone2Meta, fone2.isAcceptableOrUnknown(data['fone2']!, _fone2Meta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('tipo_sindicato')) {
      context.handle(
          _tipoSindicatoMeta,
          tipoSindicato.isAcceptableOrUnknown(
              data['tipo_sindicato']!, _tipoSindicatoMeta));
    }
    if (data.containsKey('data_base')) {
      context.handle(_dataBaseMeta,
          dataBase.isAcceptableOrUnknown(data['data_base']!, _dataBaseMeta));
    }
    if (data.containsKey('piso_salarial')) {
      context.handle(
          _pisoSalarialMeta,
          pisoSalarial.isAcceptableOrUnknown(
              data['piso_salarial']!, _pisoSalarialMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('classificacao_contabil_conta')) {
      context.handle(
          _classificacaoContabilContaMeta,
          classificacaoContabilConta.isAcceptableOrUnknown(
              data['classificacao_contabil_conta']!,
              _classificacaoContabilContaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Sindicato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Sindicato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      codigoBanco: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_banco']),
      codigoAgencia: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_agencia']),
      contaBanco: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_banco']),
      codigoCedente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_cedente']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      fone1: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fone1']),
      fone2: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fone2']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      tipoSindicato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_sindicato']),
      dataBase: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_base']),
      pisoSalarial: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}piso_salarial']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      classificacaoContabilConta: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}classificacao_contabil_conta']),
    );
  }

  @override
  $SindicatosTable createAlias(String alias) {
    return $SindicatosTable(attachedDatabase, alias);
  }
}

class Sindicato extends DataClass implements Insertable<Sindicato> {
  final int? id;
  final String? nome;
  final int? codigoBanco;
  final int? codigoAgencia;
  final String? contaBanco;
  final String? codigoCedente;
  final String? logradouro;
  final String? numero;
  final String? bairro;
  final int? municipioIbge;
  final String? uf;
  final String? fone1;
  final String? fone2;
  final String? email;
  final String? tipoSindicato;
  final DateTime? dataBase;
  final double? pisoSalarial;
  final String? cnpj;
  final String? classificacaoContabilConta;
  const Sindicato(
      {this.id,
      this.nome,
      this.codigoBanco,
      this.codigoAgencia,
      this.contaBanco,
      this.codigoCedente,
      this.logradouro,
      this.numero,
      this.bairro,
      this.municipioIbge,
      this.uf,
      this.fone1,
      this.fone2,
      this.email,
      this.tipoSindicato,
      this.dataBase,
      this.pisoSalarial,
      this.cnpj,
      this.classificacaoContabilConta});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || codigoBanco != null) {
      map['codigo_banco'] = Variable<int>(codigoBanco);
    }
    if (!nullToAbsent || codigoAgencia != null) {
      map['codigo_agencia'] = Variable<int>(codigoAgencia);
    }
    if (!nullToAbsent || contaBanco != null) {
      map['conta_banco'] = Variable<String>(contaBanco);
    }
    if (!nullToAbsent || codigoCedente != null) {
      map['codigo_cedente'] = Variable<String>(codigoCedente);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<int>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || fone1 != null) {
      map['fone1'] = Variable<String>(fone1);
    }
    if (!nullToAbsent || fone2 != null) {
      map['fone2'] = Variable<String>(fone2);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || tipoSindicato != null) {
      map['tipo_sindicato'] = Variable<String>(tipoSindicato);
    }
    if (!nullToAbsent || dataBase != null) {
      map['data_base'] = Variable<DateTime>(dataBase);
    }
    if (!nullToAbsent || pisoSalarial != null) {
      map['piso_salarial'] = Variable<double>(pisoSalarial);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || classificacaoContabilConta != null) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta);
    }
    return map;
  }

  factory Sindicato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Sindicato(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      codigoBanco: serializer.fromJson<int?>(json['codigoBanco']),
      codigoAgencia: serializer.fromJson<int?>(json['codigoAgencia']),
      contaBanco: serializer.fromJson<String?>(json['contaBanco']),
      codigoCedente: serializer.fromJson<String?>(json['codigoCedente']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      municipioIbge: serializer.fromJson<int?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      fone1: serializer.fromJson<String?>(json['fone1']),
      fone2: serializer.fromJson<String?>(json['fone2']),
      email: serializer.fromJson<String?>(json['email']),
      tipoSindicato: serializer.fromJson<String?>(json['tipoSindicato']),
      dataBase: serializer.fromJson<DateTime?>(json['dataBase']),
      pisoSalarial: serializer.fromJson<double?>(json['pisoSalarial']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      classificacaoContabilConta:
          serializer.fromJson<String?>(json['classificacaoContabilConta']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'codigoBanco': serializer.toJson<int?>(codigoBanco),
      'codigoAgencia': serializer.toJson<int?>(codigoAgencia),
      'contaBanco': serializer.toJson<String?>(contaBanco),
      'codigoCedente': serializer.toJson<String?>(codigoCedente),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'bairro': serializer.toJson<String?>(bairro),
      'municipioIbge': serializer.toJson<int?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'fone1': serializer.toJson<String?>(fone1),
      'fone2': serializer.toJson<String?>(fone2),
      'email': serializer.toJson<String?>(email),
      'tipoSindicato': serializer.toJson<String?>(tipoSindicato),
      'dataBase': serializer.toJson<DateTime?>(dataBase),
      'pisoSalarial': serializer.toJson<double?>(pisoSalarial),
      'cnpj': serializer.toJson<String?>(cnpj),
      'classificacaoContabilConta':
          serializer.toJson<String?>(classificacaoContabilConta),
    };
  }

  Sindicato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<int?> codigoBanco = const Value.absent(),
          Value<int?> codigoAgencia = const Value.absent(),
          Value<String?> contaBanco = const Value.absent(),
          Value<String?> codigoCedente = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> fone1 = const Value.absent(),
          Value<String?> fone2 = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> tipoSindicato = const Value.absent(),
          Value<DateTime?> dataBase = const Value.absent(),
          Value<double?> pisoSalarial = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> classificacaoContabilConta = const Value.absent()}) =>
      Sindicato(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        codigoBanco: codigoBanco.present ? codigoBanco.value : this.codigoBanco,
        codigoAgencia:
            codigoAgencia.present ? codigoAgencia.value : this.codigoAgencia,
        contaBanco: contaBanco.present ? contaBanco.value : this.contaBanco,
        codigoCedente:
            codigoCedente.present ? codigoCedente.value : this.codigoCedente,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        bairro: bairro.present ? bairro.value : this.bairro,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        fone1: fone1.present ? fone1.value : this.fone1,
        fone2: fone2.present ? fone2.value : this.fone2,
        email: email.present ? email.value : this.email,
        tipoSindicato:
            tipoSindicato.present ? tipoSindicato.value : this.tipoSindicato,
        dataBase: dataBase.present ? dataBase.value : this.dataBase,
        pisoSalarial:
            pisoSalarial.present ? pisoSalarial.value : this.pisoSalarial,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        classificacaoContabilConta: classificacaoContabilConta.present
            ? classificacaoContabilConta.value
            : this.classificacaoContabilConta,
      );
  @override
  String toString() {
    return (StringBuffer('Sindicato(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('codigoBanco: $codigoBanco, ')
          ..write('codigoAgencia: $codigoAgencia, ')
          ..write('contaBanco: $contaBanco, ')
          ..write('codigoCedente: $codigoCedente, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('fone1: $fone1, ')
          ..write('fone2: $fone2, ')
          ..write('email: $email, ')
          ..write('tipoSindicato: $tipoSindicato, ')
          ..write('dataBase: $dataBase, ')
          ..write('pisoSalarial: $pisoSalarial, ')
          ..write('cnpj: $cnpj, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      nome,
      codigoBanco,
      codigoAgencia,
      contaBanco,
      codigoCedente,
      logradouro,
      numero,
      bairro,
      municipioIbge,
      uf,
      fone1,
      fone2,
      email,
      tipoSindicato,
      dataBase,
      pisoSalarial,
      cnpj,
      classificacaoContabilConta);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Sindicato &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.codigoBanco == this.codigoBanco &&
          other.codigoAgencia == this.codigoAgencia &&
          other.contaBanco == this.contaBanco &&
          other.codigoCedente == this.codigoCedente &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.bairro == this.bairro &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.fone1 == this.fone1 &&
          other.fone2 == this.fone2 &&
          other.email == this.email &&
          other.tipoSindicato == this.tipoSindicato &&
          other.dataBase == this.dataBase &&
          other.pisoSalarial == this.pisoSalarial &&
          other.cnpj == this.cnpj &&
          other.classificacaoContabilConta == this.classificacaoContabilConta);
}

class SindicatosCompanion extends UpdateCompanion<Sindicato> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<int?> codigoBanco;
  final Value<int?> codigoAgencia;
  final Value<String?> contaBanco;
  final Value<String?> codigoCedente;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> bairro;
  final Value<int?> municipioIbge;
  final Value<String?> uf;
  final Value<String?> fone1;
  final Value<String?> fone2;
  final Value<String?> email;
  final Value<String?> tipoSindicato;
  final Value<DateTime?> dataBase;
  final Value<double?> pisoSalarial;
  final Value<String?> cnpj;
  final Value<String?> classificacaoContabilConta;
  const SindicatosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoBanco = const Value.absent(),
    this.codigoAgencia = const Value.absent(),
    this.contaBanco = const Value.absent(),
    this.codigoCedente = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.fone1 = const Value.absent(),
    this.fone2 = const Value.absent(),
    this.email = const Value.absent(),
    this.tipoSindicato = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.pisoSalarial = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  SindicatosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoBanco = const Value.absent(),
    this.codigoAgencia = const Value.absent(),
    this.contaBanco = const Value.absent(),
    this.codigoCedente = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.bairro = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.fone1 = const Value.absent(),
    this.fone2 = const Value.absent(),
    this.email = const Value.absent(),
    this.tipoSindicato = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.pisoSalarial = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  static Insertable<Sindicato> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<int>? codigoBanco,
    Expression<int>? codigoAgencia,
    Expression<String>? contaBanco,
    Expression<String>? codigoCedente,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? bairro,
    Expression<int>? municipioIbge,
    Expression<String>? uf,
    Expression<String>? fone1,
    Expression<String>? fone2,
    Expression<String>? email,
    Expression<String>? tipoSindicato,
    Expression<DateTime>? dataBase,
    Expression<double>? pisoSalarial,
    Expression<String>? cnpj,
    Expression<String>? classificacaoContabilConta,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (codigoBanco != null) 'codigo_banco': codigoBanco,
      if (codigoAgencia != null) 'codigo_agencia': codigoAgencia,
      if (contaBanco != null) 'conta_banco': contaBanco,
      if (codigoCedente != null) 'codigo_cedente': codigoCedente,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (bairro != null) 'bairro': bairro,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (fone1 != null) 'fone1': fone1,
      if (fone2 != null) 'fone2': fone2,
      if (email != null) 'email': email,
      if (tipoSindicato != null) 'tipo_sindicato': tipoSindicato,
      if (dataBase != null) 'data_base': dataBase,
      if (pisoSalarial != null) 'piso_salarial': pisoSalarial,
      if (cnpj != null) 'cnpj': cnpj,
      if (classificacaoContabilConta != null)
        'classificacao_contabil_conta': classificacaoContabilConta,
    });
  }

  SindicatosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<int?>? codigoBanco,
      Value<int?>? codigoAgencia,
      Value<String?>? contaBanco,
      Value<String?>? codigoCedente,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? bairro,
      Value<int?>? municipioIbge,
      Value<String?>? uf,
      Value<String?>? fone1,
      Value<String?>? fone2,
      Value<String?>? email,
      Value<String?>? tipoSindicato,
      Value<DateTime?>? dataBase,
      Value<double?>? pisoSalarial,
      Value<String?>? cnpj,
      Value<String?>? classificacaoContabilConta}) {
    return SindicatosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      codigoBanco: codigoBanco ?? this.codigoBanco,
      codigoAgencia: codigoAgencia ?? this.codigoAgencia,
      contaBanco: contaBanco ?? this.contaBanco,
      codigoCedente: codigoCedente ?? this.codigoCedente,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      bairro: bairro ?? this.bairro,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      fone1: fone1 ?? this.fone1,
      fone2: fone2 ?? this.fone2,
      email: email ?? this.email,
      tipoSindicato: tipoSindicato ?? this.tipoSindicato,
      dataBase: dataBase ?? this.dataBase,
      pisoSalarial: pisoSalarial ?? this.pisoSalarial,
      cnpj: cnpj ?? this.cnpj,
      classificacaoContabilConta:
          classificacaoContabilConta ?? this.classificacaoContabilConta,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (codigoBanco.present) {
      map['codigo_banco'] = Variable<int>(codigoBanco.value);
    }
    if (codigoAgencia.present) {
      map['codigo_agencia'] = Variable<int>(codigoAgencia.value);
    }
    if (contaBanco.present) {
      map['conta_banco'] = Variable<String>(contaBanco.value);
    }
    if (codigoCedente.present) {
      map['codigo_cedente'] = Variable<String>(codigoCedente.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<int>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (fone1.present) {
      map['fone1'] = Variable<String>(fone1.value);
    }
    if (fone2.present) {
      map['fone2'] = Variable<String>(fone2.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (tipoSindicato.present) {
      map['tipo_sindicato'] = Variable<String>(tipoSindicato.value);
    }
    if (dataBase.present) {
      map['data_base'] = Variable<DateTime>(dataBase.value);
    }
    if (pisoSalarial.present) {
      map['piso_salarial'] = Variable<double>(pisoSalarial.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (classificacaoContabilConta.present) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SindicatosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('codigoBanco: $codigoBanco, ')
          ..write('codigoAgencia: $codigoAgencia, ')
          ..write('contaBanco: $contaBanco, ')
          ..write('codigoCedente: $codigoCedente, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('bairro: $bairro, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('fone1: $fone1, ')
          ..write('fone2: $fone2, ')
          ..write('email: $email, ')
          ..write('tipoSindicato: $tipoSindicato, ')
          ..write('dataBase: $dataBase, ')
          ..write('pisoSalarial: $pisoSalarial, ')
          ..write('cnpj: $cnpj, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }
}

class $TributIcmsCustomCabsTable extends TributIcmsCustomCabs
    with TableInfo<$TributIcmsCustomCabsTable, TributIcmsCustomCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIcmsCustomCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, descricao, origemMercadoria];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_icms_custom_cab';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributIcmsCustomCab> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIcmsCustomCab map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIcmsCustomCab(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
    );
  }

  @override
  $TributIcmsCustomCabsTable createAlias(String alias) {
    return $TributIcmsCustomCabsTable(attachedDatabase, alias);
  }
}

class TributIcmsCustomCab extends DataClass
    implements Insertable<TributIcmsCustomCab> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  const TributIcmsCustomCab({this.id, this.descricao, this.origemMercadoria});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    return map;
  }

  factory TributIcmsCustomCab.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIcmsCustomCab(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
    };
  }

  TributIcmsCustomCab copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent()}) =>
      TributIcmsCustomCab(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
      );
  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCab(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIcmsCustomCab &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria);
}

class TributIcmsCustomCabsCompanion
    extends UpdateCompanion<TributIcmsCustomCab> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  const TributIcmsCustomCabsCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  TributIcmsCustomCabsCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  static Insertable<TributIcmsCustomCab> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
    });
  }

  TributIcmsCustomCabsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria}) {
    return TributIcmsCustomCabsCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCabsCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }
}

class $TributGrupoTributariosTable extends TributGrupoTributarios
    with TableInfo<$TributGrupoTributariosTable, TributGrupoTributario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributGrupoTributariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, origemMercadoria, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_grupo_tributario';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributGrupoTributario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributGrupoTributario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributGrupoTributario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $TributGrupoTributariosTable createAlias(String alias) {
    return $TributGrupoTributariosTable(attachedDatabase, alias);
  }
}

class TributGrupoTributario extends DataClass
    implements Insertable<TributGrupoTributario> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  final String? observacao;
  const TributGrupoTributario(
      {this.id, this.descricao, this.origemMercadoria, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory TributGrupoTributario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributGrupoTributario(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  TributGrupoTributario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      TributGrupoTributario(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('TributGrupoTributario(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributGrupoTributario &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria &&
          other.observacao == this.observacao);
}

class TributGrupoTributariosCompanion
    extends UpdateCompanion<TributGrupoTributario> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  final Value<String?> observacao;
  const TributGrupoTributariosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  TributGrupoTributariosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<TributGrupoTributario> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
      if (observacao != null) 'observacao': observacao,
    });
  }

  TributGrupoTributariosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria,
      Value<String?>? observacao}) {
    return TributGrupoTributariosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributGrupoTributariosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $PessoaFisicasTable pessoaFisicas = $PessoaFisicasTable(this);
  late final $PessoaJuridicasTable pessoaJuridicas =
      $PessoaJuridicasTable(this);
  late final $ClientesTable clientes = $ClientesTable(this);
  late final $FornecedorsTable fornecedors = $FornecedorsTable(this);
  late final $TransportadorasTable transportadoras =
      $TransportadorasTable(this);
  late final $ContadorsTable contadors = $ContadorsTable(this);
  late final $VendedorsTable vendedors = $VendedorsTable(this);
  late final $PessoaEnderecosTable pessoaEnderecos =
      $PessoaEnderecosTable(this);
  late final $PessoaContatosTable pessoaContatos = $PessoaContatosTable(this);
  late final $PessoaTelefonesTable pessoaTelefones =
      $PessoaTelefonesTable(this);
  late final $ColaboradorRelacionamentosTable colaboradorRelacionamentos =
      $ColaboradorRelacionamentosTable(this);
  late final $PapelFuncaosTable papelFuncaos = $PapelFuncaosTable(this);
  late final $UsuariosTable usuarios = $UsuariosTable(this);
  late final $PessoasTable pessoas = $PessoasTable(this);
  late final $ColaboradorsTable colaboradors = $ColaboradorsTable(this);
  late final $PapelsTable papels = $PapelsTable(this);
  late final $FuncaosTable funcaos = $FuncaosTable(this);
  late final $EstadoCivilsTable estadoCivils = $EstadoCivilsTable(this);
  late final $CargosTable cargos = $CargosTable(this);
  late final $SetorsTable setors = $SetorsTable(this);
  late final $ColaboradorSituacaosTable colaboradorSituacaos =
      $ColaboradorSituacaosTable(this);
  late final $TipoAdmissaosTable tipoAdmissaos = $TipoAdmissaosTable(this);
  late final $ColaboradorTiposTable colaboradorTipos =
      $ColaboradorTiposTable(this);
  late final $ProdutoGruposTable produtoGrupos = $ProdutoGruposTable(this);
  late final $ProdutoSubgruposTable produtoSubgrupos =
      $ProdutoSubgruposTable(this);
  late final $ProdutoMarcasTable produtoMarcas = $ProdutoMarcasTable(this);
  late final $ProdutoUnidadesTable produtoUnidades =
      $ProdutoUnidadesTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $BancosTable bancos = $BancosTable(this);
  late final $BancoAgenciasTable bancoAgencias = $BancoAgenciasTable(this);
  late final $BancoContaCaixasTable bancoContaCaixas =
      $BancoContaCaixasTable(this);
  late final $CepsTable ceps = $CepsTable(this);
  late final $UfsTable ufs = $UfsTable(this);
  late final $MunicipiosTable municipios = $MunicipiosTable(this);
  late final $NcmsTable ncms = $NcmsTable(this);
  late final $CfopsTable cfops = $CfopsTable(this);
  late final $CstIcmssTable cstIcmss = $CstIcmssTable(this);
  late final $CstIpisTable cstIpis = $CstIpisTable(this);
  late final $CstCofinssTable cstCofinss = $CstCofinssTable(this);
  late final $CstPissTable cstPiss = $CstPissTable(this);
  late final $CsosnsTable csosns = $CsosnsTable(this);
  late final $CnaesTable cnaes = $CnaesTable(this);
  late final $PaissTable paiss = $PaissTable(this);
  late final $NivelFormacaosTable nivelFormacaos = $NivelFormacaosTable(this);
  late final $TabelaPrecosTable tabelaPrecos = $TabelaPrecosTable(this);
  late final $TipoRelacionamentosTable tipoRelacionamentos =
      $TipoRelacionamentosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ComissaoPerfilsTable comissaoPerfils =
      $ComissaoPerfilsTable(this);
  late final $SindicatosTable sindicatos = $SindicatosTable(this);
  late final $TributIcmsCustomCabsTable tributIcmsCustomCabs =
      $TributIcmsCustomCabsTable(this);
  late final $TributGrupoTributariosTable tributGrupoTributarios =
      $TributGrupoTributariosTable(this);
  late final PessoaDao pessoaDao = PessoaDao(this as AppDatabase);
  late final ColaboradorDao colaboradorDao =
      ColaboradorDao(this as AppDatabase);
  late final PapelDao papelDao = PapelDao(this as AppDatabase);
  late final FuncaoDao funcaoDao = FuncaoDao(this as AppDatabase);
  late final EstadoCivilDao estadoCivilDao =
      EstadoCivilDao(this as AppDatabase);
  late final CargoDao cargoDao = CargoDao(this as AppDatabase);
  late final SetorDao setorDao = SetorDao(this as AppDatabase);
  late final ColaboradorSituacaoDao colaboradorSituacaoDao =
      ColaboradorSituacaoDao(this as AppDatabase);
  late final TipoAdmissaoDao tipoAdmissaoDao =
      TipoAdmissaoDao(this as AppDatabase);
  late final ColaboradorTipoDao colaboradorTipoDao =
      ColaboradorTipoDao(this as AppDatabase);
  late final ProdutoGrupoDao produtoGrupoDao =
      ProdutoGrupoDao(this as AppDatabase);
  late final ProdutoSubgrupoDao produtoSubgrupoDao =
      ProdutoSubgrupoDao(this as AppDatabase);
  late final ProdutoMarcaDao produtoMarcaDao =
      ProdutoMarcaDao(this as AppDatabase);
  late final ProdutoUnidadeDao produtoUnidadeDao =
      ProdutoUnidadeDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final BancoDao bancoDao = BancoDao(this as AppDatabase);
  late final BancoAgenciaDao bancoAgenciaDao =
      BancoAgenciaDao(this as AppDatabase);
  late final BancoContaCaixaDao bancoContaCaixaDao =
      BancoContaCaixaDao(this as AppDatabase);
  late final CepDao cepDao = CepDao(this as AppDatabase);
  late final UfDao ufDao = UfDao(this as AppDatabase);
  late final MunicipioDao municipioDao = MunicipioDao(this as AppDatabase);
  late final NcmDao ncmDao = NcmDao(this as AppDatabase);
  late final CfopDao cfopDao = CfopDao(this as AppDatabase);
  late final CstIcmsDao cstIcmsDao = CstIcmsDao(this as AppDatabase);
  late final CstIpiDao cstIpiDao = CstIpiDao(this as AppDatabase);
  late final CstCofinsDao cstCofinsDao = CstCofinsDao(this as AppDatabase);
  late final CstPisDao cstPisDao = CstPisDao(this as AppDatabase);
  late final CsosnDao csosnDao = CsosnDao(this as AppDatabase);
  late final CnaeDao cnaeDao = CnaeDao(this as AppDatabase);
  late final PaisDao paisDao = PaisDao(this as AppDatabase);
  late final NivelFormacaoDao nivelFormacaoDao =
      NivelFormacaoDao(this as AppDatabase);
  late final TabelaPrecoDao tabelaPrecoDao =
      TabelaPrecoDao(this as AppDatabase);
  late final TipoRelacionamentoDao tipoRelacionamentoDao =
      TipoRelacionamentoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ComissaoPerfilDao comissaoPerfilDao =
      ComissaoPerfilDao(this as AppDatabase);
  late final SindicatoDao sindicatoDao = SindicatoDao(this as AppDatabase);
  late final TributIcmsCustomCabDao tributIcmsCustomCabDao =
      TributIcmsCustomCabDao(this as AppDatabase);
  late final TributGrupoTributarioDao tributGrupoTributarioDao =
      TributGrupoTributarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        pessoaFisicas,
        pessoaJuridicas,
        clientes,
        fornecedors,
        transportadoras,
        contadors,
        vendedors,
        pessoaEnderecos,
        pessoaContatos,
        pessoaTelefones,
        colaboradorRelacionamentos,
        papelFuncaos,
        usuarios,
        pessoas,
        colaboradors,
        papels,
        funcaos,
        estadoCivils,
        cargos,
        setors,
        colaboradorSituacaos,
        tipoAdmissaos,
        colaboradorTipos,
        produtoGrupos,
        produtoSubgrupos,
        produtoMarcas,
        produtoUnidades,
        produtos,
        bancos,
        bancoAgencias,
        bancoContaCaixas,
        ceps,
        ufs,
        municipios,
        ncms,
        cfops,
        cstIcmss,
        cstIpis,
        cstCofinss,
        cstPiss,
        csosns,
        cnaes,
        paiss,
        nivelFormacaos,
        tabelaPrecos,
        tipoRelacionamentos,
        viewControleAcessos,
        viewPessoaUsuarios,
        comissaoPerfils,
        sindicatos,
        tributIcmsCustomCabs,
        tributGrupoTributarios
      ];
}
