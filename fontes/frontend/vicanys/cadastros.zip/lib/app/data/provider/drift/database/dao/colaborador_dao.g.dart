// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'colaborador_dao.dart';

// ignore_for_file: type=lint
mixin _$ColaboradorDaoMixin on DatabaseAccessor<AppDatabase> {
  $ColaboradorsTable get colaboradors => attachedDatabase.colaboradors;
  $VendedorsTable get vendedors => attachedDatabase.vendedors;
  $ComissaoPerfilsTable get comissaoPerfils => attachedDatabase.comissaoPerfils;
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $ColaboradorSituacaosTable get colaboradorSituacaos =>
      attachedDatabase.colaboradorSituacaos;
  $ColaboradorTiposTable get colaboradorTipos =>
      attachedDatabase.colaboradorTipos;
  $SetorsTable get setors => attachedDatabase.setors;
  $CargosTable get cargos => attachedDatabase.cargos;
  $TipoAdmissaosTable get tipoAdmissaos => attachedDatabase.tipoAdmissaos;
  $ColaboradorRelacionamentosTable get colaboradorRelacionamentos =>
      attachedDatabase.colaboradorRelacionamentos;
  $TipoRelacionamentosTable get tipoRelacionamentos =>
      attachedDatabase.tipoRelacionamentos;
  $SindicatosTable get sindicatos => attachedDatabase.sindicatos;
}
