// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'colaborador_situacao_dao.dart';

// ignore_for_file: type=lint
mixin _$ColaboradorSituacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ColaboradorSituacaosTable get colaboradorSituacaos =>
      attachedDatabase.colaboradorSituacaos;
}
