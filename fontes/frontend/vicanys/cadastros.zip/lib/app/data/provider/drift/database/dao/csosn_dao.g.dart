// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'csosn_dao.dart';

// ignore_for_file: type=lint
mixin _$CsosnDaoMixin on DatabaseAccessor<AppDatabase> {
  $CsosnsTable get csosns => attachedDatabase.csosns;
}
