// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tribut_icms_custom_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$TributIcmsCustomCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $TributIcmsCustomCabsTable get tributIcmsCustomCabs =>
      attachedDatabase.tributIcmsCustomCabs;
}
