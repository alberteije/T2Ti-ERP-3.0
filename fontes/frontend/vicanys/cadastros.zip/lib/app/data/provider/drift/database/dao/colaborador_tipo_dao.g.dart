// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'colaborador_tipo_dao.dart';

// ignore_for_file: type=lint
mixin _$ColaboradorTipoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ColaboradorTiposTable get colaboradorTipos =>
      attachedDatabase.colaboradorTipos;
}
