// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tipo_admissao_dao.dart';

// ignore_for_file: type=lint
mixin _$TipoAdmissaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $TipoAdmissaosTable get tipoAdmissaos => attachedDatabase.tipoAdmissaos;
}
