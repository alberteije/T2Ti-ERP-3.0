// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pais_dao.dart';

// ignore_for_file: type=lint
mixin _$PaisDaoMixin on DatabaseAccessor<AppDatabase> {
  $PaissTable get paiss => attachedDatabase.paiss;
}
