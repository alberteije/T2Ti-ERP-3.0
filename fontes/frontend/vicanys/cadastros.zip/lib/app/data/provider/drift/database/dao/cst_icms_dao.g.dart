// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cst_icms_dao.dart';

// ignore_for_file: type=lint
mixin _$CstIcmsDaoMixin on DatabaseAccessor<AppDatabase> {
  $CstIcmssTable get cstIcmss => attachedDatabase.cstIcmss;
}
