// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estado_civil_dao.dart';

// ignore_for_file: type=lint
mixin _$EstadoCivilDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstadoCivilsTable get estadoCivils => attachedDatabase.estadoCivils;
}
