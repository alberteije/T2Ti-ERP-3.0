abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const frotaVeiculoListPage = '/frotaVeiculoListPage'; 
	static const frotaVeiculoTabPage = '/frotaVeiculoTabPage';
	static const frotaVeiculoTipoListPage = '/frotaVeiculoTipoListPage'; 
	static const frotaVeiculoTipoEditPage = '/frotaVeiculoTipoEditPage';
	static const frotaCombustivelTipoListPage = '/frotaCombustivelTipoListPage'; 
	static const frotaCombustivelTipoEditPage = '/frotaCombustivelTipoEditPage';
	static const frotaMotoristaListPage = '/frotaMotoristaListPage'; 
	static const frotaMotoristaEditPage = '/frotaMotoristaEditPage';
}