// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'frota_veiculo_tipo_dao.dart';

// ignore_for_file: type=lint
mixin _$FrotaVeiculoTipoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FrotaVeiculoTiposTable get frotaVeiculoTipos =>
      attachedDatabase.frotaVeiculoTipos;
}
