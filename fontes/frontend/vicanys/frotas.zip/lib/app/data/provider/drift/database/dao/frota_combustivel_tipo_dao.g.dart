// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'frota_combustivel_tipo_dao.dart';

// ignore_for_file: type=lint
mixin _$FrotaCombustivelTipoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FrotaCombustivelTiposTable get frotaCombustivelTipos =>
      attachedDatabase.frotaCombustivelTipos;
}
