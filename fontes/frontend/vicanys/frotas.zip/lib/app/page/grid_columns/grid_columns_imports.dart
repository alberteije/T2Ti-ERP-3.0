
export 'frota_ipva_controle_grid_columns.dart';
export 'frota_dpvat_controle_grid_columns.dart';
export 'frota_veiculo_sinistro_grid_columns.dart';
export 'frota_veiculo_movimentacao_grid_columns.dart';
export 'frota_veiculo_pneu_grid_columns.dart';
export 'frota_veiculo_manutencao_grid_columns.dart';
export 'frota_multa_controle_grid_columns.dart';
export 'frota_combustivel_controle_grid_columns.dart';
export 'frota_veiculo_grid_columns.dart';
export 'frota_veiculo_tipo_grid_columns.dart';
export 'frota_combustivel_tipo_grid_columns.dart';
export 'frota_motorista_grid_columns.dart';
export 'view_controle_acesso_grid_columns.dart';
export 'view_pessoa_usuario_grid_columns.dart';
export 'view_pessoa_colaborador_grid_columns.dart';