// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_parametro_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaParametroDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaParametrosTable get folhaParametros => attachedDatabase.folhaParametros;
}
