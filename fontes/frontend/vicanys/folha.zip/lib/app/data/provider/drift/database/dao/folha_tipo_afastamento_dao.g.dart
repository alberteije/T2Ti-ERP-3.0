// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_tipo_afastamento_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaTipoAfastamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaTipoAfastamentosTable get folhaTipoAfastamentos =>
      attachedDatabase.folhaTipoAfastamentos;
}
