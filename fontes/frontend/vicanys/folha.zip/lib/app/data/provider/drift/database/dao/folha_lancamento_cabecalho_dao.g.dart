// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_lancamento_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaLancamentoCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaLancamentoCabecalhosTable get folhaLancamentoCabecalhos =>
      attachedDatabase.folhaLancamentoCabecalhos;
  $FolhaLancamentoDetalhesTable get folhaLancamentoDetalhes =>
      attachedDatabase.folhaLancamentoDetalhes;
  $FolhaEventosTable get folhaEventos => attachedDatabase.folhaEventos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
