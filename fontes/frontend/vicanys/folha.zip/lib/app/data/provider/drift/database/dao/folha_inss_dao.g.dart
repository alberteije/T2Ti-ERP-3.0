// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_inss_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaInssDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaInsssTable get folhaInsss => attachedDatabase.folhaInsss;
  $FolhaInssRetencaosTable get folhaInssRetencaos =>
      attachedDatabase.folhaInssRetencaos;
  $FolhaInssServicosTable get folhaInssServicos =>
      attachedDatabase.folhaInssServicos;
}
