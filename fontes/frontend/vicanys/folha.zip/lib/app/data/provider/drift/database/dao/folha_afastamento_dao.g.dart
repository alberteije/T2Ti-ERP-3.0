// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_afastamento_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaAfastamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaAfastamentosTable get folhaAfastamentos =>
      attachedDatabase.folhaAfastamentos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $FolhaTipoAfastamentosTable get folhaTipoAfastamentos =>
      attachedDatabase.folhaTipoAfastamentos;
}
