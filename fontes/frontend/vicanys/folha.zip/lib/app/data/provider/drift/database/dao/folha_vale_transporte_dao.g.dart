// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_vale_transporte_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaValeTransporteDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaValeTransportesTable get folhaValeTransportes =>
      attachedDatabase.folhaValeTransportes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $EmpresaTransporteItinerariosTable get empresaTransporteItinerarios =>
      attachedDatabase.empresaTransporteItinerarios;
}
