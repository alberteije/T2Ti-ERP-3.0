// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feriados_dao.dart';

// ignore_for_file: type=lint
mixin _$FeriadosDaoMixin on DatabaseAccessor<AppDatabase> {
  $FeriadossTable get feriadoss => attachedDatabase.feriadoss;
}
