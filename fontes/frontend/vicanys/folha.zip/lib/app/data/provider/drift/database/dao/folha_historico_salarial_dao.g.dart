// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_historico_salarial_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaHistoricoSalarialDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaHistoricoSalarialsTable get folhaHistoricoSalarials =>
      attachedDatabase.folhaHistoricoSalarials;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
