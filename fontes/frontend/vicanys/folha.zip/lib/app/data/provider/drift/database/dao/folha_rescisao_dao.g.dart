// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_rescisao_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaRescisaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaRescisaosTable get folhaRescisaos => attachedDatabase.folhaRescisaos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
