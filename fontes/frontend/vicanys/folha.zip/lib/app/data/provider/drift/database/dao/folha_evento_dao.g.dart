// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_evento_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaEventoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaEventosTable get folhaEventos => attachedDatabase.folhaEventos;
}
