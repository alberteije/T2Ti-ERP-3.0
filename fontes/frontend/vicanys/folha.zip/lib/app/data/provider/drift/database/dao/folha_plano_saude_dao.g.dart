// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_plano_saude_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaPlanoSaudeDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaPlanoSaudesTable get folhaPlanoSaudes =>
      attachedDatabase.folhaPlanoSaudes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $OperadoraPlanoSaudesTable get operadoraPlanoSaudes =>
      attachedDatabase.operadoraPlanoSaudes;
}
