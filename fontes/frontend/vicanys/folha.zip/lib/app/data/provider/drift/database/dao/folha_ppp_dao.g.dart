// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'folha_ppp_dao.dart';

// ignore_for_file: type=lint
mixin _$FolhaPppDaoMixin on DatabaseAccessor<AppDatabase> {
  $FolhaPppsTable get folhaPpps => attachedDatabase.folhaPpps;
  $FolhaPppCatsTable get folhaPppCats => attachedDatabase.folhaPppCats;
  $FolhaPppAtividadesTable get folhaPppAtividades =>
      attachedDatabase.folhaPppAtividades;
  $FolhaPppFatorRiscosTable get folhaPppFatorRiscos =>
      attachedDatabase.folhaPppFatorRiscos;
  $FolhaPppExameMedicosTable get folhaPppExameMedicos =>
      attachedDatabase.folhaPppExameMedicos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
