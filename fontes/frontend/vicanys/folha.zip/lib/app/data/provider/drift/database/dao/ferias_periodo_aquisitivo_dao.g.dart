// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ferias_periodo_aquisitivo_dao.dart';

// ignore_for_file: type=lint
mixin _$FeriasPeriodoAquisitivoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FeriasPeriodoAquisitivosTable get feriasPeriodoAquisitivos =>
      attachedDatabase.feriasPeriodoAquisitivos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
