// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $EmpresaTransporteItinerariosTable extends EmpresaTransporteItinerarios
    with
        TableInfo<$EmpresaTransporteItinerariosTable,
            EmpresaTransporteItinerario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaTransporteItinerariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaTransporteMeta =
      const VerificationMeta('idEmpresaTransporte');
  @override
  late final GeneratedColumn<int> idEmpresaTransporte = GeneratedColumn<int>(
      'id_empresa_transporte', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tarifaMeta = const VerificationMeta('tarifa');
  @override
  late final GeneratedColumn<double> tarifa = GeneratedColumn<double>(
      'tarifa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _trajetoMeta =
      const VerificationMeta('trajeto');
  @override
  late final GeneratedColumn<String> trajeto = GeneratedColumn<String>(
      'trajeto', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idEmpresaTransporte, nome, tarifa, trajeto];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_transporte_itinerario';
  @override
  VerificationContext validateIntegrity(
      Insertable<EmpresaTransporteItinerario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_empresa_transporte')) {
      context.handle(
          _idEmpresaTransporteMeta,
          idEmpresaTransporte.isAcceptableOrUnknown(
              data['id_empresa_transporte']!, _idEmpresaTransporteMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tarifa')) {
      context.handle(_tarifaMeta,
          tarifa.isAcceptableOrUnknown(data['tarifa']!, _tarifaMeta));
    }
    if (data.containsKey('trajeto')) {
      context.handle(_trajetoMeta,
          trajeto.isAcceptableOrUnknown(data['trajeto']!, _trajetoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaTransporteItinerario map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaTransporteItinerario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEmpresaTransporte: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_empresa_transporte']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tarifa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tarifa']),
      trajeto: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}trajeto']),
    );
  }

  @override
  $EmpresaTransporteItinerariosTable createAlias(String alias) {
    return $EmpresaTransporteItinerariosTable(attachedDatabase, alias);
  }
}

class EmpresaTransporteItinerario extends DataClass
    implements Insertable<EmpresaTransporteItinerario> {
  final int? id;
  final int? idEmpresaTransporte;
  final String? nome;
  final double? tarifa;
  final String? trajeto;
  const EmpresaTransporteItinerario(
      {this.id,
      this.idEmpresaTransporte,
      this.nome,
      this.tarifa,
      this.trajeto});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEmpresaTransporte != null) {
      map['id_empresa_transporte'] = Variable<int>(idEmpresaTransporte);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tarifa != null) {
      map['tarifa'] = Variable<double>(tarifa);
    }
    if (!nullToAbsent || trajeto != null) {
      map['trajeto'] = Variable<String>(trajeto);
    }
    return map;
  }

  factory EmpresaTransporteItinerario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaTransporteItinerario(
      id: serializer.fromJson<int?>(json['id']),
      idEmpresaTransporte:
          serializer.fromJson<int?>(json['idEmpresaTransporte']),
      nome: serializer.fromJson<String?>(json['nome']),
      tarifa: serializer.fromJson<double?>(json['tarifa']),
      trajeto: serializer.fromJson<String?>(json['trajeto']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEmpresaTransporte': serializer.toJson<int?>(idEmpresaTransporte),
      'nome': serializer.toJson<String?>(nome),
      'tarifa': serializer.toJson<double?>(tarifa),
      'trajeto': serializer.toJson<String?>(trajeto),
    };
  }

  EmpresaTransporteItinerario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEmpresaTransporte = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<double?> tarifa = const Value.absent(),
          Value<String?> trajeto = const Value.absent()}) =>
      EmpresaTransporteItinerario(
        id: id.present ? id.value : this.id,
        idEmpresaTransporte: idEmpresaTransporte.present
            ? idEmpresaTransporte.value
            : this.idEmpresaTransporte,
        nome: nome.present ? nome.value : this.nome,
        tarifa: tarifa.present ? tarifa.value : this.tarifa,
        trajeto: trajeto.present ? trajeto.value : this.trajeto,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaTransporteItinerario(')
          ..write('id: $id, ')
          ..write('idEmpresaTransporte: $idEmpresaTransporte, ')
          ..write('nome: $nome, ')
          ..write('tarifa: $tarifa, ')
          ..write('trajeto: $trajeto')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idEmpresaTransporte, nome, tarifa, trajeto);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaTransporteItinerario &&
          other.id == this.id &&
          other.idEmpresaTransporte == this.idEmpresaTransporte &&
          other.nome == this.nome &&
          other.tarifa == this.tarifa &&
          other.trajeto == this.trajeto);
}

class EmpresaTransporteItinerariosCompanion
    extends UpdateCompanion<EmpresaTransporteItinerario> {
  final Value<int?> id;
  final Value<int?> idEmpresaTransporte;
  final Value<String?> nome;
  final Value<double?> tarifa;
  final Value<String?> trajeto;
  const EmpresaTransporteItinerariosCompanion({
    this.id = const Value.absent(),
    this.idEmpresaTransporte = const Value.absent(),
    this.nome = const Value.absent(),
    this.tarifa = const Value.absent(),
    this.trajeto = const Value.absent(),
  });
  EmpresaTransporteItinerariosCompanion.insert({
    this.id = const Value.absent(),
    this.idEmpresaTransporte = const Value.absent(),
    this.nome = const Value.absent(),
    this.tarifa = const Value.absent(),
    this.trajeto = const Value.absent(),
  });
  static Insertable<EmpresaTransporteItinerario> custom({
    Expression<int>? id,
    Expression<int>? idEmpresaTransporte,
    Expression<String>? nome,
    Expression<double>? tarifa,
    Expression<String>? trajeto,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEmpresaTransporte != null)
        'id_empresa_transporte': idEmpresaTransporte,
      if (nome != null) 'nome': nome,
      if (tarifa != null) 'tarifa': tarifa,
      if (trajeto != null) 'trajeto': trajeto,
    });
  }

  EmpresaTransporteItinerariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEmpresaTransporte,
      Value<String?>? nome,
      Value<double?>? tarifa,
      Value<String?>? trajeto}) {
    return EmpresaTransporteItinerariosCompanion(
      id: id ?? this.id,
      idEmpresaTransporte: idEmpresaTransporte ?? this.idEmpresaTransporte,
      nome: nome ?? this.nome,
      tarifa: tarifa ?? this.tarifa,
      trajeto: trajeto ?? this.trajeto,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEmpresaTransporte.present) {
      map['id_empresa_transporte'] = Variable<int>(idEmpresaTransporte.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tarifa.present) {
      map['tarifa'] = Variable<double>(tarifa.value);
    }
    if (trajeto.present) {
      map['trajeto'] = Variable<String>(trajeto.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaTransporteItinerariosCompanion(')
          ..write('id: $id, ')
          ..write('idEmpresaTransporte: $idEmpresaTransporte, ')
          ..write('nome: $nome, ')
          ..write('tarifa: $tarifa, ')
          ..write('trajeto: $trajeto')
          ..write(')'))
        .toString();
  }
}

class $FolhaLancamentoDetalhesTable extends FolhaLancamentoDetalhes
    with TableInfo<$FolhaLancamentoDetalhesTable, FolhaLancamentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaLancamentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaLancamentoCabecalhoMeta =
      const VerificationMeta('idFolhaLancamentoCabecalho');
  @override
  late final GeneratedColumn<int> idFolhaLancamentoCabecalho =
      GeneratedColumn<int>('id_folha_lancamento_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaEventoMeta =
      const VerificationMeta('idFolhaEvento');
  @override
  late final GeneratedColumn<int> idFolhaEvento = GeneratedColumn<int>(
      'id_folha_evento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _origemMeta = const VerificationMeta('origem');
  @override
  late final GeneratedColumn<double> origem = GeneratedColumn<double>(
      'origem', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _proventoMeta =
      const VerificationMeta('provento');
  @override
  late final GeneratedColumn<double> provento = GeneratedColumn<double>(
      'provento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _descontoMeta =
      const VerificationMeta('desconto');
  @override
  late final GeneratedColumn<double> desconto = GeneratedColumn<double>(
      'desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFolhaLancamentoCabecalho,
        idFolhaEvento,
        origem,
        provento,
        desconto
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_lancamento_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaLancamentoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_lancamento_cabecalho')) {
      context.handle(
          _idFolhaLancamentoCabecalhoMeta,
          idFolhaLancamentoCabecalho.isAcceptableOrUnknown(
              data['id_folha_lancamento_cabecalho']!,
              _idFolhaLancamentoCabecalhoMeta));
    }
    if (data.containsKey('id_folha_evento')) {
      context.handle(
          _idFolhaEventoMeta,
          idFolhaEvento.isAcceptableOrUnknown(
              data['id_folha_evento']!, _idFolhaEventoMeta));
    }
    if (data.containsKey('origem')) {
      context.handle(_origemMeta,
          origem.isAcceptableOrUnknown(data['origem']!, _origemMeta));
    }
    if (data.containsKey('provento')) {
      context.handle(_proventoMeta,
          provento.isAcceptableOrUnknown(data['provento']!, _proventoMeta));
    }
    if (data.containsKey('desconto')) {
      context.handle(_descontoMeta,
          desconto.isAcceptableOrUnknown(data['desconto']!, _descontoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaLancamentoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaLancamentoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaLancamentoCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_folha_lancamento_cabecalho']),
      idFolhaEvento: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_evento']),
      origem: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}origem']),
      provento: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}provento']),
      desconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}desconto']),
    );
  }

  @override
  $FolhaLancamentoDetalhesTable createAlias(String alias) {
    return $FolhaLancamentoDetalhesTable(attachedDatabase, alias);
  }
}

class FolhaLancamentoDetalhe extends DataClass
    implements Insertable<FolhaLancamentoDetalhe> {
  final int? id;
  final int? idFolhaLancamentoCabecalho;
  final int? idFolhaEvento;
  final double? origem;
  final double? provento;
  final double? desconto;
  const FolhaLancamentoDetalhe(
      {this.id,
      this.idFolhaLancamentoCabecalho,
      this.idFolhaEvento,
      this.origem,
      this.provento,
      this.desconto});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaLancamentoCabecalho != null) {
      map['id_folha_lancamento_cabecalho'] =
          Variable<int>(idFolhaLancamentoCabecalho);
    }
    if (!nullToAbsent || idFolhaEvento != null) {
      map['id_folha_evento'] = Variable<int>(idFolhaEvento);
    }
    if (!nullToAbsent || origem != null) {
      map['origem'] = Variable<double>(origem);
    }
    if (!nullToAbsent || provento != null) {
      map['provento'] = Variable<double>(provento);
    }
    if (!nullToAbsent || desconto != null) {
      map['desconto'] = Variable<double>(desconto);
    }
    return map;
  }

  factory FolhaLancamentoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaLancamentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaLancamentoCabecalho:
          serializer.fromJson<int?>(json['idFolhaLancamentoCabecalho']),
      idFolhaEvento: serializer.fromJson<int?>(json['idFolhaEvento']),
      origem: serializer.fromJson<double?>(json['origem']),
      provento: serializer.fromJson<double?>(json['provento']),
      desconto: serializer.fromJson<double?>(json['desconto']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaLancamentoCabecalho':
          serializer.toJson<int?>(idFolhaLancamentoCabecalho),
      'idFolhaEvento': serializer.toJson<int?>(idFolhaEvento),
      'origem': serializer.toJson<double?>(origem),
      'provento': serializer.toJson<double?>(provento),
      'desconto': serializer.toJson<double?>(desconto),
    };
  }

  FolhaLancamentoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaLancamentoCabecalho = const Value.absent(),
          Value<int?> idFolhaEvento = const Value.absent(),
          Value<double?> origem = const Value.absent(),
          Value<double?> provento = const Value.absent(),
          Value<double?> desconto = const Value.absent()}) =>
      FolhaLancamentoDetalhe(
        id: id.present ? id.value : this.id,
        idFolhaLancamentoCabecalho: idFolhaLancamentoCabecalho.present
            ? idFolhaLancamentoCabecalho.value
            : this.idFolhaLancamentoCabecalho,
        idFolhaEvento:
            idFolhaEvento.present ? idFolhaEvento.value : this.idFolhaEvento,
        origem: origem.present ? origem.value : this.origem,
        provento: provento.present ? provento.value : this.provento,
        desconto: desconto.present ? desconto.value : this.desconto,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoDetalhe(')
          ..write('id: $id, ')
          ..write('idFolhaLancamentoCabecalho: $idFolhaLancamentoCabecalho, ')
          ..write('idFolhaEvento: $idFolhaEvento, ')
          ..write('origem: $origem, ')
          ..write('provento: $provento, ')
          ..write('desconto: $desconto')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idFolhaLancamentoCabecalho, idFolhaEvento,
      origem, provento, desconto);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaLancamentoDetalhe &&
          other.id == this.id &&
          other.idFolhaLancamentoCabecalho == this.idFolhaLancamentoCabecalho &&
          other.idFolhaEvento == this.idFolhaEvento &&
          other.origem == this.origem &&
          other.provento == this.provento &&
          other.desconto == this.desconto);
}

class FolhaLancamentoDetalhesCompanion
    extends UpdateCompanion<FolhaLancamentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idFolhaLancamentoCabecalho;
  final Value<int?> idFolhaEvento;
  final Value<double?> origem;
  final Value<double?> provento;
  final Value<double?> desconto;
  const FolhaLancamentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idFolhaLancamentoCabecalho = const Value.absent(),
    this.idFolhaEvento = const Value.absent(),
    this.origem = const Value.absent(),
    this.provento = const Value.absent(),
    this.desconto = const Value.absent(),
  });
  FolhaLancamentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaLancamentoCabecalho = const Value.absent(),
    this.idFolhaEvento = const Value.absent(),
    this.origem = const Value.absent(),
    this.provento = const Value.absent(),
    this.desconto = const Value.absent(),
  });
  static Insertable<FolhaLancamentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idFolhaLancamentoCabecalho,
    Expression<int>? idFolhaEvento,
    Expression<double>? origem,
    Expression<double>? provento,
    Expression<double>? desconto,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaLancamentoCabecalho != null)
        'id_folha_lancamento_cabecalho': idFolhaLancamentoCabecalho,
      if (idFolhaEvento != null) 'id_folha_evento': idFolhaEvento,
      if (origem != null) 'origem': origem,
      if (provento != null) 'provento': provento,
      if (desconto != null) 'desconto': desconto,
    });
  }

  FolhaLancamentoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaLancamentoCabecalho,
      Value<int?>? idFolhaEvento,
      Value<double?>? origem,
      Value<double?>? provento,
      Value<double?>? desconto}) {
    return FolhaLancamentoDetalhesCompanion(
      id: id ?? this.id,
      idFolhaLancamentoCabecalho:
          idFolhaLancamentoCabecalho ?? this.idFolhaLancamentoCabecalho,
      idFolhaEvento: idFolhaEvento ?? this.idFolhaEvento,
      origem: origem ?? this.origem,
      provento: provento ?? this.provento,
      desconto: desconto ?? this.desconto,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaLancamentoCabecalho.present) {
      map['id_folha_lancamento_cabecalho'] =
          Variable<int>(idFolhaLancamentoCabecalho.value);
    }
    if (idFolhaEvento.present) {
      map['id_folha_evento'] = Variable<int>(idFolhaEvento.value);
    }
    if (origem.present) {
      map['origem'] = Variable<double>(origem.value);
    }
    if (provento.present) {
      map['provento'] = Variable<double>(provento.value);
    }
    if (desconto.present) {
      map['desconto'] = Variable<double>(desconto.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaLancamentoCabecalho: $idFolhaLancamentoCabecalho, ')
          ..write('idFolhaEvento: $idFolhaEvento, ')
          ..write('origem: $origem, ')
          ..write('provento: $provento, ')
          ..write('desconto: $desconto')
          ..write(')'))
        .toString();
  }
}

class $FolhaInssRetencaosTable extends FolhaInssRetencaos
    with TableInfo<$FolhaInssRetencaosTable, FolhaInssRetencao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaInssRetencaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaInssMeta =
      const VerificationMeta('idFolhaInss');
  @override
  late final GeneratedColumn<int> idFolhaInss = GeneratedColumn<int>(
      'id_folha_inss', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaInssServicoMeta =
      const VerificationMeta('idFolhaInssServico');
  @override
  late final GeneratedColumn<int> idFolhaInssServico = GeneratedColumn<int>(
      'id_folha_inss_servico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorMensalMeta =
      const VerificationMeta('valorMensal');
  @override
  late final GeneratedColumn<double> valorMensal = GeneratedColumn<double>(
      'valor_mensal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valor13Meta =
      const VerificationMeta('valor13');
  @override
  late final GeneratedColumn<double> valor13 = GeneratedColumn<double>(
      'valor_13', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFolhaInss, idFolhaInssServico, valorMensal, valor13];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_inss_retencao';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaInssRetencao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_inss')) {
      context.handle(
          _idFolhaInssMeta,
          idFolhaInss.isAcceptableOrUnknown(
              data['id_folha_inss']!, _idFolhaInssMeta));
    }
    if (data.containsKey('id_folha_inss_servico')) {
      context.handle(
          _idFolhaInssServicoMeta,
          idFolhaInssServico.isAcceptableOrUnknown(
              data['id_folha_inss_servico']!, _idFolhaInssServicoMeta));
    }
    if (data.containsKey('valor_mensal')) {
      context.handle(
          _valorMensalMeta,
          valorMensal.isAcceptableOrUnknown(
              data['valor_mensal']!, _valorMensalMeta));
    }
    if (data.containsKey('valor_13')) {
      context.handle(_valor13Meta,
          valor13.isAcceptableOrUnknown(data['valor_13']!, _valor13Meta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaInssRetencao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaInssRetencao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaInss: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_inss']),
      idFolhaInssServico: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_folha_inss_servico']),
      valorMensal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_mensal']),
      valor13: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_13']),
    );
  }

  @override
  $FolhaInssRetencaosTable createAlias(String alias) {
    return $FolhaInssRetencaosTable(attachedDatabase, alias);
  }
}

class FolhaInssRetencao extends DataClass
    implements Insertable<FolhaInssRetencao> {
  final int? id;
  final int? idFolhaInss;
  final int? idFolhaInssServico;
  final double? valorMensal;
  final double? valor13;
  const FolhaInssRetencao(
      {this.id,
      this.idFolhaInss,
      this.idFolhaInssServico,
      this.valorMensal,
      this.valor13});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaInss != null) {
      map['id_folha_inss'] = Variable<int>(idFolhaInss);
    }
    if (!nullToAbsent || idFolhaInssServico != null) {
      map['id_folha_inss_servico'] = Variable<int>(idFolhaInssServico);
    }
    if (!nullToAbsent || valorMensal != null) {
      map['valor_mensal'] = Variable<double>(valorMensal);
    }
    if (!nullToAbsent || valor13 != null) {
      map['valor_13'] = Variable<double>(valor13);
    }
    return map;
  }

  factory FolhaInssRetencao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaInssRetencao(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaInss: serializer.fromJson<int?>(json['idFolhaInss']),
      idFolhaInssServico: serializer.fromJson<int?>(json['idFolhaInssServico']),
      valorMensal: serializer.fromJson<double?>(json['valorMensal']),
      valor13: serializer.fromJson<double?>(json['valor13']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaInss': serializer.toJson<int?>(idFolhaInss),
      'idFolhaInssServico': serializer.toJson<int?>(idFolhaInssServico),
      'valorMensal': serializer.toJson<double?>(valorMensal),
      'valor13': serializer.toJson<double?>(valor13),
    };
  }

  FolhaInssRetencao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaInss = const Value.absent(),
          Value<int?> idFolhaInssServico = const Value.absent(),
          Value<double?> valorMensal = const Value.absent(),
          Value<double?> valor13 = const Value.absent()}) =>
      FolhaInssRetencao(
        id: id.present ? id.value : this.id,
        idFolhaInss: idFolhaInss.present ? idFolhaInss.value : this.idFolhaInss,
        idFolhaInssServico: idFolhaInssServico.present
            ? idFolhaInssServico.value
            : this.idFolhaInssServico,
        valorMensal: valorMensal.present ? valorMensal.value : this.valorMensal,
        valor13: valor13.present ? valor13.value : this.valor13,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaInssRetencao(')
          ..write('id: $id, ')
          ..write('idFolhaInss: $idFolhaInss, ')
          ..write('idFolhaInssServico: $idFolhaInssServico, ')
          ..write('valorMensal: $valorMensal, ')
          ..write('valor13: $valor13')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idFolhaInss, idFolhaInssServico, valorMensal, valor13);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaInssRetencao &&
          other.id == this.id &&
          other.idFolhaInss == this.idFolhaInss &&
          other.idFolhaInssServico == this.idFolhaInssServico &&
          other.valorMensal == this.valorMensal &&
          other.valor13 == this.valor13);
}

class FolhaInssRetencaosCompanion extends UpdateCompanion<FolhaInssRetencao> {
  final Value<int?> id;
  final Value<int?> idFolhaInss;
  final Value<int?> idFolhaInssServico;
  final Value<double?> valorMensal;
  final Value<double?> valor13;
  const FolhaInssRetencaosCompanion({
    this.id = const Value.absent(),
    this.idFolhaInss = const Value.absent(),
    this.idFolhaInssServico = const Value.absent(),
    this.valorMensal = const Value.absent(),
    this.valor13 = const Value.absent(),
  });
  FolhaInssRetencaosCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaInss = const Value.absent(),
    this.idFolhaInssServico = const Value.absent(),
    this.valorMensal = const Value.absent(),
    this.valor13 = const Value.absent(),
  });
  static Insertable<FolhaInssRetencao> custom({
    Expression<int>? id,
    Expression<int>? idFolhaInss,
    Expression<int>? idFolhaInssServico,
    Expression<double>? valorMensal,
    Expression<double>? valor13,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaInss != null) 'id_folha_inss': idFolhaInss,
      if (idFolhaInssServico != null)
        'id_folha_inss_servico': idFolhaInssServico,
      if (valorMensal != null) 'valor_mensal': valorMensal,
      if (valor13 != null) 'valor_13': valor13,
    });
  }

  FolhaInssRetencaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaInss,
      Value<int?>? idFolhaInssServico,
      Value<double?>? valorMensal,
      Value<double?>? valor13}) {
    return FolhaInssRetencaosCompanion(
      id: id ?? this.id,
      idFolhaInss: idFolhaInss ?? this.idFolhaInss,
      idFolhaInssServico: idFolhaInssServico ?? this.idFolhaInssServico,
      valorMensal: valorMensal ?? this.valorMensal,
      valor13: valor13 ?? this.valor13,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaInss.present) {
      map['id_folha_inss'] = Variable<int>(idFolhaInss.value);
    }
    if (idFolhaInssServico.present) {
      map['id_folha_inss_servico'] = Variable<int>(idFolhaInssServico.value);
    }
    if (valorMensal.present) {
      map['valor_mensal'] = Variable<double>(valorMensal.value);
    }
    if (valor13.present) {
      map['valor_13'] = Variable<double>(valor13.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaInssRetencaosCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaInss: $idFolhaInss, ')
          ..write('idFolhaInssServico: $idFolhaInssServico, ')
          ..write('valorMensal: $valorMensal, ')
          ..write('valor13: $valor13')
          ..write(')'))
        .toString();
  }
}

class $FolhaPppCatsTable extends FolhaPppCats
    with TableInfo<$FolhaPppCatsTable, FolhaPppCat> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPppCatsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaPppMeta =
      const VerificationMeta('idFolhaPpp');
  @override
  late final GeneratedColumn<int> idFolhaPpp = GeneratedColumn<int>(
      'id_folha_ppp', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroCatMeta =
      const VerificationMeta('numeroCat');
  @override
  late final GeneratedColumn<int> numeroCat = GeneratedColumn<int>(
      'numero_cat', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataAfastamentoMeta =
      const VerificationMeta('dataAfastamento');
  @override
  late final GeneratedColumn<DateTime> dataAfastamento =
      GeneratedColumn<DateTime>('data_afastamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataRegistroMeta =
      const VerificationMeta('dataRegistro');
  @override
  late final GeneratedColumn<DateTime> dataRegistro = GeneratedColumn<DateTime>(
      'data_registro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFolhaPpp, numeroCat, dataAfastamento, dataRegistro];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ppp_cat';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaPppCat> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_ppp')) {
      context.handle(
          _idFolhaPppMeta,
          idFolhaPpp.isAcceptableOrUnknown(
              data['id_folha_ppp']!, _idFolhaPppMeta));
    }
    if (data.containsKey('numero_cat')) {
      context.handle(_numeroCatMeta,
          numeroCat.isAcceptableOrUnknown(data['numero_cat']!, _numeroCatMeta));
    }
    if (data.containsKey('data_afastamento')) {
      context.handle(
          _dataAfastamentoMeta,
          dataAfastamento.isAcceptableOrUnknown(
              data['data_afastamento']!, _dataAfastamentoMeta));
    }
    if (data.containsKey('data_registro')) {
      context.handle(
          _dataRegistroMeta,
          dataRegistro.isAcceptableOrUnknown(
              data['data_registro']!, _dataRegistroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPppCat map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPppCat(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaPpp: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_ppp']),
      numeroCat: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_cat']),
      dataAfastamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_afastamento']),
      dataRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_registro']),
    );
  }

  @override
  $FolhaPppCatsTable createAlias(String alias) {
    return $FolhaPppCatsTable(attachedDatabase, alias);
  }
}

class FolhaPppCat extends DataClass implements Insertable<FolhaPppCat> {
  final int? id;
  final int? idFolhaPpp;
  final int? numeroCat;
  final DateTime? dataAfastamento;
  final DateTime? dataRegistro;
  const FolhaPppCat(
      {this.id,
      this.idFolhaPpp,
      this.numeroCat,
      this.dataAfastamento,
      this.dataRegistro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaPpp != null) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp);
    }
    if (!nullToAbsent || numeroCat != null) {
      map['numero_cat'] = Variable<int>(numeroCat);
    }
    if (!nullToAbsent || dataAfastamento != null) {
      map['data_afastamento'] = Variable<DateTime>(dataAfastamento);
    }
    if (!nullToAbsent || dataRegistro != null) {
      map['data_registro'] = Variable<DateTime>(dataRegistro);
    }
    return map;
  }

  factory FolhaPppCat.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPppCat(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaPpp: serializer.fromJson<int?>(json['idFolhaPpp']),
      numeroCat: serializer.fromJson<int?>(json['numeroCat']),
      dataAfastamento: serializer.fromJson<DateTime?>(json['dataAfastamento']),
      dataRegistro: serializer.fromJson<DateTime?>(json['dataRegistro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaPpp': serializer.toJson<int?>(idFolhaPpp),
      'numeroCat': serializer.toJson<int?>(numeroCat),
      'dataAfastamento': serializer.toJson<DateTime?>(dataAfastamento),
      'dataRegistro': serializer.toJson<DateTime?>(dataRegistro),
    };
  }

  FolhaPppCat copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaPpp = const Value.absent(),
          Value<int?> numeroCat = const Value.absent(),
          Value<DateTime?> dataAfastamento = const Value.absent(),
          Value<DateTime?> dataRegistro = const Value.absent()}) =>
      FolhaPppCat(
        id: id.present ? id.value : this.id,
        idFolhaPpp: idFolhaPpp.present ? idFolhaPpp.value : this.idFolhaPpp,
        numeroCat: numeroCat.present ? numeroCat.value : this.numeroCat,
        dataAfastamento: dataAfastamento.present
            ? dataAfastamento.value
            : this.dataAfastamento,
        dataRegistro:
            dataRegistro.present ? dataRegistro.value : this.dataRegistro,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPppCat(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('numeroCat: $numeroCat, ')
          ..write('dataAfastamento: $dataAfastamento, ')
          ..write('dataRegistro: $dataRegistro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idFolhaPpp, numeroCat, dataAfastamento, dataRegistro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPppCat &&
          other.id == this.id &&
          other.idFolhaPpp == this.idFolhaPpp &&
          other.numeroCat == this.numeroCat &&
          other.dataAfastamento == this.dataAfastamento &&
          other.dataRegistro == this.dataRegistro);
}

class FolhaPppCatsCompanion extends UpdateCompanion<FolhaPppCat> {
  final Value<int?> id;
  final Value<int?> idFolhaPpp;
  final Value<int?> numeroCat;
  final Value<DateTime?> dataAfastamento;
  final Value<DateTime?> dataRegistro;
  const FolhaPppCatsCompanion({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.numeroCat = const Value.absent(),
    this.dataAfastamento = const Value.absent(),
    this.dataRegistro = const Value.absent(),
  });
  FolhaPppCatsCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.numeroCat = const Value.absent(),
    this.dataAfastamento = const Value.absent(),
    this.dataRegistro = const Value.absent(),
  });
  static Insertable<FolhaPppCat> custom({
    Expression<int>? id,
    Expression<int>? idFolhaPpp,
    Expression<int>? numeroCat,
    Expression<DateTime>? dataAfastamento,
    Expression<DateTime>? dataRegistro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaPpp != null) 'id_folha_ppp': idFolhaPpp,
      if (numeroCat != null) 'numero_cat': numeroCat,
      if (dataAfastamento != null) 'data_afastamento': dataAfastamento,
      if (dataRegistro != null) 'data_registro': dataRegistro,
    });
  }

  FolhaPppCatsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaPpp,
      Value<int?>? numeroCat,
      Value<DateTime?>? dataAfastamento,
      Value<DateTime?>? dataRegistro}) {
    return FolhaPppCatsCompanion(
      id: id ?? this.id,
      idFolhaPpp: idFolhaPpp ?? this.idFolhaPpp,
      numeroCat: numeroCat ?? this.numeroCat,
      dataAfastamento: dataAfastamento ?? this.dataAfastamento,
      dataRegistro: dataRegistro ?? this.dataRegistro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaPpp.present) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp.value);
    }
    if (numeroCat.present) {
      map['numero_cat'] = Variable<int>(numeroCat.value);
    }
    if (dataAfastamento.present) {
      map['data_afastamento'] = Variable<DateTime>(dataAfastamento.value);
    }
    if (dataRegistro.present) {
      map['data_registro'] = Variable<DateTime>(dataRegistro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPppCatsCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('numeroCat: $numeroCat, ')
          ..write('dataAfastamento: $dataAfastamento, ')
          ..write('dataRegistro: $dataRegistro')
          ..write(')'))
        .toString();
  }
}

class $FolhaPppAtividadesTable extends FolhaPppAtividades
    with TableInfo<$FolhaPppAtividadesTable, FolhaPppAtividade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPppAtividadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaPppMeta =
      const VerificationMeta('idFolhaPpp');
  @override
  late final GeneratedColumn<int> idFolhaPpp = GeneratedColumn<int>(
      'id_folha_ppp', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFolhaPpp, dataInicio, dataFim, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ppp_atividade';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaPppAtividade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_ppp')) {
      context.handle(
          _idFolhaPppMeta,
          idFolhaPpp.isAcceptableOrUnknown(
              data['id_folha_ppp']!, _idFolhaPppMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPppAtividade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPppAtividade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaPpp: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_ppp']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $FolhaPppAtividadesTable createAlias(String alias) {
    return $FolhaPppAtividadesTable(attachedDatabase, alias);
  }
}

class FolhaPppAtividade extends DataClass
    implements Insertable<FolhaPppAtividade> {
  final int? id;
  final int? idFolhaPpp;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final String? descricao;
  const FolhaPppAtividade(
      {this.id,
      this.idFolhaPpp,
      this.dataInicio,
      this.dataFim,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaPpp != null) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FolhaPppAtividade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPppAtividade(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaPpp: serializer.fromJson<int?>(json['idFolhaPpp']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaPpp': serializer.toJson<int?>(idFolhaPpp),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FolhaPppAtividade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaPpp = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      FolhaPppAtividade(
        id: id.present ? id.value : this.id,
        idFolhaPpp: idFolhaPpp.present ? idFolhaPpp.value : this.idFolhaPpp,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPppAtividade(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idFolhaPpp, dataInicio, dataFim, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPppAtividade &&
          other.id == this.id &&
          other.idFolhaPpp == this.idFolhaPpp &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.descricao == this.descricao);
}

class FolhaPppAtividadesCompanion extends UpdateCompanion<FolhaPppAtividade> {
  final Value<int?> id;
  final Value<int?> idFolhaPpp;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<String?> descricao;
  const FolhaPppAtividadesCompanion({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FolhaPppAtividadesCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FolhaPppAtividade> custom({
    Expression<int>? id,
    Expression<int>? idFolhaPpp,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaPpp != null) 'id_folha_ppp': idFolhaPpp,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FolhaPppAtividadesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaPpp,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<String?>? descricao}) {
    return FolhaPppAtividadesCompanion(
      id: id ?? this.id,
      idFolhaPpp: idFolhaPpp ?? this.idFolhaPpp,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaPpp.present) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPppAtividadesCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FolhaPppFatorRiscosTable extends FolhaPppFatorRiscos
    with TableInfo<$FolhaPppFatorRiscosTable, FolhaPppFatorRisco> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPppFatorRiscosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaPppMeta =
      const VerificationMeta('idFolhaPpp');
  @override
  late final GeneratedColumn<int> idFolhaPpp = GeneratedColumn<int>(
      'id_folha_ppp', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fatorRiscoMeta =
      const VerificationMeta('fatorRisco');
  @override
  late final GeneratedColumn<String> fatorRisco = GeneratedColumn<String>(
      'fator_risco', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 40),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _intensidadeMeta =
      const VerificationMeta('intensidade');
  @override
  late final GeneratedColumn<String> intensidade = GeneratedColumn<String>(
      'intensidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tecnicaUtilizadaMeta =
      const VerificationMeta('tecnicaUtilizada');
  @override
  late final GeneratedColumn<String> tecnicaUtilizada = GeneratedColumn<String>(
      'tecnica_utilizada', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 40),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _epcEficazMeta =
      const VerificationMeta('epcEficaz');
  @override
  late final GeneratedColumn<String> epcEficaz = GeneratedColumn<String>(
      'epc_eficaz', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _epiEficazMeta =
      const VerificationMeta('epiEficaz');
  @override
  late final GeneratedColumn<String> epiEficaz = GeneratedColumn<String>(
      'epi_eficaz', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _caEpiMeta = const VerificationMeta('caEpi');
  @override
  late final GeneratedColumn<int> caEpi = GeneratedColumn<int>(
      'ca_epi', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _atendimentoNr061Meta =
      const VerificationMeta('atendimentoNr061');
  @override
  late final GeneratedColumn<String> atendimentoNr061 = GeneratedColumn<String>(
      'atendimento_nr06_1', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _atendimentoNr062Meta =
      const VerificationMeta('atendimentoNr062');
  @override
  late final GeneratedColumn<String> atendimentoNr062 = GeneratedColumn<String>(
      'atendimento_nr06_2', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _atendimentoNr063Meta =
      const VerificationMeta('atendimentoNr063');
  @override
  late final GeneratedColumn<String> atendimentoNr063 = GeneratedColumn<String>(
      'atendimento_nr06_3', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _atendimentoNr064Meta =
      const VerificationMeta('atendimentoNr064');
  @override
  late final GeneratedColumn<String> atendimentoNr064 = GeneratedColumn<String>(
      'atendimento_nr06_4', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _atendimentoNr065Meta =
      const VerificationMeta('atendimentoNr065');
  @override
  late final GeneratedColumn<String> atendimentoNr065 = GeneratedColumn<String>(
      'atendimento_nr06_5', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFolhaPpp,
        dataInicio,
        dataFim,
        tipo,
        fatorRisco,
        intensidade,
        tecnicaUtilizada,
        epcEficaz,
        epiEficaz,
        caEpi,
        atendimentoNr061,
        atendimentoNr062,
        atendimentoNr063,
        atendimentoNr064,
        atendimentoNr065
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ppp_fator_risco';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaPppFatorRisco> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_ppp')) {
      context.handle(
          _idFolhaPppMeta,
          idFolhaPpp.isAcceptableOrUnknown(
              data['id_folha_ppp']!, _idFolhaPppMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('fator_risco')) {
      context.handle(
          _fatorRiscoMeta,
          fatorRisco.isAcceptableOrUnknown(
              data['fator_risco']!, _fatorRiscoMeta));
    }
    if (data.containsKey('intensidade')) {
      context.handle(
          _intensidadeMeta,
          intensidade.isAcceptableOrUnknown(
              data['intensidade']!, _intensidadeMeta));
    }
    if (data.containsKey('tecnica_utilizada')) {
      context.handle(
          _tecnicaUtilizadaMeta,
          tecnicaUtilizada.isAcceptableOrUnknown(
              data['tecnica_utilizada']!, _tecnicaUtilizadaMeta));
    }
    if (data.containsKey('epc_eficaz')) {
      context.handle(_epcEficazMeta,
          epcEficaz.isAcceptableOrUnknown(data['epc_eficaz']!, _epcEficazMeta));
    }
    if (data.containsKey('epi_eficaz')) {
      context.handle(_epiEficazMeta,
          epiEficaz.isAcceptableOrUnknown(data['epi_eficaz']!, _epiEficazMeta));
    }
    if (data.containsKey('ca_epi')) {
      context.handle(
          _caEpiMeta, caEpi.isAcceptableOrUnknown(data['ca_epi']!, _caEpiMeta));
    }
    if (data.containsKey('atendimento_nr06_1')) {
      context.handle(
          _atendimentoNr061Meta,
          atendimentoNr061.isAcceptableOrUnknown(
              data['atendimento_nr06_1']!, _atendimentoNr061Meta));
    }
    if (data.containsKey('atendimento_nr06_2')) {
      context.handle(
          _atendimentoNr062Meta,
          atendimentoNr062.isAcceptableOrUnknown(
              data['atendimento_nr06_2']!, _atendimentoNr062Meta));
    }
    if (data.containsKey('atendimento_nr06_3')) {
      context.handle(
          _atendimentoNr063Meta,
          atendimentoNr063.isAcceptableOrUnknown(
              data['atendimento_nr06_3']!, _atendimentoNr063Meta));
    }
    if (data.containsKey('atendimento_nr06_4')) {
      context.handle(
          _atendimentoNr064Meta,
          atendimentoNr064.isAcceptableOrUnknown(
              data['atendimento_nr06_4']!, _atendimentoNr064Meta));
    }
    if (data.containsKey('atendimento_nr06_5')) {
      context.handle(
          _atendimentoNr065Meta,
          atendimentoNr065.isAcceptableOrUnknown(
              data['atendimento_nr06_5']!, _atendimentoNr065Meta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPppFatorRisco map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPppFatorRisco(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaPpp: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_ppp']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      fatorRisco: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fator_risco']),
      intensidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}intensidade']),
      tecnicaUtilizada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tecnica_utilizada']),
      epcEficaz: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}epc_eficaz']),
      epiEficaz: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}epi_eficaz']),
      caEpi: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ca_epi']),
      atendimentoNr061: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}atendimento_nr06_1']),
      atendimentoNr062: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}atendimento_nr06_2']),
      atendimentoNr063: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}atendimento_nr06_3']),
      atendimentoNr064: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}atendimento_nr06_4']),
      atendimentoNr065: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}atendimento_nr06_5']),
    );
  }

  @override
  $FolhaPppFatorRiscosTable createAlias(String alias) {
    return $FolhaPppFatorRiscosTable(attachedDatabase, alias);
  }
}

class FolhaPppFatorRisco extends DataClass
    implements Insertable<FolhaPppFatorRisco> {
  final int? id;
  final int? idFolhaPpp;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final String? tipo;
  final String? fatorRisco;
  final String? intensidade;
  final String? tecnicaUtilizada;
  final String? epcEficaz;
  final String? epiEficaz;
  final int? caEpi;
  final String? atendimentoNr061;
  final String? atendimentoNr062;
  final String? atendimentoNr063;
  final String? atendimentoNr064;
  final String? atendimentoNr065;
  const FolhaPppFatorRisco(
      {this.id,
      this.idFolhaPpp,
      this.dataInicio,
      this.dataFim,
      this.tipo,
      this.fatorRisco,
      this.intensidade,
      this.tecnicaUtilizada,
      this.epcEficaz,
      this.epiEficaz,
      this.caEpi,
      this.atendimentoNr061,
      this.atendimentoNr062,
      this.atendimentoNr063,
      this.atendimentoNr064,
      this.atendimentoNr065});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaPpp != null) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || fatorRisco != null) {
      map['fator_risco'] = Variable<String>(fatorRisco);
    }
    if (!nullToAbsent || intensidade != null) {
      map['intensidade'] = Variable<String>(intensidade);
    }
    if (!nullToAbsent || tecnicaUtilizada != null) {
      map['tecnica_utilizada'] = Variable<String>(tecnicaUtilizada);
    }
    if (!nullToAbsent || epcEficaz != null) {
      map['epc_eficaz'] = Variable<String>(epcEficaz);
    }
    if (!nullToAbsent || epiEficaz != null) {
      map['epi_eficaz'] = Variable<String>(epiEficaz);
    }
    if (!nullToAbsent || caEpi != null) {
      map['ca_epi'] = Variable<int>(caEpi);
    }
    if (!nullToAbsent || atendimentoNr061 != null) {
      map['atendimento_nr06_1'] = Variable<String>(atendimentoNr061);
    }
    if (!nullToAbsent || atendimentoNr062 != null) {
      map['atendimento_nr06_2'] = Variable<String>(atendimentoNr062);
    }
    if (!nullToAbsent || atendimentoNr063 != null) {
      map['atendimento_nr06_3'] = Variable<String>(atendimentoNr063);
    }
    if (!nullToAbsent || atendimentoNr064 != null) {
      map['atendimento_nr06_4'] = Variable<String>(atendimentoNr064);
    }
    if (!nullToAbsent || atendimentoNr065 != null) {
      map['atendimento_nr06_5'] = Variable<String>(atendimentoNr065);
    }
    return map;
  }

  factory FolhaPppFatorRisco.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPppFatorRisco(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaPpp: serializer.fromJson<int?>(json['idFolhaPpp']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      fatorRisco: serializer.fromJson<String?>(json['fatorRisco']),
      intensidade: serializer.fromJson<String?>(json['intensidade']),
      tecnicaUtilizada: serializer.fromJson<String?>(json['tecnicaUtilizada']),
      epcEficaz: serializer.fromJson<String?>(json['epcEficaz']),
      epiEficaz: serializer.fromJson<String?>(json['epiEficaz']),
      caEpi: serializer.fromJson<int?>(json['caEpi']),
      atendimentoNr061: serializer.fromJson<String?>(json['atendimentoNr061']),
      atendimentoNr062: serializer.fromJson<String?>(json['atendimentoNr062']),
      atendimentoNr063: serializer.fromJson<String?>(json['atendimentoNr063']),
      atendimentoNr064: serializer.fromJson<String?>(json['atendimentoNr064']),
      atendimentoNr065: serializer.fromJson<String?>(json['atendimentoNr065']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaPpp': serializer.toJson<int?>(idFolhaPpp),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'tipo': serializer.toJson<String?>(tipo),
      'fatorRisco': serializer.toJson<String?>(fatorRisco),
      'intensidade': serializer.toJson<String?>(intensidade),
      'tecnicaUtilizada': serializer.toJson<String?>(tecnicaUtilizada),
      'epcEficaz': serializer.toJson<String?>(epcEficaz),
      'epiEficaz': serializer.toJson<String?>(epiEficaz),
      'caEpi': serializer.toJson<int?>(caEpi),
      'atendimentoNr061': serializer.toJson<String?>(atendimentoNr061),
      'atendimentoNr062': serializer.toJson<String?>(atendimentoNr062),
      'atendimentoNr063': serializer.toJson<String?>(atendimentoNr063),
      'atendimentoNr064': serializer.toJson<String?>(atendimentoNr064),
      'atendimentoNr065': serializer.toJson<String?>(atendimentoNr065),
    };
  }

  FolhaPppFatorRisco copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaPpp = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> fatorRisco = const Value.absent(),
          Value<String?> intensidade = const Value.absent(),
          Value<String?> tecnicaUtilizada = const Value.absent(),
          Value<String?> epcEficaz = const Value.absent(),
          Value<String?> epiEficaz = const Value.absent(),
          Value<int?> caEpi = const Value.absent(),
          Value<String?> atendimentoNr061 = const Value.absent(),
          Value<String?> atendimentoNr062 = const Value.absent(),
          Value<String?> atendimentoNr063 = const Value.absent(),
          Value<String?> atendimentoNr064 = const Value.absent(),
          Value<String?> atendimentoNr065 = const Value.absent()}) =>
      FolhaPppFatorRisco(
        id: id.present ? id.value : this.id,
        idFolhaPpp: idFolhaPpp.present ? idFolhaPpp.value : this.idFolhaPpp,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        tipo: tipo.present ? tipo.value : this.tipo,
        fatorRisco: fatorRisco.present ? fatorRisco.value : this.fatorRisco,
        intensidade: intensidade.present ? intensidade.value : this.intensidade,
        tecnicaUtilizada: tecnicaUtilizada.present
            ? tecnicaUtilizada.value
            : this.tecnicaUtilizada,
        epcEficaz: epcEficaz.present ? epcEficaz.value : this.epcEficaz,
        epiEficaz: epiEficaz.present ? epiEficaz.value : this.epiEficaz,
        caEpi: caEpi.present ? caEpi.value : this.caEpi,
        atendimentoNr061: atendimentoNr061.present
            ? atendimentoNr061.value
            : this.atendimentoNr061,
        atendimentoNr062: atendimentoNr062.present
            ? atendimentoNr062.value
            : this.atendimentoNr062,
        atendimentoNr063: atendimentoNr063.present
            ? atendimentoNr063.value
            : this.atendimentoNr063,
        atendimentoNr064: atendimentoNr064.present
            ? atendimentoNr064.value
            : this.atendimentoNr064,
        atendimentoNr065: atendimentoNr065.present
            ? atendimentoNr065.value
            : this.atendimentoNr065,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPppFatorRisco(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('tipo: $tipo, ')
          ..write('fatorRisco: $fatorRisco, ')
          ..write('intensidade: $intensidade, ')
          ..write('tecnicaUtilizada: $tecnicaUtilizada, ')
          ..write('epcEficaz: $epcEficaz, ')
          ..write('epiEficaz: $epiEficaz, ')
          ..write('caEpi: $caEpi, ')
          ..write('atendimentoNr061: $atendimentoNr061, ')
          ..write('atendimentoNr062: $atendimentoNr062, ')
          ..write('atendimentoNr063: $atendimentoNr063, ')
          ..write('atendimentoNr064: $atendimentoNr064, ')
          ..write('atendimentoNr065: $atendimentoNr065')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idFolhaPpp,
      dataInicio,
      dataFim,
      tipo,
      fatorRisco,
      intensidade,
      tecnicaUtilizada,
      epcEficaz,
      epiEficaz,
      caEpi,
      atendimentoNr061,
      atendimentoNr062,
      atendimentoNr063,
      atendimentoNr064,
      atendimentoNr065);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPppFatorRisco &&
          other.id == this.id &&
          other.idFolhaPpp == this.idFolhaPpp &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.tipo == this.tipo &&
          other.fatorRisco == this.fatorRisco &&
          other.intensidade == this.intensidade &&
          other.tecnicaUtilizada == this.tecnicaUtilizada &&
          other.epcEficaz == this.epcEficaz &&
          other.epiEficaz == this.epiEficaz &&
          other.caEpi == this.caEpi &&
          other.atendimentoNr061 == this.atendimentoNr061 &&
          other.atendimentoNr062 == this.atendimentoNr062 &&
          other.atendimentoNr063 == this.atendimentoNr063 &&
          other.atendimentoNr064 == this.atendimentoNr064 &&
          other.atendimentoNr065 == this.atendimentoNr065);
}

class FolhaPppFatorRiscosCompanion extends UpdateCompanion<FolhaPppFatorRisco> {
  final Value<int?> id;
  final Value<int?> idFolhaPpp;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<String?> tipo;
  final Value<String?> fatorRisco;
  final Value<String?> intensidade;
  final Value<String?> tecnicaUtilizada;
  final Value<String?> epcEficaz;
  final Value<String?> epiEficaz;
  final Value<int?> caEpi;
  final Value<String?> atendimentoNr061;
  final Value<String?> atendimentoNr062;
  final Value<String?> atendimentoNr063;
  final Value<String?> atendimentoNr064;
  final Value<String?> atendimentoNr065;
  const FolhaPppFatorRiscosCompanion({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.tipo = const Value.absent(),
    this.fatorRisco = const Value.absent(),
    this.intensidade = const Value.absent(),
    this.tecnicaUtilizada = const Value.absent(),
    this.epcEficaz = const Value.absent(),
    this.epiEficaz = const Value.absent(),
    this.caEpi = const Value.absent(),
    this.atendimentoNr061 = const Value.absent(),
    this.atendimentoNr062 = const Value.absent(),
    this.atendimentoNr063 = const Value.absent(),
    this.atendimentoNr064 = const Value.absent(),
    this.atendimentoNr065 = const Value.absent(),
  });
  FolhaPppFatorRiscosCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.tipo = const Value.absent(),
    this.fatorRisco = const Value.absent(),
    this.intensidade = const Value.absent(),
    this.tecnicaUtilizada = const Value.absent(),
    this.epcEficaz = const Value.absent(),
    this.epiEficaz = const Value.absent(),
    this.caEpi = const Value.absent(),
    this.atendimentoNr061 = const Value.absent(),
    this.atendimentoNr062 = const Value.absent(),
    this.atendimentoNr063 = const Value.absent(),
    this.atendimentoNr064 = const Value.absent(),
    this.atendimentoNr065 = const Value.absent(),
  });
  static Insertable<FolhaPppFatorRisco> custom({
    Expression<int>? id,
    Expression<int>? idFolhaPpp,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<String>? tipo,
    Expression<String>? fatorRisco,
    Expression<String>? intensidade,
    Expression<String>? tecnicaUtilizada,
    Expression<String>? epcEficaz,
    Expression<String>? epiEficaz,
    Expression<int>? caEpi,
    Expression<String>? atendimentoNr061,
    Expression<String>? atendimentoNr062,
    Expression<String>? atendimentoNr063,
    Expression<String>? atendimentoNr064,
    Expression<String>? atendimentoNr065,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaPpp != null) 'id_folha_ppp': idFolhaPpp,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (tipo != null) 'tipo': tipo,
      if (fatorRisco != null) 'fator_risco': fatorRisco,
      if (intensidade != null) 'intensidade': intensidade,
      if (tecnicaUtilizada != null) 'tecnica_utilizada': tecnicaUtilizada,
      if (epcEficaz != null) 'epc_eficaz': epcEficaz,
      if (epiEficaz != null) 'epi_eficaz': epiEficaz,
      if (caEpi != null) 'ca_epi': caEpi,
      if (atendimentoNr061 != null) 'atendimento_nr06_1': atendimentoNr061,
      if (atendimentoNr062 != null) 'atendimento_nr06_2': atendimentoNr062,
      if (atendimentoNr063 != null) 'atendimento_nr06_3': atendimentoNr063,
      if (atendimentoNr064 != null) 'atendimento_nr06_4': atendimentoNr064,
      if (atendimentoNr065 != null) 'atendimento_nr06_5': atendimentoNr065,
    });
  }

  FolhaPppFatorRiscosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaPpp,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<String?>? tipo,
      Value<String?>? fatorRisco,
      Value<String?>? intensidade,
      Value<String?>? tecnicaUtilizada,
      Value<String?>? epcEficaz,
      Value<String?>? epiEficaz,
      Value<int?>? caEpi,
      Value<String?>? atendimentoNr061,
      Value<String?>? atendimentoNr062,
      Value<String?>? atendimentoNr063,
      Value<String?>? atendimentoNr064,
      Value<String?>? atendimentoNr065}) {
    return FolhaPppFatorRiscosCompanion(
      id: id ?? this.id,
      idFolhaPpp: idFolhaPpp ?? this.idFolhaPpp,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      tipo: tipo ?? this.tipo,
      fatorRisco: fatorRisco ?? this.fatorRisco,
      intensidade: intensidade ?? this.intensidade,
      tecnicaUtilizada: tecnicaUtilizada ?? this.tecnicaUtilizada,
      epcEficaz: epcEficaz ?? this.epcEficaz,
      epiEficaz: epiEficaz ?? this.epiEficaz,
      caEpi: caEpi ?? this.caEpi,
      atendimentoNr061: atendimentoNr061 ?? this.atendimentoNr061,
      atendimentoNr062: atendimentoNr062 ?? this.atendimentoNr062,
      atendimentoNr063: atendimentoNr063 ?? this.atendimentoNr063,
      atendimentoNr064: atendimentoNr064 ?? this.atendimentoNr064,
      atendimentoNr065: atendimentoNr065 ?? this.atendimentoNr065,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaPpp.present) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (fatorRisco.present) {
      map['fator_risco'] = Variable<String>(fatorRisco.value);
    }
    if (intensidade.present) {
      map['intensidade'] = Variable<String>(intensidade.value);
    }
    if (tecnicaUtilizada.present) {
      map['tecnica_utilizada'] = Variable<String>(tecnicaUtilizada.value);
    }
    if (epcEficaz.present) {
      map['epc_eficaz'] = Variable<String>(epcEficaz.value);
    }
    if (epiEficaz.present) {
      map['epi_eficaz'] = Variable<String>(epiEficaz.value);
    }
    if (caEpi.present) {
      map['ca_epi'] = Variable<int>(caEpi.value);
    }
    if (atendimentoNr061.present) {
      map['atendimento_nr06_1'] = Variable<String>(atendimentoNr061.value);
    }
    if (atendimentoNr062.present) {
      map['atendimento_nr06_2'] = Variable<String>(atendimentoNr062.value);
    }
    if (atendimentoNr063.present) {
      map['atendimento_nr06_3'] = Variable<String>(atendimentoNr063.value);
    }
    if (atendimentoNr064.present) {
      map['atendimento_nr06_4'] = Variable<String>(atendimentoNr064.value);
    }
    if (atendimentoNr065.present) {
      map['atendimento_nr06_5'] = Variable<String>(atendimentoNr065.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPppFatorRiscosCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('tipo: $tipo, ')
          ..write('fatorRisco: $fatorRisco, ')
          ..write('intensidade: $intensidade, ')
          ..write('tecnicaUtilizada: $tecnicaUtilizada, ')
          ..write('epcEficaz: $epcEficaz, ')
          ..write('epiEficaz: $epiEficaz, ')
          ..write('caEpi: $caEpi, ')
          ..write('atendimentoNr061: $atendimentoNr061, ')
          ..write('atendimentoNr062: $atendimentoNr062, ')
          ..write('atendimentoNr063: $atendimentoNr063, ')
          ..write('atendimentoNr064: $atendimentoNr064, ')
          ..write('atendimentoNr065: $atendimentoNr065')
          ..write(')'))
        .toString();
  }
}

class $FolhaPppExameMedicosTable extends FolhaPppExameMedicos
    with TableInfo<$FolhaPppExameMedicosTable, FolhaPppExameMedico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPppExameMedicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaPppMeta =
      const VerificationMeta('idFolhaPpp');
  @override
  late final GeneratedColumn<int> idFolhaPpp = GeneratedColumn<int>(
      'id_folha_ppp', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataUltimoMeta =
      const VerificationMeta('dataUltimo');
  @override
  late final GeneratedColumn<DateTime> dataUltimo = GeneratedColumn<DateTime>(
      'data_ultimo', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _exameMeta = const VerificationMeta('exame');
  @override
  late final GeneratedColumn<String> exame = GeneratedColumn<String>(
      'exame', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturezaMeta =
      const VerificationMeta('natureza');
  @override
  late final GeneratedColumn<String> natureza = GeneratedColumn<String>(
      'natureza', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _indicacaoResultadosMeta =
      const VerificationMeta('indicacaoResultados');
  @override
  late final GeneratedColumn<String> indicacaoResultados =
      GeneratedColumn<String>('indicacao_resultados', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 50),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFolhaPpp, dataUltimo, tipo, exame, natureza, indicacaoResultados];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ppp_exame_medico';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaPppExameMedico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_folha_ppp')) {
      context.handle(
          _idFolhaPppMeta,
          idFolhaPpp.isAcceptableOrUnknown(
              data['id_folha_ppp']!, _idFolhaPppMeta));
    }
    if (data.containsKey('data_ultimo')) {
      context.handle(
          _dataUltimoMeta,
          dataUltimo.isAcceptableOrUnknown(
              data['data_ultimo']!, _dataUltimoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('exame')) {
      context.handle(
          _exameMeta, exame.isAcceptableOrUnknown(data['exame']!, _exameMeta));
    }
    if (data.containsKey('natureza')) {
      context.handle(_naturezaMeta,
          natureza.isAcceptableOrUnknown(data['natureza']!, _naturezaMeta));
    }
    if (data.containsKey('indicacao_resultados')) {
      context.handle(
          _indicacaoResultadosMeta,
          indicacaoResultados.isAcceptableOrUnknown(
              data['indicacao_resultados']!, _indicacaoResultadosMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPppExameMedico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPppExameMedico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFolhaPpp: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_folha_ppp']),
      dataUltimo: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_ultimo']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      exame: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}exame']),
      natureza: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}natureza']),
      indicacaoResultados: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}indicacao_resultados']),
    );
  }

  @override
  $FolhaPppExameMedicosTable createAlias(String alias) {
    return $FolhaPppExameMedicosTable(attachedDatabase, alias);
  }
}

class FolhaPppExameMedico extends DataClass
    implements Insertable<FolhaPppExameMedico> {
  final int? id;
  final int? idFolhaPpp;
  final DateTime? dataUltimo;
  final String? tipo;
  final String? exame;
  final String? natureza;
  final String? indicacaoResultados;
  const FolhaPppExameMedico(
      {this.id,
      this.idFolhaPpp,
      this.dataUltimo,
      this.tipo,
      this.exame,
      this.natureza,
      this.indicacaoResultados});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFolhaPpp != null) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp);
    }
    if (!nullToAbsent || dataUltimo != null) {
      map['data_ultimo'] = Variable<DateTime>(dataUltimo);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || exame != null) {
      map['exame'] = Variable<String>(exame);
    }
    if (!nullToAbsent || natureza != null) {
      map['natureza'] = Variable<String>(natureza);
    }
    if (!nullToAbsent || indicacaoResultados != null) {
      map['indicacao_resultados'] = Variable<String>(indicacaoResultados);
    }
    return map;
  }

  factory FolhaPppExameMedico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPppExameMedico(
      id: serializer.fromJson<int?>(json['id']),
      idFolhaPpp: serializer.fromJson<int?>(json['idFolhaPpp']),
      dataUltimo: serializer.fromJson<DateTime?>(json['dataUltimo']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      exame: serializer.fromJson<String?>(json['exame']),
      natureza: serializer.fromJson<String?>(json['natureza']),
      indicacaoResultados:
          serializer.fromJson<String?>(json['indicacaoResultados']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFolhaPpp': serializer.toJson<int?>(idFolhaPpp),
      'dataUltimo': serializer.toJson<DateTime?>(dataUltimo),
      'tipo': serializer.toJson<String?>(tipo),
      'exame': serializer.toJson<String?>(exame),
      'natureza': serializer.toJson<String?>(natureza),
      'indicacaoResultados': serializer.toJson<String?>(indicacaoResultados),
    };
  }

  FolhaPppExameMedico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFolhaPpp = const Value.absent(),
          Value<DateTime?> dataUltimo = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> exame = const Value.absent(),
          Value<String?> natureza = const Value.absent(),
          Value<String?> indicacaoResultados = const Value.absent()}) =>
      FolhaPppExameMedico(
        id: id.present ? id.value : this.id,
        idFolhaPpp: idFolhaPpp.present ? idFolhaPpp.value : this.idFolhaPpp,
        dataUltimo: dataUltimo.present ? dataUltimo.value : this.dataUltimo,
        tipo: tipo.present ? tipo.value : this.tipo,
        exame: exame.present ? exame.value : this.exame,
        natureza: natureza.present ? natureza.value : this.natureza,
        indicacaoResultados: indicacaoResultados.present
            ? indicacaoResultados.value
            : this.indicacaoResultados,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPppExameMedico(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataUltimo: $dataUltimo, ')
          ..write('tipo: $tipo, ')
          ..write('exame: $exame, ')
          ..write('natureza: $natureza, ')
          ..write('indicacaoResultados: $indicacaoResultados')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idFolhaPpp, dataUltimo, tipo, exame, natureza, indicacaoResultados);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPppExameMedico &&
          other.id == this.id &&
          other.idFolhaPpp == this.idFolhaPpp &&
          other.dataUltimo == this.dataUltimo &&
          other.tipo == this.tipo &&
          other.exame == this.exame &&
          other.natureza == this.natureza &&
          other.indicacaoResultados == this.indicacaoResultados);
}

class FolhaPppExameMedicosCompanion
    extends UpdateCompanion<FolhaPppExameMedico> {
  final Value<int?> id;
  final Value<int?> idFolhaPpp;
  final Value<DateTime?> dataUltimo;
  final Value<String?> tipo;
  final Value<String?> exame;
  final Value<String?> natureza;
  final Value<String?> indicacaoResultados;
  const FolhaPppExameMedicosCompanion({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataUltimo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.exame = const Value.absent(),
    this.natureza = const Value.absent(),
    this.indicacaoResultados = const Value.absent(),
  });
  FolhaPppExameMedicosCompanion.insert({
    this.id = const Value.absent(),
    this.idFolhaPpp = const Value.absent(),
    this.dataUltimo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.exame = const Value.absent(),
    this.natureza = const Value.absent(),
    this.indicacaoResultados = const Value.absent(),
  });
  static Insertable<FolhaPppExameMedico> custom({
    Expression<int>? id,
    Expression<int>? idFolhaPpp,
    Expression<DateTime>? dataUltimo,
    Expression<String>? tipo,
    Expression<String>? exame,
    Expression<String>? natureza,
    Expression<String>? indicacaoResultados,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFolhaPpp != null) 'id_folha_ppp': idFolhaPpp,
      if (dataUltimo != null) 'data_ultimo': dataUltimo,
      if (tipo != null) 'tipo': tipo,
      if (exame != null) 'exame': exame,
      if (natureza != null) 'natureza': natureza,
      if (indicacaoResultados != null)
        'indicacao_resultados': indicacaoResultados,
    });
  }

  FolhaPppExameMedicosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFolhaPpp,
      Value<DateTime?>? dataUltimo,
      Value<String?>? tipo,
      Value<String?>? exame,
      Value<String?>? natureza,
      Value<String?>? indicacaoResultados}) {
    return FolhaPppExameMedicosCompanion(
      id: id ?? this.id,
      idFolhaPpp: idFolhaPpp ?? this.idFolhaPpp,
      dataUltimo: dataUltimo ?? this.dataUltimo,
      tipo: tipo ?? this.tipo,
      exame: exame ?? this.exame,
      natureza: natureza ?? this.natureza,
      indicacaoResultados: indicacaoResultados ?? this.indicacaoResultados,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFolhaPpp.present) {
      map['id_folha_ppp'] = Variable<int>(idFolhaPpp.value);
    }
    if (dataUltimo.present) {
      map['data_ultimo'] = Variable<DateTime>(dataUltimo.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (exame.present) {
      map['exame'] = Variable<String>(exame.value);
    }
    if (natureza.present) {
      map['natureza'] = Variable<String>(natureza.value);
    }
    if (indicacaoResultados.present) {
      map['indicacao_resultados'] = Variable<String>(indicacaoResultados.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPppExameMedicosCompanion(')
          ..write('id: $id, ')
          ..write('idFolhaPpp: $idFolhaPpp, ')
          ..write('dataUltimo: $dataUltimo, ')
          ..write('tipo: $tipo, ')
          ..write('exame: $exame, ')
          ..write('natureza: $natureza, ')
          ..write('indicacaoResultados: $indicacaoResultados')
          ..write(')'))
        .toString();
  }
}

class $EmpresaTransportesTable extends EmpresaTransportes
    with TableInfo<$EmpresaTransportesTable, EmpresaTransporte> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EmpresaTransportesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _classificacaoContabilContaMeta =
      const VerificationMeta('classificacaoContabilConta');
  @override
  late final GeneratedColumn<String> classificacaoContabilConta =
      GeneratedColumn<String>('classificacao_contabil_conta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nome, uf, classificacaoContabilConta];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'empresa_transporte';
  @override
  VerificationContext validateIntegrity(Insertable<EmpresaTransporte> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('classificacao_contabil_conta')) {
      context.handle(
          _classificacaoContabilContaMeta,
          classificacaoContabilConta.isAcceptableOrUnknown(
              data['classificacao_contabil_conta']!,
              _classificacaoContabilContaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EmpresaTransporte map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EmpresaTransporte(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      classificacaoContabilConta: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}classificacao_contabil_conta']),
    );
  }

  @override
  $EmpresaTransportesTable createAlias(String alias) {
    return $EmpresaTransportesTable(attachedDatabase, alias);
  }
}

class EmpresaTransporte extends DataClass
    implements Insertable<EmpresaTransporte> {
  final int? id;
  final String? nome;
  final String? uf;
  final String? classificacaoContabilConta;
  const EmpresaTransporte(
      {this.id, this.nome, this.uf, this.classificacaoContabilConta});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || classificacaoContabilConta != null) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta);
    }
    return map;
  }

  factory EmpresaTransporte.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EmpresaTransporte(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      uf: serializer.fromJson<String?>(json['uf']),
      classificacaoContabilConta:
          serializer.fromJson<String?>(json['classificacaoContabilConta']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'uf': serializer.toJson<String?>(uf),
      'classificacaoContabilConta':
          serializer.toJson<String?>(classificacaoContabilConta),
    };
  }

  EmpresaTransporte copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> classificacaoContabilConta = const Value.absent()}) =>
      EmpresaTransporte(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        uf: uf.present ? uf.value : this.uf,
        classificacaoContabilConta: classificacaoContabilConta.present
            ? classificacaoContabilConta.value
            : this.classificacaoContabilConta,
      );
  @override
  String toString() {
    return (StringBuffer('EmpresaTransporte(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('uf: $uf, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, uf, classificacaoContabilConta);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EmpresaTransporte &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.uf == this.uf &&
          other.classificacaoContabilConta == this.classificacaoContabilConta);
}

class EmpresaTransportesCompanion extends UpdateCompanion<EmpresaTransporte> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> uf;
  final Value<String?> classificacaoContabilConta;
  const EmpresaTransportesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.uf = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  EmpresaTransportesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.uf = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  static Insertable<EmpresaTransporte> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? uf,
    Expression<String>? classificacaoContabilConta,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (uf != null) 'uf': uf,
      if (classificacaoContabilConta != null)
        'classificacao_contabil_conta': classificacaoContabilConta,
    });
  }

  EmpresaTransportesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? uf,
      Value<String?>? classificacaoContabilConta}) {
    return EmpresaTransportesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      uf: uf ?? this.uf,
      classificacaoContabilConta:
          classificacaoContabilConta ?? this.classificacaoContabilConta,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (classificacaoContabilConta.present) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EmpresaTransportesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('uf: $uf, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }
}

class $FolhaLancamentoCabecalhosTable extends FolhaLancamentoCabecalhos
    with TableInfo<$FolhaLancamentoCabecalhosTable, FolhaLancamentoCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaLancamentoCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idColaborador, competencia, tipo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_lancamento_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaLancamentoCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaLancamentoCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaLancamentoCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
    );
  }

  @override
  $FolhaLancamentoCabecalhosTable createAlias(String alias) {
    return $FolhaLancamentoCabecalhosTable(attachedDatabase, alias);
  }
}

class FolhaLancamentoCabecalho extends DataClass
    implements Insertable<FolhaLancamentoCabecalho> {
  final int? id;
  final int? idColaborador;
  final String? competencia;
  final String? tipo;
  const FolhaLancamentoCabecalho(
      {this.id, this.idColaborador, this.competencia, this.tipo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    return map;
  }

  factory FolhaLancamentoCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaLancamentoCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      tipo: serializer.fromJson<String?>(json['tipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'competencia': serializer.toJson<String?>(competencia),
      'tipo': serializer.toJson<String?>(tipo),
    };
  }

  FolhaLancamentoCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<String?> tipo = const Value.absent()}) =>
      FolhaLancamentoCabecalho(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        competencia: competencia.present ? competencia.value : this.competencia,
        tipo: tipo.present ? tipo.value : this.tipo,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoCabecalho(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('tipo: $tipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, competencia, tipo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaLancamentoCabecalho &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.competencia == this.competencia &&
          other.tipo == this.tipo);
}

class FolhaLancamentoCabecalhosCompanion
    extends UpdateCompanion<FolhaLancamentoCabecalho> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<String?> competencia;
  final Value<String?> tipo;
  const FolhaLancamentoCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.tipo = const Value.absent(),
  });
  FolhaLancamentoCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.tipo = const Value.absent(),
  });
  static Insertable<FolhaLancamentoCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<String>? competencia,
    Expression<String>? tipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (competencia != null) 'competencia': competencia,
      if (tipo != null) 'tipo': tipo,
    });
  }

  FolhaLancamentoCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<String?>? competencia,
      Value<String?>? tipo}) {
    return FolhaLancamentoCabecalhosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      competencia: competencia ?? this.competencia,
      tipo: tipo ?? this.tipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('tipo: $tipo')
          ..write(')'))
        .toString();
  }
}

class $FolhaInsssTable extends FolhaInsss
    with TableInfo<$FolhaInsssTable, FolhaInss> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaInsssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, competencia];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_inss';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaInss> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaInss map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaInss(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
    );
  }

  @override
  $FolhaInsssTable createAlias(String alias) {
    return $FolhaInsssTable(attachedDatabase, alias);
  }
}

class FolhaInss extends DataClass implements Insertable<FolhaInss> {
  final int? id;
  final String? competencia;
  const FolhaInss({this.id, this.competencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    return map;
  }

  factory FolhaInss.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaInss(
      id: serializer.fromJson<int?>(json['id']),
      competencia: serializer.fromJson<String?>(json['competencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'competencia': serializer.toJson<String?>(competencia),
    };
  }

  FolhaInss copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> competencia = const Value.absent()}) =>
      FolhaInss(
        id: id.present ? id.value : this.id,
        competencia: competencia.present ? competencia.value : this.competencia,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaInss(')
          ..write('id: $id, ')
          ..write('competencia: $competencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, competencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaInss &&
          other.id == this.id &&
          other.competencia == this.competencia);
}

class FolhaInsssCompanion extends UpdateCompanion<FolhaInss> {
  final Value<int?> id;
  final Value<String?> competencia;
  const FolhaInsssCompanion({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
  });
  FolhaInsssCompanion.insert({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
  });
  static Insertable<FolhaInss> custom({
    Expression<int>? id,
    Expression<String>? competencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (competencia != null) 'competencia': competencia,
    });
  }

  FolhaInsssCompanion copyWith({Value<int?>? id, Value<String?>? competencia}) {
    return FolhaInsssCompanion(
      id: id ?? this.id,
      competencia: competencia ?? this.competencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaInsssCompanion(')
          ..write('id: $id, ')
          ..write('competencia: $competencia')
          ..write(')'))
        .toString();
  }
}

class $FolhaPppsTable extends FolhaPpps
    with TableInfo<$FolhaPppsTable, FolhaPpp> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPppsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idColaborador, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ppp';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaPpp> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPpp map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPpp(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FolhaPppsTable createAlias(String alias) {
    return $FolhaPppsTable(attachedDatabase, alias);
  }
}

class FolhaPpp extends DataClass implements Insertable<FolhaPpp> {
  final int? id;
  final int? idColaborador;
  final String? observacao;
  const FolhaPpp({this.id, this.idColaborador, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FolhaPpp.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPpp(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FolhaPpp copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      FolhaPpp(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPpp(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPpp &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.observacao == this.observacao);
}

class FolhaPppsCompanion extends UpdateCompanion<FolhaPpp> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<String?> observacao;
  const FolhaPppsCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FolhaPppsCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FolhaPpp> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FolhaPppsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<String?>? observacao}) {
    return FolhaPppsCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPppsCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $OperadoraPlanoSaudesTable extends OperadoraPlanoSaudes
    with TableInfo<$OperadoraPlanoSaudesTable, OperadoraPlanoSaude> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OperadoraPlanoSaudesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _registroAnsMeta =
      const VerificationMeta('registroAns');
  @override
  late final GeneratedColumn<String> registroAns = GeneratedColumn<String>(
      'registro_ans', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _classificacaoContabilContaMeta =
      const VerificationMeta('classificacaoContabilConta');
  @override
  late final GeneratedColumn<String> classificacaoContabilConta =
      GeneratedColumn<String>('classificacao_contabil_conta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nome, registroAns, classificacaoContabilConta];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'operadora_plano_saude';
  @override
  VerificationContext validateIntegrity(
      Insertable<OperadoraPlanoSaude> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('registro_ans')) {
      context.handle(
          _registroAnsMeta,
          registroAns.isAcceptableOrUnknown(
              data['registro_ans']!, _registroAnsMeta));
    }
    if (data.containsKey('classificacao_contabil_conta')) {
      context.handle(
          _classificacaoContabilContaMeta,
          classificacaoContabilConta.isAcceptableOrUnknown(
              data['classificacao_contabil_conta']!,
              _classificacaoContabilContaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OperadoraPlanoSaude map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OperadoraPlanoSaude(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      registroAns: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}registro_ans']),
      classificacaoContabilConta: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}classificacao_contabil_conta']),
    );
  }

  @override
  $OperadoraPlanoSaudesTable createAlias(String alias) {
    return $OperadoraPlanoSaudesTable(attachedDatabase, alias);
  }
}

class OperadoraPlanoSaude extends DataClass
    implements Insertable<OperadoraPlanoSaude> {
  final int? id;
  final String? nome;
  final String? registroAns;
  final String? classificacaoContabilConta;
  const OperadoraPlanoSaude(
      {this.id, this.nome, this.registroAns, this.classificacaoContabilConta});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || registroAns != null) {
      map['registro_ans'] = Variable<String>(registroAns);
    }
    if (!nullToAbsent || classificacaoContabilConta != null) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta);
    }
    return map;
  }

  factory OperadoraPlanoSaude.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OperadoraPlanoSaude(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      registroAns: serializer.fromJson<String?>(json['registroAns']),
      classificacaoContabilConta:
          serializer.fromJson<String?>(json['classificacaoContabilConta']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'registroAns': serializer.toJson<String?>(registroAns),
      'classificacaoContabilConta':
          serializer.toJson<String?>(classificacaoContabilConta),
    };
  }

  OperadoraPlanoSaude copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> registroAns = const Value.absent(),
          Value<String?> classificacaoContabilConta = const Value.absent()}) =>
      OperadoraPlanoSaude(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        registroAns: registroAns.present ? registroAns.value : this.registroAns,
        classificacaoContabilConta: classificacaoContabilConta.present
            ? classificacaoContabilConta.value
            : this.classificacaoContabilConta,
      );
  @override
  String toString() {
    return (StringBuffer('OperadoraPlanoSaude(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('registroAns: $registroAns, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, nome, registroAns, classificacaoContabilConta);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OperadoraPlanoSaude &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.registroAns == this.registroAns &&
          other.classificacaoContabilConta == this.classificacaoContabilConta);
}

class OperadoraPlanoSaudesCompanion
    extends UpdateCompanion<OperadoraPlanoSaude> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> registroAns;
  final Value<String?> classificacaoContabilConta;
  const OperadoraPlanoSaudesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.registroAns = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  OperadoraPlanoSaudesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.registroAns = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
  });
  static Insertable<OperadoraPlanoSaude> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? registroAns,
    Expression<String>? classificacaoContabilConta,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (registroAns != null) 'registro_ans': registroAns,
      if (classificacaoContabilConta != null)
        'classificacao_contabil_conta': classificacaoContabilConta,
    });
  }

  OperadoraPlanoSaudesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? registroAns,
      Value<String?>? classificacaoContabilConta}) {
    return OperadoraPlanoSaudesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      registroAns: registroAns ?? this.registroAns,
      classificacaoContabilConta:
          classificacaoContabilConta ?? this.classificacaoContabilConta,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (registroAns.present) {
      map['registro_ans'] = Variable<String>(registroAns.value);
    }
    if (classificacaoContabilConta.present) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OperadoraPlanoSaudesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('registroAns: $registroAns, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta')
          ..write(')'))
        .toString();
  }
}

class $FolhaLancamentoComissaosTable extends FolhaLancamentoComissaos
    with TableInfo<$FolhaLancamentoComissaosTable, FolhaLancamentoComissao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaLancamentoComissaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _vencimentoMeta =
      const VerificationMeta('vencimento');
  @override
  late final GeneratedColumn<DateTime> vencimento = GeneratedColumn<DateTime>(
      'vencimento', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoMeta =
      const VerificationMeta('baseCalculo');
  @override
  late final GeneratedColumn<double> baseCalculo = GeneratedColumn<double>(
      'base_calculo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorComissaoMeta =
      const VerificationMeta('valorComissao');
  @override
  late final GeneratedColumn<double> valorComissao = GeneratedColumn<double>(
      'valor_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, competencia, vencimento, baseCalculo, valorComissao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_lancamento_comissao';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaLancamentoComissao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('vencimento')) {
      context.handle(
          _vencimentoMeta,
          vencimento.isAcceptableOrUnknown(
              data['vencimento']!, _vencimentoMeta));
    }
    if (data.containsKey('base_calculo')) {
      context.handle(
          _baseCalculoMeta,
          baseCalculo.isAcceptableOrUnknown(
              data['base_calculo']!, _baseCalculoMeta));
    }
    if (data.containsKey('valor_comissao')) {
      context.handle(
          _valorComissaoMeta,
          valorComissao.isAcceptableOrUnknown(
              data['valor_comissao']!, _valorComissaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaLancamentoComissao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaLancamentoComissao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      vencimento: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}vencimento']),
      baseCalculo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}base_calculo']),
      valorComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_comissao']),
    );
  }

  @override
  $FolhaLancamentoComissaosTable createAlias(String alias) {
    return $FolhaLancamentoComissaosTable(attachedDatabase, alias);
  }
}

class FolhaLancamentoComissao extends DataClass
    implements Insertable<FolhaLancamentoComissao> {
  final int? id;
  final int? idColaborador;
  final String? competencia;
  final DateTime? vencimento;
  final double? baseCalculo;
  final double? valorComissao;
  const FolhaLancamentoComissao(
      {this.id,
      this.idColaborador,
      this.competencia,
      this.vencimento,
      this.baseCalculo,
      this.valorComissao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || vencimento != null) {
      map['vencimento'] = Variable<DateTime>(vencimento);
    }
    if (!nullToAbsent || baseCalculo != null) {
      map['base_calculo'] = Variable<double>(baseCalculo);
    }
    if (!nullToAbsent || valorComissao != null) {
      map['valor_comissao'] = Variable<double>(valorComissao);
    }
    return map;
  }

  factory FolhaLancamentoComissao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaLancamentoComissao(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      vencimento: serializer.fromJson<DateTime?>(json['vencimento']),
      baseCalculo: serializer.fromJson<double?>(json['baseCalculo']),
      valorComissao: serializer.fromJson<double?>(json['valorComissao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'competencia': serializer.toJson<String?>(competencia),
      'vencimento': serializer.toJson<DateTime?>(vencimento),
      'baseCalculo': serializer.toJson<double?>(baseCalculo),
      'valorComissao': serializer.toJson<double?>(valorComissao),
    };
  }

  FolhaLancamentoComissao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<DateTime?> vencimento = const Value.absent(),
          Value<double?> baseCalculo = const Value.absent(),
          Value<double?> valorComissao = const Value.absent()}) =>
      FolhaLancamentoComissao(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        competencia: competencia.present ? competencia.value : this.competencia,
        vencimento: vencimento.present ? vencimento.value : this.vencimento,
        baseCalculo: baseCalculo.present ? baseCalculo.value : this.baseCalculo,
        valorComissao:
            valorComissao.present ? valorComissao.value : this.valorComissao,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoComissao(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('vencimento: $vencimento, ')
          ..write('baseCalculo: $baseCalculo, ')
          ..write('valorComissao: $valorComissao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idColaborador, competencia, vencimento, baseCalculo, valorComissao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaLancamentoComissao &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.competencia == this.competencia &&
          other.vencimento == this.vencimento &&
          other.baseCalculo == this.baseCalculo &&
          other.valorComissao == this.valorComissao);
}

class FolhaLancamentoComissaosCompanion
    extends UpdateCompanion<FolhaLancamentoComissao> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<String?> competencia;
  final Value<DateTime?> vencimento;
  final Value<double?> baseCalculo;
  final Value<double?> valorComissao;
  const FolhaLancamentoComissaosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.vencimento = const Value.absent(),
    this.baseCalculo = const Value.absent(),
    this.valorComissao = const Value.absent(),
  });
  FolhaLancamentoComissaosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.vencimento = const Value.absent(),
    this.baseCalculo = const Value.absent(),
    this.valorComissao = const Value.absent(),
  });
  static Insertable<FolhaLancamentoComissao> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<String>? competencia,
    Expression<DateTime>? vencimento,
    Expression<double>? baseCalculo,
    Expression<double>? valorComissao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (competencia != null) 'competencia': competencia,
      if (vencimento != null) 'vencimento': vencimento,
      if (baseCalculo != null) 'base_calculo': baseCalculo,
      if (valorComissao != null) 'valor_comissao': valorComissao,
    });
  }

  FolhaLancamentoComissaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<String?>? competencia,
      Value<DateTime?>? vencimento,
      Value<double?>? baseCalculo,
      Value<double?>? valorComissao}) {
    return FolhaLancamentoComissaosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      competencia: competencia ?? this.competencia,
      vencimento: vencimento ?? this.vencimento,
      baseCalculo: baseCalculo ?? this.baseCalculo,
      valorComissao: valorComissao ?? this.valorComissao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (vencimento.present) {
      map['vencimento'] = Variable<DateTime>(vencimento.value);
    }
    if (baseCalculo.present) {
      map['base_calculo'] = Variable<double>(baseCalculo.value);
    }
    if (valorComissao.present) {
      map['valor_comissao'] = Variable<double>(valorComissao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaLancamentoComissaosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('vencimento: $vencimento, ')
          ..write('baseCalculo: $baseCalculo, ')
          ..write('valorComissao: $valorComissao')
          ..write(')'))
        .toString();
  }
}

class $FolhaParametrosTable extends FolhaParametros
    with TableInfo<$FolhaParametrosTable, FolhaParametro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaParametrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contribuiPisMeta =
      const VerificationMeta('contribuiPis');
  @override
  late final GeneratedColumn<String> contribuiPis = GeneratedColumn<String>(
      'contribui_pis', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aliquotaPisMeta =
      const VerificationMeta('aliquotaPis');
  @override
  late final GeneratedColumn<double> aliquotaPis = GeneratedColumn<double>(
      'aliquota_pis', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _discriminarDsrMeta =
      const VerificationMeta('discriminarDsr');
  @override
  late final GeneratedColumn<String> discriminarDsr = GeneratedColumn<String>(
      'discriminar_dsr', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _diaPagamentoMeta =
      const VerificationMeta('diaPagamento');
  @override
  late final GeneratedColumn<String> diaPagamento = GeneratedColumn<String>(
      'dia_pagamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _calculoProporcionalidadeMeta =
      const VerificationMeta('calculoProporcionalidade');
  @override
  late final GeneratedColumn<String> calculoProporcionalidade =
      GeneratedColumn<String>('calculo_proporcionalidade', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _descontarFaltas13Meta =
      const VerificationMeta('descontarFaltas13');
  @override
  late final GeneratedColumn<String> descontarFaltas13 =
      GeneratedColumn<String>('descontar_faltas_13', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pagarAdicionais13Meta =
      const VerificationMeta('pagarAdicionais13');
  @override
  late final GeneratedColumn<String> pagarAdicionais13 =
      GeneratedColumn<String>('pagar_adicionais_13', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pagarEstagiarios13Meta =
      const VerificationMeta('pagarEstagiarios13');
  @override
  late final GeneratedColumn<String> pagarEstagiarios13 =
      GeneratedColumn<String>('pagar_estagiarios_13', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _mesAdiantamento13Meta =
      const VerificationMeta('mesAdiantamento13');
  @override
  late final GeneratedColumn<String> mesAdiantamento13 =
      GeneratedColumn<String>('mes_adiantamento_13', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _percentualAdiantam13Meta =
      const VerificationMeta('percentualAdiantam13');
  @override
  late final GeneratedColumn<double> percentualAdiantam13 =
      GeneratedColumn<double>('percentual_adiantam_13', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _feriasDescontarFaltasMeta =
      const VerificationMeta('feriasDescontarFaltas');
  @override
  late final GeneratedColumn<String> feriasDescontarFaltas =
      GeneratedColumn<String>('ferias_descontar_faltas', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _feriasPagarAdicionaisMeta =
      const VerificationMeta('feriasPagarAdicionais');
  @override
  late final GeneratedColumn<String> feriasPagarAdicionais =
      GeneratedColumn<String>('ferias_pagar_adicionais', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _feriasAdiantar13Meta =
      const VerificationMeta('feriasAdiantar13');
  @override
  late final GeneratedColumn<String> feriasAdiantar13 = GeneratedColumn<String>(
      'ferias_adiantar_13', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _feriasPagarEstagiariosMeta =
      const VerificationMeta('feriasPagarEstagiarios');
  @override
  late final GeneratedColumn<String> feriasPagarEstagiarios =
      GeneratedColumn<String>('ferias_pagar_estagiarios', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _feriasCalcJustaCausaMeta =
      const VerificationMeta('feriasCalcJustaCausa');
  @override
  late final GeneratedColumn<String> feriasCalcJustaCausa =
      GeneratedColumn<String>(
          'ferias_calc_justa_causa', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _feriasMovimentoMensalMeta =
      const VerificationMeta('feriasMovimentoMensal');
  @override
  late final GeneratedColumn<String> feriasMovimentoMensal =
      GeneratedColumn<String>('ferias_movimento_mensal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        competencia,
        contribuiPis,
        aliquotaPis,
        discriminarDsr,
        diaPagamento,
        calculoProporcionalidade,
        descontarFaltas13,
        pagarAdicionais13,
        pagarEstagiarios13,
        mesAdiantamento13,
        percentualAdiantam13,
        feriasDescontarFaltas,
        feriasPagarAdicionais,
        feriasAdiantar13,
        feriasPagarEstagiarios,
        feriasCalcJustaCausa,
        feriasMovimentoMensal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_parametro';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaParametro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('contribui_pis')) {
      context.handle(
          _contribuiPisMeta,
          contribuiPis.isAcceptableOrUnknown(
              data['contribui_pis']!, _contribuiPisMeta));
    }
    if (data.containsKey('aliquota_pis')) {
      context.handle(
          _aliquotaPisMeta,
          aliquotaPis.isAcceptableOrUnknown(
              data['aliquota_pis']!, _aliquotaPisMeta));
    }
    if (data.containsKey('discriminar_dsr')) {
      context.handle(
          _discriminarDsrMeta,
          discriminarDsr.isAcceptableOrUnknown(
              data['discriminar_dsr']!, _discriminarDsrMeta));
    }
    if (data.containsKey('dia_pagamento')) {
      context.handle(
          _diaPagamentoMeta,
          diaPagamento.isAcceptableOrUnknown(
              data['dia_pagamento']!, _diaPagamentoMeta));
    }
    if (data.containsKey('calculo_proporcionalidade')) {
      context.handle(
          _calculoProporcionalidadeMeta,
          calculoProporcionalidade.isAcceptableOrUnknown(
              data['calculo_proporcionalidade']!,
              _calculoProporcionalidadeMeta));
    }
    if (data.containsKey('descontar_faltas_13')) {
      context.handle(
          _descontarFaltas13Meta,
          descontarFaltas13.isAcceptableOrUnknown(
              data['descontar_faltas_13']!, _descontarFaltas13Meta));
    }
    if (data.containsKey('pagar_adicionais_13')) {
      context.handle(
          _pagarAdicionais13Meta,
          pagarAdicionais13.isAcceptableOrUnknown(
              data['pagar_adicionais_13']!, _pagarAdicionais13Meta));
    }
    if (data.containsKey('pagar_estagiarios_13')) {
      context.handle(
          _pagarEstagiarios13Meta,
          pagarEstagiarios13.isAcceptableOrUnknown(
              data['pagar_estagiarios_13']!, _pagarEstagiarios13Meta));
    }
    if (data.containsKey('mes_adiantamento_13')) {
      context.handle(
          _mesAdiantamento13Meta,
          mesAdiantamento13.isAcceptableOrUnknown(
              data['mes_adiantamento_13']!, _mesAdiantamento13Meta));
    }
    if (data.containsKey('percentual_adiantam_13')) {
      context.handle(
          _percentualAdiantam13Meta,
          percentualAdiantam13.isAcceptableOrUnknown(
              data['percentual_adiantam_13']!, _percentualAdiantam13Meta));
    }
    if (data.containsKey('ferias_descontar_faltas')) {
      context.handle(
          _feriasDescontarFaltasMeta,
          feriasDescontarFaltas.isAcceptableOrUnknown(
              data['ferias_descontar_faltas']!, _feriasDescontarFaltasMeta));
    }
    if (data.containsKey('ferias_pagar_adicionais')) {
      context.handle(
          _feriasPagarAdicionaisMeta,
          feriasPagarAdicionais.isAcceptableOrUnknown(
              data['ferias_pagar_adicionais']!, _feriasPagarAdicionaisMeta));
    }
    if (data.containsKey('ferias_adiantar_13')) {
      context.handle(
          _feriasAdiantar13Meta,
          feriasAdiantar13.isAcceptableOrUnknown(
              data['ferias_adiantar_13']!, _feriasAdiantar13Meta));
    }
    if (data.containsKey('ferias_pagar_estagiarios')) {
      context.handle(
          _feriasPagarEstagiariosMeta,
          feriasPagarEstagiarios.isAcceptableOrUnknown(
              data['ferias_pagar_estagiarios']!, _feriasPagarEstagiariosMeta));
    }
    if (data.containsKey('ferias_calc_justa_causa')) {
      context.handle(
          _feriasCalcJustaCausaMeta,
          feriasCalcJustaCausa.isAcceptableOrUnknown(
              data['ferias_calc_justa_causa']!, _feriasCalcJustaCausaMeta));
    }
    if (data.containsKey('ferias_movimento_mensal')) {
      context.handle(
          _feriasMovimentoMensalMeta,
          feriasMovimentoMensal.isAcceptableOrUnknown(
              data['ferias_movimento_mensal']!, _feriasMovimentoMensalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaParametro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaParametro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      contribuiPis: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contribui_pis']),
      aliquotaPis: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota_pis']),
      discriminarDsr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}discriminar_dsr']),
      diaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}dia_pagamento']),
      calculoProporcionalidade: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}calculo_proporcionalidade']),
      descontarFaltas13: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}descontar_faltas_13']),
      pagarAdicionais13: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}pagar_adicionais_13']),
      pagarEstagiarios13: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}pagar_estagiarios_13']),
      mesAdiantamento13: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}mes_adiantamento_13']),
      percentualAdiantam13: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_adiantam_13']),
      feriasDescontarFaltas: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}ferias_descontar_faltas']),
      feriasPagarAdicionais: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}ferias_pagar_adicionais']),
      feriasAdiantar13: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}ferias_adiantar_13']),
      feriasPagarEstagiarios: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}ferias_pagar_estagiarios']),
      feriasCalcJustaCausa: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}ferias_calc_justa_causa']),
      feriasMovimentoMensal: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}ferias_movimento_mensal']),
    );
  }

  @override
  $FolhaParametrosTable createAlias(String alias) {
    return $FolhaParametrosTable(attachedDatabase, alias);
  }
}

class FolhaParametro extends DataClass implements Insertable<FolhaParametro> {
  final int? id;
  final String? competencia;
  final String? contribuiPis;
  final double? aliquotaPis;
  final String? discriminarDsr;
  final String? diaPagamento;
  final String? calculoProporcionalidade;
  final String? descontarFaltas13;
  final String? pagarAdicionais13;
  final String? pagarEstagiarios13;
  final String? mesAdiantamento13;
  final double? percentualAdiantam13;
  final String? feriasDescontarFaltas;
  final String? feriasPagarAdicionais;
  final String? feriasAdiantar13;
  final String? feriasPagarEstagiarios;
  final String? feriasCalcJustaCausa;
  final String? feriasMovimentoMensal;
  const FolhaParametro(
      {this.id,
      this.competencia,
      this.contribuiPis,
      this.aliquotaPis,
      this.discriminarDsr,
      this.diaPagamento,
      this.calculoProporcionalidade,
      this.descontarFaltas13,
      this.pagarAdicionais13,
      this.pagarEstagiarios13,
      this.mesAdiantamento13,
      this.percentualAdiantam13,
      this.feriasDescontarFaltas,
      this.feriasPagarAdicionais,
      this.feriasAdiantar13,
      this.feriasPagarEstagiarios,
      this.feriasCalcJustaCausa,
      this.feriasMovimentoMensal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || contribuiPis != null) {
      map['contribui_pis'] = Variable<String>(contribuiPis);
    }
    if (!nullToAbsent || aliquotaPis != null) {
      map['aliquota_pis'] = Variable<double>(aliquotaPis);
    }
    if (!nullToAbsent || discriminarDsr != null) {
      map['discriminar_dsr'] = Variable<String>(discriminarDsr);
    }
    if (!nullToAbsent || diaPagamento != null) {
      map['dia_pagamento'] = Variable<String>(diaPagamento);
    }
    if (!nullToAbsent || calculoProporcionalidade != null) {
      map['calculo_proporcionalidade'] =
          Variable<String>(calculoProporcionalidade);
    }
    if (!nullToAbsent || descontarFaltas13 != null) {
      map['descontar_faltas_13'] = Variable<String>(descontarFaltas13);
    }
    if (!nullToAbsent || pagarAdicionais13 != null) {
      map['pagar_adicionais_13'] = Variable<String>(pagarAdicionais13);
    }
    if (!nullToAbsent || pagarEstagiarios13 != null) {
      map['pagar_estagiarios_13'] = Variable<String>(pagarEstagiarios13);
    }
    if (!nullToAbsent || mesAdiantamento13 != null) {
      map['mes_adiantamento_13'] = Variable<String>(mesAdiantamento13);
    }
    if (!nullToAbsent || percentualAdiantam13 != null) {
      map['percentual_adiantam_13'] = Variable<double>(percentualAdiantam13);
    }
    if (!nullToAbsent || feriasDescontarFaltas != null) {
      map['ferias_descontar_faltas'] = Variable<String>(feriasDescontarFaltas);
    }
    if (!nullToAbsent || feriasPagarAdicionais != null) {
      map['ferias_pagar_adicionais'] = Variable<String>(feriasPagarAdicionais);
    }
    if (!nullToAbsent || feriasAdiantar13 != null) {
      map['ferias_adiantar_13'] = Variable<String>(feriasAdiantar13);
    }
    if (!nullToAbsent || feriasPagarEstagiarios != null) {
      map['ferias_pagar_estagiarios'] =
          Variable<String>(feriasPagarEstagiarios);
    }
    if (!nullToAbsent || feriasCalcJustaCausa != null) {
      map['ferias_calc_justa_causa'] = Variable<String>(feriasCalcJustaCausa);
    }
    if (!nullToAbsent || feriasMovimentoMensal != null) {
      map['ferias_movimento_mensal'] = Variable<String>(feriasMovimentoMensal);
    }
    return map;
  }

  factory FolhaParametro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaParametro(
      id: serializer.fromJson<int?>(json['id']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      contribuiPis: serializer.fromJson<String?>(json['contribuiPis']),
      aliquotaPis: serializer.fromJson<double?>(json['aliquotaPis']),
      discriminarDsr: serializer.fromJson<String?>(json['discriminarDsr']),
      diaPagamento: serializer.fromJson<String?>(json['diaPagamento']),
      calculoProporcionalidade:
          serializer.fromJson<String?>(json['calculoProporcionalidade']),
      descontarFaltas13:
          serializer.fromJson<String?>(json['descontarFaltas13']),
      pagarAdicionais13:
          serializer.fromJson<String?>(json['pagarAdicionais13']),
      pagarEstagiarios13:
          serializer.fromJson<String?>(json['pagarEstagiarios13']),
      mesAdiantamento13:
          serializer.fromJson<String?>(json['mesAdiantamento13']),
      percentualAdiantam13:
          serializer.fromJson<double?>(json['percentualAdiantam13']),
      feriasDescontarFaltas:
          serializer.fromJson<String?>(json['feriasDescontarFaltas']),
      feriasPagarAdicionais:
          serializer.fromJson<String?>(json['feriasPagarAdicionais']),
      feriasAdiantar13: serializer.fromJson<String?>(json['feriasAdiantar13']),
      feriasPagarEstagiarios:
          serializer.fromJson<String?>(json['feriasPagarEstagiarios']),
      feriasCalcJustaCausa:
          serializer.fromJson<String?>(json['feriasCalcJustaCausa']),
      feriasMovimentoMensal:
          serializer.fromJson<String?>(json['feriasMovimentoMensal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'competencia': serializer.toJson<String?>(competencia),
      'contribuiPis': serializer.toJson<String?>(contribuiPis),
      'aliquotaPis': serializer.toJson<double?>(aliquotaPis),
      'discriminarDsr': serializer.toJson<String?>(discriminarDsr),
      'diaPagamento': serializer.toJson<String?>(diaPagamento),
      'calculoProporcionalidade':
          serializer.toJson<String?>(calculoProporcionalidade),
      'descontarFaltas13': serializer.toJson<String?>(descontarFaltas13),
      'pagarAdicionais13': serializer.toJson<String?>(pagarAdicionais13),
      'pagarEstagiarios13': serializer.toJson<String?>(pagarEstagiarios13),
      'mesAdiantamento13': serializer.toJson<String?>(mesAdiantamento13),
      'percentualAdiantam13': serializer.toJson<double?>(percentualAdiantam13),
      'feriasDescontarFaltas':
          serializer.toJson<String?>(feriasDescontarFaltas),
      'feriasPagarAdicionais':
          serializer.toJson<String?>(feriasPagarAdicionais),
      'feriasAdiantar13': serializer.toJson<String?>(feriasAdiantar13),
      'feriasPagarEstagiarios':
          serializer.toJson<String?>(feriasPagarEstagiarios),
      'feriasCalcJustaCausa': serializer.toJson<String?>(feriasCalcJustaCausa),
      'feriasMovimentoMensal':
          serializer.toJson<String?>(feriasMovimentoMensal),
    };
  }

  FolhaParametro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<String?> contribuiPis = const Value.absent(),
          Value<double?> aliquotaPis = const Value.absent(),
          Value<String?> discriminarDsr = const Value.absent(),
          Value<String?> diaPagamento = const Value.absent(),
          Value<String?> calculoProporcionalidade = const Value.absent(),
          Value<String?> descontarFaltas13 = const Value.absent(),
          Value<String?> pagarAdicionais13 = const Value.absent(),
          Value<String?> pagarEstagiarios13 = const Value.absent(),
          Value<String?> mesAdiantamento13 = const Value.absent(),
          Value<double?> percentualAdiantam13 = const Value.absent(),
          Value<String?> feriasDescontarFaltas = const Value.absent(),
          Value<String?> feriasPagarAdicionais = const Value.absent(),
          Value<String?> feriasAdiantar13 = const Value.absent(),
          Value<String?> feriasPagarEstagiarios = const Value.absent(),
          Value<String?> feriasCalcJustaCausa = const Value.absent(),
          Value<String?> feriasMovimentoMensal = const Value.absent()}) =>
      FolhaParametro(
        id: id.present ? id.value : this.id,
        competencia: competencia.present ? competencia.value : this.competencia,
        contribuiPis:
            contribuiPis.present ? contribuiPis.value : this.contribuiPis,
        aliquotaPis: aliquotaPis.present ? aliquotaPis.value : this.aliquotaPis,
        discriminarDsr:
            discriminarDsr.present ? discriminarDsr.value : this.discriminarDsr,
        diaPagamento:
            diaPagamento.present ? diaPagamento.value : this.diaPagamento,
        calculoProporcionalidade: calculoProporcionalidade.present
            ? calculoProporcionalidade.value
            : this.calculoProporcionalidade,
        descontarFaltas13: descontarFaltas13.present
            ? descontarFaltas13.value
            : this.descontarFaltas13,
        pagarAdicionais13: pagarAdicionais13.present
            ? pagarAdicionais13.value
            : this.pagarAdicionais13,
        pagarEstagiarios13: pagarEstagiarios13.present
            ? pagarEstagiarios13.value
            : this.pagarEstagiarios13,
        mesAdiantamento13: mesAdiantamento13.present
            ? mesAdiantamento13.value
            : this.mesAdiantamento13,
        percentualAdiantam13: percentualAdiantam13.present
            ? percentualAdiantam13.value
            : this.percentualAdiantam13,
        feriasDescontarFaltas: feriasDescontarFaltas.present
            ? feriasDescontarFaltas.value
            : this.feriasDescontarFaltas,
        feriasPagarAdicionais: feriasPagarAdicionais.present
            ? feriasPagarAdicionais.value
            : this.feriasPagarAdicionais,
        feriasAdiantar13: feriasAdiantar13.present
            ? feriasAdiantar13.value
            : this.feriasAdiantar13,
        feriasPagarEstagiarios: feriasPagarEstagiarios.present
            ? feriasPagarEstagiarios.value
            : this.feriasPagarEstagiarios,
        feriasCalcJustaCausa: feriasCalcJustaCausa.present
            ? feriasCalcJustaCausa.value
            : this.feriasCalcJustaCausa,
        feriasMovimentoMensal: feriasMovimentoMensal.present
            ? feriasMovimentoMensal.value
            : this.feriasMovimentoMensal,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaParametro(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('contribuiPis: $contribuiPis, ')
          ..write('aliquotaPis: $aliquotaPis, ')
          ..write('discriminarDsr: $discriminarDsr, ')
          ..write('diaPagamento: $diaPagamento, ')
          ..write('calculoProporcionalidade: $calculoProporcionalidade, ')
          ..write('descontarFaltas13: $descontarFaltas13, ')
          ..write('pagarAdicionais13: $pagarAdicionais13, ')
          ..write('pagarEstagiarios13: $pagarEstagiarios13, ')
          ..write('mesAdiantamento13: $mesAdiantamento13, ')
          ..write('percentualAdiantam13: $percentualAdiantam13, ')
          ..write('feriasDescontarFaltas: $feriasDescontarFaltas, ')
          ..write('feriasPagarAdicionais: $feriasPagarAdicionais, ')
          ..write('feriasAdiantar13: $feriasAdiantar13, ')
          ..write('feriasPagarEstagiarios: $feriasPagarEstagiarios, ')
          ..write('feriasCalcJustaCausa: $feriasCalcJustaCausa, ')
          ..write('feriasMovimentoMensal: $feriasMovimentoMensal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      competencia,
      contribuiPis,
      aliquotaPis,
      discriminarDsr,
      diaPagamento,
      calculoProporcionalidade,
      descontarFaltas13,
      pagarAdicionais13,
      pagarEstagiarios13,
      mesAdiantamento13,
      percentualAdiantam13,
      feriasDescontarFaltas,
      feriasPagarAdicionais,
      feriasAdiantar13,
      feriasPagarEstagiarios,
      feriasCalcJustaCausa,
      feriasMovimentoMensal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaParametro &&
          other.id == this.id &&
          other.competencia == this.competencia &&
          other.contribuiPis == this.contribuiPis &&
          other.aliquotaPis == this.aliquotaPis &&
          other.discriminarDsr == this.discriminarDsr &&
          other.diaPagamento == this.diaPagamento &&
          other.calculoProporcionalidade == this.calculoProporcionalidade &&
          other.descontarFaltas13 == this.descontarFaltas13 &&
          other.pagarAdicionais13 == this.pagarAdicionais13 &&
          other.pagarEstagiarios13 == this.pagarEstagiarios13 &&
          other.mesAdiantamento13 == this.mesAdiantamento13 &&
          other.percentualAdiantam13 == this.percentualAdiantam13 &&
          other.feriasDescontarFaltas == this.feriasDescontarFaltas &&
          other.feriasPagarAdicionais == this.feriasPagarAdicionais &&
          other.feriasAdiantar13 == this.feriasAdiantar13 &&
          other.feriasPagarEstagiarios == this.feriasPagarEstagiarios &&
          other.feriasCalcJustaCausa == this.feriasCalcJustaCausa &&
          other.feriasMovimentoMensal == this.feriasMovimentoMensal);
}

class FolhaParametrosCompanion extends UpdateCompanion<FolhaParametro> {
  final Value<int?> id;
  final Value<String?> competencia;
  final Value<String?> contribuiPis;
  final Value<double?> aliquotaPis;
  final Value<String?> discriminarDsr;
  final Value<String?> diaPagamento;
  final Value<String?> calculoProporcionalidade;
  final Value<String?> descontarFaltas13;
  final Value<String?> pagarAdicionais13;
  final Value<String?> pagarEstagiarios13;
  final Value<String?> mesAdiantamento13;
  final Value<double?> percentualAdiantam13;
  final Value<String?> feriasDescontarFaltas;
  final Value<String?> feriasPagarAdicionais;
  final Value<String?> feriasAdiantar13;
  final Value<String?> feriasPagarEstagiarios;
  final Value<String?> feriasCalcJustaCausa;
  final Value<String?> feriasMovimentoMensal;
  const FolhaParametrosCompanion({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.contribuiPis = const Value.absent(),
    this.aliquotaPis = const Value.absent(),
    this.discriminarDsr = const Value.absent(),
    this.diaPagamento = const Value.absent(),
    this.calculoProporcionalidade = const Value.absent(),
    this.descontarFaltas13 = const Value.absent(),
    this.pagarAdicionais13 = const Value.absent(),
    this.pagarEstagiarios13 = const Value.absent(),
    this.mesAdiantamento13 = const Value.absent(),
    this.percentualAdiantam13 = const Value.absent(),
    this.feriasDescontarFaltas = const Value.absent(),
    this.feriasPagarAdicionais = const Value.absent(),
    this.feriasAdiantar13 = const Value.absent(),
    this.feriasPagarEstagiarios = const Value.absent(),
    this.feriasCalcJustaCausa = const Value.absent(),
    this.feriasMovimentoMensal = const Value.absent(),
  });
  FolhaParametrosCompanion.insert({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.contribuiPis = const Value.absent(),
    this.aliquotaPis = const Value.absent(),
    this.discriminarDsr = const Value.absent(),
    this.diaPagamento = const Value.absent(),
    this.calculoProporcionalidade = const Value.absent(),
    this.descontarFaltas13 = const Value.absent(),
    this.pagarAdicionais13 = const Value.absent(),
    this.pagarEstagiarios13 = const Value.absent(),
    this.mesAdiantamento13 = const Value.absent(),
    this.percentualAdiantam13 = const Value.absent(),
    this.feriasDescontarFaltas = const Value.absent(),
    this.feriasPagarAdicionais = const Value.absent(),
    this.feriasAdiantar13 = const Value.absent(),
    this.feriasPagarEstagiarios = const Value.absent(),
    this.feriasCalcJustaCausa = const Value.absent(),
    this.feriasMovimentoMensal = const Value.absent(),
  });
  static Insertable<FolhaParametro> custom({
    Expression<int>? id,
    Expression<String>? competencia,
    Expression<String>? contribuiPis,
    Expression<double>? aliquotaPis,
    Expression<String>? discriminarDsr,
    Expression<String>? diaPagamento,
    Expression<String>? calculoProporcionalidade,
    Expression<String>? descontarFaltas13,
    Expression<String>? pagarAdicionais13,
    Expression<String>? pagarEstagiarios13,
    Expression<String>? mesAdiantamento13,
    Expression<double>? percentualAdiantam13,
    Expression<String>? feriasDescontarFaltas,
    Expression<String>? feriasPagarAdicionais,
    Expression<String>? feriasAdiantar13,
    Expression<String>? feriasPagarEstagiarios,
    Expression<String>? feriasCalcJustaCausa,
    Expression<String>? feriasMovimentoMensal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (competencia != null) 'competencia': competencia,
      if (contribuiPis != null) 'contribui_pis': contribuiPis,
      if (aliquotaPis != null) 'aliquota_pis': aliquotaPis,
      if (discriminarDsr != null) 'discriminar_dsr': discriminarDsr,
      if (diaPagamento != null) 'dia_pagamento': diaPagamento,
      if (calculoProporcionalidade != null)
        'calculo_proporcionalidade': calculoProporcionalidade,
      if (descontarFaltas13 != null) 'descontar_faltas_13': descontarFaltas13,
      if (pagarAdicionais13 != null) 'pagar_adicionais_13': pagarAdicionais13,
      if (pagarEstagiarios13 != null)
        'pagar_estagiarios_13': pagarEstagiarios13,
      if (mesAdiantamento13 != null) 'mes_adiantamento_13': mesAdiantamento13,
      if (percentualAdiantam13 != null)
        'percentual_adiantam_13': percentualAdiantam13,
      if (feriasDescontarFaltas != null)
        'ferias_descontar_faltas': feriasDescontarFaltas,
      if (feriasPagarAdicionais != null)
        'ferias_pagar_adicionais': feriasPagarAdicionais,
      if (feriasAdiantar13 != null) 'ferias_adiantar_13': feriasAdiantar13,
      if (feriasPagarEstagiarios != null)
        'ferias_pagar_estagiarios': feriasPagarEstagiarios,
      if (feriasCalcJustaCausa != null)
        'ferias_calc_justa_causa': feriasCalcJustaCausa,
      if (feriasMovimentoMensal != null)
        'ferias_movimento_mensal': feriasMovimentoMensal,
    });
  }

  FolhaParametrosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? competencia,
      Value<String?>? contribuiPis,
      Value<double?>? aliquotaPis,
      Value<String?>? discriminarDsr,
      Value<String?>? diaPagamento,
      Value<String?>? calculoProporcionalidade,
      Value<String?>? descontarFaltas13,
      Value<String?>? pagarAdicionais13,
      Value<String?>? pagarEstagiarios13,
      Value<String?>? mesAdiantamento13,
      Value<double?>? percentualAdiantam13,
      Value<String?>? feriasDescontarFaltas,
      Value<String?>? feriasPagarAdicionais,
      Value<String?>? feriasAdiantar13,
      Value<String?>? feriasPagarEstagiarios,
      Value<String?>? feriasCalcJustaCausa,
      Value<String?>? feriasMovimentoMensal}) {
    return FolhaParametrosCompanion(
      id: id ?? this.id,
      competencia: competencia ?? this.competencia,
      contribuiPis: contribuiPis ?? this.contribuiPis,
      aliquotaPis: aliquotaPis ?? this.aliquotaPis,
      discriminarDsr: discriminarDsr ?? this.discriminarDsr,
      diaPagamento: diaPagamento ?? this.diaPagamento,
      calculoProporcionalidade:
          calculoProporcionalidade ?? this.calculoProporcionalidade,
      descontarFaltas13: descontarFaltas13 ?? this.descontarFaltas13,
      pagarAdicionais13: pagarAdicionais13 ?? this.pagarAdicionais13,
      pagarEstagiarios13: pagarEstagiarios13 ?? this.pagarEstagiarios13,
      mesAdiantamento13: mesAdiantamento13 ?? this.mesAdiantamento13,
      percentualAdiantam13: percentualAdiantam13 ?? this.percentualAdiantam13,
      feriasDescontarFaltas:
          feriasDescontarFaltas ?? this.feriasDescontarFaltas,
      feriasPagarAdicionais:
          feriasPagarAdicionais ?? this.feriasPagarAdicionais,
      feriasAdiantar13: feriasAdiantar13 ?? this.feriasAdiantar13,
      feriasPagarEstagiarios:
          feriasPagarEstagiarios ?? this.feriasPagarEstagiarios,
      feriasCalcJustaCausa: feriasCalcJustaCausa ?? this.feriasCalcJustaCausa,
      feriasMovimentoMensal:
          feriasMovimentoMensal ?? this.feriasMovimentoMensal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (contribuiPis.present) {
      map['contribui_pis'] = Variable<String>(contribuiPis.value);
    }
    if (aliquotaPis.present) {
      map['aliquota_pis'] = Variable<double>(aliquotaPis.value);
    }
    if (discriminarDsr.present) {
      map['discriminar_dsr'] = Variable<String>(discriminarDsr.value);
    }
    if (diaPagamento.present) {
      map['dia_pagamento'] = Variable<String>(diaPagamento.value);
    }
    if (calculoProporcionalidade.present) {
      map['calculo_proporcionalidade'] =
          Variable<String>(calculoProporcionalidade.value);
    }
    if (descontarFaltas13.present) {
      map['descontar_faltas_13'] = Variable<String>(descontarFaltas13.value);
    }
    if (pagarAdicionais13.present) {
      map['pagar_adicionais_13'] = Variable<String>(pagarAdicionais13.value);
    }
    if (pagarEstagiarios13.present) {
      map['pagar_estagiarios_13'] = Variable<String>(pagarEstagiarios13.value);
    }
    if (mesAdiantamento13.present) {
      map['mes_adiantamento_13'] = Variable<String>(mesAdiantamento13.value);
    }
    if (percentualAdiantam13.present) {
      map['percentual_adiantam_13'] =
          Variable<double>(percentualAdiantam13.value);
    }
    if (feriasDescontarFaltas.present) {
      map['ferias_descontar_faltas'] =
          Variable<String>(feriasDescontarFaltas.value);
    }
    if (feriasPagarAdicionais.present) {
      map['ferias_pagar_adicionais'] =
          Variable<String>(feriasPagarAdicionais.value);
    }
    if (feriasAdiantar13.present) {
      map['ferias_adiantar_13'] = Variable<String>(feriasAdiantar13.value);
    }
    if (feriasPagarEstagiarios.present) {
      map['ferias_pagar_estagiarios'] =
          Variable<String>(feriasPagarEstagiarios.value);
    }
    if (feriasCalcJustaCausa.present) {
      map['ferias_calc_justa_causa'] =
          Variable<String>(feriasCalcJustaCausa.value);
    }
    if (feriasMovimentoMensal.present) {
      map['ferias_movimento_mensal'] =
          Variable<String>(feriasMovimentoMensal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaParametrosCompanion(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('contribuiPis: $contribuiPis, ')
          ..write('aliquotaPis: $aliquotaPis, ')
          ..write('discriminarDsr: $discriminarDsr, ')
          ..write('diaPagamento: $diaPagamento, ')
          ..write('calculoProporcionalidade: $calculoProporcionalidade, ')
          ..write('descontarFaltas13: $descontarFaltas13, ')
          ..write('pagarAdicionais13: $pagarAdicionais13, ')
          ..write('pagarEstagiarios13: $pagarEstagiarios13, ')
          ..write('mesAdiantamento13: $mesAdiantamento13, ')
          ..write('percentualAdiantam13: $percentualAdiantam13, ')
          ..write('feriasDescontarFaltas: $feriasDescontarFaltas, ')
          ..write('feriasPagarAdicionais: $feriasPagarAdicionais, ')
          ..write('feriasAdiantar13: $feriasAdiantar13, ')
          ..write('feriasPagarEstagiarios: $feriasPagarEstagiarios, ')
          ..write('feriasCalcJustaCausa: $feriasCalcJustaCausa, ')
          ..write('feriasMovimentoMensal: $feriasMovimentoMensal')
          ..write(')'))
        .toString();
  }
}

class $GuiasAcumuladassTable extends GuiasAcumuladass
    with TableInfo<$GuiasAcumuladassTable, GuiasAcumuladas> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GuiasAcumuladassTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _gpsTipoMeta =
      const VerificationMeta('gpsTipo');
  @override
  late final GeneratedColumn<String> gpsTipo = GeneratedColumn<String>(
      'gps_tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gpsCompetenciaMeta =
      const VerificationMeta('gpsCompetencia');
  @override
  late final GeneratedColumn<String> gpsCompetencia = GeneratedColumn<String>(
      'gps_competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gpsValorInssMeta =
      const VerificationMeta('gpsValorInss');
  @override
  late final GeneratedColumn<double> gpsValorInss = GeneratedColumn<double>(
      'gps_valor_inss', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _gpsValorOutrasEntMeta =
      const VerificationMeta('gpsValorOutrasEnt');
  @override
  late final GeneratedColumn<double> gpsValorOutrasEnt =
      GeneratedColumn<double>('gps_valor_outras_ent', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _gpsDataPagamentoMeta =
      const VerificationMeta('gpsDataPagamento');
  @override
  late final GeneratedColumn<DateTime> gpsDataPagamento =
      GeneratedColumn<DateTime>('gps_data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _irrfCompetenciaMeta =
      const VerificationMeta('irrfCompetencia');
  @override
  late final GeneratedColumn<String> irrfCompetencia = GeneratedColumn<String>(
      'irrf_competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _irrfCodigoRecolhimentoMeta =
      const VerificationMeta('irrfCodigoRecolhimento');
  @override
  late final GeneratedColumn<int> irrfCodigoRecolhimento = GeneratedColumn<int>(
      'irrf_codigo_recolhimento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _irrfValorAcumuladoMeta =
      const VerificationMeta('irrfValorAcumulado');
  @override
  late final GeneratedColumn<double> irrfValorAcumulado =
      GeneratedColumn<double>('irrf_valor_acumulado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _irrfDataPagamentoMeta =
      const VerificationMeta('irrfDataPagamento');
  @override
  late final GeneratedColumn<DateTime> irrfDataPagamento =
      GeneratedColumn<DateTime>('irrf_data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _pisCompetenciaMeta =
      const VerificationMeta('pisCompetencia');
  @override
  late final GeneratedColumn<String> pisCompetencia = GeneratedColumn<String>(
      'pis_competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _pisValorAcumuladoMeta =
      const VerificationMeta('pisValorAcumulado');
  @override
  late final GeneratedColumn<double> pisValorAcumulado =
      GeneratedColumn<double>('pis_valor_acumulado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pisDataPagamentoMeta =
      const VerificationMeta('pisDataPagamento');
  @override
  late final GeneratedColumn<DateTime> pisDataPagamento =
      GeneratedColumn<DateTime>('pis_data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        gpsTipo,
        gpsCompetencia,
        gpsValorInss,
        gpsValorOutrasEnt,
        gpsDataPagamento,
        irrfCompetencia,
        irrfCodigoRecolhimento,
        irrfValorAcumulado,
        irrfDataPagamento,
        pisCompetencia,
        pisValorAcumulado,
        pisDataPagamento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'guias_acumuladas';
  @override
  VerificationContext validateIntegrity(Insertable<GuiasAcumuladas> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('gps_tipo')) {
      context.handle(_gpsTipoMeta,
          gpsTipo.isAcceptableOrUnknown(data['gps_tipo']!, _gpsTipoMeta));
    }
    if (data.containsKey('gps_competencia')) {
      context.handle(
          _gpsCompetenciaMeta,
          gpsCompetencia.isAcceptableOrUnknown(
              data['gps_competencia']!, _gpsCompetenciaMeta));
    }
    if (data.containsKey('gps_valor_inss')) {
      context.handle(
          _gpsValorInssMeta,
          gpsValorInss.isAcceptableOrUnknown(
              data['gps_valor_inss']!, _gpsValorInssMeta));
    }
    if (data.containsKey('gps_valor_outras_ent')) {
      context.handle(
          _gpsValorOutrasEntMeta,
          gpsValorOutrasEnt.isAcceptableOrUnknown(
              data['gps_valor_outras_ent']!, _gpsValorOutrasEntMeta));
    }
    if (data.containsKey('gps_data_pagamento')) {
      context.handle(
          _gpsDataPagamentoMeta,
          gpsDataPagamento.isAcceptableOrUnknown(
              data['gps_data_pagamento']!, _gpsDataPagamentoMeta));
    }
    if (data.containsKey('irrf_competencia')) {
      context.handle(
          _irrfCompetenciaMeta,
          irrfCompetencia.isAcceptableOrUnknown(
              data['irrf_competencia']!, _irrfCompetenciaMeta));
    }
    if (data.containsKey('irrf_codigo_recolhimento')) {
      context.handle(
          _irrfCodigoRecolhimentoMeta,
          irrfCodigoRecolhimento.isAcceptableOrUnknown(
              data['irrf_codigo_recolhimento']!, _irrfCodigoRecolhimentoMeta));
    }
    if (data.containsKey('irrf_valor_acumulado')) {
      context.handle(
          _irrfValorAcumuladoMeta,
          irrfValorAcumulado.isAcceptableOrUnknown(
              data['irrf_valor_acumulado']!, _irrfValorAcumuladoMeta));
    }
    if (data.containsKey('irrf_data_pagamento')) {
      context.handle(
          _irrfDataPagamentoMeta,
          irrfDataPagamento.isAcceptableOrUnknown(
              data['irrf_data_pagamento']!, _irrfDataPagamentoMeta));
    }
    if (data.containsKey('pis_competencia')) {
      context.handle(
          _pisCompetenciaMeta,
          pisCompetencia.isAcceptableOrUnknown(
              data['pis_competencia']!, _pisCompetenciaMeta));
    }
    if (data.containsKey('pis_valor_acumulado')) {
      context.handle(
          _pisValorAcumuladoMeta,
          pisValorAcumulado.isAcceptableOrUnknown(
              data['pis_valor_acumulado']!, _pisValorAcumuladoMeta));
    }
    if (data.containsKey('pis_data_pagamento')) {
      context.handle(
          _pisDataPagamentoMeta,
          pisDataPagamento.isAcceptableOrUnknown(
              data['pis_data_pagamento']!, _pisDataPagamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GuiasAcumuladas map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GuiasAcumuladas(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      gpsTipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gps_tipo']),
      gpsCompetencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gps_competencia']),
      gpsValorInss: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}gps_valor_inss']),
      gpsValorOutrasEnt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}gps_valor_outras_ent']),
      gpsDataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}gps_data_pagamento']),
      irrfCompetencia: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}irrf_competencia']),
      irrfCodigoRecolhimento: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}irrf_codigo_recolhimento']),
      irrfValorAcumulado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}irrf_valor_acumulado']),
      irrfDataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}irrf_data_pagamento']),
      pisCompetencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pis_competencia']),
      pisValorAcumulado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}pis_valor_acumulado']),
      pisDataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}pis_data_pagamento']),
    );
  }

  @override
  $GuiasAcumuladassTable createAlias(String alias) {
    return $GuiasAcumuladassTable(attachedDatabase, alias);
  }
}

class GuiasAcumuladas extends DataClass implements Insertable<GuiasAcumuladas> {
  final int? id;
  final String? gpsTipo;
  final String? gpsCompetencia;
  final double? gpsValorInss;
  final double? gpsValorOutrasEnt;
  final DateTime? gpsDataPagamento;
  final String? irrfCompetencia;
  final int? irrfCodigoRecolhimento;
  final double? irrfValorAcumulado;
  final DateTime? irrfDataPagamento;
  final String? pisCompetencia;
  final double? pisValorAcumulado;
  final DateTime? pisDataPagamento;
  const GuiasAcumuladas(
      {this.id,
      this.gpsTipo,
      this.gpsCompetencia,
      this.gpsValorInss,
      this.gpsValorOutrasEnt,
      this.gpsDataPagamento,
      this.irrfCompetencia,
      this.irrfCodigoRecolhimento,
      this.irrfValorAcumulado,
      this.irrfDataPagamento,
      this.pisCompetencia,
      this.pisValorAcumulado,
      this.pisDataPagamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || gpsTipo != null) {
      map['gps_tipo'] = Variable<String>(gpsTipo);
    }
    if (!nullToAbsent || gpsCompetencia != null) {
      map['gps_competencia'] = Variable<String>(gpsCompetencia);
    }
    if (!nullToAbsent || gpsValorInss != null) {
      map['gps_valor_inss'] = Variable<double>(gpsValorInss);
    }
    if (!nullToAbsent || gpsValorOutrasEnt != null) {
      map['gps_valor_outras_ent'] = Variable<double>(gpsValorOutrasEnt);
    }
    if (!nullToAbsent || gpsDataPagamento != null) {
      map['gps_data_pagamento'] = Variable<DateTime>(gpsDataPagamento);
    }
    if (!nullToAbsent || irrfCompetencia != null) {
      map['irrf_competencia'] = Variable<String>(irrfCompetencia);
    }
    if (!nullToAbsent || irrfCodigoRecolhimento != null) {
      map['irrf_codigo_recolhimento'] = Variable<int>(irrfCodigoRecolhimento);
    }
    if (!nullToAbsent || irrfValorAcumulado != null) {
      map['irrf_valor_acumulado'] = Variable<double>(irrfValorAcumulado);
    }
    if (!nullToAbsent || irrfDataPagamento != null) {
      map['irrf_data_pagamento'] = Variable<DateTime>(irrfDataPagamento);
    }
    if (!nullToAbsent || pisCompetencia != null) {
      map['pis_competencia'] = Variable<String>(pisCompetencia);
    }
    if (!nullToAbsent || pisValorAcumulado != null) {
      map['pis_valor_acumulado'] = Variable<double>(pisValorAcumulado);
    }
    if (!nullToAbsent || pisDataPagamento != null) {
      map['pis_data_pagamento'] = Variable<DateTime>(pisDataPagamento);
    }
    return map;
  }

  factory GuiasAcumuladas.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GuiasAcumuladas(
      id: serializer.fromJson<int?>(json['id']),
      gpsTipo: serializer.fromJson<String?>(json['gpsTipo']),
      gpsCompetencia: serializer.fromJson<String?>(json['gpsCompetencia']),
      gpsValorInss: serializer.fromJson<double?>(json['gpsValorInss']),
      gpsValorOutrasEnt:
          serializer.fromJson<double?>(json['gpsValorOutrasEnt']),
      gpsDataPagamento:
          serializer.fromJson<DateTime?>(json['gpsDataPagamento']),
      irrfCompetencia: serializer.fromJson<String?>(json['irrfCompetencia']),
      irrfCodigoRecolhimento:
          serializer.fromJson<int?>(json['irrfCodigoRecolhimento']),
      irrfValorAcumulado:
          serializer.fromJson<double?>(json['irrfValorAcumulado']),
      irrfDataPagamento:
          serializer.fromJson<DateTime?>(json['irrfDataPagamento']),
      pisCompetencia: serializer.fromJson<String?>(json['pisCompetencia']),
      pisValorAcumulado:
          serializer.fromJson<double?>(json['pisValorAcumulado']),
      pisDataPagamento:
          serializer.fromJson<DateTime?>(json['pisDataPagamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'gpsTipo': serializer.toJson<String?>(gpsTipo),
      'gpsCompetencia': serializer.toJson<String?>(gpsCompetencia),
      'gpsValorInss': serializer.toJson<double?>(gpsValorInss),
      'gpsValorOutrasEnt': serializer.toJson<double?>(gpsValorOutrasEnt),
      'gpsDataPagamento': serializer.toJson<DateTime?>(gpsDataPagamento),
      'irrfCompetencia': serializer.toJson<String?>(irrfCompetencia),
      'irrfCodigoRecolhimento': serializer.toJson<int?>(irrfCodigoRecolhimento),
      'irrfValorAcumulado': serializer.toJson<double?>(irrfValorAcumulado),
      'irrfDataPagamento': serializer.toJson<DateTime?>(irrfDataPagamento),
      'pisCompetencia': serializer.toJson<String?>(pisCompetencia),
      'pisValorAcumulado': serializer.toJson<double?>(pisValorAcumulado),
      'pisDataPagamento': serializer.toJson<DateTime?>(pisDataPagamento),
    };
  }

  GuiasAcumuladas copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> gpsTipo = const Value.absent(),
          Value<String?> gpsCompetencia = const Value.absent(),
          Value<double?> gpsValorInss = const Value.absent(),
          Value<double?> gpsValorOutrasEnt = const Value.absent(),
          Value<DateTime?> gpsDataPagamento = const Value.absent(),
          Value<String?> irrfCompetencia = const Value.absent(),
          Value<int?> irrfCodigoRecolhimento = const Value.absent(),
          Value<double?> irrfValorAcumulado = const Value.absent(),
          Value<DateTime?> irrfDataPagamento = const Value.absent(),
          Value<String?> pisCompetencia = const Value.absent(),
          Value<double?> pisValorAcumulado = const Value.absent(),
          Value<DateTime?> pisDataPagamento = const Value.absent()}) =>
      GuiasAcumuladas(
        id: id.present ? id.value : this.id,
        gpsTipo: gpsTipo.present ? gpsTipo.value : this.gpsTipo,
        gpsCompetencia:
            gpsCompetencia.present ? gpsCompetencia.value : this.gpsCompetencia,
        gpsValorInss:
            gpsValorInss.present ? gpsValorInss.value : this.gpsValorInss,
        gpsValorOutrasEnt: gpsValorOutrasEnt.present
            ? gpsValorOutrasEnt.value
            : this.gpsValorOutrasEnt,
        gpsDataPagamento: gpsDataPagamento.present
            ? gpsDataPagamento.value
            : this.gpsDataPagamento,
        irrfCompetencia: irrfCompetencia.present
            ? irrfCompetencia.value
            : this.irrfCompetencia,
        irrfCodigoRecolhimento: irrfCodigoRecolhimento.present
            ? irrfCodigoRecolhimento.value
            : this.irrfCodigoRecolhimento,
        irrfValorAcumulado: irrfValorAcumulado.present
            ? irrfValorAcumulado.value
            : this.irrfValorAcumulado,
        irrfDataPagamento: irrfDataPagamento.present
            ? irrfDataPagamento.value
            : this.irrfDataPagamento,
        pisCompetencia:
            pisCompetencia.present ? pisCompetencia.value : this.pisCompetencia,
        pisValorAcumulado: pisValorAcumulado.present
            ? pisValorAcumulado.value
            : this.pisValorAcumulado,
        pisDataPagamento: pisDataPagamento.present
            ? pisDataPagamento.value
            : this.pisDataPagamento,
      );
  @override
  String toString() {
    return (StringBuffer('GuiasAcumuladas(')
          ..write('id: $id, ')
          ..write('gpsTipo: $gpsTipo, ')
          ..write('gpsCompetencia: $gpsCompetencia, ')
          ..write('gpsValorInss: $gpsValorInss, ')
          ..write('gpsValorOutrasEnt: $gpsValorOutrasEnt, ')
          ..write('gpsDataPagamento: $gpsDataPagamento, ')
          ..write('irrfCompetencia: $irrfCompetencia, ')
          ..write('irrfCodigoRecolhimento: $irrfCodigoRecolhimento, ')
          ..write('irrfValorAcumulado: $irrfValorAcumulado, ')
          ..write('irrfDataPagamento: $irrfDataPagamento, ')
          ..write('pisCompetencia: $pisCompetencia, ')
          ..write('pisValorAcumulado: $pisValorAcumulado, ')
          ..write('pisDataPagamento: $pisDataPagamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      gpsTipo,
      gpsCompetencia,
      gpsValorInss,
      gpsValorOutrasEnt,
      gpsDataPagamento,
      irrfCompetencia,
      irrfCodigoRecolhimento,
      irrfValorAcumulado,
      irrfDataPagamento,
      pisCompetencia,
      pisValorAcumulado,
      pisDataPagamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GuiasAcumuladas &&
          other.id == this.id &&
          other.gpsTipo == this.gpsTipo &&
          other.gpsCompetencia == this.gpsCompetencia &&
          other.gpsValorInss == this.gpsValorInss &&
          other.gpsValorOutrasEnt == this.gpsValorOutrasEnt &&
          other.gpsDataPagamento == this.gpsDataPagamento &&
          other.irrfCompetencia == this.irrfCompetencia &&
          other.irrfCodigoRecolhimento == this.irrfCodigoRecolhimento &&
          other.irrfValorAcumulado == this.irrfValorAcumulado &&
          other.irrfDataPagamento == this.irrfDataPagamento &&
          other.pisCompetencia == this.pisCompetencia &&
          other.pisValorAcumulado == this.pisValorAcumulado &&
          other.pisDataPagamento == this.pisDataPagamento);
}

class GuiasAcumuladassCompanion extends UpdateCompanion<GuiasAcumuladas> {
  final Value<int?> id;
  final Value<String?> gpsTipo;
  final Value<String?> gpsCompetencia;
  final Value<double?> gpsValorInss;
  final Value<double?> gpsValorOutrasEnt;
  final Value<DateTime?> gpsDataPagamento;
  final Value<String?> irrfCompetencia;
  final Value<int?> irrfCodigoRecolhimento;
  final Value<double?> irrfValorAcumulado;
  final Value<DateTime?> irrfDataPagamento;
  final Value<String?> pisCompetencia;
  final Value<double?> pisValorAcumulado;
  final Value<DateTime?> pisDataPagamento;
  const GuiasAcumuladassCompanion({
    this.id = const Value.absent(),
    this.gpsTipo = const Value.absent(),
    this.gpsCompetencia = const Value.absent(),
    this.gpsValorInss = const Value.absent(),
    this.gpsValorOutrasEnt = const Value.absent(),
    this.gpsDataPagamento = const Value.absent(),
    this.irrfCompetencia = const Value.absent(),
    this.irrfCodigoRecolhimento = const Value.absent(),
    this.irrfValorAcumulado = const Value.absent(),
    this.irrfDataPagamento = const Value.absent(),
    this.pisCompetencia = const Value.absent(),
    this.pisValorAcumulado = const Value.absent(),
    this.pisDataPagamento = const Value.absent(),
  });
  GuiasAcumuladassCompanion.insert({
    this.id = const Value.absent(),
    this.gpsTipo = const Value.absent(),
    this.gpsCompetencia = const Value.absent(),
    this.gpsValorInss = const Value.absent(),
    this.gpsValorOutrasEnt = const Value.absent(),
    this.gpsDataPagamento = const Value.absent(),
    this.irrfCompetencia = const Value.absent(),
    this.irrfCodigoRecolhimento = const Value.absent(),
    this.irrfValorAcumulado = const Value.absent(),
    this.irrfDataPagamento = const Value.absent(),
    this.pisCompetencia = const Value.absent(),
    this.pisValorAcumulado = const Value.absent(),
    this.pisDataPagamento = const Value.absent(),
  });
  static Insertable<GuiasAcumuladas> custom({
    Expression<int>? id,
    Expression<String>? gpsTipo,
    Expression<String>? gpsCompetencia,
    Expression<double>? gpsValorInss,
    Expression<double>? gpsValorOutrasEnt,
    Expression<DateTime>? gpsDataPagamento,
    Expression<String>? irrfCompetencia,
    Expression<int>? irrfCodigoRecolhimento,
    Expression<double>? irrfValorAcumulado,
    Expression<DateTime>? irrfDataPagamento,
    Expression<String>? pisCompetencia,
    Expression<double>? pisValorAcumulado,
    Expression<DateTime>? pisDataPagamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (gpsTipo != null) 'gps_tipo': gpsTipo,
      if (gpsCompetencia != null) 'gps_competencia': gpsCompetencia,
      if (gpsValorInss != null) 'gps_valor_inss': gpsValorInss,
      if (gpsValorOutrasEnt != null) 'gps_valor_outras_ent': gpsValorOutrasEnt,
      if (gpsDataPagamento != null) 'gps_data_pagamento': gpsDataPagamento,
      if (irrfCompetencia != null) 'irrf_competencia': irrfCompetencia,
      if (irrfCodigoRecolhimento != null)
        'irrf_codigo_recolhimento': irrfCodigoRecolhimento,
      if (irrfValorAcumulado != null)
        'irrf_valor_acumulado': irrfValorAcumulado,
      if (irrfDataPagamento != null) 'irrf_data_pagamento': irrfDataPagamento,
      if (pisCompetencia != null) 'pis_competencia': pisCompetencia,
      if (pisValorAcumulado != null) 'pis_valor_acumulado': pisValorAcumulado,
      if (pisDataPagamento != null) 'pis_data_pagamento': pisDataPagamento,
    });
  }

  GuiasAcumuladassCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? gpsTipo,
      Value<String?>? gpsCompetencia,
      Value<double?>? gpsValorInss,
      Value<double?>? gpsValorOutrasEnt,
      Value<DateTime?>? gpsDataPagamento,
      Value<String?>? irrfCompetencia,
      Value<int?>? irrfCodigoRecolhimento,
      Value<double?>? irrfValorAcumulado,
      Value<DateTime?>? irrfDataPagamento,
      Value<String?>? pisCompetencia,
      Value<double?>? pisValorAcumulado,
      Value<DateTime?>? pisDataPagamento}) {
    return GuiasAcumuladassCompanion(
      id: id ?? this.id,
      gpsTipo: gpsTipo ?? this.gpsTipo,
      gpsCompetencia: gpsCompetencia ?? this.gpsCompetencia,
      gpsValorInss: gpsValorInss ?? this.gpsValorInss,
      gpsValorOutrasEnt: gpsValorOutrasEnt ?? this.gpsValorOutrasEnt,
      gpsDataPagamento: gpsDataPagamento ?? this.gpsDataPagamento,
      irrfCompetencia: irrfCompetencia ?? this.irrfCompetencia,
      irrfCodigoRecolhimento:
          irrfCodigoRecolhimento ?? this.irrfCodigoRecolhimento,
      irrfValorAcumulado: irrfValorAcumulado ?? this.irrfValorAcumulado,
      irrfDataPagamento: irrfDataPagamento ?? this.irrfDataPagamento,
      pisCompetencia: pisCompetencia ?? this.pisCompetencia,
      pisValorAcumulado: pisValorAcumulado ?? this.pisValorAcumulado,
      pisDataPagamento: pisDataPagamento ?? this.pisDataPagamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (gpsTipo.present) {
      map['gps_tipo'] = Variable<String>(gpsTipo.value);
    }
    if (gpsCompetencia.present) {
      map['gps_competencia'] = Variable<String>(gpsCompetencia.value);
    }
    if (gpsValorInss.present) {
      map['gps_valor_inss'] = Variable<double>(gpsValorInss.value);
    }
    if (gpsValorOutrasEnt.present) {
      map['gps_valor_outras_ent'] = Variable<double>(gpsValorOutrasEnt.value);
    }
    if (gpsDataPagamento.present) {
      map['gps_data_pagamento'] = Variable<DateTime>(gpsDataPagamento.value);
    }
    if (irrfCompetencia.present) {
      map['irrf_competencia'] = Variable<String>(irrfCompetencia.value);
    }
    if (irrfCodigoRecolhimento.present) {
      map['irrf_codigo_recolhimento'] =
          Variable<int>(irrfCodigoRecolhimento.value);
    }
    if (irrfValorAcumulado.present) {
      map['irrf_valor_acumulado'] = Variable<double>(irrfValorAcumulado.value);
    }
    if (irrfDataPagamento.present) {
      map['irrf_data_pagamento'] = Variable<DateTime>(irrfDataPagamento.value);
    }
    if (pisCompetencia.present) {
      map['pis_competencia'] = Variable<String>(pisCompetencia.value);
    }
    if (pisValorAcumulado.present) {
      map['pis_valor_acumulado'] = Variable<double>(pisValorAcumulado.value);
    }
    if (pisDataPagamento.present) {
      map['pis_data_pagamento'] = Variable<DateTime>(pisDataPagamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GuiasAcumuladassCompanion(')
          ..write('id: $id, ')
          ..write('gpsTipo: $gpsTipo, ')
          ..write('gpsCompetencia: $gpsCompetencia, ')
          ..write('gpsValorInss: $gpsValorInss, ')
          ..write('gpsValorOutrasEnt: $gpsValorOutrasEnt, ')
          ..write('gpsDataPagamento: $gpsDataPagamento, ')
          ..write('irrfCompetencia: $irrfCompetencia, ')
          ..write('irrfCodigoRecolhimento: $irrfCodigoRecolhimento, ')
          ..write('irrfValorAcumulado: $irrfValorAcumulado, ')
          ..write('irrfDataPagamento: $irrfDataPagamento, ')
          ..write('pisCompetencia: $pisCompetencia, ')
          ..write('pisValorAcumulado: $pisValorAcumulado, ')
          ..write('pisDataPagamento: $pisDataPagamento')
          ..write(')'))
        .toString();
  }
}

class $FolhaFechamentosTable extends FolhaFechamentos
    with TableInfo<$FolhaFechamentosTable, FolhaFechamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaFechamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _fechamentoAtualMeta =
      const VerificationMeta('fechamentoAtual');
  @override
  late final GeneratedColumn<String> fechamentoAtual = GeneratedColumn<String>(
      'fechamento_atual', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proximoFechamentoMeta =
      const VerificationMeta('proximoFechamento');
  @override
  late final GeneratedColumn<String> proximoFechamento =
      GeneratedColumn<String>('proximo_fechamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 7),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, fechamentoAtual, proximoFechamento];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_fechamento';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaFechamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('fechamento_atual')) {
      context.handle(
          _fechamentoAtualMeta,
          fechamentoAtual.isAcceptableOrUnknown(
              data['fechamento_atual']!, _fechamentoAtualMeta));
    }
    if (data.containsKey('proximo_fechamento')) {
      context.handle(
          _proximoFechamentoMeta,
          proximoFechamento.isAcceptableOrUnknown(
              data['proximo_fechamento']!, _proximoFechamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaFechamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaFechamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      fechamentoAtual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}fechamento_atual']),
      proximoFechamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proximo_fechamento']),
    );
  }

  @override
  $FolhaFechamentosTable createAlias(String alias) {
    return $FolhaFechamentosTable(attachedDatabase, alias);
  }
}

class FolhaFechamento extends DataClass implements Insertable<FolhaFechamento> {
  final int? id;
  final String? fechamentoAtual;
  final String? proximoFechamento;
  const FolhaFechamento(
      {this.id, this.fechamentoAtual, this.proximoFechamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || fechamentoAtual != null) {
      map['fechamento_atual'] = Variable<String>(fechamentoAtual);
    }
    if (!nullToAbsent || proximoFechamento != null) {
      map['proximo_fechamento'] = Variable<String>(proximoFechamento);
    }
    return map;
  }

  factory FolhaFechamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaFechamento(
      id: serializer.fromJson<int?>(json['id']),
      fechamentoAtual: serializer.fromJson<String?>(json['fechamentoAtual']),
      proximoFechamento:
          serializer.fromJson<String?>(json['proximoFechamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'fechamentoAtual': serializer.toJson<String?>(fechamentoAtual),
      'proximoFechamento': serializer.toJson<String?>(proximoFechamento),
    };
  }

  FolhaFechamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> fechamentoAtual = const Value.absent(),
          Value<String?> proximoFechamento = const Value.absent()}) =>
      FolhaFechamento(
        id: id.present ? id.value : this.id,
        fechamentoAtual: fechamentoAtual.present
            ? fechamentoAtual.value
            : this.fechamentoAtual,
        proximoFechamento: proximoFechamento.present
            ? proximoFechamento.value
            : this.proximoFechamento,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaFechamento(')
          ..write('id: $id, ')
          ..write('fechamentoAtual: $fechamentoAtual, ')
          ..write('proximoFechamento: $proximoFechamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, fechamentoAtual, proximoFechamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaFechamento &&
          other.id == this.id &&
          other.fechamentoAtual == this.fechamentoAtual &&
          other.proximoFechamento == this.proximoFechamento);
}

class FolhaFechamentosCompanion extends UpdateCompanion<FolhaFechamento> {
  final Value<int?> id;
  final Value<String?> fechamentoAtual;
  final Value<String?> proximoFechamento;
  const FolhaFechamentosCompanion({
    this.id = const Value.absent(),
    this.fechamentoAtual = const Value.absent(),
    this.proximoFechamento = const Value.absent(),
  });
  FolhaFechamentosCompanion.insert({
    this.id = const Value.absent(),
    this.fechamentoAtual = const Value.absent(),
    this.proximoFechamento = const Value.absent(),
  });
  static Insertable<FolhaFechamento> custom({
    Expression<int>? id,
    Expression<String>? fechamentoAtual,
    Expression<String>? proximoFechamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (fechamentoAtual != null) 'fechamento_atual': fechamentoAtual,
      if (proximoFechamento != null) 'proximo_fechamento': proximoFechamento,
    });
  }

  FolhaFechamentosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? fechamentoAtual,
      Value<String?>? proximoFechamento}) {
    return FolhaFechamentosCompanion(
      id: id ?? this.id,
      fechamentoAtual: fechamentoAtual ?? this.fechamentoAtual,
      proximoFechamento: proximoFechamento ?? this.proximoFechamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (fechamentoAtual.present) {
      map['fechamento_atual'] = Variable<String>(fechamentoAtual.value);
    }
    if (proximoFechamento.present) {
      map['proximo_fechamento'] = Variable<String>(proximoFechamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaFechamentosCompanion(')
          ..write('id: $id, ')
          ..write('fechamentoAtual: $fechamentoAtual, ')
          ..write('proximoFechamento: $proximoFechamento')
          ..write(')'))
        .toString();
  }
}

class $FeriasPeriodoAquisitivosTable extends FeriasPeriodoAquisitivos
    with TableInfo<$FeriasPeriodoAquisitivosTable, FeriasPeriodoAquisitivo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FeriasPeriodoAquisitivosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _limiteParaGozoMeta =
      const VerificationMeta('limiteParaGozo');
  @override
  late final GeneratedColumn<DateTime> limiteParaGozo =
      GeneratedColumn<DateTime>('limite_para_gozo', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descontarFaltasMeta =
      const VerificationMeta('descontarFaltas');
  @override
  late final GeneratedColumn<String> descontarFaltas = GeneratedColumn<String>(
      'descontar_faltas', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desconsiderarAfastamentoMeta =
      const VerificationMeta('desconsiderarAfastamento');
  @override
  late final GeneratedColumn<String> desconsiderarAfastamento =
      GeneratedColumn<String>('desconsiderar_afastamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _afastamentoPrevidenciaMeta =
      const VerificationMeta('afastamentoPrevidencia');
  @override
  late final GeneratedColumn<int> afastamentoPrevidencia = GeneratedColumn<int>(
      'afastamento_previdencia', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _afastamentoSemRemunMeta =
      const VerificationMeta('afastamentoSemRemun');
  @override
  late final GeneratedColumn<int> afastamentoSemRemun = GeneratedColumn<int>(
      'afastamento_sem_remun', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _afastamentoComRemunMeta =
      const VerificationMeta('afastamentoComRemun');
  @override
  late final GeneratedColumn<int> afastamentoComRemun = GeneratedColumn<int>(
      'afastamento_com_remun', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diasDireitoMeta =
      const VerificationMeta('diasDireito');
  @override
  late final GeneratedColumn<int> diasDireito = GeneratedColumn<int>(
      'dias_direito', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diasGozadosMeta =
      const VerificationMeta('diasGozados');
  @override
  late final GeneratedColumn<int> diasGozados = GeneratedColumn<int>(
      'dias_gozados', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diasFaltasMeta =
      const VerificationMeta('diasFaltas');
  @override
  late final GeneratedColumn<int> diasFaltas = GeneratedColumn<int>(
      'dias_faltas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diasRestantesMeta =
      const VerificationMeta('diasRestantes');
  @override
  late final GeneratedColumn<int> diasRestantes = GeneratedColumn<int>(
      'dias_restantes', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        dataInicio,
        dataFim,
        situacao,
        limiteParaGozo,
        descontarFaltas,
        desconsiderarAfastamento,
        afastamentoPrevidencia,
        afastamentoSemRemun,
        afastamentoComRemun,
        diasDireito,
        diasGozados,
        diasFaltas,
        diasRestantes
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ferias_periodo_aquisitivo';
  @override
  VerificationContext validateIntegrity(
      Insertable<FeriasPeriodoAquisitivo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    if (data.containsKey('limite_para_gozo')) {
      context.handle(
          _limiteParaGozoMeta,
          limiteParaGozo.isAcceptableOrUnknown(
              data['limite_para_gozo']!, _limiteParaGozoMeta));
    }
    if (data.containsKey('descontar_faltas')) {
      context.handle(
          _descontarFaltasMeta,
          descontarFaltas.isAcceptableOrUnknown(
              data['descontar_faltas']!, _descontarFaltasMeta));
    }
    if (data.containsKey('desconsiderar_afastamento')) {
      context.handle(
          _desconsiderarAfastamentoMeta,
          desconsiderarAfastamento.isAcceptableOrUnknown(
              data['desconsiderar_afastamento']!,
              _desconsiderarAfastamentoMeta));
    }
    if (data.containsKey('afastamento_previdencia')) {
      context.handle(
          _afastamentoPrevidenciaMeta,
          afastamentoPrevidencia.isAcceptableOrUnknown(
              data['afastamento_previdencia']!, _afastamentoPrevidenciaMeta));
    }
    if (data.containsKey('afastamento_sem_remun')) {
      context.handle(
          _afastamentoSemRemunMeta,
          afastamentoSemRemun.isAcceptableOrUnknown(
              data['afastamento_sem_remun']!, _afastamentoSemRemunMeta));
    }
    if (data.containsKey('afastamento_com_remun')) {
      context.handle(
          _afastamentoComRemunMeta,
          afastamentoComRemun.isAcceptableOrUnknown(
              data['afastamento_com_remun']!, _afastamentoComRemunMeta));
    }
    if (data.containsKey('dias_direito')) {
      context.handle(
          _diasDireitoMeta,
          diasDireito.isAcceptableOrUnknown(
              data['dias_direito']!, _diasDireitoMeta));
    }
    if (data.containsKey('dias_gozados')) {
      context.handle(
          _diasGozadosMeta,
          diasGozados.isAcceptableOrUnknown(
              data['dias_gozados']!, _diasGozadosMeta));
    }
    if (data.containsKey('dias_faltas')) {
      context.handle(
          _diasFaltasMeta,
          diasFaltas.isAcceptableOrUnknown(
              data['dias_faltas']!, _diasFaltasMeta));
    }
    if (data.containsKey('dias_restantes')) {
      context.handle(
          _diasRestantesMeta,
          diasRestantes.isAcceptableOrUnknown(
              data['dias_restantes']!, _diasRestantesMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FeriasPeriodoAquisitivo map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FeriasPeriodoAquisitivo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
      limiteParaGozo: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}limite_para_gozo']),
      descontarFaltas: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}descontar_faltas']),
      desconsiderarAfastamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}desconsiderar_afastamento']),
      afastamentoPrevidencia: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}afastamento_previdencia']),
      afastamentoSemRemun: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}afastamento_sem_remun']),
      afastamentoComRemun: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}afastamento_com_remun']),
      diasDireito: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_direito']),
      diasGozados: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_gozados']),
      diasFaltas: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_faltas']),
      diasRestantes: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_restantes']),
    );
  }

  @override
  $FeriasPeriodoAquisitivosTable createAlias(String alias) {
    return $FeriasPeriodoAquisitivosTable(attachedDatabase, alias);
  }
}

class FeriasPeriodoAquisitivo extends DataClass
    implements Insertable<FeriasPeriodoAquisitivo> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final String? situacao;
  final DateTime? limiteParaGozo;
  final String? descontarFaltas;
  final String? desconsiderarAfastamento;
  final int? afastamentoPrevidencia;
  final int? afastamentoSemRemun;
  final int? afastamentoComRemun;
  final int? diasDireito;
  final int? diasGozados;
  final int? diasFaltas;
  final int? diasRestantes;
  const FeriasPeriodoAquisitivo(
      {this.id,
      this.idColaborador,
      this.dataInicio,
      this.dataFim,
      this.situacao,
      this.limiteParaGozo,
      this.descontarFaltas,
      this.desconsiderarAfastamento,
      this.afastamentoPrevidencia,
      this.afastamentoSemRemun,
      this.afastamentoComRemun,
      this.diasDireito,
      this.diasGozados,
      this.diasFaltas,
      this.diasRestantes});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    if (!nullToAbsent || limiteParaGozo != null) {
      map['limite_para_gozo'] = Variable<DateTime>(limiteParaGozo);
    }
    if (!nullToAbsent || descontarFaltas != null) {
      map['descontar_faltas'] = Variable<String>(descontarFaltas);
    }
    if (!nullToAbsent || desconsiderarAfastamento != null) {
      map['desconsiderar_afastamento'] =
          Variable<String>(desconsiderarAfastamento);
    }
    if (!nullToAbsent || afastamentoPrevidencia != null) {
      map['afastamento_previdencia'] = Variable<int>(afastamentoPrevidencia);
    }
    if (!nullToAbsent || afastamentoSemRemun != null) {
      map['afastamento_sem_remun'] = Variable<int>(afastamentoSemRemun);
    }
    if (!nullToAbsent || afastamentoComRemun != null) {
      map['afastamento_com_remun'] = Variable<int>(afastamentoComRemun);
    }
    if (!nullToAbsent || diasDireito != null) {
      map['dias_direito'] = Variable<int>(diasDireito);
    }
    if (!nullToAbsent || diasGozados != null) {
      map['dias_gozados'] = Variable<int>(diasGozados);
    }
    if (!nullToAbsent || diasFaltas != null) {
      map['dias_faltas'] = Variable<int>(diasFaltas);
    }
    if (!nullToAbsent || diasRestantes != null) {
      map['dias_restantes'] = Variable<int>(diasRestantes);
    }
    return map;
  }

  factory FeriasPeriodoAquisitivo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FeriasPeriodoAquisitivo(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      situacao: serializer.fromJson<String?>(json['situacao']),
      limiteParaGozo: serializer.fromJson<DateTime?>(json['limiteParaGozo']),
      descontarFaltas: serializer.fromJson<String?>(json['descontarFaltas']),
      desconsiderarAfastamento:
          serializer.fromJson<String?>(json['desconsiderarAfastamento']),
      afastamentoPrevidencia:
          serializer.fromJson<int?>(json['afastamentoPrevidencia']),
      afastamentoSemRemun:
          serializer.fromJson<int?>(json['afastamentoSemRemun']),
      afastamentoComRemun:
          serializer.fromJson<int?>(json['afastamentoComRemun']),
      diasDireito: serializer.fromJson<int?>(json['diasDireito']),
      diasGozados: serializer.fromJson<int?>(json['diasGozados']),
      diasFaltas: serializer.fromJson<int?>(json['diasFaltas']),
      diasRestantes: serializer.fromJson<int?>(json['diasRestantes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'situacao': serializer.toJson<String?>(situacao),
      'limiteParaGozo': serializer.toJson<DateTime?>(limiteParaGozo),
      'descontarFaltas': serializer.toJson<String?>(descontarFaltas),
      'desconsiderarAfastamento':
          serializer.toJson<String?>(desconsiderarAfastamento),
      'afastamentoPrevidencia': serializer.toJson<int?>(afastamentoPrevidencia),
      'afastamentoSemRemun': serializer.toJson<int?>(afastamentoSemRemun),
      'afastamentoComRemun': serializer.toJson<int?>(afastamentoComRemun),
      'diasDireito': serializer.toJson<int?>(diasDireito),
      'diasGozados': serializer.toJson<int?>(diasGozados),
      'diasFaltas': serializer.toJson<int?>(diasFaltas),
      'diasRestantes': serializer.toJson<int?>(diasRestantes),
    };
  }

  FeriasPeriodoAquisitivo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<String?> situacao = const Value.absent(),
          Value<DateTime?> limiteParaGozo = const Value.absent(),
          Value<String?> descontarFaltas = const Value.absent(),
          Value<String?> desconsiderarAfastamento = const Value.absent(),
          Value<int?> afastamentoPrevidencia = const Value.absent(),
          Value<int?> afastamentoSemRemun = const Value.absent(),
          Value<int?> afastamentoComRemun = const Value.absent(),
          Value<int?> diasDireito = const Value.absent(),
          Value<int?> diasGozados = const Value.absent(),
          Value<int?> diasFaltas = const Value.absent(),
          Value<int?> diasRestantes = const Value.absent()}) =>
      FeriasPeriodoAquisitivo(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        situacao: situacao.present ? situacao.value : this.situacao,
        limiteParaGozo:
            limiteParaGozo.present ? limiteParaGozo.value : this.limiteParaGozo,
        descontarFaltas: descontarFaltas.present
            ? descontarFaltas.value
            : this.descontarFaltas,
        desconsiderarAfastamento: desconsiderarAfastamento.present
            ? desconsiderarAfastamento.value
            : this.desconsiderarAfastamento,
        afastamentoPrevidencia: afastamentoPrevidencia.present
            ? afastamentoPrevidencia.value
            : this.afastamentoPrevidencia,
        afastamentoSemRemun: afastamentoSemRemun.present
            ? afastamentoSemRemun.value
            : this.afastamentoSemRemun,
        afastamentoComRemun: afastamentoComRemun.present
            ? afastamentoComRemun.value
            : this.afastamentoComRemun,
        diasDireito: diasDireito.present ? diasDireito.value : this.diasDireito,
        diasGozados: diasGozados.present ? diasGozados.value : this.diasGozados,
        diasFaltas: diasFaltas.present ? diasFaltas.value : this.diasFaltas,
        diasRestantes:
            diasRestantes.present ? diasRestantes.value : this.diasRestantes,
      );
  @override
  String toString() {
    return (StringBuffer('FeriasPeriodoAquisitivo(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('situacao: $situacao, ')
          ..write('limiteParaGozo: $limiteParaGozo, ')
          ..write('descontarFaltas: $descontarFaltas, ')
          ..write('desconsiderarAfastamento: $desconsiderarAfastamento, ')
          ..write('afastamentoPrevidencia: $afastamentoPrevidencia, ')
          ..write('afastamentoSemRemun: $afastamentoSemRemun, ')
          ..write('afastamentoComRemun: $afastamentoComRemun, ')
          ..write('diasDireito: $diasDireito, ')
          ..write('diasGozados: $diasGozados, ')
          ..write('diasFaltas: $diasFaltas, ')
          ..write('diasRestantes: $diasRestantes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idColaborador,
      dataInicio,
      dataFim,
      situacao,
      limiteParaGozo,
      descontarFaltas,
      desconsiderarAfastamento,
      afastamentoPrevidencia,
      afastamentoSemRemun,
      afastamentoComRemun,
      diasDireito,
      diasGozados,
      diasFaltas,
      diasRestantes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FeriasPeriodoAquisitivo &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.situacao == this.situacao &&
          other.limiteParaGozo == this.limiteParaGozo &&
          other.descontarFaltas == this.descontarFaltas &&
          other.desconsiderarAfastamento == this.desconsiderarAfastamento &&
          other.afastamentoPrevidencia == this.afastamentoPrevidencia &&
          other.afastamentoSemRemun == this.afastamentoSemRemun &&
          other.afastamentoComRemun == this.afastamentoComRemun &&
          other.diasDireito == this.diasDireito &&
          other.diasGozados == this.diasGozados &&
          other.diasFaltas == this.diasFaltas &&
          other.diasRestantes == this.diasRestantes);
}

class FeriasPeriodoAquisitivosCompanion
    extends UpdateCompanion<FeriasPeriodoAquisitivo> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<String?> situacao;
  final Value<DateTime?> limiteParaGozo;
  final Value<String?> descontarFaltas;
  final Value<String?> desconsiderarAfastamento;
  final Value<int?> afastamentoPrevidencia;
  final Value<int?> afastamentoSemRemun;
  final Value<int?> afastamentoComRemun;
  final Value<int?> diasDireito;
  final Value<int?> diasGozados;
  final Value<int?> diasFaltas;
  final Value<int?> diasRestantes;
  const FeriasPeriodoAquisitivosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.situacao = const Value.absent(),
    this.limiteParaGozo = const Value.absent(),
    this.descontarFaltas = const Value.absent(),
    this.desconsiderarAfastamento = const Value.absent(),
    this.afastamentoPrevidencia = const Value.absent(),
    this.afastamentoSemRemun = const Value.absent(),
    this.afastamentoComRemun = const Value.absent(),
    this.diasDireito = const Value.absent(),
    this.diasGozados = const Value.absent(),
    this.diasFaltas = const Value.absent(),
    this.diasRestantes = const Value.absent(),
  });
  FeriasPeriodoAquisitivosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.situacao = const Value.absent(),
    this.limiteParaGozo = const Value.absent(),
    this.descontarFaltas = const Value.absent(),
    this.desconsiderarAfastamento = const Value.absent(),
    this.afastamentoPrevidencia = const Value.absent(),
    this.afastamentoSemRemun = const Value.absent(),
    this.afastamentoComRemun = const Value.absent(),
    this.diasDireito = const Value.absent(),
    this.diasGozados = const Value.absent(),
    this.diasFaltas = const Value.absent(),
    this.diasRestantes = const Value.absent(),
  });
  static Insertable<FeriasPeriodoAquisitivo> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<String>? situacao,
    Expression<DateTime>? limiteParaGozo,
    Expression<String>? descontarFaltas,
    Expression<String>? desconsiderarAfastamento,
    Expression<int>? afastamentoPrevidencia,
    Expression<int>? afastamentoSemRemun,
    Expression<int>? afastamentoComRemun,
    Expression<int>? diasDireito,
    Expression<int>? diasGozados,
    Expression<int>? diasFaltas,
    Expression<int>? diasRestantes,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (situacao != null) 'situacao': situacao,
      if (limiteParaGozo != null) 'limite_para_gozo': limiteParaGozo,
      if (descontarFaltas != null) 'descontar_faltas': descontarFaltas,
      if (desconsiderarAfastamento != null)
        'desconsiderar_afastamento': desconsiderarAfastamento,
      if (afastamentoPrevidencia != null)
        'afastamento_previdencia': afastamentoPrevidencia,
      if (afastamentoSemRemun != null)
        'afastamento_sem_remun': afastamentoSemRemun,
      if (afastamentoComRemun != null)
        'afastamento_com_remun': afastamentoComRemun,
      if (diasDireito != null) 'dias_direito': diasDireito,
      if (diasGozados != null) 'dias_gozados': diasGozados,
      if (diasFaltas != null) 'dias_faltas': diasFaltas,
      if (diasRestantes != null) 'dias_restantes': diasRestantes,
    });
  }

  FeriasPeriodoAquisitivosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<String?>? situacao,
      Value<DateTime?>? limiteParaGozo,
      Value<String?>? descontarFaltas,
      Value<String?>? desconsiderarAfastamento,
      Value<int?>? afastamentoPrevidencia,
      Value<int?>? afastamentoSemRemun,
      Value<int?>? afastamentoComRemun,
      Value<int?>? diasDireito,
      Value<int?>? diasGozados,
      Value<int?>? diasFaltas,
      Value<int?>? diasRestantes}) {
    return FeriasPeriodoAquisitivosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      situacao: situacao ?? this.situacao,
      limiteParaGozo: limiteParaGozo ?? this.limiteParaGozo,
      descontarFaltas: descontarFaltas ?? this.descontarFaltas,
      desconsiderarAfastamento:
          desconsiderarAfastamento ?? this.desconsiderarAfastamento,
      afastamentoPrevidencia:
          afastamentoPrevidencia ?? this.afastamentoPrevidencia,
      afastamentoSemRemun: afastamentoSemRemun ?? this.afastamentoSemRemun,
      afastamentoComRemun: afastamentoComRemun ?? this.afastamentoComRemun,
      diasDireito: diasDireito ?? this.diasDireito,
      diasGozados: diasGozados ?? this.diasGozados,
      diasFaltas: diasFaltas ?? this.diasFaltas,
      diasRestantes: diasRestantes ?? this.diasRestantes,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    if (limiteParaGozo.present) {
      map['limite_para_gozo'] = Variable<DateTime>(limiteParaGozo.value);
    }
    if (descontarFaltas.present) {
      map['descontar_faltas'] = Variable<String>(descontarFaltas.value);
    }
    if (desconsiderarAfastamento.present) {
      map['desconsiderar_afastamento'] =
          Variable<String>(desconsiderarAfastamento.value);
    }
    if (afastamentoPrevidencia.present) {
      map['afastamento_previdencia'] =
          Variable<int>(afastamentoPrevidencia.value);
    }
    if (afastamentoSemRemun.present) {
      map['afastamento_sem_remun'] = Variable<int>(afastamentoSemRemun.value);
    }
    if (afastamentoComRemun.present) {
      map['afastamento_com_remun'] = Variable<int>(afastamentoComRemun.value);
    }
    if (diasDireito.present) {
      map['dias_direito'] = Variable<int>(diasDireito.value);
    }
    if (diasGozados.present) {
      map['dias_gozados'] = Variable<int>(diasGozados.value);
    }
    if (diasFaltas.present) {
      map['dias_faltas'] = Variable<int>(diasFaltas.value);
    }
    if (diasRestantes.present) {
      map['dias_restantes'] = Variable<int>(diasRestantes.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FeriasPeriodoAquisitivosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('situacao: $situacao, ')
          ..write('limiteParaGozo: $limiteParaGozo, ')
          ..write('descontarFaltas: $descontarFaltas, ')
          ..write('desconsiderarAfastamento: $desconsiderarAfastamento, ')
          ..write('afastamentoPrevidencia: $afastamentoPrevidencia, ')
          ..write('afastamentoSemRemun: $afastamentoSemRemun, ')
          ..write('afastamentoComRemun: $afastamentoComRemun, ')
          ..write('diasDireito: $diasDireito, ')
          ..write('diasGozados: $diasGozados, ')
          ..write('diasFaltas: $diasFaltas, ')
          ..write('diasRestantes: $diasRestantes')
          ..write(')'))
        .toString();
  }
}

class $FolhaTipoAfastamentosTable extends FolhaTipoAfastamentos
    with TableInfo<$FolhaTipoAfastamentosTable, FolhaTipoAfastamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaTipoAfastamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoEsocialMeta =
      const VerificationMeta('codigoEsocial');
  @override
  late final GeneratedColumn<String> codigoEsocial = GeneratedColumn<String>(
      'codigo_esocial', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, codigo, nome, codigoEsocial, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_tipo_afastamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaTipoAfastamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('codigo_esocial')) {
      context.handle(
          _codigoEsocialMeta,
          codigoEsocial.isAcceptableOrUnknown(
              data['codigo_esocial']!, _codigoEsocialMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaTipoAfastamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaTipoAfastamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      codigoEsocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_esocial']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $FolhaTipoAfastamentosTable createAlias(String alias) {
    return $FolhaTipoAfastamentosTable(attachedDatabase, alias);
  }
}

class FolhaTipoAfastamento extends DataClass
    implements Insertable<FolhaTipoAfastamento> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? codigoEsocial;
  final String? descricao;
  const FolhaTipoAfastamento(
      {this.id, this.codigo, this.nome, this.codigoEsocial, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || codigoEsocial != null) {
      map['codigo_esocial'] = Variable<String>(codigoEsocial);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FolhaTipoAfastamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaTipoAfastamento(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      codigoEsocial: serializer.fromJson<String?>(json['codigoEsocial']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'codigoEsocial': serializer.toJson<String?>(codigoEsocial),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FolhaTipoAfastamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> codigoEsocial = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      FolhaTipoAfastamento(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        codigoEsocial:
            codigoEsocial.present ? codigoEsocial.value : this.codigoEsocial,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaTipoAfastamento(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('codigoEsocial: $codigoEsocial, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, codigoEsocial, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaTipoAfastamento &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.codigoEsocial == this.codigoEsocial &&
          other.descricao == this.descricao);
}

class FolhaTipoAfastamentosCompanion
    extends UpdateCompanion<FolhaTipoAfastamento> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> codigoEsocial;
  final Value<String?> descricao;
  const FolhaTipoAfastamentosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoEsocial = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FolhaTipoAfastamentosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.codigoEsocial = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FolhaTipoAfastamento> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? codigoEsocial,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (codigoEsocial != null) 'codigo_esocial': codigoEsocial,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FolhaTipoAfastamentosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? codigoEsocial,
      Value<String?>? descricao}) {
    return FolhaTipoAfastamentosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      codigoEsocial: codigoEsocial ?? this.codigoEsocial,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (codigoEsocial.present) {
      map['codigo_esocial'] = Variable<String>(codigoEsocial.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaTipoAfastamentosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('codigoEsocial: $codigoEsocial, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FolhaAfastamentosTable extends FolhaAfastamentos
    with TableInfo<$FolhaAfastamentosTable, FolhaAfastamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaAfastamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFolhaTipoAfastamentoMeta =
      const VerificationMeta('idFolhaTipoAfastamento');
  @override
  late final GeneratedColumn<int> idFolhaTipoAfastamento = GeneratedColumn<int>(
      'id_folha_tipo_afastamento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diasAfastadoMeta =
      const VerificationMeta('diasAfastado');
  @override
  late final GeneratedColumn<int> diasAfastado = GeneratedColumn<int>(
      'dias_afastado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        idFolhaTipoAfastamento,
        dataInicio,
        dataFim,
        diasAfastado
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_afastamento';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaAfastamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_folha_tipo_afastamento')) {
      context.handle(
          _idFolhaTipoAfastamentoMeta,
          idFolhaTipoAfastamento.isAcceptableOrUnknown(
              data['id_folha_tipo_afastamento']!, _idFolhaTipoAfastamentoMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('dias_afastado')) {
      context.handle(
          _diasAfastadoMeta,
          diasAfastado.isAcceptableOrUnknown(
              data['dias_afastado']!, _diasAfastadoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaAfastamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaAfastamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idFolhaTipoAfastamento: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_folha_tipo_afastamento']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      diasAfastado: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_afastado']),
    );
  }

  @override
  $FolhaAfastamentosTable createAlias(String alias) {
    return $FolhaAfastamentosTable(attachedDatabase, alias);
  }
}

class FolhaAfastamento extends DataClass
    implements Insertable<FolhaAfastamento> {
  final int? id;
  final int? idColaborador;
  final int? idFolhaTipoAfastamento;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final int? diasAfastado;
  const FolhaAfastamento(
      {this.id,
      this.idColaborador,
      this.idFolhaTipoAfastamento,
      this.dataInicio,
      this.dataFim,
      this.diasAfastado});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idFolhaTipoAfastamento != null) {
      map['id_folha_tipo_afastamento'] = Variable<int>(idFolhaTipoAfastamento);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || diasAfastado != null) {
      map['dias_afastado'] = Variable<int>(diasAfastado);
    }
    return map;
  }

  factory FolhaAfastamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaAfastamento(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idFolhaTipoAfastamento:
          serializer.fromJson<int?>(json['idFolhaTipoAfastamento']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      diasAfastado: serializer.fromJson<int?>(json['diasAfastado']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idFolhaTipoAfastamento': serializer.toJson<int?>(idFolhaTipoAfastamento),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'diasAfastado': serializer.toJson<int?>(diasAfastado),
    };
  }

  FolhaAfastamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idFolhaTipoAfastamento = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<int?> diasAfastado = const Value.absent()}) =>
      FolhaAfastamento(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idFolhaTipoAfastamento: idFolhaTipoAfastamento.present
            ? idFolhaTipoAfastamento.value
            : this.idFolhaTipoAfastamento,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        diasAfastado:
            diasAfastado.present ? diasAfastado.value : this.diasAfastado,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaAfastamento(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idFolhaTipoAfastamento: $idFolhaTipoAfastamento, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('diasAfastado: $diasAfastado')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, idFolhaTipoAfastamento,
      dataInicio, dataFim, diasAfastado);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaAfastamento &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idFolhaTipoAfastamento == this.idFolhaTipoAfastamento &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.diasAfastado == this.diasAfastado);
}

class FolhaAfastamentosCompanion extends UpdateCompanion<FolhaAfastamento> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idFolhaTipoAfastamento;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<int?> diasAfastado;
  const FolhaAfastamentosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idFolhaTipoAfastamento = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.diasAfastado = const Value.absent(),
  });
  FolhaAfastamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idFolhaTipoAfastamento = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.diasAfastado = const Value.absent(),
  });
  static Insertable<FolhaAfastamento> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idFolhaTipoAfastamento,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<int>? diasAfastado,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idFolhaTipoAfastamento != null)
        'id_folha_tipo_afastamento': idFolhaTipoAfastamento,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (diasAfastado != null) 'dias_afastado': diasAfastado,
    });
  }

  FolhaAfastamentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? idFolhaTipoAfastamento,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<int?>? diasAfastado}) {
    return FolhaAfastamentosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idFolhaTipoAfastamento:
          idFolhaTipoAfastamento ?? this.idFolhaTipoAfastamento,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      diasAfastado: diasAfastado ?? this.diasAfastado,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idFolhaTipoAfastamento.present) {
      map['id_folha_tipo_afastamento'] =
          Variable<int>(idFolhaTipoAfastamento.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (diasAfastado.present) {
      map['dias_afastado'] = Variable<int>(diasAfastado.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaAfastamentosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idFolhaTipoAfastamento: $idFolhaTipoAfastamento, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('diasAfastado: $diasAfastado')
          ..write(')'))
        .toString();
  }
}

class $FolhaPlanoSaudesTable extends FolhaPlanoSaudes
    with TableInfo<$FolhaPlanoSaudesTable, FolhaPlanoSaude> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaPlanoSaudesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOperadoraPlanoSaudeMeta =
      const VerificationMeta('idOperadoraPlanoSaude');
  @override
  late final GeneratedColumn<int> idOperadoraPlanoSaude = GeneratedColumn<int>(
      'id_operadora_plano_saude', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _beneficiarioMeta =
      const VerificationMeta('beneficiario');
  @override
  late final GeneratedColumn<String> beneficiario = GeneratedColumn<String>(
      'beneficiario', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idOperadoraPlanoSaude, idColaborador, dataInicio, beneficiario];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_plano_saude';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaPlanoSaude> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_operadora_plano_saude')) {
      context.handle(
          _idOperadoraPlanoSaudeMeta,
          idOperadoraPlanoSaude.isAcceptableOrUnknown(
              data['id_operadora_plano_saude']!, _idOperadoraPlanoSaudeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('beneficiario')) {
      context.handle(
          _beneficiarioMeta,
          beneficiario.isAcceptableOrUnknown(
              data['beneficiario']!, _beneficiarioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaPlanoSaude map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaPlanoSaude(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOperadoraPlanoSaude: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_operadora_plano_saude']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      beneficiario: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}beneficiario']),
    );
  }

  @override
  $FolhaPlanoSaudesTable createAlias(String alias) {
    return $FolhaPlanoSaudesTable(attachedDatabase, alias);
  }
}

class FolhaPlanoSaude extends DataClass implements Insertable<FolhaPlanoSaude> {
  final int? id;
  final int? idOperadoraPlanoSaude;
  final int? idColaborador;
  final DateTime? dataInicio;
  final String? beneficiario;
  const FolhaPlanoSaude(
      {this.id,
      this.idOperadoraPlanoSaude,
      this.idColaborador,
      this.dataInicio,
      this.beneficiario});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOperadoraPlanoSaude != null) {
      map['id_operadora_plano_saude'] = Variable<int>(idOperadoraPlanoSaude);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || beneficiario != null) {
      map['beneficiario'] = Variable<String>(beneficiario);
    }
    return map;
  }

  factory FolhaPlanoSaude.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaPlanoSaude(
      id: serializer.fromJson<int?>(json['id']),
      idOperadoraPlanoSaude:
          serializer.fromJson<int?>(json['idOperadoraPlanoSaude']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      beneficiario: serializer.fromJson<String?>(json['beneficiario']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOperadoraPlanoSaude': serializer.toJson<int?>(idOperadoraPlanoSaude),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'beneficiario': serializer.toJson<String?>(beneficiario),
    };
  }

  FolhaPlanoSaude copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOperadoraPlanoSaude = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<String?> beneficiario = const Value.absent()}) =>
      FolhaPlanoSaude(
        id: id.present ? id.value : this.id,
        idOperadoraPlanoSaude: idOperadoraPlanoSaude.present
            ? idOperadoraPlanoSaude.value
            : this.idOperadoraPlanoSaude,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        beneficiario:
            beneficiario.present ? beneficiario.value : this.beneficiario,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaPlanoSaude(')
          ..write('id: $id, ')
          ..write('idOperadoraPlanoSaude: $idOperadoraPlanoSaude, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('beneficiario: $beneficiario')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idOperadoraPlanoSaude, idColaborador, dataInicio, beneficiario);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaPlanoSaude &&
          other.id == this.id &&
          other.idOperadoraPlanoSaude == this.idOperadoraPlanoSaude &&
          other.idColaborador == this.idColaborador &&
          other.dataInicio == this.dataInicio &&
          other.beneficiario == this.beneficiario);
}

class FolhaPlanoSaudesCompanion extends UpdateCompanion<FolhaPlanoSaude> {
  final Value<int?> id;
  final Value<int?> idOperadoraPlanoSaude;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataInicio;
  final Value<String?> beneficiario;
  const FolhaPlanoSaudesCompanion({
    this.id = const Value.absent(),
    this.idOperadoraPlanoSaude = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.beneficiario = const Value.absent(),
  });
  FolhaPlanoSaudesCompanion.insert({
    this.id = const Value.absent(),
    this.idOperadoraPlanoSaude = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.beneficiario = const Value.absent(),
  });
  static Insertable<FolhaPlanoSaude> custom({
    Expression<int>? id,
    Expression<int>? idOperadoraPlanoSaude,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataInicio,
    Expression<String>? beneficiario,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOperadoraPlanoSaude != null)
        'id_operadora_plano_saude': idOperadoraPlanoSaude,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (beneficiario != null) 'beneficiario': beneficiario,
    });
  }

  FolhaPlanoSaudesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOperadoraPlanoSaude,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataInicio,
      Value<String?>? beneficiario}) {
    return FolhaPlanoSaudesCompanion(
      id: id ?? this.id,
      idOperadoraPlanoSaude:
          idOperadoraPlanoSaude ?? this.idOperadoraPlanoSaude,
      idColaborador: idColaborador ?? this.idColaborador,
      dataInicio: dataInicio ?? this.dataInicio,
      beneficiario: beneficiario ?? this.beneficiario,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOperadoraPlanoSaude.present) {
      map['id_operadora_plano_saude'] =
          Variable<int>(idOperadoraPlanoSaude.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (beneficiario.present) {
      map['beneficiario'] = Variable<String>(beneficiario.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaPlanoSaudesCompanion(')
          ..write('id: $id, ')
          ..write('idOperadoraPlanoSaude: $idOperadoraPlanoSaude, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('beneficiario: $beneficiario')
          ..write(')'))
        .toString();
  }
}

class $FolhaEventosTable extends FolhaEventos
    with TableInfo<$FolhaEventosTable, FolhaEvento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaEventosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoMeta =
      const VerificationMeta('baseCalculo');
  @override
  late final GeneratedColumn<String> baseCalculo = GeneratedColumn<String>(
      'base_calculo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _unidadeMeta =
      const VerificationMeta('unidade');
  @override
  late final GeneratedColumn<String> unidade = GeneratedColumn<String>(
      'unidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _taxaMeta = const VerificationMeta('taxa');
  @override
  late final GeneratedColumn<double> taxa = GeneratedColumn<double>(
      'taxa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _rubricaEsocialMeta =
      const VerificationMeta('rubricaEsocial');
  @override
  late final GeneratedColumn<String> rubricaEsocial = GeneratedColumn<String>(
      'rubrica_esocial', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codIncidenciaPrevidenciaMeta =
      const VerificationMeta('codIncidenciaPrevidencia');
  @override
  late final GeneratedColumn<String> codIncidenciaPrevidencia =
      GeneratedColumn<String>('cod_incidencia_previdencia', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codIncidenciaIrrfMeta =
      const VerificationMeta('codIncidenciaIrrf');
  @override
  late final GeneratedColumn<String> codIncidenciaIrrf =
      GeneratedColumn<String>('cod_incidencia_irrf', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codIncidenciaFgtsMeta =
      const VerificationMeta('codIncidenciaFgts');
  @override
  late final GeneratedColumn<String> codIncidenciaFgts =
      GeneratedColumn<String>('cod_incidencia_fgts', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codIncidenciaSindicatoMeta =
      const VerificationMeta('codIncidenciaSindicato');
  @override
  late final GeneratedColumn<String> codIncidenciaSindicato =
      GeneratedColumn<String>('cod_incidencia_sindicato', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _repercuteDsrMeta =
      const VerificationMeta('repercuteDsr');
  @override
  late final GeneratedColumn<String> repercuteDsr = GeneratedColumn<String>(
      'repercute_dsr', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _repercute13Meta =
      const VerificationMeta('repercute13');
  @override
  late final GeneratedColumn<String> repercute13 = GeneratedColumn<String>(
      'repercute_13', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _repercuteFeriasMeta =
      const VerificationMeta('repercuteFerias');
  @override
  late final GeneratedColumn<String> repercuteFerias = GeneratedColumn<String>(
      'repercute_ferias', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _repercuteAvisoMeta =
      const VerificationMeta('repercuteAviso');
  @override
  late final GeneratedColumn<String> repercuteAviso = GeneratedColumn<String>(
      'repercute_aviso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        codigo,
        nome,
        descricao,
        baseCalculo,
        tipo,
        unidade,
        taxa,
        rubricaEsocial,
        codIncidenciaPrevidencia,
        codIncidenciaIrrf,
        codIncidenciaFgts,
        codIncidenciaSindicato,
        repercuteDsr,
        repercute13,
        repercuteFerias,
        repercuteAviso
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_evento';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaEvento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('base_calculo')) {
      context.handle(
          _baseCalculoMeta,
          baseCalculo.isAcceptableOrUnknown(
              data['base_calculo']!, _baseCalculoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('unidade')) {
      context.handle(_unidadeMeta,
          unidade.isAcceptableOrUnknown(data['unidade']!, _unidadeMeta));
    }
    if (data.containsKey('taxa')) {
      context.handle(
          _taxaMeta, taxa.isAcceptableOrUnknown(data['taxa']!, _taxaMeta));
    }
    if (data.containsKey('rubrica_esocial')) {
      context.handle(
          _rubricaEsocialMeta,
          rubricaEsocial.isAcceptableOrUnknown(
              data['rubrica_esocial']!, _rubricaEsocialMeta));
    }
    if (data.containsKey('cod_incidencia_previdencia')) {
      context.handle(
          _codIncidenciaPrevidenciaMeta,
          codIncidenciaPrevidencia.isAcceptableOrUnknown(
              data['cod_incidencia_previdencia']!,
              _codIncidenciaPrevidenciaMeta));
    }
    if (data.containsKey('cod_incidencia_irrf')) {
      context.handle(
          _codIncidenciaIrrfMeta,
          codIncidenciaIrrf.isAcceptableOrUnknown(
              data['cod_incidencia_irrf']!, _codIncidenciaIrrfMeta));
    }
    if (data.containsKey('cod_incidencia_fgts')) {
      context.handle(
          _codIncidenciaFgtsMeta,
          codIncidenciaFgts.isAcceptableOrUnknown(
              data['cod_incidencia_fgts']!, _codIncidenciaFgtsMeta));
    }
    if (data.containsKey('cod_incidencia_sindicato')) {
      context.handle(
          _codIncidenciaSindicatoMeta,
          codIncidenciaSindicato.isAcceptableOrUnknown(
              data['cod_incidencia_sindicato']!, _codIncidenciaSindicatoMeta));
    }
    if (data.containsKey('repercute_dsr')) {
      context.handle(
          _repercuteDsrMeta,
          repercuteDsr.isAcceptableOrUnknown(
              data['repercute_dsr']!, _repercuteDsrMeta));
    }
    if (data.containsKey('repercute_13')) {
      context.handle(
          _repercute13Meta,
          repercute13.isAcceptableOrUnknown(
              data['repercute_13']!, _repercute13Meta));
    }
    if (data.containsKey('repercute_ferias')) {
      context.handle(
          _repercuteFeriasMeta,
          repercuteFerias.isAcceptableOrUnknown(
              data['repercute_ferias']!, _repercuteFeriasMeta));
    }
    if (data.containsKey('repercute_aviso')) {
      context.handle(
          _repercuteAvisoMeta,
          repercuteAviso.isAcceptableOrUnknown(
              data['repercute_aviso']!, _repercuteAvisoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaEvento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaEvento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      baseCalculo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}base_calculo']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      unidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}unidade']),
      taxa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa']),
      rubricaEsocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rubrica_esocial']),
      codIncidenciaPrevidencia: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}cod_incidencia_previdencia']),
      codIncidenciaIrrf: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cod_incidencia_irrf']),
      codIncidenciaFgts: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cod_incidencia_fgts']),
      codIncidenciaSindicato: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}cod_incidencia_sindicato']),
      repercuteDsr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}repercute_dsr']),
      repercute13: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}repercute_13']),
      repercuteFerias: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}repercute_ferias']),
      repercuteAviso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}repercute_aviso']),
    );
  }

  @override
  $FolhaEventosTable createAlias(String alias) {
    return $FolhaEventosTable(attachedDatabase, alias);
  }
}

class FolhaEvento extends DataClass implements Insertable<FolhaEvento> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  final String? baseCalculo;
  final String? tipo;
  final String? unidade;
  final double? taxa;
  final String? rubricaEsocial;
  final String? codIncidenciaPrevidencia;
  final String? codIncidenciaIrrf;
  final String? codIncidenciaFgts;
  final String? codIncidenciaSindicato;
  final String? repercuteDsr;
  final String? repercute13;
  final String? repercuteFerias;
  final String? repercuteAviso;
  const FolhaEvento(
      {this.id,
      this.codigo,
      this.nome,
      this.descricao,
      this.baseCalculo,
      this.tipo,
      this.unidade,
      this.taxa,
      this.rubricaEsocial,
      this.codIncidenciaPrevidencia,
      this.codIncidenciaIrrf,
      this.codIncidenciaFgts,
      this.codIncidenciaSindicato,
      this.repercuteDsr,
      this.repercute13,
      this.repercuteFerias,
      this.repercuteAviso});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || baseCalculo != null) {
      map['base_calculo'] = Variable<String>(baseCalculo);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || unidade != null) {
      map['unidade'] = Variable<String>(unidade);
    }
    if (!nullToAbsent || taxa != null) {
      map['taxa'] = Variable<double>(taxa);
    }
    if (!nullToAbsent || rubricaEsocial != null) {
      map['rubrica_esocial'] = Variable<String>(rubricaEsocial);
    }
    if (!nullToAbsent || codIncidenciaPrevidencia != null) {
      map['cod_incidencia_previdencia'] =
          Variable<String>(codIncidenciaPrevidencia);
    }
    if (!nullToAbsent || codIncidenciaIrrf != null) {
      map['cod_incidencia_irrf'] = Variable<String>(codIncidenciaIrrf);
    }
    if (!nullToAbsent || codIncidenciaFgts != null) {
      map['cod_incidencia_fgts'] = Variable<String>(codIncidenciaFgts);
    }
    if (!nullToAbsent || codIncidenciaSindicato != null) {
      map['cod_incidencia_sindicato'] =
          Variable<String>(codIncidenciaSindicato);
    }
    if (!nullToAbsent || repercuteDsr != null) {
      map['repercute_dsr'] = Variable<String>(repercuteDsr);
    }
    if (!nullToAbsent || repercute13 != null) {
      map['repercute_13'] = Variable<String>(repercute13);
    }
    if (!nullToAbsent || repercuteFerias != null) {
      map['repercute_ferias'] = Variable<String>(repercuteFerias);
    }
    if (!nullToAbsent || repercuteAviso != null) {
      map['repercute_aviso'] = Variable<String>(repercuteAviso);
    }
    return map;
  }

  factory FolhaEvento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaEvento(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      baseCalculo: serializer.fromJson<String?>(json['baseCalculo']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      unidade: serializer.fromJson<String?>(json['unidade']),
      taxa: serializer.fromJson<double?>(json['taxa']),
      rubricaEsocial: serializer.fromJson<String?>(json['rubricaEsocial']),
      codIncidenciaPrevidencia:
          serializer.fromJson<String?>(json['codIncidenciaPrevidencia']),
      codIncidenciaIrrf:
          serializer.fromJson<String?>(json['codIncidenciaIrrf']),
      codIncidenciaFgts:
          serializer.fromJson<String?>(json['codIncidenciaFgts']),
      codIncidenciaSindicato:
          serializer.fromJson<String?>(json['codIncidenciaSindicato']),
      repercuteDsr: serializer.fromJson<String?>(json['repercuteDsr']),
      repercute13: serializer.fromJson<String?>(json['repercute13']),
      repercuteFerias: serializer.fromJson<String?>(json['repercuteFerias']),
      repercuteAviso: serializer.fromJson<String?>(json['repercuteAviso']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'baseCalculo': serializer.toJson<String?>(baseCalculo),
      'tipo': serializer.toJson<String?>(tipo),
      'unidade': serializer.toJson<String?>(unidade),
      'taxa': serializer.toJson<double?>(taxa),
      'rubricaEsocial': serializer.toJson<String?>(rubricaEsocial),
      'codIncidenciaPrevidencia':
          serializer.toJson<String?>(codIncidenciaPrevidencia),
      'codIncidenciaIrrf': serializer.toJson<String?>(codIncidenciaIrrf),
      'codIncidenciaFgts': serializer.toJson<String?>(codIncidenciaFgts),
      'codIncidenciaSindicato':
          serializer.toJson<String?>(codIncidenciaSindicato),
      'repercuteDsr': serializer.toJson<String?>(repercuteDsr),
      'repercute13': serializer.toJson<String?>(repercute13),
      'repercuteFerias': serializer.toJson<String?>(repercuteFerias),
      'repercuteAviso': serializer.toJson<String?>(repercuteAviso),
    };
  }

  FolhaEvento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> baseCalculo = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> unidade = const Value.absent(),
          Value<double?> taxa = const Value.absent(),
          Value<String?> rubricaEsocial = const Value.absent(),
          Value<String?> codIncidenciaPrevidencia = const Value.absent(),
          Value<String?> codIncidenciaIrrf = const Value.absent(),
          Value<String?> codIncidenciaFgts = const Value.absent(),
          Value<String?> codIncidenciaSindicato = const Value.absent(),
          Value<String?> repercuteDsr = const Value.absent(),
          Value<String?> repercute13 = const Value.absent(),
          Value<String?> repercuteFerias = const Value.absent(),
          Value<String?> repercuteAviso = const Value.absent()}) =>
      FolhaEvento(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        baseCalculo: baseCalculo.present ? baseCalculo.value : this.baseCalculo,
        tipo: tipo.present ? tipo.value : this.tipo,
        unidade: unidade.present ? unidade.value : this.unidade,
        taxa: taxa.present ? taxa.value : this.taxa,
        rubricaEsocial:
            rubricaEsocial.present ? rubricaEsocial.value : this.rubricaEsocial,
        codIncidenciaPrevidencia: codIncidenciaPrevidencia.present
            ? codIncidenciaPrevidencia.value
            : this.codIncidenciaPrevidencia,
        codIncidenciaIrrf: codIncidenciaIrrf.present
            ? codIncidenciaIrrf.value
            : this.codIncidenciaIrrf,
        codIncidenciaFgts: codIncidenciaFgts.present
            ? codIncidenciaFgts.value
            : this.codIncidenciaFgts,
        codIncidenciaSindicato: codIncidenciaSindicato.present
            ? codIncidenciaSindicato.value
            : this.codIncidenciaSindicato,
        repercuteDsr:
            repercuteDsr.present ? repercuteDsr.value : this.repercuteDsr,
        repercute13: repercute13.present ? repercute13.value : this.repercute13,
        repercuteFerias: repercuteFerias.present
            ? repercuteFerias.value
            : this.repercuteFerias,
        repercuteAviso:
            repercuteAviso.present ? repercuteAviso.value : this.repercuteAviso,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaEvento(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('baseCalculo: $baseCalculo, ')
          ..write('tipo: $tipo, ')
          ..write('unidade: $unidade, ')
          ..write('taxa: $taxa, ')
          ..write('rubricaEsocial: $rubricaEsocial, ')
          ..write('codIncidenciaPrevidencia: $codIncidenciaPrevidencia, ')
          ..write('codIncidenciaIrrf: $codIncidenciaIrrf, ')
          ..write('codIncidenciaFgts: $codIncidenciaFgts, ')
          ..write('codIncidenciaSindicato: $codIncidenciaSindicato, ')
          ..write('repercuteDsr: $repercuteDsr, ')
          ..write('repercute13: $repercute13, ')
          ..write('repercuteFerias: $repercuteFerias, ')
          ..write('repercuteAviso: $repercuteAviso')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      codigo,
      nome,
      descricao,
      baseCalculo,
      tipo,
      unidade,
      taxa,
      rubricaEsocial,
      codIncidenciaPrevidencia,
      codIncidenciaIrrf,
      codIncidenciaFgts,
      codIncidenciaSindicato,
      repercuteDsr,
      repercute13,
      repercuteFerias,
      repercuteAviso);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaEvento &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.baseCalculo == this.baseCalculo &&
          other.tipo == this.tipo &&
          other.unidade == this.unidade &&
          other.taxa == this.taxa &&
          other.rubricaEsocial == this.rubricaEsocial &&
          other.codIncidenciaPrevidencia == this.codIncidenciaPrevidencia &&
          other.codIncidenciaIrrf == this.codIncidenciaIrrf &&
          other.codIncidenciaFgts == this.codIncidenciaFgts &&
          other.codIncidenciaSindicato == this.codIncidenciaSindicato &&
          other.repercuteDsr == this.repercuteDsr &&
          other.repercute13 == this.repercute13 &&
          other.repercuteFerias == this.repercuteFerias &&
          other.repercuteAviso == this.repercuteAviso);
}

class FolhaEventosCompanion extends UpdateCompanion<FolhaEvento> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> baseCalculo;
  final Value<String?> tipo;
  final Value<String?> unidade;
  final Value<double?> taxa;
  final Value<String?> rubricaEsocial;
  final Value<String?> codIncidenciaPrevidencia;
  final Value<String?> codIncidenciaIrrf;
  final Value<String?> codIncidenciaFgts;
  final Value<String?> codIncidenciaSindicato;
  final Value<String?> repercuteDsr;
  final Value<String?> repercute13;
  final Value<String?> repercuteFerias;
  final Value<String?> repercuteAviso;
  const FolhaEventosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.baseCalculo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.unidade = const Value.absent(),
    this.taxa = const Value.absent(),
    this.rubricaEsocial = const Value.absent(),
    this.codIncidenciaPrevidencia = const Value.absent(),
    this.codIncidenciaIrrf = const Value.absent(),
    this.codIncidenciaFgts = const Value.absent(),
    this.codIncidenciaSindicato = const Value.absent(),
    this.repercuteDsr = const Value.absent(),
    this.repercute13 = const Value.absent(),
    this.repercuteFerias = const Value.absent(),
    this.repercuteAviso = const Value.absent(),
  });
  FolhaEventosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.baseCalculo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.unidade = const Value.absent(),
    this.taxa = const Value.absent(),
    this.rubricaEsocial = const Value.absent(),
    this.codIncidenciaPrevidencia = const Value.absent(),
    this.codIncidenciaIrrf = const Value.absent(),
    this.codIncidenciaFgts = const Value.absent(),
    this.codIncidenciaSindicato = const Value.absent(),
    this.repercuteDsr = const Value.absent(),
    this.repercute13 = const Value.absent(),
    this.repercuteFerias = const Value.absent(),
    this.repercuteAviso = const Value.absent(),
  });
  static Insertable<FolhaEvento> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? baseCalculo,
    Expression<String>? tipo,
    Expression<String>? unidade,
    Expression<double>? taxa,
    Expression<String>? rubricaEsocial,
    Expression<String>? codIncidenciaPrevidencia,
    Expression<String>? codIncidenciaIrrf,
    Expression<String>? codIncidenciaFgts,
    Expression<String>? codIncidenciaSindicato,
    Expression<String>? repercuteDsr,
    Expression<String>? repercute13,
    Expression<String>? repercuteFerias,
    Expression<String>? repercuteAviso,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (baseCalculo != null) 'base_calculo': baseCalculo,
      if (tipo != null) 'tipo': tipo,
      if (unidade != null) 'unidade': unidade,
      if (taxa != null) 'taxa': taxa,
      if (rubricaEsocial != null) 'rubrica_esocial': rubricaEsocial,
      if (codIncidenciaPrevidencia != null)
        'cod_incidencia_previdencia': codIncidenciaPrevidencia,
      if (codIncidenciaIrrf != null) 'cod_incidencia_irrf': codIncidenciaIrrf,
      if (codIncidenciaFgts != null) 'cod_incidencia_fgts': codIncidenciaFgts,
      if (codIncidenciaSindicato != null)
        'cod_incidencia_sindicato': codIncidenciaSindicato,
      if (repercuteDsr != null) 'repercute_dsr': repercuteDsr,
      if (repercute13 != null) 'repercute_13': repercute13,
      if (repercuteFerias != null) 'repercute_ferias': repercuteFerias,
      if (repercuteAviso != null) 'repercute_aviso': repercuteAviso,
    });
  }

  FolhaEventosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? baseCalculo,
      Value<String?>? tipo,
      Value<String?>? unidade,
      Value<double?>? taxa,
      Value<String?>? rubricaEsocial,
      Value<String?>? codIncidenciaPrevidencia,
      Value<String?>? codIncidenciaIrrf,
      Value<String?>? codIncidenciaFgts,
      Value<String?>? codIncidenciaSindicato,
      Value<String?>? repercuteDsr,
      Value<String?>? repercute13,
      Value<String?>? repercuteFerias,
      Value<String?>? repercuteAviso}) {
    return FolhaEventosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      baseCalculo: baseCalculo ?? this.baseCalculo,
      tipo: tipo ?? this.tipo,
      unidade: unidade ?? this.unidade,
      taxa: taxa ?? this.taxa,
      rubricaEsocial: rubricaEsocial ?? this.rubricaEsocial,
      codIncidenciaPrevidencia:
          codIncidenciaPrevidencia ?? this.codIncidenciaPrevidencia,
      codIncidenciaIrrf: codIncidenciaIrrf ?? this.codIncidenciaIrrf,
      codIncidenciaFgts: codIncidenciaFgts ?? this.codIncidenciaFgts,
      codIncidenciaSindicato:
          codIncidenciaSindicato ?? this.codIncidenciaSindicato,
      repercuteDsr: repercuteDsr ?? this.repercuteDsr,
      repercute13: repercute13 ?? this.repercute13,
      repercuteFerias: repercuteFerias ?? this.repercuteFerias,
      repercuteAviso: repercuteAviso ?? this.repercuteAviso,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (baseCalculo.present) {
      map['base_calculo'] = Variable<String>(baseCalculo.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (unidade.present) {
      map['unidade'] = Variable<String>(unidade.value);
    }
    if (taxa.present) {
      map['taxa'] = Variable<double>(taxa.value);
    }
    if (rubricaEsocial.present) {
      map['rubrica_esocial'] = Variable<String>(rubricaEsocial.value);
    }
    if (codIncidenciaPrevidencia.present) {
      map['cod_incidencia_previdencia'] =
          Variable<String>(codIncidenciaPrevidencia.value);
    }
    if (codIncidenciaIrrf.present) {
      map['cod_incidencia_irrf'] = Variable<String>(codIncidenciaIrrf.value);
    }
    if (codIncidenciaFgts.present) {
      map['cod_incidencia_fgts'] = Variable<String>(codIncidenciaFgts.value);
    }
    if (codIncidenciaSindicato.present) {
      map['cod_incidencia_sindicato'] =
          Variable<String>(codIncidenciaSindicato.value);
    }
    if (repercuteDsr.present) {
      map['repercute_dsr'] = Variable<String>(repercuteDsr.value);
    }
    if (repercute13.present) {
      map['repercute_13'] = Variable<String>(repercute13.value);
    }
    if (repercuteFerias.present) {
      map['repercute_ferias'] = Variable<String>(repercuteFerias.value);
    }
    if (repercuteAviso.present) {
      map['repercute_aviso'] = Variable<String>(repercuteAviso.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaEventosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('baseCalculo: $baseCalculo, ')
          ..write('tipo: $tipo, ')
          ..write('unidade: $unidade, ')
          ..write('taxa: $taxa, ')
          ..write('rubricaEsocial: $rubricaEsocial, ')
          ..write('codIncidenciaPrevidencia: $codIncidenciaPrevidencia, ')
          ..write('codIncidenciaIrrf: $codIncidenciaIrrf, ')
          ..write('codIncidenciaFgts: $codIncidenciaFgts, ')
          ..write('codIncidenciaSindicato: $codIncidenciaSindicato, ')
          ..write('repercuteDsr: $repercuteDsr, ')
          ..write('repercute13: $repercute13, ')
          ..write('repercuteFerias: $repercuteFerias, ')
          ..write('repercuteAviso: $repercuteAviso')
          ..write(')'))
        .toString();
  }
}

class $FolhaRescisaosTable extends FolhaRescisaos
    with TableInfo<$FolhaRescisaosTable, FolhaRescisao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaRescisaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPagamentoMeta =
      const VerificationMeta('dataPagamento');
  @override
  late final GeneratedColumn<DateTime> dataPagamento =
      GeneratedColumn<DateTime>('data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _motivoMeta = const VerificationMeta('motivo');
  @override
  late final GeneratedColumn<String> motivo = GeneratedColumn<String>(
      'motivo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _motivoEsocialMeta =
      const VerificationMeta('motivoEsocial');
  @override
  late final GeneratedColumn<String> motivoEsocial = GeneratedColumn<String>(
      'motivo_esocial', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataAvisoPrevioMeta =
      const VerificationMeta('dataAvisoPrevio');
  @override
  late final GeneratedColumn<DateTime> dataAvisoPrevio =
      GeneratedColumn<DateTime>('data_aviso_previo', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diasAvisoPrevioMeta =
      const VerificationMeta('diasAvisoPrevio');
  @override
  late final GeneratedColumn<int> diasAvisoPrevio = GeneratedColumn<int>(
      'dias_aviso_previo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _comprovouNovoEmpregoMeta =
      const VerificationMeta('comprovouNovoEmprego');
  @override
  late final GeneratedColumn<String> comprovouNovoEmprego =
      GeneratedColumn<String>(
          'comprovou_novo_emprego', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dispensouEmpregadoMeta =
      const VerificationMeta('dispensouEmpregado');
  @override
  late final GeneratedColumn<String> dispensouEmpregado =
      GeneratedColumn<String>('dispensou_empregado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pensaoAlimenticiaMeta =
      const VerificationMeta('pensaoAlimenticia');
  @override
  late final GeneratedColumn<double> pensaoAlimenticia =
      GeneratedColumn<double>('pensao_alimenticia', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pensaoAlimenticiaFgtsMeta =
      const VerificationMeta('pensaoAlimenticiaFgts');
  @override
  late final GeneratedColumn<double> pensaoAlimenticiaFgts =
      GeneratedColumn<double>('pensao_alimenticia_fgts', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fgtsValorRescisaoMeta =
      const VerificationMeta('fgtsValorRescisao');
  @override
  late final GeneratedColumn<double> fgtsValorRescisao =
      GeneratedColumn<double>('fgts_valor_rescisao', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fgtsSaldoBancoMeta =
      const VerificationMeta('fgtsSaldoBanco');
  @override
  late final GeneratedColumn<double> fgtsSaldoBanco = GeneratedColumn<double>(
      'fgts_saldo_banco', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fgtsComplementoSaldoMeta =
      const VerificationMeta('fgtsComplementoSaldo');
  @override
  late final GeneratedColumn<double> fgtsComplementoSaldo =
      GeneratedColumn<double>('fgts_complemento_saldo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fgtsCodigoAfastamentoMeta =
      const VerificationMeta('fgtsCodigoAfastamento');
  @override
  late final GeneratedColumn<String> fgtsCodigoAfastamento =
      GeneratedColumn<String>('fgts_codigo_afastamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 10),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _fgtsCodigoSaqueMeta =
      const VerificationMeta('fgtsCodigoSaque');
  @override
  late final GeneratedColumn<String> fgtsCodigoSaque = GeneratedColumn<String>(
      'fgts_codigo_saque', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        dataDemissao,
        dataPagamento,
        motivo,
        motivoEsocial,
        dataAvisoPrevio,
        diasAvisoPrevio,
        comprovouNovoEmprego,
        dispensouEmpregado,
        pensaoAlimenticia,
        pensaoAlimenticiaFgts,
        fgtsValorRescisao,
        fgtsSaldoBanco,
        fgtsComplementoSaldo,
        fgtsCodigoAfastamento,
        fgtsCodigoSaque
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_rescisao';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaRescisao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('data_pagamento')) {
      context.handle(
          _dataPagamentoMeta,
          dataPagamento.isAcceptableOrUnknown(
              data['data_pagamento']!, _dataPagamentoMeta));
    }
    if (data.containsKey('motivo')) {
      context.handle(_motivoMeta,
          motivo.isAcceptableOrUnknown(data['motivo']!, _motivoMeta));
    }
    if (data.containsKey('motivo_esocial')) {
      context.handle(
          _motivoEsocialMeta,
          motivoEsocial.isAcceptableOrUnknown(
              data['motivo_esocial']!, _motivoEsocialMeta));
    }
    if (data.containsKey('data_aviso_previo')) {
      context.handle(
          _dataAvisoPrevioMeta,
          dataAvisoPrevio.isAcceptableOrUnknown(
              data['data_aviso_previo']!, _dataAvisoPrevioMeta));
    }
    if (data.containsKey('dias_aviso_previo')) {
      context.handle(
          _diasAvisoPrevioMeta,
          diasAvisoPrevio.isAcceptableOrUnknown(
              data['dias_aviso_previo']!, _diasAvisoPrevioMeta));
    }
    if (data.containsKey('comprovou_novo_emprego')) {
      context.handle(
          _comprovouNovoEmpregoMeta,
          comprovouNovoEmprego.isAcceptableOrUnknown(
              data['comprovou_novo_emprego']!, _comprovouNovoEmpregoMeta));
    }
    if (data.containsKey('dispensou_empregado')) {
      context.handle(
          _dispensouEmpregadoMeta,
          dispensouEmpregado.isAcceptableOrUnknown(
              data['dispensou_empregado']!, _dispensouEmpregadoMeta));
    }
    if (data.containsKey('pensao_alimenticia')) {
      context.handle(
          _pensaoAlimenticiaMeta,
          pensaoAlimenticia.isAcceptableOrUnknown(
              data['pensao_alimenticia']!, _pensaoAlimenticiaMeta));
    }
    if (data.containsKey('pensao_alimenticia_fgts')) {
      context.handle(
          _pensaoAlimenticiaFgtsMeta,
          pensaoAlimenticiaFgts.isAcceptableOrUnknown(
              data['pensao_alimenticia_fgts']!, _pensaoAlimenticiaFgtsMeta));
    }
    if (data.containsKey('fgts_valor_rescisao')) {
      context.handle(
          _fgtsValorRescisaoMeta,
          fgtsValorRescisao.isAcceptableOrUnknown(
              data['fgts_valor_rescisao']!, _fgtsValorRescisaoMeta));
    }
    if (data.containsKey('fgts_saldo_banco')) {
      context.handle(
          _fgtsSaldoBancoMeta,
          fgtsSaldoBanco.isAcceptableOrUnknown(
              data['fgts_saldo_banco']!, _fgtsSaldoBancoMeta));
    }
    if (data.containsKey('fgts_complemento_saldo')) {
      context.handle(
          _fgtsComplementoSaldoMeta,
          fgtsComplementoSaldo.isAcceptableOrUnknown(
              data['fgts_complemento_saldo']!, _fgtsComplementoSaldoMeta));
    }
    if (data.containsKey('fgts_codigo_afastamento')) {
      context.handle(
          _fgtsCodigoAfastamentoMeta,
          fgtsCodigoAfastamento.isAcceptableOrUnknown(
              data['fgts_codigo_afastamento']!, _fgtsCodigoAfastamentoMeta));
    }
    if (data.containsKey('fgts_codigo_saque')) {
      context.handle(
          _fgtsCodigoSaqueMeta,
          fgtsCodigoSaque.isAcceptableOrUnknown(
              data['fgts_codigo_saque']!, _fgtsCodigoSaqueMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaRescisao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaRescisao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      dataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_pagamento']),
      motivo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}motivo']),
      motivoEsocial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}motivo_esocial']),
      dataAvisoPrevio: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_aviso_previo']),
      diasAvisoPrevio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_aviso_previo']),
      comprovouNovoEmprego: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}comprovou_novo_emprego']),
      dispensouEmpregado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}dispensou_empregado']),
      pensaoAlimenticia: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}pensao_alimenticia']),
      pensaoAlimenticiaFgts: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}pensao_alimenticia_fgts']),
      fgtsValorRescisao: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}fgts_valor_rescisao']),
      fgtsSaldoBanco: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}fgts_saldo_banco']),
      fgtsComplementoSaldo: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}fgts_complemento_saldo']),
      fgtsCodigoAfastamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}fgts_codigo_afastamento']),
      fgtsCodigoSaque: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}fgts_codigo_saque']),
    );
  }

  @override
  $FolhaRescisaosTable createAlias(String alias) {
    return $FolhaRescisaosTable(attachedDatabase, alias);
  }
}

class FolhaRescisao extends DataClass implements Insertable<FolhaRescisao> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataDemissao;
  final DateTime? dataPagamento;
  final String? motivo;
  final String? motivoEsocial;
  final DateTime? dataAvisoPrevio;
  final int? diasAvisoPrevio;
  final String? comprovouNovoEmprego;
  final String? dispensouEmpregado;
  final double? pensaoAlimenticia;
  final double? pensaoAlimenticiaFgts;
  final double? fgtsValorRescisao;
  final double? fgtsSaldoBanco;
  final double? fgtsComplementoSaldo;
  final String? fgtsCodigoAfastamento;
  final String? fgtsCodigoSaque;
  const FolhaRescisao(
      {this.id,
      this.idColaborador,
      this.dataDemissao,
      this.dataPagamento,
      this.motivo,
      this.motivoEsocial,
      this.dataAvisoPrevio,
      this.diasAvisoPrevio,
      this.comprovouNovoEmprego,
      this.dispensouEmpregado,
      this.pensaoAlimenticia,
      this.pensaoAlimenticiaFgts,
      this.fgtsValorRescisao,
      this.fgtsSaldoBanco,
      this.fgtsComplementoSaldo,
      this.fgtsCodigoAfastamento,
      this.fgtsCodigoSaque});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || dataPagamento != null) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento);
    }
    if (!nullToAbsent || motivo != null) {
      map['motivo'] = Variable<String>(motivo);
    }
    if (!nullToAbsent || motivoEsocial != null) {
      map['motivo_esocial'] = Variable<String>(motivoEsocial);
    }
    if (!nullToAbsent || dataAvisoPrevio != null) {
      map['data_aviso_previo'] = Variable<DateTime>(dataAvisoPrevio);
    }
    if (!nullToAbsent || diasAvisoPrevio != null) {
      map['dias_aviso_previo'] = Variable<int>(diasAvisoPrevio);
    }
    if (!nullToAbsent || comprovouNovoEmprego != null) {
      map['comprovou_novo_emprego'] = Variable<String>(comprovouNovoEmprego);
    }
    if (!nullToAbsent || dispensouEmpregado != null) {
      map['dispensou_empregado'] = Variable<String>(dispensouEmpregado);
    }
    if (!nullToAbsent || pensaoAlimenticia != null) {
      map['pensao_alimenticia'] = Variable<double>(pensaoAlimenticia);
    }
    if (!nullToAbsent || pensaoAlimenticiaFgts != null) {
      map['pensao_alimenticia_fgts'] = Variable<double>(pensaoAlimenticiaFgts);
    }
    if (!nullToAbsent || fgtsValorRescisao != null) {
      map['fgts_valor_rescisao'] = Variable<double>(fgtsValorRescisao);
    }
    if (!nullToAbsent || fgtsSaldoBanco != null) {
      map['fgts_saldo_banco'] = Variable<double>(fgtsSaldoBanco);
    }
    if (!nullToAbsent || fgtsComplementoSaldo != null) {
      map['fgts_complemento_saldo'] = Variable<double>(fgtsComplementoSaldo);
    }
    if (!nullToAbsent || fgtsCodigoAfastamento != null) {
      map['fgts_codigo_afastamento'] = Variable<String>(fgtsCodigoAfastamento);
    }
    if (!nullToAbsent || fgtsCodigoSaque != null) {
      map['fgts_codigo_saque'] = Variable<String>(fgtsCodigoSaque);
    }
    return map;
  }

  factory FolhaRescisao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaRescisao(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      dataPagamento: serializer.fromJson<DateTime?>(json['dataPagamento']),
      motivo: serializer.fromJson<String?>(json['motivo']),
      motivoEsocial: serializer.fromJson<String?>(json['motivoEsocial']),
      dataAvisoPrevio: serializer.fromJson<DateTime?>(json['dataAvisoPrevio']),
      diasAvisoPrevio: serializer.fromJson<int?>(json['diasAvisoPrevio']),
      comprovouNovoEmprego:
          serializer.fromJson<String?>(json['comprovouNovoEmprego']),
      dispensouEmpregado:
          serializer.fromJson<String?>(json['dispensouEmpregado']),
      pensaoAlimenticia:
          serializer.fromJson<double?>(json['pensaoAlimenticia']),
      pensaoAlimenticiaFgts:
          serializer.fromJson<double?>(json['pensaoAlimenticiaFgts']),
      fgtsValorRescisao:
          serializer.fromJson<double?>(json['fgtsValorRescisao']),
      fgtsSaldoBanco: serializer.fromJson<double?>(json['fgtsSaldoBanco']),
      fgtsComplementoSaldo:
          serializer.fromJson<double?>(json['fgtsComplementoSaldo']),
      fgtsCodigoAfastamento:
          serializer.fromJson<String?>(json['fgtsCodigoAfastamento']),
      fgtsCodigoSaque: serializer.fromJson<String?>(json['fgtsCodigoSaque']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'dataPagamento': serializer.toJson<DateTime?>(dataPagamento),
      'motivo': serializer.toJson<String?>(motivo),
      'motivoEsocial': serializer.toJson<String?>(motivoEsocial),
      'dataAvisoPrevio': serializer.toJson<DateTime?>(dataAvisoPrevio),
      'diasAvisoPrevio': serializer.toJson<int?>(diasAvisoPrevio),
      'comprovouNovoEmprego': serializer.toJson<String?>(comprovouNovoEmprego),
      'dispensouEmpregado': serializer.toJson<String?>(dispensouEmpregado),
      'pensaoAlimenticia': serializer.toJson<double?>(pensaoAlimenticia),
      'pensaoAlimenticiaFgts':
          serializer.toJson<double?>(pensaoAlimenticiaFgts),
      'fgtsValorRescisao': serializer.toJson<double?>(fgtsValorRescisao),
      'fgtsSaldoBanco': serializer.toJson<double?>(fgtsSaldoBanco),
      'fgtsComplementoSaldo': serializer.toJson<double?>(fgtsComplementoSaldo),
      'fgtsCodigoAfastamento':
          serializer.toJson<String?>(fgtsCodigoAfastamento),
      'fgtsCodigoSaque': serializer.toJson<String?>(fgtsCodigoSaque),
    };
  }

  FolhaRescisao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<DateTime?> dataPagamento = const Value.absent(),
          Value<String?> motivo = const Value.absent(),
          Value<String?> motivoEsocial = const Value.absent(),
          Value<DateTime?> dataAvisoPrevio = const Value.absent(),
          Value<int?> diasAvisoPrevio = const Value.absent(),
          Value<String?> comprovouNovoEmprego = const Value.absent(),
          Value<String?> dispensouEmpregado = const Value.absent(),
          Value<double?> pensaoAlimenticia = const Value.absent(),
          Value<double?> pensaoAlimenticiaFgts = const Value.absent(),
          Value<double?> fgtsValorRescisao = const Value.absent(),
          Value<double?> fgtsSaldoBanco = const Value.absent(),
          Value<double?> fgtsComplementoSaldo = const Value.absent(),
          Value<String?> fgtsCodigoAfastamento = const Value.absent(),
          Value<String?> fgtsCodigoSaque = const Value.absent()}) =>
      FolhaRescisao(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        dataPagamento:
            dataPagamento.present ? dataPagamento.value : this.dataPagamento,
        motivo: motivo.present ? motivo.value : this.motivo,
        motivoEsocial:
            motivoEsocial.present ? motivoEsocial.value : this.motivoEsocial,
        dataAvisoPrevio: dataAvisoPrevio.present
            ? dataAvisoPrevio.value
            : this.dataAvisoPrevio,
        diasAvisoPrevio: diasAvisoPrevio.present
            ? diasAvisoPrevio.value
            : this.diasAvisoPrevio,
        comprovouNovoEmprego: comprovouNovoEmprego.present
            ? comprovouNovoEmprego.value
            : this.comprovouNovoEmprego,
        dispensouEmpregado: dispensouEmpregado.present
            ? dispensouEmpregado.value
            : this.dispensouEmpregado,
        pensaoAlimenticia: pensaoAlimenticia.present
            ? pensaoAlimenticia.value
            : this.pensaoAlimenticia,
        pensaoAlimenticiaFgts: pensaoAlimenticiaFgts.present
            ? pensaoAlimenticiaFgts.value
            : this.pensaoAlimenticiaFgts,
        fgtsValorRescisao: fgtsValorRescisao.present
            ? fgtsValorRescisao.value
            : this.fgtsValorRescisao,
        fgtsSaldoBanco:
            fgtsSaldoBanco.present ? fgtsSaldoBanco.value : this.fgtsSaldoBanco,
        fgtsComplementoSaldo: fgtsComplementoSaldo.present
            ? fgtsComplementoSaldo.value
            : this.fgtsComplementoSaldo,
        fgtsCodigoAfastamento: fgtsCodigoAfastamento.present
            ? fgtsCodigoAfastamento.value
            : this.fgtsCodigoAfastamento,
        fgtsCodigoSaque: fgtsCodigoSaque.present
            ? fgtsCodigoSaque.value
            : this.fgtsCodigoSaque,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaRescisao(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('motivo: $motivo, ')
          ..write('motivoEsocial: $motivoEsocial, ')
          ..write('dataAvisoPrevio: $dataAvisoPrevio, ')
          ..write('diasAvisoPrevio: $diasAvisoPrevio, ')
          ..write('comprovouNovoEmprego: $comprovouNovoEmprego, ')
          ..write('dispensouEmpregado: $dispensouEmpregado, ')
          ..write('pensaoAlimenticia: $pensaoAlimenticia, ')
          ..write('pensaoAlimenticiaFgts: $pensaoAlimenticiaFgts, ')
          ..write('fgtsValorRescisao: $fgtsValorRescisao, ')
          ..write('fgtsSaldoBanco: $fgtsSaldoBanco, ')
          ..write('fgtsComplementoSaldo: $fgtsComplementoSaldo, ')
          ..write('fgtsCodigoAfastamento: $fgtsCodigoAfastamento, ')
          ..write('fgtsCodigoSaque: $fgtsCodigoSaque')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idColaborador,
      dataDemissao,
      dataPagamento,
      motivo,
      motivoEsocial,
      dataAvisoPrevio,
      diasAvisoPrevio,
      comprovouNovoEmprego,
      dispensouEmpregado,
      pensaoAlimenticia,
      pensaoAlimenticiaFgts,
      fgtsValorRescisao,
      fgtsSaldoBanco,
      fgtsComplementoSaldo,
      fgtsCodigoAfastamento,
      fgtsCodigoSaque);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaRescisao &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataDemissao == this.dataDemissao &&
          other.dataPagamento == this.dataPagamento &&
          other.motivo == this.motivo &&
          other.motivoEsocial == this.motivoEsocial &&
          other.dataAvisoPrevio == this.dataAvisoPrevio &&
          other.diasAvisoPrevio == this.diasAvisoPrevio &&
          other.comprovouNovoEmprego == this.comprovouNovoEmprego &&
          other.dispensouEmpregado == this.dispensouEmpregado &&
          other.pensaoAlimenticia == this.pensaoAlimenticia &&
          other.pensaoAlimenticiaFgts == this.pensaoAlimenticiaFgts &&
          other.fgtsValorRescisao == this.fgtsValorRescisao &&
          other.fgtsSaldoBanco == this.fgtsSaldoBanco &&
          other.fgtsComplementoSaldo == this.fgtsComplementoSaldo &&
          other.fgtsCodigoAfastamento == this.fgtsCodigoAfastamento &&
          other.fgtsCodigoSaque == this.fgtsCodigoSaque);
}

class FolhaRescisaosCompanion extends UpdateCompanion<FolhaRescisao> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataDemissao;
  final Value<DateTime?> dataPagamento;
  final Value<String?> motivo;
  final Value<String?> motivoEsocial;
  final Value<DateTime?> dataAvisoPrevio;
  final Value<int?> diasAvisoPrevio;
  final Value<String?> comprovouNovoEmprego;
  final Value<String?> dispensouEmpregado;
  final Value<double?> pensaoAlimenticia;
  final Value<double?> pensaoAlimenticiaFgts;
  final Value<double?> fgtsValorRescisao;
  final Value<double?> fgtsSaldoBanco;
  final Value<double?> fgtsComplementoSaldo;
  final Value<String?> fgtsCodigoAfastamento;
  final Value<String?> fgtsCodigoSaque;
  const FolhaRescisaosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.motivo = const Value.absent(),
    this.motivoEsocial = const Value.absent(),
    this.dataAvisoPrevio = const Value.absent(),
    this.diasAvisoPrevio = const Value.absent(),
    this.comprovouNovoEmprego = const Value.absent(),
    this.dispensouEmpregado = const Value.absent(),
    this.pensaoAlimenticia = const Value.absent(),
    this.pensaoAlimenticiaFgts = const Value.absent(),
    this.fgtsValorRescisao = const Value.absent(),
    this.fgtsSaldoBanco = const Value.absent(),
    this.fgtsComplementoSaldo = const Value.absent(),
    this.fgtsCodigoAfastamento = const Value.absent(),
    this.fgtsCodigoSaque = const Value.absent(),
  });
  FolhaRescisaosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.motivo = const Value.absent(),
    this.motivoEsocial = const Value.absent(),
    this.dataAvisoPrevio = const Value.absent(),
    this.diasAvisoPrevio = const Value.absent(),
    this.comprovouNovoEmprego = const Value.absent(),
    this.dispensouEmpregado = const Value.absent(),
    this.pensaoAlimenticia = const Value.absent(),
    this.pensaoAlimenticiaFgts = const Value.absent(),
    this.fgtsValorRescisao = const Value.absent(),
    this.fgtsSaldoBanco = const Value.absent(),
    this.fgtsComplementoSaldo = const Value.absent(),
    this.fgtsCodigoAfastamento = const Value.absent(),
    this.fgtsCodigoSaque = const Value.absent(),
  });
  static Insertable<FolhaRescisao> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataDemissao,
    Expression<DateTime>? dataPagamento,
    Expression<String>? motivo,
    Expression<String>? motivoEsocial,
    Expression<DateTime>? dataAvisoPrevio,
    Expression<int>? diasAvisoPrevio,
    Expression<String>? comprovouNovoEmprego,
    Expression<String>? dispensouEmpregado,
    Expression<double>? pensaoAlimenticia,
    Expression<double>? pensaoAlimenticiaFgts,
    Expression<double>? fgtsValorRescisao,
    Expression<double>? fgtsSaldoBanco,
    Expression<double>? fgtsComplementoSaldo,
    Expression<String>? fgtsCodigoAfastamento,
    Expression<String>? fgtsCodigoSaque,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (dataPagamento != null) 'data_pagamento': dataPagamento,
      if (motivo != null) 'motivo': motivo,
      if (motivoEsocial != null) 'motivo_esocial': motivoEsocial,
      if (dataAvisoPrevio != null) 'data_aviso_previo': dataAvisoPrevio,
      if (diasAvisoPrevio != null) 'dias_aviso_previo': diasAvisoPrevio,
      if (comprovouNovoEmprego != null)
        'comprovou_novo_emprego': comprovouNovoEmprego,
      if (dispensouEmpregado != null) 'dispensou_empregado': dispensouEmpregado,
      if (pensaoAlimenticia != null) 'pensao_alimenticia': pensaoAlimenticia,
      if (pensaoAlimenticiaFgts != null)
        'pensao_alimenticia_fgts': pensaoAlimenticiaFgts,
      if (fgtsValorRescisao != null) 'fgts_valor_rescisao': fgtsValorRescisao,
      if (fgtsSaldoBanco != null) 'fgts_saldo_banco': fgtsSaldoBanco,
      if (fgtsComplementoSaldo != null)
        'fgts_complemento_saldo': fgtsComplementoSaldo,
      if (fgtsCodigoAfastamento != null)
        'fgts_codigo_afastamento': fgtsCodigoAfastamento,
      if (fgtsCodigoSaque != null) 'fgts_codigo_saque': fgtsCodigoSaque,
    });
  }

  FolhaRescisaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataDemissao,
      Value<DateTime?>? dataPagamento,
      Value<String?>? motivo,
      Value<String?>? motivoEsocial,
      Value<DateTime?>? dataAvisoPrevio,
      Value<int?>? diasAvisoPrevio,
      Value<String?>? comprovouNovoEmprego,
      Value<String?>? dispensouEmpregado,
      Value<double?>? pensaoAlimenticia,
      Value<double?>? pensaoAlimenticiaFgts,
      Value<double?>? fgtsValorRescisao,
      Value<double?>? fgtsSaldoBanco,
      Value<double?>? fgtsComplementoSaldo,
      Value<String?>? fgtsCodigoAfastamento,
      Value<String?>? fgtsCodigoSaque}) {
    return FolhaRescisaosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      dataPagamento: dataPagamento ?? this.dataPagamento,
      motivo: motivo ?? this.motivo,
      motivoEsocial: motivoEsocial ?? this.motivoEsocial,
      dataAvisoPrevio: dataAvisoPrevio ?? this.dataAvisoPrevio,
      diasAvisoPrevio: diasAvisoPrevio ?? this.diasAvisoPrevio,
      comprovouNovoEmprego: comprovouNovoEmprego ?? this.comprovouNovoEmprego,
      dispensouEmpregado: dispensouEmpregado ?? this.dispensouEmpregado,
      pensaoAlimenticia: pensaoAlimenticia ?? this.pensaoAlimenticia,
      pensaoAlimenticiaFgts:
          pensaoAlimenticiaFgts ?? this.pensaoAlimenticiaFgts,
      fgtsValorRescisao: fgtsValorRescisao ?? this.fgtsValorRescisao,
      fgtsSaldoBanco: fgtsSaldoBanco ?? this.fgtsSaldoBanco,
      fgtsComplementoSaldo: fgtsComplementoSaldo ?? this.fgtsComplementoSaldo,
      fgtsCodigoAfastamento:
          fgtsCodigoAfastamento ?? this.fgtsCodigoAfastamento,
      fgtsCodigoSaque: fgtsCodigoSaque ?? this.fgtsCodigoSaque,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (dataPagamento.present) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento.value);
    }
    if (motivo.present) {
      map['motivo'] = Variable<String>(motivo.value);
    }
    if (motivoEsocial.present) {
      map['motivo_esocial'] = Variable<String>(motivoEsocial.value);
    }
    if (dataAvisoPrevio.present) {
      map['data_aviso_previo'] = Variable<DateTime>(dataAvisoPrevio.value);
    }
    if (diasAvisoPrevio.present) {
      map['dias_aviso_previo'] = Variable<int>(diasAvisoPrevio.value);
    }
    if (comprovouNovoEmprego.present) {
      map['comprovou_novo_emprego'] =
          Variable<String>(comprovouNovoEmprego.value);
    }
    if (dispensouEmpregado.present) {
      map['dispensou_empregado'] = Variable<String>(dispensouEmpregado.value);
    }
    if (pensaoAlimenticia.present) {
      map['pensao_alimenticia'] = Variable<double>(pensaoAlimenticia.value);
    }
    if (pensaoAlimenticiaFgts.present) {
      map['pensao_alimenticia_fgts'] =
          Variable<double>(pensaoAlimenticiaFgts.value);
    }
    if (fgtsValorRescisao.present) {
      map['fgts_valor_rescisao'] = Variable<double>(fgtsValorRescisao.value);
    }
    if (fgtsSaldoBanco.present) {
      map['fgts_saldo_banco'] = Variable<double>(fgtsSaldoBanco.value);
    }
    if (fgtsComplementoSaldo.present) {
      map['fgts_complemento_saldo'] =
          Variable<double>(fgtsComplementoSaldo.value);
    }
    if (fgtsCodigoAfastamento.present) {
      map['fgts_codigo_afastamento'] =
          Variable<String>(fgtsCodigoAfastamento.value);
    }
    if (fgtsCodigoSaque.present) {
      map['fgts_codigo_saque'] = Variable<String>(fgtsCodigoSaque.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaRescisaosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('motivo: $motivo, ')
          ..write('motivoEsocial: $motivoEsocial, ')
          ..write('dataAvisoPrevio: $dataAvisoPrevio, ')
          ..write('diasAvisoPrevio: $diasAvisoPrevio, ')
          ..write('comprovouNovoEmprego: $comprovouNovoEmprego, ')
          ..write('dispensouEmpregado: $dispensouEmpregado, ')
          ..write('pensaoAlimenticia: $pensaoAlimenticia, ')
          ..write('pensaoAlimenticiaFgts: $pensaoAlimenticiaFgts, ')
          ..write('fgtsValorRescisao: $fgtsValorRescisao, ')
          ..write('fgtsSaldoBanco: $fgtsSaldoBanco, ')
          ..write('fgtsComplementoSaldo: $fgtsComplementoSaldo, ')
          ..write('fgtsCodigoAfastamento: $fgtsCodigoAfastamento, ')
          ..write('fgtsCodigoSaque: $fgtsCodigoSaque')
          ..write(')'))
        .toString();
  }
}

class $FolhaFeriasColetivassTable extends FolhaFeriasColetivass
    with TableInfo<$FolhaFeriasColetivassTable, FolhaFeriasColetivas> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaFeriasColetivassTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diasGozoMeta =
      const VerificationMeta('diasGozo');
  @override
  late final GeneratedColumn<int> diasGozo = GeneratedColumn<int>(
      'dias_gozo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _abonoPecuniarioInicioMeta =
      const VerificationMeta('abonoPecuniarioInicio');
  @override
  late final GeneratedColumn<DateTime> abonoPecuniarioInicio =
      GeneratedColumn<DateTime>('abono_pecuniario_inicio', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _abonoPecuniarioFimMeta =
      const VerificationMeta('abonoPecuniarioFim');
  @override
  late final GeneratedColumn<DateTime> abonoPecuniarioFim =
      GeneratedColumn<DateTime>('abono_pecuniario_fim', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diasAbonoMeta =
      const VerificationMeta('diasAbono');
  @override
  late final GeneratedColumn<int> diasAbono = GeneratedColumn<int>(
      'dias_abono', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataPagamentoMeta =
      const VerificationMeta('dataPagamento');
  @override
  late final GeneratedColumn<DateTime> dataPagamento =
      GeneratedColumn<DateTime>('data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dataInicio,
        dataFim,
        diasGozo,
        abonoPecuniarioInicio,
        abonoPecuniarioFim,
        diasAbono,
        dataPagamento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_ferias_coletivas';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaFeriasColetivas> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('dias_gozo')) {
      context.handle(_diasGozoMeta,
          diasGozo.isAcceptableOrUnknown(data['dias_gozo']!, _diasGozoMeta));
    }
    if (data.containsKey('abono_pecuniario_inicio')) {
      context.handle(
          _abonoPecuniarioInicioMeta,
          abonoPecuniarioInicio.isAcceptableOrUnknown(
              data['abono_pecuniario_inicio']!, _abonoPecuniarioInicioMeta));
    }
    if (data.containsKey('abono_pecuniario_fim')) {
      context.handle(
          _abonoPecuniarioFimMeta,
          abonoPecuniarioFim.isAcceptableOrUnknown(
              data['abono_pecuniario_fim']!, _abonoPecuniarioFimMeta));
    }
    if (data.containsKey('dias_abono')) {
      context.handle(_diasAbonoMeta,
          diasAbono.isAcceptableOrUnknown(data['dias_abono']!, _diasAbonoMeta));
    }
    if (data.containsKey('data_pagamento')) {
      context.handle(
          _dataPagamentoMeta,
          dataPagamento.isAcceptableOrUnknown(
              data['data_pagamento']!, _dataPagamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaFeriasColetivas map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaFeriasColetivas(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      diasGozo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_gozo']),
      abonoPecuniarioInicio: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}abono_pecuniario_inicio']),
      abonoPecuniarioFim: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}abono_pecuniario_fim']),
      diasAbono: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_abono']),
      dataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_pagamento']),
    );
  }

  @override
  $FolhaFeriasColetivassTable createAlias(String alias) {
    return $FolhaFeriasColetivassTable(attachedDatabase, alias);
  }
}

class FolhaFeriasColetivas extends DataClass
    implements Insertable<FolhaFeriasColetivas> {
  final int? id;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final int? diasGozo;
  final DateTime? abonoPecuniarioInicio;
  final DateTime? abonoPecuniarioFim;
  final int? diasAbono;
  final DateTime? dataPagamento;
  const FolhaFeriasColetivas(
      {this.id,
      this.dataInicio,
      this.dataFim,
      this.diasGozo,
      this.abonoPecuniarioInicio,
      this.abonoPecuniarioFim,
      this.diasAbono,
      this.dataPagamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || diasGozo != null) {
      map['dias_gozo'] = Variable<int>(diasGozo);
    }
    if (!nullToAbsent || abonoPecuniarioInicio != null) {
      map['abono_pecuniario_inicio'] =
          Variable<DateTime>(abonoPecuniarioInicio);
    }
    if (!nullToAbsent || abonoPecuniarioFim != null) {
      map['abono_pecuniario_fim'] = Variable<DateTime>(abonoPecuniarioFim);
    }
    if (!nullToAbsent || diasAbono != null) {
      map['dias_abono'] = Variable<int>(diasAbono);
    }
    if (!nullToAbsent || dataPagamento != null) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento);
    }
    return map;
  }

  factory FolhaFeriasColetivas.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaFeriasColetivas(
      id: serializer.fromJson<int?>(json['id']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      diasGozo: serializer.fromJson<int?>(json['diasGozo']),
      abonoPecuniarioInicio:
          serializer.fromJson<DateTime?>(json['abonoPecuniarioInicio']),
      abonoPecuniarioFim:
          serializer.fromJson<DateTime?>(json['abonoPecuniarioFim']),
      diasAbono: serializer.fromJson<int?>(json['diasAbono']),
      dataPagamento: serializer.fromJson<DateTime?>(json['dataPagamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'diasGozo': serializer.toJson<int?>(diasGozo),
      'abonoPecuniarioInicio':
          serializer.toJson<DateTime?>(abonoPecuniarioInicio),
      'abonoPecuniarioFim': serializer.toJson<DateTime?>(abonoPecuniarioFim),
      'diasAbono': serializer.toJson<int?>(diasAbono),
      'dataPagamento': serializer.toJson<DateTime?>(dataPagamento),
    };
  }

  FolhaFeriasColetivas copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<int?> diasGozo = const Value.absent(),
          Value<DateTime?> abonoPecuniarioInicio = const Value.absent(),
          Value<DateTime?> abonoPecuniarioFim = const Value.absent(),
          Value<int?> diasAbono = const Value.absent(),
          Value<DateTime?> dataPagamento = const Value.absent()}) =>
      FolhaFeriasColetivas(
        id: id.present ? id.value : this.id,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        diasGozo: diasGozo.present ? diasGozo.value : this.diasGozo,
        abonoPecuniarioInicio: abonoPecuniarioInicio.present
            ? abonoPecuniarioInicio.value
            : this.abonoPecuniarioInicio,
        abonoPecuniarioFim: abonoPecuniarioFim.present
            ? abonoPecuniarioFim.value
            : this.abonoPecuniarioFim,
        diasAbono: diasAbono.present ? diasAbono.value : this.diasAbono,
        dataPagamento:
            dataPagamento.present ? dataPagamento.value : this.dataPagamento,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaFeriasColetivas(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('diasGozo: $diasGozo, ')
          ..write('abonoPecuniarioInicio: $abonoPecuniarioInicio, ')
          ..write('abonoPecuniarioFim: $abonoPecuniarioFim, ')
          ..write('diasAbono: $diasAbono, ')
          ..write('dataPagamento: $dataPagamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataInicio, dataFim, diasGozo,
      abonoPecuniarioInicio, abonoPecuniarioFim, diasAbono, dataPagamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaFeriasColetivas &&
          other.id == this.id &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.diasGozo == this.diasGozo &&
          other.abonoPecuniarioInicio == this.abonoPecuniarioInicio &&
          other.abonoPecuniarioFim == this.abonoPecuniarioFim &&
          other.diasAbono == this.diasAbono &&
          other.dataPagamento == this.dataPagamento);
}

class FolhaFeriasColetivassCompanion
    extends UpdateCompanion<FolhaFeriasColetivas> {
  final Value<int?> id;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<int?> diasGozo;
  final Value<DateTime?> abonoPecuniarioInicio;
  final Value<DateTime?> abonoPecuniarioFim;
  final Value<int?> diasAbono;
  final Value<DateTime?> dataPagamento;
  const FolhaFeriasColetivassCompanion({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.diasGozo = const Value.absent(),
    this.abonoPecuniarioInicio = const Value.absent(),
    this.abonoPecuniarioFim = const Value.absent(),
    this.diasAbono = const Value.absent(),
    this.dataPagamento = const Value.absent(),
  });
  FolhaFeriasColetivassCompanion.insert({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.diasGozo = const Value.absent(),
    this.abonoPecuniarioInicio = const Value.absent(),
    this.abonoPecuniarioFim = const Value.absent(),
    this.diasAbono = const Value.absent(),
    this.dataPagamento = const Value.absent(),
  });
  static Insertable<FolhaFeriasColetivas> custom({
    Expression<int>? id,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<int>? diasGozo,
    Expression<DateTime>? abonoPecuniarioInicio,
    Expression<DateTime>? abonoPecuniarioFim,
    Expression<int>? diasAbono,
    Expression<DateTime>? dataPagamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (diasGozo != null) 'dias_gozo': diasGozo,
      if (abonoPecuniarioInicio != null)
        'abono_pecuniario_inicio': abonoPecuniarioInicio,
      if (abonoPecuniarioFim != null)
        'abono_pecuniario_fim': abonoPecuniarioFim,
      if (diasAbono != null) 'dias_abono': diasAbono,
      if (dataPagamento != null) 'data_pagamento': dataPagamento,
    });
  }

  FolhaFeriasColetivassCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<int?>? diasGozo,
      Value<DateTime?>? abonoPecuniarioInicio,
      Value<DateTime?>? abonoPecuniarioFim,
      Value<int?>? diasAbono,
      Value<DateTime?>? dataPagamento}) {
    return FolhaFeriasColetivassCompanion(
      id: id ?? this.id,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      diasGozo: diasGozo ?? this.diasGozo,
      abonoPecuniarioInicio:
          abonoPecuniarioInicio ?? this.abonoPecuniarioInicio,
      abonoPecuniarioFim: abonoPecuniarioFim ?? this.abonoPecuniarioFim,
      diasAbono: diasAbono ?? this.diasAbono,
      dataPagamento: dataPagamento ?? this.dataPagamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (diasGozo.present) {
      map['dias_gozo'] = Variable<int>(diasGozo.value);
    }
    if (abonoPecuniarioInicio.present) {
      map['abono_pecuniario_inicio'] =
          Variable<DateTime>(abonoPecuniarioInicio.value);
    }
    if (abonoPecuniarioFim.present) {
      map['abono_pecuniario_fim'] =
          Variable<DateTime>(abonoPecuniarioFim.value);
    }
    if (diasAbono.present) {
      map['dias_abono'] = Variable<int>(diasAbono.value);
    }
    if (dataPagamento.present) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaFeriasColetivassCompanion(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('diasGozo: $diasGozo, ')
          ..write('abonoPecuniarioInicio: $abonoPecuniarioInicio, ')
          ..write('abonoPecuniarioFim: $abonoPecuniarioFim, ')
          ..write('diasAbono: $diasAbono, ')
          ..write('dataPagamento: $dataPagamento')
          ..write(')'))
        .toString();
  }
}

class $FolhaValeTransportesTable extends FolhaValeTransportes
    with TableInfo<$FolhaValeTransportesTable, FolhaValeTransporte> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaValeTransportesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEmpresaTranspItinMeta =
      const VerificationMeta('idEmpresaTranspItin');
  @override
  late final GeneratedColumn<int> idEmpresaTranspItin = GeneratedColumn<int>(
      'id_empresa_transp_itin', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, idEmpresaTranspItin, quantidade];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_vale_transporte';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaValeTransporte> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_empresa_transp_itin')) {
      context.handle(
          _idEmpresaTranspItinMeta,
          idEmpresaTranspItin.isAcceptableOrUnknown(
              data['id_empresa_transp_itin']!, _idEmpresaTranspItinMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaValeTransporte map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaValeTransporte(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idEmpresaTranspItin: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_empresa_transp_itin']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantidade']),
    );
  }

  @override
  $FolhaValeTransportesTable createAlias(String alias) {
    return $FolhaValeTransportesTable(attachedDatabase, alias);
  }
}

class FolhaValeTransporte extends DataClass
    implements Insertable<FolhaValeTransporte> {
  final int? id;
  final int? idColaborador;
  final int? idEmpresaTranspItin;
  final int? quantidade;
  const FolhaValeTransporte(
      {this.id, this.idColaborador, this.idEmpresaTranspItin, this.quantidade});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idEmpresaTranspItin != null) {
      map['id_empresa_transp_itin'] = Variable<int>(idEmpresaTranspItin);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    return map;
  }

  factory FolhaValeTransporte.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaValeTransporte(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idEmpresaTranspItin:
          serializer.fromJson<int?>(json['idEmpresaTranspItin']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idEmpresaTranspItin': serializer.toJson<int?>(idEmpresaTranspItin),
      'quantidade': serializer.toJson<int?>(quantidade),
    };
  }

  FolhaValeTransporte copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idEmpresaTranspItin = const Value.absent(),
          Value<int?> quantidade = const Value.absent()}) =>
      FolhaValeTransporte(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idEmpresaTranspItin: idEmpresaTranspItin.present
            ? idEmpresaTranspItin.value
            : this.idEmpresaTranspItin,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaValeTransporte(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idEmpresaTranspItin: $idEmpresaTranspItin, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idColaborador, idEmpresaTranspItin, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaValeTransporte &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idEmpresaTranspItin == this.idEmpresaTranspItin &&
          other.quantidade == this.quantidade);
}

class FolhaValeTransportesCompanion
    extends UpdateCompanion<FolhaValeTransporte> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idEmpresaTranspItin;
  final Value<int?> quantidade;
  const FolhaValeTransportesCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idEmpresaTranspItin = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  FolhaValeTransportesCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idEmpresaTranspItin = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<FolhaValeTransporte> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idEmpresaTranspItin,
    Expression<int>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idEmpresaTranspItin != null)
        'id_empresa_transp_itin': idEmpresaTranspItin,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  FolhaValeTransportesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? idEmpresaTranspItin,
      Value<int?>? quantidade}) {
    return FolhaValeTransportesCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idEmpresaTranspItin: idEmpresaTranspItin ?? this.idEmpresaTranspItin,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idEmpresaTranspItin.present) {
      map['id_empresa_transp_itin'] = Variable<int>(idEmpresaTranspItin.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaValeTransportesCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idEmpresaTranspItin: $idEmpresaTranspItin, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $FolhaInssServicosTable extends FolhaInssServicos
    with TableInfo<$FolhaInssServicosTable, FolhaInssServico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaInssServicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_inss_servico';
  @override
  VerificationContext validateIntegrity(Insertable<FolhaInssServico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaInssServico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaInssServico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FolhaInssServicosTable createAlias(String alias) {
    return $FolhaInssServicosTable(attachedDatabase, alias);
  }
}

class FolhaInssServico extends DataClass
    implements Insertable<FolhaInssServico> {
  final int? id;
  final String? codigo;
  final String? nome;
  const FolhaInssServico({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FolhaInssServico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaInssServico(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FolhaInssServico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FolhaInssServico(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaInssServico(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaInssServico &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FolhaInssServicosCompanion extends UpdateCompanion<FolhaInssServico> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FolhaInssServicosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FolhaInssServicosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FolhaInssServico> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FolhaInssServicosCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return FolhaInssServicosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaInssServicosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FolhaHistoricoSalarialsTable extends FolhaHistoricoSalarials
    with TableInfo<$FolhaHistoricoSalarialsTable, FolhaHistoricoSalarial> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FolhaHistoricoSalarialsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _salarioAtualMeta =
      const VerificationMeta('salarioAtual');
  @override
  late final GeneratedColumn<double> salarioAtual = GeneratedColumn<double>(
      'salario_atual', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _percentualAumentoMeta =
      const VerificationMeta('percentualAumento');
  @override
  late final GeneratedColumn<double> percentualAumento =
      GeneratedColumn<double>('percentual_aumento', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _salarioNovoMeta =
      const VerificationMeta('salarioNovo');
  @override
  late final GeneratedColumn<double> salarioNovo = GeneratedColumn<double>(
      'salario_novo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _validoAPartirMeta =
      const VerificationMeta('validoAPartir');
  @override
  late final GeneratedColumn<String> validoAPartir = GeneratedColumn<String>(
      'valido_a_partir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _motivoMeta = const VerificationMeta('motivo');
  @override
  late final GeneratedColumn<String> motivo = GeneratedColumn<String>(
      'motivo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        competencia,
        salarioAtual,
        percentualAumento,
        salarioNovo,
        validoAPartir,
        motivo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'folha_historico_salarial';
  @override
  VerificationContext validateIntegrity(
      Insertable<FolhaHistoricoSalarial> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('salario_atual')) {
      context.handle(
          _salarioAtualMeta,
          salarioAtual.isAcceptableOrUnknown(
              data['salario_atual']!, _salarioAtualMeta));
    }
    if (data.containsKey('percentual_aumento')) {
      context.handle(
          _percentualAumentoMeta,
          percentualAumento.isAcceptableOrUnknown(
              data['percentual_aumento']!, _percentualAumentoMeta));
    }
    if (data.containsKey('salario_novo')) {
      context.handle(
          _salarioNovoMeta,
          salarioNovo.isAcceptableOrUnknown(
              data['salario_novo']!, _salarioNovoMeta));
    }
    if (data.containsKey('valido_a_partir')) {
      context.handle(
          _validoAPartirMeta,
          validoAPartir.isAcceptableOrUnknown(
              data['valido_a_partir']!, _validoAPartirMeta));
    }
    if (data.containsKey('motivo')) {
      context.handle(_motivoMeta,
          motivo.isAcceptableOrUnknown(data['motivo']!, _motivoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FolhaHistoricoSalarial map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FolhaHistoricoSalarial(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      salarioAtual: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}salario_atual']),
      percentualAumento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}percentual_aumento']),
      salarioNovo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}salario_novo']),
      validoAPartir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}valido_a_partir']),
      motivo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}motivo']),
    );
  }

  @override
  $FolhaHistoricoSalarialsTable createAlias(String alias) {
    return $FolhaHistoricoSalarialsTable(attachedDatabase, alias);
  }
}

class FolhaHistoricoSalarial extends DataClass
    implements Insertable<FolhaHistoricoSalarial> {
  final int? id;
  final int? idColaborador;
  final String? competencia;
  final double? salarioAtual;
  final double? percentualAumento;
  final double? salarioNovo;
  final String? validoAPartir;
  final String? motivo;
  const FolhaHistoricoSalarial(
      {this.id,
      this.idColaborador,
      this.competencia,
      this.salarioAtual,
      this.percentualAumento,
      this.salarioNovo,
      this.validoAPartir,
      this.motivo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || salarioAtual != null) {
      map['salario_atual'] = Variable<double>(salarioAtual);
    }
    if (!nullToAbsent || percentualAumento != null) {
      map['percentual_aumento'] = Variable<double>(percentualAumento);
    }
    if (!nullToAbsent || salarioNovo != null) {
      map['salario_novo'] = Variable<double>(salarioNovo);
    }
    if (!nullToAbsent || validoAPartir != null) {
      map['valido_a_partir'] = Variable<String>(validoAPartir);
    }
    if (!nullToAbsent || motivo != null) {
      map['motivo'] = Variable<String>(motivo);
    }
    return map;
  }

  factory FolhaHistoricoSalarial.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FolhaHistoricoSalarial(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      salarioAtual: serializer.fromJson<double?>(json['salarioAtual']),
      percentualAumento:
          serializer.fromJson<double?>(json['percentualAumento']),
      salarioNovo: serializer.fromJson<double?>(json['salarioNovo']),
      validoAPartir: serializer.fromJson<String?>(json['validoAPartir']),
      motivo: serializer.fromJson<String?>(json['motivo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'competencia': serializer.toJson<String?>(competencia),
      'salarioAtual': serializer.toJson<double?>(salarioAtual),
      'percentualAumento': serializer.toJson<double?>(percentualAumento),
      'salarioNovo': serializer.toJson<double?>(salarioNovo),
      'validoAPartir': serializer.toJson<String?>(validoAPartir),
      'motivo': serializer.toJson<String?>(motivo),
    };
  }

  FolhaHistoricoSalarial copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<double?> salarioAtual = const Value.absent(),
          Value<double?> percentualAumento = const Value.absent(),
          Value<double?> salarioNovo = const Value.absent(),
          Value<String?> validoAPartir = const Value.absent(),
          Value<String?> motivo = const Value.absent()}) =>
      FolhaHistoricoSalarial(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        competencia: competencia.present ? competencia.value : this.competencia,
        salarioAtual:
            salarioAtual.present ? salarioAtual.value : this.salarioAtual,
        percentualAumento: percentualAumento.present
            ? percentualAumento.value
            : this.percentualAumento,
        salarioNovo: salarioNovo.present ? salarioNovo.value : this.salarioNovo,
        validoAPartir:
            validoAPartir.present ? validoAPartir.value : this.validoAPartir,
        motivo: motivo.present ? motivo.value : this.motivo,
      );
  @override
  String toString() {
    return (StringBuffer('FolhaHistoricoSalarial(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('salarioAtual: $salarioAtual, ')
          ..write('percentualAumento: $percentualAumento, ')
          ..write('salarioNovo: $salarioNovo, ')
          ..write('validoAPartir: $validoAPartir, ')
          ..write('motivo: $motivo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, competencia, salarioAtual,
      percentualAumento, salarioNovo, validoAPartir, motivo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FolhaHistoricoSalarial &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.competencia == this.competencia &&
          other.salarioAtual == this.salarioAtual &&
          other.percentualAumento == this.percentualAumento &&
          other.salarioNovo == this.salarioNovo &&
          other.validoAPartir == this.validoAPartir &&
          other.motivo == this.motivo);
}

class FolhaHistoricoSalarialsCompanion
    extends UpdateCompanion<FolhaHistoricoSalarial> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<String?> competencia;
  final Value<double?> salarioAtual;
  final Value<double?> percentualAumento;
  final Value<double?> salarioNovo;
  final Value<String?> validoAPartir;
  final Value<String?> motivo;
  const FolhaHistoricoSalarialsCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.salarioAtual = const Value.absent(),
    this.percentualAumento = const Value.absent(),
    this.salarioNovo = const Value.absent(),
    this.validoAPartir = const Value.absent(),
    this.motivo = const Value.absent(),
  });
  FolhaHistoricoSalarialsCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.competencia = const Value.absent(),
    this.salarioAtual = const Value.absent(),
    this.percentualAumento = const Value.absent(),
    this.salarioNovo = const Value.absent(),
    this.validoAPartir = const Value.absent(),
    this.motivo = const Value.absent(),
  });
  static Insertable<FolhaHistoricoSalarial> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<String>? competencia,
    Expression<double>? salarioAtual,
    Expression<double>? percentualAumento,
    Expression<double>? salarioNovo,
    Expression<String>? validoAPartir,
    Expression<String>? motivo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (competencia != null) 'competencia': competencia,
      if (salarioAtual != null) 'salario_atual': salarioAtual,
      if (percentualAumento != null) 'percentual_aumento': percentualAumento,
      if (salarioNovo != null) 'salario_novo': salarioNovo,
      if (validoAPartir != null) 'valido_a_partir': validoAPartir,
      if (motivo != null) 'motivo': motivo,
    });
  }

  FolhaHistoricoSalarialsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<String?>? competencia,
      Value<double?>? salarioAtual,
      Value<double?>? percentualAumento,
      Value<double?>? salarioNovo,
      Value<String?>? validoAPartir,
      Value<String?>? motivo}) {
    return FolhaHistoricoSalarialsCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      competencia: competencia ?? this.competencia,
      salarioAtual: salarioAtual ?? this.salarioAtual,
      percentualAumento: percentualAumento ?? this.percentualAumento,
      salarioNovo: salarioNovo ?? this.salarioNovo,
      validoAPartir: validoAPartir ?? this.validoAPartir,
      motivo: motivo ?? this.motivo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (salarioAtual.present) {
      map['salario_atual'] = Variable<double>(salarioAtual.value);
    }
    if (percentualAumento.present) {
      map['percentual_aumento'] = Variable<double>(percentualAumento.value);
    }
    if (salarioNovo.present) {
      map['salario_novo'] = Variable<double>(salarioNovo.value);
    }
    if (validoAPartir.present) {
      map['valido_a_partir'] = Variable<String>(validoAPartir.value);
    }
    if (motivo.present) {
      map['motivo'] = Variable<String>(motivo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FolhaHistoricoSalarialsCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('competencia: $competencia, ')
          ..write('salarioAtual: $salarioAtual, ')
          ..write('percentualAumento: $percentualAumento, ')
          ..write('salarioNovo: $salarioNovo, ')
          ..write('validoAPartir: $validoAPartir, ')
          ..write('motivo: $motivo')
          ..write(')'))
        .toString();
  }
}

class $FeriadossTable extends Feriadoss
    with TableInfo<$FeriadossTable, Feriados> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FeriadossTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
      'ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _abrangenciaMeta =
      const VerificationMeta('abrangencia');
  @override
  late final GeneratedColumn<String> abrangencia = GeneratedColumn<String>(
      'abrangencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<int> municipioIbge = GeneratedColumn<int>(
      'municipio_ibge', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataFeriadoMeta =
      const VerificationMeta('dataFeriado');
  @override
  late final GeneratedColumn<DateTime> dataFeriado = GeneratedColumn<DateTime>(
      'data_feriado', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, ano, nome, abrangencia, uf, municipioIbge, tipo, dataFeriado];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'feriados';
  @override
  VerificationContext validateIntegrity(Insertable<Feriados> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('ano')) {
      context.handle(
          _anoMeta, ano.isAcceptableOrUnknown(data['ano']!, _anoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('abrangencia')) {
      context.handle(
          _abrangenciaMeta,
          abrangencia.isAcceptableOrUnknown(
              data['abrangencia']!, _abrangenciaMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('data_feriado')) {
      context.handle(
          _dataFeriadoMeta,
          dataFeriado.isAcceptableOrUnknown(
              data['data_feriado']!, _dataFeriadoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Feriados map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Feriados(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      ano: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ano']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      abrangencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}abrangencia']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}municipio_ibge']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      dataFeriado: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_feriado']),
    );
  }

  @override
  $FeriadossTable createAlias(String alias) {
    return $FeriadossTable(attachedDatabase, alias);
  }
}

class Feriados extends DataClass implements Insertable<Feriados> {
  final int? id;
  final String? ano;
  final String? nome;
  final String? abrangencia;
  final String? uf;
  final int? municipioIbge;
  final String? tipo;
  final DateTime? dataFeriado;
  const Feriados(
      {this.id,
      this.ano,
      this.nome,
      this.abrangencia,
      this.uf,
      this.municipioIbge,
      this.tipo,
      this.dataFeriado});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || abrangencia != null) {
      map['abrangencia'] = Variable<String>(abrangencia);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<int>(municipioIbge);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || dataFeriado != null) {
      map['data_feriado'] = Variable<DateTime>(dataFeriado);
    }
    return map;
  }

  factory Feriados.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Feriados(
      id: serializer.fromJson<int?>(json['id']),
      ano: serializer.fromJson<String?>(json['ano']),
      nome: serializer.fromJson<String?>(json['nome']),
      abrangencia: serializer.fromJson<String?>(json['abrangencia']),
      uf: serializer.fromJson<String?>(json['uf']),
      municipioIbge: serializer.fromJson<int?>(json['municipioIbge']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      dataFeriado: serializer.fromJson<DateTime?>(json['dataFeriado']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'ano': serializer.toJson<String?>(ano),
      'nome': serializer.toJson<String?>(nome),
      'abrangencia': serializer.toJson<String?>(abrangencia),
      'uf': serializer.toJson<String?>(uf),
      'municipioIbge': serializer.toJson<int?>(municipioIbge),
      'tipo': serializer.toJson<String?>(tipo),
      'dataFeriado': serializer.toJson<DateTime?>(dataFeriado),
    };
  }

  Feriados copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> ano = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> abrangencia = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> municipioIbge = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<DateTime?> dataFeriado = const Value.absent()}) =>
      Feriados(
        id: id.present ? id.value : this.id,
        ano: ano.present ? ano.value : this.ano,
        nome: nome.present ? nome.value : this.nome,
        abrangencia: abrangencia.present ? abrangencia.value : this.abrangencia,
        uf: uf.present ? uf.value : this.uf,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        tipo: tipo.present ? tipo.value : this.tipo,
        dataFeriado: dataFeriado.present ? dataFeriado.value : this.dataFeriado,
      );
  @override
  String toString() {
    return (StringBuffer('Feriados(')
          ..write('id: $id, ')
          ..write('ano: $ano, ')
          ..write('nome: $nome, ')
          ..write('abrangencia: $abrangencia, ')
          ..write('uf: $uf, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('tipo: $tipo, ')
          ..write('dataFeriado: $dataFeriado')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, ano, nome, abrangencia, uf, municipioIbge, tipo, dataFeriado);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Feriados &&
          other.id == this.id &&
          other.ano == this.ano &&
          other.nome == this.nome &&
          other.abrangencia == this.abrangencia &&
          other.uf == this.uf &&
          other.municipioIbge == this.municipioIbge &&
          other.tipo == this.tipo &&
          other.dataFeriado == this.dataFeriado);
}

class FeriadossCompanion extends UpdateCompanion<Feriados> {
  final Value<int?> id;
  final Value<String?> ano;
  final Value<String?> nome;
  final Value<String?> abrangencia;
  final Value<String?> uf;
  final Value<int?> municipioIbge;
  final Value<String?> tipo;
  final Value<DateTime?> dataFeriado;
  const FeriadossCompanion({
    this.id = const Value.absent(),
    this.ano = const Value.absent(),
    this.nome = const Value.absent(),
    this.abrangencia = const Value.absent(),
    this.uf = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataFeriado = const Value.absent(),
  });
  FeriadossCompanion.insert({
    this.id = const Value.absent(),
    this.ano = const Value.absent(),
    this.nome = const Value.absent(),
    this.abrangencia = const Value.absent(),
    this.uf = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataFeriado = const Value.absent(),
  });
  static Insertable<Feriados> custom({
    Expression<int>? id,
    Expression<String>? ano,
    Expression<String>? nome,
    Expression<String>? abrangencia,
    Expression<String>? uf,
    Expression<int>? municipioIbge,
    Expression<String>? tipo,
    Expression<DateTime>? dataFeriado,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (ano != null) 'ano': ano,
      if (nome != null) 'nome': nome,
      if (abrangencia != null) 'abrangencia': abrangencia,
      if (uf != null) 'uf': uf,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (tipo != null) 'tipo': tipo,
      if (dataFeriado != null) 'data_feriado': dataFeriado,
    });
  }

  FeriadossCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? ano,
      Value<String?>? nome,
      Value<String?>? abrangencia,
      Value<String?>? uf,
      Value<int?>? municipioIbge,
      Value<String?>? tipo,
      Value<DateTime?>? dataFeriado}) {
    return FeriadossCompanion(
      id: id ?? this.id,
      ano: ano ?? this.ano,
      nome: nome ?? this.nome,
      abrangencia: abrangencia ?? this.abrangencia,
      uf: uf ?? this.uf,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      tipo: tipo ?? this.tipo,
      dataFeriado: dataFeriado ?? this.dataFeriado,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (abrangencia.present) {
      map['abrangencia'] = Variable<String>(abrangencia.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<int>(municipioIbge.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (dataFeriado.present) {
      map['data_feriado'] = Variable<DateTime>(dataFeriado.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FeriadossCompanion(')
          ..write('id: $id, ')
          ..write('ano: $ano, ')
          ..write('nome: $nome, ')
          ..write('abrangencia: $abrangencia, ')
          ..write('uf: $uf, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('tipo: $tipo, ')
          ..write('dataFeriado: $dataFeriado')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $EmpresaTransporteItinerariosTable empresaTransporteItinerarios =
      $EmpresaTransporteItinerariosTable(this);
  late final $FolhaLancamentoDetalhesTable folhaLancamentoDetalhes =
      $FolhaLancamentoDetalhesTable(this);
  late final $FolhaInssRetencaosTable folhaInssRetencaos =
      $FolhaInssRetencaosTable(this);
  late final $FolhaPppCatsTable folhaPppCats = $FolhaPppCatsTable(this);
  late final $FolhaPppAtividadesTable folhaPppAtividades =
      $FolhaPppAtividadesTable(this);
  late final $FolhaPppFatorRiscosTable folhaPppFatorRiscos =
      $FolhaPppFatorRiscosTable(this);
  late final $FolhaPppExameMedicosTable folhaPppExameMedicos =
      $FolhaPppExameMedicosTable(this);
  late final $EmpresaTransportesTable empresaTransportes =
      $EmpresaTransportesTable(this);
  late final $FolhaLancamentoCabecalhosTable folhaLancamentoCabecalhos =
      $FolhaLancamentoCabecalhosTable(this);
  late final $FolhaInsssTable folhaInsss = $FolhaInsssTable(this);
  late final $FolhaPppsTable folhaPpps = $FolhaPppsTable(this);
  late final $OperadoraPlanoSaudesTable operadoraPlanoSaudes =
      $OperadoraPlanoSaudesTable(this);
  late final $FolhaLancamentoComissaosTable folhaLancamentoComissaos =
      $FolhaLancamentoComissaosTable(this);
  late final $FolhaParametrosTable folhaParametros =
      $FolhaParametrosTable(this);
  late final $GuiasAcumuladassTable guiasAcumuladass =
      $GuiasAcumuladassTable(this);
  late final $FolhaFechamentosTable folhaFechamentos =
      $FolhaFechamentosTable(this);
  late final $FeriasPeriodoAquisitivosTable feriasPeriodoAquisitivos =
      $FeriasPeriodoAquisitivosTable(this);
  late final $FolhaTipoAfastamentosTable folhaTipoAfastamentos =
      $FolhaTipoAfastamentosTable(this);
  late final $FolhaAfastamentosTable folhaAfastamentos =
      $FolhaAfastamentosTable(this);
  late final $FolhaPlanoSaudesTable folhaPlanoSaudes =
      $FolhaPlanoSaudesTable(this);
  late final $FolhaEventosTable folhaEventos = $FolhaEventosTable(this);
  late final $FolhaRescisaosTable folhaRescisaos = $FolhaRescisaosTable(this);
  late final $FolhaFeriasColetivassTable folhaFeriasColetivass =
      $FolhaFeriasColetivassTable(this);
  late final $FolhaValeTransportesTable folhaValeTransportes =
      $FolhaValeTransportesTable(this);
  late final $FolhaInssServicosTable folhaInssServicos =
      $FolhaInssServicosTable(this);
  late final $FolhaHistoricoSalarialsTable folhaHistoricoSalarials =
      $FolhaHistoricoSalarialsTable(this);
  late final $FeriadossTable feriadoss = $FeriadossTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final EmpresaTransporteDao empresaTransporteDao =
      EmpresaTransporteDao(this as AppDatabase);
  late final FolhaLancamentoCabecalhoDao folhaLancamentoCabecalhoDao =
      FolhaLancamentoCabecalhoDao(this as AppDatabase);
  late final FolhaInssDao folhaInssDao = FolhaInssDao(this as AppDatabase);
  late final FolhaPppDao folhaPppDao = FolhaPppDao(this as AppDatabase);
  late final OperadoraPlanoSaudeDao operadoraPlanoSaudeDao =
      OperadoraPlanoSaudeDao(this as AppDatabase);
  late final FolhaLancamentoComissaoDao folhaLancamentoComissaoDao =
      FolhaLancamentoComissaoDao(this as AppDatabase);
  late final FolhaParametroDao folhaParametroDao =
      FolhaParametroDao(this as AppDatabase);
  late final GuiasAcumuladasDao guiasAcumuladasDao =
      GuiasAcumuladasDao(this as AppDatabase);
  late final FolhaFechamentoDao folhaFechamentoDao =
      FolhaFechamentoDao(this as AppDatabase);
  late final FeriasPeriodoAquisitivoDao feriasPeriodoAquisitivoDao =
      FeriasPeriodoAquisitivoDao(this as AppDatabase);
  late final FolhaTipoAfastamentoDao folhaTipoAfastamentoDao =
      FolhaTipoAfastamentoDao(this as AppDatabase);
  late final FolhaAfastamentoDao folhaAfastamentoDao =
      FolhaAfastamentoDao(this as AppDatabase);
  late final FolhaPlanoSaudeDao folhaPlanoSaudeDao =
      FolhaPlanoSaudeDao(this as AppDatabase);
  late final FolhaEventoDao folhaEventoDao =
      FolhaEventoDao(this as AppDatabase);
  late final FolhaRescisaoDao folhaRescisaoDao =
      FolhaRescisaoDao(this as AppDatabase);
  late final FolhaFeriasColetivasDao folhaFeriasColetivasDao =
      FolhaFeriasColetivasDao(this as AppDatabase);
  late final FolhaValeTransporteDao folhaValeTransporteDao =
      FolhaValeTransporteDao(this as AppDatabase);
  late final FolhaInssServicoDao folhaInssServicoDao =
      FolhaInssServicoDao(this as AppDatabase);
  late final FolhaHistoricoSalarialDao folhaHistoricoSalarialDao =
      FolhaHistoricoSalarialDao(this as AppDatabase);
  late final FeriadosDao feriadosDao = FeriadosDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        empresaTransporteItinerarios,
        folhaLancamentoDetalhes,
        folhaInssRetencaos,
        folhaPppCats,
        folhaPppAtividades,
        folhaPppFatorRiscos,
        folhaPppExameMedicos,
        empresaTransportes,
        folhaLancamentoCabecalhos,
        folhaInsss,
        folhaPpps,
        operadoraPlanoSaudes,
        folhaLancamentoComissaos,
        folhaParametros,
        guiasAcumuladass,
        folhaFechamentos,
        feriasPeriodoAquisitivos,
        folhaTipoAfastamentos,
        folhaAfastamentos,
        folhaPlanoSaudes,
        folhaEventos,
        folhaRescisaos,
        folhaFeriasColetivass,
        folhaValeTransportes,
        folhaInssServicos,
        folhaHistoricoSalarials,
        feriadoss,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaColaboradors
      ];
}
