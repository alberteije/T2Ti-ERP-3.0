// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'operadora_plano_saude_dao.dart';

// ignore_for_file: type=lint
mixin _$OperadoraPlanoSaudeDaoMixin on DatabaseAccessor<AppDatabase> {
  $OperadoraPlanoSaudesTable get operadoraPlanoSaudes =>
      attachedDatabase.operadoraPlanoSaudes;
}
