// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contrato_template_dao.dart';

// ignore_for_file: type=lint
mixin _$ContratoTemplateDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContratoTemplatesTable get contratoTemplates =>
      attachedDatabase.contratoTemplates;
}
