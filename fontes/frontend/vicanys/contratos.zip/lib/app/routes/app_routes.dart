abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const contratoListPage = '/contratoListPage'; 
	static const contratoTabPage = '/contratoTabPage';
	static const tipoContratoListPage = '/tipoContratoListPage'; 
	static const tipoContratoEditPage = '/tipoContratoEditPage';
	static const contratoTipoServicoListPage = '/contratoTipoServicoListPage'; 
	static const contratoTipoServicoEditPage = '/contratoTipoServicoEditPage';
	static const contratoSolicitacaoServicoListPage = '/contratoSolicitacaoServicoListPage'; 
	static const contratoSolicitacaoServicoEditPage = '/contratoSolicitacaoServicoEditPage';
	static const contratoTemplateListPage = '/contratoTemplateListPage'; 
	static const contratoTemplateEditPage = '/contratoTemplateEditPage';
}