// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_classificacao_jornada_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoClassificacaoJornadaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoClassificacaoJornadasTable get pontoClassificacaoJornadas =>
      attachedDatabase.pontoClassificacaoJornadas;
}
