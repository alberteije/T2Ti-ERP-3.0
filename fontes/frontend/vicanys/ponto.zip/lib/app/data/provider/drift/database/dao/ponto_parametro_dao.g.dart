// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_parametro_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoParametroDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoParametrosTable get pontoParametros => attachedDatabase.pontoParametros;
}
