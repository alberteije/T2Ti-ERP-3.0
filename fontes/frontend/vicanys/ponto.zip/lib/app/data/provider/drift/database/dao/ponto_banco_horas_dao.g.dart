// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_banco_horas_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoBancoHorasDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoBancoHorassTable get pontoBancoHorass =>
      attachedDatabase.pontoBancoHorass;
  $PontoBancoHorasUtilizacaosTable get pontoBancoHorasUtilizacaos =>
      attachedDatabase.pontoBancoHorasUtilizacaos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
