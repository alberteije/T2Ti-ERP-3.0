// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PontoTurmasTable extends PontoTurmas
    with TableInfo<$PontoTurmasTable, PontoTurma> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoTurmasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPontoEscalaMeta =
      const VerificationMeta('idPontoEscala');
  @override
  late final GeneratedColumn<int> idPontoEscala = GeneratedColumn<int>(
      'id_ponto_escala', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 5),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idPontoEscala, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_turma';
  @override
  VerificationContext validateIntegrity(Insertable<PontoTurma> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ponto_escala')) {
      context.handle(
          _idPontoEscalaMeta,
          idPontoEscala.isAcceptableOrUnknown(
              data['id_ponto_escala']!, _idPontoEscalaMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoTurma map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoTurma(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPontoEscala: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_ponto_escala']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $PontoTurmasTable createAlias(String alias) {
    return $PontoTurmasTable(attachedDatabase, alias);
  }
}

class PontoTurma extends DataClass implements Insertable<PontoTurma> {
  final int? id;
  final int? idPontoEscala;
  final String? codigo;
  final String? nome;
  const PontoTurma({this.id, this.idPontoEscala, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPontoEscala != null) {
      map['id_ponto_escala'] = Variable<int>(idPontoEscala);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory PontoTurma.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoTurma(
      id: serializer.fromJson<int?>(json['id']),
      idPontoEscala: serializer.fromJson<int?>(json['idPontoEscala']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPontoEscala': serializer.toJson<int?>(idPontoEscala),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  PontoTurma copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPontoEscala = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      PontoTurma(
        id: id.present ? id.value : this.id,
        idPontoEscala:
            idPontoEscala.present ? idPontoEscala.value : this.idPontoEscala,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('PontoTurma(')
          ..write('id: $id, ')
          ..write('idPontoEscala: $idPontoEscala, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPontoEscala, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoTurma &&
          other.id == this.id &&
          other.idPontoEscala == this.idPontoEscala &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class PontoTurmasCompanion extends UpdateCompanion<PontoTurma> {
  final Value<int?> id;
  final Value<int?> idPontoEscala;
  final Value<String?> codigo;
  final Value<String?> nome;
  const PontoTurmasCompanion({
    this.id = const Value.absent(),
    this.idPontoEscala = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  PontoTurmasCompanion.insert({
    this.id = const Value.absent(),
    this.idPontoEscala = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<PontoTurma> custom({
    Expression<int>? id,
    Expression<int>? idPontoEscala,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPontoEscala != null) 'id_ponto_escala': idPontoEscala,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  PontoTurmasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPontoEscala,
      Value<String?>? codigo,
      Value<String?>? nome}) {
    return PontoTurmasCompanion(
      id: id ?? this.id,
      idPontoEscala: idPontoEscala ?? this.idPontoEscala,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPontoEscala.present) {
      map['id_ponto_escala'] = Variable<int>(idPontoEscala.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoTurmasCompanion(')
          ..write('id: $id, ')
          ..write('idPontoEscala: $idPontoEscala, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $PontoAbonoUtilizacaosTable extends PontoAbonoUtilizacaos
    with TableInfo<$PontoAbonoUtilizacaosTable, PontoAbonoUtilizacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoAbonoUtilizacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPontoAbonoMeta =
      const VerificationMeta('idPontoAbono');
  @override
  late final GeneratedColumn<int> idPontoAbono = GeneratedColumn<int>(
      'id_ponto_abono', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataUtilizacaoMeta =
      const VerificationMeta('dataUtilizacao');
  @override
  late final GeneratedColumn<DateTime> dataUtilizacao =
      GeneratedColumn<DateTime>('data_utilizacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPontoAbono, dataUtilizacao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_abono_utilizacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PontoAbonoUtilizacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ponto_abono')) {
      context.handle(
          _idPontoAbonoMeta,
          idPontoAbono.isAcceptableOrUnknown(
              data['id_ponto_abono']!, _idPontoAbonoMeta));
    }
    if (data.containsKey('data_utilizacao')) {
      context.handle(
          _dataUtilizacaoMeta,
          dataUtilizacao.isAcceptableOrUnknown(
              data['data_utilizacao']!, _dataUtilizacaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoAbonoUtilizacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoAbonoUtilizacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPontoAbono: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_ponto_abono']),
      dataUtilizacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_utilizacao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PontoAbonoUtilizacaosTable createAlias(String alias) {
    return $PontoAbonoUtilizacaosTable(attachedDatabase, alias);
  }
}

class PontoAbonoUtilizacao extends DataClass
    implements Insertable<PontoAbonoUtilizacao> {
  final int? id;
  final int? idPontoAbono;
  final DateTime? dataUtilizacao;
  final String? observacao;
  const PontoAbonoUtilizacao(
      {this.id, this.idPontoAbono, this.dataUtilizacao, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPontoAbono != null) {
      map['id_ponto_abono'] = Variable<int>(idPontoAbono);
    }
    if (!nullToAbsent || dataUtilizacao != null) {
      map['data_utilizacao'] = Variable<DateTime>(dataUtilizacao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PontoAbonoUtilizacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoAbonoUtilizacao(
      id: serializer.fromJson<int?>(json['id']),
      idPontoAbono: serializer.fromJson<int?>(json['idPontoAbono']),
      dataUtilizacao: serializer.fromJson<DateTime?>(json['dataUtilizacao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPontoAbono': serializer.toJson<int?>(idPontoAbono),
      'dataUtilizacao': serializer.toJson<DateTime?>(dataUtilizacao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PontoAbonoUtilizacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPontoAbono = const Value.absent(),
          Value<DateTime?> dataUtilizacao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PontoAbonoUtilizacao(
        id: id.present ? id.value : this.id,
        idPontoAbono:
            idPontoAbono.present ? idPontoAbono.value : this.idPontoAbono,
        dataUtilizacao:
            dataUtilizacao.present ? dataUtilizacao.value : this.dataUtilizacao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoAbonoUtilizacao(')
          ..write('id: $id, ')
          ..write('idPontoAbono: $idPontoAbono, ')
          ..write('dataUtilizacao: $dataUtilizacao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPontoAbono, dataUtilizacao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoAbonoUtilizacao &&
          other.id == this.id &&
          other.idPontoAbono == this.idPontoAbono &&
          other.dataUtilizacao == this.dataUtilizacao &&
          other.observacao == this.observacao);
}

class PontoAbonoUtilizacaosCompanion
    extends UpdateCompanion<PontoAbonoUtilizacao> {
  final Value<int?> id;
  final Value<int?> idPontoAbono;
  final Value<DateTime?> dataUtilizacao;
  final Value<String?> observacao;
  const PontoAbonoUtilizacaosCompanion({
    this.id = const Value.absent(),
    this.idPontoAbono = const Value.absent(),
    this.dataUtilizacao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PontoAbonoUtilizacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idPontoAbono = const Value.absent(),
    this.dataUtilizacao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PontoAbonoUtilizacao> custom({
    Expression<int>? id,
    Expression<int>? idPontoAbono,
    Expression<DateTime>? dataUtilizacao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPontoAbono != null) 'id_ponto_abono': idPontoAbono,
      if (dataUtilizacao != null) 'data_utilizacao': dataUtilizacao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PontoAbonoUtilizacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPontoAbono,
      Value<DateTime?>? dataUtilizacao,
      Value<String?>? observacao}) {
    return PontoAbonoUtilizacaosCompanion(
      id: id ?? this.id,
      idPontoAbono: idPontoAbono ?? this.idPontoAbono,
      dataUtilizacao: dataUtilizacao ?? this.dataUtilizacao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPontoAbono.present) {
      map['id_ponto_abono'] = Variable<int>(idPontoAbono.value);
    }
    if (dataUtilizacao.present) {
      map['data_utilizacao'] = Variable<DateTime>(dataUtilizacao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoAbonoUtilizacaosCompanion(')
          ..write('id: $id, ')
          ..write('idPontoAbono: $idPontoAbono, ')
          ..write('dataUtilizacao: $dataUtilizacao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PontoBancoHorasUtilizacaosTable extends PontoBancoHorasUtilizacaos
    with
        TableInfo<$PontoBancoHorasUtilizacaosTable, PontoBancoHorasUtilizacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoBancoHorasUtilizacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPontoBancoHorasMeta =
      const VerificationMeta('idPontoBancoHoras');
  @override
  late final GeneratedColumn<int> idPontoBancoHoras = GeneratedColumn<int>(
      'id_ponto_banco_horas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataUtilizacaoMeta =
      const VerificationMeta('dataUtilizacao');
  @override
  late final GeneratedColumn<DateTime> dataUtilizacao =
      GeneratedColumn<DateTime>('data_utilizacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeUtilizadaMeta =
      const VerificationMeta('quantidadeUtilizada');
  @override
  late final GeneratedColumn<String> quantidadeUtilizada =
      GeneratedColumn<String>('quantidade_utilizada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPontoBancoHoras, dataUtilizacao, quantidadeUtilizada, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_banco_horas_utilizacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<PontoBancoHorasUtilizacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ponto_banco_horas')) {
      context.handle(
          _idPontoBancoHorasMeta,
          idPontoBancoHoras.isAcceptableOrUnknown(
              data['id_ponto_banco_horas']!, _idPontoBancoHorasMeta));
    }
    if (data.containsKey('data_utilizacao')) {
      context.handle(
          _dataUtilizacaoMeta,
          dataUtilizacao.isAcceptableOrUnknown(
              data['data_utilizacao']!, _dataUtilizacaoMeta));
    }
    if (data.containsKey('quantidade_utilizada')) {
      context.handle(
          _quantidadeUtilizadaMeta,
          quantidadeUtilizada.isAcceptableOrUnknown(
              data['quantidade_utilizada']!, _quantidadeUtilizadaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoBancoHorasUtilizacao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoBancoHorasUtilizacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPontoBancoHoras: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_ponto_banco_horas']),
      dataUtilizacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_utilizacao']),
      quantidadeUtilizada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}quantidade_utilizada']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PontoBancoHorasUtilizacaosTable createAlias(String alias) {
    return $PontoBancoHorasUtilizacaosTable(attachedDatabase, alias);
  }
}

class PontoBancoHorasUtilizacao extends DataClass
    implements Insertable<PontoBancoHorasUtilizacao> {
  final int? id;
  final int? idPontoBancoHoras;
  final DateTime? dataUtilizacao;
  final String? quantidadeUtilizada;
  final String? observacao;
  const PontoBancoHorasUtilizacao(
      {this.id,
      this.idPontoBancoHoras,
      this.dataUtilizacao,
      this.quantidadeUtilizada,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPontoBancoHoras != null) {
      map['id_ponto_banco_horas'] = Variable<int>(idPontoBancoHoras);
    }
    if (!nullToAbsent || dataUtilizacao != null) {
      map['data_utilizacao'] = Variable<DateTime>(dataUtilizacao);
    }
    if (!nullToAbsent || quantidadeUtilizada != null) {
      map['quantidade_utilizada'] = Variable<String>(quantidadeUtilizada);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PontoBancoHorasUtilizacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoBancoHorasUtilizacao(
      id: serializer.fromJson<int?>(json['id']),
      idPontoBancoHoras: serializer.fromJson<int?>(json['idPontoBancoHoras']),
      dataUtilizacao: serializer.fromJson<DateTime?>(json['dataUtilizacao']),
      quantidadeUtilizada:
          serializer.fromJson<String?>(json['quantidadeUtilizada']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPontoBancoHoras': serializer.toJson<int?>(idPontoBancoHoras),
      'dataUtilizacao': serializer.toJson<DateTime?>(dataUtilizacao),
      'quantidadeUtilizada': serializer.toJson<String?>(quantidadeUtilizada),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PontoBancoHorasUtilizacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPontoBancoHoras = const Value.absent(),
          Value<DateTime?> dataUtilizacao = const Value.absent(),
          Value<String?> quantidadeUtilizada = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PontoBancoHorasUtilizacao(
        id: id.present ? id.value : this.id,
        idPontoBancoHoras: idPontoBancoHoras.present
            ? idPontoBancoHoras.value
            : this.idPontoBancoHoras,
        dataUtilizacao:
            dataUtilizacao.present ? dataUtilizacao.value : this.dataUtilizacao,
        quantidadeUtilizada: quantidadeUtilizada.present
            ? quantidadeUtilizada.value
            : this.quantidadeUtilizada,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoBancoHorasUtilizacao(')
          ..write('id: $id, ')
          ..write('idPontoBancoHoras: $idPontoBancoHoras, ')
          ..write('dataUtilizacao: $dataUtilizacao, ')
          ..write('quantidadeUtilizada: $quantidadeUtilizada, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPontoBancoHoras, dataUtilizacao, quantidadeUtilizada, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoBancoHorasUtilizacao &&
          other.id == this.id &&
          other.idPontoBancoHoras == this.idPontoBancoHoras &&
          other.dataUtilizacao == this.dataUtilizacao &&
          other.quantidadeUtilizada == this.quantidadeUtilizada &&
          other.observacao == this.observacao);
}

class PontoBancoHorasUtilizacaosCompanion
    extends UpdateCompanion<PontoBancoHorasUtilizacao> {
  final Value<int?> id;
  final Value<int?> idPontoBancoHoras;
  final Value<DateTime?> dataUtilizacao;
  final Value<String?> quantidadeUtilizada;
  final Value<String?> observacao;
  const PontoBancoHorasUtilizacaosCompanion({
    this.id = const Value.absent(),
    this.idPontoBancoHoras = const Value.absent(),
    this.dataUtilizacao = const Value.absent(),
    this.quantidadeUtilizada = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PontoBancoHorasUtilizacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idPontoBancoHoras = const Value.absent(),
    this.dataUtilizacao = const Value.absent(),
    this.quantidadeUtilizada = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PontoBancoHorasUtilizacao> custom({
    Expression<int>? id,
    Expression<int>? idPontoBancoHoras,
    Expression<DateTime>? dataUtilizacao,
    Expression<String>? quantidadeUtilizada,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPontoBancoHoras != null) 'id_ponto_banco_horas': idPontoBancoHoras,
      if (dataUtilizacao != null) 'data_utilizacao': dataUtilizacao,
      if (quantidadeUtilizada != null)
        'quantidade_utilizada': quantidadeUtilizada,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PontoBancoHorasUtilizacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPontoBancoHoras,
      Value<DateTime?>? dataUtilizacao,
      Value<String?>? quantidadeUtilizada,
      Value<String?>? observacao}) {
    return PontoBancoHorasUtilizacaosCompanion(
      id: id ?? this.id,
      idPontoBancoHoras: idPontoBancoHoras ?? this.idPontoBancoHoras,
      dataUtilizacao: dataUtilizacao ?? this.dataUtilizacao,
      quantidadeUtilizada: quantidadeUtilizada ?? this.quantidadeUtilizada,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPontoBancoHoras.present) {
      map['id_ponto_banco_horas'] = Variable<int>(idPontoBancoHoras.value);
    }
    if (dataUtilizacao.present) {
      map['data_utilizacao'] = Variable<DateTime>(dataUtilizacao.value);
    }
    if (quantidadeUtilizada.present) {
      map['quantidade_utilizada'] = Variable<String>(quantidadeUtilizada.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoBancoHorasUtilizacaosCompanion(')
          ..write('id: $id, ')
          ..write('idPontoBancoHoras: $idPontoBancoHoras, ')
          ..write('dataUtilizacao: $dataUtilizacao, ')
          ..write('quantidadeUtilizada: $quantidadeUtilizada, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PontoEscalasTable extends PontoEscalas
    with TableInfo<$PontoEscalasTable, PontoEscala> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoEscalasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descontoHoraDiaMeta =
      const VerificationMeta('descontoHoraDia');
  @override
  late final GeneratedColumn<String> descontoHoraDia = GeneratedColumn<String>(
      'desconto_hora_dia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descontoDsrMeta =
      const VerificationMeta('descontoDsr');
  @override
  late final GeneratedColumn<String> descontoDsr = GeneratedColumn<String>(
      'desconto_dsr', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioDomingoMeta =
      const VerificationMeta('codigoHorarioDomingo');
  @override
  late final GeneratedColumn<String> codigoHorarioDomingo =
      GeneratedColumn<String>(
          'codigo_horario_domingo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioSegundaMeta =
      const VerificationMeta('codigoHorarioSegunda');
  @override
  late final GeneratedColumn<String> codigoHorarioSegunda =
      GeneratedColumn<String>(
          'codigo_horario_segunda', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioTercaMeta =
      const VerificationMeta('codigoHorarioTerca');
  @override
  late final GeneratedColumn<String> codigoHorarioTerca =
      GeneratedColumn<String>('codigo_horario_terca', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioQuartaMeta =
      const VerificationMeta('codigoHorarioQuarta');
  @override
  late final GeneratedColumn<String> codigoHorarioQuarta =
      GeneratedColumn<String>('codigo_horario_quarta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioQuintaMeta =
      const VerificationMeta('codigoHorarioQuinta');
  @override
  late final GeneratedColumn<String> codigoHorarioQuinta =
      GeneratedColumn<String>('codigo_horario_quinta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioSextaMeta =
      const VerificationMeta('codigoHorarioSexta');
  @override
  late final GeneratedColumn<String> codigoHorarioSexta =
      GeneratedColumn<String>('codigo_horario_sexta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioSabadoMeta =
      const VerificationMeta('codigoHorarioSabado');
  @override
  late final GeneratedColumn<String> codigoHorarioSabado =
      GeneratedColumn<String>('codigo_horario_sabado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 4),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        descontoHoraDia,
        descontoDsr,
        codigoHorarioDomingo,
        codigoHorarioSegunda,
        codigoHorarioTerca,
        codigoHorarioQuarta,
        codigoHorarioQuinta,
        codigoHorarioSexta,
        codigoHorarioSabado
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_escala';
  @override
  VerificationContext validateIntegrity(Insertable<PontoEscala> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('desconto_hora_dia')) {
      context.handle(
          _descontoHoraDiaMeta,
          descontoHoraDia.isAcceptableOrUnknown(
              data['desconto_hora_dia']!, _descontoHoraDiaMeta));
    }
    if (data.containsKey('desconto_dsr')) {
      context.handle(
          _descontoDsrMeta,
          descontoDsr.isAcceptableOrUnknown(
              data['desconto_dsr']!, _descontoDsrMeta));
    }
    if (data.containsKey('codigo_horario_domingo')) {
      context.handle(
          _codigoHorarioDomingoMeta,
          codigoHorarioDomingo.isAcceptableOrUnknown(
              data['codigo_horario_domingo']!, _codigoHorarioDomingoMeta));
    }
    if (data.containsKey('codigo_horario_segunda')) {
      context.handle(
          _codigoHorarioSegundaMeta,
          codigoHorarioSegunda.isAcceptableOrUnknown(
              data['codigo_horario_segunda']!, _codigoHorarioSegundaMeta));
    }
    if (data.containsKey('codigo_horario_terca')) {
      context.handle(
          _codigoHorarioTercaMeta,
          codigoHorarioTerca.isAcceptableOrUnknown(
              data['codigo_horario_terca']!, _codigoHorarioTercaMeta));
    }
    if (data.containsKey('codigo_horario_quarta')) {
      context.handle(
          _codigoHorarioQuartaMeta,
          codigoHorarioQuarta.isAcceptableOrUnknown(
              data['codigo_horario_quarta']!, _codigoHorarioQuartaMeta));
    }
    if (data.containsKey('codigo_horario_quinta')) {
      context.handle(
          _codigoHorarioQuintaMeta,
          codigoHorarioQuinta.isAcceptableOrUnknown(
              data['codigo_horario_quinta']!, _codigoHorarioQuintaMeta));
    }
    if (data.containsKey('codigo_horario_sexta')) {
      context.handle(
          _codigoHorarioSextaMeta,
          codigoHorarioSexta.isAcceptableOrUnknown(
              data['codigo_horario_sexta']!, _codigoHorarioSextaMeta));
    }
    if (data.containsKey('codigo_horario_sabado')) {
      context.handle(
          _codigoHorarioSabadoMeta,
          codigoHorarioSabado.isAcceptableOrUnknown(
              data['codigo_horario_sabado']!, _codigoHorarioSabadoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoEscala map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoEscala(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descontoHoraDia: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}desconto_hora_dia']),
      descontoDsr: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}desconto_dsr']),
      codigoHorarioDomingo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}codigo_horario_domingo']),
      codigoHorarioSegunda: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}codigo_horario_segunda']),
      codigoHorarioTerca: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_horario_terca']),
      codigoHorarioQuarta: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_horario_quarta']),
      codigoHorarioQuinta: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_horario_quinta']),
      codigoHorarioSexta: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_horario_sexta']),
      codigoHorarioSabado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_horario_sabado']),
    );
  }

  @override
  $PontoEscalasTable createAlias(String alias) {
    return $PontoEscalasTable(attachedDatabase, alias);
  }
}

class PontoEscala extends DataClass implements Insertable<PontoEscala> {
  final int? id;
  final String? nome;
  final String? descontoHoraDia;
  final String? descontoDsr;
  final String? codigoHorarioDomingo;
  final String? codigoHorarioSegunda;
  final String? codigoHorarioTerca;
  final String? codigoHorarioQuarta;
  final String? codigoHorarioQuinta;
  final String? codigoHorarioSexta;
  final String? codigoHorarioSabado;
  const PontoEscala(
      {this.id,
      this.nome,
      this.descontoHoraDia,
      this.descontoDsr,
      this.codigoHorarioDomingo,
      this.codigoHorarioSegunda,
      this.codigoHorarioTerca,
      this.codigoHorarioQuarta,
      this.codigoHorarioQuinta,
      this.codigoHorarioSexta,
      this.codigoHorarioSabado});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descontoHoraDia != null) {
      map['desconto_hora_dia'] = Variable<String>(descontoHoraDia);
    }
    if (!nullToAbsent || descontoDsr != null) {
      map['desconto_dsr'] = Variable<String>(descontoDsr);
    }
    if (!nullToAbsent || codigoHorarioDomingo != null) {
      map['codigo_horario_domingo'] = Variable<String>(codigoHorarioDomingo);
    }
    if (!nullToAbsent || codigoHorarioSegunda != null) {
      map['codigo_horario_segunda'] = Variable<String>(codigoHorarioSegunda);
    }
    if (!nullToAbsent || codigoHorarioTerca != null) {
      map['codigo_horario_terca'] = Variable<String>(codigoHorarioTerca);
    }
    if (!nullToAbsent || codigoHorarioQuarta != null) {
      map['codigo_horario_quarta'] = Variable<String>(codigoHorarioQuarta);
    }
    if (!nullToAbsent || codigoHorarioQuinta != null) {
      map['codigo_horario_quinta'] = Variable<String>(codigoHorarioQuinta);
    }
    if (!nullToAbsent || codigoHorarioSexta != null) {
      map['codigo_horario_sexta'] = Variable<String>(codigoHorarioSexta);
    }
    if (!nullToAbsent || codigoHorarioSabado != null) {
      map['codigo_horario_sabado'] = Variable<String>(codigoHorarioSabado);
    }
    return map;
  }

  factory PontoEscala.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoEscala(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descontoHoraDia: serializer.fromJson<String?>(json['descontoHoraDia']),
      descontoDsr: serializer.fromJson<String?>(json['descontoDsr']),
      codigoHorarioDomingo:
          serializer.fromJson<String?>(json['codigoHorarioDomingo']),
      codigoHorarioSegunda:
          serializer.fromJson<String?>(json['codigoHorarioSegunda']),
      codigoHorarioTerca:
          serializer.fromJson<String?>(json['codigoHorarioTerca']),
      codigoHorarioQuarta:
          serializer.fromJson<String?>(json['codigoHorarioQuarta']),
      codigoHorarioQuinta:
          serializer.fromJson<String?>(json['codigoHorarioQuinta']),
      codigoHorarioSexta:
          serializer.fromJson<String?>(json['codigoHorarioSexta']),
      codigoHorarioSabado:
          serializer.fromJson<String?>(json['codigoHorarioSabado']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descontoHoraDia': serializer.toJson<String?>(descontoHoraDia),
      'descontoDsr': serializer.toJson<String?>(descontoDsr),
      'codigoHorarioDomingo': serializer.toJson<String?>(codigoHorarioDomingo),
      'codigoHorarioSegunda': serializer.toJson<String?>(codigoHorarioSegunda),
      'codigoHorarioTerca': serializer.toJson<String?>(codigoHorarioTerca),
      'codigoHorarioQuarta': serializer.toJson<String?>(codigoHorarioQuarta),
      'codigoHorarioQuinta': serializer.toJson<String?>(codigoHorarioQuinta),
      'codigoHorarioSexta': serializer.toJson<String?>(codigoHorarioSexta),
      'codigoHorarioSabado': serializer.toJson<String?>(codigoHorarioSabado),
    };
  }

  PontoEscala copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descontoHoraDia = const Value.absent(),
          Value<String?> descontoDsr = const Value.absent(),
          Value<String?> codigoHorarioDomingo = const Value.absent(),
          Value<String?> codigoHorarioSegunda = const Value.absent(),
          Value<String?> codigoHorarioTerca = const Value.absent(),
          Value<String?> codigoHorarioQuarta = const Value.absent(),
          Value<String?> codigoHorarioQuinta = const Value.absent(),
          Value<String?> codigoHorarioSexta = const Value.absent(),
          Value<String?> codigoHorarioSabado = const Value.absent()}) =>
      PontoEscala(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descontoHoraDia: descontoHoraDia.present
            ? descontoHoraDia.value
            : this.descontoHoraDia,
        descontoDsr: descontoDsr.present ? descontoDsr.value : this.descontoDsr,
        codigoHorarioDomingo: codigoHorarioDomingo.present
            ? codigoHorarioDomingo.value
            : this.codigoHorarioDomingo,
        codigoHorarioSegunda: codigoHorarioSegunda.present
            ? codigoHorarioSegunda.value
            : this.codigoHorarioSegunda,
        codigoHorarioTerca: codigoHorarioTerca.present
            ? codigoHorarioTerca.value
            : this.codigoHorarioTerca,
        codigoHorarioQuarta: codigoHorarioQuarta.present
            ? codigoHorarioQuarta.value
            : this.codigoHorarioQuarta,
        codigoHorarioQuinta: codigoHorarioQuinta.present
            ? codigoHorarioQuinta.value
            : this.codigoHorarioQuinta,
        codigoHorarioSexta: codigoHorarioSexta.present
            ? codigoHorarioSexta.value
            : this.codigoHorarioSexta,
        codigoHorarioSabado: codigoHorarioSabado.present
            ? codigoHorarioSabado.value
            : this.codigoHorarioSabado,
      );
  @override
  String toString() {
    return (StringBuffer('PontoEscala(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descontoHoraDia: $descontoHoraDia, ')
          ..write('descontoDsr: $descontoDsr, ')
          ..write('codigoHorarioDomingo: $codigoHorarioDomingo, ')
          ..write('codigoHorarioSegunda: $codigoHorarioSegunda, ')
          ..write('codigoHorarioTerca: $codigoHorarioTerca, ')
          ..write('codigoHorarioQuarta: $codigoHorarioQuarta, ')
          ..write('codigoHorarioQuinta: $codigoHorarioQuinta, ')
          ..write('codigoHorarioSexta: $codigoHorarioSexta, ')
          ..write('codigoHorarioSabado: $codigoHorarioSabado')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      nome,
      descontoHoraDia,
      descontoDsr,
      codigoHorarioDomingo,
      codigoHorarioSegunda,
      codigoHorarioTerca,
      codigoHorarioQuarta,
      codigoHorarioQuinta,
      codigoHorarioSexta,
      codigoHorarioSabado);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoEscala &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descontoHoraDia == this.descontoHoraDia &&
          other.descontoDsr == this.descontoDsr &&
          other.codigoHorarioDomingo == this.codigoHorarioDomingo &&
          other.codigoHorarioSegunda == this.codigoHorarioSegunda &&
          other.codigoHorarioTerca == this.codigoHorarioTerca &&
          other.codigoHorarioQuarta == this.codigoHorarioQuarta &&
          other.codigoHorarioQuinta == this.codigoHorarioQuinta &&
          other.codigoHorarioSexta == this.codigoHorarioSexta &&
          other.codigoHorarioSabado == this.codigoHorarioSabado);
}

class PontoEscalasCompanion extends UpdateCompanion<PontoEscala> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descontoHoraDia;
  final Value<String?> descontoDsr;
  final Value<String?> codigoHorarioDomingo;
  final Value<String?> codigoHorarioSegunda;
  final Value<String?> codigoHorarioTerca;
  final Value<String?> codigoHorarioQuarta;
  final Value<String?> codigoHorarioQuinta;
  final Value<String?> codigoHorarioSexta;
  final Value<String?> codigoHorarioSabado;
  const PontoEscalasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descontoHoraDia = const Value.absent(),
    this.descontoDsr = const Value.absent(),
    this.codigoHorarioDomingo = const Value.absent(),
    this.codigoHorarioSegunda = const Value.absent(),
    this.codigoHorarioTerca = const Value.absent(),
    this.codigoHorarioQuarta = const Value.absent(),
    this.codigoHorarioQuinta = const Value.absent(),
    this.codigoHorarioSexta = const Value.absent(),
    this.codigoHorarioSabado = const Value.absent(),
  });
  PontoEscalasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descontoHoraDia = const Value.absent(),
    this.descontoDsr = const Value.absent(),
    this.codigoHorarioDomingo = const Value.absent(),
    this.codigoHorarioSegunda = const Value.absent(),
    this.codigoHorarioTerca = const Value.absent(),
    this.codigoHorarioQuarta = const Value.absent(),
    this.codigoHorarioQuinta = const Value.absent(),
    this.codigoHorarioSexta = const Value.absent(),
    this.codigoHorarioSabado = const Value.absent(),
  });
  static Insertable<PontoEscala> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descontoHoraDia,
    Expression<String>? descontoDsr,
    Expression<String>? codigoHorarioDomingo,
    Expression<String>? codigoHorarioSegunda,
    Expression<String>? codigoHorarioTerca,
    Expression<String>? codigoHorarioQuarta,
    Expression<String>? codigoHorarioQuinta,
    Expression<String>? codigoHorarioSexta,
    Expression<String>? codigoHorarioSabado,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descontoHoraDia != null) 'desconto_hora_dia': descontoHoraDia,
      if (descontoDsr != null) 'desconto_dsr': descontoDsr,
      if (codigoHorarioDomingo != null)
        'codigo_horario_domingo': codigoHorarioDomingo,
      if (codigoHorarioSegunda != null)
        'codigo_horario_segunda': codigoHorarioSegunda,
      if (codigoHorarioTerca != null)
        'codigo_horario_terca': codigoHorarioTerca,
      if (codigoHorarioQuarta != null)
        'codigo_horario_quarta': codigoHorarioQuarta,
      if (codigoHorarioQuinta != null)
        'codigo_horario_quinta': codigoHorarioQuinta,
      if (codigoHorarioSexta != null)
        'codigo_horario_sexta': codigoHorarioSexta,
      if (codigoHorarioSabado != null)
        'codigo_horario_sabado': codigoHorarioSabado,
    });
  }

  PontoEscalasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? descontoHoraDia,
      Value<String?>? descontoDsr,
      Value<String?>? codigoHorarioDomingo,
      Value<String?>? codigoHorarioSegunda,
      Value<String?>? codigoHorarioTerca,
      Value<String?>? codigoHorarioQuarta,
      Value<String?>? codigoHorarioQuinta,
      Value<String?>? codigoHorarioSexta,
      Value<String?>? codigoHorarioSabado}) {
    return PontoEscalasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descontoHoraDia: descontoHoraDia ?? this.descontoHoraDia,
      descontoDsr: descontoDsr ?? this.descontoDsr,
      codigoHorarioDomingo: codigoHorarioDomingo ?? this.codigoHorarioDomingo,
      codigoHorarioSegunda: codigoHorarioSegunda ?? this.codigoHorarioSegunda,
      codigoHorarioTerca: codigoHorarioTerca ?? this.codigoHorarioTerca,
      codigoHorarioQuarta: codigoHorarioQuarta ?? this.codigoHorarioQuarta,
      codigoHorarioQuinta: codigoHorarioQuinta ?? this.codigoHorarioQuinta,
      codigoHorarioSexta: codigoHorarioSexta ?? this.codigoHorarioSexta,
      codigoHorarioSabado: codigoHorarioSabado ?? this.codigoHorarioSabado,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descontoHoraDia.present) {
      map['desconto_hora_dia'] = Variable<String>(descontoHoraDia.value);
    }
    if (descontoDsr.present) {
      map['desconto_dsr'] = Variable<String>(descontoDsr.value);
    }
    if (codigoHorarioDomingo.present) {
      map['codigo_horario_domingo'] =
          Variable<String>(codigoHorarioDomingo.value);
    }
    if (codigoHorarioSegunda.present) {
      map['codigo_horario_segunda'] =
          Variable<String>(codigoHorarioSegunda.value);
    }
    if (codigoHorarioTerca.present) {
      map['codigo_horario_terca'] = Variable<String>(codigoHorarioTerca.value);
    }
    if (codigoHorarioQuarta.present) {
      map['codigo_horario_quarta'] =
          Variable<String>(codigoHorarioQuarta.value);
    }
    if (codigoHorarioQuinta.present) {
      map['codigo_horario_quinta'] =
          Variable<String>(codigoHorarioQuinta.value);
    }
    if (codigoHorarioSexta.present) {
      map['codigo_horario_sexta'] = Variable<String>(codigoHorarioSexta.value);
    }
    if (codigoHorarioSabado.present) {
      map['codigo_horario_sabado'] =
          Variable<String>(codigoHorarioSabado.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoEscalasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descontoHoraDia: $descontoHoraDia, ')
          ..write('descontoDsr: $descontoDsr, ')
          ..write('codigoHorarioDomingo: $codigoHorarioDomingo, ')
          ..write('codigoHorarioSegunda: $codigoHorarioSegunda, ')
          ..write('codigoHorarioTerca: $codigoHorarioTerca, ')
          ..write('codigoHorarioQuarta: $codigoHorarioQuarta, ')
          ..write('codigoHorarioQuinta: $codigoHorarioQuinta, ')
          ..write('codigoHorarioSexta: $codigoHorarioSexta, ')
          ..write('codigoHorarioSabado: $codigoHorarioSabado')
          ..write(')'))
        .toString();
  }
}

class $PontoBancoHorassTable extends PontoBancoHorass
    with TableInfo<$PontoBancoHorassTable, PontoBancoHoras> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoBancoHorassTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataTrabalhoMeta =
      const VerificationMeta('dataTrabalho');
  @override
  late final GeneratedColumn<DateTime> dataTrabalho = GeneratedColumn<DateTime>(
      'data_trabalho', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<String> quantidade = GeneratedColumn<String>(
      'quantidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, dataTrabalho, quantidade, situacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_banco_horas';
  @override
  VerificationContext validateIntegrity(Insertable<PontoBancoHoras> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_trabalho')) {
      context.handle(
          _dataTrabalhoMeta,
          dataTrabalho.isAcceptableOrUnknown(
              data['data_trabalho']!, _dataTrabalhoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoBancoHoras map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoBancoHoras(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataTrabalho: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_trabalho']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}quantidade']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
    );
  }

  @override
  $PontoBancoHorassTable createAlias(String alias) {
    return $PontoBancoHorassTable(attachedDatabase, alias);
  }
}

class PontoBancoHoras extends DataClass implements Insertable<PontoBancoHoras> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataTrabalho;
  final String? quantidade;
  final String? situacao;
  const PontoBancoHoras(
      {this.id,
      this.idColaborador,
      this.dataTrabalho,
      this.quantidade,
      this.situacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataTrabalho != null) {
      map['data_trabalho'] = Variable<DateTime>(dataTrabalho);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<String>(quantidade);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    return map;
  }

  factory PontoBancoHoras.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoBancoHoras(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataTrabalho: serializer.fromJson<DateTime?>(json['dataTrabalho']),
      quantidade: serializer.fromJson<String?>(json['quantidade']),
      situacao: serializer.fromJson<String?>(json['situacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataTrabalho': serializer.toJson<DateTime?>(dataTrabalho),
      'quantidade': serializer.toJson<String?>(quantidade),
      'situacao': serializer.toJson<String?>(situacao),
    };
  }

  PontoBancoHoras copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataTrabalho = const Value.absent(),
          Value<String?> quantidade = const Value.absent(),
          Value<String?> situacao = const Value.absent()}) =>
      PontoBancoHoras(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataTrabalho:
            dataTrabalho.present ? dataTrabalho.value : this.dataTrabalho,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        situacao: situacao.present ? situacao.value : this.situacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoBancoHoras(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataTrabalho: $dataTrabalho, ')
          ..write('quantidade: $quantidade, ')
          ..write('situacao: $situacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idColaborador, dataTrabalho, quantidade, situacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoBancoHoras &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataTrabalho == this.dataTrabalho &&
          other.quantidade == this.quantidade &&
          other.situacao == this.situacao);
}

class PontoBancoHorassCompanion extends UpdateCompanion<PontoBancoHoras> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataTrabalho;
  final Value<String?> quantidade;
  final Value<String?> situacao;
  const PontoBancoHorassCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataTrabalho = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.situacao = const Value.absent(),
  });
  PontoBancoHorassCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataTrabalho = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.situacao = const Value.absent(),
  });
  static Insertable<PontoBancoHoras> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataTrabalho,
    Expression<String>? quantidade,
    Expression<String>? situacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataTrabalho != null) 'data_trabalho': dataTrabalho,
      if (quantidade != null) 'quantidade': quantidade,
      if (situacao != null) 'situacao': situacao,
    });
  }

  PontoBancoHorassCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataTrabalho,
      Value<String?>? quantidade,
      Value<String?>? situacao}) {
    return PontoBancoHorassCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataTrabalho: dataTrabalho ?? this.dataTrabalho,
      quantidade: quantidade ?? this.quantidade,
      situacao: situacao ?? this.situacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataTrabalho.present) {
      map['data_trabalho'] = Variable<DateTime>(dataTrabalho.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<String>(quantidade.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoBancoHorassCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataTrabalho: $dataTrabalho, ')
          ..write('quantidade: $quantidade, ')
          ..write('situacao: $situacao')
          ..write(')'))
        .toString();
  }
}

class $PontoAbonosTable extends PontoAbonos
    with TableInfo<$PontoAbonosTable, PontoAbono> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoAbonosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _utilizadoMeta =
      const VerificationMeta('utilizado');
  @override
  late final GeneratedColumn<int> utilizado = GeneratedColumn<int>(
      'utilizado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _saldoMeta = const VerificationMeta('saldo');
  @override
  late final GeneratedColumn<int> saldo = GeneratedColumn<int>(
      'saldo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _inicioUtilizacaoMeta =
      const VerificationMeta('inicioUtilizacao');
  @override
  late final GeneratedColumn<DateTime> inicioUtilizacao =
      GeneratedColumn<DateTime>('inicio_utilizacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataValidadeMeta =
      const VerificationMeta('dataValidade');
  @override
  late final GeneratedColumn<DateTime> dataValidade = GeneratedColumn<DateTime>(
      'data_validade', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        quantidade,
        utilizado,
        saldo,
        dataCadastro,
        inicioUtilizacao,
        dataValidade,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_abono';
  @override
  VerificationContext validateIntegrity(Insertable<PontoAbono> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('utilizado')) {
      context.handle(_utilizadoMeta,
          utilizado.isAcceptableOrUnknown(data['utilizado']!, _utilizadoMeta));
    }
    if (data.containsKey('saldo')) {
      context.handle(
          _saldoMeta, saldo.isAcceptableOrUnknown(data['saldo']!, _saldoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('inicio_utilizacao')) {
      context.handle(
          _inicioUtilizacaoMeta,
          inicioUtilizacao.isAcceptableOrUnknown(
              data['inicio_utilizacao']!, _inicioUtilizacaoMeta));
    }
    if (data.containsKey('data_validade')) {
      context.handle(
          _dataValidadeMeta,
          dataValidade.isAcceptableOrUnknown(
              data['data_validade']!, _dataValidadeMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoAbono map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoAbono(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantidade']),
      utilizado: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}utilizado']),
      saldo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}saldo']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      inicioUtilizacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}inicio_utilizacao']),
      dataValidade: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_validade']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PontoAbonosTable createAlias(String alias) {
    return $PontoAbonosTable(attachedDatabase, alias);
  }
}

class PontoAbono extends DataClass implements Insertable<PontoAbono> {
  final int? id;
  final int? idColaborador;
  final int? quantidade;
  final int? utilizado;
  final int? saldo;
  final DateTime? dataCadastro;
  final DateTime? inicioUtilizacao;
  final DateTime? dataValidade;
  final String? observacao;
  const PontoAbono(
      {this.id,
      this.idColaborador,
      this.quantidade,
      this.utilizado,
      this.saldo,
      this.dataCadastro,
      this.inicioUtilizacao,
      this.dataValidade,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    if (!nullToAbsent || utilizado != null) {
      map['utilizado'] = Variable<int>(utilizado);
    }
    if (!nullToAbsent || saldo != null) {
      map['saldo'] = Variable<int>(saldo);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || inicioUtilizacao != null) {
      map['inicio_utilizacao'] = Variable<DateTime>(inicioUtilizacao);
    }
    if (!nullToAbsent || dataValidade != null) {
      map['data_validade'] = Variable<DateTime>(dataValidade);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PontoAbono.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoAbono(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
      utilizado: serializer.fromJson<int?>(json['utilizado']),
      saldo: serializer.fromJson<int?>(json['saldo']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      inicioUtilizacao:
          serializer.fromJson<DateTime?>(json['inicioUtilizacao']),
      dataValidade: serializer.fromJson<DateTime?>(json['dataValidade']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'quantidade': serializer.toJson<int?>(quantidade),
      'utilizado': serializer.toJson<int?>(utilizado),
      'saldo': serializer.toJson<int?>(saldo),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'inicioUtilizacao': serializer.toJson<DateTime?>(inicioUtilizacao),
      'dataValidade': serializer.toJson<DateTime?>(dataValidade),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PontoAbono copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> quantidade = const Value.absent(),
          Value<int?> utilizado = const Value.absent(),
          Value<int?> saldo = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> inicioUtilizacao = const Value.absent(),
          Value<DateTime?> dataValidade = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PontoAbono(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        utilizado: utilizado.present ? utilizado.value : this.utilizado,
        saldo: saldo.present ? saldo.value : this.saldo,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        inicioUtilizacao: inicioUtilizacao.present
            ? inicioUtilizacao.value
            : this.inicioUtilizacao,
        dataValidade:
            dataValidade.present ? dataValidade.value : this.dataValidade,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoAbono(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('quantidade: $quantidade, ')
          ..write('utilizado: $utilizado, ')
          ..write('saldo: $saldo, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('inicioUtilizacao: $inicioUtilizacao, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, quantidade, utilizado,
      saldo, dataCadastro, inicioUtilizacao, dataValidade, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoAbono &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.quantidade == this.quantidade &&
          other.utilizado == this.utilizado &&
          other.saldo == this.saldo &&
          other.dataCadastro == this.dataCadastro &&
          other.inicioUtilizacao == this.inicioUtilizacao &&
          other.dataValidade == this.dataValidade &&
          other.observacao == this.observacao);
}

class PontoAbonosCompanion extends UpdateCompanion<PontoAbono> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> quantidade;
  final Value<int?> utilizado;
  final Value<int?> saldo;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> inicioUtilizacao;
  final Value<DateTime?> dataValidade;
  final Value<String?> observacao;
  const PontoAbonosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.utilizado = const Value.absent(),
    this.saldo = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.inicioUtilizacao = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PontoAbonosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.utilizado = const Value.absent(),
    this.saldo = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.inicioUtilizacao = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PontoAbono> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? quantidade,
    Expression<int>? utilizado,
    Expression<int>? saldo,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? inicioUtilizacao,
    Expression<DateTime>? dataValidade,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (quantidade != null) 'quantidade': quantidade,
      if (utilizado != null) 'utilizado': utilizado,
      if (saldo != null) 'saldo': saldo,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (inicioUtilizacao != null) 'inicio_utilizacao': inicioUtilizacao,
      if (dataValidade != null) 'data_validade': dataValidade,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PontoAbonosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<int?>? quantidade,
      Value<int?>? utilizado,
      Value<int?>? saldo,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? inicioUtilizacao,
      Value<DateTime?>? dataValidade,
      Value<String?>? observacao}) {
    return PontoAbonosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      quantidade: quantidade ?? this.quantidade,
      utilizado: utilizado ?? this.utilizado,
      saldo: saldo ?? this.saldo,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      inicioUtilizacao: inicioUtilizacao ?? this.inicioUtilizacao,
      dataValidade: dataValidade ?? this.dataValidade,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    if (utilizado.present) {
      map['utilizado'] = Variable<int>(utilizado.value);
    }
    if (saldo.present) {
      map['saldo'] = Variable<int>(saldo.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (inicioUtilizacao.present) {
      map['inicio_utilizacao'] = Variable<DateTime>(inicioUtilizacao.value);
    }
    if (dataValidade.present) {
      map['data_validade'] = Variable<DateTime>(dataValidade.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoAbonosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('quantidade: $quantidade, ')
          ..write('utilizado: $utilizado, ')
          ..write('saldo: $saldo, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('inicioUtilizacao: $inicioUtilizacao, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $PontoParametrosTable extends PontoParametros
    with TableInfo<$PontoParametrosTable, PontoParametro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoParametrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _mesAnoMeta = const VerificationMeta('mesAno');
  @override
  late final GeneratedColumn<String> mesAno = GeneratedColumn<String>(
      'mes_ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _diaInicialApuracaoMeta =
      const VerificationMeta('diaInicialApuracao');
  @override
  late final GeneratedColumn<int> diaInicialApuracao = GeneratedColumn<int>(
      'dia_inicial_apuracao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _horaNoturnaInicioMeta =
      const VerificationMeta('horaNoturnaInicio');
  @override
  late final GeneratedColumn<String> horaNoturnaInicio =
      GeneratedColumn<String>('hora_noturna_inicio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaNoturnaFimMeta =
      const VerificationMeta('horaNoturnaFim');
  @override
  late final GeneratedColumn<String> horaNoturnaFim = GeneratedColumn<String>(
      'hora_noturna_fim', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _periodoMinimoInterjornadaMeta =
      const VerificationMeta('periodoMinimoInterjornada');
  @override
  late final GeneratedColumn<String> periodoMinimoInterjornada =
      GeneratedColumn<String>('periodo_minimo_interjornada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _percentualHeDiurnaMeta =
      const VerificationMeta('percentualHeDiurna');
  @override
  late final GeneratedColumn<double> percentualHeDiurna =
      GeneratedColumn<double>('percentual_he_diurna', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _percentualHeNoturnaMeta =
      const VerificationMeta('percentualHeNoturna');
  @override
  late final GeneratedColumn<double> percentualHeNoturna =
      GeneratedColumn<double>('percentual_he_noturna', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _duracaoHoraNoturnaMeta =
      const VerificationMeta('duracaoHoraNoturna');
  @override
  late final GeneratedColumn<String> duracaoHoraNoturna =
      GeneratedColumn<String>('duracao_hora_noturna', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tratamentoHoraMaisMeta =
      const VerificationMeta('tratamentoHoraMais');
  @override
  late final GeneratedColumn<String> tratamentoHoraMais =
      GeneratedColumn<String>('tratamento_hora_mais', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tratamentoHoraMenosMeta =
      const VerificationMeta('tratamentoHoraMenos');
  @override
  late final GeneratedColumn<String> tratamentoHoraMenos =
      GeneratedColumn<String>('tratamento_hora_menos', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        mesAno,
        diaInicialApuracao,
        horaNoturnaInicio,
        horaNoturnaFim,
        periodoMinimoInterjornada,
        percentualHeDiurna,
        percentualHeNoturna,
        duracaoHoraNoturna,
        tratamentoHoraMais,
        tratamentoHoraMenos
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_parametro';
  @override
  VerificationContext validateIntegrity(Insertable<PontoParametro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('mes_ano')) {
      context.handle(_mesAnoMeta,
          mesAno.isAcceptableOrUnknown(data['mes_ano']!, _mesAnoMeta));
    }
    if (data.containsKey('dia_inicial_apuracao')) {
      context.handle(
          _diaInicialApuracaoMeta,
          diaInicialApuracao.isAcceptableOrUnknown(
              data['dia_inicial_apuracao']!, _diaInicialApuracaoMeta));
    }
    if (data.containsKey('hora_noturna_inicio')) {
      context.handle(
          _horaNoturnaInicioMeta,
          horaNoturnaInicio.isAcceptableOrUnknown(
              data['hora_noturna_inicio']!, _horaNoturnaInicioMeta));
    }
    if (data.containsKey('hora_noturna_fim')) {
      context.handle(
          _horaNoturnaFimMeta,
          horaNoturnaFim.isAcceptableOrUnknown(
              data['hora_noturna_fim']!, _horaNoturnaFimMeta));
    }
    if (data.containsKey('periodo_minimo_interjornada')) {
      context.handle(
          _periodoMinimoInterjornadaMeta,
          periodoMinimoInterjornada.isAcceptableOrUnknown(
              data['periodo_minimo_interjornada']!,
              _periodoMinimoInterjornadaMeta));
    }
    if (data.containsKey('percentual_he_diurna')) {
      context.handle(
          _percentualHeDiurnaMeta,
          percentualHeDiurna.isAcceptableOrUnknown(
              data['percentual_he_diurna']!, _percentualHeDiurnaMeta));
    }
    if (data.containsKey('percentual_he_noturna')) {
      context.handle(
          _percentualHeNoturnaMeta,
          percentualHeNoturna.isAcceptableOrUnknown(
              data['percentual_he_noturna']!, _percentualHeNoturnaMeta));
    }
    if (data.containsKey('duracao_hora_noturna')) {
      context.handle(
          _duracaoHoraNoturnaMeta,
          duracaoHoraNoturna.isAcceptableOrUnknown(
              data['duracao_hora_noturna']!, _duracaoHoraNoturnaMeta));
    }
    if (data.containsKey('tratamento_hora_mais')) {
      context.handle(
          _tratamentoHoraMaisMeta,
          tratamentoHoraMais.isAcceptableOrUnknown(
              data['tratamento_hora_mais']!, _tratamentoHoraMaisMeta));
    }
    if (data.containsKey('tratamento_hora_menos')) {
      context.handle(
          _tratamentoHoraMenosMeta,
          tratamentoHoraMenos.isAcceptableOrUnknown(
              data['tratamento_hora_menos']!, _tratamentoHoraMenosMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoParametro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoParametro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      mesAno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mes_ano']),
      diaInicialApuracao: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}dia_inicial_apuracao']),
      horaNoturnaInicio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_noturna_inicio']),
      horaNoturnaFim: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_noturna_fim']),
      periodoMinimoInterjornada: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}periodo_minimo_interjornada']),
      percentualHeDiurna: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}percentual_he_diurna']),
      percentualHeNoturna: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}percentual_he_noturna']),
      duracaoHoraNoturna: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}duracao_hora_noturna']),
      tratamentoHoraMais: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tratamento_hora_mais']),
      tratamentoHoraMenos: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tratamento_hora_menos']),
    );
  }

  @override
  $PontoParametrosTable createAlias(String alias) {
    return $PontoParametrosTable(attachedDatabase, alias);
  }
}

class PontoParametro extends DataClass implements Insertable<PontoParametro> {
  final int? id;
  final String? mesAno;
  final int? diaInicialApuracao;
  final String? horaNoturnaInicio;
  final String? horaNoturnaFim;
  final String? periodoMinimoInterjornada;
  final double? percentualHeDiurna;
  final double? percentualHeNoturna;
  final String? duracaoHoraNoturna;
  final String? tratamentoHoraMais;
  final String? tratamentoHoraMenos;
  const PontoParametro(
      {this.id,
      this.mesAno,
      this.diaInicialApuracao,
      this.horaNoturnaInicio,
      this.horaNoturnaFim,
      this.periodoMinimoInterjornada,
      this.percentualHeDiurna,
      this.percentualHeNoturna,
      this.duracaoHoraNoturna,
      this.tratamentoHoraMais,
      this.tratamentoHoraMenos});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || mesAno != null) {
      map['mes_ano'] = Variable<String>(mesAno);
    }
    if (!nullToAbsent || diaInicialApuracao != null) {
      map['dia_inicial_apuracao'] = Variable<int>(diaInicialApuracao);
    }
    if (!nullToAbsent || horaNoturnaInicio != null) {
      map['hora_noturna_inicio'] = Variable<String>(horaNoturnaInicio);
    }
    if (!nullToAbsent || horaNoturnaFim != null) {
      map['hora_noturna_fim'] = Variable<String>(horaNoturnaFim);
    }
    if (!nullToAbsent || periodoMinimoInterjornada != null) {
      map['periodo_minimo_interjornada'] =
          Variable<String>(periodoMinimoInterjornada);
    }
    if (!nullToAbsent || percentualHeDiurna != null) {
      map['percentual_he_diurna'] = Variable<double>(percentualHeDiurna);
    }
    if (!nullToAbsent || percentualHeNoturna != null) {
      map['percentual_he_noturna'] = Variable<double>(percentualHeNoturna);
    }
    if (!nullToAbsent || duracaoHoraNoturna != null) {
      map['duracao_hora_noturna'] = Variable<String>(duracaoHoraNoturna);
    }
    if (!nullToAbsent || tratamentoHoraMais != null) {
      map['tratamento_hora_mais'] = Variable<String>(tratamentoHoraMais);
    }
    if (!nullToAbsent || tratamentoHoraMenos != null) {
      map['tratamento_hora_menos'] = Variable<String>(tratamentoHoraMenos);
    }
    return map;
  }

  factory PontoParametro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoParametro(
      id: serializer.fromJson<int?>(json['id']),
      mesAno: serializer.fromJson<String?>(json['mesAno']),
      diaInicialApuracao: serializer.fromJson<int?>(json['diaInicialApuracao']),
      horaNoturnaInicio:
          serializer.fromJson<String?>(json['horaNoturnaInicio']),
      horaNoturnaFim: serializer.fromJson<String?>(json['horaNoturnaFim']),
      periodoMinimoInterjornada:
          serializer.fromJson<String?>(json['periodoMinimoInterjornada']),
      percentualHeDiurna:
          serializer.fromJson<double?>(json['percentualHeDiurna']),
      percentualHeNoturna:
          serializer.fromJson<double?>(json['percentualHeNoturna']),
      duracaoHoraNoturna:
          serializer.fromJson<String?>(json['duracaoHoraNoturna']),
      tratamentoHoraMais:
          serializer.fromJson<String?>(json['tratamentoHoraMais']),
      tratamentoHoraMenos:
          serializer.fromJson<String?>(json['tratamentoHoraMenos']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'mesAno': serializer.toJson<String?>(mesAno),
      'diaInicialApuracao': serializer.toJson<int?>(diaInicialApuracao),
      'horaNoturnaInicio': serializer.toJson<String?>(horaNoturnaInicio),
      'horaNoturnaFim': serializer.toJson<String?>(horaNoturnaFim),
      'periodoMinimoInterjornada':
          serializer.toJson<String?>(periodoMinimoInterjornada),
      'percentualHeDiurna': serializer.toJson<double?>(percentualHeDiurna),
      'percentualHeNoturna': serializer.toJson<double?>(percentualHeNoturna),
      'duracaoHoraNoturna': serializer.toJson<String?>(duracaoHoraNoturna),
      'tratamentoHoraMais': serializer.toJson<String?>(tratamentoHoraMais),
      'tratamentoHoraMenos': serializer.toJson<String?>(tratamentoHoraMenos),
    };
  }

  PontoParametro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> mesAno = const Value.absent(),
          Value<int?> diaInicialApuracao = const Value.absent(),
          Value<String?> horaNoturnaInicio = const Value.absent(),
          Value<String?> horaNoturnaFim = const Value.absent(),
          Value<String?> periodoMinimoInterjornada = const Value.absent(),
          Value<double?> percentualHeDiurna = const Value.absent(),
          Value<double?> percentualHeNoturna = const Value.absent(),
          Value<String?> duracaoHoraNoturna = const Value.absent(),
          Value<String?> tratamentoHoraMais = const Value.absent(),
          Value<String?> tratamentoHoraMenos = const Value.absent()}) =>
      PontoParametro(
        id: id.present ? id.value : this.id,
        mesAno: mesAno.present ? mesAno.value : this.mesAno,
        diaInicialApuracao: diaInicialApuracao.present
            ? diaInicialApuracao.value
            : this.diaInicialApuracao,
        horaNoturnaInicio: horaNoturnaInicio.present
            ? horaNoturnaInicio.value
            : this.horaNoturnaInicio,
        horaNoturnaFim:
            horaNoturnaFim.present ? horaNoturnaFim.value : this.horaNoturnaFim,
        periodoMinimoInterjornada: periodoMinimoInterjornada.present
            ? periodoMinimoInterjornada.value
            : this.periodoMinimoInterjornada,
        percentualHeDiurna: percentualHeDiurna.present
            ? percentualHeDiurna.value
            : this.percentualHeDiurna,
        percentualHeNoturna: percentualHeNoturna.present
            ? percentualHeNoturna.value
            : this.percentualHeNoturna,
        duracaoHoraNoturna: duracaoHoraNoturna.present
            ? duracaoHoraNoturna.value
            : this.duracaoHoraNoturna,
        tratamentoHoraMais: tratamentoHoraMais.present
            ? tratamentoHoraMais.value
            : this.tratamentoHoraMais,
        tratamentoHoraMenos: tratamentoHoraMenos.present
            ? tratamentoHoraMenos.value
            : this.tratamentoHoraMenos,
      );
  @override
  String toString() {
    return (StringBuffer('PontoParametro(')
          ..write('id: $id, ')
          ..write('mesAno: $mesAno, ')
          ..write('diaInicialApuracao: $diaInicialApuracao, ')
          ..write('horaNoturnaInicio: $horaNoturnaInicio, ')
          ..write('horaNoturnaFim: $horaNoturnaFim, ')
          ..write('periodoMinimoInterjornada: $periodoMinimoInterjornada, ')
          ..write('percentualHeDiurna: $percentualHeDiurna, ')
          ..write('percentualHeNoturna: $percentualHeNoturna, ')
          ..write('duracaoHoraNoturna: $duracaoHoraNoturna, ')
          ..write('tratamentoHoraMais: $tratamentoHoraMais, ')
          ..write('tratamentoHoraMenos: $tratamentoHoraMenos')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      mesAno,
      diaInicialApuracao,
      horaNoturnaInicio,
      horaNoturnaFim,
      periodoMinimoInterjornada,
      percentualHeDiurna,
      percentualHeNoturna,
      duracaoHoraNoturna,
      tratamentoHoraMais,
      tratamentoHoraMenos);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoParametro &&
          other.id == this.id &&
          other.mesAno == this.mesAno &&
          other.diaInicialApuracao == this.diaInicialApuracao &&
          other.horaNoturnaInicio == this.horaNoturnaInicio &&
          other.horaNoturnaFim == this.horaNoturnaFim &&
          other.periodoMinimoInterjornada == this.periodoMinimoInterjornada &&
          other.percentualHeDiurna == this.percentualHeDiurna &&
          other.percentualHeNoturna == this.percentualHeNoturna &&
          other.duracaoHoraNoturna == this.duracaoHoraNoturna &&
          other.tratamentoHoraMais == this.tratamentoHoraMais &&
          other.tratamentoHoraMenos == this.tratamentoHoraMenos);
}

class PontoParametrosCompanion extends UpdateCompanion<PontoParametro> {
  final Value<int?> id;
  final Value<String?> mesAno;
  final Value<int?> diaInicialApuracao;
  final Value<String?> horaNoturnaInicio;
  final Value<String?> horaNoturnaFim;
  final Value<String?> periodoMinimoInterjornada;
  final Value<double?> percentualHeDiurna;
  final Value<double?> percentualHeNoturna;
  final Value<String?> duracaoHoraNoturna;
  final Value<String?> tratamentoHoraMais;
  final Value<String?> tratamentoHoraMenos;
  const PontoParametrosCompanion({
    this.id = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.diaInicialApuracao = const Value.absent(),
    this.horaNoturnaInicio = const Value.absent(),
    this.horaNoturnaFim = const Value.absent(),
    this.periodoMinimoInterjornada = const Value.absent(),
    this.percentualHeDiurna = const Value.absent(),
    this.percentualHeNoturna = const Value.absent(),
    this.duracaoHoraNoturna = const Value.absent(),
    this.tratamentoHoraMais = const Value.absent(),
    this.tratamentoHoraMenos = const Value.absent(),
  });
  PontoParametrosCompanion.insert({
    this.id = const Value.absent(),
    this.mesAno = const Value.absent(),
    this.diaInicialApuracao = const Value.absent(),
    this.horaNoturnaInicio = const Value.absent(),
    this.horaNoturnaFim = const Value.absent(),
    this.periodoMinimoInterjornada = const Value.absent(),
    this.percentualHeDiurna = const Value.absent(),
    this.percentualHeNoturna = const Value.absent(),
    this.duracaoHoraNoturna = const Value.absent(),
    this.tratamentoHoraMais = const Value.absent(),
    this.tratamentoHoraMenos = const Value.absent(),
  });
  static Insertable<PontoParametro> custom({
    Expression<int>? id,
    Expression<String>? mesAno,
    Expression<int>? diaInicialApuracao,
    Expression<String>? horaNoturnaInicio,
    Expression<String>? horaNoturnaFim,
    Expression<String>? periodoMinimoInterjornada,
    Expression<double>? percentualHeDiurna,
    Expression<double>? percentualHeNoturna,
    Expression<String>? duracaoHoraNoturna,
    Expression<String>? tratamentoHoraMais,
    Expression<String>? tratamentoHoraMenos,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (mesAno != null) 'mes_ano': mesAno,
      if (diaInicialApuracao != null)
        'dia_inicial_apuracao': diaInicialApuracao,
      if (horaNoturnaInicio != null) 'hora_noturna_inicio': horaNoturnaInicio,
      if (horaNoturnaFim != null) 'hora_noturna_fim': horaNoturnaFim,
      if (periodoMinimoInterjornada != null)
        'periodo_minimo_interjornada': periodoMinimoInterjornada,
      if (percentualHeDiurna != null)
        'percentual_he_diurna': percentualHeDiurna,
      if (percentualHeNoturna != null)
        'percentual_he_noturna': percentualHeNoturna,
      if (duracaoHoraNoturna != null)
        'duracao_hora_noturna': duracaoHoraNoturna,
      if (tratamentoHoraMais != null)
        'tratamento_hora_mais': tratamentoHoraMais,
      if (tratamentoHoraMenos != null)
        'tratamento_hora_menos': tratamentoHoraMenos,
    });
  }

  PontoParametrosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? mesAno,
      Value<int?>? diaInicialApuracao,
      Value<String?>? horaNoturnaInicio,
      Value<String?>? horaNoturnaFim,
      Value<String?>? periodoMinimoInterjornada,
      Value<double?>? percentualHeDiurna,
      Value<double?>? percentualHeNoturna,
      Value<String?>? duracaoHoraNoturna,
      Value<String?>? tratamentoHoraMais,
      Value<String?>? tratamentoHoraMenos}) {
    return PontoParametrosCompanion(
      id: id ?? this.id,
      mesAno: mesAno ?? this.mesAno,
      diaInicialApuracao: diaInicialApuracao ?? this.diaInicialApuracao,
      horaNoturnaInicio: horaNoturnaInicio ?? this.horaNoturnaInicio,
      horaNoturnaFim: horaNoturnaFim ?? this.horaNoturnaFim,
      periodoMinimoInterjornada:
          periodoMinimoInterjornada ?? this.periodoMinimoInterjornada,
      percentualHeDiurna: percentualHeDiurna ?? this.percentualHeDiurna,
      percentualHeNoturna: percentualHeNoturna ?? this.percentualHeNoturna,
      duracaoHoraNoturna: duracaoHoraNoturna ?? this.duracaoHoraNoturna,
      tratamentoHoraMais: tratamentoHoraMais ?? this.tratamentoHoraMais,
      tratamentoHoraMenos: tratamentoHoraMenos ?? this.tratamentoHoraMenos,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (mesAno.present) {
      map['mes_ano'] = Variable<String>(mesAno.value);
    }
    if (diaInicialApuracao.present) {
      map['dia_inicial_apuracao'] = Variable<int>(diaInicialApuracao.value);
    }
    if (horaNoturnaInicio.present) {
      map['hora_noturna_inicio'] = Variable<String>(horaNoturnaInicio.value);
    }
    if (horaNoturnaFim.present) {
      map['hora_noturna_fim'] = Variable<String>(horaNoturnaFim.value);
    }
    if (periodoMinimoInterjornada.present) {
      map['periodo_minimo_interjornada'] =
          Variable<String>(periodoMinimoInterjornada.value);
    }
    if (percentualHeDiurna.present) {
      map['percentual_he_diurna'] = Variable<double>(percentualHeDiurna.value);
    }
    if (percentualHeNoturna.present) {
      map['percentual_he_noturna'] =
          Variable<double>(percentualHeNoturna.value);
    }
    if (duracaoHoraNoturna.present) {
      map['duracao_hora_noturna'] = Variable<String>(duracaoHoraNoturna.value);
    }
    if (tratamentoHoraMais.present) {
      map['tratamento_hora_mais'] = Variable<String>(tratamentoHoraMais.value);
    }
    if (tratamentoHoraMenos.present) {
      map['tratamento_hora_menos'] =
          Variable<String>(tratamentoHoraMenos.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoParametrosCompanion(')
          ..write('id: $id, ')
          ..write('mesAno: $mesAno, ')
          ..write('diaInicialApuracao: $diaInicialApuracao, ')
          ..write('horaNoturnaInicio: $horaNoturnaInicio, ')
          ..write('horaNoturnaFim: $horaNoturnaFim, ')
          ..write('periodoMinimoInterjornada: $periodoMinimoInterjornada, ')
          ..write('percentualHeDiurna: $percentualHeDiurna, ')
          ..write('percentualHeNoturna: $percentualHeNoturna, ')
          ..write('duracaoHoraNoturna: $duracaoHoraNoturna, ')
          ..write('tratamentoHoraMais: $tratamentoHoraMais, ')
          ..write('tratamentoHoraMenos: $tratamentoHoraMenos')
          ..write(')'))
        .toString();
  }
}

class $PontoHorariosTable extends PontoHorarios
    with TableInfo<$PontoHorariosTable, PontoHorario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoHorariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoTrabalhoMeta =
      const VerificationMeta('tipoTrabalho');
  @override
  late final GeneratedColumn<String> tipoTrabalho = GeneratedColumn<String>(
      'tipo_trabalho', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaMeta =
      const VerificationMeta('cargaHoraria');
  @override
  late final GeneratedColumn<String> cargaHoraria = GeneratedColumn<String>(
      'carga_horaria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada01Meta =
      const VerificationMeta('entrada01');
  @override
  late final GeneratedColumn<String> entrada01 = GeneratedColumn<String>(
      'entrada01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida01Meta =
      const VerificationMeta('saida01');
  @override
  late final GeneratedColumn<String> saida01 = GeneratedColumn<String>(
      'saida01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada02Meta =
      const VerificationMeta('entrada02');
  @override
  late final GeneratedColumn<String> entrada02 = GeneratedColumn<String>(
      'entrada02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida02Meta =
      const VerificationMeta('saida02');
  @override
  late final GeneratedColumn<String> saida02 = GeneratedColumn<String>(
      'saida02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada03Meta =
      const VerificationMeta('entrada03');
  @override
  late final GeneratedColumn<String> entrada03 = GeneratedColumn<String>(
      'entrada03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida03Meta =
      const VerificationMeta('saida03');
  @override
  late final GeneratedColumn<String> saida03 = GeneratedColumn<String>(
      'saida03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada04Meta =
      const VerificationMeta('entrada04');
  @override
  late final GeneratedColumn<String> entrada04 = GeneratedColumn<String>(
      'entrada04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida04Meta =
      const VerificationMeta('saida04');
  @override
  late final GeneratedColumn<String> saida04 = GeneratedColumn<String>(
      'saida04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada05Meta =
      const VerificationMeta('entrada05');
  @override
  late final GeneratedColumn<String> entrada05 = GeneratedColumn<String>(
      'entrada05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida05Meta =
      const VerificationMeta('saida05');
  @override
  late final GeneratedColumn<String> saida05 = GeneratedColumn<String>(
      'saida05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _horaInicioJornadaMeta =
      const VerificationMeta('horaInicioJornada');
  @override
  late final GeneratedColumn<String> horaInicioJornada =
      GeneratedColumn<String>('hora_inicio_jornada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaFimJornadaMeta =
      const VerificationMeta('horaFimJornada');
  @override
  late final GeneratedColumn<String> horaFimJornada = GeneratedColumn<String>(
      'hora_fim_jornada', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        tipo,
        codigo,
        nome,
        tipoTrabalho,
        cargaHoraria,
        entrada01,
        saida01,
        entrada02,
        saida02,
        entrada03,
        saida03,
        entrada04,
        saida04,
        entrada05,
        saida05,
        horaInicioJornada,
        horaFimJornada
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_horario';
  @override
  VerificationContext validateIntegrity(Insertable<PontoHorario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo_trabalho')) {
      context.handle(
          _tipoTrabalhoMeta,
          tipoTrabalho.isAcceptableOrUnknown(
              data['tipo_trabalho']!, _tipoTrabalhoMeta));
    }
    if (data.containsKey('carga_horaria')) {
      context.handle(
          _cargaHorariaMeta,
          cargaHoraria.isAcceptableOrUnknown(
              data['carga_horaria']!, _cargaHorariaMeta));
    }
    if (data.containsKey('entrada01')) {
      context.handle(_entrada01Meta,
          entrada01.isAcceptableOrUnknown(data['entrada01']!, _entrada01Meta));
    }
    if (data.containsKey('saida01')) {
      context.handle(_saida01Meta,
          saida01.isAcceptableOrUnknown(data['saida01']!, _saida01Meta));
    }
    if (data.containsKey('entrada02')) {
      context.handle(_entrada02Meta,
          entrada02.isAcceptableOrUnknown(data['entrada02']!, _entrada02Meta));
    }
    if (data.containsKey('saida02')) {
      context.handle(_saida02Meta,
          saida02.isAcceptableOrUnknown(data['saida02']!, _saida02Meta));
    }
    if (data.containsKey('entrada03')) {
      context.handle(_entrada03Meta,
          entrada03.isAcceptableOrUnknown(data['entrada03']!, _entrada03Meta));
    }
    if (data.containsKey('saida03')) {
      context.handle(_saida03Meta,
          saida03.isAcceptableOrUnknown(data['saida03']!, _saida03Meta));
    }
    if (data.containsKey('entrada04')) {
      context.handle(_entrada04Meta,
          entrada04.isAcceptableOrUnknown(data['entrada04']!, _entrada04Meta));
    }
    if (data.containsKey('saida04')) {
      context.handle(_saida04Meta,
          saida04.isAcceptableOrUnknown(data['saida04']!, _saida04Meta));
    }
    if (data.containsKey('entrada05')) {
      context.handle(_entrada05Meta,
          entrada05.isAcceptableOrUnknown(data['entrada05']!, _entrada05Meta));
    }
    if (data.containsKey('saida05')) {
      context.handle(_saida05Meta,
          saida05.isAcceptableOrUnknown(data['saida05']!, _saida05Meta));
    }
    if (data.containsKey('hora_inicio_jornada')) {
      context.handle(
          _horaInicioJornadaMeta,
          horaInicioJornada.isAcceptableOrUnknown(
              data['hora_inicio_jornada']!, _horaInicioJornadaMeta));
    }
    if (data.containsKey('hora_fim_jornada')) {
      context.handle(
          _horaFimJornadaMeta,
          horaFimJornada.isAcceptableOrUnknown(
              data['hora_fim_jornada']!, _horaFimJornadaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoHorario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoHorario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipoTrabalho: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_trabalho']),
      cargaHoraria: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}carga_horaria']),
      entrada01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada01']),
      saida01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida01']),
      entrada02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada02']),
      saida02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida02']),
      entrada03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada03']),
      saida03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida03']),
      entrada04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada04']),
      saida04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida04']),
      entrada05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada05']),
      saida05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida05']),
      horaInicioJornada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_inicio_jornada']),
      horaFimJornada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_fim_jornada']),
    );
  }

  @override
  $PontoHorariosTable createAlias(String alias) {
    return $PontoHorariosTable(attachedDatabase, alias);
  }
}

class PontoHorario extends DataClass implements Insertable<PontoHorario> {
  final int? id;
  final String? tipo;
  final String? codigo;
  final String? nome;
  final String? tipoTrabalho;
  final String? cargaHoraria;
  final String? entrada01;
  final String? saida01;
  final String? entrada02;
  final String? saida02;
  final String? entrada03;
  final String? saida03;
  final String? entrada04;
  final String? saida04;
  final String? entrada05;
  final String? saida05;
  final String? horaInicioJornada;
  final String? horaFimJornada;
  const PontoHorario(
      {this.id,
      this.tipo,
      this.codigo,
      this.nome,
      this.tipoTrabalho,
      this.cargaHoraria,
      this.entrada01,
      this.saida01,
      this.entrada02,
      this.saida02,
      this.entrada03,
      this.saida03,
      this.entrada04,
      this.saida04,
      this.entrada05,
      this.saida05,
      this.horaInicioJornada,
      this.horaFimJornada});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipoTrabalho != null) {
      map['tipo_trabalho'] = Variable<String>(tipoTrabalho);
    }
    if (!nullToAbsent || cargaHoraria != null) {
      map['carga_horaria'] = Variable<String>(cargaHoraria);
    }
    if (!nullToAbsent || entrada01 != null) {
      map['entrada01'] = Variable<String>(entrada01);
    }
    if (!nullToAbsent || saida01 != null) {
      map['saida01'] = Variable<String>(saida01);
    }
    if (!nullToAbsent || entrada02 != null) {
      map['entrada02'] = Variable<String>(entrada02);
    }
    if (!nullToAbsent || saida02 != null) {
      map['saida02'] = Variable<String>(saida02);
    }
    if (!nullToAbsent || entrada03 != null) {
      map['entrada03'] = Variable<String>(entrada03);
    }
    if (!nullToAbsent || saida03 != null) {
      map['saida03'] = Variable<String>(saida03);
    }
    if (!nullToAbsent || entrada04 != null) {
      map['entrada04'] = Variable<String>(entrada04);
    }
    if (!nullToAbsent || saida04 != null) {
      map['saida04'] = Variable<String>(saida04);
    }
    if (!nullToAbsent || entrada05 != null) {
      map['entrada05'] = Variable<String>(entrada05);
    }
    if (!nullToAbsent || saida05 != null) {
      map['saida05'] = Variable<String>(saida05);
    }
    if (!nullToAbsent || horaInicioJornada != null) {
      map['hora_inicio_jornada'] = Variable<String>(horaInicioJornada);
    }
    if (!nullToAbsent || horaFimJornada != null) {
      map['hora_fim_jornada'] = Variable<String>(horaFimJornada);
    }
    return map;
  }

  factory PontoHorario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoHorario(
      id: serializer.fromJson<int?>(json['id']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipoTrabalho: serializer.fromJson<String?>(json['tipoTrabalho']),
      cargaHoraria: serializer.fromJson<String?>(json['cargaHoraria']),
      entrada01: serializer.fromJson<String?>(json['entrada01']),
      saida01: serializer.fromJson<String?>(json['saida01']),
      entrada02: serializer.fromJson<String?>(json['entrada02']),
      saida02: serializer.fromJson<String?>(json['saida02']),
      entrada03: serializer.fromJson<String?>(json['entrada03']),
      saida03: serializer.fromJson<String?>(json['saida03']),
      entrada04: serializer.fromJson<String?>(json['entrada04']),
      saida04: serializer.fromJson<String?>(json['saida04']),
      entrada05: serializer.fromJson<String?>(json['entrada05']),
      saida05: serializer.fromJson<String?>(json['saida05']),
      horaInicioJornada:
          serializer.fromJson<String?>(json['horaInicioJornada']),
      horaFimJornada: serializer.fromJson<String?>(json['horaFimJornada']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'tipo': serializer.toJson<String?>(tipo),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'tipoTrabalho': serializer.toJson<String?>(tipoTrabalho),
      'cargaHoraria': serializer.toJson<String?>(cargaHoraria),
      'entrada01': serializer.toJson<String?>(entrada01),
      'saida01': serializer.toJson<String?>(saida01),
      'entrada02': serializer.toJson<String?>(entrada02),
      'saida02': serializer.toJson<String?>(saida02),
      'entrada03': serializer.toJson<String?>(entrada03),
      'saida03': serializer.toJson<String?>(saida03),
      'entrada04': serializer.toJson<String?>(entrada04),
      'saida04': serializer.toJson<String?>(saida04),
      'entrada05': serializer.toJson<String?>(entrada05),
      'saida05': serializer.toJson<String?>(saida05),
      'horaInicioJornada': serializer.toJson<String?>(horaInicioJornada),
      'horaFimJornada': serializer.toJson<String?>(horaFimJornada),
    };
  }

  PontoHorario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipoTrabalho = const Value.absent(),
          Value<String?> cargaHoraria = const Value.absent(),
          Value<String?> entrada01 = const Value.absent(),
          Value<String?> saida01 = const Value.absent(),
          Value<String?> entrada02 = const Value.absent(),
          Value<String?> saida02 = const Value.absent(),
          Value<String?> entrada03 = const Value.absent(),
          Value<String?> saida03 = const Value.absent(),
          Value<String?> entrada04 = const Value.absent(),
          Value<String?> saida04 = const Value.absent(),
          Value<String?> entrada05 = const Value.absent(),
          Value<String?> saida05 = const Value.absent(),
          Value<String?> horaInicioJornada = const Value.absent(),
          Value<String?> horaFimJornada = const Value.absent()}) =>
      PontoHorario(
        id: id.present ? id.value : this.id,
        tipo: tipo.present ? tipo.value : this.tipo,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        tipoTrabalho:
            tipoTrabalho.present ? tipoTrabalho.value : this.tipoTrabalho,
        cargaHoraria:
            cargaHoraria.present ? cargaHoraria.value : this.cargaHoraria,
        entrada01: entrada01.present ? entrada01.value : this.entrada01,
        saida01: saida01.present ? saida01.value : this.saida01,
        entrada02: entrada02.present ? entrada02.value : this.entrada02,
        saida02: saida02.present ? saida02.value : this.saida02,
        entrada03: entrada03.present ? entrada03.value : this.entrada03,
        saida03: saida03.present ? saida03.value : this.saida03,
        entrada04: entrada04.present ? entrada04.value : this.entrada04,
        saida04: saida04.present ? saida04.value : this.saida04,
        entrada05: entrada05.present ? entrada05.value : this.entrada05,
        saida05: saida05.present ? saida05.value : this.saida05,
        horaInicioJornada: horaInicioJornada.present
            ? horaInicioJornada.value
            : this.horaInicioJornada,
        horaFimJornada:
            horaFimJornada.present ? horaFimJornada.value : this.horaFimJornada,
      );
  @override
  String toString() {
    return (StringBuffer('PontoHorario(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('tipoTrabalho: $tipoTrabalho, ')
          ..write('cargaHoraria: $cargaHoraria, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaInicioJornada: $horaInicioJornada, ')
          ..write('horaFimJornada: $horaFimJornada')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      tipo,
      codigo,
      nome,
      tipoTrabalho,
      cargaHoraria,
      entrada01,
      saida01,
      entrada02,
      saida02,
      entrada03,
      saida03,
      entrada04,
      saida04,
      entrada05,
      saida05,
      horaInicioJornada,
      horaFimJornada);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoHorario &&
          other.id == this.id &&
          other.tipo == this.tipo &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.tipoTrabalho == this.tipoTrabalho &&
          other.cargaHoraria == this.cargaHoraria &&
          other.entrada01 == this.entrada01 &&
          other.saida01 == this.saida01 &&
          other.entrada02 == this.entrada02 &&
          other.saida02 == this.saida02 &&
          other.entrada03 == this.entrada03 &&
          other.saida03 == this.saida03 &&
          other.entrada04 == this.entrada04 &&
          other.saida04 == this.saida04 &&
          other.entrada05 == this.entrada05 &&
          other.saida05 == this.saida05 &&
          other.horaInicioJornada == this.horaInicioJornada &&
          other.horaFimJornada == this.horaFimJornada);
}

class PontoHorariosCompanion extends UpdateCompanion<PontoHorario> {
  final Value<int?> id;
  final Value<String?> tipo;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> tipoTrabalho;
  final Value<String?> cargaHoraria;
  final Value<String?> entrada01;
  final Value<String?> saida01;
  final Value<String?> entrada02;
  final Value<String?> saida02;
  final Value<String?> entrada03;
  final Value<String?> saida03;
  final Value<String?> entrada04;
  final Value<String?> saida04;
  final Value<String?> entrada05;
  final Value<String?> saida05;
  final Value<String?> horaInicioJornada;
  final Value<String?> horaFimJornada;
  const PontoHorariosCompanion({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipoTrabalho = const Value.absent(),
    this.cargaHoraria = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaInicioJornada = const Value.absent(),
    this.horaFimJornada = const Value.absent(),
  });
  PontoHorariosCompanion.insert({
    this.id = const Value.absent(),
    this.tipo = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipoTrabalho = const Value.absent(),
    this.cargaHoraria = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaInicioJornada = const Value.absent(),
    this.horaFimJornada = const Value.absent(),
  });
  static Insertable<PontoHorario> custom({
    Expression<int>? id,
    Expression<String>? tipo,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? tipoTrabalho,
    Expression<String>? cargaHoraria,
    Expression<String>? entrada01,
    Expression<String>? saida01,
    Expression<String>? entrada02,
    Expression<String>? saida02,
    Expression<String>? entrada03,
    Expression<String>? saida03,
    Expression<String>? entrada04,
    Expression<String>? saida04,
    Expression<String>? entrada05,
    Expression<String>? saida05,
    Expression<String>? horaInicioJornada,
    Expression<String>? horaFimJornada,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (tipo != null) 'tipo': tipo,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (tipoTrabalho != null) 'tipo_trabalho': tipoTrabalho,
      if (cargaHoraria != null) 'carga_horaria': cargaHoraria,
      if (entrada01 != null) 'entrada01': entrada01,
      if (saida01 != null) 'saida01': saida01,
      if (entrada02 != null) 'entrada02': entrada02,
      if (saida02 != null) 'saida02': saida02,
      if (entrada03 != null) 'entrada03': entrada03,
      if (saida03 != null) 'saida03': saida03,
      if (entrada04 != null) 'entrada04': entrada04,
      if (saida04 != null) 'saida04': saida04,
      if (entrada05 != null) 'entrada05': entrada05,
      if (saida05 != null) 'saida05': saida05,
      if (horaInicioJornada != null) 'hora_inicio_jornada': horaInicioJornada,
      if (horaFimJornada != null) 'hora_fim_jornada': horaFimJornada,
    });
  }

  PontoHorariosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? tipo,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? tipoTrabalho,
      Value<String?>? cargaHoraria,
      Value<String?>? entrada01,
      Value<String?>? saida01,
      Value<String?>? entrada02,
      Value<String?>? saida02,
      Value<String?>? entrada03,
      Value<String?>? saida03,
      Value<String?>? entrada04,
      Value<String?>? saida04,
      Value<String?>? entrada05,
      Value<String?>? saida05,
      Value<String?>? horaInicioJornada,
      Value<String?>? horaFimJornada}) {
    return PontoHorariosCompanion(
      id: id ?? this.id,
      tipo: tipo ?? this.tipo,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      tipoTrabalho: tipoTrabalho ?? this.tipoTrabalho,
      cargaHoraria: cargaHoraria ?? this.cargaHoraria,
      entrada01: entrada01 ?? this.entrada01,
      saida01: saida01 ?? this.saida01,
      entrada02: entrada02 ?? this.entrada02,
      saida02: saida02 ?? this.saida02,
      entrada03: entrada03 ?? this.entrada03,
      saida03: saida03 ?? this.saida03,
      entrada04: entrada04 ?? this.entrada04,
      saida04: saida04 ?? this.saida04,
      entrada05: entrada05 ?? this.entrada05,
      saida05: saida05 ?? this.saida05,
      horaInicioJornada: horaInicioJornada ?? this.horaInicioJornada,
      horaFimJornada: horaFimJornada ?? this.horaFimJornada,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipoTrabalho.present) {
      map['tipo_trabalho'] = Variable<String>(tipoTrabalho.value);
    }
    if (cargaHoraria.present) {
      map['carga_horaria'] = Variable<String>(cargaHoraria.value);
    }
    if (entrada01.present) {
      map['entrada01'] = Variable<String>(entrada01.value);
    }
    if (saida01.present) {
      map['saida01'] = Variable<String>(saida01.value);
    }
    if (entrada02.present) {
      map['entrada02'] = Variable<String>(entrada02.value);
    }
    if (saida02.present) {
      map['saida02'] = Variable<String>(saida02.value);
    }
    if (entrada03.present) {
      map['entrada03'] = Variable<String>(entrada03.value);
    }
    if (saida03.present) {
      map['saida03'] = Variable<String>(saida03.value);
    }
    if (entrada04.present) {
      map['entrada04'] = Variable<String>(entrada04.value);
    }
    if (saida04.present) {
      map['saida04'] = Variable<String>(saida04.value);
    }
    if (entrada05.present) {
      map['entrada05'] = Variable<String>(entrada05.value);
    }
    if (saida05.present) {
      map['saida05'] = Variable<String>(saida05.value);
    }
    if (horaInicioJornada.present) {
      map['hora_inicio_jornada'] = Variable<String>(horaInicioJornada.value);
    }
    if (horaFimJornada.present) {
      map['hora_fim_jornada'] = Variable<String>(horaFimJornada.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoHorariosCompanion(')
          ..write('id: $id, ')
          ..write('tipo: $tipo, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('tipoTrabalho: $tipoTrabalho, ')
          ..write('cargaHoraria: $cargaHoraria, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaInicioJornada: $horaInicioJornada, ')
          ..write('horaFimJornada: $horaFimJornada')
          ..write(')'))
        .toString();
  }
}

class $PontoRelogiosTable extends PontoRelogios
    with TableInfo<$PontoRelogiosTable, PontoRelogio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoRelogiosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _localizacaoMeta =
      const VerificationMeta('localizacao');
  @override
  late final GeneratedColumn<String> localizacao = GeneratedColumn<String>(
      'localizacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _marcaMeta = const VerificationMeta('marca');
  @override
  late final GeneratedColumn<String> marca = GeneratedColumn<String>(
      'marca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fabricanteMeta =
      const VerificationMeta('fabricante');
  @override
  late final GeneratedColumn<String> fabricante = GeneratedColumn<String>(
      'fabricante', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroSerieMeta =
      const VerificationMeta('numeroSerie');
  @override
  late final GeneratedColumn<String> numeroSerie = GeneratedColumn<String>(
      'numero_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _utilizacaoMeta =
      const VerificationMeta('utilizacao');
  @override
  late final GeneratedColumn<String> utilizacao = GeneratedColumn<String>(
      'utilizacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, localizacao, marca, fabricante, numeroSerie, utilizacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_relogio';
  @override
  VerificationContext validateIntegrity(Insertable<PontoRelogio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('localizacao')) {
      context.handle(
          _localizacaoMeta,
          localizacao.isAcceptableOrUnknown(
              data['localizacao']!, _localizacaoMeta));
    }
    if (data.containsKey('marca')) {
      context.handle(
          _marcaMeta, marca.isAcceptableOrUnknown(data['marca']!, _marcaMeta));
    }
    if (data.containsKey('fabricante')) {
      context.handle(
          _fabricanteMeta,
          fabricante.isAcceptableOrUnknown(
              data['fabricante']!, _fabricanteMeta));
    }
    if (data.containsKey('numero_serie')) {
      context.handle(
          _numeroSerieMeta,
          numeroSerie.isAcceptableOrUnknown(
              data['numero_serie']!, _numeroSerieMeta));
    }
    if (data.containsKey('utilizacao')) {
      context.handle(
          _utilizacaoMeta,
          utilizacao.isAcceptableOrUnknown(
              data['utilizacao']!, _utilizacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoRelogio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoRelogio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      localizacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}localizacao']),
      marca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}marca']),
      fabricante: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fabricante']),
      numeroSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_serie']),
      utilizacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}utilizacao']),
    );
  }

  @override
  $PontoRelogiosTable createAlias(String alias) {
    return $PontoRelogiosTable(attachedDatabase, alias);
  }
}

class PontoRelogio extends DataClass implements Insertable<PontoRelogio> {
  final int? id;
  final String? localizacao;
  final String? marca;
  final String? fabricante;
  final String? numeroSerie;
  final String? utilizacao;
  const PontoRelogio(
      {this.id,
      this.localizacao,
      this.marca,
      this.fabricante,
      this.numeroSerie,
      this.utilizacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || localizacao != null) {
      map['localizacao'] = Variable<String>(localizacao);
    }
    if (!nullToAbsent || marca != null) {
      map['marca'] = Variable<String>(marca);
    }
    if (!nullToAbsent || fabricante != null) {
      map['fabricante'] = Variable<String>(fabricante);
    }
    if (!nullToAbsent || numeroSerie != null) {
      map['numero_serie'] = Variable<String>(numeroSerie);
    }
    if (!nullToAbsent || utilizacao != null) {
      map['utilizacao'] = Variable<String>(utilizacao);
    }
    return map;
  }

  factory PontoRelogio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoRelogio(
      id: serializer.fromJson<int?>(json['id']),
      localizacao: serializer.fromJson<String?>(json['localizacao']),
      marca: serializer.fromJson<String?>(json['marca']),
      fabricante: serializer.fromJson<String?>(json['fabricante']),
      numeroSerie: serializer.fromJson<String?>(json['numeroSerie']),
      utilizacao: serializer.fromJson<String?>(json['utilizacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'localizacao': serializer.toJson<String?>(localizacao),
      'marca': serializer.toJson<String?>(marca),
      'fabricante': serializer.toJson<String?>(fabricante),
      'numeroSerie': serializer.toJson<String?>(numeroSerie),
      'utilizacao': serializer.toJson<String?>(utilizacao),
    };
  }

  PontoRelogio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> localizacao = const Value.absent(),
          Value<String?> marca = const Value.absent(),
          Value<String?> fabricante = const Value.absent(),
          Value<String?> numeroSerie = const Value.absent(),
          Value<String?> utilizacao = const Value.absent()}) =>
      PontoRelogio(
        id: id.present ? id.value : this.id,
        localizacao: localizacao.present ? localizacao.value : this.localizacao,
        marca: marca.present ? marca.value : this.marca,
        fabricante: fabricante.present ? fabricante.value : this.fabricante,
        numeroSerie: numeroSerie.present ? numeroSerie.value : this.numeroSerie,
        utilizacao: utilizacao.present ? utilizacao.value : this.utilizacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoRelogio(')
          ..write('id: $id, ')
          ..write('localizacao: $localizacao, ')
          ..write('marca: $marca, ')
          ..write('fabricante: $fabricante, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('utilizacao: $utilizacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, localizacao, marca, fabricante, numeroSerie, utilizacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoRelogio &&
          other.id == this.id &&
          other.localizacao == this.localizacao &&
          other.marca == this.marca &&
          other.fabricante == this.fabricante &&
          other.numeroSerie == this.numeroSerie &&
          other.utilizacao == this.utilizacao);
}

class PontoRelogiosCompanion extends UpdateCompanion<PontoRelogio> {
  final Value<int?> id;
  final Value<String?> localizacao;
  final Value<String?> marca;
  final Value<String?> fabricante;
  final Value<String?> numeroSerie;
  final Value<String?> utilizacao;
  const PontoRelogiosCompanion({
    this.id = const Value.absent(),
    this.localizacao = const Value.absent(),
    this.marca = const Value.absent(),
    this.fabricante = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.utilizacao = const Value.absent(),
  });
  PontoRelogiosCompanion.insert({
    this.id = const Value.absent(),
    this.localizacao = const Value.absent(),
    this.marca = const Value.absent(),
    this.fabricante = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.utilizacao = const Value.absent(),
  });
  static Insertable<PontoRelogio> custom({
    Expression<int>? id,
    Expression<String>? localizacao,
    Expression<String>? marca,
    Expression<String>? fabricante,
    Expression<String>? numeroSerie,
    Expression<String>? utilizacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (localizacao != null) 'localizacao': localizacao,
      if (marca != null) 'marca': marca,
      if (fabricante != null) 'fabricante': fabricante,
      if (numeroSerie != null) 'numero_serie': numeroSerie,
      if (utilizacao != null) 'utilizacao': utilizacao,
    });
  }

  PontoRelogiosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? localizacao,
      Value<String?>? marca,
      Value<String?>? fabricante,
      Value<String?>? numeroSerie,
      Value<String?>? utilizacao}) {
    return PontoRelogiosCompanion(
      id: id ?? this.id,
      localizacao: localizacao ?? this.localizacao,
      marca: marca ?? this.marca,
      fabricante: fabricante ?? this.fabricante,
      numeroSerie: numeroSerie ?? this.numeroSerie,
      utilizacao: utilizacao ?? this.utilizacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (localizacao.present) {
      map['localizacao'] = Variable<String>(localizacao.value);
    }
    if (marca.present) {
      map['marca'] = Variable<String>(marca.value);
    }
    if (fabricante.present) {
      map['fabricante'] = Variable<String>(fabricante.value);
    }
    if (numeroSerie.present) {
      map['numero_serie'] = Variable<String>(numeroSerie.value);
    }
    if (utilizacao.present) {
      map['utilizacao'] = Variable<String>(utilizacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoRelogiosCompanion(')
          ..write('id: $id, ')
          ..write('localizacao: $localizacao, ')
          ..write('marca: $marca, ')
          ..write('fabricante: $fabricante, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('utilizacao: $utilizacao')
          ..write(')'))
        .toString();
  }
}

class $PontoMarcacaosTable extends PontoMarcacaos
    with TableInfo<$PontoMarcacaosTable, PontoMarcacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoMarcacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPontoRelogioMeta =
      const VerificationMeta('idPontoRelogio');
  @override
  late final GeneratedColumn<int> idPontoRelogio = GeneratedColumn<int>(
      'id_ponto_relogio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nsrMeta = const VerificationMeta('nsr');
  @override
  late final GeneratedColumn<int> nsr = GeneratedColumn<int>(
      'nsr', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataMarcacaoMeta =
      const VerificationMeta('dataMarcacao');
  @override
  late final GeneratedColumn<DateTime> dataMarcacao = GeneratedColumn<DateTime>(
      'data_marcacao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaMarcacaoMeta =
      const VerificationMeta('horaMarcacao');
  @override
  late final GeneratedColumn<String> horaMarcacao = GeneratedColumn<String>(
      'hora_marcacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMarcacaoMeta =
      const VerificationMeta('tipoMarcacao');
  @override
  late final GeneratedColumn<String> tipoMarcacao = GeneratedColumn<String>(
      'tipo_marcacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoRegistroMeta =
      const VerificationMeta('tipoRegistro');
  @override
  late final GeneratedColumn<String> tipoRegistro = GeneratedColumn<String>(
      'tipo_registro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _parEntradaSaidaMeta =
      const VerificationMeta('parEntradaSaida');
  @override
  late final GeneratedColumn<String> parEntradaSaida = GeneratedColumn<String>(
      'par_entrada_saida', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _justificativaMeta =
      const VerificationMeta('justificativa');
  @override
  late final GeneratedColumn<String> justificativa = GeneratedColumn<String>(
      'justificativa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPontoRelogio,
        idColaborador,
        nsr,
        dataMarcacao,
        horaMarcacao,
        tipoMarcacao,
        tipoRegistro,
        parEntradaSaida,
        justificativa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_marcacao';
  @override
  VerificationContext validateIntegrity(Insertable<PontoMarcacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ponto_relogio')) {
      context.handle(
          _idPontoRelogioMeta,
          idPontoRelogio.isAcceptableOrUnknown(
              data['id_ponto_relogio']!, _idPontoRelogioMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('nsr')) {
      context.handle(
          _nsrMeta, nsr.isAcceptableOrUnknown(data['nsr']!, _nsrMeta));
    }
    if (data.containsKey('data_marcacao')) {
      context.handle(
          _dataMarcacaoMeta,
          dataMarcacao.isAcceptableOrUnknown(
              data['data_marcacao']!, _dataMarcacaoMeta));
    }
    if (data.containsKey('hora_marcacao')) {
      context.handle(
          _horaMarcacaoMeta,
          horaMarcacao.isAcceptableOrUnknown(
              data['hora_marcacao']!, _horaMarcacaoMeta));
    }
    if (data.containsKey('tipo_marcacao')) {
      context.handle(
          _tipoMarcacaoMeta,
          tipoMarcacao.isAcceptableOrUnknown(
              data['tipo_marcacao']!, _tipoMarcacaoMeta));
    }
    if (data.containsKey('tipo_registro')) {
      context.handle(
          _tipoRegistroMeta,
          tipoRegistro.isAcceptableOrUnknown(
              data['tipo_registro']!, _tipoRegistroMeta));
    }
    if (data.containsKey('par_entrada_saida')) {
      context.handle(
          _parEntradaSaidaMeta,
          parEntradaSaida.isAcceptableOrUnknown(
              data['par_entrada_saida']!, _parEntradaSaidaMeta));
    }
    if (data.containsKey('justificativa')) {
      context.handle(
          _justificativaMeta,
          justificativa.isAcceptableOrUnknown(
              data['justificativa']!, _justificativaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoMarcacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoMarcacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPontoRelogio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_ponto_relogio']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      nsr: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}nsr']),
      dataMarcacao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_marcacao']),
      horaMarcacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_marcacao']),
      tipoMarcacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_marcacao']),
      tipoRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_registro']),
      parEntradaSaida: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}par_entrada_saida']),
      justificativa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}justificativa']),
    );
  }

  @override
  $PontoMarcacaosTable createAlias(String alias) {
    return $PontoMarcacaosTable(attachedDatabase, alias);
  }
}

class PontoMarcacao extends DataClass implements Insertable<PontoMarcacao> {
  final int? id;
  final int? idPontoRelogio;
  final int? idColaborador;
  final int? nsr;
  final DateTime? dataMarcacao;
  final String? horaMarcacao;
  final String? tipoMarcacao;
  final String? tipoRegistro;
  final String? parEntradaSaida;
  final String? justificativa;
  const PontoMarcacao(
      {this.id,
      this.idPontoRelogio,
      this.idColaborador,
      this.nsr,
      this.dataMarcacao,
      this.horaMarcacao,
      this.tipoMarcacao,
      this.tipoRegistro,
      this.parEntradaSaida,
      this.justificativa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPontoRelogio != null) {
      map['id_ponto_relogio'] = Variable<int>(idPontoRelogio);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || nsr != null) {
      map['nsr'] = Variable<int>(nsr);
    }
    if (!nullToAbsent || dataMarcacao != null) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao);
    }
    if (!nullToAbsent || horaMarcacao != null) {
      map['hora_marcacao'] = Variable<String>(horaMarcacao);
    }
    if (!nullToAbsent || tipoMarcacao != null) {
      map['tipo_marcacao'] = Variable<String>(tipoMarcacao);
    }
    if (!nullToAbsent || tipoRegistro != null) {
      map['tipo_registro'] = Variable<String>(tipoRegistro);
    }
    if (!nullToAbsent || parEntradaSaida != null) {
      map['par_entrada_saida'] = Variable<String>(parEntradaSaida);
    }
    if (!nullToAbsent || justificativa != null) {
      map['justificativa'] = Variable<String>(justificativa);
    }
    return map;
  }

  factory PontoMarcacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoMarcacao(
      id: serializer.fromJson<int?>(json['id']),
      idPontoRelogio: serializer.fromJson<int?>(json['idPontoRelogio']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      nsr: serializer.fromJson<int?>(json['nsr']),
      dataMarcacao: serializer.fromJson<DateTime?>(json['dataMarcacao']),
      horaMarcacao: serializer.fromJson<String?>(json['horaMarcacao']),
      tipoMarcacao: serializer.fromJson<String?>(json['tipoMarcacao']),
      tipoRegistro: serializer.fromJson<String?>(json['tipoRegistro']),
      parEntradaSaida: serializer.fromJson<String?>(json['parEntradaSaida']),
      justificativa: serializer.fromJson<String?>(json['justificativa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPontoRelogio': serializer.toJson<int?>(idPontoRelogio),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'nsr': serializer.toJson<int?>(nsr),
      'dataMarcacao': serializer.toJson<DateTime?>(dataMarcacao),
      'horaMarcacao': serializer.toJson<String?>(horaMarcacao),
      'tipoMarcacao': serializer.toJson<String?>(tipoMarcacao),
      'tipoRegistro': serializer.toJson<String?>(tipoRegistro),
      'parEntradaSaida': serializer.toJson<String?>(parEntradaSaida),
      'justificativa': serializer.toJson<String?>(justificativa),
    };
  }

  PontoMarcacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPontoRelogio = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> nsr = const Value.absent(),
          Value<DateTime?> dataMarcacao = const Value.absent(),
          Value<String?> horaMarcacao = const Value.absent(),
          Value<String?> tipoMarcacao = const Value.absent(),
          Value<String?> tipoRegistro = const Value.absent(),
          Value<String?> parEntradaSaida = const Value.absent(),
          Value<String?> justificativa = const Value.absent()}) =>
      PontoMarcacao(
        id: id.present ? id.value : this.id,
        idPontoRelogio:
            idPontoRelogio.present ? idPontoRelogio.value : this.idPontoRelogio,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        nsr: nsr.present ? nsr.value : this.nsr,
        dataMarcacao:
            dataMarcacao.present ? dataMarcacao.value : this.dataMarcacao,
        horaMarcacao:
            horaMarcacao.present ? horaMarcacao.value : this.horaMarcacao,
        tipoMarcacao:
            tipoMarcacao.present ? tipoMarcacao.value : this.tipoMarcacao,
        tipoRegistro:
            tipoRegistro.present ? tipoRegistro.value : this.tipoRegistro,
        parEntradaSaida: parEntradaSaida.present
            ? parEntradaSaida.value
            : this.parEntradaSaida,
        justificativa:
            justificativa.present ? justificativa.value : this.justificativa,
      );
  @override
  String toString() {
    return (StringBuffer('PontoMarcacao(')
          ..write('id: $id, ')
          ..write('idPontoRelogio: $idPontoRelogio, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('nsr: $nsr, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('horaMarcacao: $horaMarcacao, ')
          ..write('tipoMarcacao: $tipoMarcacao, ')
          ..write('tipoRegistro: $tipoRegistro, ')
          ..write('parEntradaSaida: $parEntradaSaida, ')
          ..write('justificativa: $justificativa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPontoRelogio,
      idColaborador,
      nsr,
      dataMarcacao,
      horaMarcacao,
      tipoMarcacao,
      tipoRegistro,
      parEntradaSaida,
      justificativa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoMarcacao &&
          other.id == this.id &&
          other.idPontoRelogio == this.idPontoRelogio &&
          other.idColaborador == this.idColaborador &&
          other.nsr == this.nsr &&
          other.dataMarcacao == this.dataMarcacao &&
          other.horaMarcacao == this.horaMarcacao &&
          other.tipoMarcacao == this.tipoMarcacao &&
          other.tipoRegistro == this.tipoRegistro &&
          other.parEntradaSaida == this.parEntradaSaida &&
          other.justificativa == this.justificativa);
}

class PontoMarcacaosCompanion extends UpdateCompanion<PontoMarcacao> {
  final Value<int?> id;
  final Value<int?> idPontoRelogio;
  final Value<int?> idColaborador;
  final Value<int?> nsr;
  final Value<DateTime?> dataMarcacao;
  final Value<String?> horaMarcacao;
  final Value<String?> tipoMarcacao;
  final Value<String?> tipoRegistro;
  final Value<String?> parEntradaSaida;
  final Value<String?> justificativa;
  const PontoMarcacaosCompanion({
    this.id = const Value.absent(),
    this.idPontoRelogio = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.nsr = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.horaMarcacao = const Value.absent(),
    this.tipoMarcacao = const Value.absent(),
    this.tipoRegistro = const Value.absent(),
    this.parEntradaSaida = const Value.absent(),
    this.justificativa = const Value.absent(),
  });
  PontoMarcacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idPontoRelogio = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.nsr = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.horaMarcacao = const Value.absent(),
    this.tipoMarcacao = const Value.absent(),
    this.tipoRegistro = const Value.absent(),
    this.parEntradaSaida = const Value.absent(),
    this.justificativa = const Value.absent(),
  });
  static Insertable<PontoMarcacao> custom({
    Expression<int>? id,
    Expression<int>? idPontoRelogio,
    Expression<int>? idColaborador,
    Expression<int>? nsr,
    Expression<DateTime>? dataMarcacao,
    Expression<String>? horaMarcacao,
    Expression<String>? tipoMarcacao,
    Expression<String>? tipoRegistro,
    Expression<String>? parEntradaSaida,
    Expression<String>? justificativa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPontoRelogio != null) 'id_ponto_relogio': idPontoRelogio,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (nsr != null) 'nsr': nsr,
      if (dataMarcacao != null) 'data_marcacao': dataMarcacao,
      if (horaMarcacao != null) 'hora_marcacao': horaMarcacao,
      if (tipoMarcacao != null) 'tipo_marcacao': tipoMarcacao,
      if (tipoRegistro != null) 'tipo_registro': tipoRegistro,
      if (parEntradaSaida != null) 'par_entrada_saida': parEntradaSaida,
      if (justificativa != null) 'justificativa': justificativa,
    });
  }

  PontoMarcacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPontoRelogio,
      Value<int?>? idColaborador,
      Value<int?>? nsr,
      Value<DateTime?>? dataMarcacao,
      Value<String?>? horaMarcacao,
      Value<String?>? tipoMarcacao,
      Value<String?>? tipoRegistro,
      Value<String?>? parEntradaSaida,
      Value<String?>? justificativa}) {
    return PontoMarcacaosCompanion(
      id: id ?? this.id,
      idPontoRelogio: idPontoRelogio ?? this.idPontoRelogio,
      idColaborador: idColaborador ?? this.idColaborador,
      nsr: nsr ?? this.nsr,
      dataMarcacao: dataMarcacao ?? this.dataMarcacao,
      horaMarcacao: horaMarcacao ?? this.horaMarcacao,
      tipoMarcacao: tipoMarcacao ?? this.tipoMarcacao,
      tipoRegistro: tipoRegistro ?? this.tipoRegistro,
      parEntradaSaida: parEntradaSaida ?? this.parEntradaSaida,
      justificativa: justificativa ?? this.justificativa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPontoRelogio.present) {
      map['id_ponto_relogio'] = Variable<int>(idPontoRelogio.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (nsr.present) {
      map['nsr'] = Variable<int>(nsr.value);
    }
    if (dataMarcacao.present) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao.value);
    }
    if (horaMarcacao.present) {
      map['hora_marcacao'] = Variable<String>(horaMarcacao.value);
    }
    if (tipoMarcacao.present) {
      map['tipo_marcacao'] = Variable<String>(tipoMarcacao.value);
    }
    if (tipoRegistro.present) {
      map['tipo_registro'] = Variable<String>(tipoRegistro.value);
    }
    if (parEntradaSaida.present) {
      map['par_entrada_saida'] = Variable<String>(parEntradaSaida.value);
    }
    if (justificativa.present) {
      map['justificativa'] = Variable<String>(justificativa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoMarcacaosCompanion(')
          ..write('id: $id, ')
          ..write('idPontoRelogio: $idPontoRelogio, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('nsr: $nsr, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('horaMarcacao: $horaMarcacao, ')
          ..write('tipoMarcacao: $tipoMarcacao, ')
          ..write('tipoRegistro: $tipoRegistro, ')
          ..write('parEntradaSaida: $parEntradaSaida, ')
          ..write('justificativa: $justificativa')
          ..write(')'))
        .toString();
  }
}

class $PontoClassificacaoJornadasTable extends PontoClassificacaoJornadas
    with
        TableInfo<$PontoClassificacaoJornadasTable, PontoClassificacaoJornada> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoClassificacaoJornadasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _padraoMeta = const VerificationMeta('padrao');
  @override
  late final GeneratedColumn<String> padrao = GeneratedColumn<String>(
      'padrao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descontarHorasMeta =
      const VerificationMeta('descontarHoras');
  @override
  late final GeneratedColumn<String> descontarHoras = GeneratedColumn<String>(
      'descontar_horas', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, codigo, nome, descricao, padrao, descontarHoras];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_classificacao_jornada';
  @override
  VerificationContext validateIntegrity(
      Insertable<PontoClassificacaoJornada> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('padrao')) {
      context.handle(_padraoMeta,
          padrao.isAcceptableOrUnknown(data['padrao']!, _padraoMeta));
    }
    if (data.containsKey('descontar_horas')) {
      context.handle(
          _descontarHorasMeta,
          descontarHoras.isAcceptableOrUnknown(
              data['descontar_horas']!, _descontarHorasMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoClassificacaoJornada map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoClassificacaoJornada(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      padrao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}padrao']),
      descontarHoras: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descontar_horas']),
    );
  }

  @override
  $PontoClassificacaoJornadasTable createAlias(String alias) {
    return $PontoClassificacaoJornadasTable(attachedDatabase, alias);
  }
}

class PontoClassificacaoJornada extends DataClass
    implements Insertable<PontoClassificacaoJornada> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  final String? padrao;
  final String? descontarHoras;
  const PontoClassificacaoJornada(
      {this.id,
      this.codigo,
      this.nome,
      this.descricao,
      this.padrao,
      this.descontarHoras});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || padrao != null) {
      map['padrao'] = Variable<String>(padrao);
    }
    if (!nullToAbsent || descontarHoras != null) {
      map['descontar_horas'] = Variable<String>(descontarHoras);
    }
    return map;
  }

  factory PontoClassificacaoJornada.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoClassificacaoJornada(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      padrao: serializer.fromJson<String?>(json['padrao']),
      descontarHoras: serializer.fromJson<String?>(json['descontarHoras']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'padrao': serializer.toJson<String?>(padrao),
      'descontarHoras': serializer.toJson<String?>(descontarHoras),
    };
  }

  PontoClassificacaoJornada copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> padrao = const Value.absent(),
          Value<String?> descontarHoras = const Value.absent()}) =>
      PontoClassificacaoJornada(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        padrao: padrao.present ? padrao.value : this.padrao,
        descontarHoras:
            descontarHoras.present ? descontarHoras.value : this.descontarHoras,
      );
  @override
  String toString() {
    return (StringBuffer('PontoClassificacaoJornada(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('padrao: $padrao, ')
          ..write('descontarHoras: $descontarHoras')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, codigo, nome, descricao, padrao, descontarHoras);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoClassificacaoJornada &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.padrao == this.padrao &&
          other.descontarHoras == this.descontarHoras);
}

class PontoClassificacaoJornadasCompanion
    extends UpdateCompanion<PontoClassificacaoJornada> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> padrao;
  final Value<String?> descontarHoras;
  const PontoClassificacaoJornadasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.padrao = const Value.absent(),
    this.descontarHoras = const Value.absent(),
  });
  PontoClassificacaoJornadasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.padrao = const Value.absent(),
    this.descontarHoras = const Value.absent(),
  });
  static Insertable<PontoClassificacaoJornada> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? padrao,
    Expression<String>? descontarHoras,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (padrao != null) 'padrao': padrao,
      if (descontarHoras != null) 'descontar_horas': descontarHoras,
    });
  }

  PontoClassificacaoJornadasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? padrao,
      Value<String?>? descontarHoras}) {
    return PontoClassificacaoJornadasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      padrao: padrao ?? this.padrao,
      descontarHoras: descontarHoras ?? this.descontarHoras,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (padrao.present) {
      map['padrao'] = Variable<String>(padrao.value);
    }
    if (descontarHoras.present) {
      map['descontar_horas'] = Variable<String>(descontarHoras.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoClassificacaoJornadasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('padrao: $padrao, ')
          ..write('descontarHoras: $descontarHoras')
          ..write(')'))
        .toString();
  }
}

class $PontoHorarioAutorizadosTable extends PontoHorarioAutorizados
    with TableInfo<$PontoHorarioAutorizadosTable, PontoHorarioAutorizado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoHorarioAutorizadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataHorarioMeta =
      const VerificationMeta('dataHorario');
  @override
  late final GeneratedColumn<DateTime> dataHorario = GeneratedColumn<DateTime>(
      'data_horario', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaMeta =
      const VerificationMeta('cargaHoraria');
  @override
  late final GeneratedColumn<String> cargaHoraria = GeneratedColumn<String>(
      'carga_horaria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada01Meta =
      const VerificationMeta('entrada01');
  @override
  late final GeneratedColumn<String> entrada01 = GeneratedColumn<String>(
      'entrada01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida01Meta =
      const VerificationMeta('saida01');
  @override
  late final GeneratedColumn<String> saida01 = GeneratedColumn<String>(
      'saida01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada02Meta =
      const VerificationMeta('entrada02');
  @override
  late final GeneratedColumn<String> entrada02 = GeneratedColumn<String>(
      'entrada02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida02Meta =
      const VerificationMeta('saida02');
  @override
  late final GeneratedColumn<String> saida02 = GeneratedColumn<String>(
      'saida02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada03Meta =
      const VerificationMeta('entrada03');
  @override
  late final GeneratedColumn<String> entrada03 = GeneratedColumn<String>(
      'entrada03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida03Meta =
      const VerificationMeta('saida03');
  @override
  late final GeneratedColumn<String> saida03 = GeneratedColumn<String>(
      'saida03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada04Meta =
      const VerificationMeta('entrada04');
  @override
  late final GeneratedColumn<String> entrada04 = GeneratedColumn<String>(
      'entrada04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida04Meta =
      const VerificationMeta('saida04');
  @override
  late final GeneratedColumn<String> saida04 = GeneratedColumn<String>(
      'saida04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada05Meta =
      const VerificationMeta('entrada05');
  @override
  late final GeneratedColumn<String> entrada05 = GeneratedColumn<String>(
      'entrada05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida05Meta =
      const VerificationMeta('saida05');
  @override
  late final GeneratedColumn<String> saida05 = GeneratedColumn<String>(
      'saida05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _horaFechamentoDiaMeta =
      const VerificationMeta('horaFechamentoDia');
  @override
  late final GeneratedColumn<String> horaFechamentoDia =
      GeneratedColumn<String>('hora_fechamento_dia', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idColaborador,
        dataHorario,
        tipo,
        cargaHoraria,
        entrada01,
        saida01,
        entrada02,
        saida02,
        entrada03,
        saida03,
        entrada04,
        saida04,
        entrada05,
        saida05,
        horaFechamentoDia
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_horario_autorizado';
  @override
  VerificationContext validateIntegrity(
      Insertable<PontoHorarioAutorizado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_horario')) {
      context.handle(
          _dataHorarioMeta,
          dataHorario.isAcceptableOrUnknown(
              data['data_horario']!, _dataHorarioMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('carga_horaria')) {
      context.handle(
          _cargaHorariaMeta,
          cargaHoraria.isAcceptableOrUnknown(
              data['carga_horaria']!, _cargaHorariaMeta));
    }
    if (data.containsKey('entrada01')) {
      context.handle(_entrada01Meta,
          entrada01.isAcceptableOrUnknown(data['entrada01']!, _entrada01Meta));
    }
    if (data.containsKey('saida01')) {
      context.handle(_saida01Meta,
          saida01.isAcceptableOrUnknown(data['saida01']!, _saida01Meta));
    }
    if (data.containsKey('entrada02')) {
      context.handle(_entrada02Meta,
          entrada02.isAcceptableOrUnknown(data['entrada02']!, _entrada02Meta));
    }
    if (data.containsKey('saida02')) {
      context.handle(_saida02Meta,
          saida02.isAcceptableOrUnknown(data['saida02']!, _saida02Meta));
    }
    if (data.containsKey('entrada03')) {
      context.handle(_entrada03Meta,
          entrada03.isAcceptableOrUnknown(data['entrada03']!, _entrada03Meta));
    }
    if (data.containsKey('saida03')) {
      context.handle(_saida03Meta,
          saida03.isAcceptableOrUnknown(data['saida03']!, _saida03Meta));
    }
    if (data.containsKey('entrada04')) {
      context.handle(_entrada04Meta,
          entrada04.isAcceptableOrUnknown(data['entrada04']!, _entrada04Meta));
    }
    if (data.containsKey('saida04')) {
      context.handle(_saida04Meta,
          saida04.isAcceptableOrUnknown(data['saida04']!, _saida04Meta));
    }
    if (data.containsKey('entrada05')) {
      context.handle(_entrada05Meta,
          entrada05.isAcceptableOrUnknown(data['entrada05']!, _entrada05Meta));
    }
    if (data.containsKey('saida05')) {
      context.handle(_saida05Meta,
          saida05.isAcceptableOrUnknown(data['saida05']!, _saida05Meta));
    }
    if (data.containsKey('hora_fechamento_dia')) {
      context.handle(
          _horaFechamentoDiaMeta,
          horaFechamentoDia.isAcceptableOrUnknown(
              data['hora_fechamento_dia']!, _horaFechamentoDiaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoHorarioAutorizado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoHorarioAutorizado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataHorario: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_horario']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      cargaHoraria: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}carga_horaria']),
      entrada01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada01']),
      saida01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida01']),
      entrada02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada02']),
      saida02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida02']),
      entrada03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada03']),
      saida03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida03']),
      entrada04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada04']),
      saida04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida04']),
      entrada05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada05']),
      saida05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida05']),
      horaFechamentoDia: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_fechamento_dia']),
    );
  }

  @override
  $PontoHorarioAutorizadosTable createAlias(String alias) {
    return $PontoHorarioAutorizadosTable(attachedDatabase, alias);
  }
}

class PontoHorarioAutorizado extends DataClass
    implements Insertable<PontoHorarioAutorizado> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataHorario;
  final String? tipo;
  final String? cargaHoraria;
  final String? entrada01;
  final String? saida01;
  final String? entrada02;
  final String? saida02;
  final String? entrada03;
  final String? saida03;
  final String? entrada04;
  final String? saida04;
  final String? entrada05;
  final String? saida05;
  final String? horaFechamentoDia;
  const PontoHorarioAutorizado(
      {this.id,
      this.idColaborador,
      this.dataHorario,
      this.tipo,
      this.cargaHoraria,
      this.entrada01,
      this.saida01,
      this.entrada02,
      this.saida02,
      this.entrada03,
      this.saida03,
      this.entrada04,
      this.saida04,
      this.entrada05,
      this.saida05,
      this.horaFechamentoDia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataHorario != null) {
      map['data_horario'] = Variable<DateTime>(dataHorario);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || cargaHoraria != null) {
      map['carga_horaria'] = Variable<String>(cargaHoraria);
    }
    if (!nullToAbsent || entrada01 != null) {
      map['entrada01'] = Variable<String>(entrada01);
    }
    if (!nullToAbsent || saida01 != null) {
      map['saida01'] = Variable<String>(saida01);
    }
    if (!nullToAbsent || entrada02 != null) {
      map['entrada02'] = Variable<String>(entrada02);
    }
    if (!nullToAbsent || saida02 != null) {
      map['saida02'] = Variable<String>(saida02);
    }
    if (!nullToAbsent || entrada03 != null) {
      map['entrada03'] = Variable<String>(entrada03);
    }
    if (!nullToAbsent || saida03 != null) {
      map['saida03'] = Variable<String>(saida03);
    }
    if (!nullToAbsent || entrada04 != null) {
      map['entrada04'] = Variable<String>(entrada04);
    }
    if (!nullToAbsent || saida04 != null) {
      map['saida04'] = Variable<String>(saida04);
    }
    if (!nullToAbsent || entrada05 != null) {
      map['entrada05'] = Variable<String>(entrada05);
    }
    if (!nullToAbsent || saida05 != null) {
      map['saida05'] = Variable<String>(saida05);
    }
    if (!nullToAbsent || horaFechamentoDia != null) {
      map['hora_fechamento_dia'] = Variable<String>(horaFechamentoDia);
    }
    return map;
  }

  factory PontoHorarioAutorizado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoHorarioAutorizado(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataHorario: serializer.fromJson<DateTime?>(json['dataHorario']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      cargaHoraria: serializer.fromJson<String?>(json['cargaHoraria']),
      entrada01: serializer.fromJson<String?>(json['entrada01']),
      saida01: serializer.fromJson<String?>(json['saida01']),
      entrada02: serializer.fromJson<String?>(json['entrada02']),
      saida02: serializer.fromJson<String?>(json['saida02']),
      entrada03: serializer.fromJson<String?>(json['entrada03']),
      saida03: serializer.fromJson<String?>(json['saida03']),
      entrada04: serializer.fromJson<String?>(json['entrada04']),
      saida04: serializer.fromJson<String?>(json['saida04']),
      entrada05: serializer.fromJson<String?>(json['entrada05']),
      saida05: serializer.fromJson<String?>(json['saida05']),
      horaFechamentoDia:
          serializer.fromJson<String?>(json['horaFechamentoDia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataHorario': serializer.toJson<DateTime?>(dataHorario),
      'tipo': serializer.toJson<String?>(tipo),
      'cargaHoraria': serializer.toJson<String?>(cargaHoraria),
      'entrada01': serializer.toJson<String?>(entrada01),
      'saida01': serializer.toJson<String?>(saida01),
      'entrada02': serializer.toJson<String?>(entrada02),
      'saida02': serializer.toJson<String?>(saida02),
      'entrada03': serializer.toJson<String?>(entrada03),
      'saida03': serializer.toJson<String?>(saida03),
      'entrada04': serializer.toJson<String?>(entrada04),
      'saida04': serializer.toJson<String?>(saida04),
      'entrada05': serializer.toJson<String?>(entrada05),
      'saida05': serializer.toJson<String?>(saida05),
      'horaFechamentoDia': serializer.toJson<String?>(horaFechamentoDia),
    };
  }

  PontoHorarioAutorizado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataHorario = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> cargaHoraria = const Value.absent(),
          Value<String?> entrada01 = const Value.absent(),
          Value<String?> saida01 = const Value.absent(),
          Value<String?> entrada02 = const Value.absent(),
          Value<String?> saida02 = const Value.absent(),
          Value<String?> entrada03 = const Value.absent(),
          Value<String?> saida03 = const Value.absent(),
          Value<String?> entrada04 = const Value.absent(),
          Value<String?> saida04 = const Value.absent(),
          Value<String?> entrada05 = const Value.absent(),
          Value<String?> saida05 = const Value.absent(),
          Value<String?> horaFechamentoDia = const Value.absent()}) =>
      PontoHorarioAutorizado(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataHorario: dataHorario.present ? dataHorario.value : this.dataHorario,
        tipo: tipo.present ? tipo.value : this.tipo,
        cargaHoraria:
            cargaHoraria.present ? cargaHoraria.value : this.cargaHoraria,
        entrada01: entrada01.present ? entrada01.value : this.entrada01,
        saida01: saida01.present ? saida01.value : this.saida01,
        entrada02: entrada02.present ? entrada02.value : this.entrada02,
        saida02: saida02.present ? saida02.value : this.saida02,
        entrada03: entrada03.present ? entrada03.value : this.entrada03,
        saida03: saida03.present ? saida03.value : this.saida03,
        entrada04: entrada04.present ? entrada04.value : this.entrada04,
        saida04: saida04.present ? saida04.value : this.saida04,
        entrada05: entrada05.present ? entrada05.value : this.entrada05,
        saida05: saida05.present ? saida05.value : this.saida05,
        horaFechamentoDia: horaFechamentoDia.present
            ? horaFechamentoDia.value
            : this.horaFechamentoDia,
      );
  @override
  String toString() {
    return (StringBuffer('PontoHorarioAutorizado(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataHorario: $dataHorario, ')
          ..write('tipo: $tipo, ')
          ..write('cargaHoraria: $cargaHoraria, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaFechamentoDia: $horaFechamentoDia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idColaborador,
      dataHorario,
      tipo,
      cargaHoraria,
      entrada01,
      saida01,
      entrada02,
      saida02,
      entrada03,
      saida03,
      entrada04,
      saida04,
      entrada05,
      saida05,
      horaFechamentoDia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoHorarioAutorizado &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataHorario == this.dataHorario &&
          other.tipo == this.tipo &&
          other.cargaHoraria == this.cargaHoraria &&
          other.entrada01 == this.entrada01 &&
          other.saida01 == this.saida01 &&
          other.entrada02 == this.entrada02 &&
          other.saida02 == this.saida02 &&
          other.entrada03 == this.entrada03 &&
          other.saida03 == this.saida03 &&
          other.entrada04 == this.entrada04 &&
          other.saida04 == this.saida04 &&
          other.entrada05 == this.entrada05 &&
          other.saida05 == this.saida05 &&
          other.horaFechamentoDia == this.horaFechamentoDia);
}

class PontoHorarioAutorizadosCompanion
    extends UpdateCompanion<PontoHorarioAutorizado> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataHorario;
  final Value<String?> tipo;
  final Value<String?> cargaHoraria;
  final Value<String?> entrada01;
  final Value<String?> saida01;
  final Value<String?> entrada02;
  final Value<String?> saida02;
  final Value<String?> entrada03;
  final Value<String?> saida03;
  final Value<String?> entrada04;
  final Value<String?> saida04;
  final Value<String?> entrada05;
  final Value<String?> saida05;
  final Value<String?> horaFechamentoDia;
  const PontoHorarioAutorizadosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataHorario = const Value.absent(),
    this.tipo = const Value.absent(),
    this.cargaHoraria = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaFechamentoDia = const Value.absent(),
  });
  PontoHorarioAutorizadosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataHorario = const Value.absent(),
    this.tipo = const Value.absent(),
    this.cargaHoraria = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaFechamentoDia = const Value.absent(),
  });
  static Insertable<PontoHorarioAutorizado> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataHorario,
    Expression<String>? tipo,
    Expression<String>? cargaHoraria,
    Expression<String>? entrada01,
    Expression<String>? saida01,
    Expression<String>? entrada02,
    Expression<String>? saida02,
    Expression<String>? entrada03,
    Expression<String>? saida03,
    Expression<String>? entrada04,
    Expression<String>? saida04,
    Expression<String>? entrada05,
    Expression<String>? saida05,
    Expression<String>? horaFechamentoDia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataHorario != null) 'data_horario': dataHorario,
      if (tipo != null) 'tipo': tipo,
      if (cargaHoraria != null) 'carga_horaria': cargaHoraria,
      if (entrada01 != null) 'entrada01': entrada01,
      if (saida01 != null) 'saida01': saida01,
      if (entrada02 != null) 'entrada02': entrada02,
      if (saida02 != null) 'saida02': saida02,
      if (entrada03 != null) 'entrada03': entrada03,
      if (saida03 != null) 'saida03': saida03,
      if (entrada04 != null) 'entrada04': entrada04,
      if (saida04 != null) 'saida04': saida04,
      if (entrada05 != null) 'entrada05': entrada05,
      if (saida05 != null) 'saida05': saida05,
      if (horaFechamentoDia != null) 'hora_fechamento_dia': horaFechamentoDia,
    });
  }

  PontoHorarioAutorizadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataHorario,
      Value<String?>? tipo,
      Value<String?>? cargaHoraria,
      Value<String?>? entrada01,
      Value<String?>? saida01,
      Value<String?>? entrada02,
      Value<String?>? saida02,
      Value<String?>? entrada03,
      Value<String?>? saida03,
      Value<String?>? entrada04,
      Value<String?>? saida04,
      Value<String?>? entrada05,
      Value<String?>? saida05,
      Value<String?>? horaFechamentoDia}) {
    return PontoHorarioAutorizadosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataHorario: dataHorario ?? this.dataHorario,
      tipo: tipo ?? this.tipo,
      cargaHoraria: cargaHoraria ?? this.cargaHoraria,
      entrada01: entrada01 ?? this.entrada01,
      saida01: saida01 ?? this.saida01,
      entrada02: entrada02 ?? this.entrada02,
      saida02: saida02 ?? this.saida02,
      entrada03: entrada03 ?? this.entrada03,
      saida03: saida03 ?? this.saida03,
      entrada04: entrada04 ?? this.entrada04,
      saida04: saida04 ?? this.saida04,
      entrada05: entrada05 ?? this.entrada05,
      saida05: saida05 ?? this.saida05,
      horaFechamentoDia: horaFechamentoDia ?? this.horaFechamentoDia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataHorario.present) {
      map['data_horario'] = Variable<DateTime>(dataHorario.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (cargaHoraria.present) {
      map['carga_horaria'] = Variable<String>(cargaHoraria.value);
    }
    if (entrada01.present) {
      map['entrada01'] = Variable<String>(entrada01.value);
    }
    if (saida01.present) {
      map['saida01'] = Variable<String>(saida01.value);
    }
    if (entrada02.present) {
      map['entrada02'] = Variable<String>(entrada02.value);
    }
    if (saida02.present) {
      map['saida02'] = Variable<String>(saida02.value);
    }
    if (entrada03.present) {
      map['entrada03'] = Variable<String>(entrada03.value);
    }
    if (saida03.present) {
      map['saida03'] = Variable<String>(saida03.value);
    }
    if (entrada04.present) {
      map['entrada04'] = Variable<String>(entrada04.value);
    }
    if (saida04.present) {
      map['saida04'] = Variable<String>(saida04.value);
    }
    if (entrada05.present) {
      map['entrada05'] = Variable<String>(entrada05.value);
    }
    if (saida05.present) {
      map['saida05'] = Variable<String>(saida05.value);
    }
    if (horaFechamentoDia.present) {
      map['hora_fechamento_dia'] = Variable<String>(horaFechamentoDia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoHorarioAutorizadosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataHorario: $dataHorario, ')
          ..write('tipo: $tipo, ')
          ..write('cargaHoraria: $cargaHoraria, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaFechamentoDia: $horaFechamentoDia')
          ..write(')'))
        .toString();
  }
}

class $PontoFechamentoJornadasTable extends PontoFechamentoJornadas
    with TableInfo<$PontoFechamentoJornadasTable, PontoFechamentoJornada> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PontoFechamentoJornadasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPontoClassificacaoJornadaMeta =
      const VerificationMeta('idPontoClassificacaoJornada');
  @override
  late final GeneratedColumn<int> idPontoClassificacaoJornada =
      GeneratedColumn<int>('id_ponto_classificacao_jornada', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataFechamentoMeta =
      const VerificationMeta('dataFechamento');
  @override
  late final GeneratedColumn<DateTime> dataFechamento =
      GeneratedColumn<DateTime>('data_fechamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diaSemanaMeta =
      const VerificationMeta('diaSemana');
  @override
  late final GeneratedColumn<String> diaSemana = GeneratedColumn<String>(
      'dia_semana', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoHorarioMeta =
      const VerificationMeta('codigoHorario');
  @override
  late final GeneratedColumn<String> codigoHorario = GeneratedColumn<String>(
      'codigo_horario', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaEsperadaMeta =
      const VerificationMeta('cargaHorariaEsperada');
  @override
  late final GeneratedColumn<String> cargaHorariaEsperada =
      GeneratedColumn<String>(
          'carga_horaria_esperada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaDiurnaMeta =
      const VerificationMeta('cargaHorariaDiurna');
  @override
  late final GeneratedColumn<String> cargaHorariaDiurna =
      GeneratedColumn<String>('carga_horaria_diurna', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaNoturnaMeta =
      const VerificationMeta('cargaHorariaNoturna');
  @override
  late final GeneratedColumn<String> cargaHorariaNoturna =
      GeneratedColumn<String>('carga_horaria_noturna', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cargaHorariaTotalMeta =
      const VerificationMeta('cargaHorariaTotal');
  @override
  late final GeneratedColumn<String> cargaHorariaTotal =
      GeneratedColumn<String>('carga_horaria_total', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _entrada01Meta =
      const VerificationMeta('entrada01');
  @override
  late final GeneratedColumn<String> entrada01 = GeneratedColumn<String>(
      'entrada01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida01Meta =
      const VerificationMeta('saida01');
  @override
  late final GeneratedColumn<String> saida01 = GeneratedColumn<String>(
      'saida01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada02Meta =
      const VerificationMeta('entrada02');
  @override
  late final GeneratedColumn<String> entrada02 = GeneratedColumn<String>(
      'entrada02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida02Meta =
      const VerificationMeta('saida02');
  @override
  late final GeneratedColumn<String> saida02 = GeneratedColumn<String>(
      'saida02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada03Meta =
      const VerificationMeta('entrada03');
  @override
  late final GeneratedColumn<String> entrada03 = GeneratedColumn<String>(
      'entrada03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida03Meta =
      const VerificationMeta('saida03');
  @override
  late final GeneratedColumn<String> saida03 = GeneratedColumn<String>(
      'saida03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada04Meta =
      const VerificationMeta('entrada04');
  @override
  late final GeneratedColumn<String> entrada04 = GeneratedColumn<String>(
      'entrada04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida04Meta =
      const VerificationMeta('saida04');
  @override
  late final GeneratedColumn<String> saida04 = GeneratedColumn<String>(
      'saida04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entrada05Meta =
      const VerificationMeta('entrada05');
  @override
  late final GeneratedColumn<String> entrada05 = GeneratedColumn<String>(
      'entrada05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _saida05Meta =
      const VerificationMeta('saida05');
  @override
  late final GeneratedColumn<String> saida05 = GeneratedColumn<String>(
      'saida05', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _horaInicioJornadaMeta =
      const VerificationMeta('horaInicioJornada');
  @override
  late final GeneratedColumn<String> horaInicioJornada =
      GeneratedColumn<String>('hora_inicio_jornada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaFimJornadaMeta =
      const VerificationMeta('horaFimJornada');
  @override
  late final GeneratedColumn<String> horaFimJornada = GeneratedColumn<String>(
      'hora_fim_jornada', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _horaExtra01Meta =
      const VerificationMeta('horaExtra01');
  @override
  late final GeneratedColumn<String> horaExtra01 = GeneratedColumn<String>(
      'hora_extra01', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _percentualHoraExtra01Meta =
      const VerificationMeta('percentualHoraExtra01');
  @override
  late final GeneratedColumn<double> percentualHoraExtra01 =
      GeneratedColumn<double>('percentual_hora_extra01', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeHoraExtra01Meta =
      const VerificationMeta('modalidadeHoraExtra01');
  @override
  late final GeneratedColumn<String> modalidadeHoraExtra01 =
      GeneratedColumn<String>('modalidade_hora_extra01', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaExtra02Meta =
      const VerificationMeta('horaExtra02');
  @override
  late final GeneratedColumn<String> horaExtra02 = GeneratedColumn<String>(
      'hora_extra02', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _percentualHoraExtra02Meta =
      const VerificationMeta('percentualHoraExtra02');
  @override
  late final GeneratedColumn<double> percentualHoraExtra02 =
      GeneratedColumn<double>('percentual_hora_extra02', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeHoraExtra02Meta =
      const VerificationMeta('modalidadeHoraExtra02');
  @override
  late final GeneratedColumn<String> modalidadeHoraExtra02 =
      GeneratedColumn<String>('modalidade_hora_extra02', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaExtra03Meta =
      const VerificationMeta('horaExtra03');
  @override
  late final GeneratedColumn<String> horaExtra03 = GeneratedColumn<String>(
      'hora_extra03', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _percentualHoraExtra03Meta =
      const VerificationMeta('percentualHoraExtra03');
  @override
  late final GeneratedColumn<double> percentualHoraExtra03 =
      GeneratedColumn<double>('percentual_hora_extra03', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeHoraExtra03Meta =
      const VerificationMeta('modalidadeHoraExtra03');
  @override
  late final GeneratedColumn<String> modalidadeHoraExtra03 =
      GeneratedColumn<String>('modalidade_hora_extra03', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _horaExtra04Meta =
      const VerificationMeta('horaExtra04');
  @override
  late final GeneratedColumn<String> horaExtra04 = GeneratedColumn<String>(
      'hora_extra04', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _percentualHoraExtra04Meta =
      const VerificationMeta('percentualHoraExtra04');
  @override
  late final GeneratedColumn<double> percentualHoraExtra04 =
      GeneratedColumn<double>('percentual_hora_extra04', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeHoraExtra04Meta =
      const VerificationMeta('modalidadeHoraExtra04');
  @override
  late final GeneratedColumn<String> modalidadeHoraExtra04 =
      GeneratedColumn<String>('modalidade_hora_extra04', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _faltaAtrasoMeta =
      const VerificationMeta('faltaAtraso');
  @override
  late final GeneratedColumn<String> faltaAtraso = GeneratedColumn<String>(
      'falta_atraso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _compensarMeta =
      const VerificationMeta('compensar');
  @override
  late final GeneratedColumn<String> compensar = GeneratedColumn<String>(
      'compensar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bancoHorasMeta =
      const VerificationMeta('bancoHoras');
  @override
  late final GeneratedColumn<String> bancoHoras = GeneratedColumn<String>(
      'banco_horas', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPontoClassificacaoJornada,
        idColaborador,
        dataFechamento,
        diaSemana,
        codigoHorario,
        cargaHorariaEsperada,
        cargaHorariaDiurna,
        cargaHorariaNoturna,
        cargaHorariaTotal,
        entrada01,
        saida01,
        entrada02,
        saida02,
        entrada03,
        saida03,
        entrada04,
        saida04,
        entrada05,
        saida05,
        horaInicioJornada,
        horaFimJornada,
        horaExtra01,
        percentualHoraExtra01,
        modalidadeHoraExtra01,
        horaExtra02,
        percentualHoraExtra02,
        modalidadeHoraExtra02,
        horaExtra03,
        percentualHoraExtra03,
        modalidadeHoraExtra03,
        horaExtra04,
        percentualHoraExtra04,
        modalidadeHoraExtra04,
        faltaAtraso,
        compensar,
        bancoHoras,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ponto_fechamento_jornada';
  @override
  VerificationContext validateIntegrity(
      Insertable<PontoFechamentoJornada> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ponto_classificacao_jornada')) {
      context.handle(
          _idPontoClassificacaoJornadaMeta,
          idPontoClassificacaoJornada.isAcceptableOrUnknown(
              data['id_ponto_classificacao_jornada']!,
              _idPontoClassificacaoJornadaMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_fechamento')) {
      context.handle(
          _dataFechamentoMeta,
          dataFechamento.isAcceptableOrUnknown(
              data['data_fechamento']!, _dataFechamentoMeta));
    }
    if (data.containsKey('dia_semana')) {
      context.handle(_diaSemanaMeta,
          diaSemana.isAcceptableOrUnknown(data['dia_semana']!, _diaSemanaMeta));
    }
    if (data.containsKey('codigo_horario')) {
      context.handle(
          _codigoHorarioMeta,
          codigoHorario.isAcceptableOrUnknown(
              data['codigo_horario']!, _codigoHorarioMeta));
    }
    if (data.containsKey('carga_horaria_esperada')) {
      context.handle(
          _cargaHorariaEsperadaMeta,
          cargaHorariaEsperada.isAcceptableOrUnknown(
              data['carga_horaria_esperada']!, _cargaHorariaEsperadaMeta));
    }
    if (data.containsKey('carga_horaria_diurna')) {
      context.handle(
          _cargaHorariaDiurnaMeta,
          cargaHorariaDiurna.isAcceptableOrUnknown(
              data['carga_horaria_diurna']!, _cargaHorariaDiurnaMeta));
    }
    if (data.containsKey('carga_horaria_noturna')) {
      context.handle(
          _cargaHorariaNoturnaMeta,
          cargaHorariaNoturna.isAcceptableOrUnknown(
              data['carga_horaria_noturna']!, _cargaHorariaNoturnaMeta));
    }
    if (data.containsKey('carga_horaria_total')) {
      context.handle(
          _cargaHorariaTotalMeta,
          cargaHorariaTotal.isAcceptableOrUnknown(
              data['carga_horaria_total']!, _cargaHorariaTotalMeta));
    }
    if (data.containsKey('entrada01')) {
      context.handle(_entrada01Meta,
          entrada01.isAcceptableOrUnknown(data['entrada01']!, _entrada01Meta));
    }
    if (data.containsKey('saida01')) {
      context.handle(_saida01Meta,
          saida01.isAcceptableOrUnknown(data['saida01']!, _saida01Meta));
    }
    if (data.containsKey('entrada02')) {
      context.handle(_entrada02Meta,
          entrada02.isAcceptableOrUnknown(data['entrada02']!, _entrada02Meta));
    }
    if (data.containsKey('saida02')) {
      context.handle(_saida02Meta,
          saida02.isAcceptableOrUnknown(data['saida02']!, _saida02Meta));
    }
    if (data.containsKey('entrada03')) {
      context.handle(_entrada03Meta,
          entrada03.isAcceptableOrUnknown(data['entrada03']!, _entrada03Meta));
    }
    if (data.containsKey('saida03')) {
      context.handle(_saida03Meta,
          saida03.isAcceptableOrUnknown(data['saida03']!, _saida03Meta));
    }
    if (data.containsKey('entrada04')) {
      context.handle(_entrada04Meta,
          entrada04.isAcceptableOrUnknown(data['entrada04']!, _entrada04Meta));
    }
    if (data.containsKey('saida04')) {
      context.handle(_saida04Meta,
          saida04.isAcceptableOrUnknown(data['saida04']!, _saida04Meta));
    }
    if (data.containsKey('entrada05')) {
      context.handle(_entrada05Meta,
          entrada05.isAcceptableOrUnknown(data['entrada05']!, _entrada05Meta));
    }
    if (data.containsKey('saida05')) {
      context.handle(_saida05Meta,
          saida05.isAcceptableOrUnknown(data['saida05']!, _saida05Meta));
    }
    if (data.containsKey('hora_inicio_jornada')) {
      context.handle(
          _horaInicioJornadaMeta,
          horaInicioJornada.isAcceptableOrUnknown(
              data['hora_inicio_jornada']!, _horaInicioJornadaMeta));
    }
    if (data.containsKey('hora_fim_jornada')) {
      context.handle(
          _horaFimJornadaMeta,
          horaFimJornada.isAcceptableOrUnknown(
              data['hora_fim_jornada']!, _horaFimJornadaMeta));
    }
    if (data.containsKey('hora_extra01')) {
      context.handle(
          _horaExtra01Meta,
          horaExtra01.isAcceptableOrUnknown(
              data['hora_extra01']!, _horaExtra01Meta));
    }
    if (data.containsKey('percentual_hora_extra01')) {
      context.handle(
          _percentualHoraExtra01Meta,
          percentualHoraExtra01.isAcceptableOrUnknown(
              data['percentual_hora_extra01']!, _percentualHoraExtra01Meta));
    }
    if (data.containsKey('modalidade_hora_extra01')) {
      context.handle(
          _modalidadeHoraExtra01Meta,
          modalidadeHoraExtra01.isAcceptableOrUnknown(
              data['modalidade_hora_extra01']!, _modalidadeHoraExtra01Meta));
    }
    if (data.containsKey('hora_extra02')) {
      context.handle(
          _horaExtra02Meta,
          horaExtra02.isAcceptableOrUnknown(
              data['hora_extra02']!, _horaExtra02Meta));
    }
    if (data.containsKey('percentual_hora_extra02')) {
      context.handle(
          _percentualHoraExtra02Meta,
          percentualHoraExtra02.isAcceptableOrUnknown(
              data['percentual_hora_extra02']!, _percentualHoraExtra02Meta));
    }
    if (data.containsKey('modalidade_hora_extra02')) {
      context.handle(
          _modalidadeHoraExtra02Meta,
          modalidadeHoraExtra02.isAcceptableOrUnknown(
              data['modalidade_hora_extra02']!, _modalidadeHoraExtra02Meta));
    }
    if (data.containsKey('hora_extra03')) {
      context.handle(
          _horaExtra03Meta,
          horaExtra03.isAcceptableOrUnknown(
              data['hora_extra03']!, _horaExtra03Meta));
    }
    if (data.containsKey('percentual_hora_extra03')) {
      context.handle(
          _percentualHoraExtra03Meta,
          percentualHoraExtra03.isAcceptableOrUnknown(
              data['percentual_hora_extra03']!, _percentualHoraExtra03Meta));
    }
    if (data.containsKey('modalidade_hora_extra03')) {
      context.handle(
          _modalidadeHoraExtra03Meta,
          modalidadeHoraExtra03.isAcceptableOrUnknown(
              data['modalidade_hora_extra03']!, _modalidadeHoraExtra03Meta));
    }
    if (data.containsKey('hora_extra04')) {
      context.handle(
          _horaExtra04Meta,
          horaExtra04.isAcceptableOrUnknown(
              data['hora_extra04']!, _horaExtra04Meta));
    }
    if (data.containsKey('percentual_hora_extra04')) {
      context.handle(
          _percentualHoraExtra04Meta,
          percentualHoraExtra04.isAcceptableOrUnknown(
              data['percentual_hora_extra04']!, _percentualHoraExtra04Meta));
    }
    if (data.containsKey('modalidade_hora_extra04')) {
      context.handle(
          _modalidadeHoraExtra04Meta,
          modalidadeHoraExtra04.isAcceptableOrUnknown(
              data['modalidade_hora_extra04']!, _modalidadeHoraExtra04Meta));
    }
    if (data.containsKey('falta_atraso')) {
      context.handle(
          _faltaAtrasoMeta,
          faltaAtraso.isAcceptableOrUnknown(
              data['falta_atraso']!, _faltaAtrasoMeta));
    }
    if (data.containsKey('compensar')) {
      context.handle(_compensarMeta,
          compensar.isAcceptableOrUnknown(data['compensar']!, _compensarMeta));
    }
    if (data.containsKey('banco_horas')) {
      context.handle(
          _bancoHorasMeta,
          bancoHoras.isAcceptableOrUnknown(
              data['banco_horas']!, _bancoHorasMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PontoFechamentoJornada map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PontoFechamentoJornada(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPontoClassificacaoJornada: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_ponto_classificacao_jornada']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataFechamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_fechamento']),
      diaSemana: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}dia_semana']),
      codigoHorario: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_horario']),
      cargaHorariaEsperada: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}carga_horaria_esperada']),
      cargaHorariaDiurna: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}carga_horaria_diurna']),
      cargaHorariaNoturna: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}carga_horaria_noturna']),
      cargaHorariaTotal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}carga_horaria_total']),
      entrada01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada01']),
      saida01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida01']),
      entrada02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada02']),
      saida02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida02']),
      entrada03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada03']),
      saida03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida03']),
      entrada04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada04']),
      saida04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida04']),
      entrada05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entrada05']),
      saida05: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}saida05']),
      horaInicioJornada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_inicio_jornada']),
      horaFimJornada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_fim_jornada']),
      horaExtra01: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_extra01']),
      percentualHoraExtra01: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_hora_extra01']),
      modalidadeHoraExtra01: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_hora_extra01']),
      horaExtra02: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_extra02']),
      percentualHoraExtra02: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_hora_extra02']),
      modalidadeHoraExtra02: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_hora_extra02']),
      horaExtra03: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_extra03']),
      percentualHoraExtra03: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_hora_extra03']),
      modalidadeHoraExtra03: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_hora_extra03']),
      horaExtra04: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_extra04']),
      percentualHoraExtra04: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_hora_extra04']),
      modalidadeHoraExtra04: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_hora_extra04']),
      faltaAtraso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}falta_atraso']),
      compensar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}compensar']),
      bancoHoras: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}banco_horas']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $PontoFechamentoJornadasTable createAlias(String alias) {
    return $PontoFechamentoJornadasTable(attachedDatabase, alias);
  }
}

class PontoFechamentoJornada extends DataClass
    implements Insertable<PontoFechamentoJornada> {
  final int? id;
  final int? idPontoClassificacaoJornada;
  final int? idColaborador;
  final DateTime? dataFechamento;
  final String? diaSemana;
  final String? codigoHorario;
  final String? cargaHorariaEsperada;
  final String? cargaHorariaDiurna;
  final String? cargaHorariaNoturna;
  final String? cargaHorariaTotal;
  final String? entrada01;
  final String? saida01;
  final String? entrada02;
  final String? saida02;
  final String? entrada03;
  final String? saida03;
  final String? entrada04;
  final String? saida04;
  final String? entrada05;
  final String? saida05;
  final String? horaInicioJornada;
  final String? horaFimJornada;
  final String? horaExtra01;
  final double? percentualHoraExtra01;
  final String? modalidadeHoraExtra01;
  final String? horaExtra02;
  final double? percentualHoraExtra02;
  final String? modalidadeHoraExtra02;
  final String? horaExtra03;
  final double? percentualHoraExtra03;
  final String? modalidadeHoraExtra03;
  final String? horaExtra04;
  final double? percentualHoraExtra04;
  final String? modalidadeHoraExtra04;
  final String? faltaAtraso;
  final String? compensar;
  final String? bancoHoras;
  final String? observacao;
  const PontoFechamentoJornada(
      {this.id,
      this.idPontoClassificacaoJornada,
      this.idColaborador,
      this.dataFechamento,
      this.diaSemana,
      this.codigoHorario,
      this.cargaHorariaEsperada,
      this.cargaHorariaDiurna,
      this.cargaHorariaNoturna,
      this.cargaHorariaTotal,
      this.entrada01,
      this.saida01,
      this.entrada02,
      this.saida02,
      this.entrada03,
      this.saida03,
      this.entrada04,
      this.saida04,
      this.entrada05,
      this.saida05,
      this.horaInicioJornada,
      this.horaFimJornada,
      this.horaExtra01,
      this.percentualHoraExtra01,
      this.modalidadeHoraExtra01,
      this.horaExtra02,
      this.percentualHoraExtra02,
      this.modalidadeHoraExtra02,
      this.horaExtra03,
      this.percentualHoraExtra03,
      this.modalidadeHoraExtra03,
      this.horaExtra04,
      this.percentualHoraExtra04,
      this.modalidadeHoraExtra04,
      this.faltaAtraso,
      this.compensar,
      this.bancoHoras,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPontoClassificacaoJornada != null) {
      map['id_ponto_classificacao_jornada'] =
          Variable<int>(idPontoClassificacaoJornada);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataFechamento != null) {
      map['data_fechamento'] = Variable<DateTime>(dataFechamento);
    }
    if (!nullToAbsent || diaSemana != null) {
      map['dia_semana'] = Variable<String>(diaSemana);
    }
    if (!nullToAbsent || codigoHorario != null) {
      map['codigo_horario'] = Variable<String>(codigoHorario);
    }
    if (!nullToAbsent || cargaHorariaEsperada != null) {
      map['carga_horaria_esperada'] = Variable<String>(cargaHorariaEsperada);
    }
    if (!nullToAbsent || cargaHorariaDiurna != null) {
      map['carga_horaria_diurna'] = Variable<String>(cargaHorariaDiurna);
    }
    if (!nullToAbsent || cargaHorariaNoturna != null) {
      map['carga_horaria_noturna'] = Variable<String>(cargaHorariaNoturna);
    }
    if (!nullToAbsent || cargaHorariaTotal != null) {
      map['carga_horaria_total'] = Variable<String>(cargaHorariaTotal);
    }
    if (!nullToAbsent || entrada01 != null) {
      map['entrada01'] = Variable<String>(entrada01);
    }
    if (!nullToAbsent || saida01 != null) {
      map['saida01'] = Variable<String>(saida01);
    }
    if (!nullToAbsent || entrada02 != null) {
      map['entrada02'] = Variable<String>(entrada02);
    }
    if (!nullToAbsent || saida02 != null) {
      map['saida02'] = Variable<String>(saida02);
    }
    if (!nullToAbsent || entrada03 != null) {
      map['entrada03'] = Variable<String>(entrada03);
    }
    if (!nullToAbsent || saida03 != null) {
      map['saida03'] = Variable<String>(saida03);
    }
    if (!nullToAbsent || entrada04 != null) {
      map['entrada04'] = Variable<String>(entrada04);
    }
    if (!nullToAbsent || saida04 != null) {
      map['saida04'] = Variable<String>(saida04);
    }
    if (!nullToAbsent || entrada05 != null) {
      map['entrada05'] = Variable<String>(entrada05);
    }
    if (!nullToAbsent || saida05 != null) {
      map['saida05'] = Variable<String>(saida05);
    }
    if (!nullToAbsent || horaInicioJornada != null) {
      map['hora_inicio_jornada'] = Variable<String>(horaInicioJornada);
    }
    if (!nullToAbsent || horaFimJornada != null) {
      map['hora_fim_jornada'] = Variable<String>(horaFimJornada);
    }
    if (!nullToAbsent || horaExtra01 != null) {
      map['hora_extra01'] = Variable<String>(horaExtra01);
    }
    if (!nullToAbsent || percentualHoraExtra01 != null) {
      map['percentual_hora_extra01'] = Variable<double>(percentualHoraExtra01);
    }
    if (!nullToAbsent || modalidadeHoraExtra01 != null) {
      map['modalidade_hora_extra01'] = Variable<String>(modalidadeHoraExtra01);
    }
    if (!nullToAbsent || horaExtra02 != null) {
      map['hora_extra02'] = Variable<String>(horaExtra02);
    }
    if (!nullToAbsent || percentualHoraExtra02 != null) {
      map['percentual_hora_extra02'] = Variable<double>(percentualHoraExtra02);
    }
    if (!nullToAbsent || modalidadeHoraExtra02 != null) {
      map['modalidade_hora_extra02'] = Variable<String>(modalidadeHoraExtra02);
    }
    if (!nullToAbsent || horaExtra03 != null) {
      map['hora_extra03'] = Variable<String>(horaExtra03);
    }
    if (!nullToAbsent || percentualHoraExtra03 != null) {
      map['percentual_hora_extra03'] = Variable<double>(percentualHoraExtra03);
    }
    if (!nullToAbsent || modalidadeHoraExtra03 != null) {
      map['modalidade_hora_extra03'] = Variable<String>(modalidadeHoraExtra03);
    }
    if (!nullToAbsent || horaExtra04 != null) {
      map['hora_extra04'] = Variable<String>(horaExtra04);
    }
    if (!nullToAbsent || percentualHoraExtra04 != null) {
      map['percentual_hora_extra04'] = Variable<double>(percentualHoraExtra04);
    }
    if (!nullToAbsent || modalidadeHoraExtra04 != null) {
      map['modalidade_hora_extra04'] = Variable<String>(modalidadeHoraExtra04);
    }
    if (!nullToAbsent || faltaAtraso != null) {
      map['falta_atraso'] = Variable<String>(faltaAtraso);
    }
    if (!nullToAbsent || compensar != null) {
      map['compensar'] = Variable<String>(compensar);
    }
    if (!nullToAbsent || bancoHoras != null) {
      map['banco_horas'] = Variable<String>(bancoHoras);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory PontoFechamentoJornada.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PontoFechamentoJornada(
      id: serializer.fromJson<int?>(json['id']),
      idPontoClassificacaoJornada:
          serializer.fromJson<int?>(json['idPontoClassificacaoJornada']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataFechamento: serializer.fromJson<DateTime?>(json['dataFechamento']),
      diaSemana: serializer.fromJson<String?>(json['diaSemana']),
      codigoHorario: serializer.fromJson<String?>(json['codigoHorario']),
      cargaHorariaEsperada:
          serializer.fromJson<String?>(json['cargaHorariaEsperada']),
      cargaHorariaDiurna:
          serializer.fromJson<String?>(json['cargaHorariaDiurna']),
      cargaHorariaNoturna:
          serializer.fromJson<String?>(json['cargaHorariaNoturna']),
      cargaHorariaTotal:
          serializer.fromJson<String?>(json['cargaHorariaTotal']),
      entrada01: serializer.fromJson<String?>(json['entrada01']),
      saida01: serializer.fromJson<String?>(json['saida01']),
      entrada02: serializer.fromJson<String?>(json['entrada02']),
      saida02: serializer.fromJson<String?>(json['saida02']),
      entrada03: serializer.fromJson<String?>(json['entrada03']),
      saida03: serializer.fromJson<String?>(json['saida03']),
      entrada04: serializer.fromJson<String?>(json['entrada04']),
      saida04: serializer.fromJson<String?>(json['saida04']),
      entrada05: serializer.fromJson<String?>(json['entrada05']),
      saida05: serializer.fromJson<String?>(json['saida05']),
      horaInicioJornada:
          serializer.fromJson<String?>(json['horaInicioJornada']),
      horaFimJornada: serializer.fromJson<String?>(json['horaFimJornada']),
      horaExtra01: serializer.fromJson<String?>(json['horaExtra01']),
      percentualHoraExtra01:
          serializer.fromJson<double?>(json['percentualHoraExtra01']),
      modalidadeHoraExtra01:
          serializer.fromJson<String?>(json['modalidadeHoraExtra01']),
      horaExtra02: serializer.fromJson<String?>(json['horaExtra02']),
      percentualHoraExtra02:
          serializer.fromJson<double?>(json['percentualHoraExtra02']),
      modalidadeHoraExtra02:
          serializer.fromJson<String?>(json['modalidadeHoraExtra02']),
      horaExtra03: serializer.fromJson<String?>(json['horaExtra03']),
      percentualHoraExtra03:
          serializer.fromJson<double?>(json['percentualHoraExtra03']),
      modalidadeHoraExtra03:
          serializer.fromJson<String?>(json['modalidadeHoraExtra03']),
      horaExtra04: serializer.fromJson<String?>(json['horaExtra04']),
      percentualHoraExtra04:
          serializer.fromJson<double?>(json['percentualHoraExtra04']),
      modalidadeHoraExtra04:
          serializer.fromJson<String?>(json['modalidadeHoraExtra04']),
      faltaAtraso: serializer.fromJson<String?>(json['faltaAtraso']),
      compensar: serializer.fromJson<String?>(json['compensar']),
      bancoHoras: serializer.fromJson<String?>(json['bancoHoras']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPontoClassificacaoJornada':
          serializer.toJson<int?>(idPontoClassificacaoJornada),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataFechamento': serializer.toJson<DateTime?>(dataFechamento),
      'diaSemana': serializer.toJson<String?>(diaSemana),
      'codigoHorario': serializer.toJson<String?>(codigoHorario),
      'cargaHorariaEsperada': serializer.toJson<String?>(cargaHorariaEsperada),
      'cargaHorariaDiurna': serializer.toJson<String?>(cargaHorariaDiurna),
      'cargaHorariaNoturna': serializer.toJson<String?>(cargaHorariaNoturna),
      'cargaHorariaTotal': serializer.toJson<String?>(cargaHorariaTotal),
      'entrada01': serializer.toJson<String?>(entrada01),
      'saida01': serializer.toJson<String?>(saida01),
      'entrada02': serializer.toJson<String?>(entrada02),
      'saida02': serializer.toJson<String?>(saida02),
      'entrada03': serializer.toJson<String?>(entrada03),
      'saida03': serializer.toJson<String?>(saida03),
      'entrada04': serializer.toJson<String?>(entrada04),
      'saida04': serializer.toJson<String?>(saida04),
      'entrada05': serializer.toJson<String?>(entrada05),
      'saida05': serializer.toJson<String?>(saida05),
      'horaInicioJornada': serializer.toJson<String?>(horaInicioJornada),
      'horaFimJornada': serializer.toJson<String?>(horaFimJornada),
      'horaExtra01': serializer.toJson<String?>(horaExtra01),
      'percentualHoraExtra01':
          serializer.toJson<double?>(percentualHoraExtra01),
      'modalidadeHoraExtra01':
          serializer.toJson<String?>(modalidadeHoraExtra01),
      'horaExtra02': serializer.toJson<String?>(horaExtra02),
      'percentualHoraExtra02':
          serializer.toJson<double?>(percentualHoraExtra02),
      'modalidadeHoraExtra02':
          serializer.toJson<String?>(modalidadeHoraExtra02),
      'horaExtra03': serializer.toJson<String?>(horaExtra03),
      'percentualHoraExtra03':
          serializer.toJson<double?>(percentualHoraExtra03),
      'modalidadeHoraExtra03':
          serializer.toJson<String?>(modalidadeHoraExtra03),
      'horaExtra04': serializer.toJson<String?>(horaExtra04),
      'percentualHoraExtra04':
          serializer.toJson<double?>(percentualHoraExtra04),
      'modalidadeHoraExtra04':
          serializer.toJson<String?>(modalidadeHoraExtra04),
      'faltaAtraso': serializer.toJson<String?>(faltaAtraso),
      'compensar': serializer.toJson<String?>(compensar),
      'bancoHoras': serializer.toJson<String?>(bancoHoras),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  PontoFechamentoJornada copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPontoClassificacaoJornada = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataFechamento = const Value.absent(),
          Value<String?> diaSemana = const Value.absent(),
          Value<String?> codigoHorario = const Value.absent(),
          Value<String?> cargaHorariaEsperada = const Value.absent(),
          Value<String?> cargaHorariaDiurna = const Value.absent(),
          Value<String?> cargaHorariaNoturna = const Value.absent(),
          Value<String?> cargaHorariaTotal = const Value.absent(),
          Value<String?> entrada01 = const Value.absent(),
          Value<String?> saida01 = const Value.absent(),
          Value<String?> entrada02 = const Value.absent(),
          Value<String?> saida02 = const Value.absent(),
          Value<String?> entrada03 = const Value.absent(),
          Value<String?> saida03 = const Value.absent(),
          Value<String?> entrada04 = const Value.absent(),
          Value<String?> saida04 = const Value.absent(),
          Value<String?> entrada05 = const Value.absent(),
          Value<String?> saida05 = const Value.absent(),
          Value<String?> horaInicioJornada = const Value.absent(),
          Value<String?> horaFimJornada = const Value.absent(),
          Value<String?> horaExtra01 = const Value.absent(),
          Value<double?> percentualHoraExtra01 = const Value.absent(),
          Value<String?> modalidadeHoraExtra01 = const Value.absent(),
          Value<String?> horaExtra02 = const Value.absent(),
          Value<double?> percentualHoraExtra02 = const Value.absent(),
          Value<String?> modalidadeHoraExtra02 = const Value.absent(),
          Value<String?> horaExtra03 = const Value.absent(),
          Value<double?> percentualHoraExtra03 = const Value.absent(),
          Value<String?> modalidadeHoraExtra03 = const Value.absent(),
          Value<String?> horaExtra04 = const Value.absent(),
          Value<double?> percentualHoraExtra04 = const Value.absent(),
          Value<String?> modalidadeHoraExtra04 = const Value.absent(),
          Value<String?> faltaAtraso = const Value.absent(),
          Value<String?> compensar = const Value.absent(),
          Value<String?> bancoHoras = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      PontoFechamentoJornada(
        id: id.present ? id.value : this.id,
        idPontoClassificacaoJornada: idPontoClassificacaoJornada.present
            ? idPontoClassificacaoJornada.value
            : this.idPontoClassificacaoJornada,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataFechamento:
            dataFechamento.present ? dataFechamento.value : this.dataFechamento,
        diaSemana: diaSemana.present ? diaSemana.value : this.diaSemana,
        codigoHorario:
            codigoHorario.present ? codigoHorario.value : this.codigoHorario,
        cargaHorariaEsperada: cargaHorariaEsperada.present
            ? cargaHorariaEsperada.value
            : this.cargaHorariaEsperada,
        cargaHorariaDiurna: cargaHorariaDiurna.present
            ? cargaHorariaDiurna.value
            : this.cargaHorariaDiurna,
        cargaHorariaNoturna: cargaHorariaNoturna.present
            ? cargaHorariaNoturna.value
            : this.cargaHorariaNoturna,
        cargaHorariaTotal: cargaHorariaTotal.present
            ? cargaHorariaTotal.value
            : this.cargaHorariaTotal,
        entrada01: entrada01.present ? entrada01.value : this.entrada01,
        saida01: saida01.present ? saida01.value : this.saida01,
        entrada02: entrada02.present ? entrada02.value : this.entrada02,
        saida02: saida02.present ? saida02.value : this.saida02,
        entrada03: entrada03.present ? entrada03.value : this.entrada03,
        saida03: saida03.present ? saida03.value : this.saida03,
        entrada04: entrada04.present ? entrada04.value : this.entrada04,
        saida04: saida04.present ? saida04.value : this.saida04,
        entrada05: entrada05.present ? entrada05.value : this.entrada05,
        saida05: saida05.present ? saida05.value : this.saida05,
        horaInicioJornada: horaInicioJornada.present
            ? horaInicioJornada.value
            : this.horaInicioJornada,
        horaFimJornada:
            horaFimJornada.present ? horaFimJornada.value : this.horaFimJornada,
        horaExtra01: horaExtra01.present ? horaExtra01.value : this.horaExtra01,
        percentualHoraExtra01: percentualHoraExtra01.present
            ? percentualHoraExtra01.value
            : this.percentualHoraExtra01,
        modalidadeHoraExtra01: modalidadeHoraExtra01.present
            ? modalidadeHoraExtra01.value
            : this.modalidadeHoraExtra01,
        horaExtra02: horaExtra02.present ? horaExtra02.value : this.horaExtra02,
        percentualHoraExtra02: percentualHoraExtra02.present
            ? percentualHoraExtra02.value
            : this.percentualHoraExtra02,
        modalidadeHoraExtra02: modalidadeHoraExtra02.present
            ? modalidadeHoraExtra02.value
            : this.modalidadeHoraExtra02,
        horaExtra03: horaExtra03.present ? horaExtra03.value : this.horaExtra03,
        percentualHoraExtra03: percentualHoraExtra03.present
            ? percentualHoraExtra03.value
            : this.percentualHoraExtra03,
        modalidadeHoraExtra03: modalidadeHoraExtra03.present
            ? modalidadeHoraExtra03.value
            : this.modalidadeHoraExtra03,
        horaExtra04: horaExtra04.present ? horaExtra04.value : this.horaExtra04,
        percentualHoraExtra04: percentualHoraExtra04.present
            ? percentualHoraExtra04.value
            : this.percentualHoraExtra04,
        modalidadeHoraExtra04: modalidadeHoraExtra04.present
            ? modalidadeHoraExtra04.value
            : this.modalidadeHoraExtra04,
        faltaAtraso: faltaAtraso.present ? faltaAtraso.value : this.faltaAtraso,
        compensar: compensar.present ? compensar.value : this.compensar,
        bancoHoras: bancoHoras.present ? bancoHoras.value : this.bancoHoras,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('PontoFechamentoJornada(')
          ..write('id: $id, ')
          ..write('idPontoClassificacaoJornada: $idPontoClassificacaoJornada, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataFechamento: $dataFechamento, ')
          ..write('diaSemana: $diaSemana, ')
          ..write('codigoHorario: $codigoHorario, ')
          ..write('cargaHorariaEsperada: $cargaHorariaEsperada, ')
          ..write('cargaHorariaDiurna: $cargaHorariaDiurna, ')
          ..write('cargaHorariaNoturna: $cargaHorariaNoturna, ')
          ..write('cargaHorariaTotal: $cargaHorariaTotal, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaInicioJornada: $horaInicioJornada, ')
          ..write('horaFimJornada: $horaFimJornada, ')
          ..write('horaExtra01: $horaExtra01, ')
          ..write('percentualHoraExtra01: $percentualHoraExtra01, ')
          ..write('modalidadeHoraExtra01: $modalidadeHoraExtra01, ')
          ..write('horaExtra02: $horaExtra02, ')
          ..write('percentualHoraExtra02: $percentualHoraExtra02, ')
          ..write('modalidadeHoraExtra02: $modalidadeHoraExtra02, ')
          ..write('horaExtra03: $horaExtra03, ')
          ..write('percentualHoraExtra03: $percentualHoraExtra03, ')
          ..write('modalidadeHoraExtra03: $modalidadeHoraExtra03, ')
          ..write('horaExtra04: $horaExtra04, ')
          ..write('percentualHoraExtra04: $percentualHoraExtra04, ')
          ..write('modalidadeHoraExtra04: $modalidadeHoraExtra04, ')
          ..write('faltaAtraso: $faltaAtraso, ')
          ..write('compensar: $compensar, ')
          ..write('bancoHoras: $bancoHoras, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idPontoClassificacaoJornada,
        idColaborador,
        dataFechamento,
        diaSemana,
        codigoHorario,
        cargaHorariaEsperada,
        cargaHorariaDiurna,
        cargaHorariaNoturna,
        cargaHorariaTotal,
        entrada01,
        saida01,
        entrada02,
        saida02,
        entrada03,
        saida03,
        entrada04,
        saida04,
        entrada05,
        saida05,
        horaInicioJornada,
        horaFimJornada,
        horaExtra01,
        percentualHoraExtra01,
        modalidadeHoraExtra01,
        horaExtra02,
        percentualHoraExtra02,
        modalidadeHoraExtra02,
        horaExtra03,
        percentualHoraExtra03,
        modalidadeHoraExtra03,
        horaExtra04,
        percentualHoraExtra04,
        modalidadeHoraExtra04,
        faltaAtraso,
        compensar,
        bancoHoras,
        observacao
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PontoFechamentoJornada &&
          other.id == this.id &&
          other.idPontoClassificacaoJornada ==
              this.idPontoClassificacaoJornada &&
          other.idColaborador == this.idColaborador &&
          other.dataFechamento == this.dataFechamento &&
          other.diaSemana == this.diaSemana &&
          other.codigoHorario == this.codigoHorario &&
          other.cargaHorariaEsperada == this.cargaHorariaEsperada &&
          other.cargaHorariaDiurna == this.cargaHorariaDiurna &&
          other.cargaHorariaNoturna == this.cargaHorariaNoturna &&
          other.cargaHorariaTotal == this.cargaHorariaTotal &&
          other.entrada01 == this.entrada01 &&
          other.saida01 == this.saida01 &&
          other.entrada02 == this.entrada02 &&
          other.saida02 == this.saida02 &&
          other.entrada03 == this.entrada03 &&
          other.saida03 == this.saida03 &&
          other.entrada04 == this.entrada04 &&
          other.saida04 == this.saida04 &&
          other.entrada05 == this.entrada05 &&
          other.saida05 == this.saida05 &&
          other.horaInicioJornada == this.horaInicioJornada &&
          other.horaFimJornada == this.horaFimJornada &&
          other.horaExtra01 == this.horaExtra01 &&
          other.percentualHoraExtra01 == this.percentualHoraExtra01 &&
          other.modalidadeHoraExtra01 == this.modalidadeHoraExtra01 &&
          other.horaExtra02 == this.horaExtra02 &&
          other.percentualHoraExtra02 == this.percentualHoraExtra02 &&
          other.modalidadeHoraExtra02 == this.modalidadeHoraExtra02 &&
          other.horaExtra03 == this.horaExtra03 &&
          other.percentualHoraExtra03 == this.percentualHoraExtra03 &&
          other.modalidadeHoraExtra03 == this.modalidadeHoraExtra03 &&
          other.horaExtra04 == this.horaExtra04 &&
          other.percentualHoraExtra04 == this.percentualHoraExtra04 &&
          other.modalidadeHoraExtra04 == this.modalidadeHoraExtra04 &&
          other.faltaAtraso == this.faltaAtraso &&
          other.compensar == this.compensar &&
          other.bancoHoras == this.bancoHoras &&
          other.observacao == this.observacao);
}

class PontoFechamentoJornadasCompanion
    extends UpdateCompanion<PontoFechamentoJornada> {
  final Value<int?> id;
  final Value<int?> idPontoClassificacaoJornada;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataFechamento;
  final Value<String?> diaSemana;
  final Value<String?> codigoHorario;
  final Value<String?> cargaHorariaEsperada;
  final Value<String?> cargaHorariaDiurna;
  final Value<String?> cargaHorariaNoturna;
  final Value<String?> cargaHorariaTotal;
  final Value<String?> entrada01;
  final Value<String?> saida01;
  final Value<String?> entrada02;
  final Value<String?> saida02;
  final Value<String?> entrada03;
  final Value<String?> saida03;
  final Value<String?> entrada04;
  final Value<String?> saida04;
  final Value<String?> entrada05;
  final Value<String?> saida05;
  final Value<String?> horaInicioJornada;
  final Value<String?> horaFimJornada;
  final Value<String?> horaExtra01;
  final Value<double?> percentualHoraExtra01;
  final Value<String?> modalidadeHoraExtra01;
  final Value<String?> horaExtra02;
  final Value<double?> percentualHoraExtra02;
  final Value<String?> modalidadeHoraExtra02;
  final Value<String?> horaExtra03;
  final Value<double?> percentualHoraExtra03;
  final Value<String?> modalidadeHoraExtra03;
  final Value<String?> horaExtra04;
  final Value<double?> percentualHoraExtra04;
  final Value<String?> modalidadeHoraExtra04;
  final Value<String?> faltaAtraso;
  final Value<String?> compensar;
  final Value<String?> bancoHoras;
  final Value<String?> observacao;
  const PontoFechamentoJornadasCompanion({
    this.id = const Value.absent(),
    this.idPontoClassificacaoJornada = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataFechamento = const Value.absent(),
    this.diaSemana = const Value.absent(),
    this.codigoHorario = const Value.absent(),
    this.cargaHorariaEsperada = const Value.absent(),
    this.cargaHorariaDiurna = const Value.absent(),
    this.cargaHorariaNoturna = const Value.absent(),
    this.cargaHorariaTotal = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaInicioJornada = const Value.absent(),
    this.horaFimJornada = const Value.absent(),
    this.horaExtra01 = const Value.absent(),
    this.percentualHoraExtra01 = const Value.absent(),
    this.modalidadeHoraExtra01 = const Value.absent(),
    this.horaExtra02 = const Value.absent(),
    this.percentualHoraExtra02 = const Value.absent(),
    this.modalidadeHoraExtra02 = const Value.absent(),
    this.horaExtra03 = const Value.absent(),
    this.percentualHoraExtra03 = const Value.absent(),
    this.modalidadeHoraExtra03 = const Value.absent(),
    this.horaExtra04 = const Value.absent(),
    this.percentualHoraExtra04 = const Value.absent(),
    this.modalidadeHoraExtra04 = const Value.absent(),
    this.faltaAtraso = const Value.absent(),
    this.compensar = const Value.absent(),
    this.bancoHoras = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  PontoFechamentoJornadasCompanion.insert({
    this.id = const Value.absent(),
    this.idPontoClassificacaoJornada = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataFechamento = const Value.absent(),
    this.diaSemana = const Value.absent(),
    this.codigoHorario = const Value.absent(),
    this.cargaHorariaEsperada = const Value.absent(),
    this.cargaHorariaDiurna = const Value.absent(),
    this.cargaHorariaNoturna = const Value.absent(),
    this.cargaHorariaTotal = const Value.absent(),
    this.entrada01 = const Value.absent(),
    this.saida01 = const Value.absent(),
    this.entrada02 = const Value.absent(),
    this.saida02 = const Value.absent(),
    this.entrada03 = const Value.absent(),
    this.saida03 = const Value.absent(),
    this.entrada04 = const Value.absent(),
    this.saida04 = const Value.absent(),
    this.entrada05 = const Value.absent(),
    this.saida05 = const Value.absent(),
    this.horaInicioJornada = const Value.absent(),
    this.horaFimJornada = const Value.absent(),
    this.horaExtra01 = const Value.absent(),
    this.percentualHoraExtra01 = const Value.absent(),
    this.modalidadeHoraExtra01 = const Value.absent(),
    this.horaExtra02 = const Value.absent(),
    this.percentualHoraExtra02 = const Value.absent(),
    this.modalidadeHoraExtra02 = const Value.absent(),
    this.horaExtra03 = const Value.absent(),
    this.percentualHoraExtra03 = const Value.absent(),
    this.modalidadeHoraExtra03 = const Value.absent(),
    this.horaExtra04 = const Value.absent(),
    this.percentualHoraExtra04 = const Value.absent(),
    this.modalidadeHoraExtra04 = const Value.absent(),
    this.faltaAtraso = const Value.absent(),
    this.compensar = const Value.absent(),
    this.bancoHoras = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<PontoFechamentoJornada> custom({
    Expression<int>? id,
    Expression<int>? idPontoClassificacaoJornada,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataFechamento,
    Expression<String>? diaSemana,
    Expression<String>? codigoHorario,
    Expression<String>? cargaHorariaEsperada,
    Expression<String>? cargaHorariaDiurna,
    Expression<String>? cargaHorariaNoturna,
    Expression<String>? cargaHorariaTotal,
    Expression<String>? entrada01,
    Expression<String>? saida01,
    Expression<String>? entrada02,
    Expression<String>? saida02,
    Expression<String>? entrada03,
    Expression<String>? saida03,
    Expression<String>? entrada04,
    Expression<String>? saida04,
    Expression<String>? entrada05,
    Expression<String>? saida05,
    Expression<String>? horaInicioJornada,
    Expression<String>? horaFimJornada,
    Expression<String>? horaExtra01,
    Expression<double>? percentualHoraExtra01,
    Expression<String>? modalidadeHoraExtra01,
    Expression<String>? horaExtra02,
    Expression<double>? percentualHoraExtra02,
    Expression<String>? modalidadeHoraExtra02,
    Expression<String>? horaExtra03,
    Expression<double>? percentualHoraExtra03,
    Expression<String>? modalidadeHoraExtra03,
    Expression<String>? horaExtra04,
    Expression<double>? percentualHoraExtra04,
    Expression<String>? modalidadeHoraExtra04,
    Expression<String>? faltaAtraso,
    Expression<String>? compensar,
    Expression<String>? bancoHoras,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPontoClassificacaoJornada != null)
        'id_ponto_classificacao_jornada': idPontoClassificacaoJornada,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataFechamento != null) 'data_fechamento': dataFechamento,
      if (diaSemana != null) 'dia_semana': diaSemana,
      if (codigoHorario != null) 'codigo_horario': codigoHorario,
      if (cargaHorariaEsperada != null)
        'carga_horaria_esperada': cargaHorariaEsperada,
      if (cargaHorariaDiurna != null)
        'carga_horaria_diurna': cargaHorariaDiurna,
      if (cargaHorariaNoturna != null)
        'carga_horaria_noturna': cargaHorariaNoturna,
      if (cargaHorariaTotal != null) 'carga_horaria_total': cargaHorariaTotal,
      if (entrada01 != null) 'entrada01': entrada01,
      if (saida01 != null) 'saida01': saida01,
      if (entrada02 != null) 'entrada02': entrada02,
      if (saida02 != null) 'saida02': saida02,
      if (entrada03 != null) 'entrada03': entrada03,
      if (saida03 != null) 'saida03': saida03,
      if (entrada04 != null) 'entrada04': entrada04,
      if (saida04 != null) 'saida04': saida04,
      if (entrada05 != null) 'entrada05': entrada05,
      if (saida05 != null) 'saida05': saida05,
      if (horaInicioJornada != null) 'hora_inicio_jornada': horaInicioJornada,
      if (horaFimJornada != null) 'hora_fim_jornada': horaFimJornada,
      if (horaExtra01 != null) 'hora_extra01': horaExtra01,
      if (percentualHoraExtra01 != null)
        'percentual_hora_extra01': percentualHoraExtra01,
      if (modalidadeHoraExtra01 != null)
        'modalidade_hora_extra01': modalidadeHoraExtra01,
      if (horaExtra02 != null) 'hora_extra02': horaExtra02,
      if (percentualHoraExtra02 != null)
        'percentual_hora_extra02': percentualHoraExtra02,
      if (modalidadeHoraExtra02 != null)
        'modalidade_hora_extra02': modalidadeHoraExtra02,
      if (horaExtra03 != null) 'hora_extra03': horaExtra03,
      if (percentualHoraExtra03 != null)
        'percentual_hora_extra03': percentualHoraExtra03,
      if (modalidadeHoraExtra03 != null)
        'modalidade_hora_extra03': modalidadeHoraExtra03,
      if (horaExtra04 != null) 'hora_extra04': horaExtra04,
      if (percentualHoraExtra04 != null)
        'percentual_hora_extra04': percentualHoraExtra04,
      if (modalidadeHoraExtra04 != null)
        'modalidade_hora_extra04': modalidadeHoraExtra04,
      if (faltaAtraso != null) 'falta_atraso': faltaAtraso,
      if (compensar != null) 'compensar': compensar,
      if (bancoHoras != null) 'banco_horas': bancoHoras,
      if (observacao != null) 'observacao': observacao,
    });
  }

  PontoFechamentoJornadasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPontoClassificacaoJornada,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataFechamento,
      Value<String?>? diaSemana,
      Value<String?>? codigoHorario,
      Value<String?>? cargaHorariaEsperada,
      Value<String?>? cargaHorariaDiurna,
      Value<String?>? cargaHorariaNoturna,
      Value<String?>? cargaHorariaTotal,
      Value<String?>? entrada01,
      Value<String?>? saida01,
      Value<String?>? entrada02,
      Value<String?>? saida02,
      Value<String?>? entrada03,
      Value<String?>? saida03,
      Value<String?>? entrada04,
      Value<String?>? saida04,
      Value<String?>? entrada05,
      Value<String?>? saida05,
      Value<String?>? horaInicioJornada,
      Value<String?>? horaFimJornada,
      Value<String?>? horaExtra01,
      Value<double?>? percentualHoraExtra01,
      Value<String?>? modalidadeHoraExtra01,
      Value<String?>? horaExtra02,
      Value<double?>? percentualHoraExtra02,
      Value<String?>? modalidadeHoraExtra02,
      Value<String?>? horaExtra03,
      Value<double?>? percentualHoraExtra03,
      Value<String?>? modalidadeHoraExtra03,
      Value<String?>? horaExtra04,
      Value<double?>? percentualHoraExtra04,
      Value<String?>? modalidadeHoraExtra04,
      Value<String?>? faltaAtraso,
      Value<String?>? compensar,
      Value<String?>? bancoHoras,
      Value<String?>? observacao}) {
    return PontoFechamentoJornadasCompanion(
      id: id ?? this.id,
      idPontoClassificacaoJornada:
          idPontoClassificacaoJornada ?? this.idPontoClassificacaoJornada,
      idColaborador: idColaborador ?? this.idColaborador,
      dataFechamento: dataFechamento ?? this.dataFechamento,
      diaSemana: diaSemana ?? this.diaSemana,
      codigoHorario: codigoHorario ?? this.codigoHorario,
      cargaHorariaEsperada: cargaHorariaEsperada ?? this.cargaHorariaEsperada,
      cargaHorariaDiurna: cargaHorariaDiurna ?? this.cargaHorariaDiurna,
      cargaHorariaNoturna: cargaHorariaNoturna ?? this.cargaHorariaNoturna,
      cargaHorariaTotal: cargaHorariaTotal ?? this.cargaHorariaTotal,
      entrada01: entrada01 ?? this.entrada01,
      saida01: saida01 ?? this.saida01,
      entrada02: entrada02 ?? this.entrada02,
      saida02: saida02 ?? this.saida02,
      entrada03: entrada03 ?? this.entrada03,
      saida03: saida03 ?? this.saida03,
      entrada04: entrada04 ?? this.entrada04,
      saida04: saida04 ?? this.saida04,
      entrada05: entrada05 ?? this.entrada05,
      saida05: saida05 ?? this.saida05,
      horaInicioJornada: horaInicioJornada ?? this.horaInicioJornada,
      horaFimJornada: horaFimJornada ?? this.horaFimJornada,
      horaExtra01: horaExtra01 ?? this.horaExtra01,
      percentualHoraExtra01:
          percentualHoraExtra01 ?? this.percentualHoraExtra01,
      modalidadeHoraExtra01:
          modalidadeHoraExtra01 ?? this.modalidadeHoraExtra01,
      horaExtra02: horaExtra02 ?? this.horaExtra02,
      percentualHoraExtra02:
          percentualHoraExtra02 ?? this.percentualHoraExtra02,
      modalidadeHoraExtra02:
          modalidadeHoraExtra02 ?? this.modalidadeHoraExtra02,
      horaExtra03: horaExtra03 ?? this.horaExtra03,
      percentualHoraExtra03:
          percentualHoraExtra03 ?? this.percentualHoraExtra03,
      modalidadeHoraExtra03:
          modalidadeHoraExtra03 ?? this.modalidadeHoraExtra03,
      horaExtra04: horaExtra04 ?? this.horaExtra04,
      percentualHoraExtra04:
          percentualHoraExtra04 ?? this.percentualHoraExtra04,
      modalidadeHoraExtra04:
          modalidadeHoraExtra04 ?? this.modalidadeHoraExtra04,
      faltaAtraso: faltaAtraso ?? this.faltaAtraso,
      compensar: compensar ?? this.compensar,
      bancoHoras: bancoHoras ?? this.bancoHoras,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPontoClassificacaoJornada.present) {
      map['id_ponto_classificacao_jornada'] =
          Variable<int>(idPontoClassificacaoJornada.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataFechamento.present) {
      map['data_fechamento'] = Variable<DateTime>(dataFechamento.value);
    }
    if (diaSemana.present) {
      map['dia_semana'] = Variable<String>(diaSemana.value);
    }
    if (codigoHorario.present) {
      map['codigo_horario'] = Variable<String>(codigoHorario.value);
    }
    if (cargaHorariaEsperada.present) {
      map['carga_horaria_esperada'] =
          Variable<String>(cargaHorariaEsperada.value);
    }
    if (cargaHorariaDiurna.present) {
      map['carga_horaria_diurna'] = Variable<String>(cargaHorariaDiurna.value);
    }
    if (cargaHorariaNoturna.present) {
      map['carga_horaria_noturna'] =
          Variable<String>(cargaHorariaNoturna.value);
    }
    if (cargaHorariaTotal.present) {
      map['carga_horaria_total'] = Variable<String>(cargaHorariaTotal.value);
    }
    if (entrada01.present) {
      map['entrada01'] = Variable<String>(entrada01.value);
    }
    if (saida01.present) {
      map['saida01'] = Variable<String>(saida01.value);
    }
    if (entrada02.present) {
      map['entrada02'] = Variable<String>(entrada02.value);
    }
    if (saida02.present) {
      map['saida02'] = Variable<String>(saida02.value);
    }
    if (entrada03.present) {
      map['entrada03'] = Variable<String>(entrada03.value);
    }
    if (saida03.present) {
      map['saida03'] = Variable<String>(saida03.value);
    }
    if (entrada04.present) {
      map['entrada04'] = Variable<String>(entrada04.value);
    }
    if (saida04.present) {
      map['saida04'] = Variable<String>(saida04.value);
    }
    if (entrada05.present) {
      map['entrada05'] = Variable<String>(entrada05.value);
    }
    if (saida05.present) {
      map['saida05'] = Variable<String>(saida05.value);
    }
    if (horaInicioJornada.present) {
      map['hora_inicio_jornada'] = Variable<String>(horaInicioJornada.value);
    }
    if (horaFimJornada.present) {
      map['hora_fim_jornada'] = Variable<String>(horaFimJornada.value);
    }
    if (horaExtra01.present) {
      map['hora_extra01'] = Variable<String>(horaExtra01.value);
    }
    if (percentualHoraExtra01.present) {
      map['percentual_hora_extra01'] =
          Variable<double>(percentualHoraExtra01.value);
    }
    if (modalidadeHoraExtra01.present) {
      map['modalidade_hora_extra01'] =
          Variable<String>(modalidadeHoraExtra01.value);
    }
    if (horaExtra02.present) {
      map['hora_extra02'] = Variable<String>(horaExtra02.value);
    }
    if (percentualHoraExtra02.present) {
      map['percentual_hora_extra02'] =
          Variable<double>(percentualHoraExtra02.value);
    }
    if (modalidadeHoraExtra02.present) {
      map['modalidade_hora_extra02'] =
          Variable<String>(modalidadeHoraExtra02.value);
    }
    if (horaExtra03.present) {
      map['hora_extra03'] = Variable<String>(horaExtra03.value);
    }
    if (percentualHoraExtra03.present) {
      map['percentual_hora_extra03'] =
          Variable<double>(percentualHoraExtra03.value);
    }
    if (modalidadeHoraExtra03.present) {
      map['modalidade_hora_extra03'] =
          Variable<String>(modalidadeHoraExtra03.value);
    }
    if (horaExtra04.present) {
      map['hora_extra04'] = Variable<String>(horaExtra04.value);
    }
    if (percentualHoraExtra04.present) {
      map['percentual_hora_extra04'] =
          Variable<double>(percentualHoraExtra04.value);
    }
    if (modalidadeHoraExtra04.present) {
      map['modalidade_hora_extra04'] =
          Variable<String>(modalidadeHoraExtra04.value);
    }
    if (faltaAtraso.present) {
      map['falta_atraso'] = Variable<String>(faltaAtraso.value);
    }
    if (compensar.present) {
      map['compensar'] = Variable<String>(compensar.value);
    }
    if (bancoHoras.present) {
      map['banco_horas'] = Variable<String>(bancoHoras.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PontoFechamentoJornadasCompanion(')
          ..write('id: $id, ')
          ..write('idPontoClassificacaoJornada: $idPontoClassificacaoJornada, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataFechamento: $dataFechamento, ')
          ..write('diaSemana: $diaSemana, ')
          ..write('codigoHorario: $codigoHorario, ')
          ..write('cargaHorariaEsperada: $cargaHorariaEsperada, ')
          ..write('cargaHorariaDiurna: $cargaHorariaDiurna, ')
          ..write('cargaHorariaNoturna: $cargaHorariaNoturna, ')
          ..write('cargaHorariaTotal: $cargaHorariaTotal, ')
          ..write('entrada01: $entrada01, ')
          ..write('saida01: $saida01, ')
          ..write('entrada02: $entrada02, ')
          ..write('saida02: $saida02, ')
          ..write('entrada03: $entrada03, ')
          ..write('saida03: $saida03, ')
          ..write('entrada04: $entrada04, ')
          ..write('saida04: $saida04, ')
          ..write('entrada05: $entrada05, ')
          ..write('saida05: $saida05, ')
          ..write('horaInicioJornada: $horaInicioJornada, ')
          ..write('horaFimJornada: $horaFimJornada, ')
          ..write('horaExtra01: $horaExtra01, ')
          ..write('percentualHoraExtra01: $percentualHoraExtra01, ')
          ..write('modalidadeHoraExtra01: $modalidadeHoraExtra01, ')
          ..write('horaExtra02: $horaExtra02, ')
          ..write('percentualHoraExtra02: $percentualHoraExtra02, ')
          ..write('modalidadeHoraExtra02: $modalidadeHoraExtra02, ')
          ..write('horaExtra03: $horaExtra03, ')
          ..write('percentualHoraExtra03: $percentualHoraExtra03, ')
          ..write('modalidadeHoraExtra03: $modalidadeHoraExtra03, ')
          ..write('horaExtra04: $horaExtra04, ')
          ..write('percentualHoraExtra04: $percentualHoraExtra04, ')
          ..write('modalidadeHoraExtra04: $modalidadeHoraExtra04, ')
          ..write('faltaAtraso: $faltaAtraso, ')
          ..write('compensar: $compensar, ')
          ..write('bancoHoras: $bancoHoras, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $PontoTurmasTable pontoTurmas = $PontoTurmasTable(this);
  late final $PontoAbonoUtilizacaosTable pontoAbonoUtilizacaos =
      $PontoAbonoUtilizacaosTable(this);
  late final $PontoBancoHorasUtilizacaosTable pontoBancoHorasUtilizacaos =
      $PontoBancoHorasUtilizacaosTable(this);
  late final $PontoEscalasTable pontoEscalas = $PontoEscalasTable(this);
  late final $PontoBancoHorassTable pontoBancoHorass =
      $PontoBancoHorassTable(this);
  late final $PontoAbonosTable pontoAbonos = $PontoAbonosTable(this);
  late final $PontoParametrosTable pontoParametros =
      $PontoParametrosTable(this);
  late final $PontoHorariosTable pontoHorarios = $PontoHorariosTable(this);
  late final $PontoRelogiosTable pontoRelogios = $PontoRelogiosTable(this);
  late final $PontoMarcacaosTable pontoMarcacaos = $PontoMarcacaosTable(this);
  late final $PontoClassificacaoJornadasTable pontoClassificacaoJornadas =
      $PontoClassificacaoJornadasTable(this);
  late final $PontoHorarioAutorizadosTable pontoHorarioAutorizados =
      $PontoHorarioAutorizadosTable(this);
  late final $PontoFechamentoJornadasTable pontoFechamentoJornadas =
      $PontoFechamentoJornadasTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final PontoEscalaDao pontoEscalaDao =
      PontoEscalaDao(this as AppDatabase);
  late final PontoBancoHorasDao pontoBancoHorasDao =
      PontoBancoHorasDao(this as AppDatabase);
  late final PontoAbonoDao pontoAbonoDao = PontoAbonoDao(this as AppDatabase);
  late final PontoParametroDao pontoParametroDao =
      PontoParametroDao(this as AppDatabase);
  late final PontoHorarioDao pontoHorarioDao =
      PontoHorarioDao(this as AppDatabase);
  late final PontoRelogioDao pontoRelogioDao =
      PontoRelogioDao(this as AppDatabase);
  late final PontoMarcacaoDao pontoMarcacaoDao =
      PontoMarcacaoDao(this as AppDatabase);
  late final PontoClassificacaoJornadaDao pontoClassificacaoJornadaDao =
      PontoClassificacaoJornadaDao(this as AppDatabase);
  late final PontoHorarioAutorizadoDao pontoHorarioAutorizadoDao =
      PontoHorarioAutorizadoDao(this as AppDatabase);
  late final PontoFechamentoJornadaDao pontoFechamentoJornadaDao =
      PontoFechamentoJornadaDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        pontoTurmas,
        pontoAbonoUtilizacaos,
        pontoBancoHorasUtilizacaos,
        pontoEscalas,
        pontoBancoHorass,
        pontoAbonos,
        pontoParametros,
        pontoHorarios,
        pontoRelogios,
        pontoMarcacaos,
        pontoClassificacaoJornadas,
        pontoHorarioAutorizados,
        pontoFechamentoJornadas,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaColaboradors
      ];
}
