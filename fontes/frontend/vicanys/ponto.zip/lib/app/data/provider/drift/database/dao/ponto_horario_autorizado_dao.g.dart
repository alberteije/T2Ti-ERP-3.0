// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_horario_autorizado_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoHorarioAutorizadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoHorarioAutorizadosTable get pontoHorarioAutorizados =>
      attachedDatabase.pontoHorarioAutorizados;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
