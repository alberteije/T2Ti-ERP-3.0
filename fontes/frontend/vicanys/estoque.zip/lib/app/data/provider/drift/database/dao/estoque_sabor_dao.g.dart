// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_sabor_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueSaborDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueSaborsTable get estoqueSabors => attachedDatabase.estoqueSabors;
}
