// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_grade_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueGradeDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueGradesTable get estoqueGrades => attachedDatabase.estoqueGrades;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $EstoqueCorsTable get estoqueCors => attachedDatabase.estoqueCors;
  $EstoqueTamanhosTable get estoqueTamanhos => attachedDatabase.estoqueTamanhos;
  $EstoqueSaborsTable get estoqueSabors => attachedDatabase.estoqueSabors;
  $EstoqueMarcasTable get estoqueMarcas => attachedDatabase.estoqueMarcas;
}
