// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $RequisicaoInternaDetalhesTable extends RequisicaoInternaDetalhes
    with TableInfo<$RequisicaoInternaDetalhesTable, RequisicaoInternaDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RequisicaoInternaDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idRequisicaoInternaCabecalhoMeta =
      const VerificationMeta('idRequisicaoInternaCabecalho');
  @override
  late final GeneratedColumn<int> idRequisicaoInternaCabecalho =
      GeneratedColumn<int>('id_requisicao_interna_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idRequisicaoInternaCabecalho, idProduto, quantidade];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'requisicao_interna_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<RequisicaoInternaDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_requisicao_interna_cabecalho')) {
      context.handle(
          _idRequisicaoInternaCabecalhoMeta,
          idRequisicaoInternaCabecalho.isAcceptableOrUnknown(
              data['id_requisicao_interna_cabecalho']!,
              _idRequisicaoInternaCabecalhoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RequisicaoInternaDetalhe map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RequisicaoInternaDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idRequisicaoInternaCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_requisicao_interna_cabecalho']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
    );
  }

  @override
  $RequisicaoInternaDetalhesTable createAlias(String alias) {
    return $RequisicaoInternaDetalhesTable(attachedDatabase, alias);
  }
}

class RequisicaoInternaDetalhe extends DataClass
    implements Insertable<RequisicaoInternaDetalhe> {
  final int? id;
  final int? idRequisicaoInternaCabecalho;
  final int? idProduto;
  final double? quantidade;
  const RequisicaoInternaDetalhe(
      {this.id,
      this.idRequisicaoInternaCabecalho,
      this.idProduto,
      this.quantidade});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idRequisicaoInternaCabecalho != null) {
      map['id_requisicao_interna_cabecalho'] =
          Variable<int>(idRequisicaoInternaCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    return map;
  }

  factory RequisicaoInternaDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RequisicaoInternaDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idRequisicaoInternaCabecalho:
          serializer.fromJson<int?>(json['idRequisicaoInternaCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idRequisicaoInternaCabecalho':
          serializer.toJson<int?>(idRequisicaoInternaCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
    };
  }

  RequisicaoInternaDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idRequisicaoInternaCabecalho = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> quantidade = const Value.absent()}) =>
      RequisicaoInternaDetalhe(
        id: id.present ? id.value : this.id,
        idRequisicaoInternaCabecalho: idRequisicaoInternaCabecalho.present
            ? idRequisicaoInternaCabecalho.value
            : this.idRequisicaoInternaCabecalho,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
      );
  @override
  String toString() {
    return (StringBuffer('RequisicaoInternaDetalhe(')
          ..write('id: $id, ')
          ..write(
              'idRequisicaoInternaCabecalho: $idRequisicaoInternaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idRequisicaoInternaCabecalho, idProduto, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RequisicaoInternaDetalhe &&
          other.id == this.id &&
          other.idRequisicaoInternaCabecalho ==
              this.idRequisicaoInternaCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade);
}

class RequisicaoInternaDetalhesCompanion
    extends UpdateCompanion<RequisicaoInternaDetalhe> {
  final Value<int?> id;
  final Value<int?> idRequisicaoInternaCabecalho;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  const RequisicaoInternaDetalhesCompanion({
    this.id = const Value.absent(),
    this.idRequisicaoInternaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  RequisicaoInternaDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idRequisicaoInternaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<RequisicaoInternaDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idRequisicaoInternaCabecalho,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idRequisicaoInternaCabecalho != null)
        'id_requisicao_interna_cabecalho': idRequisicaoInternaCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  RequisicaoInternaDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idRequisicaoInternaCabecalho,
      Value<int?>? idProduto,
      Value<double?>? quantidade}) {
    return RequisicaoInternaDetalhesCompanion(
      id: id ?? this.id,
      idRequisicaoInternaCabecalho:
          idRequisicaoInternaCabecalho ?? this.idRequisicaoInternaCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idRequisicaoInternaCabecalho.present) {
      map['id_requisicao_interna_cabecalho'] =
          Variable<int>(idRequisicaoInternaCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RequisicaoInternaDetalhesCompanion(')
          ..write('id: $id, ')
          ..write(
              'idRequisicaoInternaCabecalho: $idRequisicaoInternaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $EstoqueReajusteDetalhesTable extends EstoqueReajusteDetalhes
    with TableInfo<$EstoqueReajusteDetalhesTable, EstoqueReajusteDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueReajusteDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstoqueReajusteCabecalhoMeta =
      const VerificationMeta('idEstoqueReajusteCabecalho');
  @override
  late final GeneratedColumn<int> idEstoqueReajusteCabecalho =
      GeneratedColumn<int>('id_estoque_reajuste_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorOriginalMeta =
      const VerificationMeta('valorOriginal');
  @override
  late final GeneratedColumn<double> valorOriginal = GeneratedColumn<double>(
      'valor_original', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorReajusteMeta =
      const VerificationMeta('valorReajuste');
  @override
  late final GeneratedColumn<double> valorReajuste = GeneratedColumn<double>(
      'valor_reajuste', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idEstoqueReajusteCabecalho, idProduto, valorOriginal, valorReajuste];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_reajuste_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<EstoqueReajusteDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_estoque_reajuste_cabecalho')) {
      context.handle(
          _idEstoqueReajusteCabecalhoMeta,
          idEstoqueReajusteCabecalho.isAcceptableOrUnknown(
              data['id_estoque_reajuste_cabecalho']!,
              _idEstoqueReajusteCabecalhoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('valor_original')) {
      context.handle(
          _valorOriginalMeta,
          valorOriginal.isAcceptableOrUnknown(
              data['valor_original']!, _valorOriginalMeta));
    }
    if (data.containsKey('valor_reajuste')) {
      context.handle(
          _valorReajusteMeta,
          valorReajuste.isAcceptableOrUnknown(
              data['valor_reajuste']!, _valorReajusteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueReajusteDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueReajusteDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEstoqueReajusteCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_estoque_reajuste_cabecalho']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      valorOriginal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_original']),
      valorReajuste: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_reajuste']),
    );
  }

  @override
  $EstoqueReajusteDetalhesTable createAlias(String alias) {
    return $EstoqueReajusteDetalhesTable(attachedDatabase, alias);
  }
}

class EstoqueReajusteDetalhe extends DataClass
    implements Insertable<EstoqueReajusteDetalhe> {
  final int? id;
  final int? idEstoqueReajusteCabecalho;
  final int? idProduto;
  final double? valorOriginal;
  final double? valorReajuste;
  const EstoqueReajusteDetalhe(
      {this.id,
      this.idEstoqueReajusteCabecalho,
      this.idProduto,
      this.valorOriginal,
      this.valorReajuste});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEstoqueReajusteCabecalho != null) {
      map['id_estoque_reajuste_cabecalho'] =
          Variable<int>(idEstoqueReajusteCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || valorOriginal != null) {
      map['valor_original'] = Variable<double>(valorOriginal);
    }
    if (!nullToAbsent || valorReajuste != null) {
      map['valor_reajuste'] = Variable<double>(valorReajuste);
    }
    return map;
  }

  factory EstoqueReajusteDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueReajusteDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idEstoqueReajusteCabecalho:
          serializer.fromJson<int?>(json['idEstoqueReajusteCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      valorOriginal: serializer.fromJson<double?>(json['valorOriginal']),
      valorReajuste: serializer.fromJson<double?>(json['valorReajuste']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEstoqueReajusteCabecalho':
          serializer.toJson<int?>(idEstoqueReajusteCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'valorOriginal': serializer.toJson<double?>(valorOriginal),
      'valorReajuste': serializer.toJson<double?>(valorReajuste),
    };
  }

  EstoqueReajusteDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEstoqueReajusteCabecalho = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> valorOriginal = const Value.absent(),
          Value<double?> valorReajuste = const Value.absent()}) =>
      EstoqueReajusteDetalhe(
        id: id.present ? id.value : this.id,
        idEstoqueReajusteCabecalho: idEstoqueReajusteCabecalho.present
            ? idEstoqueReajusteCabecalho.value
            : this.idEstoqueReajusteCabecalho,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        valorOriginal:
            valorOriginal.present ? valorOriginal.value : this.valorOriginal,
        valorReajuste:
            valorReajuste.present ? valorReajuste.value : this.valorReajuste,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueReajusteDetalhe(')
          ..write('id: $id, ')
          ..write('idEstoqueReajusteCabecalho: $idEstoqueReajusteCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorReajuste: $valorReajuste')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idEstoqueReajusteCabecalho, idProduto, valorOriginal, valorReajuste);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueReajusteDetalhe &&
          other.id == this.id &&
          other.idEstoqueReajusteCabecalho == this.idEstoqueReajusteCabecalho &&
          other.idProduto == this.idProduto &&
          other.valorOriginal == this.valorOriginal &&
          other.valorReajuste == this.valorReajuste);
}

class EstoqueReajusteDetalhesCompanion
    extends UpdateCompanion<EstoqueReajusteDetalhe> {
  final Value<int?> id;
  final Value<int?> idEstoqueReajusteCabecalho;
  final Value<int?> idProduto;
  final Value<double?> valorOriginal;
  final Value<double?> valorReajuste;
  const EstoqueReajusteDetalhesCompanion({
    this.id = const Value.absent(),
    this.idEstoqueReajusteCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorReajuste = const Value.absent(),
  });
  EstoqueReajusteDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idEstoqueReajusteCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorReajuste = const Value.absent(),
  });
  static Insertable<EstoqueReajusteDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idEstoqueReajusteCabecalho,
    Expression<int>? idProduto,
    Expression<double>? valorOriginal,
    Expression<double>? valorReajuste,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEstoqueReajusteCabecalho != null)
        'id_estoque_reajuste_cabecalho': idEstoqueReajusteCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (valorOriginal != null) 'valor_original': valorOriginal,
      if (valorReajuste != null) 'valor_reajuste': valorReajuste,
    });
  }

  EstoqueReajusteDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEstoqueReajusteCabecalho,
      Value<int?>? idProduto,
      Value<double?>? valorOriginal,
      Value<double?>? valorReajuste}) {
    return EstoqueReajusteDetalhesCompanion(
      id: id ?? this.id,
      idEstoqueReajusteCabecalho:
          idEstoqueReajusteCabecalho ?? this.idEstoqueReajusteCabecalho,
      idProduto: idProduto ?? this.idProduto,
      valorOriginal: valorOriginal ?? this.valorOriginal,
      valorReajuste: valorReajuste ?? this.valorReajuste,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEstoqueReajusteCabecalho.present) {
      map['id_estoque_reajuste_cabecalho'] =
          Variable<int>(idEstoqueReajusteCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (valorOriginal.present) {
      map['valor_original'] = Variable<double>(valorOriginal.value);
    }
    if (valorReajuste.present) {
      map['valor_reajuste'] = Variable<double>(valorReajuste.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueReajusteDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idEstoqueReajusteCabecalho: $idEstoqueReajusteCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorReajuste: $valorReajuste')
          ..write(')'))
        .toString();
  }
}

class $RequisicaoInternaCabecalhosTable extends RequisicaoInternaCabecalhos
    with
        TableInfo<$RequisicaoInternaCabecalhosTable,
            RequisicaoInternaCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RequisicaoInternaCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataRequisicaoMeta =
      const VerificationMeta('dataRequisicao');
  @override
  late final GeneratedColumn<DateTime> dataRequisicao =
      GeneratedColumn<DateTime>('data_requisicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, dataRequisicao, situacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'requisicao_interna_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<RequisicaoInternaCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_requisicao')) {
      context.handle(
          _dataRequisicaoMeta,
          dataRequisicao.isAcceptableOrUnknown(
              data['data_requisicao']!, _dataRequisicaoMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RequisicaoInternaCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RequisicaoInternaCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataRequisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_requisicao']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
    );
  }

  @override
  $RequisicaoInternaCabecalhosTable createAlias(String alias) {
    return $RequisicaoInternaCabecalhosTable(attachedDatabase, alias);
  }
}

class RequisicaoInternaCabecalho extends DataClass
    implements Insertable<RequisicaoInternaCabecalho> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataRequisicao;
  final String? situacao;
  const RequisicaoInternaCabecalho(
      {this.id, this.idColaborador, this.dataRequisicao, this.situacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataRequisicao != null) {
      map['data_requisicao'] = Variable<DateTime>(dataRequisicao);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    return map;
  }

  factory RequisicaoInternaCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RequisicaoInternaCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataRequisicao: serializer.fromJson<DateTime?>(json['dataRequisicao']),
      situacao: serializer.fromJson<String?>(json['situacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataRequisicao': serializer.toJson<DateTime?>(dataRequisicao),
      'situacao': serializer.toJson<String?>(situacao),
    };
  }

  RequisicaoInternaCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataRequisicao = const Value.absent(),
          Value<String?> situacao = const Value.absent()}) =>
      RequisicaoInternaCabecalho(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataRequisicao:
            dataRequisicao.present ? dataRequisicao.value : this.dataRequisicao,
        situacao: situacao.present ? situacao.value : this.situacao,
      );
  @override
  String toString() {
    return (StringBuffer('RequisicaoInternaCabecalho(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataRequisicao: $dataRequisicao, ')
          ..write('situacao: $situacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, dataRequisicao, situacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RequisicaoInternaCabecalho &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataRequisicao == this.dataRequisicao &&
          other.situacao == this.situacao);
}

class RequisicaoInternaCabecalhosCompanion
    extends UpdateCompanion<RequisicaoInternaCabecalho> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataRequisicao;
  final Value<String?> situacao;
  const RequisicaoInternaCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataRequisicao = const Value.absent(),
    this.situacao = const Value.absent(),
  });
  RequisicaoInternaCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataRequisicao = const Value.absent(),
    this.situacao = const Value.absent(),
  });
  static Insertable<RequisicaoInternaCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataRequisicao,
    Expression<String>? situacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataRequisicao != null) 'data_requisicao': dataRequisicao,
      if (situacao != null) 'situacao': situacao,
    });
  }

  RequisicaoInternaCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataRequisicao,
      Value<String?>? situacao}) {
    return RequisicaoInternaCabecalhosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataRequisicao: dataRequisicao ?? this.dataRequisicao,
      situacao: situacao ?? this.situacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataRequisicao.present) {
      map['data_requisicao'] = Variable<DateTime>(dataRequisicao.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RequisicaoInternaCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataRequisicao: $dataRequisicao, ')
          ..write('situacao: $situacao')
          ..write(')'))
        .toString();
  }
}

class $EstoqueReajusteCabecalhosTable extends EstoqueReajusteCabecalhos
    with TableInfo<$EstoqueReajusteCabecalhosTable, EstoqueReajusteCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueReajusteCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataReajusteMeta =
      const VerificationMeta('dataReajuste');
  @override
  late final GeneratedColumn<DateTime> dataReajuste = GeneratedColumn<DateTime>(
      'data_reajuste', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaMeta = const VerificationMeta('taxa');
  @override
  late final GeneratedColumn<double> taxa = GeneratedColumn<double>(
      'taxa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _tipoReajusteMeta =
      const VerificationMeta('tipoReajuste');
  @override
  late final GeneratedColumn<String> tipoReajuste = GeneratedColumn<String>(
      'tipo_reajuste', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _justificativaMeta =
      const VerificationMeta('justificativa');
  @override
  late final GeneratedColumn<String> justificativa = GeneratedColumn<String>(
      'justificativa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, dataReajuste, taxa, tipoReajuste, justificativa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_reajuste_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<EstoqueReajusteCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('data_reajuste')) {
      context.handle(
          _dataReajusteMeta,
          dataReajuste.isAcceptableOrUnknown(
              data['data_reajuste']!, _dataReajusteMeta));
    }
    if (data.containsKey('taxa')) {
      context.handle(
          _taxaMeta, taxa.isAcceptableOrUnknown(data['taxa']!, _taxaMeta));
    }
    if (data.containsKey('tipo_reajuste')) {
      context.handle(
          _tipoReajusteMeta,
          tipoReajuste.isAcceptableOrUnknown(
              data['tipo_reajuste']!, _tipoReajusteMeta));
    }
    if (data.containsKey('justificativa')) {
      context.handle(
          _justificativaMeta,
          justificativa.isAcceptableOrUnknown(
              data['justificativa']!, _justificativaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueReajusteCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueReajusteCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      dataReajuste: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_reajuste']),
      taxa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa']),
      tipoReajuste: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_reajuste']),
      justificativa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}justificativa']),
    );
  }

  @override
  $EstoqueReajusteCabecalhosTable createAlias(String alias) {
    return $EstoqueReajusteCabecalhosTable(attachedDatabase, alias);
  }
}

class EstoqueReajusteCabecalho extends DataClass
    implements Insertable<EstoqueReajusteCabecalho> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataReajuste;
  final double? taxa;
  final String? tipoReajuste;
  final String? justificativa;
  const EstoqueReajusteCabecalho(
      {this.id,
      this.idColaborador,
      this.dataReajuste,
      this.taxa,
      this.tipoReajuste,
      this.justificativa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataReajuste != null) {
      map['data_reajuste'] = Variable<DateTime>(dataReajuste);
    }
    if (!nullToAbsent || taxa != null) {
      map['taxa'] = Variable<double>(taxa);
    }
    if (!nullToAbsent || tipoReajuste != null) {
      map['tipo_reajuste'] = Variable<String>(tipoReajuste);
    }
    if (!nullToAbsent || justificativa != null) {
      map['justificativa'] = Variable<String>(justificativa);
    }
    return map;
  }

  factory EstoqueReajusteCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueReajusteCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataReajuste: serializer.fromJson<DateTime?>(json['dataReajuste']),
      taxa: serializer.fromJson<double?>(json['taxa']),
      tipoReajuste: serializer.fromJson<String?>(json['tipoReajuste']),
      justificativa: serializer.fromJson<String?>(json['justificativa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataReajuste': serializer.toJson<DateTime?>(dataReajuste),
      'taxa': serializer.toJson<double?>(taxa),
      'tipoReajuste': serializer.toJson<String?>(tipoReajuste),
      'justificativa': serializer.toJson<String?>(justificativa),
    };
  }

  EstoqueReajusteCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<DateTime?> dataReajuste = const Value.absent(),
          Value<double?> taxa = const Value.absent(),
          Value<String?> tipoReajuste = const Value.absent(),
          Value<String?> justificativa = const Value.absent()}) =>
      EstoqueReajusteCabecalho(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        dataReajuste:
            dataReajuste.present ? dataReajuste.value : this.dataReajuste,
        taxa: taxa.present ? taxa.value : this.taxa,
        tipoReajuste:
            tipoReajuste.present ? tipoReajuste.value : this.tipoReajuste,
        justificativa:
            justificativa.present ? justificativa.value : this.justificativa,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueReajusteCabecalho(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataReajuste: $dataReajuste, ')
          ..write('taxa: $taxa, ')
          ..write('tipoReajuste: $tipoReajuste, ')
          ..write('justificativa: $justificativa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idColaborador, dataReajuste, taxa, tipoReajuste, justificativa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueReajusteCabecalho &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataReajuste == this.dataReajuste &&
          other.taxa == this.taxa &&
          other.tipoReajuste == this.tipoReajuste &&
          other.justificativa == this.justificativa);
}

class EstoqueReajusteCabecalhosCompanion
    extends UpdateCompanion<EstoqueReajusteCabecalho> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataReajuste;
  final Value<double?> taxa;
  final Value<String?> tipoReajuste;
  final Value<String?> justificativa;
  const EstoqueReajusteCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataReajuste = const Value.absent(),
    this.taxa = const Value.absent(),
    this.tipoReajuste = const Value.absent(),
    this.justificativa = const Value.absent(),
  });
  EstoqueReajusteCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataReajuste = const Value.absent(),
    this.taxa = const Value.absent(),
    this.tipoReajuste = const Value.absent(),
    this.justificativa = const Value.absent(),
  });
  static Insertable<EstoqueReajusteCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataReajuste,
    Expression<double>? taxa,
    Expression<String>? tipoReajuste,
    Expression<String>? justificativa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataReajuste != null) 'data_reajuste': dataReajuste,
      if (taxa != null) 'taxa': taxa,
      if (tipoReajuste != null) 'tipo_reajuste': tipoReajuste,
      if (justificativa != null) 'justificativa': justificativa,
    });
  }

  EstoqueReajusteCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<DateTime?>? dataReajuste,
      Value<double?>? taxa,
      Value<String?>? tipoReajuste,
      Value<String?>? justificativa}) {
    return EstoqueReajusteCabecalhosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataReajuste: dataReajuste ?? this.dataReajuste,
      taxa: taxa ?? this.taxa,
      tipoReajuste: tipoReajuste ?? this.tipoReajuste,
      justificativa: justificativa ?? this.justificativa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataReajuste.present) {
      map['data_reajuste'] = Variable<DateTime>(dataReajuste.value);
    }
    if (taxa.present) {
      map['taxa'] = Variable<double>(taxa.value);
    }
    if (tipoReajuste.present) {
      map['tipo_reajuste'] = Variable<String>(tipoReajuste.value);
    }
    if (justificativa.present) {
      map['justificativa'] = Variable<String>(justificativa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueReajusteCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataReajuste: $dataReajuste, ')
          ..write('taxa: $taxa, ')
          ..write('tipoReajuste: $tipoReajuste, ')
          ..write('justificativa: $justificativa')
          ..write(')'))
        .toString();
  }
}

class $ProdutoGruposTable extends ProdutoGrupos
    with TableInfo<$ProdutoGruposTable, ProdutoGrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoGruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_grupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoGrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoGrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoGrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoGruposTable createAlias(String alias) {
    return $ProdutoGruposTable(attachedDatabase, alias);
  }
}

class ProdutoGrupo extends DataClass implements Insertable<ProdutoGrupo> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoGrupo({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoGrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoGrupo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoGrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoGrupo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoGrupo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoGrupo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoGruposCompanion extends UpdateCompanion<ProdutoGrupo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoGruposCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoGruposCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoGrupo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoGruposCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoGruposCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoGruposCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoSubgruposTable extends ProdutoSubgrupos
    with TableInfo<$ProdutoSubgruposTable, ProdutoSubgrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoSubgruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoGrupoMeta =
      const VerificationMeta('idProdutoGrupo');
  @override
  late final GeneratedColumn<int> idProdutoGrupo = GeneratedColumn<int>(
      'id_produto_grupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idProdutoGrupo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_subgrupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoSubgrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_grupo')) {
      context.handle(
          _idProdutoGrupoMeta,
          idProdutoGrupo.isAcceptableOrUnknown(
              data['id_produto_grupo']!, _idProdutoGrupoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoSubgrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoSubgrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoGrupo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_grupo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoSubgruposTable createAlias(String alias) {
    return $ProdutoSubgruposTable(attachedDatabase, alias);
  }
}

class ProdutoSubgrupo extends DataClass implements Insertable<ProdutoSubgrupo> {
  final int? id;
  final int? idProdutoGrupo;
  final String? nome;
  final String? descricao;
  const ProdutoSubgrupo(
      {this.id, this.idProdutoGrupo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoGrupo != null) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoSubgrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoSubgrupo(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoGrupo: serializer.fromJson<int?>(json['idProdutoGrupo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoGrupo': serializer.toJson<int?>(idProdutoGrupo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoSubgrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoGrupo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoSubgrupo(
        id: id.present ? id.value : this.id,
        idProdutoGrupo:
            idProdutoGrupo.present ? idProdutoGrupo.value : this.idProdutoGrupo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoSubgrupo(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProdutoGrupo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoSubgrupo &&
          other.id == this.id &&
          other.idProdutoGrupo == this.idProdutoGrupo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoSubgruposCompanion extends UpdateCompanion<ProdutoSubgrupo> {
  final Value<int?> id;
  final Value<int?> idProdutoGrupo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoSubgruposCompanion({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoSubgruposCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoSubgrupo> custom({
    Expression<int>? id,
    Expression<int>? idProdutoGrupo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoGrupo != null) 'id_produto_grupo': idProdutoGrupo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoSubgruposCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoGrupo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return ProdutoSubgruposCompanion(
      id: id ?? this.id,
      idProdutoGrupo: idProdutoGrupo ?? this.idProdutoGrupo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoGrupo.present) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoSubgruposCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoMarcasTable extends ProdutoMarcas
    with TableInfo<$ProdutoMarcasTable, ProdutoMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_marca';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoMarcasTable createAlias(String alias) {
    return $ProdutoMarcasTable(attachedDatabase, alias);
  }
}

class ProdutoMarca extends DataClass implements Insertable<ProdutoMarca> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoMarca({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoMarca(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoMarca(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoMarca(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoMarca &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoMarcasCompanion extends UpdateCompanion<ProdutoMarca> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoMarcasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoMarca> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoMarcasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarcasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoUnidadesTable extends ProdutoUnidades
    with TableInfo<$ProdutoUnidadesTable, ProdutoUnidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoUnidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeFracionarMeta =
      const VerificationMeta('podeFracionar');
  @override
  late final GeneratedColumn<String> podeFracionar = GeneratedColumn<String>(
      'pode_fracionar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, sigla, descricao, podeFracionar];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_unidade';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoUnidade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('pode_fracionar')) {
      context.handle(
          _podeFracionarMeta,
          podeFracionar.isAcceptableOrUnknown(
              data['pode_fracionar']!, _podeFracionarMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoUnidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoUnidade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      podeFracionar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_fracionar']),
    );
  }

  @override
  $ProdutoUnidadesTable createAlias(String alias) {
    return $ProdutoUnidadesTable(attachedDatabase, alias);
  }
}

class ProdutoUnidade extends DataClass implements Insertable<ProdutoUnidade> {
  final int? id;
  final String? sigla;
  final String? descricao;
  final String? podeFracionar;
  const ProdutoUnidade(
      {this.id, this.sigla, this.descricao, this.podeFracionar});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || podeFracionar != null) {
      map['pode_fracionar'] = Variable<String>(podeFracionar);
    }
    return map;
  }

  factory ProdutoUnidade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoUnidade(
      id: serializer.fromJson<int?>(json['id']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      podeFracionar: serializer.fromJson<String?>(json['podeFracionar']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'sigla': serializer.toJson<String?>(sigla),
      'descricao': serializer.toJson<String?>(descricao),
      'podeFracionar': serializer.toJson<String?>(podeFracionar),
    };
  }

  ProdutoUnidade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> podeFracionar = const Value.absent()}) =>
      ProdutoUnidade(
        id: id.present ? id.value : this.id,
        sigla: sigla.present ? sigla.value : this.sigla,
        descricao: descricao.present ? descricao.value : this.descricao,
        podeFracionar:
            podeFracionar.present ? podeFracionar.value : this.podeFracionar,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoUnidade(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sigla, descricao, podeFracionar);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoUnidade &&
          other.id == this.id &&
          other.sigla == this.sigla &&
          other.descricao == this.descricao &&
          other.podeFracionar == this.podeFracionar);
}

class ProdutoUnidadesCompanion extends UpdateCompanion<ProdutoUnidade> {
  final Value<int?> id;
  final Value<String?> sigla;
  final Value<String?> descricao;
  final Value<String?> podeFracionar;
  const ProdutoUnidadesCompanion({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  ProdutoUnidadesCompanion.insert({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  static Insertable<ProdutoUnidade> custom({
    Expression<int>? id,
    Expression<String>? sigla,
    Expression<String>? descricao,
    Expression<String>? podeFracionar,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sigla != null) 'sigla': sigla,
      if (descricao != null) 'descricao': descricao,
      if (podeFracionar != null) 'pode_fracionar': podeFracionar,
    });
  }

  ProdutoUnidadesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? sigla,
      Value<String?>? descricao,
      Value<String?>? podeFracionar}) {
    return ProdutoUnidadesCompanion(
      id: id ?? this.id,
      sigla: sigla ?? this.sigla,
      descricao: descricao ?? this.descricao,
      podeFracionar: podeFracionar ?? this.podeFracionar,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (podeFracionar.present) {
      map['pode_fracionar'] = Variable<String>(podeFracionar.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidadesCompanion(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoSubgrupoMeta =
      const VerificationMeta('idProdutoSubgrupo');
  @override
  late final GeneratedColumn<int> idProdutoSubgrupo = GeneratedColumn<int>(
      'id_produto_subgrupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMarcaMeta =
      const VerificationMeta('idProdutoMarca');
  @override
  late final GeneratedColumn<int> idProdutoMarca = GeneratedColumn<int>(
      'id_produto_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoUnidadeMeta =
      const VerificationMeta('idProdutoUnidade');
  @override
  late final GeneratedColumn<int> idProdutoUnidade = GeneratedColumn<int>(
      'id_produto_unidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
      'id_tribut_icms_custom_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>('id_tribut_grupo_tributario', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
      'gtin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _codigoNcmMeta =
      const VerificationMeta('codigoNcm');
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
      'codigo_ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _estoqueMinimoMeta =
      const VerificationMeta('estoqueMinimo');
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
      'estoque_minimo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMaximoMeta =
      const VerificationMeta('estoqueMaximo');
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
      'estoque_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeEstoqueMeta =
      const VerificationMeta('quantidadeEstoque');
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>('quantidade_estoque', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProdutoSubgrupo,
        idProdutoMarca,
        idProdutoUnidade,
        idTributIcmsCustomCab,
        idTributGrupoTributario,
        nome,
        descricao,
        gtin,
        codigoInterno,
        valorCompra,
        valorVenda,
        codigoNcm,
        estoqueMinimo,
        estoqueMaximo,
        quantidadeEstoque,
        dataCadastro
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(Insertable<Produto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_subgrupo')) {
      context.handle(
          _idProdutoSubgrupoMeta,
          idProdutoSubgrupo.isAcceptableOrUnknown(
              data['id_produto_subgrupo']!, _idProdutoSubgrupoMeta));
    }
    if (data.containsKey('id_produto_marca')) {
      context.handle(
          _idProdutoMarcaMeta,
          idProdutoMarca.isAcceptableOrUnknown(
              data['id_produto_marca']!, _idProdutoMarcaMeta));
    }
    if (data.containsKey('id_produto_unidade')) {
      context.handle(
          _idProdutoUnidadeMeta,
          idProdutoUnidade.isAcceptableOrUnknown(
              data['id_produto_unidade']!, _idProdutoUnidadeMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
          _idTributIcmsCustomCabMeta,
          idTributIcmsCustomCab.isAcceptableOrUnknown(
              data['id_tribut_icms_custom_cab']!, _idTributIcmsCustomCabMeta));
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
          _idTributGrupoTributarioMeta,
          idTributGrupoTributario.isAcceptableOrUnknown(
              data['id_tribut_grupo_tributario']!,
              _idTributGrupoTributarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('gtin')) {
      context.handle(
          _gtinMeta, gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(_codigoNcmMeta,
          codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta));
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
          _estoqueMinimoMeta,
          estoqueMinimo.isAcceptableOrUnknown(
              data['estoque_minimo']!, _estoqueMinimoMeta));
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
          _estoqueMaximoMeta,
          estoqueMaximo.isAcceptableOrUnknown(
              data['estoque_maximo']!, _estoqueMaximoMeta));
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
          _quantidadeEstoqueMeta,
          quantidadeEstoque.isAcceptableOrUnknown(
              data['quantidade_estoque']!, _quantidadeEstoqueMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoSubgrupo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_produto_subgrupo']),
      idProdutoMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_marca']),
      idProdutoUnidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_unidade']),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_icms_custom_cab']),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_grupo_tributario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      gtin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gtin']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      codigoNcm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_ncm']),
      estoqueMinimo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_minimo']),
      estoqueMaximo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_maximo']),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_estoque']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idProdutoSubgrupo;
  final int? idProdutoMarca;
  final int? idProdutoUnidade;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  final DateTime? dataCadastro;
  const Produto(
      {this.id,
      this.idProdutoSubgrupo,
      this.idProdutoMarca,
      this.idProdutoUnidade,
      this.idTributIcmsCustomCab,
      this.idTributGrupoTributario,
      this.nome,
      this.descricao,
      this.gtin,
      this.codigoInterno,
      this.valorCompra,
      this.valorVenda,
      this.codigoNcm,
      this.estoqueMinimo,
      this.estoqueMaximo,
      this.quantidadeEstoque,
      this.dataCadastro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoSubgrupo != null) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo);
    }
    if (!nullToAbsent || idProdutoMarca != null) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca);
    }
    if (!nullToAbsent || idProdutoUnidade != null) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Produto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoSubgrupo: serializer.fromJson<int?>(json['idProdutoSubgrupo']),
      idProdutoMarca: serializer.fromJson<int?>(json['idProdutoMarca']),
      idProdutoUnidade: serializer.fromJson<int?>(json['idProdutoUnidade']),
      idTributIcmsCustomCab:
          serializer.fromJson<int?>(json['idTributIcmsCustomCab']),
      idTributGrupoTributario:
          serializer.fromJson<int?>(json['idTributGrupoTributario']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque:
          serializer.fromJson<double?>(json['quantidadeEstoque']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoSubgrupo': serializer.toJson<int?>(idProdutoSubgrupo),
      'idProdutoMarca': serializer.toJson<int?>(idProdutoMarca),
      'idProdutoUnidade': serializer.toJson<int?>(idProdutoUnidade),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario':
          serializer.toJson<int?>(idTributGrupoTributario),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Produto copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoSubgrupo = const Value.absent(),
          Value<int?> idProdutoMarca = const Value.absent(),
          Value<int?> idProdutoUnidade = const Value.absent(),
          Value<int?> idTributIcmsCustomCab = const Value.absent(),
          Value<int?> idTributGrupoTributario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> gtin = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> codigoNcm = const Value.absent(),
          Value<double?> estoqueMinimo = const Value.absent(),
          Value<double?> estoqueMaximo = const Value.absent(),
          Value<double?> quantidadeEstoque = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent()}) =>
      Produto(
        id: id.present ? id.value : this.id,
        idProdutoSubgrupo: idProdutoSubgrupo.present
            ? idProdutoSubgrupo.value
            : this.idProdutoSubgrupo,
        idProdutoMarca:
            idProdutoMarca.present ? idProdutoMarca.value : this.idProdutoMarca,
        idProdutoUnidade: idProdutoUnidade.present
            ? idProdutoUnidade.value
            : this.idProdutoUnidade,
        idTributIcmsCustomCab: idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
        idTributGrupoTributario: idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        gtin: gtin.present ? gtin.value : this.gtin,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
        estoqueMinimo:
            estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
        estoqueMaximo:
            estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
        quantidadeEstoque: quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
      );
  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idProdutoSubgrupo,
      idProdutoMarca,
      idProdutoUnidade,
      idTributIcmsCustomCab,
      idTributGrupoTributario,
      nome,
      descricao,
      gtin,
      codigoInterno,
      valorCompra,
      valorVenda,
      codigoNcm,
      estoqueMinimo,
      estoqueMaximo,
      quantidadeEstoque,
      dataCadastro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idProdutoSubgrupo == this.idProdutoSubgrupo &&
          other.idProdutoMarca == this.idProdutoMarca &&
          other.idProdutoUnidade == this.idProdutoUnidade &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque &&
          other.dataCadastro == this.dataCadastro);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idProdutoSubgrupo;
  final Value<int?> idProdutoMarca;
  final Value<int?> idProdutoUnidade;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  final Value<DateTime?> dataCadastro;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idProdutoSubgrupo,
    Expression<int>? idProdutoMarca,
    Expression<int>? idProdutoUnidade,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoSubgrupo != null) 'id_produto_subgrupo': idProdutoSubgrupo,
      if (idProdutoMarca != null) 'id_produto_marca': idProdutoMarca,
      if (idProdutoUnidade != null) 'id_produto_unidade': idProdutoUnidade,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  ProdutosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoSubgrupo,
      Value<int?>? idProdutoMarca,
      Value<int?>? idProdutoUnidade,
      Value<int?>? idTributIcmsCustomCab,
      Value<int?>? idTributGrupoTributario,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? gtin,
      Value<String?>? codigoInterno,
      Value<double?>? valorCompra,
      Value<double?>? valorVenda,
      Value<String?>? codigoNcm,
      Value<double?>? estoqueMinimo,
      Value<double?>? estoqueMaximo,
      Value<double?>? quantidadeEstoque,
      Value<DateTime?>? dataCadastro}) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idProdutoSubgrupo: idProdutoSubgrupo ?? this.idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca ?? this.idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade ?? this.idProdutoUnidade,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoSubgrupo.present) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo.value);
    }
    if (idProdutoMarca.present) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca.value);
    }
    if (idProdutoUnidade.present) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] =
          Variable<int>(idTributIcmsCustomCab.value);
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $EstoqueCorsTable extends EstoqueCors
    with TableInfo<$EstoqueCorsTable, EstoqueCor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueCorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_cor';
  @override
  VerificationContext validateIntegrity(Insertable<EstoqueCor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueCor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueCor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $EstoqueCorsTable createAlias(String alias) {
    return $EstoqueCorsTable(attachedDatabase, alias);
  }
}

class EstoqueCor extends DataClass implements Insertable<EstoqueCor> {
  final int? id;
  final String? codigo;
  final String? nome;
  const EstoqueCor({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory EstoqueCor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueCor(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  EstoqueCor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      EstoqueCor(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueCor(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueCor &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class EstoqueCorsCompanion extends UpdateCompanion<EstoqueCor> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const EstoqueCorsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  EstoqueCorsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<EstoqueCor> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  EstoqueCorsCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return EstoqueCorsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueCorsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $EstoqueTamanhosTable extends EstoqueTamanhos
    with TableInfo<$EstoqueTamanhosTable, EstoqueTamanho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueTamanhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _alturaMeta = const VerificationMeta('altura');
  @override
  late final GeneratedColumn<double> altura = GeneratedColumn<double>(
      'altura', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _comprimentoMeta =
      const VerificationMeta('comprimento');
  @override
  late final GeneratedColumn<double> comprimento = GeneratedColumn<double>(
      'comprimento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _larguraMeta =
      const VerificationMeta('largura');
  @override
  late final GeneratedColumn<double> largura = GeneratedColumn<double>(
      'largura', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, codigo, nome, altura, comprimento, largura];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_tamanho';
  @override
  VerificationContext validateIntegrity(Insertable<EstoqueTamanho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('altura')) {
      context.handle(_alturaMeta,
          altura.isAcceptableOrUnknown(data['altura']!, _alturaMeta));
    }
    if (data.containsKey('comprimento')) {
      context.handle(
          _comprimentoMeta,
          comprimento.isAcceptableOrUnknown(
              data['comprimento']!, _comprimentoMeta));
    }
    if (data.containsKey('largura')) {
      context.handle(_larguraMeta,
          largura.isAcceptableOrUnknown(data['largura']!, _larguraMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueTamanho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueTamanho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      altura: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}altura']),
      comprimento: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}comprimento']),
      largura: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}largura']),
    );
  }

  @override
  $EstoqueTamanhosTable createAlias(String alias) {
    return $EstoqueTamanhosTable(attachedDatabase, alias);
  }
}

class EstoqueTamanho extends DataClass implements Insertable<EstoqueTamanho> {
  final int? id;
  final String? codigo;
  final String? nome;
  final double? altura;
  final double? comprimento;
  final double? largura;
  const EstoqueTamanho(
      {this.id,
      this.codigo,
      this.nome,
      this.altura,
      this.comprimento,
      this.largura});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || altura != null) {
      map['altura'] = Variable<double>(altura);
    }
    if (!nullToAbsent || comprimento != null) {
      map['comprimento'] = Variable<double>(comprimento);
    }
    if (!nullToAbsent || largura != null) {
      map['largura'] = Variable<double>(largura);
    }
    return map;
  }

  factory EstoqueTamanho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueTamanho(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      altura: serializer.fromJson<double?>(json['altura']),
      comprimento: serializer.fromJson<double?>(json['comprimento']),
      largura: serializer.fromJson<double?>(json['largura']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'altura': serializer.toJson<double?>(altura),
      'comprimento': serializer.toJson<double?>(comprimento),
      'largura': serializer.toJson<double?>(largura),
    };
  }

  EstoqueTamanho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<double?> altura = const Value.absent(),
          Value<double?> comprimento = const Value.absent(),
          Value<double?> largura = const Value.absent()}) =>
      EstoqueTamanho(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        altura: altura.present ? altura.value : this.altura,
        comprimento: comprimento.present ? comprimento.value : this.comprimento,
        largura: largura.present ? largura.value : this.largura,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueTamanho(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('altura: $altura, ')
          ..write('comprimento: $comprimento, ')
          ..write('largura: $largura')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, codigo, nome, altura, comprimento, largura);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueTamanho &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.altura == this.altura &&
          other.comprimento == this.comprimento &&
          other.largura == this.largura);
}

class EstoqueTamanhosCompanion extends UpdateCompanion<EstoqueTamanho> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<double?> altura;
  final Value<double?> comprimento;
  final Value<double?> largura;
  const EstoqueTamanhosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.altura = const Value.absent(),
    this.comprimento = const Value.absent(),
    this.largura = const Value.absent(),
  });
  EstoqueTamanhosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.altura = const Value.absent(),
    this.comprimento = const Value.absent(),
    this.largura = const Value.absent(),
  });
  static Insertable<EstoqueTamanho> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<double>? altura,
    Expression<double>? comprimento,
    Expression<double>? largura,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (altura != null) 'altura': altura,
      if (comprimento != null) 'comprimento': comprimento,
      if (largura != null) 'largura': largura,
    });
  }

  EstoqueTamanhosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<double?>? altura,
      Value<double?>? comprimento,
      Value<double?>? largura}) {
    return EstoqueTamanhosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      altura: altura ?? this.altura,
      comprimento: comprimento ?? this.comprimento,
      largura: largura ?? this.largura,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (altura.present) {
      map['altura'] = Variable<double>(altura.value);
    }
    if (comprimento.present) {
      map['comprimento'] = Variable<double>(comprimento.value);
    }
    if (largura.present) {
      map['largura'] = Variable<double>(largura.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueTamanhosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('altura: $altura, ')
          ..write('comprimento: $comprimento, ')
          ..write('largura: $largura')
          ..write(')'))
        .toString();
  }
}

class $EstoqueSaborsTable extends EstoqueSabors
    with TableInfo<$EstoqueSaborsTable, EstoqueSabor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueSaborsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_sabor';
  @override
  VerificationContext validateIntegrity(Insertable<EstoqueSabor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueSabor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueSabor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $EstoqueSaborsTable createAlias(String alias) {
    return $EstoqueSaborsTable(attachedDatabase, alias);
  }
}

class EstoqueSabor extends DataClass implements Insertable<EstoqueSabor> {
  final int? id;
  final String? codigo;
  final String? nome;
  const EstoqueSabor({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory EstoqueSabor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueSabor(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  EstoqueSabor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      EstoqueSabor(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueSabor(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueSabor &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class EstoqueSaborsCompanion extends UpdateCompanion<EstoqueSabor> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const EstoqueSaborsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  EstoqueSaborsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<EstoqueSabor> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  EstoqueSaborsCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return EstoqueSaborsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueSaborsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $EstoqueMarcasTable extends EstoqueMarcas
    with TableInfo<$EstoqueMarcasTable, EstoqueMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_marca';
  @override
  VerificationContext validateIntegrity(Insertable<EstoqueMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $EstoqueMarcasTable createAlias(String alias) {
    return $EstoqueMarcasTable(attachedDatabase, alias);
  }
}

class EstoqueMarca extends DataClass implements Insertable<EstoqueMarca> {
  final int? id;
  final String? codigo;
  final String? nome;
  const EstoqueMarca({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory EstoqueMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueMarca(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  EstoqueMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      EstoqueMarca(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueMarca(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueMarca &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class EstoqueMarcasCompanion extends UpdateCompanion<EstoqueMarca> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const EstoqueMarcasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  EstoqueMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<EstoqueMarca> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  EstoqueMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return EstoqueMarcasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueMarcasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $EstoqueGradesTable extends EstoqueGrades
    with TableInfo<$EstoqueGradesTable, EstoqueGrade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EstoqueGradesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstoqueMarcaMeta =
      const VerificationMeta('idEstoqueMarca');
  @override
  late final GeneratedColumn<int> idEstoqueMarca = GeneratedColumn<int>(
      'id_estoque_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstoqueSaborMeta =
      const VerificationMeta('idEstoqueSabor');
  @override
  late final GeneratedColumn<int> idEstoqueSabor = GeneratedColumn<int>(
      'id_estoque_sabor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstoqueTamanhoMeta =
      const VerificationMeta('idEstoqueTamanho');
  @override
  late final GeneratedColumn<int> idEstoqueTamanho = GeneratedColumn<int>(
      'id_estoque_tamanho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEstoqueCorMeta =
      const VerificationMeta('idEstoqueCor');
  @override
  late final GeneratedColumn<int> idEstoqueCor = GeneratedColumn<int>(
      'id_estoque_cor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProduto,
        idEstoqueMarca,
        idEstoqueSabor,
        idEstoqueTamanho,
        idEstoqueCor,
        codigo,
        quantidade
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'estoque_grade';
  @override
  VerificationContext validateIntegrity(Insertable<EstoqueGrade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('id_estoque_marca')) {
      context.handle(
          _idEstoqueMarcaMeta,
          idEstoqueMarca.isAcceptableOrUnknown(
              data['id_estoque_marca']!, _idEstoqueMarcaMeta));
    }
    if (data.containsKey('id_estoque_sabor')) {
      context.handle(
          _idEstoqueSaborMeta,
          idEstoqueSabor.isAcceptableOrUnknown(
              data['id_estoque_sabor']!, _idEstoqueSaborMeta));
    }
    if (data.containsKey('id_estoque_tamanho')) {
      context.handle(
          _idEstoqueTamanhoMeta,
          idEstoqueTamanho.isAcceptableOrUnknown(
              data['id_estoque_tamanho']!, _idEstoqueTamanhoMeta));
    }
    if (data.containsKey('id_estoque_cor')) {
      context.handle(
          _idEstoqueCorMeta,
          idEstoqueCor.isAcceptableOrUnknown(
              data['id_estoque_cor']!, _idEstoqueCorMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EstoqueGrade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EstoqueGrade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      idEstoqueMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estoque_marca']),
      idEstoqueSabor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estoque_sabor']),
      idEstoqueTamanho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estoque_tamanho']),
      idEstoqueCor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_estoque_cor']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
    );
  }

  @override
  $EstoqueGradesTable createAlias(String alias) {
    return $EstoqueGradesTable(attachedDatabase, alias);
  }
}

class EstoqueGrade extends DataClass implements Insertable<EstoqueGrade> {
  final int? id;
  final int? idProduto;
  final int? idEstoqueMarca;
  final int? idEstoqueSabor;
  final int? idEstoqueTamanho;
  final int? idEstoqueCor;
  final String? codigo;
  final double? quantidade;
  const EstoqueGrade(
      {this.id,
      this.idProduto,
      this.idEstoqueMarca,
      this.idEstoqueSabor,
      this.idEstoqueTamanho,
      this.idEstoqueCor,
      this.codigo,
      this.quantidade});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || idEstoqueMarca != null) {
      map['id_estoque_marca'] = Variable<int>(idEstoqueMarca);
    }
    if (!nullToAbsent || idEstoqueSabor != null) {
      map['id_estoque_sabor'] = Variable<int>(idEstoqueSabor);
    }
    if (!nullToAbsent || idEstoqueTamanho != null) {
      map['id_estoque_tamanho'] = Variable<int>(idEstoqueTamanho);
    }
    if (!nullToAbsent || idEstoqueCor != null) {
      map['id_estoque_cor'] = Variable<int>(idEstoqueCor);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    return map;
  }

  factory EstoqueGrade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EstoqueGrade(
      id: serializer.fromJson<int?>(json['id']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      idEstoqueMarca: serializer.fromJson<int?>(json['idEstoqueMarca']),
      idEstoqueSabor: serializer.fromJson<int?>(json['idEstoqueSabor']),
      idEstoqueTamanho: serializer.fromJson<int?>(json['idEstoqueTamanho']),
      idEstoqueCor: serializer.fromJson<int?>(json['idEstoqueCor']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProduto': serializer.toJson<int?>(idProduto),
      'idEstoqueMarca': serializer.toJson<int?>(idEstoqueMarca),
      'idEstoqueSabor': serializer.toJson<int?>(idEstoqueSabor),
      'idEstoqueTamanho': serializer.toJson<int?>(idEstoqueTamanho),
      'idEstoqueCor': serializer.toJson<int?>(idEstoqueCor),
      'codigo': serializer.toJson<String?>(codigo),
      'quantidade': serializer.toJson<double?>(quantidade),
    };
  }

  EstoqueGrade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<int?> idEstoqueMarca = const Value.absent(),
          Value<int?> idEstoqueSabor = const Value.absent(),
          Value<int?> idEstoqueTamanho = const Value.absent(),
          Value<int?> idEstoqueCor = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<double?> quantidade = const Value.absent()}) =>
      EstoqueGrade(
        id: id.present ? id.value : this.id,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        idEstoqueMarca:
            idEstoqueMarca.present ? idEstoqueMarca.value : this.idEstoqueMarca,
        idEstoqueSabor:
            idEstoqueSabor.present ? idEstoqueSabor.value : this.idEstoqueSabor,
        idEstoqueTamanho: idEstoqueTamanho.present
            ? idEstoqueTamanho.value
            : this.idEstoqueTamanho,
        idEstoqueCor:
            idEstoqueCor.present ? idEstoqueCor.value : this.idEstoqueCor,
        codigo: codigo.present ? codigo.value : this.codigo,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
      );
  @override
  String toString() {
    return (StringBuffer('EstoqueGrade(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('idEstoqueMarca: $idEstoqueMarca, ')
          ..write('idEstoqueSabor: $idEstoqueSabor, ')
          ..write('idEstoqueTamanho: $idEstoqueTamanho, ')
          ..write('idEstoqueCor: $idEstoqueCor, ')
          ..write('codigo: $codigo, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProduto, idEstoqueMarca, idEstoqueSabor,
      idEstoqueTamanho, idEstoqueCor, codigo, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EstoqueGrade &&
          other.id == this.id &&
          other.idProduto == this.idProduto &&
          other.idEstoqueMarca == this.idEstoqueMarca &&
          other.idEstoqueSabor == this.idEstoqueSabor &&
          other.idEstoqueTamanho == this.idEstoqueTamanho &&
          other.idEstoqueCor == this.idEstoqueCor &&
          other.codigo == this.codigo &&
          other.quantidade == this.quantidade);
}

class EstoqueGradesCompanion extends UpdateCompanion<EstoqueGrade> {
  final Value<int?> id;
  final Value<int?> idProduto;
  final Value<int?> idEstoqueMarca;
  final Value<int?> idEstoqueSabor;
  final Value<int?> idEstoqueTamanho;
  final Value<int?> idEstoqueCor;
  final Value<String?> codigo;
  final Value<double?> quantidade;
  const EstoqueGradesCompanion({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idEstoqueMarca = const Value.absent(),
    this.idEstoqueSabor = const Value.absent(),
    this.idEstoqueTamanho = const Value.absent(),
    this.idEstoqueCor = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  EstoqueGradesCompanion.insert({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idEstoqueMarca = const Value.absent(),
    this.idEstoqueSabor = const Value.absent(),
    this.idEstoqueTamanho = const Value.absent(),
    this.idEstoqueCor = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<EstoqueGrade> custom({
    Expression<int>? id,
    Expression<int>? idProduto,
    Expression<int>? idEstoqueMarca,
    Expression<int>? idEstoqueSabor,
    Expression<int>? idEstoqueTamanho,
    Expression<int>? idEstoqueCor,
    Expression<String>? codigo,
    Expression<double>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProduto != null) 'id_produto': idProduto,
      if (idEstoqueMarca != null) 'id_estoque_marca': idEstoqueMarca,
      if (idEstoqueSabor != null) 'id_estoque_sabor': idEstoqueSabor,
      if (idEstoqueTamanho != null) 'id_estoque_tamanho': idEstoqueTamanho,
      if (idEstoqueCor != null) 'id_estoque_cor': idEstoqueCor,
      if (codigo != null) 'codigo': codigo,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  EstoqueGradesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProduto,
      Value<int?>? idEstoqueMarca,
      Value<int?>? idEstoqueSabor,
      Value<int?>? idEstoqueTamanho,
      Value<int?>? idEstoqueCor,
      Value<String?>? codigo,
      Value<double?>? quantidade}) {
    return EstoqueGradesCompanion(
      id: id ?? this.id,
      idProduto: idProduto ?? this.idProduto,
      idEstoqueMarca: idEstoqueMarca ?? this.idEstoqueMarca,
      idEstoqueSabor: idEstoqueSabor ?? this.idEstoqueSabor,
      idEstoqueTamanho: idEstoqueTamanho ?? this.idEstoqueTamanho,
      idEstoqueCor: idEstoqueCor ?? this.idEstoqueCor,
      codigo: codigo ?? this.codigo,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (idEstoqueMarca.present) {
      map['id_estoque_marca'] = Variable<int>(idEstoqueMarca.value);
    }
    if (idEstoqueSabor.present) {
      map['id_estoque_sabor'] = Variable<int>(idEstoqueSabor.value);
    }
    if (idEstoqueTamanho.present) {
      map['id_estoque_tamanho'] = Variable<int>(idEstoqueTamanho.value);
    }
    if (idEstoqueCor.present) {
      map['id_estoque_cor'] = Variable<int>(idEstoqueCor.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EstoqueGradesCompanion(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('idEstoqueMarca: $idEstoqueMarca, ')
          ..write('idEstoqueSabor: $idEstoqueSabor, ')
          ..write('idEstoqueTamanho: $idEstoqueTamanho, ')
          ..write('idEstoqueCor: $idEstoqueCor, ')
          ..write('codigo: $codigo, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $RequisicaoInternaDetalhesTable requisicaoInternaDetalhes =
      $RequisicaoInternaDetalhesTable(this);
  late final $EstoqueReajusteDetalhesTable estoqueReajusteDetalhes =
      $EstoqueReajusteDetalhesTable(this);
  late final $RequisicaoInternaCabecalhosTable requisicaoInternaCabecalhos =
      $RequisicaoInternaCabecalhosTable(this);
  late final $EstoqueReajusteCabecalhosTable estoqueReajusteCabecalhos =
      $EstoqueReajusteCabecalhosTable(this);
  late final $ProdutoGruposTable produtoGrupos = $ProdutoGruposTable(this);
  late final $ProdutoSubgruposTable produtoSubgrupos =
      $ProdutoSubgruposTable(this);
  late final $ProdutoMarcasTable produtoMarcas = $ProdutoMarcasTable(this);
  late final $ProdutoUnidadesTable produtoUnidades =
      $ProdutoUnidadesTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $EstoqueCorsTable estoqueCors = $EstoqueCorsTable(this);
  late final $EstoqueTamanhosTable estoqueTamanhos =
      $EstoqueTamanhosTable(this);
  late final $EstoqueSaborsTable estoqueSabors = $EstoqueSaborsTable(this);
  late final $EstoqueMarcasTable estoqueMarcas = $EstoqueMarcasTable(this);
  late final $EstoqueGradesTable estoqueGrades = $EstoqueGradesTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final RequisicaoInternaCabecalhoDao requisicaoInternaCabecalhoDao =
      RequisicaoInternaCabecalhoDao(this as AppDatabase);
  late final EstoqueReajusteCabecalhoDao estoqueReajusteCabecalhoDao =
      EstoqueReajusteCabecalhoDao(this as AppDatabase);
  late final ProdutoGrupoDao produtoGrupoDao =
      ProdutoGrupoDao(this as AppDatabase);
  late final ProdutoSubgrupoDao produtoSubgrupoDao =
      ProdutoSubgrupoDao(this as AppDatabase);
  late final ProdutoMarcaDao produtoMarcaDao =
      ProdutoMarcaDao(this as AppDatabase);
  late final ProdutoUnidadeDao produtoUnidadeDao =
      ProdutoUnidadeDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final EstoqueCorDao estoqueCorDao = EstoqueCorDao(this as AppDatabase);
  late final EstoqueTamanhoDao estoqueTamanhoDao =
      EstoqueTamanhoDao(this as AppDatabase);
  late final EstoqueSaborDao estoqueSaborDao =
      EstoqueSaborDao(this as AppDatabase);
  late final EstoqueMarcaDao estoqueMarcaDao =
      EstoqueMarcaDao(this as AppDatabase);
  late final EstoqueGradeDao estoqueGradeDao =
      EstoqueGradeDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        requisicaoInternaDetalhes,
        estoqueReajusteDetalhes,
        requisicaoInternaCabecalhos,
        estoqueReajusteCabecalhos,
        produtoGrupos,
        produtoSubgrupos,
        produtoMarcas,
        produtoUnidades,
        produtos,
        estoqueCors,
        estoqueTamanhos,
        estoqueSabors,
        estoqueMarcas,
        estoqueGrades,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaColaboradors
      ];
}
