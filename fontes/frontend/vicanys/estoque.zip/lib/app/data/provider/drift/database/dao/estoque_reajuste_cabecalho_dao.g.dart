// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_reajuste_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueReajusteCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueReajusteCabecalhosTable get estoqueReajusteCabecalhos =>
      attachedDatabase.estoqueReajusteCabecalhos;
  $EstoqueReajusteDetalhesTable get estoqueReajusteDetalhes =>
      attachedDatabase.estoqueReajusteDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
