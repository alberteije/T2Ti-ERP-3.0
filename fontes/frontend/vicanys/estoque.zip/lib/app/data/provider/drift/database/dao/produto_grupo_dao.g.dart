// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_grupo_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoGrupoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutoGruposTable get produtoGrupos => attachedDatabase.produtoGrupos;
}
