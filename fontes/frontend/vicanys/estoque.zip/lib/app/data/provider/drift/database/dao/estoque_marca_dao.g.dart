// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'estoque_marca_dao.dart';

// ignore_for_file: type=lint
mixin _$EstoqueMarcaDaoMixin on DatabaseAccessor<AppDatabase> {
  $EstoqueMarcasTable get estoqueMarcas => attachedDatabase.estoqueMarcas;
}
