
export 'tribut_icms_custom_det_domain.dart';
export 'tribut_icms_uf_domain.dart';
export 'tribut_pis_domain.dart';
export 'tribut_cofins_domain.dart';
export 'tribut_ipi_domain.dart';
export 'tribut_icms_custom_cab_domain.dart';
export 'tribut_grupo_tributario_domain.dart';
export 'tribut_iss_domain.dart';