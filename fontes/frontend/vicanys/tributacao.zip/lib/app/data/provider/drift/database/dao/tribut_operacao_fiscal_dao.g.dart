// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tribut_operacao_fiscal_dao.dart';

// ignore_for_file: type=lint
mixin _$TributOperacaoFiscalDaoMixin on DatabaseAccessor<AppDatabase> {
  $TributOperacaoFiscalsTable get tributOperacaoFiscals =>
      attachedDatabase.tributOperacaoFiscals;
}
