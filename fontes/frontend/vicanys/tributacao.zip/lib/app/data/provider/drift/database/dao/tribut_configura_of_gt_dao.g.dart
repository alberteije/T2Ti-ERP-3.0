// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tribut_configura_of_gt_dao.dart';

// ignore_for_file: type=lint
mixin _$TributConfiguraOfGtDaoMixin on DatabaseAccessor<AppDatabase> {
  $TributConfiguraOfGtsTable get tributConfiguraOfGts =>
      attachedDatabase.tributConfiguraOfGts;
  $TributIpisTable get tributIpis => attachedDatabase.tributIpis;
  $TributCofinssTable get tributCofinss => attachedDatabase.tributCofinss;
  $TributPissTable get tributPiss => attachedDatabase.tributPiss;
  $TributGrupoTributariosTable get tributGrupoTributarios =>
      attachedDatabase.tributGrupoTributarios;
  $TributOperacaoFiscalsTable get tributOperacaoFiscals =>
      attachedDatabase.tributOperacaoFiscals;
  $TributIcmsUfsTable get tributIcmsUfs => attachedDatabase.tributIcmsUfs;
}
