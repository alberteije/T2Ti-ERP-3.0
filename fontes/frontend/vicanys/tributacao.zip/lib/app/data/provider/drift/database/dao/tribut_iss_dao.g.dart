// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tribut_iss_dao.dart';

// ignore_for_file: type=lint
mixin _$TributIssDaoMixin on DatabaseAccessor<AppDatabase> {
  $TributIsssTable get tributIsss => attachedDatabase.tributIsss;
  $TributOperacaoFiscalsTable get tributOperacaoFiscals =>
      attachedDatabase.tributOperacaoFiscals;
}
