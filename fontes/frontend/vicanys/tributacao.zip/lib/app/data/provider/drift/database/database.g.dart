// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $TributIcmsCustomDetsTable extends TributIcmsCustomDets
    with TableInfo<$TributIcmsCustomDetsTable, TributIcmsCustomDet> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIcmsCustomDetsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
      'id_tribut_icms_custom_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufDestinoMeta =
      const VerificationMeta('ufDestino');
  @override
  late final GeneratedColumn<String> ufDestino = GeneratedColumn<String>(
      'uf_destino', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cstMeta = const VerificationMeta('cst');
  @override
  late final GeneratedColumn<String> cst = GeneratedColumn<String>(
      'cst', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _csosnMeta = const VerificationMeta('csosn');
  @override
  late final GeneratedColumn<String> csosn = GeneratedColumn<String>(
      'csosn', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBcMeta =
      const VerificationMeta('modalidadeBc');
  @override
  late final GeneratedColumn<String> modalidadeBc = GeneratedColumn<String>(
      'modalidade_bc', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cfopMeta = const VerificationMeta('cfop');
  @override
  late final GeneratedColumn<int> cfop = GeneratedColumn<int>(
      'cfop', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaMeta =
      const VerificationMeta('aliquota');
  @override
  late final GeneratedColumn<double> aliquota = GeneratedColumn<double>(
      'aliquota', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaMeta =
      const VerificationMeta('valorPauta');
  @override
  late final GeneratedColumn<double> valorPauta = GeneratedColumn<double>(
      'valor_pauta', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _mvaMeta = const VerificationMeta('mva');
  @override
  late final GeneratedColumn<double> mva = GeneratedColumn<double>(
      'mva', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _porcentoBcMeta =
      const VerificationMeta('porcentoBc');
  @override
  late final GeneratedColumn<double> porcentoBc = GeneratedColumn<double>(
      'porcento_bc', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBcStMeta =
      const VerificationMeta('modalidadeBcSt');
  @override
  late final GeneratedColumn<String> modalidadeBcSt = GeneratedColumn<String>(
      'modalidade_bc_st', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aliquotaInternaStMeta =
      const VerificationMeta('aliquotaInternaSt');
  @override
  late final GeneratedColumn<double> aliquotaInternaSt =
      GeneratedColumn<double>('aliquota_interna_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaInterestadualStMeta =
      const VerificationMeta('aliquotaInterestadualSt');
  @override
  late final GeneratedColumn<double> aliquotaInterestadualSt =
      GeneratedColumn<double>('aliquota_interestadual_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _porcentoBcStMeta =
      const VerificationMeta('porcentoBcSt');
  @override
  late final GeneratedColumn<double> porcentoBcSt = GeneratedColumn<double>(
      'porcento_bc_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsStMeta =
      const VerificationMeta('aliquotaIcmsSt');
  @override
  late final GeneratedColumn<double> aliquotaIcmsSt = GeneratedColumn<double>(
      'aliquota_icms_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaStMeta =
      const VerificationMeta('valorPautaSt');
  @override
  late final GeneratedColumn<double> valorPautaSt = GeneratedColumn<double>(
      'valor_pauta_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoStMeta =
      const VerificationMeta('valorPrecoMaximoSt');
  @override
  late final GeneratedColumn<double> valorPrecoMaximoSt =
      GeneratedColumn<double>('valor_preco_maximo_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributIcmsCustomCab,
        ufDestino,
        cst,
        csosn,
        modalidadeBc,
        cfop,
        aliquota,
        valorPauta,
        valorPrecoMaximo,
        mva,
        porcentoBc,
        modalidadeBcSt,
        aliquotaInternaSt,
        aliquotaInterestadualSt,
        porcentoBcSt,
        aliquotaIcmsSt,
        valorPautaSt,
        valorPrecoMaximoSt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_icms_custom_det';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributIcmsCustomDet> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
          _idTributIcmsCustomCabMeta,
          idTributIcmsCustomCab.isAcceptableOrUnknown(
              data['id_tribut_icms_custom_cab']!, _idTributIcmsCustomCabMeta));
    }
    if (data.containsKey('uf_destino')) {
      context.handle(_ufDestinoMeta,
          ufDestino.isAcceptableOrUnknown(data['uf_destino']!, _ufDestinoMeta));
    }
    if (data.containsKey('cst')) {
      context.handle(
          _cstMeta, cst.isAcceptableOrUnknown(data['cst']!, _cstMeta));
    }
    if (data.containsKey('csosn')) {
      context.handle(
          _csosnMeta, csosn.isAcceptableOrUnknown(data['csosn']!, _csosnMeta));
    }
    if (data.containsKey('modalidade_bc')) {
      context.handle(
          _modalidadeBcMeta,
          modalidadeBc.isAcceptableOrUnknown(
              data['modalidade_bc']!, _modalidadeBcMeta));
    }
    if (data.containsKey('cfop')) {
      context.handle(
          _cfopMeta, cfop.isAcceptableOrUnknown(data['cfop']!, _cfopMeta));
    }
    if (data.containsKey('aliquota')) {
      context.handle(_aliquotaMeta,
          aliquota.isAcceptableOrUnknown(data['aliquota']!, _aliquotaMeta));
    }
    if (data.containsKey('valor_pauta')) {
      context.handle(
          _valorPautaMeta,
          valorPauta.isAcceptableOrUnknown(
              data['valor_pauta']!, _valorPautaMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('mva')) {
      context.handle(
          _mvaMeta, mva.isAcceptableOrUnknown(data['mva']!, _mvaMeta));
    }
    if (data.containsKey('porcento_bc')) {
      context.handle(
          _porcentoBcMeta,
          porcentoBc.isAcceptableOrUnknown(
              data['porcento_bc']!, _porcentoBcMeta));
    }
    if (data.containsKey('modalidade_bc_st')) {
      context.handle(
          _modalidadeBcStMeta,
          modalidadeBcSt.isAcceptableOrUnknown(
              data['modalidade_bc_st']!, _modalidadeBcStMeta));
    }
    if (data.containsKey('aliquota_interna_st')) {
      context.handle(
          _aliquotaInternaStMeta,
          aliquotaInternaSt.isAcceptableOrUnknown(
              data['aliquota_interna_st']!, _aliquotaInternaStMeta));
    }
    if (data.containsKey('aliquota_interestadual_st')) {
      context.handle(
          _aliquotaInterestadualStMeta,
          aliquotaInterestadualSt.isAcceptableOrUnknown(
              data['aliquota_interestadual_st']!,
              _aliquotaInterestadualStMeta));
    }
    if (data.containsKey('porcento_bc_st')) {
      context.handle(
          _porcentoBcStMeta,
          porcentoBcSt.isAcceptableOrUnknown(
              data['porcento_bc_st']!, _porcentoBcStMeta));
    }
    if (data.containsKey('aliquota_icms_st')) {
      context.handle(
          _aliquotaIcmsStMeta,
          aliquotaIcmsSt.isAcceptableOrUnknown(
              data['aliquota_icms_st']!, _aliquotaIcmsStMeta));
    }
    if (data.containsKey('valor_pauta_st')) {
      context.handle(
          _valorPautaStMeta,
          valorPautaSt.isAcceptableOrUnknown(
              data['valor_pauta_st']!, _valorPautaStMeta));
    }
    if (data.containsKey('valor_preco_maximo_st')) {
      context.handle(
          _valorPrecoMaximoStMeta,
          valorPrecoMaximoSt.isAcceptableOrUnknown(
              data['valor_preco_maximo_st']!, _valorPrecoMaximoStMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIcmsCustomDet map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIcmsCustomDet(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_icms_custom_cab']),
      ufDestino: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_destino']),
      cst: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst']),
      csosn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}csosn']),
      modalidadeBc: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modalidade_bc']),
      cfop: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop']),
      aliquota: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota']),
      valorPauta: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pauta']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      mva: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}mva']),
      porcentoBc: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_bc']),
      modalidadeBcSt: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}modalidade_bc_st']),
      aliquotaInternaSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_interna_st']),
      aliquotaInterestadualSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}aliquota_interestadual_st']),
      porcentoBcSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_bc_st']),
      aliquotaIcmsSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_icms_st']),
      valorPautaSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pauta_st']),
      valorPrecoMaximoSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo_st']),
    );
  }

  @override
  $TributIcmsCustomDetsTable createAlias(String alias) {
    return $TributIcmsCustomDetsTable(attachedDatabase, alias);
  }
}

class TributIcmsCustomDet extends DataClass
    implements Insertable<TributIcmsCustomDet> {
  final int? id;
  final int? idTributIcmsCustomCab;
  final String? ufDestino;
  final String? cst;
  final String? csosn;
  final String? modalidadeBc;
  final int? cfop;
  final double? aliquota;
  final double? valorPauta;
  final double? valorPrecoMaximo;
  final double? mva;
  final double? porcentoBc;
  final String? modalidadeBcSt;
  final double? aliquotaInternaSt;
  final double? aliquotaInterestadualSt;
  final double? porcentoBcSt;
  final double? aliquotaIcmsSt;
  final double? valorPautaSt;
  final double? valorPrecoMaximoSt;
  const TributIcmsCustomDet(
      {this.id,
      this.idTributIcmsCustomCab,
      this.ufDestino,
      this.cst,
      this.csosn,
      this.modalidadeBc,
      this.cfop,
      this.aliquota,
      this.valorPauta,
      this.valorPrecoMaximo,
      this.mva,
      this.porcentoBc,
      this.modalidadeBcSt,
      this.aliquotaInternaSt,
      this.aliquotaInterestadualSt,
      this.porcentoBcSt,
      this.aliquotaIcmsSt,
      this.valorPautaSt,
      this.valorPrecoMaximoSt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || ufDestino != null) {
      map['uf_destino'] = Variable<String>(ufDestino);
    }
    if (!nullToAbsent || cst != null) {
      map['cst'] = Variable<String>(cst);
    }
    if (!nullToAbsent || csosn != null) {
      map['csosn'] = Variable<String>(csosn);
    }
    if (!nullToAbsent || modalidadeBc != null) {
      map['modalidade_bc'] = Variable<String>(modalidadeBc);
    }
    if (!nullToAbsent || cfop != null) {
      map['cfop'] = Variable<int>(cfop);
    }
    if (!nullToAbsent || aliquota != null) {
      map['aliquota'] = Variable<double>(aliquota);
    }
    if (!nullToAbsent || valorPauta != null) {
      map['valor_pauta'] = Variable<double>(valorPauta);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || mva != null) {
      map['mva'] = Variable<double>(mva);
    }
    if (!nullToAbsent || porcentoBc != null) {
      map['porcento_bc'] = Variable<double>(porcentoBc);
    }
    if (!nullToAbsent || modalidadeBcSt != null) {
      map['modalidade_bc_st'] = Variable<String>(modalidadeBcSt);
    }
    if (!nullToAbsent || aliquotaInternaSt != null) {
      map['aliquota_interna_st'] = Variable<double>(aliquotaInternaSt);
    }
    if (!nullToAbsent || aliquotaInterestadualSt != null) {
      map['aliquota_interestadual_st'] =
          Variable<double>(aliquotaInterestadualSt);
    }
    if (!nullToAbsent || porcentoBcSt != null) {
      map['porcento_bc_st'] = Variable<double>(porcentoBcSt);
    }
    if (!nullToAbsent || aliquotaIcmsSt != null) {
      map['aliquota_icms_st'] = Variable<double>(aliquotaIcmsSt);
    }
    if (!nullToAbsent || valorPautaSt != null) {
      map['valor_pauta_st'] = Variable<double>(valorPautaSt);
    }
    if (!nullToAbsent || valorPrecoMaximoSt != null) {
      map['valor_preco_maximo_st'] = Variable<double>(valorPrecoMaximoSt);
    }
    return map;
  }

  factory TributIcmsCustomDet.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIcmsCustomDet(
      id: serializer.fromJson<int?>(json['id']),
      idTributIcmsCustomCab:
          serializer.fromJson<int?>(json['idTributIcmsCustomCab']),
      ufDestino: serializer.fromJson<String?>(json['ufDestino']),
      cst: serializer.fromJson<String?>(json['cst']),
      csosn: serializer.fromJson<String?>(json['csosn']),
      modalidadeBc: serializer.fromJson<String?>(json['modalidadeBc']),
      cfop: serializer.fromJson<int?>(json['cfop']),
      aliquota: serializer.fromJson<double?>(json['aliquota']),
      valorPauta: serializer.fromJson<double?>(json['valorPauta']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      mva: serializer.fromJson<double?>(json['mva']),
      porcentoBc: serializer.fromJson<double?>(json['porcentoBc']),
      modalidadeBcSt: serializer.fromJson<String?>(json['modalidadeBcSt']),
      aliquotaInternaSt:
          serializer.fromJson<double?>(json['aliquotaInternaSt']),
      aliquotaInterestadualSt:
          serializer.fromJson<double?>(json['aliquotaInterestadualSt']),
      porcentoBcSt: serializer.fromJson<double?>(json['porcentoBcSt']),
      aliquotaIcmsSt: serializer.fromJson<double?>(json['aliquotaIcmsSt']),
      valorPautaSt: serializer.fromJson<double?>(json['valorPautaSt']),
      valorPrecoMaximoSt:
          serializer.fromJson<double?>(json['valorPrecoMaximoSt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'ufDestino': serializer.toJson<String?>(ufDestino),
      'cst': serializer.toJson<String?>(cst),
      'csosn': serializer.toJson<String?>(csosn),
      'modalidadeBc': serializer.toJson<String?>(modalidadeBc),
      'cfop': serializer.toJson<int?>(cfop),
      'aliquota': serializer.toJson<double?>(aliquota),
      'valorPauta': serializer.toJson<double?>(valorPauta),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'mva': serializer.toJson<double?>(mva),
      'porcentoBc': serializer.toJson<double?>(porcentoBc),
      'modalidadeBcSt': serializer.toJson<String?>(modalidadeBcSt),
      'aliquotaInternaSt': serializer.toJson<double?>(aliquotaInternaSt),
      'aliquotaInterestadualSt':
          serializer.toJson<double?>(aliquotaInterestadualSt),
      'porcentoBcSt': serializer.toJson<double?>(porcentoBcSt),
      'aliquotaIcmsSt': serializer.toJson<double?>(aliquotaIcmsSt),
      'valorPautaSt': serializer.toJson<double?>(valorPautaSt),
      'valorPrecoMaximoSt': serializer.toJson<double?>(valorPrecoMaximoSt),
    };
  }

  TributIcmsCustomDet copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributIcmsCustomCab = const Value.absent(),
          Value<String?> ufDestino = const Value.absent(),
          Value<String?> cst = const Value.absent(),
          Value<String?> csosn = const Value.absent(),
          Value<String?> modalidadeBc = const Value.absent(),
          Value<int?> cfop = const Value.absent(),
          Value<double?> aliquota = const Value.absent(),
          Value<double?> valorPauta = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> mva = const Value.absent(),
          Value<double?> porcentoBc = const Value.absent(),
          Value<String?> modalidadeBcSt = const Value.absent(),
          Value<double?> aliquotaInternaSt = const Value.absent(),
          Value<double?> aliquotaInterestadualSt = const Value.absent(),
          Value<double?> porcentoBcSt = const Value.absent(),
          Value<double?> aliquotaIcmsSt = const Value.absent(),
          Value<double?> valorPautaSt = const Value.absent(),
          Value<double?> valorPrecoMaximoSt = const Value.absent()}) =>
      TributIcmsCustomDet(
        id: id.present ? id.value : this.id,
        idTributIcmsCustomCab: idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
        ufDestino: ufDestino.present ? ufDestino.value : this.ufDestino,
        cst: cst.present ? cst.value : this.cst,
        csosn: csosn.present ? csosn.value : this.csosn,
        modalidadeBc:
            modalidadeBc.present ? modalidadeBc.value : this.modalidadeBc,
        cfop: cfop.present ? cfop.value : this.cfop,
        aliquota: aliquota.present ? aliquota.value : this.aliquota,
        valorPauta: valorPauta.present ? valorPauta.value : this.valorPauta,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        mva: mva.present ? mva.value : this.mva,
        porcentoBc: porcentoBc.present ? porcentoBc.value : this.porcentoBc,
        modalidadeBcSt:
            modalidadeBcSt.present ? modalidadeBcSt.value : this.modalidadeBcSt,
        aliquotaInternaSt: aliquotaInternaSt.present
            ? aliquotaInternaSt.value
            : this.aliquotaInternaSt,
        aliquotaInterestadualSt: aliquotaInterestadualSt.present
            ? aliquotaInterestadualSt.value
            : this.aliquotaInterestadualSt,
        porcentoBcSt:
            porcentoBcSt.present ? porcentoBcSt.value : this.porcentoBcSt,
        aliquotaIcmsSt:
            aliquotaIcmsSt.present ? aliquotaIcmsSt.value : this.aliquotaIcmsSt,
        valorPautaSt:
            valorPautaSt.present ? valorPautaSt.value : this.valorPautaSt,
        valorPrecoMaximoSt: valorPrecoMaximoSt.present
            ? valorPrecoMaximoSt.value
            : this.valorPrecoMaximoSt,
      );
  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomDet(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('ufDestino: $ufDestino, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('modalidadeBc: $modalidadeBc, ')
          ..write('cfop: $cfop, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorPauta: $valorPauta, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('mva: $mva, ')
          ..write('porcentoBc: $porcentoBc, ')
          ..write('modalidadeBcSt: $modalidadeBcSt, ')
          ..write('aliquotaInternaSt: $aliquotaInternaSt, ')
          ..write('aliquotaInterestadualSt: $aliquotaInterestadualSt, ')
          ..write('porcentoBcSt: $porcentoBcSt, ')
          ..write('aliquotaIcmsSt: $aliquotaIcmsSt, ')
          ..write('valorPautaSt: $valorPautaSt, ')
          ..write('valorPrecoMaximoSt: $valorPrecoMaximoSt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributIcmsCustomCab,
      ufDestino,
      cst,
      csosn,
      modalidadeBc,
      cfop,
      aliquota,
      valorPauta,
      valorPrecoMaximo,
      mva,
      porcentoBc,
      modalidadeBcSt,
      aliquotaInternaSt,
      aliquotaInterestadualSt,
      porcentoBcSt,
      aliquotaIcmsSt,
      valorPautaSt,
      valorPrecoMaximoSt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIcmsCustomDet &&
          other.id == this.id &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.ufDestino == this.ufDestino &&
          other.cst == this.cst &&
          other.csosn == this.csosn &&
          other.modalidadeBc == this.modalidadeBc &&
          other.cfop == this.cfop &&
          other.aliquota == this.aliquota &&
          other.valorPauta == this.valorPauta &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.mva == this.mva &&
          other.porcentoBc == this.porcentoBc &&
          other.modalidadeBcSt == this.modalidadeBcSt &&
          other.aliquotaInternaSt == this.aliquotaInternaSt &&
          other.aliquotaInterestadualSt == this.aliquotaInterestadualSt &&
          other.porcentoBcSt == this.porcentoBcSt &&
          other.aliquotaIcmsSt == this.aliquotaIcmsSt &&
          other.valorPautaSt == this.valorPautaSt &&
          other.valorPrecoMaximoSt == this.valorPrecoMaximoSt);
}

class TributIcmsCustomDetsCompanion
    extends UpdateCompanion<TributIcmsCustomDet> {
  final Value<int?> id;
  final Value<int?> idTributIcmsCustomCab;
  final Value<String?> ufDestino;
  final Value<String?> cst;
  final Value<String?> csosn;
  final Value<String?> modalidadeBc;
  final Value<int?> cfop;
  final Value<double?> aliquota;
  final Value<double?> valorPauta;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> mva;
  final Value<double?> porcentoBc;
  final Value<String?> modalidadeBcSt;
  final Value<double?> aliquotaInternaSt;
  final Value<double?> aliquotaInterestadualSt;
  final Value<double?> porcentoBcSt;
  final Value<double?> aliquotaIcmsSt;
  final Value<double?> valorPautaSt;
  final Value<double?> valorPrecoMaximoSt;
  const TributIcmsCustomDetsCompanion({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.ufDestino = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.modalidadeBc = const Value.absent(),
    this.cfop = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorPauta = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.mva = const Value.absent(),
    this.porcentoBc = const Value.absent(),
    this.modalidadeBcSt = const Value.absent(),
    this.aliquotaInternaSt = const Value.absent(),
    this.aliquotaInterestadualSt = const Value.absent(),
    this.porcentoBcSt = const Value.absent(),
    this.aliquotaIcmsSt = const Value.absent(),
    this.valorPautaSt = const Value.absent(),
    this.valorPrecoMaximoSt = const Value.absent(),
  });
  TributIcmsCustomDetsCompanion.insert({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.ufDestino = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.modalidadeBc = const Value.absent(),
    this.cfop = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorPauta = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.mva = const Value.absent(),
    this.porcentoBc = const Value.absent(),
    this.modalidadeBcSt = const Value.absent(),
    this.aliquotaInternaSt = const Value.absent(),
    this.aliquotaInterestadualSt = const Value.absent(),
    this.porcentoBcSt = const Value.absent(),
    this.aliquotaIcmsSt = const Value.absent(),
    this.valorPautaSt = const Value.absent(),
    this.valorPrecoMaximoSt = const Value.absent(),
  });
  static Insertable<TributIcmsCustomDet> custom({
    Expression<int>? id,
    Expression<int>? idTributIcmsCustomCab,
    Expression<String>? ufDestino,
    Expression<String>? cst,
    Expression<String>? csosn,
    Expression<String>? modalidadeBc,
    Expression<int>? cfop,
    Expression<double>? aliquota,
    Expression<double>? valorPauta,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? mva,
    Expression<double>? porcentoBc,
    Expression<String>? modalidadeBcSt,
    Expression<double>? aliquotaInternaSt,
    Expression<double>? aliquotaInterestadualSt,
    Expression<double>? porcentoBcSt,
    Expression<double>? aliquotaIcmsSt,
    Expression<double>? valorPautaSt,
    Expression<double>? valorPrecoMaximoSt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (ufDestino != null) 'uf_destino': ufDestino,
      if (cst != null) 'cst': cst,
      if (csosn != null) 'csosn': csosn,
      if (modalidadeBc != null) 'modalidade_bc': modalidadeBc,
      if (cfop != null) 'cfop': cfop,
      if (aliquota != null) 'aliquota': aliquota,
      if (valorPauta != null) 'valor_pauta': valorPauta,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (mva != null) 'mva': mva,
      if (porcentoBc != null) 'porcento_bc': porcentoBc,
      if (modalidadeBcSt != null) 'modalidade_bc_st': modalidadeBcSt,
      if (aliquotaInternaSt != null) 'aliquota_interna_st': aliquotaInternaSt,
      if (aliquotaInterestadualSt != null)
        'aliquota_interestadual_st': aliquotaInterestadualSt,
      if (porcentoBcSt != null) 'porcento_bc_st': porcentoBcSt,
      if (aliquotaIcmsSt != null) 'aliquota_icms_st': aliquotaIcmsSt,
      if (valorPautaSt != null) 'valor_pauta_st': valorPautaSt,
      if (valorPrecoMaximoSt != null)
        'valor_preco_maximo_st': valorPrecoMaximoSt,
    });
  }

  TributIcmsCustomDetsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributIcmsCustomCab,
      Value<String?>? ufDestino,
      Value<String?>? cst,
      Value<String?>? csosn,
      Value<String?>? modalidadeBc,
      Value<int?>? cfop,
      Value<double?>? aliquota,
      Value<double?>? valorPauta,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? mva,
      Value<double?>? porcentoBc,
      Value<String?>? modalidadeBcSt,
      Value<double?>? aliquotaInternaSt,
      Value<double?>? aliquotaInterestadualSt,
      Value<double?>? porcentoBcSt,
      Value<double?>? aliquotaIcmsSt,
      Value<double?>? valorPautaSt,
      Value<double?>? valorPrecoMaximoSt}) {
    return TributIcmsCustomDetsCompanion(
      id: id ?? this.id,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      ufDestino: ufDestino ?? this.ufDestino,
      cst: cst ?? this.cst,
      csosn: csosn ?? this.csosn,
      modalidadeBc: modalidadeBc ?? this.modalidadeBc,
      cfop: cfop ?? this.cfop,
      aliquota: aliquota ?? this.aliquota,
      valorPauta: valorPauta ?? this.valorPauta,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      mva: mva ?? this.mva,
      porcentoBc: porcentoBc ?? this.porcentoBc,
      modalidadeBcSt: modalidadeBcSt ?? this.modalidadeBcSt,
      aliquotaInternaSt: aliquotaInternaSt ?? this.aliquotaInternaSt,
      aliquotaInterestadualSt:
          aliquotaInterestadualSt ?? this.aliquotaInterestadualSt,
      porcentoBcSt: porcentoBcSt ?? this.porcentoBcSt,
      aliquotaIcmsSt: aliquotaIcmsSt ?? this.aliquotaIcmsSt,
      valorPautaSt: valorPautaSt ?? this.valorPautaSt,
      valorPrecoMaximoSt: valorPrecoMaximoSt ?? this.valorPrecoMaximoSt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] =
          Variable<int>(idTributIcmsCustomCab.value);
    }
    if (ufDestino.present) {
      map['uf_destino'] = Variable<String>(ufDestino.value);
    }
    if (cst.present) {
      map['cst'] = Variable<String>(cst.value);
    }
    if (csosn.present) {
      map['csosn'] = Variable<String>(csosn.value);
    }
    if (modalidadeBc.present) {
      map['modalidade_bc'] = Variable<String>(modalidadeBc.value);
    }
    if (cfop.present) {
      map['cfop'] = Variable<int>(cfop.value);
    }
    if (aliquota.present) {
      map['aliquota'] = Variable<double>(aliquota.value);
    }
    if (valorPauta.present) {
      map['valor_pauta'] = Variable<double>(valorPauta.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (mva.present) {
      map['mva'] = Variable<double>(mva.value);
    }
    if (porcentoBc.present) {
      map['porcento_bc'] = Variable<double>(porcentoBc.value);
    }
    if (modalidadeBcSt.present) {
      map['modalidade_bc_st'] = Variable<String>(modalidadeBcSt.value);
    }
    if (aliquotaInternaSt.present) {
      map['aliquota_interna_st'] = Variable<double>(aliquotaInternaSt.value);
    }
    if (aliquotaInterestadualSt.present) {
      map['aliquota_interestadual_st'] =
          Variable<double>(aliquotaInterestadualSt.value);
    }
    if (porcentoBcSt.present) {
      map['porcento_bc_st'] = Variable<double>(porcentoBcSt.value);
    }
    if (aliquotaIcmsSt.present) {
      map['aliquota_icms_st'] = Variable<double>(aliquotaIcmsSt.value);
    }
    if (valorPautaSt.present) {
      map['valor_pauta_st'] = Variable<double>(valorPautaSt.value);
    }
    if (valorPrecoMaximoSt.present) {
      map['valor_preco_maximo_st'] = Variable<double>(valorPrecoMaximoSt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomDetsCompanion(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('ufDestino: $ufDestino, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('modalidadeBc: $modalidadeBc, ')
          ..write('cfop: $cfop, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorPauta: $valorPauta, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('mva: $mva, ')
          ..write('porcentoBc: $porcentoBc, ')
          ..write('modalidadeBcSt: $modalidadeBcSt, ')
          ..write('aliquotaInternaSt: $aliquotaInternaSt, ')
          ..write('aliquotaInterestadualSt: $aliquotaInterestadualSt, ')
          ..write('porcentoBcSt: $porcentoBcSt, ')
          ..write('aliquotaIcmsSt: $aliquotaIcmsSt, ')
          ..write('valorPautaSt: $valorPautaSt, ')
          ..write('valorPrecoMaximoSt: $valorPrecoMaximoSt')
          ..write(')'))
        .toString();
  }
}

class $TributIcmsUfsTable extends TributIcmsUfs
    with TableInfo<$TributIcmsUfsTable, TributIcmsUf> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIcmsUfsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributConfiguraOfGtMeta =
      const VerificationMeta('idTributConfiguraOfGt');
  @override
  late final GeneratedColumn<int> idTributConfiguraOfGt = GeneratedColumn<int>(
      'id_tribut_configura_of_gt', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufDestinoMeta =
      const VerificationMeta('ufDestino');
  @override
  late final GeneratedColumn<String> ufDestino = GeneratedColumn<String>(
      'uf_destino', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cstMeta = const VerificationMeta('cst');
  @override
  late final GeneratedColumn<String> cst = GeneratedColumn<String>(
      'cst', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _csosnMeta = const VerificationMeta('csosn');
  @override
  late final GeneratedColumn<String> csosn = GeneratedColumn<String>(
      'csosn', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBcMeta =
      const VerificationMeta('modalidadeBc');
  @override
  late final GeneratedColumn<String> modalidadeBc = GeneratedColumn<String>(
      'modalidade_bc', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cfopMeta = const VerificationMeta('cfop');
  @override
  late final GeneratedColumn<int> cfop = GeneratedColumn<int>(
      'cfop', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaMeta =
      const VerificationMeta('aliquota');
  @override
  late final GeneratedColumn<double> aliquota = GeneratedColumn<double>(
      'aliquota', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaMeta =
      const VerificationMeta('valorPauta');
  @override
  late final GeneratedColumn<double> valorPauta = GeneratedColumn<double>(
      'valor_pauta', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _mvaMeta = const VerificationMeta('mva');
  @override
  late final GeneratedColumn<double> mva = GeneratedColumn<double>(
      'mva', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _porcentoBcMeta =
      const VerificationMeta('porcentoBc');
  @override
  late final GeneratedColumn<double> porcentoBc = GeneratedColumn<double>(
      'porcento_bc', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBcStMeta =
      const VerificationMeta('modalidadeBcSt');
  @override
  late final GeneratedColumn<String> modalidadeBcSt = GeneratedColumn<String>(
      'modalidade_bc_st', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aliquotaInternaStMeta =
      const VerificationMeta('aliquotaInternaSt');
  @override
  late final GeneratedColumn<double> aliquotaInternaSt =
      GeneratedColumn<double>('aliquota_interna_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaInterestadualStMeta =
      const VerificationMeta('aliquotaInterestadualSt');
  @override
  late final GeneratedColumn<double> aliquotaInterestadualSt =
      GeneratedColumn<double>('aliquota_interestadual_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _porcentoBcStMeta =
      const VerificationMeta('porcentoBcSt');
  @override
  late final GeneratedColumn<double> porcentoBcSt = GeneratedColumn<double>(
      'porcento_bc_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsStMeta =
      const VerificationMeta('aliquotaIcmsSt');
  @override
  late final GeneratedColumn<double> aliquotaIcmsSt = GeneratedColumn<double>(
      'aliquota_icms_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaStMeta =
      const VerificationMeta('valorPautaSt');
  @override
  late final GeneratedColumn<double> valorPautaSt = GeneratedColumn<double>(
      'valor_pauta_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoStMeta =
      const VerificationMeta('valorPrecoMaximoSt');
  @override
  late final GeneratedColumn<double> valorPrecoMaximoSt =
      GeneratedColumn<double>('valor_preco_maximo_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributConfiguraOfGt,
        ufDestino,
        cst,
        csosn,
        modalidadeBc,
        cfop,
        aliquota,
        valorPauta,
        valorPrecoMaximo,
        mva,
        porcentoBc,
        modalidadeBcSt,
        aliquotaInternaSt,
        aliquotaInterestadualSt,
        porcentoBcSt,
        aliquotaIcmsSt,
        valorPautaSt,
        valorPrecoMaximoSt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_icms_uf';
  @override
  VerificationContext validateIntegrity(Insertable<TributIcmsUf> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_configura_of_gt')) {
      context.handle(
          _idTributConfiguraOfGtMeta,
          idTributConfiguraOfGt.isAcceptableOrUnknown(
              data['id_tribut_configura_of_gt']!, _idTributConfiguraOfGtMeta));
    }
    if (data.containsKey('uf_destino')) {
      context.handle(_ufDestinoMeta,
          ufDestino.isAcceptableOrUnknown(data['uf_destino']!, _ufDestinoMeta));
    }
    if (data.containsKey('cst')) {
      context.handle(
          _cstMeta, cst.isAcceptableOrUnknown(data['cst']!, _cstMeta));
    }
    if (data.containsKey('csosn')) {
      context.handle(
          _csosnMeta, csosn.isAcceptableOrUnknown(data['csosn']!, _csosnMeta));
    }
    if (data.containsKey('modalidade_bc')) {
      context.handle(
          _modalidadeBcMeta,
          modalidadeBc.isAcceptableOrUnknown(
              data['modalidade_bc']!, _modalidadeBcMeta));
    }
    if (data.containsKey('cfop')) {
      context.handle(
          _cfopMeta, cfop.isAcceptableOrUnknown(data['cfop']!, _cfopMeta));
    }
    if (data.containsKey('aliquota')) {
      context.handle(_aliquotaMeta,
          aliquota.isAcceptableOrUnknown(data['aliquota']!, _aliquotaMeta));
    }
    if (data.containsKey('valor_pauta')) {
      context.handle(
          _valorPautaMeta,
          valorPauta.isAcceptableOrUnknown(
              data['valor_pauta']!, _valorPautaMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('mva')) {
      context.handle(
          _mvaMeta, mva.isAcceptableOrUnknown(data['mva']!, _mvaMeta));
    }
    if (data.containsKey('porcento_bc')) {
      context.handle(
          _porcentoBcMeta,
          porcentoBc.isAcceptableOrUnknown(
              data['porcento_bc']!, _porcentoBcMeta));
    }
    if (data.containsKey('modalidade_bc_st')) {
      context.handle(
          _modalidadeBcStMeta,
          modalidadeBcSt.isAcceptableOrUnknown(
              data['modalidade_bc_st']!, _modalidadeBcStMeta));
    }
    if (data.containsKey('aliquota_interna_st')) {
      context.handle(
          _aliquotaInternaStMeta,
          aliquotaInternaSt.isAcceptableOrUnknown(
              data['aliquota_interna_st']!, _aliquotaInternaStMeta));
    }
    if (data.containsKey('aliquota_interestadual_st')) {
      context.handle(
          _aliquotaInterestadualStMeta,
          aliquotaInterestadualSt.isAcceptableOrUnknown(
              data['aliquota_interestadual_st']!,
              _aliquotaInterestadualStMeta));
    }
    if (data.containsKey('porcento_bc_st')) {
      context.handle(
          _porcentoBcStMeta,
          porcentoBcSt.isAcceptableOrUnknown(
              data['porcento_bc_st']!, _porcentoBcStMeta));
    }
    if (data.containsKey('aliquota_icms_st')) {
      context.handle(
          _aliquotaIcmsStMeta,
          aliquotaIcmsSt.isAcceptableOrUnknown(
              data['aliquota_icms_st']!, _aliquotaIcmsStMeta));
    }
    if (data.containsKey('valor_pauta_st')) {
      context.handle(
          _valorPautaStMeta,
          valorPautaSt.isAcceptableOrUnknown(
              data['valor_pauta_st']!, _valorPautaStMeta));
    }
    if (data.containsKey('valor_preco_maximo_st')) {
      context.handle(
          _valorPrecoMaximoStMeta,
          valorPrecoMaximoSt.isAcceptableOrUnknown(
              data['valor_preco_maximo_st']!, _valorPrecoMaximoStMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIcmsUf map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIcmsUf(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributConfiguraOfGt: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_configura_of_gt']),
      ufDestino: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_destino']),
      cst: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst']),
      csosn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}csosn']),
      modalidadeBc: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modalidade_bc']),
      cfop: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop']),
      aliquota: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota']),
      valorPauta: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pauta']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      mva: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}mva']),
      porcentoBc: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_bc']),
      modalidadeBcSt: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}modalidade_bc_st']),
      aliquotaInternaSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_interna_st']),
      aliquotaInterestadualSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}aliquota_interestadual_st']),
      porcentoBcSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_bc_st']),
      aliquotaIcmsSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_icms_st']),
      valorPautaSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pauta_st']),
      valorPrecoMaximoSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo_st']),
    );
  }

  @override
  $TributIcmsUfsTable createAlias(String alias) {
    return $TributIcmsUfsTable(attachedDatabase, alias);
  }
}

class TributIcmsUf extends DataClass implements Insertable<TributIcmsUf> {
  final int? id;
  final int? idTributConfiguraOfGt;
  final String? ufDestino;
  final String? cst;
  final String? csosn;
  final String? modalidadeBc;
  final int? cfop;
  final double? aliquota;
  final double? valorPauta;
  final double? valorPrecoMaximo;
  final double? mva;
  final double? porcentoBc;
  final String? modalidadeBcSt;
  final double? aliquotaInternaSt;
  final double? aliquotaInterestadualSt;
  final double? porcentoBcSt;
  final double? aliquotaIcmsSt;
  final double? valorPautaSt;
  final double? valorPrecoMaximoSt;
  const TributIcmsUf(
      {this.id,
      this.idTributConfiguraOfGt,
      this.ufDestino,
      this.cst,
      this.csosn,
      this.modalidadeBc,
      this.cfop,
      this.aliquota,
      this.valorPauta,
      this.valorPrecoMaximo,
      this.mva,
      this.porcentoBc,
      this.modalidadeBcSt,
      this.aliquotaInternaSt,
      this.aliquotaInterestadualSt,
      this.porcentoBcSt,
      this.aliquotaIcmsSt,
      this.valorPautaSt,
      this.valorPrecoMaximoSt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributConfiguraOfGt != null) {
      map['id_tribut_configura_of_gt'] = Variable<int>(idTributConfiguraOfGt);
    }
    if (!nullToAbsent || ufDestino != null) {
      map['uf_destino'] = Variable<String>(ufDestino);
    }
    if (!nullToAbsent || cst != null) {
      map['cst'] = Variable<String>(cst);
    }
    if (!nullToAbsent || csosn != null) {
      map['csosn'] = Variable<String>(csosn);
    }
    if (!nullToAbsent || modalidadeBc != null) {
      map['modalidade_bc'] = Variable<String>(modalidadeBc);
    }
    if (!nullToAbsent || cfop != null) {
      map['cfop'] = Variable<int>(cfop);
    }
    if (!nullToAbsent || aliquota != null) {
      map['aliquota'] = Variable<double>(aliquota);
    }
    if (!nullToAbsent || valorPauta != null) {
      map['valor_pauta'] = Variable<double>(valorPauta);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || mva != null) {
      map['mva'] = Variable<double>(mva);
    }
    if (!nullToAbsent || porcentoBc != null) {
      map['porcento_bc'] = Variable<double>(porcentoBc);
    }
    if (!nullToAbsent || modalidadeBcSt != null) {
      map['modalidade_bc_st'] = Variable<String>(modalidadeBcSt);
    }
    if (!nullToAbsent || aliquotaInternaSt != null) {
      map['aliquota_interna_st'] = Variable<double>(aliquotaInternaSt);
    }
    if (!nullToAbsent || aliquotaInterestadualSt != null) {
      map['aliquota_interestadual_st'] =
          Variable<double>(aliquotaInterestadualSt);
    }
    if (!nullToAbsent || porcentoBcSt != null) {
      map['porcento_bc_st'] = Variable<double>(porcentoBcSt);
    }
    if (!nullToAbsent || aliquotaIcmsSt != null) {
      map['aliquota_icms_st'] = Variable<double>(aliquotaIcmsSt);
    }
    if (!nullToAbsent || valorPautaSt != null) {
      map['valor_pauta_st'] = Variable<double>(valorPautaSt);
    }
    if (!nullToAbsent || valorPrecoMaximoSt != null) {
      map['valor_preco_maximo_st'] = Variable<double>(valorPrecoMaximoSt);
    }
    return map;
  }

  factory TributIcmsUf.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIcmsUf(
      id: serializer.fromJson<int?>(json['id']),
      idTributConfiguraOfGt:
          serializer.fromJson<int?>(json['idTributConfiguraOfGt']),
      ufDestino: serializer.fromJson<String?>(json['ufDestino']),
      cst: serializer.fromJson<String?>(json['cst']),
      csosn: serializer.fromJson<String?>(json['csosn']),
      modalidadeBc: serializer.fromJson<String?>(json['modalidadeBc']),
      cfop: serializer.fromJson<int?>(json['cfop']),
      aliquota: serializer.fromJson<double?>(json['aliquota']),
      valorPauta: serializer.fromJson<double?>(json['valorPauta']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      mva: serializer.fromJson<double?>(json['mva']),
      porcentoBc: serializer.fromJson<double?>(json['porcentoBc']),
      modalidadeBcSt: serializer.fromJson<String?>(json['modalidadeBcSt']),
      aliquotaInternaSt:
          serializer.fromJson<double?>(json['aliquotaInternaSt']),
      aliquotaInterestadualSt:
          serializer.fromJson<double?>(json['aliquotaInterestadualSt']),
      porcentoBcSt: serializer.fromJson<double?>(json['porcentoBcSt']),
      aliquotaIcmsSt: serializer.fromJson<double?>(json['aliquotaIcmsSt']),
      valorPautaSt: serializer.fromJson<double?>(json['valorPautaSt']),
      valorPrecoMaximoSt:
          serializer.fromJson<double?>(json['valorPrecoMaximoSt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributConfiguraOfGt': serializer.toJson<int?>(idTributConfiguraOfGt),
      'ufDestino': serializer.toJson<String?>(ufDestino),
      'cst': serializer.toJson<String?>(cst),
      'csosn': serializer.toJson<String?>(csosn),
      'modalidadeBc': serializer.toJson<String?>(modalidadeBc),
      'cfop': serializer.toJson<int?>(cfop),
      'aliquota': serializer.toJson<double?>(aliquota),
      'valorPauta': serializer.toJson<double?>(valorPauta),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'mva': serializer.toJson<double?>(mva),
      'porcentoBc': serializer.toJson<double?>(porcentoBc),
      'modalidadeBcSt': serializer.toJson<String?>(modalidadeBcSt),
      'aliquotaInternaSt': serializer.toJson<double?>(aliquotaInternaSt),
      'aliquotaInterestadualSt':
          serializer.toJson<double?>(aliquotaInterestadualSt),
      'porcentoBcSt': serializer.toJson<double?>(porcentoBcSt),
      'aliquotaIcmsSt': serializer.toJson<double?>(aliquotaIcmsSt),
      'valorPautaSt': serializer.toJson<double?>(valorPautaSt),
      'valorPrecoMaximoSt': serializer.toJson<double?>(valorPrecoMaximoSt),
    };
  }

  TributIcmsUf copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributConfiguraOfGt = const Value.absent(),
          Value<String?> ufDestino = const Value.absent(),
          Value<String?> cst = const Value.absent(),
          Value<String?> csosn = const Value.absent(),
          Value<String?> modalidadeBc = const Value.absent(),
          Value<int?> cfop = const Value.absent(),
          Value<double?> aliquota = const Value.absent(),
          Value<double?> valorPauta = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> mva = const Value.absent(),
          Value<double?> porcentoBc = const Value.absent(),
          Value<String?> modalidadeBcSt = const Value.absent(),
          Value<double?> aliquotaInternaSt = const Value.absent(),
          Value<double?> aliquotaInterestadualSt = const Value.absent(),
          Value<double?> porcentoBcSt = const Value.absent(),
          Value<double?> aliquotaIcmsSt = const Value.absent(),
          Value<double?> valorPautaSt = const Value.absent(),
          Value<double?> valorPrecoMaximoSt = const Value.absent()}) =>
      TributIcmsUf(
        id: id.present ? id.value : this.id,
        idTributConfiguraOfGt: idTributConfiguraOfGt.present
            ? idTributConfiguraOfGt.value
            : this.idTributConfiguraOfGt,
        ufDestino: ufDestino.present ? ufDestino.value : this.ufDestino,
        cst: cst.present ? cst.value : this.cst,
        csosn: csosn.present ? csosn.value : this.csosn,
        modalidadeBc:
            modalidadeBc.present ? modalidadeBc.value : this.modalidadeBc,
        cfop: cfop.present ? cfop.value : this.cfop,
        aliquota: aliquota.present ? aliquota.value : this.aliquota,
        valorPauta: valorPauta.present ? valorPauta.value : this.valorPauta,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        mva: mva.present ? mva.value : this.mva,
        porcentoBc: porcentoBc.present ? porcentoBc.value : this.porcentoBc,
        modalidadeBcSt:
            modalidadeBcSt.present ? modalidadeBcSt.value : this.modalidadeBcSt,
        aliquotaInternaSt: aliquotaInternaSt.present
            ? aliquotaInternaSt.value
            : this.aliquotaInternaSt,
        aliquotaInterestadualSt: aliquotaInterestadualSt.present
            ? aliquotaInterestadualSt.value
            : this.aliquotaInterestadualSt,
        porcentoBcSt:
            porcentoBcSt.present ? porcentoBcSt.value : this.porcentoBcSt,
        aliquotaIcmsSt:
            aliquotaIcmsSt.present ? aliquotaIcmsSt.value : this.aliquotaIcmsSt,
        valorPautaSt:
            valorPautaSt.present ? valorPautaSt.value : this.valorPautaSt,
        valorPrecoMaximoSt: valorPrecoMaximoSt.present
            ? valorPrecoMaximoSt.value
            : this.valorPrecoMaximoSt,
      );
  @override
  String toString() {
    return (StringBuffer('TributIcmsUf(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('ufDestino: $ufDestino, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('modalidadeBc: $modalidadeBc, ')
          ..write('cfop: $cfop, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorPauta: $valorPauta, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('mva: $mva, ')
          ..write('porcentoBc: $porcentoBc, ')
          ..write('modalidadeBcSt: $modalidadeBcSt, ')
          ..write('aliquotaInternaSt: $aliquotaInternaSt, ')
          ..write('aliquotaInterestadualSt: $aliquotaInterestadualSt, ')
          ..write('porcentoBcSt: $porcentoBcSt, ')
          ..write('aliquotaIcmsSt: $aliquotaIcmsSt, ')
          ..write('valorPautaSt: $valorPautaSt, ')
          ..write('valorPrecoMaximoSt: $valorPrecoMaximoSt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributConfiguraOfGt,
      ufDestino,
      cst,
      csosn,
      modalidadeBc,
      cfop,
      aliquota,
      valorPauta,
      valorPrecoMaximo,
      mva,
      porcentoBc,
      modalidadeBcSt,
      aliquotaInternaSt,
      aliquotaInterestadualSt,
      porcentoBcSt,
      aliquotaIcmsSt,
      valorPautaSt,
      valorPrecoMaximoSt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIcmsUf &&
          other.id == this.id &&
          other.idTributConfiguraOfGt == this.idTributConfiguraOfGt &&
          other.ufDestino == this.ufDestino &&
          other.cst == this.cst &&
          other.csosn == this.csosn &&
          other.modalidadeBc == this.modalidadeBc &&
          other.cfop == this.cfop &&
          other.aliquota == this.aliquota &&
          other.valorPauta == this.valorPauta &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.mva == this.mva &&
          other.porcentoBc == this.porcentoBc &&
          other.modalidadeBcSt == this.modalidadeBcSt &&
          other.aliquotaInternaSt == this.aliquotaInternaSt &&
          other.aliquotaInterestadualSt == this.aliquotaInterestadualSt &&
          other.porcentoBcSt == this.porcentoBcSt &&
          other.aliquotaIcmsSt == this.aliquotaIcmsSt &&
          other.valorPautaSt == this.valorPautaSt &&
          other.valorPrecoMaximoSt == this.valorPrecoMaximoSt);
}

class TributIcmsUfsCompanion extends UpdateCompanion<TributIcmsUf> {
  final Value<int?> id;
  final Value<int?> idTributConfiguraOfGt;
  final Value<String?> ufDestino;
  final Value<String?> cst;
  final Value<String?> csosn;
  final Value<String?> modalidadeBc;
  final Value<int?> cfop;
  final Value<double?> aliquota;
  final Value<double?> valorPauta;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> mva;
  final Value<double?> porcentoBc;
  final Value<String?> modalidadeBcSt;
  final Value<double?> aliquotaInternaSt;
  final Value<double?> aliquotaInterestadualSt;
  final Value<double?> porcentoBcSt;
  final Value<double?> aliquotaIcmsSt;
  final Value<double?> valorPautaSt;
  final Value<double?> valorPrecoMaximoSt;
  const TributIcmsUfsCompanion({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.ufDestino = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.modalidadeBc = const Value.absent(),
    this.cfop = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorPauta = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.mva = const Value.absent(),
    this.porcentoBc = const Value.absent(),
    this.modalidadeBcSt = const Value.absent(),
    this.aliquotaInternaSt = const Value.absent(),
    this.aliquotaInterestadualSt = const Value.absent(),
    this.porcentoBcSt = const Value.absent(),
    this.aliquotaIcmsSt = const Value.absent(),
    this.valorPautaSt = const Value.absent(),
    this.valorPrecoMaximoSt = const Value.absent(),
  });
  TributIcmsUfsCompanion.insert({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.ufDestino = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.modalidadeBc = const Value.absent(),
    this.cfop = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorPauta = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.mva = const Value.absent(),
    this.porcentoBc = const Value.absent(),
    this.modalidadeBcSt = const Value.absent(),
    this.aliquotaInternaSt = const Value.absent(),
    this.aliquotaInterestadualSt = const Value.absent(),
    this.porcentoBcSt = const Value.absent(),
    this.aliquotaIcmsSt = const Value.absent(),
    this.valorPautaSt = const Value.absent(),
    this.valorPrecoMaximoSt = const Value.absent(),
  });
  static Insertable<TributIcmsUf> custom({
    Expression<int>? id,
    Expression<int>? idTributConfiguraOfGt,
    Expression<String>? ufDestino,
    Expression<String>? cst,
    Expression<String>? csosn,
    Expression<String>? modalidadeBc,
    Expression<int>? cfop,
    Expression<double>? aliquota,
    Expression<double>? valorPauta,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? mva,
    Expression<double>? porcentoBc,
    Expression<String>? modalidadeBcSt,
    Expression<double>? aliquotaInternaSt,
    Expression<double>? aliquotaInterestadualSt,
    Expression<double>? porcentoBcSt,
    Expression<double>? aliquotaIcmsSt,
    Expression<double>? valorPautaSt,
    Expression<double>? valorPrecoMaximoSt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributConfiguraOfGt != null)
        'id_tribut_configura_of_gt': idTributConfiguraOfGt,
      if (ufDestino != null) 'uf_destino': ufDestino,
      if (cst != null) 'cst': cst,
      if (csosn != null) 'csosn': csosn,
      if (modalidadeBc != null) 'modalidade_bc': modalidadeBc,
      if (cfop != null) 'cfop': cfop,
      if (aliquota != null) 'aliquota': aliquota,
      if (valorPauta != null) 'valor_pauta': valorPauta,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (mva != null) 'mva': mva,
      if (porcentoBc != null) 'porcento_bc': porcentoBc,
      if (modalidadeBcSt != null) 'modalidade_bc_st': modalidadeBcSt,
      if (aliquotaInternaSt != null) 'aliquota_interna_st': aliquotaInternaSt,
      if (aliquotaInterestadualSt != null)
        'aliquota_interestadual_st': aliquotaInterestadualSt,
      if (porcentoBcSt != null) 'porcento_bc_st': porcentoBcSt,
      if (aliquotaIcmsSt != null) 'aliquota_icms_st': aliquotaIcmsSt,
      if (valorPautaSt != null) 'valor_pauta_st': valorPautaSt,
      if (valorPrecoMaximoSt != null)
        'valor_preco_maximo_st': valorPrecoMaximoSt,
    });
  }

  TributIcmsUfsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributConfiguraOfGt,
      Value<String?>? ufDestino,
      Value<String?>? cst,
      Value<String?>? csosn,
      Value<String?>? modalidadeBc,
      Value<int?>? cfop,
      Value<double?>? aliquota,
      Value<double?>? valorPauta,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? mva,
      Value<double?>? porcentoBc,
      Value<String?>? modalidadeBcSt,
      Value<double?>? aliquotaInternaSt,
      Value<double?>? aliquotaInterestadualSt,
      Value<double?>? porcentoBcSt,
      Value<double?>? aliquotaIcmsSt,
      Value<double?>? valorPautaSt,
      Value<double?>? valorPrecoMaximoSt}) {
    return TributIcmsUfsCompanion(
      id: id ?? this.id,
      idTributConfiguraOfGt:
          idTributConfiguraOfGt ?? this.idTributConfiguraOfGt,
      ufDestino: ufDestino ?? this.ufDestino,
      cst: cst ?? this.cst,
      csosn: csosn ?? this.csosn,
      modalidadeBc: modalidadeBc ?? this.modalidadeBc,
      cfop: cfop ?? this.cfop,
      aliquota: aliquota ?? this.aliquota,
      valorPauta: valorPauta ?? this.valorPauta,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      mva: mva ?? this.mva,
      porcentoBc: porcentoBc ?? this.porcentoBc,
      modalidadeBcSt: modalidadeBcSt ?? this.modalidadeBcSt,
      aliquotaInternaSt: aliquotaInternaSt ?? this.aliquotaInternaSt,
      aliquotaInterestadualSt:
          aliquotaInterestadualSt ?? this.aliquotaInterestadualSt,
      porcentoBcSt: porcentoBcSt ?? this.porcentoBcSt,
      aliquotaIcmsSt: aliquotaIcmsSt ?? this.aliquotaIcmsSt,
      valorPautaSt: valorPautaSt ?? this.valorPautaSt,
      valorPrecoMaximoSt: valorPrecoMaximoSt ?? this.valorPrecoMaximoSt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributConfiguraOfGt.present) {
      map['id_tribut_configura_of_gt'] =
          Variable<int>(idTributConfiguraOfGt.value);
    }
    if (ufDestino.present) {
      map['uf_destino'] = Variable<String>(ufDestino.value);
    }
    if (cst.present) {
      map['cst'] = Variable<String>(cst.value);
    }
    if (csosn.present) {
      map['csosn'] = Variable<String>(csosn.value);
    }
    if (modalidadeBc.present) {
      map['modalidade_bc'] = Variable<String>(modalidadeBc.value);
    }
    if (cfop.present) {
      map['cfop'] = Variable<int>(cfop.value);
    }
    if (aliquota.present) {
      map['aliquota'] = Variable<double>(aliquota.value);
    }
    if (valorPauta.present) {
      map['valor_pauta'] = Variable<double>(valorPauta.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (mva.present) {
      map['mva'] = Variable<double>(mva.value);
    }
    if (porcentoBc.present) {
      map['porcento_bc'] = Variable<double>(porcentoBc.value);
    }
    if (modalidadeBcSt.present) {
      map['modalidade_bc_st'] = Variable<String>(modalidadeBcSt.value);
    }
    if (aliquotaInternaSt.present) {
      map['aliquota_interna_st'] = Variable<double>(aliquotaInternaSt.value);
    }
    if (aliquotaInterestadualSt.present) {
      map['aliquota_interestadual_st'] =
          Variable<double>(aliquotaInterestadualSt.value);
    }
    if (porcentoBcSt.present) {
      map['porcento_bc_st'] = Variable<double>(porcentoBcSt.value);
    }
    if (aliquotaIcmsSt.present) {
      map['aliquota_icms_st'] = Variable<double>(aliquotaIcmsSt.value);
    }
    if (valorPautaSt.present) {
      map['valor_pauta_st'] = Variable<double>(valorPautaSt.value);
    }
    if (valorPrecoMaximoSt.present) {
      map['valor_preco_maximo_st'] = Variable<double>(valorPrecoMaximoSt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIcmsUfsCompanion(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('ufDestino: $ufDestino, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('modalidadeBc: $modalidadeBc, ')
          ..write('cfop: $cfop, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorPauta: $valorPauta, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('mva: $mva, ')
          ..write('porcentoBc: $porcentoBc, ')
          ..write('modalidadeBcSt: $modalidadeBcSt, ')
          ..write('aliquotaInternaSt: $aliquotaInternaSt, ')
          ..write('aliquotaInterestadualSt: $aliquotaInterestadualSt, ')
          ..write('porcentoBcSt: $porcentoBcSt, ')
          ..write('aliquotaIcmsSt: $aliquotaIcmsSt, ')
          ..write('valorPautaSt: $valorPautaSt, ')
          ..write('valorPrecoMaximoSt: $valorPrecoMaximoSt')
          ..write(')'))
        .toString();
  }
}

class $TributPissTable extends TributPiss
    with TableInfo<$TributPissTable, TributPis> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributPissTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributConfiguraOfGtMeta =
      const VerificationMeta('idTributConfiguraOfGt');
  @override
  late final GeneratedColumn<int> idTributConfiguraOfGt = GeneratedColumn<int>(
      'id_tribut_configura_of_gt', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cstPisMeta = const VerificationMeta('cstPis');
  @override
  late final GeneratedColumn<String> cstPis = GeneratedColumn<String>(
      'cst_pis', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBaseCalculoMeta =
      const VerificationMeta('modalidadeBaseCalculo');
  @override
  late final GeneratedColumn<String> modalidadeBaseCalculo =
      GeneratedColumn<String>('modalidade_base_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _efdTabela435Meta =
      const VerificationMeta('efdTabela435');
  @override
  late final GeneratedColumn<String> efdTabela435 = GeneratedColumn<String>(
      'efd_tabela_435', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _porcentoBaseCalculoMeta =
      const VerificationMeta('porcentoBaseCalculo');
  @override
  late final GeneratedColumn<double> porcentoBaseCalculo =
      GeneratedColumn<double>('porcento_base_calculo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaPorcentoMeta =
      const VerificationMeta('aliquotaPorcento');
  @override
  late final GeneratedColumn<double> aliquotaPorcento = GeneratedColumn<double>(
      'aliquota_porcento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaUnidadeMeta =
      const VerificationMeta('aliquotaUnidade');
  @override
  late final GeneratedColumn<double> aliquotaUnidade = GeneratedColumn<double>(
      'aliquota_unidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaFiscalMeta =
      const VerificationMeta('valorPautaFiscal');
  @override
  late final GeneratedColumn<double> valorPautaFiscal = GeneratedColumn<double>(
      'valor_pauta_fiscal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributConfiguraOfGt,
        cstPis,
        modalidadeBaseCalculo,
        efdTabela435,
        porcentoBaseCalculo,
        aliquotaPorcento,
        aliquotaUnidade,
        valorPrecoMaximo,
        valorPautaFiscal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_pis';
  @override
  VerificationContext validateIntegrity(Insertable<TributPis> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_configura_of_gt')) {
      context.handle(
          _idTributConfiguraOfGtMeta,
          idTributConfiguraOfGt.isAcceptableOrUnknown(
              data['id_tribut_configura_of_gt']!, _idTributConfiguraOfGtMeta));
    }
    if (data.containsKey('cst_pis')) {
      context.handle(_cstPisMeta,
          cstPis.isAcceptableOrUnknown(data['cst_pis']!, _cstPisMeta));
    }
    if (data.containsKey('modalidade_base_calculo')) {
      context.handle(
          _modalidadeBaseCalculoMeta,
          modalidadeBaseCalculo.isAcceptableOrUnknown(
              data['modalidade_base_calculo']!, _modalidadeBaseCalculoMeta));
    }
    if (data.containsKey('efd_tabela_435')) {
      context.handle(
          _efdTabela435Meta,
          efdTabela435.isAcceptableOrUnknown(
              data['efd_tabela_435']!, _efdTabela435Meta));
    }
    if (data.containsKey('porcento_base_calculo')) {
      context.handle(
          _porcentoBaseCalculoMeta,
          porcentoBaseCalculo.isAcceptableOrUnknown(
              data['porcento_base_calculo']!, _porcentoBaseCalculoMeta));
    }
    if (data.containsKey('aliquota_porcento')) {
      context.handle(
          _aliquotaPorcentoMeta,
          aliquotaPorcento.isAcceptableOrUnknown(
              data['aliquota_porcento']!, _aliquotaPorcentoMeta));
    }
    if (data.containsKey('aliquota_unidade')) {
      context.handle(
          _aliquotaUnidadeMeta,
          aliquotaUnidade.isAcceptableOrUnknown(
              data['aliquota_unidade']!, _aliquotaUnidadeMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('valor_pauta_fiscal')) {
      context.handle(
          _valorPautaFiscalMeta,
          valorPautaFiscal.isAcceptableOrUnknown(
              data['valor_pauta_fiscal']!, _valorPautaFiscalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributPis map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributPis(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributConfiguraOfGt: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_configura_of_gt']),
      cstPis: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst_pis']),
      modalidadeBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_base_calculo']),
      efdTabela435: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}efd_tabela_435']),
      porcentoBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}porcento_base_calculo']),
      aliquotaPorcento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_porcento']),
      aliquotaUnidade: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_unidade']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      valorPautaFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_pauta_fiscal']),
    );
  }

  @override
  $TributPissTable createAlias(String alias) {
    return $TributPissTable(attachedDatabase, alias);
  }
}

class TributPis extends DataClass implements Insertable<TributPis> {
  final int? id;
  final int? idTributConfiguraOfGt;
  final String? cstPis;
  final String? modalidadeBaseCalculo;
  final String? efdTabela435;
  final double? porcentoBaseCalculo;
  final double? aliquotaPorcento;
  final double? aliquotaUnidade;
  final double? valorPrecoMaximo;
  final double? valorPautaFiscal;
  const TributPis(
      {this.id,
      this.idTributConfiguraOfGt,
      this.cstPis,
      this.modalidadeBaseCalculo,
      this.efdTabela435,
      this.porcentoBaseCalculo,
      this.aliquotaPorcento,
      this.aliquotaUnidade,
      this.valorPrecoMaximo,
      this.valorPautaFiscal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributConfiguraOfGt != null) {
      map['id_tribut_configura_of_gt'] = Variable<int>(idTributConfiguraOfGt);
    }
    if (!nullToAbsent || cstPis != null) {
      map['cst_pis'] = Variable<String>(cstPis);
    }
    if (!nullToAbsent || modalidadeBaseCalculo != null) {
      map['modalidade_base_calculo'] = Variable<String>(modalidadeBaseCalculo);
    }
    if (!nullToAbsent || efdTabela435 != null) {
      map['efd_tabela_435'] = Variable<String>(efdTabela435);
    }
    if (!nullToAbsent || porcentoBaseCalculo != null) {
      map['porcento_base_calculo'] = Variable<double>(porcentoBaseCalculo);
    }
    if (!nullToAbsent || aliquotaPorcento != null) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento);
    }
    if (!nullToAbsent || aliquotaUnidade != null) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || valorPautaFiscal != null) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal);
    }
    return map;
  }

  factory TributPis.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributPis(
      id: serializer.fromJson<int?>(json['id']),
      idTributConfiguraOfGt:
          serializer.fromJson<int?>(json['idTributConfiguraOfGt']),
      cstPis: serializer.fromJson<String?>(json['cstPis']),
      modalidadeBaseCalculo:
          serializer.fromJson<String?>(json['modalidadeBaseCalculo']),
      efdTabela435: serializer.fromJson<String?>(json['efdTabela435']),
      porcentoBaseCalculo:
          serializer.fromJson<double?>(json['porcentoBaseCalculo']),
      aliquotaPorcento: serializer.fromJson<double?>(json['aliquotaPorcento']),
      aliquotaUnidade: serializer.fromJson<double?>(json['aliquotaUnidade']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      valorPautaFiscal: serializer.fromJson<double?>(json['valorPautaFiscal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributConfiguraOfGt': serializer.toJson<int?>(idTributConfiguraOfGt),
      'cstPis': serializer.toJson<String?>(cstPis),
      'modalidadeBaseCalculo':
          serializer.toJson<String?>(modalidadeBaseCalculo),
      'efdTabela435': serializer.toJson<String?>(efdTabela435),
      'porcentoBaseCalculo': serializer.toJson<double?>(porcentoBaseCalculo),
      'aliquotaPorcento': serializer.toJson<double?>(aliquotaPorcento),
      'aliquotaUnidade': serializer.toJson<double?>(aliquotaUnidade),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'valorPautaFiscal': serializer.toJson<double?>(valorPautaFiscal),
    };
  }

  TributPis copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributConfiguraOfGt = const Value.absent(),
          Value<String?> cstPis = const Value.absent(),
          Value<String?> modalidadeBaseCalculo = const Value.absent(),
          Value<String?> efdTabela435 = const Value.absent(),
          Value<double?> porcentoBaseCalculo = const Value.absent(),
          Value<double?> aliquotaPorcento = const Value.absent(),
          Value<double?> aliquotaUnidade = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> valorPautaFiscal = const Value.absent()}) =>
      TributPis(
        id: id.present ? id.value : this.id,
        idTributConfiguraOfGt: idTributConfiguraOfGt.present
            ? idTributConfiguraOfGt.value
            : this.idTributConfiguraOfGt,
        cstPis: cstPis.present ? cstPis.value : this.cstPis,
        modalidadeBaseCalculo: modalidadeBaseCalculo.present
            ? modalidadeBaseCalculo.value
            : this.modalidadeBaseCalculo,
        efdTabela435:
            efdTabela435.present ? efdTabela435.value : this.efdTabela435,
        porcentoBaseCalculo: porcentoBaseCalculo.present
            ? porcentoBaseCalculo.value
            : this.porcentoBaseCalculo,
        aliquotaPorcento: aliquotaPorcento.present
            ? aliquotaPorcento.value
            : this.aliquotaPorcento,
        aliquotaUnidade: aliquotaUnidade.present
            ? aliquotaUnidade.value
            : this.aliquotaUnidade,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        valorPautaFiscal: valorPautaFiscal.present
            ? valorPautaFiscal.value
            : this.valorPautaFiscal,
      );
  @override
  String toString() {
    return (StringBuffer('TributPis(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstPis: $cstPis, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('efdTabela435: $efdTabela435, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributConfiguraOfGt,
      cstPis,
      modalidadeBaseCalculo,
      efdTabela435,
      porcentoBaseCalculo,
      aliquotaPorcento,
      aliquotaUnidade,
      valorPrecoMaximo,
      valorPautaFiscal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributPis &&
          other.id == this.id &&
          other.idTributConfiguraOfGt == this.idTributConfiguraOfGt &&
          other.cstPis == this.cstPis &&
          other.modalidadeBaseCalculo == this.modalidadeBaseCalculo &&
          other.efdTabela435 == this.efdTabela435 &&
          other.porcentoBaseCalculo == this.porcentoBaseCalculo &&
          other.aliquotaPorcento == this.aliquotaPorcento &&
          other.aliquotaUnidade == this.aliquotaUnidade &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.valorPautaFiscal == this.valorPautaFiscal);
}

class TributPissCompanion extends UpdateCompanion<TributPis> {
  final Value<int?> id;
  final Value<int?> idTributConfiguraOfGt;
  final Value<String?> cstPis;
  final Value<String?> modalidadeBaseCalculo;
  final Value<String?> efdTabela435;
  final Value<double?> porcentoBaseCalculo;
  final Value<double?> aliquotaPorcento;
  final Value<double?> aliquotaUnidade;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> valorPautaFiscal;
  const TributPissCompanion({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstPis = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.efdTabela435 = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  TributPissCompanion.insert({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstPis = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.efdTabela435 = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  static Insertable<TributPis> custom({
    Expression<int>? id,
    Expression<int>? idTributConfiguraOfGt,
    Expression<String>? cstPis,
    Expression<String>? modalidadeBaseCalculo,
    Expression<String>? efdTabela435,
    Expression<double>? porcentoBaseCalculo,
    Expression<double>? aliquotaPorcento,
    Expression<double>? aliquotaUnidade,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? valorPautaFiscal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributConfiguraOfGt != null)
        'id_tribut_configura_of_gt': idTributConfiguraOfGt,
      if (cstPis != null) 'cst_pis': cstPis,
      if (modalidadeBaseCalculo != null)
        'modalidade_base_calculo': modalidadeBaseCalculo,
      if (efdTabela435 != null) 'efd_tabela_435': efdTabela435,
      if (porcentoBaseCalculo != null)
        'porcento_base_calculo': porcentoBaseCalculo,
      if (aliquotaPorcento != null) 'aliquota_porcento': aliquotaPorcento,
      if (aliquotaUnidade != null) 'aliquota_unidade': aliquotaUnidade,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (valorPautaFiscal != null) 'valor_pauta_fiscal': valorPautaFiscal,
    });
  }

  TributPissCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributConfiguraOfGt,
      Value<String?>? cstPis,
      Value<String?>? modalidadeBaseCalculo,
      Value<String?>? efdTabela435,
      Value<double?>? porcentoBaseCalculo,
      Value<double?>? aliquotaPorcento,
      Value<double?>? aliquotaUnidade,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? valorPautaFiscal}) {
    return TributPissCompanion(
      id: id ?? this.id,
      idTributConfiguraOfGt:
          idTributConfiguraOfGt ?? this.idTributConfiguraOfGt,
      cstPis: cstPis ?? this.cstPis,
      modalidadeBaseCalculo:
          modalidadeBaseCalculo ?? this.modalidadeBaseCalculo,
      efdTabela435: efdTabela435 ?? this.efdTabela435,
      porcentoBaseCalculo: porcentoBaseCalculo ?? this.porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento ?? this.aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade ?? this.aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal ?? this.valorPautaFiscal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributConfiguraOfGt.present) {
      map['id_tribut_configura_of_gt'] =
          Variable<int>(idTributConfiguraOfGt.value);
    }
    if (cstPis.present) {
      map['cst_pis'] = Variable<String>(cstPis.value);
    }
    if (modalidadeBaseCalculo.present) {
      map['modalidade_base_calculo'] =
          Variable<String>(modalidadeBaseCalculo.value);
    }
    if (efdTabela435.present) {
      map['efd_tabela_435'] = Variable<String>(efdTabela435.value);
    }
    if (porcentoBaseCalculo.present) {
      map['porcento_base_calculo'] =
          Variable<double>(porcentoBaseCalculo.value);
    }
    if (aliquotaPorcento.present) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento.value);
    }
    if (aliquotaUnidade.present) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (valorPautaFiscal.present) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributPissCompanion(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstPis: $cstPis, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('efdTabela435: $efdTabela435, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }
}

class $TributCofinssTable extends TributCofinss
    with TableInfo<$TributCofinssTable, TributCofins> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributCofinssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributConfiguraOfGtMeta =
      const VerificationMeta('idTributConfiguraOfGt');
  @override
  late final GeneratedColumn<int> idTributConfiguraOfGt = GeneratedColumn<int>(
      'id_tribut_configura_of_gt', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cstCofinsMeta =
      const VerificationMeta('cstCofins');
  @override
  late final GeneratedColumn<String> cstCofins = GeneratedColumn<String>(
      'cst_cofins', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBaseCalculoMeta =
      const VerificationMeta('modalidadeBaseCalculo');
  @override
  late final GeneratedColumn<String> modalidadeBaseCalculo =
      GeneratedColumn<String>('modalidade_base_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _efdTabela435Meta =
      const VerificationMeta('efdTabela435');
  @override
  late final GeneratedColumn<String> efdTabela435 = GeneratedColumn<String>(
      'efd_tabela_435', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _porcentoBaseCalculoMeta =
      const VerificationMeta('porcentoBaseCalculo');
  @override
  late final GeneratedColumn<double> porcentoBaseCalculo =
      GeneratedColumn<double>('porcento_base_calculo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaPorcentoMeta =
      const VerificationMeta('aliquotaPorcento');
  @override
  late final GeneratedColumn<double> aliquotaPorcento = GeneratedColumn<double>(
      'aliquota_porcento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaUnidadeMeta =
      const VerificationMeta('aliquotaUnidade');
  @override
  late final GeneratedColumn<double> aliquotaUnidade = GeneratedColumn<double>(
      'aliquota_unidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaFiscalMeta =
      const VerificationMeta('valorPautaFiscal');
  @override
  late final GeneratedColumn<double> valorPautaFiscal = GeneratedColumn<double>(
      'valor_pauta_fiscal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributConfiguraOfGt,
        cstCofins,
        modalidadeBaseCalculo,
        efdTabela435,
        porcentoBaseCalculo,
        aliquotaPorcento,
        aliquotaUnidade,
        valorPrecoMaximo,
        valorPautaFiscal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_cofins';
  @override
  VerificationContext validateIntegrity(Insertable<TributCofins> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_configura_of_gt')) {
      context.handle(
          _idTributConfiguraOfGtMeta,
          idTributConfiguraOfGt.isAcceptableOrUnknown(
              data['id_tribut_configura_of_gt']!, _idTributConfiguraOfGtMeta));
    }
    if (data.containsKey('cst_cofins')) {
      context.handle(_cstCofinsMeta,
          cstCofins.isAcceptableOrUnknown(data['cst_cofins']!, _cstCofinsMeta));
    }
    if (data.containsKey('modalidade_base_calculo')) {
      context.handle(
          _modalidadeBaseCalculoMeta,
          modalidadeBaseCalculo.isAcceptableOrUnknown(
              data['modalidade_base_calculo']!, _modalidadeBaseCalculoMeta));
    }
    if (data.containsKey('efd_tabela_435')) {
      context.handle(
          _efdTabela435Meta,
          efdTabela435.isAcceptableOrUnknown(
              data['efd_tabela_435']!, _efdTabela435Meta));
    }
    if (data.containsKey('porcento_base_calculo')) {
      context.handle(
          _porcentoBaseCalculoMeta,
          porcentoBaseCalculo.isAcceptableOrUnknown(
              data['porcento_base_calculo']!, _porcentoBaseCalculoMeta));
    }
    if (data.containsKey('aliquota_porcento')) {
      context.handle(
          _aliquotaPorcentoMeta,
          aliquotaPorcento.isAcceptableOrUnknown(
              data['aliquota_porcento']!, _aliquotaPorcentoMeta));
    }
    if (data.containsKey('aliquota_unidade')) {
      context.handle(
          _aliquotaUnidadeMeta,
          aliquotaUnidade.isAcceptableOrUnknown(
              data['aliquota_unidade']!, _aliquotaUnidadeMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('valor_pauta_fiscal')) {
      context.handle(
          _valorPautaFiscalMeta,
          valorPautaFiscal.isAcceptableOrUnknown(
              data['valor_pauta_fiscal']!, _valorPautaFiscalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributCofins map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributCofins(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributConfiguraOfGt: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_configura_of_gt']),
      cstCofins: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst_cofins']),
      modalidadeBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_base_calculo']),
      efdTabela435: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}efd_tabela_435']),
      porcentoBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}porcento_base_calculo']),
      aliquotaPorcento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_porcento']),
      aliquotaUnidade: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_unidade']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      valorPautaFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_pauta_fiscal']),
    );
  }

  @override
  $TributCofinssTable createAlias(String alias) {
    return $TributCofinssTable(attachedDatabase, alias);
  }
}

class TributCofins extends DataClass implements Insertable<TributCofins> {
  final int? id;
  final int? idTributConfiguraOfGt;
  final String? cstCofins;
  final String? modalidadeBaseCalculo;
  final String? efdTabela435;
  final double? porcentoBaseCalculo;
  final double? aliquotaPorcento;
  final double? aliquotaUnidade;
  final double? valorPrecoMaximo;
  final double? valorPautaFiscal;
  const TributCofins(
      {this.id,
      this.idTributConfiguraOfGt,
      this.cstCofins,
      this.modalidadeBaseCalculo,
      this.efdTabela435,
      this.porcentoBaseCalculo,
      this.aliquotaPorcento,
      this.aliquotaUnidade,
      this.valorPrecoMaximo,
      this.valorPautaFiscal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributConfiguraOfGt != null) {
      map['id_tribut_configura_of_gt'] = Variable<int>(idTributConfiguraOfGt);
    }
    if (!nullToAbsent || cstCofins != null) {
      map['cst_cofins'] = Variable<String>(cstCofins);
    }
    if (!nullToAbsent || modalidadeBaseCalculo != null) {
      map['modalidade_base_calculo'] = Variable<String>(modalidadeBaseCalculo);
    }
    if (!nullToAbsent || efdTabela435 != null) {
      map['efd_tabela_435'] = Variable<String>(efdTabela435);
    }
    if (!nullToAbsent || porcentoBaseCalculo != null) {
      map['porcento_base_calculo'] = Variable<double>(porcentoBaseCalculo);
    }
    if (!nullToAbsent || aliquotaPorcento != null) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento);
    }
    if (!nullToAbsent || aliquotaUnidade != null) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || valorPautaFiscal != null) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal);
    }
    return map;
  }

  factory TributCofins.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributCofins(
      id: serializer.fromJson<int?>(json['id']),
      idTributConfiguraOfGt:
          serializer.fromJson<int?>(json['idTributConfiguraOfGt']),
      cstCofins: serializer.fromJson<String?>(json['cstCofins']),
      modalidadeBaseCalculo:
          serializer.fromJson<String?>(json['modalidadeBaseCalculo']),
      efdTabela435: serializer.fromJson<String?>(json['efdTabela435']),
      porcentoBaseCalculo:
          serializer.fromJson<double?>(json['porcentoBaseCalculo']),
      aliquotaPorcento: serializer.fromJson<double?>(json['aliquotaPorcento']),
      aliquotaUnidade: serializer.fromJson<double?>(json['aliquotaUnidade']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      valorPautaFiscal: serializer.fromJson<double?>(json['valorPautaFiscal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributConfiguraOfGt': serializer.toJson<int?>(idTributConfiguraOfGt),
      'cstCofins': serializer.toJson<String?>(cstCofins),
      'modalidadeBaseCalculo':
          serializer.toJson<String?>(modalidadeBaseCalculo),
      'efdTabela435': serializer.toJson<String?>(efdTabela435),
      'porcentoBaseCalculo': serializer.toJson<double?>(porcentoBaseCalculo),
      'aliquotaPorcento': serializer.toJson<double?>(aliquotaPorcento),
      'aliquotaUnidade': serializer.toJson<double?>(aliquotaUnidade),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'valorPautaFiscal': serializer.toJson<double?>(valorPautaFiscal),
    };
  }

  TributCofins copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributConfiguraOfGt = const Value.absent(),
          Value<String?> cstCofins = const Value.absent(),
          Value<String?> modalidadeBaseCalculo = const Value.absent(),
          Value<String?> efdTabela435 = const Value.absent(),
          Value<double?> porcentoBaseCalculo = const Value.absent(),
          Value<double?> aliquotaPorcento = const Value.absent(),
          Value<double?> aliquotaUnidade = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> valorPautaFiscal = const Value.absent()}) =>
      TributCofins(
        id: id.present ? id.value : this.id,
        idTributConfiguraOfGt: idTributConfiguraOfGt.present
            ? idTributConfiguraOfGt.value
            : this.idTributConfiguraOfGt,
        cstCofins: cstCofins.present ? cstCofins.value : this.cstCofins,
        modalidadeBaseCalculo: modalidadeBaseCalculo.present
            ? modalidadeBaseCalculo.value
            : this.modalidadeBaseCalculo,
        efdTabela435:
            efdTabela435.present ? efdTabela435.value : this.efdTabela435,
        porcentoBaseCalculo: porcentoBaseCalculo.present
            ? porcentoBaseCalculo.value
            : this.porcentoBaseCalculo,
        aliquotaPorcento: aliquotaPorcento.present
            ? aliquotaPorcento.value
            : this.aliquotaPorcento,
        aliquotaUnidade: aliquotaUnidade.present
            ? aliquotaUnidade.value
            : this.aliquotaUnidade,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        valorPautaFiscal: valorPautaFiscal.present
            ? valorPautaFiscal.value
            : this.valorPautaFiscal,
      );
  @override
  String toString() {
    return (StringBuffer('TributCofins(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstCofins: $cstCofins, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('efdTabela435: $efdTabela435, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributConfiguraOfGt,
      cstCofins,
      modalidadeBaseCalculo,
      efdTabela435,
      porcentoBaseCalculo,
      aliquotaPorcento,
      aliquotaUnidade,
      valorPrecoMaximo,
      valorPautaFiscal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributCofins &&
          other.id == this.id &&
          other.idTributConfiguraOfGt == this.idTributConfiguraOfGt &&
          other.cstCofins == this.cstCofins &&
          other.modalidadeBaseCalculo == this.modalidadeBaseCalculo &&
          other.efdTabela435 == this.efdTabela435 &&
          other.porcentoBaseCalculo == this.porcentoBaseCalculo &&
          other.aliquotaPorcento == this.aliquotaPorcento &&
          other.aliquotaUnidade == this.aliquotaUnidade &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.valorPautaFiscal == this.valorPautaFiscal);
}

class TributCofinssCompanion extends UpdateCompanion<TributCofins> {
  final Value<int?> id;
  final Value<int?> idTributConfiguraOfGt;
  final Value<String?> cstCofins;
  final Value<String?> modalidadeBaseCalculo;
  final Value<String?> efdTabela435;
  final Value<double?> porcentoBaseCalculo;
  final Value<double?> aliquotaPorcento;
  final Value<double?> aliquotaUnidade;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> valorPautaFiscal;
  const TributCofinssCompanion({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstCofins = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.efdTabela435 = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  TributCofinssCompanion.insert({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstCofins = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.efdTabela435 = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  static Insertable<TributCofins> custom({
    Expression<int>? id,
    Expression<int>? idTributConfiguraOfGt,
    Expression<String>? cstCofins,
    Expression<String>? modalidadeBaseCalculo,
    Expression<String>? efdTabela435,
    Expression<double>? porcentoBaseCalculo,
    Expression<double>? aliquotaPorcento,
    Expression<double>? aliquotaUnidade,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? valorPautaFiscal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributConfiguraOfGt != null)
        'id_tribut_configura_of_gt': idTributConfiguraOfGt,
      if (cstCofins != null) 'cst_cofins': cstCofins,
      if (modalidadeBaseCalculo != null)
        'modalidade_base_calculo': modalidadeBaseCalculo,
      if (efdTabela435 != null) 'efd_tabela_435': efdTabela435,
      if (porcentoBaseCalculo != null)
        'porcento_base_calculo': porcentoBaseCalculo,
      if (aliquotaPorcento != null) 'aliquota_porcento': aliquotaPorcento,
      if (aliquotaUnidade != null) 'aliquota_unidade': aliquotaUnidade,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (valorPautaFiscal != null) 'valor_pauta_fiscal': valorPautaFiscal,
    });
  }

  TributCofinssCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributConfiguraOfGt,
      Value<String?>? cstCofins,
      Value<String?>? modalidadeBaseCalculo,
      Value<String?>? efdTabela435,
      Value<double?>? porcentoBaseCalculo,
      Value<double?>? aliquotaPorcento,
      Value<double?>? aliquotaUnidade,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? valorPautaFiscal}) {
    return TributCofinssCompanion(
      id: id ?? this.id,
      idTributConfiguraOfGt:
          idTributConfiguraOfGt ?? this.idTributConfiguraOfGt,
      cstCofins: cstCofins ?? this.cstCofins,
      modalidadeBaseCalculo:
          modalidadeBaseCalculo ?? this.modalidadeBaseCalculo,
      efdTabela435: efdTabela435 ?? this.efdTabela435,
      porcentoBaseCalculo: porcentoBaseCalculo ?? this.porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento ?? this.aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade ?? this.aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal ?? this.valorPautaFiscal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributConfiguraOfGt.present) {
      map['id_tribut_configura_of_gt'] =
          Variable<int>(idTributConfiguraOfGt.value);
    }
    if (cstCofins.present) {
      map['cst_cofins'] = Variable<String>(cstCofins.value);
    }
    if (modalidadeBaseCalculo.present) {
      map['modalidade_base_calculo'] =
          Variable<String>(modalidadeBaseCalculo.value);
    }
    if (efdTabela435.present) {
      map['efd_tabela_435'] = Variable<String>(efdTabela435.value);
    }
    if (porcentoBaseCalculo.present) {
      map['porcento_base_calculo'] =
          Variable<double>(porcentoBaseCalculo.value);
    }
    if (aliquotaPorcento.present) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento.value);
    }
    if (aliquotaUnidade.present) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (valorPautaFiscal.present) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributCofinssCompanion(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstCofins: $cstCofins, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('efdTabela435: $efdTabela435, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }
}

class $TributIpisTable extends TributIpis
    with TableInfo<$TributIpisTable, TributIpi> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIpisTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributConfiguraOfGtMeta =
      const VerificationMeta('idTributConfiguraOfGt');
  @override
  late final GeneratedColumn<int> idTributConfiguraOfGt = GeneratedColumn<int>(
      'id_tribut_configura_of_gt', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cstIpiMeta = const VerificationMeta('cstIpi');
  @override
  late final GeneratedColumn<String> cstIpi = GeneratedColumn<String>(
      'cst_ipi', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBaseCalculoMeta =
      const VerificationMeta('modalidadeBaseCalculo');
  @override
  late final GeneratedColumn<String> modalidadeBaseCalculo =
      GeneratedColumn<String>('modalidade_base_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _porcentoBaseCalculoMeta =
      const VerificationMeta('porcentoBaseCalculo');
  @override
  late final GeneratedColumn<double> porcentoBaseCalculo =
      GeneratedColumn<double>('porcento_base_calculo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaPorcentoMeta =
      const VerificationMeta('aliquotaPorcento');
  @override
  late final GeneratedColumn<double> aliquotaPorcento = GeneratedColumn<double>(
      'aliquota_porcento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaUnidadeMeta =
      const VerificationMeta('aliquotaUnidade');
  @override
  late final GeneratedColumn<double> aliquotaUnidade = GeneratedColumn<double>(
      'aliquota_unidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaFiscalMeta =
      const VerificationMeta('valorPautaFiscal');
  @override
  late final GeneratedColumn<double> valorPautaFiscal = GeneratedColumn<double>(
      'valor_pauta_fiscal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributConfiguraOfGt,
        cstIpi,
        modalidadeBaseCalculo,
        porcentoBaseCalculo,
        aliquotaPorcento,
        aliquotaUnidade,
        valorPrecoMaximo,
        valorPautaFiscal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_ipi';
  @override
  VerificationContext validateIntegrity(Insertable<TributIpi> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_configura_of_gt')) {
      context.handle(
          _idTributConfiguraOfGtMeta,
          idTributConfiguraOfGt.isAcceptableOrUnknown(
              data['id_tribut_configura_of_gt']!, _idTributConfiguraOfGtMeta));
    }
    if (data.containsKey('cst_ipi')) {
      context.handle(_cstIpiMeta,
          cstIpi.isAcceptableOrUnknown(data['cst_ipi']!, _cstIpiMeta));
    }
    if (data.containsKey('modalidade_base_calculo')) {
      context.handle(
          _modalidadeBaseCalculoMeta,
          modalidadeBaseCalculo.isAcceptableOrUnknown(
              data['modalidade_base_calculo']!, _modalidadeBaseCalculoMeta));
    }
    if (data.containsKey('porcento_base_calculo')) {
      context.handle(
          _porcentoBaseCalculoMeta,
          porcentoBaseCalculo.isAcceptableOrUnknown(
              data['porcento_base_calculo']!, _porcentoBaseCalculoMeta));
    }
    if (data.containsKey('aliquota_porcento')) {
      context.handle(
          _aliquotaPorcentoMeta,
          aliquotaPorcento.isAcceptableOrUnknown(
              data['aliquota_porcento']!, _aliquotaPorcentoMeta));
    }
    if (data.containsKey('aliquota_unidade')) {
      context.handle(
          _aliquotaUnidadeMeta,
          aliquotaUnidade.isAcceptableOrUnknown(
              data['aliquota_unidade']!, _aliquotaUnidadeMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('valor_pauta_fiscal')) {
      context.handle(
          _valorPautaFiscalMeta,
          valorPautaFiscal.isAcceptableOrUnknown(
              data['valor_pauta_fiscal']!, _valorPautaFiscalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIpi map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIpi(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributConfiguraOfGt: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_configura_of_gt']),
      cstIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst_ipi']),
      modalidadeBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_base_calculo']),
      porcentoBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}porcento_base_calculo']),
      aliquotaPorcento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_porcento']),
      aliquotaUnidade: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_unidade']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      valorPautaFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_pauta_fiscal']),
    );
  }

  @override
  $TributIpisTable createAlias(String alias) {
    return $TributIpisTable(attachedDatabase, alias);
  }
}

class TributIpi extends DataClass implements Insertable<TributIpi> {
  final int? id;
  final int? idTributConfiguraOfGt;
  final String? cstIpi;
  final String? modalidadeBaseCalculo;
  final double? porcentoBaseCalculo;
  final double? aliquotaPorcento;
  final double? aliquotaUnidade;
  final double? valorPrecoMaximo;
  final double? valorPautaFiscal;
  const TributIpi(
      {this.id,
      this.idTributConfiguraOfGt,
      this.cstIpi,
      this.modalidadeBaseCalculo,
      this.porcentoBaseCalculo,
      this.aliquotaPorcento,
      this.aliquotaUnidade,
      this.valorPrecoMaximo,
      this.valorPautaFiscal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributConfiguraOfGt != null) {
      map['id_tribut_configura_of_gt'] = Variable<int>(idTributConfiguraOfGt);
    }
    if (!nullToAbsent || cstIpi != null) {
      map['cst_ipi'] = Variable<String>(cstIpi);
    }
    if (!nullToAbsent || modalidadeBaseCalculo != null) {
      map['modalidade_base_calculo'] = Variable<String>(modalidadeBaseCalculo);
    }
    if (!nullToAbsent || porcentoBaseCalculo != null) {
      map['porcento_base_calculo'] = Variable<double>(porcentoBaseCalculo);
    }
    if (!nullToAbsent || aliquotaPorcento != null) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento);
    }
    if (!nullToAbsent || aliquotaUnidade != null) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || valorPautaFiscal != null) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal);
    }
    return map;
  }

  factory TributIpi.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIpi(
      id: serializer.fromJson<int?>(json['id']),
      idTributConfiguraOfGt:
          serializer.fromJson<int?>(json['idTributConfiguraOfGt']),
      cstIpi: serializer.fromJson<String?>(json['cstIpi']),
      modalidadeBaseCalculo:
          serializer.fromJson<String?>(json['modalidadeBaseCalculo']),
      porcentoBaseCalculo:
          serializer.fromJson<double?>(json['porcentoBaseCalculo']),
      aliquotaPorcento: serializer.fromJson<double?>(json['aliquotaPorcento']),
      aliquotaUnidade: serializer.fromJson<double?>(json['aliquotaUnidade']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      valorPautaFiscal: serializer.fromJson<double?>(json['valorPautaFiscal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributConfiguraOfGt': serializer.toJson<int?>(idTributConfiguraOfGt),
      'cstIpi': serializer.toJson<String?>(cstIpi),
      'modalidadeBaseCalculo':
          serializer.toJson<String?>(modalidadeBaseCalculo),
      'porcentoBaseCalculo': serializer.toJson<double?>(porcentoBaseCalculo),
      'aliquotaPorcento': serializer.toJson<double?>(aliquotaPorcento),
      'aliquotaUnidade': serializer.toJson<double?>(aliquotaUnidade),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'valorPautaFiscal': serializer.toJson<double?>(valorPautaFiscal),
    };
  }

  TributIpi copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributConfiguraOfGt = const Value.absent(),
          Value<String?> cstIpi = const Value.absent(),
          Value<String?> modalidadeBaseCalculo = const Value.absent(),
          Value<double?> porcentoBaseCalculo = const Value.absent(),
          Value<double?> aliquotaPorcento = const Value.absent(),
          Value<double?> aliquotaUnidade = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> valorPautaFiscal = const Value.absent()}) =>
      TributIpi(
        id: id.present ? id.value : this.id,
        idTributConfiguraOfGt: idTributConfiguraOfGt.present
            ? idTributConfiguraOfGt.value
            : this.idTributConfiguraOfGt,
        cstIpi: cstIpi.present ? cstIpi.value : this.cstIpi,
        modalidadeBaseCalculo: modalidadeBaseCalculo.present
            ? modalidadeBaseCalculo.value
            : this.modalidadeBaseCalculo,
        porcentoBaseCalculo: porcentoBaseCalculo.present
            ? porcentoBaseCalculo.value
            : this.porcentoBaseCalculo,
        aliquotaPorcento: aliquotaPorcento.present
            ? aliquotaPorcento.value
            : this.aliquotaPorcento,
        aliquotaUnidade: aliquotaUnidade.present
            ? aliquotaUnidade.value
            : this.aliquotaUnidade,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        valorPautaFiscal: valorPautaFiscal.present
            ? valorPautaFiscal.value
            : this.valorPautaFiscal,
      );
  @override
  String toString() {
    return (StringBuffer('TributIpi(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstIpi: $cstIpi, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributConfiguraOfGt,
      cstIpi,
      modalidadeBaseCalculo,
      porcentoBaseCalculo,
      aliquotaPorcento,
      aliquotaUnidade,
      valorPrecoMaximo,
      valorPautaFiscal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIpi &&
          other.id == this.id &&
          other.idTributConfiguraOfGt == this.idTributConfiguraOfGt &&
          other.cstIpi == this.cstIpi &&
          other.modalidadeBaseCalculo == this.modalidadeBaseCalculo &&
          other.porcentoBaseCalculo == this.porcentoBaseCalculo &&
          other.aliquotaPorcento == this.aliquotaPorcento &&
          other.aliquotaUnidade == this.aliquotaUnidade &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.valorPautaFiscal == this.valorPautaFiscal);
}

class TributIpisCompanion extends UpdateCompanion<TributIpi> {
  final Value<int?> id;
  final Value<int?> idTributConfiguraOfGt;
  final Value<String?> cstIpi;
  final Value<String?> modalidadeBaseCalculo;
  final Value<double?> porcentoBaseCalculo;
  final Value<double?> aliquotaPorcento;
  final Value<double?> aliquotaUnidade;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> valorPautaFiscal;
  const TributIpisCompanion({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstIpi = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  TributIpisCompanion.insert({
    this.id = const Value.absent(),
    this.idTributConfiguraOfGt = const Value.absent(),
    this.cstIpi = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  static Insertable<TributIpi> custom({
    Expression<int>? id,
    Expression<int>? idTributConfiguraOfGt,
    Expression<String>? cstIpi,
    Expression<String>? modalidadeBaseCalculo,
    Expression<double>? porcentoBaseCalculo,
    Expression<double>? aliquotaPorcento,
    Expression<double>? aliquotaUnidade,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? valorPautaFiscal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributConfiguraOfGt != null)
        'id_tribut_configura_of_gt': idTributConfiguraOfGt,
      if (cstIpi != null) 'cst_ipi': cstIpi,
      if (modalidadeBaseCalculo != null)
        'modalidade_base_calculo': modalidadeBaseCalculo,
      if (porcentoBaseCalculo != null)
        'porcento_base_calculo': porcentoBaseCalculo,
      if (aliquotaPorcento != null) 'aliquota_porcento': aliquotaPorcento,
      if (aliquotaUnidade != null) 'aliquota_unidade': aliquotaUnidade,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (valorPautaFiscal != null) 'valor_pauta_fiscal': valorPautaFiscal,
    });
  }

  TributIpisCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributConfiguraOfGt,
      Value<String?>? cstIpi,
      Value<String?>? modalidadeBaseCalculo,
      Value<double?>? porcentoBaseCalculo,
      Value<double?>? aliquotaPorcento,
      Value<double?>? aliquotaUnidade,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? valorPautaFiscal}) {
    return TributIpisCompanion(
      id: id ?? this.id,
      idTributConfiguraOfGt:
          idTributConfiguraOfGt ?? this.idTributConfiguraOfGt,
      cstIpi: cstIpi ?? this.cstIpi,
      modalidadeBaseCalculo:
          modalidadeBaseCalculo ?? this.modalidadeBaseCalculo,
      porcentoBaseCalculo: porcentoBaseCalculo ?? this.porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento ?? this.aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade ?? this.aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal ?? this.valorPautaFiscal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributConfiguraOfGt.present) {
      map['id_tribut_configura_of_gt'] =
          Variable<int>(idTributConfiguraOfGt.value);
    }
    if (cstIpi.present) {
      map['cst_ipi'] = Variable<String>(cstIpi.value);
    }
    if (modalidadeBaseCalculo.present) {
      map['modalidade_base_calculo'] =
          Variable<String>(modalidadeBaseCalculo.value);
    }
    if (porcentoBaseCalculo.present) {
      map['porcento_base_calculo'] =
          Variable<double>(porcentoBaseCalculo.value);
    }
    if (aliquotaPorcento.present) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento.value);
    }
    if (aliquotaUnidade.present) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (valorPautaFiscal.present) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIpisCompanion(')
          ..write('id: $id, ')
          ..write('idTributConfiguraOfGt: $idTributConfiguraOfGt, ')
          ..write('cstIpi: $cstIpi, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }
}

class $TributIcmsCustomCabsTable extends TributIcmsCustomCabs
    with TableInfo<$TributIcmsCustomCabsTable, TributIcmsCustomCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIcmsCustomCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, descricao, origemMercadoria];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_icms_custom_cab';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributIcmsCustomCab> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIcmsCustomCab map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIcmsCustomCab(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
    );
  }

  @override
  $TributIcmsCustomCabsTable createAlias(String alias) {
    return $TributIcmsCustomCabsTable(attachedDatabase, alias);
  }
}

class TributIcmsCustomCab extends DataClass
    implements Insertable<TributIcmsCustomCab> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  const TributIcmsCustomCab({this.id, this.descricao, this.origemMercadoria});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    return map;
  }

  factory TributIcmsCustomCab.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIcmsCustomCab(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
    };
  }

  TributIcmsCustomCab copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent()}) =>
      TributIcmsCustomCab(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
      );
  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCab(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIcmsCustomCab &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria);
}

class TributIcmsCustomCabsCompanion
    extends UpdateCompanion<TributIcmsCustomCab> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  const TributIcmsCustomCabsCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  TributIcmsCustomCabsCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  static Insertable<TributIcmsCustomCab> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
    });
  }

  TributIcmsCustomCabsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria}) {
    return TributIcmsCustomCabsCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCabsCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }
}

class $TributConfiguraOfGtsTable extends TributConfiguraOfGts
    with TableInfo<$TributConfiguraOfGtsTable, TributConfiguraOfGt> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributConfiguraOfGtsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>('id_tribut_grupo_tributario', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributOperacaoFiscalMeta =
      const VerificationMeta('idTributOperacaoFiscal');
  @override
  late final GeneratedColumn<int> idTributOperacaoFiscal = GeneratedColumn<int>(
      'id_tribut_operacao_fiscal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idTributGrupoTributario, idTributOperacaoFiscal];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_configura_of_gt';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributConfiguraOfGt> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
          _idTributGrupoTributarioMeta,
          idTributGrupoTributario.isAcceptableOrUnknown(
              data['id_tribut_grupo_tributario']!,
              _idTributGrupoTributarioMeta));
    }
    if (data.containsKey('id_tribut_operacao_fiscal')) {
      context.handle(
          _idTributOperacaoFiscalMeta,
          idTributOperacaoFiscal.isAcceptableOrUnknown(
              data['id_tribut_operacao_fiscal']!, _idTributOperacaoFiscalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributConfiguraOfGt map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributConfiguraOfGt(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_grupo_tributario']),
      idTributOperacaoFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_operacao_fiscal']),
    );
  }

  @override
  $TributConfiguraOfGtsTable createAlias(String alias) {
    return $TributConfiguraOfGtsTable(attachedDatabase, alias);
  }
}

class TributConfiguraOfGt extends DataClass
    implements Insertable<TributConfiguraOfGt> {
  final int? id;
  final int? idTributGrupoTributario;
  final int? idTributOperacaoFiscal;
  const TributConfiguraOfGt(
      {this.id, this.idTributGrupoTributario, this.idTributOperacaoFiscal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario);
    }
    if (!nullToAbsent || idTributOperacaoFiscal != null) {
      map['id_tribut_operacao_fiscal'] = Variable<int>(idTributOperacaoFiscal);
    }
    return map;
  }

  factory TributConfiguraOfGt.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributConfiguraOfGt(
      id: serializer.fromJson<int?>(json['id']),
      idTributGrupoTributario:
          serializer.fromJson<int?>(json['idTributGrupoTributario']),
      idTributOperacaoFiscal:
          serializer.fromJson<int?>(json['idTributOperacaoFiscal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributGrupoTributario':
          serializer.toJson<int?>(idTributGrupoTributario),
      'idTributOperacaoFiscal': serializer.toJson<int?>(idTributOperacaoFiscal),
    };
  }

  TributConfiguraOfGt copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributGrupoTributario = const Value.absent(),
          Value<int?> idTributOperacaoFiscal = const Value.absent()}) =>
      TributConfiguraOfGt(
        id: id.present ? id.value : this.id,
        idTributGrupoTributario: idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
        idTributOperacaoFiscal: idTributOperacaoFiscal.present
            ? idTributOperacaoFiscal.value
            : this.idTributOperacaoFiscal,
      );
  @override
  String toString() {
    return (StringBuffer('TributConfiguraOfGt(')
          ..write('id: $id, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idTributGrupoTributario, idTributOperacaoFiscal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributConfiguraOfGt &&
          other.id == this.id &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.idTributOperacaoFiscal == this.idTributOperacaoFiscal);
}

class TributConfiguraOfGtsCompanion
    extends UpdateCompanion<TributConfiguraOfGt> {
  final Value<int?> id;
  final Value<int?> idTributGrupoTributario;
  final Value<int?> idTributOperacaoFiscal;
  const TributConfiguraOfGtsCompanion({
    this.id = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
  });
  TributConfiguraOfGtsCompanion.insert({
    this.id = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
  });
  static Insertable<TributConfiguraOfGt> custom({
    Expression<int>? id,
    Expression<int>? idTributGrupoTributario,
    Expression<int>? idTributOperacaoFiscal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (idTributOperacaoFiscal != null)
        'id_tribut_operacao_fiscal': idTributOperacaoFiscal,
    });
  }

  TributConfiguraOfGtsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributGrupoTributario,
      Value<int?>? idTributOperacaoFiscal}) {
    return TributConfiguraOfGtsCompanion(
      id: id ?? this.id,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      idTributOperacaoFiscal:
          idTributOperacaoFiscal ?? this.idTributOperacaoFiscal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario.value);
    }
    if (idTributOperacaoFiscal.present) {
      map['id_tribut_operacao_fiscal'] =
          Variable<int>(idTributOperacaoFiscal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributConfiguraOfGtsCompanion(')
          ..write('id: $id, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal')
          ..write(')'))
        .toString();
  }
}

class $TributGrupoTributariosTable extends TributGrupoTributarios
    with TableInfo<$TributGrupoTributariosTable, TributGrupoTributario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributGrupoTributariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, origemMercadoria, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_grupo_tributario';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributGrupoTributario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributGrupoTributario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributGrupoTributario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $TributGrupoTributariosTable createAlias(String alias) {
    return $TributGrupoTributariosTable(attachedDatabase, alias);
  }
}

class TributGrupoTributario extends DataClass
    implements Insertable<TributGrupoTributario> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  final String? observacao;
  const TributGrupoTributario(
      {this.id, this.descricao, this.origemMercadoria, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory TributGrupoTributario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributGrupoTributario(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  TributGrupoTributario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      TributGrupoTributario(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('TributGrupoTributario(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributGrupoTributario &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria &&
          other.observacao == this.observacao);
}

class TributGrupoTributariosCompanion
    extends UpdateCompanion<TributGrupoTributario> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  final Value<String?> observacao;
  const TributGrupoTributariosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  TributGrupoTributariosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<TributGrupoTributario> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
      if (observacao != null) 'observacao': observacao,
    });
  }

  TributGrupoTributariosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria,
      Value<String?>? observacao}) {
    return TributGrupoTributariosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributGrupoTributariosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $TributOperacaoFiscalsTable extends TributOperacaoFiscals
    with TableInfo<$TributOperacaoFiscalsTable, TributOperacaoFiscal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributOperacaoFiscalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cfopMeta = const VerificationMeta('cfop');
  @override
  late final GeneratedColumn<int> cfop = GeneratedColumn<int>(
      'cfop', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoNaNfMeta =
      const VerificationMeta('descricaoNaNf');
  @override
  late final GeneratedColumn<String> descricaoNaNf = GeneratedColumn<String>(
      'descricao_na_nf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, cfop, descricao, descricaoNaNf, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_operacao_fiscal';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributOperacaoFiscal> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('cfop')) {
      context.handle(
          _cfopMeta, cfop.isAcceptableOrUnknown(data['cfop']!, _cfopMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('descricao_na_nf')) {
      context.handle(
          _descricaoNaNfMeta,
          descricaoNaNf.isAcceptableOrUnknown(
              data['descricao_na_nf']!, _descricaoNaNfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributOperacaoFiscal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributOperacaoFiscal(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      cfop: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      descricaoNaNf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao_na_nf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $TributOperacaoFiscalsTable createAlias(String alias) {
    return $TributOperacaoFiscalsTable(attachedDatabase, alias);
  }
}

class TributOperacaoFiscal extends DataClass
    implements Insertable<TributOperacaoFiscal> {
  final int? id;
  final int? cfop;
  final String? descricao;
  final String? descricaoNaNf;
  final String? observacao;
  const TributOperacaoFiscal(
      {this.id,
      this.cfop,
      this.descricao,
      this.descricaoNaNf,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || cfop != null) {
      map['cfop'] = Variable<int>(cfop);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || descricaoNaNf != null) {
      map['descricao_na_nf'] = Variable<String>(descricaoNaNf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory TributOperacaoFiscal.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributOperacaoFiscal(
      id: serializer.fromJson<int?>(json['id']),
      cfop: serializer.fromJson<int?>(json['cfop']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      descricaoNaNf: serializer.fromJson<String?>(json['descricaoNaNf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'cfop': serializer.toJson<int?>(cfop),
      'descricao': serializer.toJson<String?>(descricao),
      'descricaoNaNf': serializer.toJson<String?>(descricaoNaNf),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  TributOperacaoFiscal copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> cfop = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> descricaoNaNf = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      TributOperacaoFiscal(
        id: id.present ? id.value : this.id,
        cfop: cfop.present ? cfop.value : this.cfop,
        descricao: descricao.present ? descricao.value : this.descricao,
        descricaoNaNf:
            descricaoNaNf.present ? descricaoNaNf.value : this.descricaoNaNf,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('TributOperacaoFiscal(')
          ..write('id: $id, ')
          ..write('cfop: $cfop, ')
          ..write('descricao: $descricao, ')
          ..write('descricaoNaNf: $descricaoNaNf, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, cfop, descricao, descricaoNaNf, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributOperacaoFiscal &&
          other.id == this.id &&
          other.cfop == this.cfop &&
          other.descricao == this.descricao &&
          other.descricaoNaNf == this.descricaoNaNf &&
          other.observacao == this.observacao);
}

class TributOperacaoFiscalsCompanion
    extends UpdateCompanion<TributOperacaoFiscal> {
  final Value<int?> id;
  final Value<int?> cfop;
  final Value<String?> descricao;
  final Value<String?> descricaoNaNf;
  final Value<String?> observacao;
  const TributOperacaoFiscalsCompanion({
    this.id = const Value.absent(),
    this.cfop = const Value.absent(),
    this.descricao = const Value.absent(),
    this.descricaoNaNf = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  TributOperacaoFiscalsCompanion.insert({
    this.id = const Value.absent(),
    this.cfop = const Value.absent(),
    this.descricao = const Value.absent(),
    this.descricaoNaNf = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<TributOperacaoFiscal> custom({
    Expression<int>? id,
    Expression<int>? cfop,
    Expression<String>? descricao,
    Expression<String>? descricaoNaNf,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (cfop != null) 'cfop': cfop,
      if (descricao != null) 'descricao': descricao,
      if (descricaoNaNf != null) 'descricao_na_nf': descricaoNaNf,
      if (observacao != null) 'observacao': observacao,
    });
  }

  TributOperacaoFiscalsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? cfop,
      Value<String?>? descricao,
      Value<String?>? descricaoNaNf,
      Value<String?>? observacao}) {
    return TributOperacaoFiscalsCompanion(
      id: id ?? this.id,
      cfop: cfop ?? this.cfop,
      descricao: descricao ?? this.descricao,
      descricaoNaNf: descricaoNaNf ?? this.descricaoNaNf,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (cfop.present) {
      map['cfop'] = Variable<int>(cfop.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (descricaoNaNf.present) {
      map['descricao_na_nf'] = Variable<String>(descricaoNaNf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributOperacaoFiscalsCompanion(')
          ..write('id: $id, ')
          ..write('cfop: $cfop, ')
          ..write('descricao: $descricao, ')
          ..write('descricaoNaNf: $descricaoNaNf, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $TributIsssTable extends TributIsss
    with TableInfo<$TributIsssTable, TributIss> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIsssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributOperacaoFiscalMeta =
      const VerificationMeta('idTributOperacaoFiscal');
  @override
  late final GeneratedColumn<int> idTributOperacaoFiscal = GeneratedColumn<int>(
      'id_tribut_operacao_fiscal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _modalidadeBaseCalculoMeta =
      const VerificationMeta('modalidadeBaseCalculo');
  @override
  late final GeneratedColumn<String> modalidadeBaseCalculo =
      GeneratedColumn<String>('modalidade_base_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoTributacaoMeta =
      const VerificationMeta('codigoTributacao');
  @override
  late final GeneratedColumn<String> codigoTributacao = GeneratedColumn<String>(
      'codigo_tributacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _itemListaServicoMeta =
      const VerificationMeta('itemListaServico');
  @override
  late final GeneratedColumn<int> itemListaServico = GeneratedColumn<int>(
      'item_lista_servico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _porcentoBaseCalculoMeta =
      const VerificationMeta('porcentoBaseCalculo');
  @override
  late final GeneratedColumn<double> porcentoBaseCalculo =
      GeneratedColumn<double>('porcento_base_calculo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaPorcentoMeta =
      const VerificationMeta('aliquotaPorcento');
  @override
  late final GeneratedColumn<double> aliquotaPorcento = GeneratedColumn<double>(
      'aliquota_porcento', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaUnidadeMeta =
      const VerificationMeta('aliquotaUnidade');
  @override
  late final GeneratedColumn<double> aliquotaUnidade = GeneratedColumn<double>(
      'aliquota_unidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPrecoMaximoMeta =
      const VerificationMeta('valorPrecoMaximo');
  @override
  late final GeneratedColumn<double> valorPrecoMaximo = GeneratedColumn<double>(
      'valor_preco_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPautaFiscalMeta =
      const VerificationMeta('valorPautaFiscal');
  @override
  late final GeneratedColumn<double> valorPautaFiscal = GeneratedColumn<double>(
      'valor_pauta_fiscal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idTributOperacaoFiscal,
        modalidadeBaseCalculo,
        codigoTributacao,
        itemListaServico,
        porcentoBaseCalculo,
        aliquotaPorcento,
        aliquotaUnidade,
        valorPrecoMaximo,
        valorPautaFiscal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_iss';
  @override
  VerificationContext validateIntegrity(Insertable<TributIss> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_operacao_fiscal')) {
      context.handle(
          _idTributOperacaoFiscalMeta,
          idTributOperacaoFiscal.isAcceptableOrUnknown(
              data['id_tribut_operacao_fiscal']!, _idTributOperacaoFiscalMeta));
    }
    if (data.containsKey('modalidade_base_calculo')) {
      context.handle(
          _modalidadeBaseCalculoMeta,
          modalidadeBaseCalculo.isAcceptableOrUnknown(
              data['modalidade_base_calculo']!, _modalidadeBaseCalculoMeta));
    }
    if (data.containsKey('codigo_tributacao')) {
      context.handle(
          _codigoTributacaoMeta,
          codigoTributacao.isAcceptableOrUnknown(
              data['codigo_tributacao']!, _codigoTributacaoMeta));
    }
    if (data.containsKey('item_lista_servico')) {
      context.handle(
          _itemListaServicoMeta,
          itemListaServico.isAcceptableOrUnknown(
              data['item_lista_servico']!, _itemListaServicoMeta));
    }
    if (data.containsKey('porcento_base_calculo')) {
      context.handle(
          _porcentoBaseCalculoMeta,
          porcentoBaseCalculo.isAcceptableOrUnknown(
              data['porcento_base_calculo']!, _porcentoBaseCalculoMeta));
    }
    if (data.containsKey('aliquota_porcento')) {
      context.handle(
          _aliquotaPorcentoMeta,
          aliquotaPorcento.isAcceptableOrUnknown(
              data['aliquota_porcento']!, _aliquotaPorcentoMeta));
    }
    if (data.containsKey('aliquota_unidade')) {
      context.handle(
          _aliquotaUnidadeMeta,
          aliquotaUnidade.isAcceptableOrUnknown(
              data['aliquota_unidade']!, _aliquotaUnidadeMeta));
    }
    if (data.containsKey('valor_preco_maximo')) {
      context.handle(
          _valorPrecoMaximoMeta,
          valorPrecoMaximo.isAcceptableOrUnknown(
              data['valor_preco_maximo']!, _valorPrecoMaximoMeta));
    }
    if (data.containsKey('valor_pauta_fiscal')) {
      context.handle(
          _valorPautaFiscalMeta,
          valorPautaFiscal.isAcceptableOrUnknown(
              data['valor_pauta_fiscal']!, _valorPautaFiscalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIss map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIss(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idTributOperacaoFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_operacao_fiscal']),
      modalidadeBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}modalidade_base_calculo']),
      codigoTributacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_tributacao']),
      itemListaServico: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}item_lista_servico']),
      porcentoBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}porcento_base_calculo']),
      aliquotaPorcento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_porcento']),
      aliquotaUnidade: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_unidade']),
      valorPrecoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_preco_maximo']),
      valorPautaFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_pauta_fiscal']),
    );
  }

  @override
  $TributIsssTable createAlias(String alias) {
    return $TributIsssTable(attachedDatabase, alias);
  }
}

class TributIss extends DataClass implements Insertable<TributIss> {
  final int? id;
  final int? idTributOperacaoFiscal;
  final String? modalidadeBaseCalculo;
  final String? codigoTributacao;
  final int? itemListaServico;
  final double? porcentoBaseCalculo;
  final double? aliquotaPorcento;
  final double? aliquotaUnidade;
  final double? valorPrecoMaximo;
  final double? valorPautaFiscal;
  const TributIss(
      {this.id,
      this.idTributOperacaoFiscal,
      this.modalidadeBaseCalculo,
      this.codigoTributacao,
      this.itemListaServico,
      this.porcentoBaseCalculo,
      this.aliquotaPorcento,
      this.aliquotaUnidade,
      this.valorPrecoMaximo,
      this.valorPautaFiscal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributOperacaoFiscal != null) {
      map['id_tribut_operacao_fiscal'] = Variable<int>(idTributOperacaoFiscal);
    }
    if (!nullToAbsent || modalidadeBaseCalculo != null) {
      map['modalidade_base_calculo'] = Variable<String>(modalidadeBaseCalculo);
    }
    if (!nullToAbsent || codigoTributacao != null) {
      map['codigo_tributacao'] = Variable<String>(codigoTributacao);
    }
    if (!nullToAbsent || itemListaServico != null) {
      map['item_lista_servico'] = Variable<int>(itemListaServico);
    }
    if (!nullToAbsent || porcentoBaseCalculo != null) {
      map['porcento_base_calculo'] = Variable<double>(porcentoBaseCalculo);
    }
    if (!nullToAbsent || aliquotaPorcento != null) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento);
    }
    if (!nullToAbsent || aliquotaUnidade != null) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade);
    }
    if (!nullToAbsent || valorPrecoMaximo != null) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo);
    }
    if (!nullToAbsent || valorPautaFiscal != null) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal);
    }
    return map;
  }

  factory TributIss.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIss(
      id: serializer.fromJson<int?>(json['id']),
      idTributOperacaoFiscal:
          serializer.fromJson<int?>(json['idTributOperacaoFiscal']),
      modalidadeBaseCalculo:
          serializer.fromJson<String?>(json['modalidadeBaseCalculo']),
      codigoTributacao: serializer.fromJson<String?>(json['codigoTributacao']),
      itemListaServico: serializer.fromJson<int?>(json['itemListaServico']),
      porcentoBaseCalculo:
          serializer.fromJson<double?>(json['porcentoBaseCalculo']),
      aliquotaPorcento: serializer.fromJson<double?>(json['aliquotaPorcento']),
      aliquotaUnidade: serializer.fromJson<double?>(json['aliquotaUnidade']),
      valorPrecoMaximo: serializer.fromJson<double?>(json['valorPrecoMaximo']),
      valorPautaFiscal: serializer.fromJson<double?>(json['valorPautaFiscal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributOperacaoFiscal': serializer.toJson<int?>(idTributOperacaoFiscal),
      'modalidadeBaseCalculo':
          serializer.toJson<String?>(modalidadeBaseCalculo),
      'codigoTributacao': serializer.toJson<String?>(codigoTributacao),
      'itemListaServico': serializer.toJson<int?>(itemListaServico),
      'porcentoBaseCalculo': serializer.toJson<double?>(porcentoBaseCalculo),
      'aliquotaPorcento': serializer.toJson<double?>(aliquotaPorcento),
      'aliquotaUnidade': serializer.toJson<double?>(aliquotaUnidade),
      'valorPrecoMaximo': serializer.toJson<double?>(valorPrecoMaximo),
      'valorPautaFiscal': serializer.toJson<double?>(valorPautaFiscal),
    };
  }

  TributIss copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idTributOperacaoFiscal = const Value.absent(),
          Value<String?> modalidadeBaseCalculo = const Value.absent(),
          Value<String?> codigoTributacao = const Value.absent(),
          Value<int?> itemListaServico = const Value.absent(),
          Value<double?> porcentoBaseCalculo = const Value.absent(),
          Value<double?> aliquotaPorcento = const Value.absent(),
          Value<double?> aliquotaUnidade = const Value.absent(),
          Value<double?> valorPrecoMaximo = const Value.absent(),
          Value<double?> valorPautaFiscal = const Value.absent()}) =>
      TributIss(
        id: id.present ? id.value : this.id,
        idTributOperacaoFiscal: idTributOperacaoFiscal.present
            ? idTributOperacaoFiscal.value
            : this.idTributOperacaoFiscal,
        modalidadeBaseCalculo: modalidadeBaseCalculo.present
            ? modalidadeBaseCalculo.value
            : this.modalidadeBaseCalculo,
        codigoTributacao: codigoTributacao.present
            ? codigoTributacao.value
            : this.codigoTributacao,
        itemListaServico: itemListaServico.present
            ? itemListaServico.value
            : this.itemListaServico,
        porcentoBaseCalculo: porcentoBaseCalculo.present
            ? porcentoBaseCalculo.value
            : this.porcentoBaseCalculo,
        aliquotaPorcento: aliquotaPorcento.present
            ? aliquotaPorcento.value
            : this.aliquotaPorcento,
        aliquotaUnidade: aliquotaUnidade.present
            ? aliquotaUnidade.value
            : this.aliquotaUnidade,
        valorPrecoMaximo: valorPrecoMaximo.present
            ? valorPrecoMaximo.value
            : this.valorPrecoMaximo,
        valorPautaFiscal: valorPautaFiscal.present
            ? valorPautaFiscal.value
            : this.valorPautaFiscal,
      );
  @override
  String toString() {
    return (StringBuffer('TributIss(')
          ..write('id: $id, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('codigoTributacao: $codigoTributacao, ')
          ..write('itemListaServico: $itemListaServico, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idTributOperacaoFiscal,
      modalidadeBaseCalculo,
      codigoTributacao,
      itemListaServico,
      porcentoBaseCalculo,
      aliquotaPorcento,
      aliquotaUnidade,
      valorPrecoMaximo,
      valorPautaFiscal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIss &&
          other.id == this.id &&
          other.idTributOperacaoFiscal == this.idTributOperacaoFiscal &&
          other.modalidadeBaseCalculo == this.modalidadeBaseCalculo &&
          other.codigoTributacao == this.codigoTributacao &&
          other.itemListaServico == this.itemListaServico &&
          other.porcentoBaseCalculo == this.porcentoBaseCalculo &&
          other.aliquotaPorcento == this.aliquotaPorcento &&
          other.aliquotaUnidade == this.aliquotaUnidade &&
          other.valorPrecoMaximo == this.valorPrecoMaximo &&
          other.valorPautaFiscal == this.valorPautaFiscal);
}

class TributIsssCompanion extends UpdateCompanion<TributIss> {
  final Value<int?> id;
  final Value<int?> idTributOperacaoFiscal;
  final Value<String?> modalidadeBaseCalculo;
  final Value<String?> codigoTributacao;
  final Value<int?> itemListaServico;
  final Value<double?> porcentoBaseCalculo;
  final Value<double?> aliquotaPorcento;
  final Value<double?> aliquotaUnidade;
  final Value<double?> valorPrecoMaximo;
  final Value<double?> valorPautaFiscal;
  const TributIsssCompanion({
    this.id = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.codigoTributacao = const Value.absent(),
    this.itemListaServico = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  TributIsssCompanion.insert({
    this.id = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
    this.modalidadeBaseCalculo = const Value.absent(),
    this.codigoTributacao = const Value.absent(),
    this.itemListaServico = const Value.absent(),
    this.porcentoBaseCalculo = const Value.absent(),
    this.aliquotaPorcento = const Value.absent(),
    this.aliquotaUnidade = const Value.absent(),
    this.valorPrecoMaximo = const Value.absent(),
    this.valorPautaFiscal = const Value.absent(),
  });
  static Insertable<TributIss> custom({
    Expression<int>? id,
    Expression<int>? idTributOperacaoFiscal,
    Expression<String>? modalidadeBaseCalculo,
    Expression<String>? codigoTributacao,
    Expression<int>? itemListaServico,
    Expression<double>? porcentoBaseCalculo,
    Expression<double>? aliquotaPorcento,
    Expression<double>? aliquotaUnidade,
    Expression<double>? valorPrecoMaximo,
    Expression<double>? valorPautaFiscal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributOperacaoFiscal != null)
        'id_tribut_operacao_fiscal': idTributOperacaoFiscal,
      if (modalidadeBaseCalculo != null)
        'modalidade_base_calculo': modalidadeBaseCalculo,
      if (codigoTributacao != null) 'codigo_tributacao': codigoTributacao,
      if (itemListaServico != null) 'item_lista_servico': itemListaServico,
      if (porcentoBaseCalculo != null)
        'porcento_base_calculo': porcentoBaseCalculo,
      if (aliquotaPorcento != null) 'aliquota_porcento': aliquotaPorcento,
      if (aliquotaUnidade != null) 'aliquota_unidade': aliquotaUnidade,
      if (valorPrecoMaximo != null) 'valor_preco_maximo': valorPrecoMaximo,
      if (valorPautaFiscal != null) 'valor_pauta_fiscal': valorPautaFiscal,
    });
  }

  TributIsssCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idTributOperacaoFiscal,
      Value<String?>? modalidadeBaseCalculo,
      Value<String?>? codigoTributacao,
      Value<int?>? itemListaServico,
      Value<double?>? porcentoBaseCalculo,
      Value<double?>? aliquotaPorcento,
      Value<double?>? aliquotaUnidade,
      Value<double?>? valorPrecoMaximo,
      Value<double?>? valorPautaFiscal}) {
    return TributIsssCompanion(
      id: id ?? this.id,
      idTributOperacaoFiscal:
          idTributOperacaoFiscal ?? this.idTributOperacaoFiscal,
      modalidadeBaseCalculo:
          modalidadeBaseCalculo ?? this.modalidadeBaseCalculo,
      codigoTributacao: codigoTributacao ?? this.codigoTributacao,
      itemListaServico: itemListaServico ?? this.itemListaServico,
      porcentoBaseCalculo: porcentoBaseCalculo ?? this.porcentoBaseCalculo,
      aliquotaPorcento: aliquotaPorcento ?? this.aliquotaPorcento,
      aliquotaUnidade: aliquotaUnidade ?? this.aliquotaUnidade,
      valorPrecoMaximo: valorPrecoMaximo ?? this.valorPrecoMaximo,
      valorPautaFiscal: valorPautaFiscal ?? this.valorPautaFiscal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributOperacaoFiscal.present) {
      map['id_tribut_operacao_fiscal'] =
          Variable<int>(idTributOperacaoFiscal.value);
    }
    if (modalidadeBaseCalculo.present) {
      map['modalidade_base_calculo'] =
          Variable<String>(modalidadeBaseCalculo.value);
    }
    if (codigoTributacao.present) {
      map['codigo_tributacao'] = Variable<String>(codigoTributacao.value);
    }
    if (itemListaServico.present) {
      map['item_lista_servico'] = Variable<int>(itemListaServico.value);
    }
    if (porcentoBaseCalculo.present) {
      map['porcento_base_calculo'] =
          Variable<double>(porcentoBaseCalculo.value);
    }
    if (aliquotaPorcento.present) {
      map['aliquota_porcento'] = Variable<double>(aliquotaPorcento.value);
    }
    if (aliquotaUnidade.present) {
      map['aliquota_unidade'] = Variable<double>(aliquotaUnidade.value);
    }
    if (valorPrecoMaximo.present) {
      map['valor_preco_maximo'] = Variable<double>(valorPrecoMaximo.value);
    }
    if (valorPautaFiscal.present) {
      map['valor_pauta_fiscal'] = Variable<double>(valorPautaFiscal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIsssCompanion(')
          ..write('id: $id, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal, ')
          ..write('modalidadeBaseCalculo: $modalidadeBaseCalculo, ')
          ..write('codigoTributacao: $codigoTributacao, ')
          ..write('itemListaServico: $itemListaServico, ')
          ..write('porcentoBaseCalculo: $porcentoBaseCalculo, ')
          ..write('aliquotaPorcento: $aliquotaPorcento, ')
          ..write('aliquotaUnidade: $aliquotaUnidade, ')
          ..write('valorPrecoMaximo: $valorPrecoMaximo, ')
          ..write('valorPautaFiscal: $valorPautaFiscal')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $TributIcmsCustomDetsTable tributIcmsCustomDets =
      $TributIcmsCustomDetsTable(this);
  late final $TributIcmsUfsTable tributIcmsUfs = $TributIcmsUfsTable(this);
  late final $TributPissTable tributPiss = $TributPissTable(this);
  late final $TributCofinssTable tributCofinss = $TributCofinssTable(this);
  late final $TributIpisTable tributIpis = $TributIpisTable(this);
  late final $TributIcmsCustomCabsTable tributIcmsCustomCabs =
      $TributIcmsCustomCabsTable(this);
  late final $TributConfiguraOfGtsTable tributConfiguraOfGts =
      $TributConfiguraOfGtsTable(this);
  late final $TributGrupoTributariosTable tributGrupoTributarios =
      $TributGrupoTributariosTable(this);
  late final $TributOperacaoFiscalsTable tributOperacaoFiscals =
      $TributOperacaoFiscalsTable(this);
  late final $TributIsssTable tributIsss = $TributIsssTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final TributIcmsCustomCabDao tributIcmsCustomCabDao =
      TributIcmsCustomCabDao(this as AppDatabase);
  late final TributConfiguraOfGtDao tributConfiguraOfGtDao =
      TributConfiguraOfGtDao(this as AppDatabase);
  late final TributGrupoTributarioDao tributGrupoTributarioDao =
      TributGrupoTributarioDao(this as AppDatabase);
  late final TributOperacaoFiscalDao tributOperacaoFiscalDao =
      TributOperacaoFiscalDao(this as AppDatabase);
  late final TributIssDao tributIssDao = TributIssDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        tributIcmsCustomDets,
        tributIcmsUfs,
        tributPiss,
        tributCofinss,
        tributIpis,
        tributIcmsCustomCabs,
        tributConfiguraOfGts,
        tributGrupoTributarios,
        tributOperacaoFiscals,
        tributIsss,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
