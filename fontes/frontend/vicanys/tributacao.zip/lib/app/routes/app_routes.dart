abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const tributIcmsCustomCabListPage = '/tributIcmsCustomCabListPage'; 
	static const tributIcmsCustomCabTabPage = '/tributIcmsCustomCabTabPage';
	static const tributConfiguraOfGtListPage = '/tributConfiguraOfGtListPage'; 
	static const tributConfiguraOfGtTabPage = '/tributConfiguraOfGtTabPage';
	static const tributGrupoTributarioListPage = '/tributGrupoTributarioListPage'; 
	static const tributGrupoTributarioEditPage = '/tributGrupoTributarioEditPage';
	static const tributOperacaoFiscalListPage = '/tributOperacaoFiscalListPage'; 
	static const tributOperacaoFiscalEditPage = '/tributOperacaoFiscalEditPage';
	static const tributIssListPage = '/tributIssListPage'; 
	static const tributIssEditPage = '/tributIssEditPage';
}