import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:math';
import 'package:financeiro/app/controller/theme_controller.dart';
import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:financeiro/app/page/shared_widget/message_dialog.dart';
import 'package:financeiro/app/routes/app_routes.dart';

class MainSideDrawer extends StatelessWidget {
	MainSideDrawer({Key? key}) : super(key: key);

	final themeController = Get.find<ThemeController>();

	@override
	Widget build(BuildContext context) {
		return Drawer(
			child: ListView(
				padding: EdgeInsets.zero,
				children: <Widget>[
					UserAccountsDrawerHeader(
						accountName: Text('name'.tr,),
						accountEmail: const Text('Email',),
						currentAccountPicture: MouseRegion(
							cursor: SystemMouseCursors.click,
							child: GestureDetector(
								onTap: (() {
									showInfoSnackBar(message: 'drawer_message_change_image_profile'.tr);
								}),
								child: const CircleAvatar(
									backgroundImage: AssetImage(Constants.profileImage),
								),
							),
						),
					),

          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Cadastros',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),


					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_documento_origem') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_documento_origem') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finDocumentoOrigemListPage);
						},
						title: const Text(
							'Documento Origem',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_natureza_financeira') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_natureza_financeira') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finNaturezaFinanceiraListPage);
						},
						title: const Text(
							'Natureza Financeira',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_status_parcela') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_status_parcela') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finStatusParcelaListPage);
						},
						title: const Text(
							'Status Parcela',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_tipo_pagamento') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_tipo_pagamento') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finTipoPagamentoListPage);
						},
						title: const Text(
							'Tipo Pagamento',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_tipo_recebimento') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_tipo_recebimento') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finTipoRecebimentoListPage);
						},
						title: const Text(
							'Tipo Recebimento',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					// ListTile(
					// 	enabled: Session.loggedInUser.administrador == 'S'
					// 		? true
					// 			: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_recebido') ).toList().isNotEmpty
					// 				? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_recebido') ).toList()[0].habilitado == 'S'
					// 				: false,
					// 	onTap: () {
					// 		Get.toNamed(Routes.finChequeRecebidoListPage);
					// 	},
					// 	title: const Text(
					// 		'Cheque Recebido',
					// 		style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
					// 	),
					// 	leading: Icon(
					// 		iconDataList[Random().nextInt(10)],
					// 		color: iconColorList[Random().nextInt(10)],
					// 	),
					// ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_configuracao_boleto') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_configuracao_boleto') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finConfiguracaoBoletoListPage);
						},
						title: const Text(
							'Configuracões Boleto',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'talonario_cheque') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'talonario_cheque') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.talonarioChequeListPage);
						},
						title: const Text(
							'Talonário Cheque',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),


					const Divider(),		 
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Contas a Pagar',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),


					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_pagar') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_pagar') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finLancamentoPagarListPage);
						},
						title: const Text(
							'Lançamento a Pagar',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_pagar') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_pagar') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finLancamentoPagarListPage);
						},
						title: const Text(
							'Pagamento',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					const Divider(),		 
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Contas a Receber',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finLancamentoReceberListPage);
						},
						title: const Text(
							'Lançamento a Receber',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finLancamentoReceberListPage);
						},
						title: const Text(
							'Recebimento',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_lancamento_receber') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finLancamentoReceberListPage);
						},
						title: const Text(
							'Cobrança',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					const Divider(),		 
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Controle de Caixa e Bancos',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.bancoContaCaixaListPage);
						},
						title: const Text(
							'Conta/Caixa',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.bancoContaCaixaListPage);
						},
						title: const Text(
							'Movimento Caixa/Banco',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.bancoContaCaixaListPage);
						},
						title: const Text(
							'Conciliação Bancária',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					const Divider(),		 
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Fluxo de Caixa',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'banco_conta_caixa') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.bancoContaCaixaListPage);
						},
						title: const Text(
							'Fluxo de Caixa',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),


					const Divider(),		 
          const Padding(
            padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
            child: Text(
              'Tesouraria',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 10.0),
            ),
          ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finChequeEmitidoListPage);
						},
						title: const Text(
							'Emissão de Cheque',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finChequeEmitidoListPage);
						},
						title: const Text(
							'Custódia de Cheque',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'fin_cheque_emitido') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.finChequeEmitidoListPage);
						},
						title: const Text(
							'Resumo Tesouraria',
							style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),


					const Divider(),        
					ListTile(
							onTap: () {
									Get.offAllNamed('/loginPage');
							},
							title: Text(
									"button_exit".tr,
									style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
							),
							leading: const Icon(
									Icons.exit_to_app,
									color: Colors.red,
							),
					), 
				],
			),
		);
	}
}
