// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_configuracao_boleto_dao.dart';

// ignore_for_file: type=lint
mixin _$FinConfiguracaoBoletoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinConfiguracaoBoletosTable get finConfiguracaoBoletos =>
      attachedDatabase.finConfiguracaoBoletos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
