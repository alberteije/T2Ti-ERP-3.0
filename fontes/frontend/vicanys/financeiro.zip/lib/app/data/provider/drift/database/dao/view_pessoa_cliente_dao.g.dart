// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_pessoa_cliente_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewPessoaClienteDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
