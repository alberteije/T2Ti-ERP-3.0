abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const cteCabecalhoListPage = '/cteCabecalhoListPage'; 
	static const cteCabecalhoTabPage = '/cteCabecalhoTabPage';
	static const cteInformacaoNfTransporteListPage = '/cteInformacaoNfTransporteListPage'; 
	static const cteInformacaoNfTransporteEditPage = '/cteInformacaoNfTransporteEditPage';
	static const cteInfNfTransporteLacreListPage = '/cteInfNfTransporteLacreListPage'; 
	static const cteInfNfTransporteLacreEditPage = '/cteInfNfTransporteLacreEditPage';
	static const cteInformacaoNfCargaListPage = '/cteInformacaoNfCargaListPage'; 
	static const cteInformacaoNfCargaEditPage = '/cteInformacaoNfCargaEditPage';
	static const cteInfNfCargaLacreListPage = '/cteInfNfCargaLacreListPage'; 
	static const cteInfNfCargaLacreEditPage = '/cteInfNfCargaLacreEditPage';
	static const cteDocumentoAnteriorIdListPage = '/cteDocumentoAnteriorIdListPage'; 
	static const cteDocumentoAnteriorIdEditPage = '/cteDocumentoAnteriorIdEditPage';
	static const cteRodoviarioOccListPage = '/cteRodoviarioOccListPage'; 
	static const cteRodoviarioOccEditPage = '/cteRodoviarioOccEditPage';
	static const cteRodoviarioPedagioListPage = '/cteRodoviarioPedagioListPage'; 
	static const cteRodoviarioPedagioEditPage = '/cteRodoviarioPedagioEditPage';
	static const cteRodoviarioVeiculoListPage = '/cteRodoviarioVeiculoListPage'; 
	static const cteRodoviarioVeiculoEditPage = '/cteRodoviarioVeiculoEditPage';
	static const cteRodoviarioLacreListPage = '/cteRodoviarioLacreListPage'; 
	static const cteRodoviarioLacreEditPage = '/cteRodoviarioLacreEditPage';
	static const cteRodoviarioMotoristaListPage = '/cteRodoviarioMotoristaListPage'; 
	static const cteRodoviarioMotoristaEditPage = '/cteRodoviarioMotoristaEditPage';
	static const cteAquaviarioBalsaListPage = '/cteAquaviarioBalsaListPage'; 
	static const cteAquaviarioBalsaEditPage = '/cteAquaviarioBalsaEditPage';
	static const cteFerroviarioFerroviaListPage = '/cteFerroviarioFerroviaListPage'; 
	static const cteFerroviarioFerroviaEditPage = '/cteFerroviarioFerroviaEditPage';
	static const cteFerroviarioVagaoListPage = '/cteFerroviarioVagaoListPage'; 
	static const cteFerroviarioVagaoEditPage = '/cteFerroviarioVagaoEditPage';
}