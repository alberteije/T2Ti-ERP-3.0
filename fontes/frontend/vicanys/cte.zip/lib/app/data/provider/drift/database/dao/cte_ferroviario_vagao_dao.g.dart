// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_ferroviario_vagao_dao.dart';

// ignore_for_file: type=lint
mixin _$CteFerroviarioVagaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteFerroviarioVagaosTable get cteFerroviarioVagaos =>
      attachedDatabase.cteFerroviarioVagaos;
  $CteFerroviariosTable get cteFerroviarios => attachedDatabase.cteFerroviarios;
}
