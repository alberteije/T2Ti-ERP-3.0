// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_rodoviario_motorista_dao.dart';

// ignore_for_file: type=lint
mixin _$CteRodoviarioMotoristaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteRodoviarioMotoristasTable get cteRodoviarioMotoristas =>
      attachedDatabase.cteRodoviarioMotoristas;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
}
