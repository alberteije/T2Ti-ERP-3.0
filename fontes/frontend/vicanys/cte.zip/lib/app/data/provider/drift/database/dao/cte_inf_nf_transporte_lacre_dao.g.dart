// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_inf_nf_transporte_lacre_dao.dart';

// ignore_for_file: type=lint
mixin _$CteInfNfTransporteLacreDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteInfNfTransporteLacresTable get cteInfNfTransporteLacres =>
      attachedDatabase.cteInfNfTransporteLacres;
  $CteInformacaoNfTransportesTable get cteInformacaoNfTransportes =>
      attachedDatabase.cteInformacaoNfTransportes;
}
