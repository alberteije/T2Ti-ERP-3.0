// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_inf_nf_carga_lacre_dao.dart';

// ignore_for_file: type=lint
mixin _$CteInfNfCargaLacreDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteInfNfCargaLacresTable get cteInfNfCargaLacres =>
      attachedDatabase.cteInfNfCargaLacres;
  $CteInformacaoNfCargasTable get cteInformacaoNfCargas =>
      attachedDatabase.cteInformacaoNfCargas;
}
