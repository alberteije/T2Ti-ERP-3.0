// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $CteEmitentesTable extends CteEmitentes
    with TableInfo<$CteEmitentesTable, CteEmitente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteEmitentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        ie,
        nome,
        fantasia,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        telefone
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_emitente';
  @override
  VerificationContext validateIntegrity(Insertable<CteEmitente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteEmitente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteEmitente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
    );
  }

  @override
  $CteEmitentesTable createAlias(String alias) {
    return $CteEmitentesTable(attachedDatabase, alias);
  }
}

class CteEmitente extends DataClass implements Insertable<CteEmitente> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final String? telefone;
  const CteEmitente(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.ie,
      this.nome,
      this.fantasia,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.telefone});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    return map;
  }

  factory CteEmitente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteEmitente(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      telefone: serializer.fromJson<String?>(json['telefone']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'telefone': serializer.toJson<String?>(telefone),
    };
  }

  CteEmitente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> telefone = const Value.absent()}) =>
      CteEmitente(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        telefone: telefone.present ? telefone.value : this.telefone,
      );
  @override
  String toString() {
    return (StringBuffer('CteEmitente(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      ie,
      nome,
      fantasia,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      telefone);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteEmitente &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.telefone == this.telefone);
}

class CteEmitentesCompanion extends UpdateCompanion<CteEmitente> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<String?> telefone;
  const CteEmitentesCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  CteEmitentesCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  static Insertable<CteEmitente> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<String>? telefone,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (telefone != null) 'telefone': telefone,
    });
  }

  CteEmitentesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<String?>? telefone}) {
    return CteEmitentesCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      telefone: telefone ?? this.telefone,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteEmitentesCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }
}

class $CteLocalColetasTable extends CteLocalColetas
    with TableInfo<$CteLocalColetasTable, CteLocalColeta> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteLocalColetasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        nome,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_local_coleta';
  @override
  VerificationContext validateIntegrity(Insertable<CteLocalColeta> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteLocalColeta map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteLocalColeta(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
    );
  }

  @override
  $CteLocalColetasTable createAlias(String alias) {
    return $CteLocalColetasTable(attachedDatabase, alias);
  }
}

class CteLocalColeta extends DataClass implements Insertable<CteLocalColeta> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? nome;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  const CteLocalColeta(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.nome,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    return map;
  }

  factory CteLocalColeta.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteLocalColeta(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      nome: serializer.fromJson<String?>(json['nome']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'nome': serializer.toJson<String?>(nome),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
    };
  }

  CteLocalColeta copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent()}) =>
      CteLocalColeta(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        nome: nome.present ? nome.value : this.nome,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
      );
  @override
  String toString() {
    return (StringBuffer('CteLocalColeta(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      nome,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteLocalColeta &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.nome == this.nome &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf);
}

class CteLocalColetasCompanion extends UpdateCompanion<CteLocalColeta> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> nome;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  const CteLocalColetasCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
  });
  CteLocalColetasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
  });
  static Insertable<CteLocalColeta> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? nome,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (nome != null) 'nome': nome,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
    });
  }

  CteLocalColetasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? nome,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf}) {
    return CteLocalColetasCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      nome: nome ?? this.nome,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteLocalColetasCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf')
          ..write(')'))
        .toString();
  }
}

class $CteTomadorsTable extends CteTomadors
    with TableInfo<$CteTomadorsTable, CteTomador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteTomadorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 255),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoPaisMeta =
      const VerificationMeta('codigoPais');
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
      'codigo_pais', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePaisMeta =
      const VerificationMeta('nomePais');
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
      'nome_pais', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        ie,
        nome,
        fantasia,
        telefone,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        codigoPais,
        nomePais,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_tomador';
  @override
  VerificationContext validateIntegrity(Insertable<CteTomador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
          _codigoPaisMeta,
          codigoPais.isAcceptableOrUnknown(
              data['codigo_pais']!, _codigoPaisMeta));
    }
    if (data.containsKey('nome_pais')) {
      context.handle(_nomePaisMeta,
          nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteTomador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteTomador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      codigoPais: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_pais']),
      nomePais: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pais']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $CteTomadorsTable createAlias(String alias) {
    return $CteTomadorsTable(attachedDatabase, alias);
  }
}

class CteTomador extends DataClass implements Insertable<CteTomador> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const CteTomador(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.ie,
      this.nome,
      this.fantasia,
      this.telefone,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.codigoPais,
      this.nomePais,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory CteTomador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteTomador(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  CteTomador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> codigoPais = const Value.absent(),
          Value<String?> nomePais = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      CteTomador(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        telefone: telefone.present ? telefone.value : this.telefone,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
        nomePais: nomePais.present ? nomePais.value : this.nomePais,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('CteTomador(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      ie,
      nome,
      fantasia,
      telefone,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      codigoPais,
      nomePais,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteTomador &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class CteTomadorsCompanion extends UpdateCompanion<CteTomador> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const CteTomadorsCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  CteTomadorsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<CteTomador> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  CteTomadorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? telefone,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? codigoPais,
      Value<String?>? nomePais,
      Value<String?>? email}) {
    return CteTomadorsCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteTomadorsCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $CtePassagemsTable extends CtePassagems
    with TableInfo<$CtePassagemsTable, CtePassagem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CtePassagemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaPassagemMeta =
      const VerificationMeta('siglaPassagem');
  @override
  late final GeneratedColumn<String> siglaPassagem = GeneratedColumn<String>(
      'sigla_passagem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siglaDestinoMeta =
      const VerificationMeta('siglaDestino');
  @override
  late final GeneratedColumn<String> siglaDestino = GeneratedColumn<String>(
      'sigla_destino', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rotaMeta = const VerificationMeta('rota');
  @override
  late final GeneratedColumn<String> rota = GeneratedColumn<String>(
      'rota', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, siglaPassagem, siglaDestino, rota];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_passagem';
  @override
  VerificationContext validateIntegrity(Insertable<CtePassagem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('sigla_passagem')) {
      context.handle(
          _siglaPassagemMeta,
          siglaPassagem.isAcceptableOrUnknown(
              data['sigla_passagem']!, _siglaPassagemMeta));
    }
    if (data.containsKey('sigla_destino')) {
      context.handle(
          _siglaDestinoMeta,
          siglaDestino.isAcceptableOrUnknown(
              data['sigla_destino']!, _siglaDestinoMeta));
    }
    if (data.containsKey('rota')) {
      context.handle(
          _rotaMeta, rota.isAcceptableOrUnknown(data['rota']!, _rotaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CtePassagem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CtePassagem(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      siglaPassagem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla_passagem']),
      siglaDestino: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla_destino']),
      rota: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rota']),
    );
  }

  @override
  $CtePassagemsTable createAlias(String alias) {
    return $CtePassagemsTable(attachedDatabase, alias);
  }
}

class CtePassagem extends DataClass implements Insertable<CtePassagem> {
  final int? id;
  final int? idCteCabecalho;
  final String? siglaPassagem;
  final String? siglaDestino;
  final String? rota;
  const CtePassagem(
      {this.id,
      this.idCteCabecalho,
      this.siglaPassagem,
      this.siglaDestino,
      this.rota});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || siglaPassagem != null) {
      map['sigla_passagem'] = Variable<String>(siglaPassagem);
    }
    if (!nullToAbsent || siglaDestino != null) {
      map['sigla_destino'] = Variable<String>(siglaDestino);
    }
    if (!nullToAbsent || rota != null) {
      map['rota'] = Variable<String>(rota);
    }
    return map;
  }

  factory CtePassagem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CtePassagem(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      siglaPassagem: serializer.fromJson<String?>(json['siglaPassagem']),
      siglaDestino: serializer.fromJson<String?>(json['siglaDestino']),
      rota: serializer.fromJson<String?>(json['rota']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'siglaPassagem': serializer.toJson<String?>(siglaPassagem),
      'siglaDestino': serializer.toJson<String?>(siglaDestino),
      'rota': serializer.toJson<String?>(rota),
    };
  }

  CtePassagem copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> siglaPassagem = const Value.absent(),
          Value<String?> siglaDestino = const Value.absent(),
          Value<String?> rota = const Value.absent()}) =>
      CtePassagem(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        siglaPassagem:
            siglaPassagem.present ? siglaPassagem.value : this.siglaPassagem,
        siglaDestino:
            siglaDestino.present ? siglaDestino.value : this.siglaDestino,
        rota: rota.present ? rota.value : this.rota,
      );
  @override
  String toString() {
    return (StringBuffer('CtePassagem(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('siglaPassagem: $siglaPassagem, ')
          ..write('siglaDestino: $siglaDestino, ')
          ..write('rota: $rota')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteCabecalho, siglaPassagem, siglaDestino, rota);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CtePassagem &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.siglaPassagem == this.siglaPassagem &&
          other.siglaDestino == this.siglaDestino &&
          other.rota == this.rota);
}

class CtePassagemsCompanion extends UpdateCompanion<CtePassagem> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> siglaPassagem;
  final Value<String?> siglaDestino;
  final Value<String?> rota;
  const CtePassagemsCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.siglaPassagem = const Value.absent(),
    this.siglaDestino = const Value.absent(),
    this.rota = const Value.absent(),
  });
  CtePassagemsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.siglaPassagem = const Value.absent(),
    this.siglaDestino = const Value.absent(),
    this.rota = const Value.absent(),
  });
  static Insertable<CtePassagem> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? siglaPassagem,
    Expression<String>? siglaDestino,
    Expression<String>? rota,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (siglaPassagem != null) 'sigla_passagem': siglaPassagem,
      if (siglaDestino != null) 'sigla_destino': siglaDestino,
      if (rota != null) 'rota': rota,
    });
  }

  CtePassagemsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? siglaPassagem,
      Value<String?>? siglaDestino,
      Value<String?>? rota}) {
    return CtePassagemsCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      siglaPassagem: siglaPassagem ?? this.siglaPassagem,
      siglaDestino: siglaDestino ?? this.siglaDestino,
      rota: rota ?? this.rota,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (siglaPassagem.present) {
      map['sigla_passagem'] = Variable<String>(siglaPassagem.value);
    }
    if (siglaDestino.present) {
      map['sigla_destino'] = Variable<String>(siglaDestino.value);
    }
    if (rota.present) {
      map['rota'] = Variable<String>(rota.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CtePassagemsCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('siglaPassagem: $siglaPassagem, ')
          ..write('siglaDestino: $siglaDestino, ')
          ..write('rota: $rota')
          ..write(')'))
        .toString();
  }
}

class $CteRemetentesTable extends CteRemetentes
    with TableInfo<$CteRemetentesTable, CteRemetente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRemetentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoPaisMeta =
      const VerificationMeta('codigoPais');
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
      'codigo_pais', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePaisMeta =
      const VerificationMeta('nomePais');
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
      'nome_pais', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        ie,
        nome,
        fantasia,
        telefone,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        codigoPais,
        nomePais,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_remetente';
  @override
  VerificationContext validateIntegrity(Insertable<CteRemetente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
          _codigoPaisMeta,
          codigoPais.isAcceptableOrUnknown(
              data['codigo_pais']!, _codigoPaisMeta));
    }
    if (data.containsKey('nome_pais')) {
      context.handle(_nomePaisMeta,
          nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRemetente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRemetente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      codigoPais: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_pais']),
      nomePais: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pais']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $CteRemetentesTable createAlias(String alias) {
    return $CteRemetentesTable(attachedDatabase, alias);
  }
}

class CteRemetente extends DataClass implements Insertable<CteRemetente> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const CteRemetente(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.ie,
      this.nome,
      this.fantasia,
      this.telefone,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.codigoPais,
      this.nomePais,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory CteRemetente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRemetente(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  CteRemetente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> codigoPais = const Value.absent(),
          Value<String?> nomePais = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      CteRemetente(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        telefone: telefone.present ? telefone.value : this.telefone,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
        nomePais: nomePais.present ? nomePais.value : this.nomePais,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('CteRemetente(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      ie,
      nome,
      fantasia,
      telefone,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      codigoPais,
      nomePais,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRemetente &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class CteRemetentesCompanion extends UpdateCompanion<CteRemetente> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const CteRemetentesCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  CteRemetentesCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<CteRemetente> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  CteRemetentesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? telefone,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? codigoPais,
      Value<String?>? nomePais,
      Value<String?>? email}) {
    return CteRemetentesCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRemetentesCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $CteExpedidorsTable extends CteExpedidors
    with TableInfo<$CteExpedidorsTable, CteExpedidor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteExpedidorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoPaisMeta =
      const VerificationMeta('codigoPais');
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
      'codigo_pais', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePaisMeta =
      const VerificationMeta('nomePais');
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
      'nome_pais', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        ie,
        nome,
        fantasia,
        telefone,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        codigoPais,
        nomePais,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_expedidor';
  @override
  VerificationContext validateIntegrity(Insertable<CteExpedidor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
          _codigoPaisMeta,
          codigoPais.isAcceptableOrUnknown(
              data['codigo_pais']!, _codigoPaisMeta));
    }
    if (data.containsKey('nome_pais')) {
      context.handle(_nomePaisMeta,
          nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteExpedidor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteExpedidor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      codigoPais: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_pais']),
      nomePais: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pais']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $CteExpedidorsTable createAlias(String alias) {
    return $CteExpedidorsTable(attachedDatabase, alias);
  }
}

class CteExpedidor extends DataClass implements Insertable<CteExpedidor> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const CteExpedidor(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.ie,
      this.nome,
      this.fantasia,
      this.telefone,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.codigoPais,
      this.nomePais,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory CteExpedidor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteExpedidor(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  CteExpedidor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> codigoPais = const Value.absent(),
          Value<String?> nomePais = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      CteExpedidor(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        telefone: telefone.present ? telefone.value : this.telefone,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
        nomePais: nomePais.present ? nomePais.value : this.nomePais,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('CteExpedidor(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      ie,
      nome,
      fantasia,
      telefone,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      codigoPais,
      nomePais,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteExpedidor &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class CteExpedidorsCompanion extends UpdateCompanion<CteExpedidor> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const CteExpedidorsCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  CteExpedidorsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<CteExpedidor> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  CteExpedidorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? telefone,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? codigoPais,
      Value<String?>? nomePais,
      Value<String?>? email}) {
    return CteExpedidorsCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteExpedidorsCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $CteRecebedorsTable extends CteRecebedors
    with TableInfo<$CteRecebedorsTable, CteRecebedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRecebedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoPaisMeta =
      const VerificationMeta('codigoPais');
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
      'codigo_pais', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePaisMeta =
      const VerificationMeta('nomePais');
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
      'nome_pais', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        ie,
        nome,
        fantasia,
        telefone,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        codigoPais,
        nomePais,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_recebedor';
  @override
  VerificationContext validateIntegrity(Insertable<CteRecebedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
          _codigoPaisMeta,
          codigoPais.isAcceptableOrUnknown(
              data['codigo_pais']!, _codigoPaisMeta));
    }
    if (data.containsKey('nome_pais')) {
      context.handle(_nomePaisMeta,
          nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRecebedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRecebedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      codigoPais: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_pais']),
      nomePais: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pais']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $CteRecebedorsTable createAlias(String alias) {
    return $CteRecebedorsTable(attachedDatabase, alias);
  }
}

class CteRecebedor extends DataClass implements Insertable<CteRecebedor> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const CteRecebedor(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.ie,
      this.nome,
      this.fantasia,
      this.telefone,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.codigoPais,
      this.nomePais,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory CteRecebedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRecebedor(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  CteRecebedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> codigoPais = const Value.absent(),
          Value<String?> nomePais = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      CteRecebedor(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        telefone: telefone.present ? telefone.value : this.telefone,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
        nomePais: nomePais.present ? nomePais.value : this.nomePais,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('CteRecebedor(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      ie,
      nome,
      fantasia,
      telefone,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      codigoPais,
      nomePais,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRecebedor &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class CteRecebedorsCompanion extends UpdateCompanion<CteRecebedor> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const CteRecebedorsCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  CteRecebedorsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<CteRecebedor> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  CteRecebedorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? telefone,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? codigoPais,
      Value<String?>? nomePais,
      Value<String?>? email}) {
    return CteRecebedorsCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRecebedorsCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $CteDestinatariosTable extends CteDestinatarios
    with TableInfo<$CteDestinatariosTable, CteDestinatario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteDestinatariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoPaisMeta =
      const VerificationMeta('codigoPais');
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
      'codigo_pais', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomePaisMeta =
      const VerificationMeta('nomePais');
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
      'nome_pais', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        ie,
        nome,
        fantasia,
        telefone,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep,
        codigoPais,
        nomePais,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_destinatario';
  @override
  VerificationContext validateIntegrity(Insertable<CteDestinatario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
          _codigoPaisMeta,
          codigoPais.isAcceptableOrUnknown(
              data['codigo_pais']!, _codigoPaisMeta));
    }
    if (data.containsKey('nome_pais')) {
      context.handle(_nomePaisMeta,
          nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteDestinatario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteDestinatario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      codigoPais: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_pais']),
      nomePais: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_pais']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $CteDestinatariosTable createAlias(String alias) {
    return $CteDestinatariosTable(attachedDatabase, alias);
  }
}

class CteDestinatario extends DataClass implements Insertable<CteDestinatario> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const CteDestinatario(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.ie,
      this.nome,
      this.fantasia,
      this.telefone,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep,
      this.codigoPais,
      this.nomePais,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory CteDestinatario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteDestinatario(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  CteDestinatario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<int?> codigoPais = const Value.absent(),
          Value<String?> nomePais = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      CteDestinatario(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        telefone: telefone.present ? telefone.value : this.telefone,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
        codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
        nomePais: nomePais.present ? nomePais.value : this.nomePais,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('CteDestinatario(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      ie,
      nome,
      fantasia,
      telefone,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep,
      codigoPais,
      nomePais,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteDestinatario &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class CteDestinatariosCompanion extends UpdateCompanion<CteDestinatario> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const CteDestinatariosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  CteDestinatariosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<CteDestinatario> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  CteDestinatariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? telefone,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep,
      Value<int?>? codigoPais,
      Value<String?>? nomePais,
      Value<String?>? email}) {
    return CteDestinatariosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteDestinatariosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $CteLocalEntregasTable extends CteLocalEntregas
    with TableInfo<$CteLocalEntregasTable, CteLocalEntrega> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteLocalEntregasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        cnpj,
        cpf,
        nome,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_local_entrega';
  @override
  VerificationContext validateIntegrity(Insertable<CteLocalEntrega> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteLocalEntrega map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteLocalEntrega(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
    );
  }

  @override
  $CteLocalEntregasTable createAlias(String alias) {
    return $CteLocalEntregasTable(attachedDatabase, alias);
  }
}

class CteLocalEntrega extends DataClass implements Insertable<CteLocalEntrega> {
  final int? id;
  final int? idCteCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? nome;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  const CteLocalEntrega(
      {this.id,
      this.idCteCabecalho,
      this.cnpj,
      this.cpf,
      this.nome,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    return map;
  }

  factory CteLocalEntrega.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteLocalEntrega(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      nome: serializer.fromJson<String?>(json['nome']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'nome': serializer.toJson<String?>(nome),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
    };
  }

  CteLocalEntrega copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent()}) =>
      CteLocalEntrega(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        cpf: cpf.present ? cpf.value : this.cpf,
        nome: nome.present ? nome.value : this.nome,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
      );
  @override
  String toString() {
    return (StringBuffer('CteLocalEntrega(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      cnpj,
      cpf,
      nome,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteLocalEntrega &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.nome == this.nome &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf);
}

class CteLocalEntregasCompanion extends UpdateCompanion<CteLocalEntrega> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> nome;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  const CteLocalEntregasCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
  });
  CteLocalEntregasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
  });
  static Insertable<CteLocalEntrega> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? nome,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (nome != null) 'nome': nome,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
    });
  }

  CteLocalEntregasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cnpj,
      Value<String?>? cpf,
      Value<String?>? nome,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf}) {
    return CteLocalEntregasCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      nome: nome ?? this.nome,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteLocalEntregasCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf')
          ..write(')'))
        .toString();
  }
}

class $CteComponentesTable extends CteComponentes
    with TableInfo<$CteComponentesTable, CteComponente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteComponentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idCteCabecalho, nome, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_componente';
  @override
  VerificationContext validateIntegrity(Insertable<CteComponente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteComponente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteComponente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $CteComponentesTable createAlias(String alias) {
    return $CteComponentesTable(attachedDatabase, alias);
  }
}

class CteComponente extends DataClass implements Insertable<CteComponente> {
  final int? id;
  final int? idCteCabecalho;
  final String? nome;
  final double? valor;
  const CteComponente({this.id, this.idCteCabecalho, this.nome, this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory CteComponente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteComponente(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      nome: serializer.fromJson<String?>(json['nome']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'nome': serializer.toJson<String?>(nome),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  CteComponente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      CteComponente(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        nome: nome.present ? nome.value : this.nome,
        valor: valor.present ? valor.value : this.valor,
      );
  @override
  String toString() {
    return (StringBuffer('CteComponente(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('nome: $nome, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteCabecalho, nome, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteComponente &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.nome == this.nome &&
          other.valor == this.valor);
}

class CteComponentesCompanion extends UpdateCompanion<CteComponente> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> nome;
  final Value<double?> valor;
  const CteComponentesCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.valor = const Value.absent(),
  });
  CteComponentesCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<CteComponente> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? nome,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (nome != null) 'nome': nome,
      if (valor != null) 'valor': valor,
    });
  }

  CteComponentesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? nome,
      Value<double?>? valor}) {
    return CteComponentesCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      nome: nome ?? this.nome,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteComponentesCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('nome: $nome, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $CteCargasTable extends CteCargas
    with TableInfo<$CteCargasTable, CteCarga> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteCargasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoUnidadeMedidaMeta =
      const VerificationMeta('codigoUnidadeMedida');
  @override
  late final GeneratedColumn<String> codigoUnidadeMedida =
      GeneratedColumn<String>('codigo_unidade_medida', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tipoMedidaMeta =
      const VerificationMeta('tipoMedida');
  @override
  late final GeneratedColumn<String> tipoMedida = GeneratedColumn<String>(
      'tipo_medida', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, codigoUnidadeMedida, tipoMedida, quantidade];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_carga';
  @override
  VerificationContext validateIntegrity(Insertable<CteCarga> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('codigo_unidade_medida')) {
      context.handle(
          _codigoUnidadeMedidaMeta,
          codigoUnidadeMedida.isAcceptableOrUnknown(
              data['codigo_unidade_medida']!, _codigoUnidadeMedidaMeta));
    }
    if (data.containsKey('tipo_medida')) {
      context.handle(
          _tipoMedidaMeta,
          tipoMedida.isAcceptableOrUnknown(
              data['tipo_medida']!, _tipoMedidaMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteCarga map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteCarga(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      codigoUnidadeMedida: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_unidade_medida']),
      tipoMedida: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_medida']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
    );
  }

  @override
  $CteCargasTable createAlias(String alias) {
    return $CteCargasTable(attachedDatabase, alias);
  }
}

class CteCarga extends DataClass implements Insertable<CteCarga> {
  final int? id;
  final int? idCteCabecalho;
  final String? codigoUnidadeMedida;
  final String? tipoMedida;
  final double? quantidade;
  const CteCarga(
      {this.id,
      this.idCteCabecalho,
      this.codigoUnidadeMedida,
      this.tipoMedida,
      this.quantidade});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || codigoUnidadeMedida != null) {
      map['codigo_unidade_medida'] = Variable<String>(codigoUnidadeMedida);
    }
    if (!nullToAbsent || tipoMedida != null) {
      map['tipo_medida'] = Variable<String>(tipoMedida);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    return map;
  }

  factory CteCarga.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteCarga(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      codigoUnidadeMedida:
          serializer.fromJson<String?>(json['codigoUnidadeMedida']),
      tipoMedida: serializer.fromJson<String?>(json['tipoMedida']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'codigoUnidadeMedida': serializer.toJson<String?>(codigoUnidadeMedida),
      'tipoMedida': serializer.toJson<String?>(tipoMedida),
      'quantidade': serializer.toJson<double?>(quantidade),
    };
  }

  CteCarga copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> codigoUnidadeMedida = const Value.absent(),
          Value<String?> tipoMedida = const Value.absent(),
          Value<double?> quantidade = const Value.absent()}) =>
      CteCarga(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        codigoUnidadeMedida: codigoUnidadeMedida.present
            ? codigoUnidadeMedida.value
            : this.codigoUnidadeMedida,
        tipoMedida: tipoMedida.present ? tipoMedida.value : this.tipoMedida,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
      );
  @override
  String toString() {
    return (StringBuffer('CteCarga(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('codigoUnidadeMedida: $codigoUnidadeMedida, ')
          ..write('tipoMedida: $tipoMedida, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCteCabecalho, codigoUnidadeMedida, tipoMedida, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteCarga &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.codigoUnidadeMedida == this.codigoUnidadeMedida &&
          other.tipoMedida == this.tipoMedida &&
          other.quantidade == this.quantidade);
}

class CteCargasCompanion extends UpdateCompanion<CteCarga> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> codigoUnidadeMedida;
  final Value<String?> tipoMedida;
  final Value<double?> quantidade;
  const CteCargasCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.codigoUnidadeMedida = const Value.absent(),
    this.tipoMedida = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  CteCargasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.codigoUnidadeMedida = const Value.absent(),
    this.tipoMedida = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<CteCarga> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? codigoUnidadeMedida,
    Expression<String>? tipoMedida,
    Expression<double>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (codigoUnidadeMedida != null)
        'codigo_unidade_medida': codigoUnidadeMedida,
      if (tipoMedida != null) 'tipo_medida': tipoMedida,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  CteCargasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? codigoUnidadeMedida,
      Value<String?>? tipoMedida,
      Value<double?>? quantidade}) {
    return CteCargasCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      codigoUnidadeMedida: codigoUnidadeMedida ?? this.codigoUnidadeMedida,
      tipoMedida: tipoMedida ?? this.tipoMedida,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (codigoUnidadeMedida.present) {
      map['codigo_unidade_medida'] =
          Variable<String>(codigoUnidadeMedida.value);
    }
    if (tipoMedida.present) {
      map['tipo_medida'] = Variable<String>(tipoMedida.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteCargasCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('codigoUnidadeMedida: $codigoUnidadeMedida, ')
          ..write('tipoMedida: $tipoMedida, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $CteInformacaoNfOutrossTable extends CteInformacaoNfOutross
    with TableInfo<$CteInformacaoNfOutrossTable, CteInformacaoNfOutros> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteInformacaoNfOutrossTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroRomaneioMeta =
      const VerificationMeta('numeroRomaneio');
  @override
  late final GeneratedColumn<String> numeroRomaneio = GeneratedColumn<String>(
      'numero_romaneio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroPedidoMeta =
      const VerificationMeta('numeroPedido');
  @override
  late final GeneratedColumn<String> numeroPedido = GeneratedColumn<String>(
      'numero_pedido', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _chaveAcessoNfeMeta =
      const VerificationMeta('chaveAcessoNfe');
  @override
  late final GeneratedColumn<String> chaveAcessoNfe = GeneratedColumn<String>(
      'chave_acesso_nfe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoModeloMeta =
      const VerificationMeta('codigoModelo');
  @override
  late final GeneratedColumn<String> codigoModelo = GeneratedColumn<String>(
      'codigo_modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ufEmitenteMeta =
      const VerificationMeta('ufEmitente');
  @override
  late final GeneratedColumn<int> ufEmitente = GeneratedColumn<int>(
      'uf_emitente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsMeta =
      const VerificationMeta('baseCalculoIcms');
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
      'base_calculo_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsMeta =
      const VerificationMeta('valorIcms');
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
      'valor_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsStMeta =
      const VerificationMeta('baseCalculoIcmsSt');
  @override
  late final GeneratedColumn<double> baseCalculoIcmsSt =
      GeneratedColumn<double>('base_calculo_icms_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsStMeta =
      const VerificationMeta('valorIcmsSt');
  @override
  late final GeneratedColumn<double> valorIcmsSt = GeneratedColumn<double>(
      'valor_icms_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalProdutosMeta =
      const VerificationMeta('valorTotalProdutos');
  @override
  late final GeneratedColumn<double> valorTotalProdutos =
      GeneratedColumn<double>('valor_total_produtos', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cfopPredominanteMeta =
      const VerificationMeta('cfopPredominante');
  @override
  late final GeneratedColumn<int> cfopPredominante = GeneratedColumn<int>(
      'cfop_predominante', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pesoTotalKgMeta =
      const VerificationMeta('pesoTotalKg');
  @override
  late final GeneratedColumn<double> pesoTotalKg = GeneratedColumn<double>(
      'peso_total_kg', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pinSuframaMeta =
      const VerificationMeta('pinSuframa');
  @override
  late final GeneratedColumn<int> pinSuframa = GeneratedColumn<int>(
      'pin_suframa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaEntregaMeta =
      const VerificationMeta('dataPrevistaEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevistaEntrega =
      GeneratedColumn<DateTime>('data_prevista_entrega', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _outroTipoDocOrigMeta =
      const VerificationMeta('outroTipoDocOrig');
  @override
  late final GeneratedColumn<String> outroTipoDocOrig = GeneratedColumn<String>(
      'outro_tipo_doc_orig', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _outroDescricaoMeta =
      const VerificationMeta('outroDescricao');
  @override
  late final GeneratedColumn<String> outroDescricao = GeneratedColumn<String>(
      'outro_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _outroValorDocumentoMeta =
      const VerificationMeta('outroValorDocumento');
  @override
  late final GeneratedColumn<double> outroValorDocumento =
      GeneratedColumn<double>('outro_valor_documento', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        numeroRomaneio,
        numeroPedido,
        chaveAcessoNfe,
        codigoModelo,
        serie,
        numero,
        dataEmissao,
        ufEmitente,
        baseCalculoIcms,
        valorIcms,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalProdutos,
        valorTotal,
        cfopPredominante,
        pesoTotalKg,
        pinSuframa,
        dataPrevistaEntrega,
        outroTipoDocOrig,
        outroDescricao,
        outroValorDocumento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_informacao_nf_outros';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteInformacaoNfOutros> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('numero_romaneio')) {
      context.handle(
          _numeroRomaneioMeta,
          numeroRomaneio.isAcceptableOrUnknown(
              data['numero_romaneio']!, _numeroRomaneioMeta));
    }
    if (data.containsKey('numero_pedido')) {
      context.handle(
          _numeroPedidoMeta,
          numeroPedido.isAcceptableOrUnknown(
              data['numero_pedido']!, _numeroPedidoMeta));
    }
    if (data.containsKey('chave_acesso_nfe')) {
      context.handle(
          _chaveAcessoNfeMeta,
          chaveAcessoNfe.isAcceptableOrUnknown(
              data['chave_acesso_nfe']!, _chaveAcessoNfeMeta));
    }
    if (data.containsKey('codigo_modelo')) {
      context.handle(
          _codigoModeloMeta,
          codigoModelo.isAcceptableOrUnknown(
              data['codigo_modelo']!, _codigoModeloMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('uf_emitente')) {
      context.handle(
          _ufEmitenteMeta,
          ufEmitente.isAcceptableOrUnknown(
              data['uf_emitente']!, _ufEmitenteMeta));
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
          _baseCalculoIcmsMeta,
          baseCalculoIcms.isAcceptableOrUnknown(
              data['base_calculo_icms']!, _baseCalculoIcmsMeta));
    }
    if (data.containsKey('valor_icms')) {
      context.handle(_valorIcmsMeta,
          valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta));
    }
    if (data.containsKey('base_calculo_icms_st')) {
      context.handle(
          _baseCalculoIcmsStMeta,
          baseCalculoIcmsSt.isAcceptableOrUnknown(
              data['base_calculo_icms_st']!, _baseCalculoIcmsStMeta));
    }
    if (data.containsKey('valor_icms_st')) {
      context.handle(
          _valorIcmsStMeta,
          valorIcmsSt.isAcceptableOrUnknown(
              data['valor_icms_st']!, _valorIcmsStMeta));
    }
    if (data.containsKey('valor_total_produtos')) {
      context.handle(
          _valorTotalProdutosMeta,
          valorTotalProdutos.isAcceptableOrUnknown(
              data['valor_total_produtos']!, _valorTotalProdutosMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('cfop_predominante')) {
      context.handle(
          _cfopPredominanteMeta,
          cfopPredominante.isAcceptableOrUnknown(
              data['cfop_predominante']!, _cfopPredominanteMeta));
    }
    if (data.containsKey('peso_total_kg')) {
      context.handle(
          _pesoTotalKgMeta,
          pesoTotalKg.isAcceptableOrUnknown(
              data['peso_total_kg']!, _pesoTotalKgMeta));
    }
    if (data.containsKey('pin_suframa')) {
      context.handle(
          _pinSuframaMeta,
          pinSuframa.isAcceptableOrUnknown(
              data['pin_suframa']!, _pinSuframaMeta));
    }
    if (data.containsKey('data_prevista_entrega')) {
      context.handle(
          _dataPrevistaEntregaMeta,
          dataPrevistaEntrega.isAcceptableOrUnknown(
              data['data_prevista_entrega']!, _dataPrevistaEntregaMeta));
    }
    if (data.containsKey('outro_tipo_doc_orig')) {
      context.handle(
          _outroTipoDocOrigMeta,
          outroTipoDocOrig.isAcceptableOrUnknown(
              data['outro_tipo_doc_orig']!, _outroTipoDocOrigMeta));
    }
    if (data.containsKey('outro_descricao')) {
      context.handle(
          _outroDescricaoMeta,
          outroDescricao.isAcceptableOrUnknown(
              data['outro_descricao']!, _outroDescricaoMeta));
    }
    if (data.containsKey('outro_valor_documento')) {
      context.handle(
          _outroValorDocumentoMeta,
          outroValorDocumento.isAcceptableOrUnknown(
              data['outro_valor_documento']!, _outroValorDocumentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteInformacaoNfOutros map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteInformacaoNfOutros(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      numeroRomaneio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_romaneio']),
      numeroPedido: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_pedido']),
      chaveAcessoNfe: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}chave_acesso_nfe']),
      codigoModelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_modelo']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      ufEmitente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}uf_emitente']),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms']),
      valorIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms']),
      baseCalculoIcmsSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms_st']),
      valorIcmsSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms_st']),
      valorTotalProdutos: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_produtos']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      cfopPredominante: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop_predominante']),
      pesoTotalKg: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}peso_total_kg']),
      pinSuframa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pin_suframa']),
      dataPrevistaEntrega: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prevista_entrega']),
      outroTipoDocOrig: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}outro_tipo_doc_orig']),
      outroDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}outro_descricao']),
      outroValorDocumento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}outro_valor_documento']),
    );
  }

  @override
  $CteInformacaoNfOutrossTable createAlias(String alias) {
    return $CteInformacaoNfOutrossTable(attachedDatabase, alias);
  }
}

class CteInformacaoNfOutros extends DataClass
    implements Insertable<CteInformacaoNfOutros> {
  final int? id;
  final int? idCteCabecalho;
  final String? numeroRomaneio;
  final String? numeroPedido;
  final String? chaveAcessoNfe;
  final String? codigoModelo;
  final String? serie;
  final String? numero;
  final DateTime? dataEmissao;
  final int? ufEmitente;
  final double? baseCalculoIcms;
  final double? valorIcms;
  final double? baseCalculoIcmsSt;
  final double? valorIcmsSt;
  final double? valorTotalProdutos;
  final double? valorTotal;
  final int? cfopPredominante;
  final double? pesoTotalKg;
  final int? pinSuframa;
  final DateTime? dataPrevistaEntrega;
  final String? outroTipoDocOrig;
  final String? outroDescricao;
  final double? outroValorDocumento;
  const CteInformacaoNfOutros(
      {this.id,
      this.idCteCabecalho,
      this.numeroRomaneio,
      this.numeroPedido,
      this.chaveAcessoNfe,
      this.codigoModelo,
      this.serie,
      this.numero,
      this.dataEmissao,
      this.ufEmitente,
      this.baseCalculoIcms,
      this.valorIcms,
      this.baseCalculoIcmsSt,
      this.valorIcmsSt,
      this.valorTotalProdutos,
      this.valorTotal,
      this.cfopPredominante,
      this.pesoTotalKg,
      this.pinSuframa,
      this.dataPrevistaEntrega,
      this.outroTipoDocOrig,
      this.outroDescricao,
      this.outroValorDocumento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || numeroRomaneio != null) {
      map['numero_romaneio'] = Variable<String>(numeroRomaneio);
    }
    if (!nullToAbsent || numeroPedido != null) {
      map['numero_pedido'] = Variable<String>(numeroPedido);
    }
    if (!nullToAbsent || chaveAcessoNfe != null) {
      map['chave_acesso_nfe'] = Variable<String>(chaveAcessoNfe);
    }
    if (!nullToAbsent || codigoModelo != null) {
      map['codigo_modelo'] = Variable<String>(codigoModelo);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || ufEmitente != null) {
      map['uf_emitente'] = Variable<int>(ufEmitente);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || baseCalculoIcmsSt != null) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt);
    }
    if (!nullToAbsent || valorIcmsSt != null) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt);
    }
    if (!nullToAbsent || valorTotalProdutos != null) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || cfopPredominante != null) {
      map['cfop_predominante'] = Variable<int>(cfopPredominante);
    }
    if (!nullToAbsent || pesoTotalKg != null) {
      map['peso_total_kg'] = Variable<double>(pesoTotalKg);
    }
    if (!nullToAbsent || pinSuframa != null) {
      map['pin_suframa'] = Variable<int>(pinSuframa);
    }
    if (!nullToAbsent || dataPrevistaEntrega != null) {
      map['data_prevista_entrega'] = Variable<DateTime>(dataPrevistaEntrega);
    }
    if (!nullToAbsent || outroTipoDocOrig != null) {
      map['outro_tipo_doc_orig'] = Variable<String>(outroTipoDocOrig);
    }
    if (!nullToAbsent || outroDescricao != null) {
      map['outro_descricao'] = Variable<String>(outroDescricao);
    }
    if (!nullToAbsent || outroValorDocumento != null) {
      map['outro_valor_documento'] = Variable<double>(outroValorDocumento);
    }
    return map;
  }

  factory CteInformacaoNfOutros.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteInformacaoNfOutros(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      numeroRomaneio: serializer.fromJson<String?>(json['numeroRomaneio']),
      numeroPedido: serializer.fromJson<String?>(json['numeroPedido']),
      chaveAcessoNfe: serializer.fromJson<String?>(json['chaveAcessoNfe']),
      codigoModelo: serializer.fromJson<String?>(json['codigoModelo']),
      serie: serializer.fromJson<String?>(json['serie']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      ufEmitente: serializer.fromJson<int?>(json['ufEmitente']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      baseCalculoIcmsSt:
          serializer.fromJson<double?>(json['baseCalculoIcmsSt']),
      valorIcmsSt: serializer.fromJson<double?>(json['valorIcmsSt']),
      valorTotalProdutos:
          serializer.fromJson<double?>(json['valorTotalProdutos']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      cfopPredominante: serializer.fromJson<int?>(json['cfopPredominante']),
      pesoTotalKg: serializer.fromJson<double?>(json['pesoTotalKg']),
      pinSuframa: serializer.fromJson<int?>(json['pinSuframa']),
      dataPrevistaEntrega:
          serializer.fromJson<DateTime?>(json['dataPrevistaEntrega']),
      outroTipoDocOrig: serializer.fromJson<String?>(json['outroTipoDocOrig']),
      outroDescricao: serializer.fromJson<String?>(json['outroDescricao']),
      outroValorDocumento:
          serializer.fromJson<double?>(json['outroValorDocumento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'numeroRomaneio': serializer.toJson<String?>(numeroRomaneio),
      'numeroPedido': serializer.toJson<String?>(numeroPedido),
      'chaveAcessoNfe': serializer.toJson<String?>(chaveAcessoNfe),
      'codigoModelo': serializer.toJson<String?>(codigoModelo),
      'serie': serializer.toJson<String?>(serie),
      'numero': serializer.toJson<String?>(numero),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'ufEmitente': serializer.toJson<int?>(ufEmitente),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'baseCalculoIcmsSt': serializer.toJson<double?>(baseCalculoIcmsSt),
      'valorIcmsSt': serializer.toJson<double?>(valorIcmsSt),
      'valorTotalProdutos': serializer.toJson<double?>(valorTotalProdutos),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'cfopPredominante': serializer.toJson<int?>(cfopPredominante),
      'pesoTotalKg': serializer.toJson<double?>(pesoTotalKg),
      'pinSuframa': serializer.toJson<int?>(pinSuframa),
      'dataPrevistaEntrega': serializer.toJson<DateTime?>(dataPrevistaEntrega),
      'outroTipoDocOrig': serializer.toJson<String?>(outroTipoDocOrig),
      'outroDescricao': serializer.toJson<String?>(outroDescricao),
      'outroValorDocumento': serializer.toJson<double?>(outroValorDocumento),
    };
  }

  CteInformacaoNfOutros copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> numeroRomaneio = const Value.absent(),
          Value<String?> numeroPedido = const Value.absent(),
          Value<String?> chaveAcessoNfe = const Value.absent(),
          Value<String?> codigoModelo = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<int?> ufEmitente = const Value.absent(),
          Value<double?> baseCalculoIcms = const Value.absent(),
          Value<double?> valorIcms = const Value.absent(),
          Value<double?> baseCalculoIcmsSt = const Value.absent(),
          Value<double?> valorIcmsSt = const Value.absent(),
          Value<double?> valorTotalProdutos = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<int?> cfopPredominante = const Value.absent(),
          Value<double?> pesoTotalKg = const Value.absent(),
          Value<int?> pinSuframa = const Value.absent(),
          Value<DateTime?> dataPrevistaEntrega = const Value.absent(),
          Value<String?> outroTipoDocOrig = const Value.absent(),
          Value<String?> outroDescricao = const Value.absent(),
          Value<double?> outroValorDocumento = const Value.absent()}) =>
      CteInformacaoNfOutros(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        numeroRomaneio:
            numeroRomaneio.present ? numeroRomaneio.value : this.numeroRomaneio,
        numeroPedido:
            numeroPedido.present ? numeroPedido.value : this.numeroPedido,
        chaveAcessoNfe:
            chaveAcessoNfe.present ? chaveAcessoNfe.value : this.chaveAcessoNfe,
        codigoModelo:
            codigoModelo.present ? codigoModelo.value : this.codigoModelo,
        serie: serie.present ? serie.value : this.serie,
        numero: numero.present ? numero.value : this.numero,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        ufEmitente: ufEmitente.present ? ufEmitente.value : this.ufEmitente,
        baseCalculoIcms: baseCalculoIcms.present
            ? baseCalculoIcms.value
            : this.baseCalculoIcms,
        valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
        baseCalculoIcmsSt: baseCalculoIcmsSt.present
            ? baseCalculoIcmsSt.value
            : this.baseCalculoIcmsSt,
        valorIcmsSt: valorIcmsSt.present ? valorIcmsSt.value : this.valorIcmsSt,
        valorTotalProdutos: valorTotalProdutos.present
            ? valorTotalProdutos.value
            : this.valorTotalProdutos,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        cfopPredominante: cfopPredominante.present
            ? cfopPredominante.value
            : this.cfopPredominante,
        pesoTotalKg: pesoTotalKg.present ? pesoTotalKg.value : this.pesoTotalKg,
        pinSuframa: pinSuframa.present ? pinSuframa.value : this.pinSuframa,
        dataPrevistaEntrega: dataPrevistaEntrega.present
            ? dataPrevistaEntrega.value
            : this.dataPrevistaEntrega,
        outroTipoDocOrig: outroTipoDocOrig.present
            ? outroTipoDocOrig.value
            : this.outroTipoDocOrig,
        outroDescricao:
            outroDescricao.present ? outroDescricao.value : this.outroDescricao,
        outroValorDocumento: outroValorDocumento.present
            ? outroValorDocumento.value
            : this.outroValorDocumento,
      );
  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfOutros(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroRomaneio: $numeroRomaneio, ')
          ..write('numeroPedido: $numeroPedido, ')
          ..write('chaveAcessoNfe: $chaveAcessoNfe, ')
          ..write('codigoModelo: $codigoModelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('cfopPredominante: $cfopPredominante, ')
          ..write('pesoTotalKg: $pesoTotalKg, ')
          ..write('pinSuframa: $pinSuframa, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('outroTipoDocOrig: $outroTipoDocOrig, ')
          ..write('outroDescricao: $outroDescricao, ')
          ..write('outroValorDocumento: $outroValorDocumento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idCteCabecalho,
        numeroRomaneio,
        numeroPedido,
        chaveAcessoNfe,
        codigoModelo,
        serie,
        numero,
        dataEmissao,
        ufEmitente,
        baseCalculoIcms,
        valorIcms,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalProdutos,
        valorTotal,
        cfopPredominante,
        pesoTotalKg,
        pinSuframa,
        dataPrevistaEntrega,
        outroTipoDocOrig,
        outroDescricao,
        outroValorDocumento
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteInformacaoNfOutros &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.numeroRomaneio == this.numeroRomaneio &&
          other.numeroPedido == this.numeroPedido &&
          other.chaveAcessoNfe == this.chaveAcessoNfe &&
          other.codigoModelo == this.codigoModelo &&
          other.serie == this.serie &&
          other.numero == this.numero &&
          other.dataEmissao == this.dataEmissao &&
          other.ufEmitente == this.ufEmitente &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.valorIcms == this.valorIcms &&
          other.baseCalculoIcmsSt == this.baseCalculoIcmsSt &&
          other.valorIcmsSt == this.valorIcmsSt &&
          other.valorTotalProdutos == this.valorTotalProdutos &&
          other.valorTotal == this.valorTotal &&
          other.cfopPredominante == this.cfopPredominante &&
          other.pesoTotalKg == this.pesoTotalKg &&
          other.pinSuframa == this.pinSuframa &&
          other.dataPrevistaEntrega == this.dataPrevistaEntrega &&
          other.outroTipoDocOrig == this.outroTipoDocOrig &&
          other.outroDescricao == this.outroDescricao &&
          other.outroValorDocumento == this.outroValorDocumento);
}

class CteInformacaoNfOutrossCompanion
    extends UpdateCompanion<CteInformacaoNfOutros> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> numeroRomaneio;
  final Value<String?> numeroPedido;
  final Value<String?> chaveAcessoNfe;
  final Value<String?> codigoModelo;
  final Value<String?> serie;
  final Value<String?> numero;
  final Value<DateTime?> dataEmissao;
  final Value<int?> ufEmitente;
  final Value<double?> baseCalculoIcms;
  final Value<double?> valorIcms;
  final Value<double?> baseCalculoIcmsSt;
  final Value<double?> valorIcmsSt;
  final Value<double?> valorTotalProdutos;
  final Value<double?> valorTotal;
  final Value<int?> cfopPredominante;
  final Value<double?> pesoTotalKg;
  final Value<int?> pinSuframa;
  final Value<DateTime?> dataPrevistaEntrega;
  final Value<String?> outroTipoDocOrig;
  final Value<String?> outroDescricao;
  final Value<double?> outroValorDocumento;
  const CteInformacaoNfOutrossCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroRomaneio = const Value.absent(),
    this.numeroPedido = const Value.absent(),
    this.chaveAcessoNfe = const Value.absent(),
    this.codigoModelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.cfopPredominante = const Value.absent(),
    this.pesoTotalKg = const Value.absent(),
    this.pinSuframa = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.outroTipoDocOrig = const Value.absent(),
    this.outroDescricao = const Value.absent(),
    this.outroValorDocumento = const Value.absent(),
  });
  CteInformacaoNfOutrossCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroRomaneio = const Value.absent(),
    this.numeroPedido = const Value.absent(),
    this.chaveAcessoNfe = const Value.absent(),
    this.codigoModelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.cfopPredominante = const Value.absent(),
    this.pesoTotalKg = const Value.absent(),
    this.pinSuframa = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.outroTipoDocOrig = const Value.absent(),
    this.outroDescricao = const Value.absent(),
    this.outroValorDocumento = const Value.absent(),
  });
  static Insertable<CteInformacaoNfOutros> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? numeroRomaneio,
    Expression<String>? numeroPedido,
    Expression<String>? chaveAcessoNfe,
    Expression<String>? codigoModelo,
    Expression<String>? serie,
    Expression<String>? numero,
    Expression<DateTime>? dataEmissao,
    Expression<int>? ufEmitente,
    Expression<double>? baseCalculoIcms,
    Expression<double>? valorIcms,
    Expression<double>? baseCalculoIcmsSt,
    Expression<double>? valorIcmsSt,
    Expression<double>? valorTotalProdutos,
    Expression<double>? valorTotal,
    Expression<int>? cfopPredominante,
    Expression<double>? pesoTotalKg,
    Expression<int>? pinSuframa,
    Expression<DateTime>? dataPrevistaEntrega,
    Expression<String>? outroTipoDocOrig,
    Expression<String>? outroDescricao,
    Expression<double>? outroValorDocumento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (numeroRomaneio != null) 'numero_romaneio': numeroRomaneio,
      if (numeroPedido != null) 'numero_pedido': numeroPedido,
      if (chaveAcessoNfe != null) 'chave_acesso_nfe': chaveAcessoNfe,
      if (codigoModelo != null) 'codigo_modelo': codigoModelo,
      if (serie != null) 'serie': serie,
      if (numero != null) 'numero': numero,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (ufEmitente != null) 'uf_emitente': ufEmitente,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (baseCalculoIcmsSt != null) 'base_calculo_icms_st': baseCalculoIcmsSt,
      if (valorIcmsSt != null) 'valor_icms_st': valorIcmsSt,
      if (valorTotalProdutos != null)
        'valor_total_produtos': valorTotalProdutos,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (cfopPredominante != null) 'cfop_predominante': cfopPredominante,
      if (pesoTotalKg != null) 'peso_total_kg': pesoTotalKg,
      if (pinSuframa != null) 'pin_suframa': pinSuframa,
      if (dataPrevistaEntrega != null)
        'data_prevista_entrega': dataPrevistaEntrega,
      if (outroTipoDocOrig != null) 'outro_tipo_doc_orig': outroTipoDocOrig,
      if (outroDescricao != null) 'outro_descricao': outroDescricao,
      if (outroValorDocumento != null)
        'outro_valor_documento': outroValorDocumento,
    });
  }

  CteInformacaoNfOutrossCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? numeroRomaneio,
      Value<String?>? numeroPedido,
      Value<String?>? chaveAcessoNfe,
      Value<String?>? codigoModelo,
      Value<String?>? serie,
      Value<String?>? numero,
      Value<DateTime?>? dataEmissao,
      Value<int?>? ufEmitente,
      Value<double?>? baseCalculoIcms,
      Value<double?>? valorIcms,
      Value<double?>? baseCalculoIcmsSt,
      Value<double?>? valorIcmsSt,
      Value<double?>? valorTotalProdutos,
      Value<double?>? valorTotal,
      Value<int?>? cfopPredominante,
      Value<double?>? pesoTotalKg,
      Value<int?>? pinSuframa,
      Value<DateTime?>? dataPrevistaEntrega,
      Value<String?>? outroTipoDocOrig,
      Value<String?>? outroDescricao,
      Value<double?>? outroValorDocumento}) {
    return CteInformacaoNfOutrossCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      numeroRomaneio: numeroRomaneio ?? this.numeroRomaneio,
      numeroPedido: numeroPedido ?? this.numeroPedido,
      chaveAcessoNfe: chaveAcessoNfe ?? this.chaveAcessoNfe,
      codigoModelo: codigoModelo ?? this.codigoModelo,
      serie: serie ?? this.serie,
      numero: numero ?? this.numero,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      ufEmitente: ufEmitente ?? this.ufEmitente,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      baseCalculoIcmsSt: baseCalculoIcmsSt ?? this.baseCalculoIcmsSt,
      valorIcmsSt: valorIcmsSt ?? this.valorIcmsSt,
      valorTotalProdutos: valorTotalProdutos ?? this.valorTotalProdutos,
      valorTotal: valorTotal ?? this.valorTotal,
      cfopPredominante: cfopPredominante ?? this.cfopPredominante,
      pesoTotalKg: pesoTotalKg ?? this.pesoTotalKg,
      pinSuframa: pinSuframa ?? this.pinSuframa,
      dataPrevistaEntrega: dataPrevistaEntrega ?? this.dataPrevistaEntrega,
      outroTipoDocOrig: outroTipoDocOrig ?? this.outroTipoDocOrig,
      outroDescricao: outroDescricao ?? this.outroDescricao,
      outroValorDocumento: outroValorDocumento ?? this.outroValorDocumento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (numeroRomaneio.present) {
      map['numero_romaneio'] = Variable<String>(numeroRomaneio.value);
    }
    if (numeroPedido.present) {
      map['numero_pedido'] = Variable<String>(numeroPedido.value);
    }
    if (chaveAcessoNfe.present) {
      map['chave_acesso_nfe'] = Variable<String>(chaveAcessoNfe.value);
    }
    if (codigoModelo.present) {
      map['codigo_modelo'] = Variable<String>(codigoModelo.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (ufEmitente.present) {
      map['uf_emitente'] = Variable<int>(ufEmitente.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (baseCalculoIcmsSt.present) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt.value);
    }
    if (valorIcmsSt.present) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt.value);
    }
    if (valorTotalProdutos.present) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (cfopPredominante.present) {
      map['cfop_predominante'] = Variable<int>(cfopPredominante.value);
    }
    if (pesoTotalKg.present) {
      map['peso_total_kg'] = Variable<double>(pesoTotalKg.value);
    }
    if (pinSuframa.present) {
      map['pin_suframa'] = Variable<int>(pinSuframa.value);
    }
    if (dataPrevistaEntrega.present) {
      map['data_prevista_entrega'] =
          Variable<DateTime>(dataPrevistaEntrega.value);
    }
    if (outroTipoDocOrig.present) {
      map['outro_tipo_doc_orig'] = Variable<String>(outroTipoDocOrig.value);
    }
    if (outroDescricao.present) {
      map['outro_descricao'] = Variable<String>(outroDescricao.value);
    }
    if (outroValorDocumento.present) {
      map['outro_valor_documento'] =
          Variable<double>(outroValorDocumento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfOutrossCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroRomaneio: $numeroRomaneio, ')
          ..write('numeroPedido: $numeroPedido, ')
          ..write('chaveAcessoNfe: $chaveAcessoNfe, ')
          ..write('codigoModelo: $codigoModelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('cfopPredominante: $cfopPredominante, ')
          ..write('pesoTotalKg: $pesoTotalKg, ')
          ..write('pinSuframa: $pinSuframa, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('outroTipoDocOrig: $outroTipoDocOrig, ')
          ..write('outroDescricao: $outroDescricao, ')
          ..write('outroValorDocumento: $outroValorDocumento')
          ..write(')'))
        .toString();
  }
}

class $CteSegurosTable extends CteSeguros
    with TableInfo<$CteSegurosTable, CteSeguro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteSegurosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _responsavelMeta =
      const VerificationMeta('responsavel');
  @override
  late final GeneratedColumn<String> responsavel = GeneratedColumn<String>(
      'responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _seguradoraMeta =
      const VerificationMeta('seguradora');
  @override
  late final GeneratedColumn<String> seguradora = GeneratedColumn<String>(
      'seguradora', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _apoliceMeta =
      const VerificationMeta('apolice');
  @override
  late final GeneratedColumn<String> apolice = GeneratedColumn<String>(
      'apolice', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _averbacaoMeta =
      const VerificationMeta('averbacao');
  @override
  late final GeneratedColumn<String> averbacao = GeneratedColumn<String>(
      'averbacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCargaMeta =
      const VerificationMeta('valorCarga');
  @override
  late final GeneratedColumn<double> valorCarga = GeneratedColumn<double>(
      'valor_carga', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        responsavel,
        seguradora,
        apolice,
        averbacao,
        valorCarga
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_seguro';
  @override
  VerificationContext validateIntegrity(Insertable<CteSeguro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('responsavel')) {
      context.handle(
          _responsavelMeta,
          responsavel.isAcceptableOrUnknown(
              data['responsavel']!, _responsavelMeta));
    }
    if (data.containsKey('seguradora')) {
      context.handle(
          _seguradoraMeta,
          seguradora.isAcceptableOrUnknown(
              data['seguradora']!, _seguradoraMeta));
    }
    if (data.containsKey('apolice')) {
      context.handle(_apoliceMeta,
          apolice.isAcceptableOrUnknown(data['apolice']!, _apoliceMeta));
    }
    if (data.containsKey('averbacao')) {
      context.handle(_averbacaoMeta,
          averbacao.isAcceptableOrUnknown(data['averbacao']!, _averbacaoMeta));
    }
    if (data.containsKey('valor_carga')) {
      context.handle(
          _valorCargaMeta,
          valorCarga.isAcceptableOrUnknown(
              data['valor_carga']!, _valorCargaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteSeguro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteSeguro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      responsavel: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}responsavel']),
      seguradora: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}seguradora']),
      apolice: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}apolice']),
      averbacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}averbacao']),
      valorCarga: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_carga']),
    );
  }

  @override
  $CteSegurosTable createAlias(String alias) {
    return $CteSegurosTable(attachedDatabase, alias);
  }
}

class CteSeguro extends DataClass implements Insertable<CteSeguro> {
  final int? id;
  final int? idCteCabecalho;
  final String? responsavel;
  final String? seguradora;
  final String? apolice;
  final String? averbacao;
  final double? valorCarga;
  const CteSeguro(
      {this.id,
      this.idCteCabecalho,
      this.responsavel,
      this.seguradora,
      this.apolice,
      this.averbacao,
      this.valorCarga});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || responsavel != null) {
      map['responsavel'] = Variable<String>(responsavel);
    }
    if (!nullToAbsent || seguradora != null) {
      map['seguradora'] = Variable<String>(seguradora);
    }
    if (!nullToAbsent || apolice != null) {
      map['apolice'] = Variable<String>(apolice);
    }
    if (!nullToAbsent || averbacao != null) {
      map['averbacao'] = Variable<String>(averbacao);
    }
    if (!nullToAbsent || valorCarga != null) {
      map['valor_carga'] = Variable<double>(valorCarga);
    }
    return map;
  }

  factory CteSeguro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteSeguro(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      responsavel: serializer.fromJson<String?>(json['responsavel']),
      seguradora: serializer.fromJson<String?>(json['seguradora']),
      apolice: serializer.fromJson<String?>(json['apolice']),
      averbacao: serializer.fromJson<String?>(json['averbacao']),
      valorCarga: serializer.fromJson<double?>(json['valorCarga']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'responsavel': serializer.toJson<String?>(responsavel),
      'seguradora': serializer.toJson<String?>(seguradora),
      'apolice': serializer.toJson<String?>(apolice),
      'averbacao': serializer.toJson<String?>(averbacao),
      'valorCarga': serializer.toJson<double?>(valorCarga),
    };
  }

  CteSeguro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> responsavel = const Value.absent(),
          Value<String?> seguradora = const Value.absent(),
          Value<String?> apolice = const Value.absent(),
          Value<String?> averbacao = const Value.absent(),
          Value<double?> valorCarga = const Value.absent()}) =>
      CteSeguro(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        responsavel: responsavel.present ? responsavel.value : this.responsavel,
        seguradora: seguradora.present ? seguradora.value : this.seguradora,
        apolice: apolice.present ? apolice.value : this.apolice,
        averbacao: averbacao.present ? averbacao.value : this.averbacao,
        valorCarga: valorCarga.present ? valorCarga.value : this.valorCarga,
      );
  @override
  String toString() {
    return (StringBuffer('CteSeguro(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('responsavel: $responsavel, ')
          ..write('seguradora: $seguradora, ')
          ..write('apolice: $apolice, ')
          ..write('averbacao: $averbacao, ')
          ..write('valorCarga: $valorCarga')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteCabecalho, responsavel, seguradora,
      apolice, averbacao, valorCarga);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteSeguro &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.responsavel == this.responsavel &&
          other.seguradora == this.seguradora &&
          other.apolice == this.apolice &&
          other.averbacao == this.averbacao &&
          other.valorCarga == this.valorCarga);
}

class CteSegurosCompanion extends UpdateCompanion<CteSeguro> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> responsavel;
  final Value<String?> seguradora;
  final Value<String?> apolice;
  final Value<String?> averbacao;
  final Value<double?> valorCarga;
  const CteSegurosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.seguradora = const Value.absent(),
    this.apolice = const Value.absent(),
    this.averbacao = const Value.absent(),
    this.valorCarga = const Value.absent(),
  });
  CteSegurosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.seguradora = const Value.absent(),
    this.apolice = const Value.absent(),
    this.averbacao = const Value.absent(),
    this.valorCarga = const Value.absent(),
  });
  static Insertable<CteSeguro> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? responsavel,
    Expression<String>? seguradora,
    Expression<String>? apolice,
    Expression<String>? averbacao,
    Expression<double>? valorCarga,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (responsavel != null) 'responsavel': responsavel,
      if (seguradora != null) 'seguradora': seguradora,
      if (apolice != null) 'apolice': apolice,
      if (averbacao != null) 'averbacao': averbacao,
      if (valorCarga != null) 'valor_carga': valorCarga,
    });
  }

  CteSegurosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? responsavel,
      Value<String?>? seguradora,
      Value<String?>? apolice,
      Value<String?>? averbacao,
      Value<double?>? valorCarga}) {
    return CteSegurosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      responsavel: responsavel ?? this.responsavel,
      seguradora: seguradora ?? this.seguradora,
      apolice: apolice ?? this.apolice,
      averbacao: averbacao ?? this.averbacao,
      valorCarga: valorCarga ?? this.valorCarga,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (responsavel.present) {
      map['responsavel'] = Variable<String>(responsavel.value);
    }
    if (seguradora.present) {
      map['seguradora'] = Variable<String>(seguradora.value);
    }
    if (apolice.present) {
      map['apolice'] = Variable<String>(apolice.value);
    }
    if (averbacao.present) {
      map['averbacao'] = Variable<String>(averbacao.value);
    }
    if (valorCarga.present) {
      map['valor_carga'] = Variable<double>(valorCarga.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteSegurosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('responsavel: $responsavel, ')
          ..write('seguradora: $seguradora, ')
          ..write('apolice: $apolice, ')
          ..write('averbacao: $averbacao, ')
          ..write('valorCarga: $valorCarga')
          ..write(')'))
        .toString();
  }
}

class $CtePerigososTable extends CtePerigosos
    with TableInfo<$CtePerigososTable, CtePerigoso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CtePerigososTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroOnuMeta =
      const VerificationMeta('numeroOnu');
  @override
  late final GeneratedColumn<String> numeroOnu = GeneratedColumn<String>(
      'numero_onu', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeApropriadoMeta =
      const VerificationMeta('nomeApropriado');
  @override
  late final GeneratedColumn<String> nomeApropriado = GeneratedColumn<String>(
      'nome_apropriado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _classeRiscoMeta =
      const VerificationMeta('classeRisco');
  @override
  late final GeneratedColumn<String> classeRisco = GeneratedColumn<String>(
      'classe_risco', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 40),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _grupoEmbalagemMeta =
      const VerificationMeta('grupoEmbalagem');
  @override
  late final GeneratedColumn<String> grupoEmbalagem = GeneratedColumn<String>(
      'grupo_embalagem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 6),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeTotalProdutoMeta =
      const VerificationMeta('quantidadeTotalProduto');
  @override
  late final GeneratedColumn<String> quantidadeTotalProduto =
      GeneratedColumn<String>('quantidade_total_produto', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _quantidadeTipoVolumeMeta =
      const VerificationMeta('quantidadeTipoVolume');
  @override
  late final GeneratedColumn<String> quantidadeTipoVolume =
      GeneratedColumn<String>(
          'quantidade_tipo_volume', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pontoFulgorMeta =
      const VerificationMeta('pontoFulgor');
  @override
  late final GeneratedColumn<String> pontoFulgor = GeneratedColumn<String>(
      'ponto_fulgor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 6),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        numeroOnu,
        nomeApropriado,
        classeRisco,
        grupoEmbalagem,
        quantidadeTotalProduto,
        quantidadeTipoVolume,
        pontoFulgor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_perigoso';
  @override
  VerificationContext validateIntegrity(Insertable<CtePerigoso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('numero_onu')) {
      context.handle(_numeroOnuMeta,
          numeroOnu.isAcceptableOrUnknown(data['numero_onu']!, _numeroOnuMeta));
    }
    if (data.containsKey('nome_apropriado')) {
      context.handle(
          _nomeApropriadoMeta,
          nomeApropriado.isAcceptableOrUnknown(
              data['nome_apropriado']!, _nomeApropriadoMeta));
    }
    if (data.containsKey('classe_risco')) {
      context.handle(
          _classeRiscoMeta,
          classeRisco.isAcceptableOrUnknown(
              data['classe_risco']!, _classeRiscoMeta));
    }
    if (data.containsKey('grupo_embalagem')) {
      context.handle(
          _grupoEmbalagemMeta,
          grupoEmbalagem.isAcceptableOrUnknown(
              data['grupo_embalagem']!, _grupoEmbalagemMeta));
    }
    if (data.containsKey('quantidade_total_produto')) {
      context.handle(
          _quantidadeTotalProdutoMeta,
          quantidadeTotalProduto.isAcceptableOrUnknown(
              data['quantidade_total_produto']!, _quantidadeTotalProdutoMeta));
    }
    if (data.containsKey('quantidade_tipo_volume')) {
      context.handle(
          _quantidadeTipoVolumeMeta,
          quantidadeTipoVolume.isAcceptableOrUnknown(
              data['quantidade_tipo_volume']!, _quantidadeTipoVolumeMeta));
    }
    if (data.containsKey('ponto_fulgor')) {
      context.handle(
          _pontoFulgorMeta,
          pontoFulgor.isAcceptableOrUnknown(
              data['ponto_fulgor']!, _pontoFulgorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CtePerigoso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CtePerigoso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      numeroOnu: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_onu']),
      nomeApropriado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_apropriado']),
      classeRisco: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}classe_risco']),
      grupoEmbalagem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}grupo_embalagem']),
      quantidadeTotalProduto: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}quantidade_total_produto']),
      quantidadeTipoVolume: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}quantidade_tipo_volume']),
      pontoFulgor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ponto_fulgor']),
    );
  }

  @override
  $CtePerigososTable createAlias(String alias) {
    return $CtePerigososTable(attachedDatabase, alias);
  }
}

class CtePerigoso extends DataClass implements Insertable<CtePerigoso> {
  final int? id;
  final int? idCteCabecalho;
  final String? numeroOnu;
  final String? nomeApropriado;
  final String? classeRisco;
  final String? grupoEmbalagem;
  final String? quantidadeTotalProduto;
  final String? quantidadeTipoVolume;
  final String? pontoFulgor;
  const CtePerigoso(
      {this.id,
      this.idCteCabecalho,
      this.numeroOnu,
      this.nomeApropriado,
      this.classeRisco,
      this.grupoEmbalagem,
      this.quantidadeTotalProduto,
      this.quantidadeTipoVolume,
      this.pontoFulgor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || numeroOnu != null) {
      map['numero_onu'] = Variable<String>(numeroOnu);
    }
    if (!nullToAbsent || nomeApropriado != null) {
      map['nome_apropriado'] = Variable<String>(nomeApropriado);
    }
    if (!nullToAbsent || classeRisco != null) {
      map['classe_risco'] = Variable<String>(classeRisco);
    }
    if (!nullToAbsent || grupoEmbalagem != null) {
      map['grupo_embalagem'] = Variable<String>(grupoEmbalagem);
    }
    if (!nullToAbsent || quantidadeTotalProduto != null) {
      map['quantidade_total_produto'] =
          Variable<String>(quantidadeTotalProduto);
    }
    if (!nullToAbsent || quantidadeTipoVolume != null) {
      map['quantidade_tipo_volume'] = Variable<String>(quantidadeTipoVolume);
    }
    if (!nullToAbsent || pontoFulgor != null) {
      map['ponto_fulgor'] = Variable<String>(pontoFulgor);
    }
    return map;
  }

  factory CtePerigoso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CtePerigoso(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      numeroOnu: serializer.fromJson<String?>(json['numeroOnu']),
      nomeApropriado: serializer.fromJson<String?>(json['nomeApropriado']),
      classeRisco: serializer.fromJson<String?>(json['classeRisco']),
      grupoEmbalagem: serializer.fromJson<String?>(json['grupoEmbalagem']),
      quantidadeTotalProduto:
          serializer.fromJson<String?>(json['quantidadeTotalProduto']),
      quantidadeTipoVolume:
          serializer.fromJson<String?>(json['quantidadeTipoVolume']),
      pontoFulgor: serializer.fromJson<String?>(json['pontoFulgor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'numeroOnu': serializer.toJson<String?>(numeroOnu),
      'nomeApropriado': serializer.toJson<String?>(nomeApropriado),
      'classeRisco': serializer.toJson<String?>(classeRisco),
      'grupoEmbalagem': serializer.toJson<String?>(grupoEmbalagem),
      'quantidadeTotalProduto':
          serializer.toJson<String?>(quantidadeTotalProduto),
      'quantidadeTipoVolume': serializer.toJson<String?>(quantidadeTipoVolume),
      'pontoFulgor': serializer.toJson<String?>(pontoFulgor),
    };
  }

  CtePerigoso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> numeroOnu = const Value.absent(),
          Value<String?> nomeApropriado = const Value.absent(),
          Value<String?> classeRisco = const Value.absent(),
          Value<String?> grupoEmbalagem = const Value.absent(),
          Value<String?> quantidadeTotalProduto = const Value.absent(),
          Value<String?> quantidadeTipoVolume = const Value.absent(),
          Value<String?> pontoFulgor = const Value.absent()}) =>
      CtePerigoso(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        numeroOnu: numeroOnu.present ? numeroOnu.value : this.numeroOnu,
        nomeApropriado:
            nomeApropriado.present ? nomeApropriado.value : this.nomeApropriado,
        classeRisco: classeRisco.present ? classeRisco.value : this.classeRisco,
        grupoEmbalagem:
            grupoEmbalagem.present ? grupoEmbalagem.value : this.grupoEmbalagem,
        quantidadeTotalProduto: quantidadeTotalProduto.present
            ? quantidadeTotalProduto.value
            : this.quantidadeTotalProduto,
        quantidadeTipoVolume: quantidadeTipoVolume.present
            ? quantidadeTipoVolume.value
            : this.quantidadeTipoVolume,
        pontoFulgor: pontoFulgor.present ? pontoFulgor.value : this.pontoFulgor,
      );
  @override
  String toString() {
    return (StringBuffer('CtePerigoso(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroOnu: $numeroOnu, ')
          ..write('nomeApropriado: $nomeApropriado, ')
          ..write('classeRisco: $classeRisco, ')
          ..write('grupoEmbalagem: $grupoEmbalagem, ')
          ..write('quantidadeTotalProduto: $quantidadeTotalProduto, ')
          ..write('quantidadeTipoVolume: $quantidadeTipoVolume, ')
          ..write('pontoFulgor: $pontoFulgor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      numeroOnu,
      nomeApropriado,
      classeRisco,
      grupoEmbalagem,
      quantidadeTotalProduto,
      quantidadeTipoVolume,
      pontoFulgor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CtePerigoso &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.numeroOnu == this.numeroOnu &&
          other.nomeApropriado == this.nomeApropriado &&
          other.classeRisco == this.classeRisco &&
          other.grupoEmbalagem == this.grupoEmbalagem &&
          other.quantidadeTotalProduto == this.quantidadeTotalProduto &&
          other.quantidadeTipoVolume == this.quantidadeTipoVolume &&
          other.pontoFulgor == this.pontoFulgor);
}

class CtePerigososCompanion extends UpdateCompanion<CtePerigoso> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> numeroOnu;
  final Value<String?> nomeApropriado;
  final Value<String?> classeRisco;
  final Value<String?> grupoEmbalagem;
  final Value<String?> quantidadeTotalProduto;
  final Value<String?> quantidadeTipoVolume;
  final Value<String?> pontoFulgor;
  const CtePerigososCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroOnu = const Value.absent(),
    this.nomeApropriado = const Value.absent(),
    this.classeRisco = const Value.absent(),
    this.grupoEmbalagem = const Value.absent(),
    this.quantidadeTotalProduto = const Value.absent(),
    this.quantidadeTipoVolume = const Value.absent(),
    this.pontoFulgor = const Value.absent(),
  });
  CtePerigososCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroOnu = const Value.absent(),
    this.nomeApropriado = const Value.absent(),
    this.classeRisco = const Value.absent(),
    this.grupoEmbalagem = const Value.absent(),
    this.quantidadeTotalProduto = const Value.absent(),
    this.quantidadeTipoVolume = const Value.absent(),
    this.pontoFulgor = const Value.absent(),
  });
  static Insertable<CtePerigoso> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? numeroOnu,
    Expression<String>? nomeApropriado,
    Expression<String>? classeRisco,
    Expression<String>? grupoEmbalagem,
    Expression<String>? quantidadeTotalProduto,
    Expression<String>? quantidadeTipoVolume,
    Expression<String>? pontoFulgor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (numeroOnu != null) 'numero_onu': numeroOnu,
      if (nomeApropriado != null) 'nome_apropriado': nomeApropriado,
      if (classeRisco != null) 'classe_risco': classeRisco,
      if (grupoEmbalagem != null) 'grupo_embalagem': grupoEmbalagem,
      if (quantidadeTotalProduto != null)
        'quantidade_total_produto': quantidadeTotalProduto,
      if (quantidadeTipoVolume != null)
        'quantidade_tipo_volume': quantidadeTipoVolume,
      if (pontoFulgor != null) 'ponto_fulgor': pontoFulgor,
    });
  }

  CtePerigososCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? numeroOnu,
      Value<String?>? nomeApropriado,
      Value<String?>? classeRisco,
      Value<String?>? grupoEmbalagem,
      Value<String?>? quantidadeTotalProduto,
      Value<String?>? quantidadeTipoVolume,
      Value<String?>? pontoFulgor}) {
    return CtePerigososCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      numeroOnu: numeroOnu ?? this.numeroOnu,
      nomeApropriado: nomeApropriado ?? this.nomeApropriado,
      classeRisco: classeRisco ?? this.classeRisco,
      grupoEmbalagem: grupoEmbalagem ?? this.grupoEmbalagem,
      quantidadeTotalProduto:
          quantidadeTotalProduto ?? this.quantidadeTotalProduto,
      quantidadeTipoVolume: quantidadeTipoVolume ?? this.quantidadeTipoVolume,
      pontoFulgor: pontoFulgor ?? this.pontoFulgor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (numeroOnu.present) {
      map['numero_onu'] = Variable<String>(numeroOnu.value);
    }
    if (nomeApropriado.present) {
      map['nome_apropriado'] = Variable<String>(nomeApropriado.value);
    }
    if (classeRisco.present) {
      map['classe_risco'] = Variable<String>(classeRisco.value);
    }
    if (grupoEmbalagem.present) {
      map['grupo_embalagem'] = Variable<String>(grupoEmbalagem.value);
    }
    if (quantidadeTotalProduto.present) {
      map['quantidade_total_produto'] =
          Variable<String>(quantidadeTotalProduto.value);
    }
    if (quantidadeTipoVolume.present) {
      map['quantidade_tipo_volume'] =
          Variable<String>(quantidadeTipoVolume.value);
    }
    if (pontoFulgor.present) {
      map['ponto_fulgor'] = Variable<String>(pontoFulgor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CtePerigososCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroOnu: $numeroOnu, ')
          ..write('nomeApropriado: $nomeApropriado, ')
          ..write('classeRisco: $classeRisco, ')
          ..write('grupoEmbalagem: $grupoEmbalagem, ')
          ..write('quantidadeTotalProduto: $quantidadeTotalProduto, ')
          ..write('quantidadeTipoVolume: $quantidadeTipoVolume, ')
          ..write('pontoFulgor: $pontoFulgor')
          ..write(')'))
        .toString();
  }
}

class $CteVeiculoNovosTable extends CteVeiculoNovos
    with TableInfo<$CteVeiculoNovosTable, CteVeiculoNovo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteVeiculoNovosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _chassiMeta = const VerificationMeta('chassi');
  @override
  late final GeneratedColumn<String> chassi = GeneratedColumn<String>(
      'chassi', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 17),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _corMeta = const VerificationMeta('cor');
  @override
  late final GeneratedColumn<String> cor = GeneratedColumn<String>(
      'cor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoCorMeta =
      const VerificationMeta('descricaoCor');
  @override
  late final GeneratedColumn<String> descricaoCor = GeneratedColumn<String>(
      'descricao_cor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 40),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMarcaModeloMeta =
      const VerificationMeta('codigoMarcaModelo');
  @override
  late final GeneratedColumn<String> codigoMarcaModelo =
      GeneratedColumn<String>('codigo_marca_modelo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 6),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        chassi,
        cor,
        descricaoCor,
        codigoMarcaModelo,
        valorUnitario,
        valorFrete
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_veiculo_novo';
  @override
  VerificationContext validateIntegrity(Insertable<CteVeiculoNovo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('chassi')) {
      context.handle(_chassiMeta,
          chassi.isAcceptableOrUnknown(data['chassi']!, _chassiMeta));
    }
    if (data.containsKey('cor')) {
      context.handle(
          _corMeta, cor.isAcceptableOrUnknown(data['cor']!, _corMeta));
    }
    if (data.containsKey('descricao_cor')) {
      context.handle(
          _descricaoCorMeta,
          descricaoCor.isAcceptableOrUnknown(
              data['descricao_cor']!, _descricaoCorMeta));
    }
    if (data.containsKey('codigo_marca_modelo')) {
      context.handle(
          _codigoMarcaModeloMeta,
          codigoMarcaModelo.isAcceptableOrUnknown(
              data['codigo_marca_modelo']!, _codigoMarcaModeloMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteVeiculoNovo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteVeiculoNovo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      chassi: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chassi']),
      cor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cor']),
      descricaoCor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao_cor']),
      codigoMarcaModelo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_marca_modelo']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
    );
  }

  @override
  $CteVeiculoNovosTable createAlias(String alias) {
    return $CteVeiculoNovosTable(attachedDatabase, alias);
  }
}

class CteVeiculoNovo extends DataClass implements Insertable<CteVeiculoNovo> {
  final int? id;
  final int? idCteCabecalho;
  final String? chassi;
  final String? cor;
  final String? descricaoCor;
  final String? codigoMarcaModelo;
  final double? valorUnitario;
  final double? valorFrete;
  const CteVeiculoNovo(
      {this.id,
      this.idCteCabecalho,
      this.chassi,
      this.cor,
      this.descricaoCor,
      this.codigoMarcaModelo,
      this.valorUnitario,
      this.valorFrete});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || chassi != null) {
      map['chassi'] = Variable<String>(chassi);
    }
    if (!nullToAbsent || cor != null) {
      map['cor'] = Variable<String>(cor);
    }
    if (!nullToAbsent || descricaoCor != null) {
      map['descricao_cor'] = Variable<String>(descricaoCor);
    }
    if (!nullToAbsent || codigoMarcaModelo != null) {
      map['codigo_marca_modelo'] = Variable<String>(codigoMarcaModelo);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    return map;
  }

  factory CteVeiculoNovo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteVeiculoNovo(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      chassi: serializer.fromJson<String?>(json['chassi']),
      cor: serializer.fromJson<String?>(json['cor']),
      descricaoCor: serializer.fromJson<String?>(json['descricaoCor']),
      codigoMarcaModelo:
          serializer.fromJson<String?>(json['codigoMarcaModelo']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'chassi': serializer.toJson<String?>(chassi),
      'cor': serializer.toJson<String?>(cor),
      'descricaoCor': serializer.toJson<String?>(descricaoCor),
      'codigoMarcaModelo': serializer.toJson<String?>(codigoMarcaModelo),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'valorFrete': serializer.toJson<double?>(valorFrete),
    };
  }

  CteVeiculoNovo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> chassi = const Value.absent(),
          Value<String?> cor = const Value.absent(),
          Value<String?> descricaoCor = const Value.absent(),
          Value<String?> codigoMarcaModelo = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> valorFrete = const Value.absent()}) =>
      CteVeiculoNovo(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        chassi: chassi.present ? chassi.value : this.chassi,
        cor: cor.present ? cor.value : this.cor,
        descricaoCor:
            descricaoCor.present ? descricaoCor.value : this.descricaoCor,
        codigoMarcaModelo: codigoMarcaModelo.present
            ? codigoMarcaModelo.value
            : this.codigoMarcaModelo,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
      );
  @override
  String toString() {
    return (StringBuffer('CteVeiculoNovo(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('chassi: $chassi, ')
          ..write('cor: $cor, ')
          ..write('descricaoCor: $descricaoCor, ')
          ..write('codigoMarcaModelo: $codigoMarcaModelo, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorFrete: $valorFrete')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteCabecalho, chassi, cor, descricaoCor,
      codigoMarcaModelo, valorUnitario, valorFrete);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteVeiculoNovo &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.chassi == this.chassi &&
          other.cor == this.cor &&
          other.descricaoCor == this.descricaoCor &&
          other.codigoMarcaModelo == this.codigoMarcaModelo &&
          other.valorUnitario == this.valorUnitario &&
          other.valorFrete == this.valorFrete);
}

class CteVeiculoNovosCompanion extends UpdateCompanion<CteVeiculoNovo> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> chassi;
  final Value<String?> cor;
  final Value<String?> descricaoCor;
  final Value<String?> codigoMarcaModelo;
  final Value<double?> valorUnitario;
  final Value<double?> valorFrete;
  const CteVeiculoNovosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.chassi = const Value.absent(),
    this.cor = const Value.absent(),
    this.descricaoCor = const Value.absent(),
    this.codigoMarcaModelo = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorFrete = const Value.absent(),
  });
  CteVeiculoNovosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.chassi = const Value.absent(),
    this.cor = const Value.absent(),
    this.descricaoCor = const Value.absent(),
    this.codigoMarcaModelo = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorFrete = const Value.absent(),
  });
  static Insertable<CteVeiculoNovo> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? chassi,
    Expression<String>? cor,
    Expression<String>? descricaoCor,
    Expression<String>? codigoMarcaModelo,
    Expression<double>? valorUnitario,
    Expression<double>? valorFrete,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (chassi != null) 'chassi': chassi,
      if (cor != null) 'cor': cor,
      if (descricaoCor != null) 'descricao_cor': descricaoCor,
      if (codigoMarcaModelo != null) 'codigo_marca_modelo': codigoMarcaModelo,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (valorFrete != null) 'valor_frete': valorFrete,
    });
  }

  CteVeiculoNovosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? chassi,
      Value<String?>? cor,
      Value<String?>? descricaoCor,
      Value<String?>? codigoMarcaModelo,
      Value<double?>? valorUnitario,
      Value<double?>? valorFrete}) {
    return CteVeiculoNovosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      chassi: chassi ?? this.chassi,
      cor: cor ?? this.cor,
      descricaoCor: descricaoCor ?? this.descricaoCor,
      codigoMarcaModelo: codigoMarcaModelo ?? this.codigoMarcaModelo,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      valorFrete: valorFrete ?? this.valorFrete,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (chassi.present) {
      map['chassi'] = Variable<String>(chassi.value);
    }
    if (cor.present) {
      map['cor'] = Variable<String>(cor.value);
    }
    if (descricaoCor.present) {
      map['descricao_cor'] = Variable<String>(descricaoCor.value);
    }
    if (codigoMarcaModelo.present) {
      map['codigo_marca_modelo'] = Variable<String>(codigoMarcaModelo.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteVeiculoNovosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('chassi: $chassi, ')
          ..write('cor: $cor, ')
          ..write('descricaoCor: $descricaoCor, ')
          ..write('codigoMarcaModelo: $codigoMarcaModelo, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorFrete: $valorFrete')
          ..write(')'))
        .toString();
  }
}

class $CteFaturasTable extends CteFaturas
    with TableInfo<$CteFaturasTable, CteFatura> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteFaturasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorOriginalMeta =
      const VerificationMeta('valorOriginal');
  @override
  late final GeneratedColumn<double> valorOriginal = GeneratedColumn<double>(
      'valor_original', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorLiquidoMeta =
      const VerificationMeta('valorLiquido');
  @override
  late final GeneratedColumn<double> valorLiquido = GeneratedColumn<double>(
      'valor_liquido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, numero, valorOriginal, valorDesconto, valorLiquido];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_fatura';
  @override
  VerificationContext validateIntegrity(Insertable<CteFatura> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('valor_original')) {
      context.handle(
          _valorOriginalMeta,
          valorOriginal.isAcceptableOrUnknown(
              data['valor_original']!, _valorOriginalMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_liquido')) {
      context.handle(
          _valorLiquidoMeta,
          valorLiquido.isAcceptableOrUnknown(
              data['valor_liquido']!, _valorLiquidoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteFatura map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteFatura(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      valorOriginal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_original']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorLiquido: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_liquido']),
    );
  }

  @override
  $CteFaturasTable createAlias(String alias) {
    return $CteFaturasTable(attachedDatabase, alias);
  }
}

class CteFatura extends DataClass implements Insertable<CteFatura> {
  final int? id;
  final int? idCteCabecalho;
  final String? numero;
  final double? valorOriginal;
  final double? valorDesconto;
  final double? valorLiquido;
  const CteFatura(
      {this.id,
      this.idCteCabecalho,
      this.numero,
      this.valorOriginal,
      this.valorDesconto,
      this.valorLiquido});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || valorOriginal != null) {
      map['valor_original'] = Variable<double>(valorOriginal);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorLiquido != null) {
      map['valor_liquido'] = Variable<double>(valorLiquido);
    }
    return map;
  }

  factory CteFatura.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteFatura(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      numero: serializer.fromJson<String?>(json['numero']),
      valorOriginal: serializer.fromJson<double?>(json['valorOriginal']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorLiquido: serializer.fromJson<double?>(json['valorLiquido']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'numero': serializer.toJson<String?>(numero),
      'valorOriginal': serializer.toJson<double?>(valorOriginal),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorLiquido': serializer.toJson<double?>(valorLiquido),
    };
  }

  CteFatura copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<double?> valorOriginal = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorLiquido = const Value.absent()}) =>
      CteFatura(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        numero: numero.present ? numero.value : this.numero,
        valorOriginal:
            valorOriginal.present ? valorOriginal.value : this.valorOriginal,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorLiquido:
            valorLiquido.present ? valorLiquido.value : this.valorLiquido,
      );
  @override
  String toString() {
    return (StringBuffer('CteFatura(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numero: $numero, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorLiquido: $valorLiquido')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCteCabecalho, numero, valorOriginal, valorDesconto, valorLiquido);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteFatura &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.numero == this.numero &&
          other.valorOriginal == this.valorOriginal &&
          other.valorDesconto == this.valorDesconto &&
          other.valorLiquido == this.valorLiquido);
}

class CteFaturasCompanion extends UpdateCompanion<CteFatura> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> numero;
  final Value<double?> valorOriginal;
  final Value<double?> valorDesconto;
  final Value<double?> valorLiquido;
  const CteFaturasCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numero = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorLiquido = const Value.absent(),
  });
  CteFaturasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numero = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorLiquido = const Value.absent(),
  });
  static Insertable<CteFatura> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? numero,
    Expression<double>? valorOriginal,
    Expression<double>? valorDesconto,
    Expression<double>? valorLiquido,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (numero != null) 'numero': numero,
      if (valorOriginal != null) 'valor_original': valorOriginal,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorLiquido != null) 'valor_liquido': valorLiquido,
    });
  }

  CteFaturasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? numero,
      Value<double?>? valorOriginal,
      Value<double?>? valorDesconto,
      Value<double?>? valorLiquido}) {
    return CteFaturasCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      numero: numero ?? this.numero,
      valorOriginal: valorOriginal ?? this.valorOriginal,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorLiquido: valorLiquido ?? this.valorLiquido,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (valorOriginal.present) {
      map['valor_original'] = Variable<double>(valorOriginal.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorLiquido.present) {
      map['valor_liquido'] = Variable<double>(valorLiquido.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteFaturasCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numero: $numero, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorLiquido: $valorLiquido')
          ..write(')'))
        .toString();
  }
}

class $CteDuplicatasTable extends CteDuplicatas
    with TableInfo<$CteDuplicatasTable, CteDuplicata> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteDuplicatasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, numero, dataVencimento, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_duplicata';
  @override
  VerificationContext validateIntegrity(Insertable<CteDuplicata> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteDuplicata map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteDuplicata(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $CteDuplicatasTable createAlias(String alias) {
    return $CteDuplicatasTable(attachedDatabase, alias);
  }
}

class CteDuplicata extends DataClass implements Insertable<CteDuplicata> {
  final int? id;
  final int? idCteCabecalho;
  final String? numero;
  final DateTime? dataVencimento;
  final double? valor;
  const CteDuplicata(
      {this.id,
      this.idCteCabecalho,
      this.numero,
      this.dataVencimento,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory CteDuplicata.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteDuplicata(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'numero': serializer.toJson<String?>(numero),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  CteDuplicata copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      CteDuplicata(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        numero: numero.present ? numero.value : this.numero,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        valor: valor.present ? valor.value : this.valor,
      );
  @override
  String toString() {
    return (StringBuffer('CteDuplicata(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numero: $numero, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteCabecalho, numero, dataVencimento, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteDuplicata &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.numero == this.numero &&
          other.dataVencimento == this.dataVencimento &&
          other.valor == this.valor);
}

class CteDuplicatasCompanion extends UpdateCompanion<CteDuplicata> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> numero;
  final Value<DateTime?> dataVencimento;
  final Value<double?> valor;
  const CteDuplicatasCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  CteDuplicatasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<CteDuplicata> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? numero,
    Expression<DateTime>? dataVencimento,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (numero != null) 'numero': numero,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (valor != null) 'valor': valor,
    });
  }

  CteDuplicatasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? numero,
      Value<DateTime?>? dataVencimento,
      Value<double?>? valor}) {
    return CteDuplicatasCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      numero: numero ?? this.numero,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteDuplicatasCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numero: $numero, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviariosTable extends CteRodoviarios
    with TableInfo<$CteRodoviariosTable, CteRodoviario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _rntrcMeta = const VerificationMeta('rntrc');
  @override
  late final GeneratedColumn<String> rntrc = GeneratedColumn<String>(
      'rntrc', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaEntregaMeta =
      const VerificationMeta('dataPrevistaEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevistaEntrega =
      GeneratedColumn<DateTime>('data_prevista_entrega', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _indicadorLotacaoMeta =
      const VerificationMeta('indicadorLotacao');
  @override
  late final GeneratedColumn<String> indicadorLotacao = GeneratedColumn<String>(
      'indicador_lotacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ciotMeta = const VerificationMeta('ciot');
  @override
  late final GeneratedColumn<int> ciot = GeneratedColumn<int>(
      'ciot', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, rntrc, dataPrevistaEntrega, indicadorLotacao, ciot];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario';
  @override
  VerificationContext validateIntegrity(Insertable<CteRodoviario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('rntrc')) {
      context.handle(
          _rntrcMeta, rntrc.isAcceptableOrUnknown(data['rntrc']!, _rntrcMeta));
    }
    if (data.containsKey('data_prevista_entrega')) {
      context.handle(
          _dataPrevistaEntregaMeta,
          dataPrevistaEntrega.isAcceptableOrUnknown(
              data['data_prevista_entrega']!, _dataPrevistaEntregaMeta));
    }
    if (data.containsKey('indicador_lotacao')) {
      context.handle(
          _indicadorLotacaoMeta,
          indicadorLotacao.isAcceptableOrUnknown(
              data['indicador_lotacao']!, _indicadorLotacaoMeta));
    }
    if (data.containsKey('ciot')) {
      context.handle(
          _ciotMeta, ciot.isAcceptableOrUnknown(data['ciot']!, _ciotMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      rntrc: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rntrc']),
      dataPrevistaEntrega: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prevista_entrega']),
      indicadorLotacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}indicador_lotacao']),
      ciot: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ciot']),
    );
  }

  @override
  $CteRodoviariosTable createAlias(String alias) {
    return $CteRodoviariosTable(attachedDatabase, alias);
  }
}

class CteRodoviario extends DataClass implements Insertable<CteRodoviario> {
  final int? id;
  final int? idCteCabecalho;
  final String? rntrc;
  final DateTime? dataPrevistaEntrega;
  final String? indicadorLotacao;
  final int? ciot;
  const CteRodoviario(
      {this.id,
      this.idCteCabecalho,
      this.rntrc,
      this.dataPrevistaEntrega,
      this.indicadorLotacao,
      this.ciot});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || rntrc != null) {
      map['rntrc'] = Variable<String>(rntrc);
    }
    if (!nullToAbsent || dataPrevistaEntrega != null) {
      map['data_prevista_entrega'] = Variable<DateTime>(dataPrevistaEntrega);
    }
    if (!nullToAbsent || indicadorLotacao != null) {
      map['indicador_lotacao'] = Variable<String>(indicadorLotacao);
    }
    if (!nullToAbsent || ciot != null) {
      map['ciot'] = Variable<int>(ciot);
    }
    return map;
  }

  factory CteRodoviario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviario(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      rntrc: serializer.fromJson<String?>(json['rntrc']),
      dataPrevistaEntrega:
          serializer.fromJson<DateTime?>(json['dataPrevistaEntrega']),
      indicadorLotacao: serializer.fromJson<String?>(json['indicadorLotacao']),
      ciot: serializer.fromJson<int?>(json['ciot']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'rntrc': serializer.toJson<String?>(rntrc),
      'dataPrevistaEntrega': serializer.toJson<DateTime?>(dataPrevistaEntrega),
      'indicadorLotacao': serializer.toJson<String?>(indicadorLotacao),
      'ciot': serializer.toJson<int?>(ciot),
    };
  }

  CteRodoviario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> rntrc = const Value.absent(),
          Value<DateTime?> dataPrevistaEntrega = const Value.absent(),
          Value<String?> indicadorLotacao = const Value.absent(),
          Value<int?> ciot = const Value.absent()}) =>
      CteRodoviario(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        rntrc: rntrc.present ? rntrc.value : this.rntrc,
        dataPrevistaEntrega: dataPrevistaEntrega.present
            ? dataPrevistaEntrega.value
            : this.dataPrevistaEntrega,
        indicadorLotacao: indicadorLotacao.present
            ? indicadorLotacao.value
            : this.indicadorLotacao,
        ciot: ciot.present ? ciot.value : this.ciot,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviario(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('rntrc: $rntrc, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('indicadorLotacao: $indicadorLotacao, ')
          ..write('ciot: $ciot')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCteCabecalho, rntrc, dataPrevistaEntrega, indicadorLotacao, ciot);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviario &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.rntrc == this.rntrc &&
          other.dataPrevistaEntrega == this.dataPrevistaEntrega &&
          other.indicadorLotacao == this.indicadorLotacao &&
          other.ciot == this.ciot);
}

class CteRodoviariosCompanion extends UpdateCompanion<CteRodoviario> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> rntrc;
  final Value<DateTime?> dataPrevistaEntrega;
  final Value<String?> indicadorLotacao;
  final Value<int?> ciot;
  const CteRodoviariosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.rntrc = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.indicadorLotacao = const Value.absent(),
    this.ciot = const Value.absent(),
  });
  CteRodoviariosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.rntrc = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.indicadorLotacao = const Value.absent(),
    this.ciot = const Value.absent(),
  });
  static Insertable<CteRodoviario> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? rntrc,
    Expression<DateTime>? dataPrevistaEntrega,
    Expression<String>? indicadorLotacao,
    Expression<int>? ciot,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (rntrc != null) 'rntrc': rntrc,
      if (dataPrevistaEntrega != null)
        'data_prevista_entrega': dataPrevistaEntrega,
      if (indicadorLotacao != null) 'indicador_lotacao': indicadorLotacao,
      if (ciot != null) 'ciot': ciot,
    });
  }

  CteRodoviariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? rntrc,
      Value<DateTime?>? dataPrevistaEntrega,
      Value<String?>? indicadorLotacao,
      Value<int?>? ciot}) {
    return CteRodoviariosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      rntrc: rntrc ?? this.rntrc,
      dataPrevistaEntrega: dataPrevistaEntrega ?? this.dataPrevistaEntrega,
      indicadorLotacao: indicadorLotacao ?? this.indicadorLotacao,
      ciot: ciot ?? this.ciot,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (rntrc.present) {
      map['rntrc'] = Variable<String>(rntrc.value);
    }
    if (dataPrevistaEntrega.present) {
      map['data_prevista_entrega'] =
          Variable<DateTime>(dataPrevistaEntrega.value);
    }
    if (indicadorLotacao.present) {
      map['indicador_lotacao'] = Variable<String>(indicadorLotacao.value);
    }
    if (ciot.present) {
      map['ciot'] = Variable<int>(ciot.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviariosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('rntrc: $rntrc, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('indicadorLotacao: $indicadorLotacao, ')
          ..write('ciot: $ciot')
          ..write(')'))
        .toString();
  }
}

class $CteAereosTable extends CteAereos
    with TableInfo<$CteAereosTable, CteAereo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteAereosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMinutaMeta =
      const VerificationMeta('numeroMinuta');
  @override
  late final GeneratedColumn<int> numeroMinuta = GeneratedColumn<int>(
      'numero_minuta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroConhecimentoMeta =
      const VerificationMeta('numeroConhecimento');
  @override
  late final GeneratedColumn<int> numeroConhecimento = GeneratedColumn<int>(
      'numero_conhecimento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaEntregaMeta =
      const VerificationMeta('dataPrevistaEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevistaEntrega =
      GeneratedColumn<DateTime>('data_prevista_entrega', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _idEmissorMeta =
      const VerificationMeta('idEmissor');
  @override
  late final GeneratedColumn<String> idEmissor = GeneratedColumn<String>(
      'id_emissor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idInternaTomadorMeta =
      const VerificationMeta('idInternaTomador');
  @override
  late final GeneratedColumn<String> idInternaTomador = GeneratedColumn<String>(
      'id_interna_tomador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tarifaClasseMeta =
      const VerificationMeta('tarifaClasse');
  @override
  late final GeneratedColumn<String> tarifaClasse = GeneratedColumn<String>(
      'tarifa_classe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tarifaCodigoMeta =
      const VerificationMeta('tarifaCodigo');
  @override
  late final GeneratedColumn<String> tarifaCodigo = GeneratedColumn<String>(
      'tarifa_codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tarifaValorMeta =
      const VerificationMeta('tarifaValor');
  @override
  late final GeneratedColumn<double> tarifaValor = GeneratedColumn<double>(
      'tarifa_valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cargaDimensaoMeta =
      const VerificationMeta('cargaDimensao');
  @override
  late final GeneratedColumn<String> cargaDimensao = GeneratedColumn<String>(
      'carga_dimensao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cargaInformacaoManuseioMeta =
      const VerificationMeta('cargaInformacaoManuseio');
  @override
  late final GeneratedColumn<String> cargaInformacaoManuseio =
      GeneratedColumn<String>('carga_informacao_manuseio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cargaEspecialMeta =
      const VerificationMeta('cargaEspecial');
  @override
  late final GeneratedColumn<String> cargaEspecial = GeneratedColumn<String>(
      'carga_especial', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        numeroMinuta,
        numeroConhecimento,
        dataPrevistaEntrega,
        idEmissor,
        idInternaTomador,
        tarifaClasse,
        tarifaCodigo,
        tarifaValor,
        cargaDimensao,
        cargaInformacaoManuseio,
        cargaEspecial
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_aereo';
  @override
  VerificationContext validateIntegrity(Insertable<CteAereo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('numero_minuta')) {
      context.handle(
          _numeroMinutaMeta,
          numeroMinuta.isAcceptableOrUnknown(
              data['numero_minuta']!, _numeroMinutaMeta));
    }
    if (data.containsKey('numero_conhecimento')) {
      context.handle(
          _numeroConhecimentoMeta,
          numeroConhecimento.isAcceptableOrUnknown(
              data['numero_conhecimento']!, _numeroConhecimentoMeta));
    }
    if (data.containsKey('data_prevista_entrega')) {
      context.handle(
          _dataPrevistaEntregaMeta,
          dataPrevistaEntrega.isAcceptableOrUnknown(
              data['data_prevista_entrega']!, _dataPrevistaEntregaMeta));
    }
    if (data.containsKey('id_emissor')) {
      context.handle(_idEmissorMeta,
          idEmissor.isAcceptableOrUnknown(data['id_emissor']!, _idEmissorMeta));
    }
    if (data.containsKey('id_interna_tomador')) {
      context.handle(
          _idInternaTomadorMeta,
          idInternaTomador.isAcceptableOrUnknown(
              data['id_interna_tomador']!, _idInternaTomadorMeta));
    }
    if (data.containsKey('tarifa_classe')) {
      context.handle(
          _tarifaClasseMeta,
          tarifaClasse.isAcceptableOrUnknown(
              data['tarifa_classe']!, _tarifaClasseMeta));
    }
    if (data.containsKey('tarifa_codigo')) {
      context.handle(
          _tarifaCodigoMeta,
          tarifaCodigo.isAcceptableOrUnknown(
              data['tarifa_codigo']!, _tarifaCodigoMeta));
    }
    if (data.containsKey('tarifa_valor')) {
      context.handle(
          _tarifaValorMeta,
          tarifaValor.isAcceptableOrUnknown(
              data['tarifa_valor']!, _tarifaValorMeta));
    }
    if (data.containsKey('carga_dimensao')) {
      context.handle(
          _cargaDimensaoMeta,
          cargaDimensao.isAcceptableOrUnknown(
              data['carga_dimensao']!, _cargaDimensaoMeta));
    }
    if (data.containsKey('carga_informacao_manuseio')) {
      context.handle(
          _cargaInformacaoManuseioMeta,
          cargaInformacaoManuseio.isAcceptableOrUnknown(
              data['carga_informacao_manuseio']!,
              _cargaInformacaoManuseioMeta));
    }
    if (data.containsKey('carga_especial')) {
      context.handle(
          _cargaEspecialMeta,
          cargaEspecial.isAcceptableOrUnknown(
              data['carga_especial']!, _cargaEspecialMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteAereo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteAereo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      numeroMinuta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_minuta']),
      numeroConhecimento: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}numero_conhecimento']),
      dataPrevistaEntrega: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prevista_entrega']),
      idEmissor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id_emissor']),
      idInternaTomador: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}id_interna_tomador']),
      tarifaClasse: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tarifa_classe']),
      tarifaCodigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tarifa_codigo']),
      tarifaValor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}tarifa_valor']),
      cargaDimensao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}carga_dimensao']),
      cargaInformacaoManuseio: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}carga_informacao_manuseio']),
      cargaEspecial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}carga_especial']),
    );
  }

  @override
  $CteAereosTable createAlias(String alias) {
    return $CteAereosTable(attachedDatabase, alias);
  }
}

class CteAereo extends DataClass implements Insertable<CteAereo> {
  final int? id;
  final int? idCteCabecalho;
  final int? numeroMinuta;
  final int? numeroConhecimento;
  final DateTime? dataPrevistaEntrega;
  final String? idEmissor;
  final String? idInternaTomador;
  final String? tarifaClasse;
  final String? tarifaCodigo;
  final double? tarifaValor;
  final String? cargaDimensao;
  final String? cargaInformacaoManuseio;
  final String? cargaEspecial;
  const CteAereo(
      {this.id,
      this.idCteCabecalho,
      this.numeroMinuta,
      this.numeroConhecimento,
      this.dataPrevistaEntrega,
      this.idEmissor,
      this.idInternaTomador,
      this.tarifaClasse,
      this.tarifaCodigo,
      this.tarifaValor,
      this.cargaDimensao,
      this.cargaInformacaoManuseio,
      this.cargaEspecial});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || numeroMinuta != null) {
      map['numero_minuta'] = Variable<int>(numeroMinuta);
    }
    if (!nullToAbsent || numeroConhecimento != null) {
      map['numero_conhecimento'] = Variable<int>(numeroConhecimento);
    }
    if (!nullToAbsent || dataPrevistaEntrega != null) {
      map['data_prevista_entrega'] = Variable<DateTime>(dataPrevistaEntrega);
    }
    if (!nullToAbsent || idEmissor != null) {
      map['id_emissor'] = Variable<String>(idEmissor);
    }
    if (!nullToAbsent || idInternaTomador != null) {
      map['id_interna_tomador'] = Variable<String>(idInternaTomador);
    }
    if (!nullToAbsent || tarifaClasse != null) {
      map['tarifa_classe'] = Variable<String>(tarifaClasse);
    }
    if (!nullToAbsent || tarifaCodigo != null) {
      map['tarifa_codigo'] = Variable<String>(tarifaCodigo);
    }
    if (!nullToAbsent || tarifaValor != null) {
      map['tarifa_valor'] = Variable<double>(tarifaValor);
    }
    if (!nullToAbsent || cargaDimensao != null) {
      map['carga_dimensao'] = Variable<String>(cargaDimensao);
    }
    if (!nullToAbsent || cargaInformacaoManuseio != null) {
      map['carga_informacao_manuseio'] =
          Variable<String>(cargaInformacaoManuseio);
    }
    if (!nullToAbsent || cargaEspecial != null) {
      map['carga_especial'] = Variable<String>(cargaEspecial);
    }
    return map;
  }

  factory CteAereo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteAereo(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      numeroMinuta: serializer.fromJson<int?>(json['numeroMinuta']),
      numeroConhecimento: serializer.fromJson<int?>(json['numeroConhecimento']),
      dataPrevistaEntrega:
          serializer.fromJson<DateTime?>(json['dataPrevistaEntrega']),
      idEmissor: serializer.fromJson<String?>(json['idEmissor']),
      idInternaTomador: serializer.fromJson<String?>(json['idInternaTomador']),
      tarifaClasse: serializer.fromJson<String?>(json['tarifaClasse']),
      tarifaCodigo: serializer.fromJson<String?>(json['tarifaCodigo']),
      tarifaValor: serializer.fromJson<double?>(json['tarifaValor']),
      cargaDimensao: serializer.fromJson<String?>(json['cargaDimensao']),
      cargaInformacaoManuseio:
          serializer.fromJson<String?>(json['cargaInformacaoManuseio']),
      cargaEspecial: serializer.fromJson<String?>(json['cargaEspecial']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'numeroMinuta': serializer.toJson<int?>(numeroMinuta),
      'numeroConhecimento': serializer.toJson<int?>(numeroConhecimento),
      'dataPrevistaEntrega': serializer.toJson<DateTime?>(dataPrevistaEntrega),
      'idEmissor': serializer.toJson<String?>(idEmissor),
      'idInternaTomador': serializer.toJson<String?>(idInternaTomador),
      'tarifaClasse': serializer.toJson<String?>(tarifaClasse),
      'tarifaCodigo': serializer.toJson<String?>(tarifaCodigo),
      'tarifaValor': serializer.toJson<double?>(tarifaValor),
      'cargaDimensao': serializer.toJson<String?>(cargaDimensao),
      'cargaInformacaoManuseio':
          serializer.toJson<String?>(cargaInformacaoManuseio),
      'cargaEspecial': serializer.toJson<String?>(cargaEspecial),
    };
  }

  CteAereo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<int?> numeroMinuta = const Value.absent(),
          Value<int?> numeroConhecimento = const Value.absent(),
          Value<DateTime?> dataPrevistaEntrega = const Value.absent(),
          Value<String?> idEmissor = const Value.absent(),
          Value<String?> idInternaTomador = const Value.absent(),
          Value<String?> tarifaClasse = const Value.absent(),
          Value<String?> tarifaCodigo = const Value.absent(),
          Value<double?> tarifaValor = const Value.absent(),
          Value<String?> cargaDimensao = const Value.absent(),
          Value<String?> cargaInformacaoManuseio = const Value.absent(),
          Value<String?> cargaEspecial = const Value.absent()}) =>
      CteAereo(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        numeroMinuta:
            numeroMinuta.present ? numeroMinuta.value : this.numeroMinuta,
        numeroConhecimento: numeroConhecimento.present
            ? numeroConhecimento.value
            : this.numeroConhecimento,
        dataPrevistaEntrega: dataPrevistaEntrega.present
            ? dataPrevistaEntrega.value
            : this.dataPrevistaEntrega,
        idEmissor: idEmissor.present ? idEmissor.value : this.idEmissor,
        idInternaTomador: idInternaTomador.present
            ? idInternaTomador.value
            : this.idInternaTomador,
        tarifaClasse:
            tarifaClasse.present ? tarifaClasse.value : this.tarifaClasse,
        tarifaCodigo:
            tarifaCodigo.present ? tarifaCodigo.value : this.tarifaCodigo,
        tarifaValor: tarifaValor.present ? tarifaValor.value : this.tarifaValor,
        cargaDimensao:
            cargaDimensao.present ? cargaDimensao.value : this.cargaDimensao,
        cargaInformacaoManuseio: cargaInformacaoManuseio.present
            ? cargaInformacaoManuseio.value
            : this.cargaInformacaoManuseio,
        cargaEspecial:
            cargaEspecial.present ? cargaEspecial.value : this.cargaEspecial,
      );
  @override
  String toString() {
    return (StringBuffer('CteAereo(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroMinuta: $numeroMinuta, ')
          ..write('numeroConhecimento: $numeroConhecimento, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('idEmissor: $idEmissor, ')
          ..write('idInternaTomador: $idInternaTomador, ')
          ..write('tarifaClasse: $tarifaClasse, ')
          ..write('tarifaCodigo: $tarifaCodigo, ')
          ..write('tarifaValor: $tarifaValor, ')
          ..write('cargaDimensao: $cargaDimensao, ')
          ..write('cargaInformacaoManuseio: $cargaInformacaoManuseio, ')
          ..write('cargaEspecial: $cargaEspecial')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteCabecalho,
      numeroMinuta,
      numeroConhecimento,
      dataPrevistaEntrega,
      idEmissor,
      idInternaTomador,
      tarifaClasse,
      tarifaCodigo,
      tarifaValor,
      cargaDimensao,
      cargaInformacaoManuseio,
      cargaEspecial);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteAereo &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.numeroMinuta == this.numeroMinuta &&
          other.numeroConhecimento == this.numeroConhecimento &&
          other.dataPrevistaEntrega == this.dataPrevistaEntrega &&
          other.idEmissor == this.idEmissor &&
          other.idInternaTomador == this.idInternaTomador &&
          other.tarifaClasse == this.tarifaClasse &&
          other.tarifaCodigo == this.tarifaCodigo &&
          other.tarifaValor == this.tarifaValor &&
          other.cargaDimensao == this.cargaDimensao &&
          other.cargaInformacaoManuseio == this.cargaInformacaoManuseio &&
          other.cargaEspecial == this.cargaEspecial);
}

class CteAereosCompanion extends UpdateCompanion<CteAereo> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<int?> numeroMinuta;
  final Value<int?> numeroConhecimento;
  final Value<DateTime?> dataPrevistaEntrega;
  final Value<String?> idEmissor;
  final Value<String?> idInternaTomador;
  final Value<String?> tarifaClasse;
  final Value<String?> tarifaCodigo;
  final Value<double?> tarifaValor;
  final Value<String?> cargaDimensao;
  final Value<String?> cargaInformacaoManuseio;
  final Value<String?> cargaEspecial;
  const CteAereosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroMinuta = const Value.absent(),
    this.numeroConhecimento = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.idEmissor = const Value.absent(),
    this.idInternaTomador = const Value.absent(),
    this.tarifaClasse = const Value.absent(),
    this.tarifaCodigo = const Value.absent(),
    this.tarifaValor = const Value.absent(),
    this.cargaDimensao = const Value.absent(),
    this.cargaInformacaoManuseio = const Value.absent(),
    this.cargaEspecial = const Value.absent(),
  });
  CteAereosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.numeroMinuta = const Value.absent(),
    this.numeroConhecimento = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.idEmissor = const Value.absent(),
    this.idInternaTomador = const Value.absent(),
    this.tarifaClasse = const Value.absent(),
    this.tarifaCodigo = const Value.absent(),
    this.tarifaValor = const Value.absent(),
    this.cargaDimensao = const Value.absent(),
    this.cargaInformacaoManuseio = const Value.absent(),
    this.cargaEspecial = const Value.absent(),
  });
  static Insertable<CteAereo> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<int>? numeroMinuta,
    Expression<int>? numeroConhecimento,
    Expression<DateTime>? dataPrevistaEntrega,
    Expression<String>? idEmissor,
    Expression<String>? idInternaTomador,
    Expression<String>? tarifaClasse,
    Expression<String>? tarifaCodigo,
    Expression<double>? tarifaValor,
    Expression<String>? cargaDimensao,
    Expression<String>? cargaInformacaoManuseio,
    Expression<String>? cargaEspecial,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (numeroMinuta != null) 'numero_minuta': numeroMinuta,
      if (numeroConhecimento != null) 'numero_conhecimento': numeroConhecimento,
      if (dataPrevistaEntrega != null)
        'data_prevista_entrega': dataPrevistaEntrega,
      if (idEmissor != null) 'id_emissor': idEmissor,
      if (idInternaTomador != null) 'id_interna_tomador': idInternaTomador,
      if (tarifaClasse != null) 'tarifa_classe': tarifaClasse,
      if (tarifaCodigo != null) 'tarifa_codigo': tarifaCodigo,
      if (tarifaValor != null) 'tarifa_valor': tarifaValor,
      if (cargaDimensao != null) 'carga_dimensao': cargaDimensao,
      if (cargaInformacaoManuseio != null)
        'carga_informacao_manuseio': cargaInformacaoManuseio,
      if (cargaEspecial != null) 'carga_especial': cargaEspecial,
    });
  }

  CteAereosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<int?>? numeroMinuta,
      Value<int?>? numeroConhecimento,
      Value<DateTime?>? dataPrevistaEntrega,
      Value<String?>? idEmissor,
      Value<String?>? idInternaTomador,
      Value<String?>? tarifaClasse,
      Value<String?>? tarifaCodigo,
      Value<double?>? tarifaValor,
      Value<String?>? cargaDimensao,
      Value<String?>? cargaInformacaoManuseio,
      Value<String?>? cargaEspecial}) {
    return CteAereosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      numeroMinuta: numeroMinuta ?? this.numeroMinuta,
      numeroConhecimento: numeroConhecimento ?? this.numeroConhecimento,
      dataPrevistaEntrega: dataPrevistaEntrega ?? this.dataPrevistaEntrega,
      idEmissor: idEmissor ?? this.idEmissor,
      idInternaTomador: idInternaTomador ?? this.idInternaTomador,
      tarifaClasse: tarifaClasse ?? this.tarifaClasse,
      tarifaCodigo: tarifaCodigo ?? this.tarifaCodigo,
      tarifaValor: tarifaValor ?? this.tarifaValor,
      cargaDimensao: cargaDimensao ?? this.cargaDimensao,
      cargaInformacaoManuseio:
          cargaInformacaoManuseio ?? this.cargaInformacaoManuseio,
      cargaEspecial: cargaEspecial ?? this.cargaEspecial,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (numeroMinuta.present) {
      map['numero_minuta'] = Variable<int>(numeroMinuta.value);
    }
    if (numeroConhecimento.present) {
      map['numero_conhecimento'] = Variable<int>(numeroConhecimento.value);
    }
    if (dataPrevistaEntrega.present) {
      map['data_prevista_entrega'] =
          Variable<DateTime>(dataPrevistaEntrega.value);
    }
    if (idEmissor.present) {
      map['id_emissor'] = Variable<String>(idEmissor.value);
    }
    if (idInternaTomador.present) {
      map['id_interna_tomador'] = Variable<String>(idInternaTomador.value);
    }
    if (tarifaClasse.present) {
      map['tarifa_classe'] = Variable<String>(tarifaClasse.value);
    }
    if (tarifaCodigo.present) {
      map['tarifa_codigo'] = Variable<String>(tarifaCodigo.value);
    }
    if (tarifaValor.present) {
      map['tarifa_valor'] = Variable<double>(tarifaValor.value);
    }
    if (cargaDimensao.present) {
      map['carga_dimensao'] = Variable<String>(cargaDimensao.value);
    }
    if (cargaInformacaoManuseio.present) {
      map['carga_informacao_manuseio'] =
          Variable<String>(cargaInformacaoManuseio.value);
    }
    if (cargaEspecial.present) {
      map['carga_especial'] = Variable<String>(cargaEspecial.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteAereosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('numeroMinuta: $numeroMinuta, ')
          ..write('numeroConhecimento: $numeroConhecimento, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('idEmissor: $idEmissor, ')
          ..write('idInternaTomador: $idInternaTomador, ')
          ..write('tarifaClasse: $tarifaClasse, ')
          ..write('tarifaCodigo: $tarifaCodigo, ')
          ..write('tarifaValor: $tarifaValor, ')
          ..write('cargaDimensao: $cargaDimensao, ')
          ..write('cargaInformacaoManuseio: $cargaInformacaoManuseio, ')
          ..write('cargaEspecial: $cargaEspecial')
          ..write(')'))
        .toString();
  }
}

class $CteAquaviariosTable extends CteAquaviarios
    with TableInfo<$CteAquaviariosTable, CteAquaviario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteAquaviariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorPrestacaoMeta =
      const VerificationMeta('valorPrestacao');
  @override
  late final GeneratedColumn<double> valorPrestacao = GeneratedColumn<double>(
      'valor_prestacao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _afrmmMeta = const VerificationMeta('afrmm');
  @override
  late final GeneratedColumn<double> afrmm = GeneratedColumn<double>(
      'afrmm', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _numeroBookingMeta =
      const VerificationMeta('numeroBooking');
  @override
  late final GeneratedColumn<String> numeroBooking = GeneratedColumn<String>(
      'numero_booking', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroControleMeta =
      const VerificationMeta('numeroControle');
  @override
  late final GeneratedColumn<String> numeroControle = GeneratedColumn<String>(
      'numero_controle', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idNavioMeta =
      const VerificationMeta('idNavio');
  @override
  late final GeneratedColumn<String> idNavio = GeneratedColumn<String>(
      'id_navio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        valorPrestacao,
        afrmm,
        numeroBooking,
        numeroControle,
        idNavio
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_aquaviario';
  @override
  VerificationContext validateIntegrity(Insertable<CteAquaviario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('valor_prestacao')) {
      context.handle(
          _valorPrestacaoMeta,
          valorPrestacao.isAcceptableOrUnknown(
              data['valor_prestacao']!, _valorPrestacaoMeta));
    }
    if (data.containsKey('afrmm')) {
      context.handle(
          _afrmmMeta, afrmm.isAcceptableOrUnknown(data['afrmm']!, _afrmmMeta));
    }
    if (data.containsKey('numero_booking')) {
      context.handle(
          _numeroBookingMeta,
          numeroBooking.isAcceptableOrUnknown(
              data['numero_booking']!, _numeroBookingMeta));
    }
    if (data.containsKey('numero_controle')) {
      context.handle(
          _numeroControleMeta,
          numeroControle.isAcceptableOrUnknown(
              data['numero_controle']!, _numeroControleMeta));
    }
    if (data.containsKey('id_navio')) {
      context.handle(_idNavioMeta,
          idNavio.isAcceptableOrUnknown(data['id_navio']!, _idNavioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteAquaviario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteAquaviario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      valorPrestacao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_prestacao']),
      afrmm: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}afrmm']),
      numeroBooking: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_booking']),
      numeroControle: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_controle']),
      idNavio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id_navio']),
    );
  }

  @override
  $CteAquaviariosTable createAlias(String alias) {
    return $CteAquaviariosTable(attachedDatabase, alias);
  }
}

class CteAquaviario extends DataClass implements Insertable<CteAquaviario> {
  final int? id;
  final int? idCteCabecalho;
  final double? valorPrestacao;
  final double? afrmm;
  final String? numeroBooking;
  final String? numeroControle;
  final String? idNavio;
  const CteAquaviario(
      {this.id,
      this.idCteCabecalho,
      this.valorPrestacao,
      this.afrmm,
      this.numeroBooking,
      this.numeroControle,
      this.idNavio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || valorPrestacao != null) {
      map['valor_prestacao'] = Variable<double>(valorPrestacao);
    }
    if (!nullToAbsent || afrmm != null) {
      map['afrmm'] = Variable<double>(afrmm);
    }
    if (!nullToAbsent || numeroBooking != null) {
      map['numero_booking'] = Variable<String>(numeroBooking);
    }
    if (!nullToAbsent || numeroControle != null) {
      map['numero_controle'] = Variable<String>(numeroControle);
    }
    if (!nullToAbsent || idNavio != null) {
      map['id_navio'] = Variable<String>(idNavio);
    }
    return map;
  }

  factory CteAquaviario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteAquaviario(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      valorPrestacao: serializer.fromJson<double?>(json['valorPrestacao']),
      afrmm: serializer.fromJson<double?>(json['afrmm']),
      numeroBooking: serializer.fromJson<String?>(json['numeroBooking']),
      numeroControle: serializer.fromJson<String?>(json['numeroControle']),
      idNavio: serializer.fromJson<String?>(json['idNavio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'valorPrestacao': serializer.toJson<double?>(valorPrestacao),
      'afrmm': serializer.toJson<double?>(afrmm),
      'numeroBooking': serializer.toJson<String?>(numeroBooking),
      'numeroControle': serializer.toJson<String?>(numeroControle),
      'idNavio': serializer.toJson<String?>(idNavio),
    };
  }

  CteAquaviario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<double?> valorPrestacao = const Value.absent(),
          Value<double?> afrmm = const Value.absent(),
          Value<String?> numeroBooking = const Value.absent(),
          Value<String?> numeroControle = const Value.absent(),
          Value<String?> idNavio = const Value.absent()}) =>
      CteAquaviario(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        valorPrestacao:
            valorPrestacao.present ? valorPrestacao.value : this.valorPrestacao,
        afrmm: afrmm.present ? afrmm.value : this.afrmm,
        numeroBooking:
            numeroBooking.present ? numeroBooking.value : this.numeroBooking,
        numeroControle:
            numeroControle.present ? numeroControle.value : this.numeroControle,
        idNavio: idNavio.present ? idNavio.value : this.idNavio,
      );
  @override
  String toString() {
    return (StringBuffer('CteAquaviario(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('valorPrestacao: $valorPrestacao, ')
          ..write('afrmm: $afrmm, ')
          ..write('numeroBooking: $numeroBooking, ')
          ..write('numeroControle: $numeroControle, ')
          ..write('idNavio: $idNavio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteCabecalho, valorPrestacao, afrmm,
      numeroBooking, numeroControle, idNavio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteAquaviario &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.valorPrestacao == this.valorPrestacao &&
          other.afrmm == this.afrmm &&
          other.numeroBooking == this.numeroBooking &&
          other.numeroControle == this.numeroControle &&
          other.idNavio == this.idNavio);
}

class CteAquaviariosCompanion extends UpdateCompanion<CteAquaviario> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<double?> valorPrestacao;
  final Value<double?> afrmm;
  final Value<String?> numeroBooking;
  final Value<String?> numeroControle;
  final Value<String?> idNavio;
  const CteAquaviariosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.valorPrestacao = const Value.absent(),
    this.afrmm = const Value.absent(),
    this.numeroBooking = const Value.absent(),
    this.numeroControle = const Value.absent(),
    this.idNavio = const Value.absent(),
  });
  CteAquaviariosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.valorPrestacao = const Value.absent(),
    this.afrmm = const Value.absent(),
    this.numeroBooking = const Value.absent(),
    this.numeroControle = const Value.absent(),
    this.idNavio = const Value.absent(),
  });
  static Insertable<CteAquaviario> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<double>? valorPrestacao,
    Expression<double>? afrmm,
    Expression<String>? numeroBooking,
    Expression<String>? numeroControle,
    Expression<String>? idNavio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (valorPrestacao != null) 'valor_prestacao': valorPrestacao,
      if (afrmm != null) 'afrmm': afrmm,
      if (numeroBooking != null) 'numero_booking': numeroBooking,
      if (numeroControle != null) 'numero_controle': numeroControle,
      if (idNavio != null) 'id_navio': idNavio,
    });
  }

  CteAquaviariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<double?>? valorPrestacao,
      Value<double?>? afrmm,
      Value<String?>? numeroBooking,
      Value<String?>? numeroControle,
      Value<String?>? idNavio}) {
    return CteAquaviariosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      valorPrestacao: valorPrestacao ?? this.valorPrestacao,
      afrmm: afrmm ?? this.afrmm,
      numeroBooking: numeroBooking ?? this.numeroBooking,
      numeroControle: numeroControle ?? this.numeroControle,
      idNavio: idNavio ?? this.idNavio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (valorPrestacao.present) {
      map['valor_prestacao'] = Variable<double>(valorPrestacao.value);
    }
    if (afrmm.present) {
      map['afrmm'] = Variable<double>(afrmm.value);
    }
    if (numeroBooking.present) {
      map['numero_booking'] = Variable<String>(numeroBooking.value);
    }
    if (numeroControle.present) {
      map['numero_controle'] = Variable<String>(numeroControle.value);
    }
    if (idNavio.present) {
      map['id_navio'] = Variable<String>(idNavio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteAquaviariosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('valorPrestacao: $valorPrestacao, ')
          ..write('afrmm: $afrmm, ')
          ..write('numeroBooking: $numeroBooking, ')
          ..write('numeroControle: $numeroControle, ')
          ..write('idNavio: $idNavio')
          ..write(')'))
        .toString();
  }
}

class $CteFerroviariosTable extends CteFerroviarios
    with TableInfo<$CteFerroviariosTable, CteFerroviario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteFerroviariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoTrafegoMeta =
      const VerificationMeta('tipoTrafego');
  @override
  late final GeneratedColumn<String> tipoTrafego = GeneratedColumn<String>(
      'tipo_trafego', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _responsavelFaturamentoMeta =
      const VerificationMeta('responsavelFaturamento');
  @override
  late final GeneratedColumn<String> responsavelFaturamento =
      GeneratedColumn<String>('responsavel_faturamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ferroviaEmitenteCteMeta =
      const VerificationMeta('ferroviaEmitenteCte');
  @override
  late final GeneratedColumn<String> ferroviaEmitenteCte =
      GeneratedColumn<String>('ferrovia_emitente_cte', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _fluxoMeta = const VerificationMeta('fluxo');
  @override
  late final GeneratedColumn<String> fluxo = GeneratedColumn<String>(
      'fluxo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idTremMeta = const VerificationMeta('idTrem');
  @override
  late final GeneratedColumn<String> idTrem = GeneratedColumn<String>(
      'id_trem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteCabecalho,
        tipoTrafego,
        responsavelFaturamento,
        ferroviaEmitenteCte,
        fluxo,
        idTrem,
        valorFrete
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_ferroviario';
  @override
  VerificationContext validateIntegrity(Insertable<CteFerroviario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('tipo_trafego')) {
      context.handle(
          _tipoTrafegoMeta,
          tipoTrafego.isAcceptableOrUnknown(
              data['tipo_trafego']!, _tipoTrafegoMeta));
    }
    if (data.containsKey('responsavel_faturamento')) {
      context.handle(
          _responsavelFaturamentoMeta,
          responsavelFaturamento.isAcceptableOrUnknown(
              data['responsavel_faturamento']!, _responsavelFaturamentoMeta));
    }
    if (data.containsKey('ferrovia_emitente_cte')) {
      context.handle(
          _ferroviaEmitenteCteMeta,
          ferroviaEmitenteCte.isAcceptableOrUnknown(
              data['ferrovia_emitente_cte']!, _ferroviaEmitenteCteMeta));
    }
    if (data.containsKey('fluxo')) {
      context.handle(
          _fluxoMeta, fluxo.isAcceptableOrUnknown(data['fluxo']!, _fluxoMeta));
    }
    if (data.containsKey('id_trem')) {
      context.handle(_idTremMeta,
          idTrem.isAcceptableOrUnknown(data['id_trem']!, _idTremMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteFerroviario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteFerroviario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      tipoTrafego: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_trafego']),
      responsavelFaturamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}responsavel_faturamento']),
      ferroviaEmitenteCte: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}ferrovia_emitente_cte']),
      fluxo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fluxo']),
      idTrem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id_trem']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
    );
  }

  @override
  $CteFerroviariosTable createAlias(String alias) {
    return $CteFerroviariosTable(attachedDatabase, alias);
  }
}

class CteFerroviario extends DataClass implements Insertable<CteFerroviario> {
  final int? id;
  final int? idCteCabecalho;
  final String? tipoTrafego;
  final String? responsavelFaturamento;
  final String? ferroviaEmitenteCte;
  final String? fluxo;
  final String? idTrem;
  final double? valorFrete;
  const CteFerroviario(
      {this.id,
      this.idCteCabecalho,
      this.tipoTrafego,
      this.responsavelFaturamento,
      this.ferroviaEmitenteCte,
      this.fluxo,
      this.idTrem,
      this.valorFrete});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || tipoTrafego != null) {
      map['tipo_trafego'] = Variable<String>(tipoTrafego);
    }
    if (!nullToAbsent || responsavelFaturamento != null) {
      map['responsavel_faturamento'] = Variable<String>(responsavelFaturamento);
    }
    if (!nullToAbsent || ferroviaEmitenteCte != null) {
      map['ferrovia_emitente_cte'] = Variable<String>(ferroviaEmitenteCte);
    }
    if (!nullToAbsent || fluxo != null) {
      map['fluxo'] = Variable<String>(fluxo);
    }
    if (!nullToAbsent || idTrem != null) {
      map['id_trem'] = Variable<String>(idTrem);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    return map;
  }

  factory CteFerroviario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteFerroviario(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      tipoTrafego: serializer.fromJson<String?>(json['tipoTrafego']),
      responsavelFaturamento:
          serializer.fromJson<String?>(json['responsavelFaturamento']),
      ferroviaEmitenteCte:
          serializer.fromJson<String?>(json['ferroviaEmitenteCte']),
      fluxo: serializer.fromJson<String?>(json['fluxo']),
      idTrem: serializer.fromJson<String?>(json['idTrem']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'tipoTrafego': serializer.toJson<String?>(tipoTrafego),
      'responsavelFaturamento':
          serializer.toJson<String?>(responsavelFaturamento),
      'ferroviaEmitenteCte': serializer.toJson<String?>(ferroviaEmitenteCte),
      'fluxo': serializer.toJson<String?>(fluxo),
      'idTrem': serializer.toJson<String?>(idTrem),
      'valorFrete': serializer.toJson<double?>(valorFrete),
    };
  }

  CteFerroviario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> tipoTrafego = const Value.absent(),
          Value<String?> responsavelFaturamento = const Value.absent(),
          Value<String?> ferroviaEmitenteCte = const Value.absent(),
          Value<String?> fluxo = const Value.absent(),
          Value<String?> idTrem = const Value.absent(),
          Value<double?> valorFrete = const Value.absent()}) =>
      CteFerroviario(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        tipoTrafego: tipoTrafego.present ? tipoTrafego.value : this.tipoTrafego,
        responsavelFaturamento: responsavelFaturamento.present
            ? responsavelFaturamento.value
            : this.responsavelFaturamento,
        ferroviaEmitenteCte: ferroviaEmitenteCte.present
            ? ferroviaEmitenteCte.value
            : this.ferroviaEmitenteCte,
        fluxo: fluxo.present ? fluxo.value : this.fluxo,
        idTrem: idTrem.present ? idTrem.value : this.idTrem,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
      );
  @override
  String toString() {
    return (StringBuffer('CteFerroviario(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('tipoTrafego: $tipoTrafego, ')
          ..write('responsavelFaturamento: $responsavelFaturamento, ')
          ..write('ferroviaEmitenteCte: $ferroviaEmitenteCte, ')
          ..write('fluxo: $fluxo, ')
          ..write('idTrem: $idTrem, ')
          ..write('valorFrete: $valorFrete')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteCabecalho, tipoTrafego,
      responsavelFaturamento, ferroviaEmitenteCte, fluxo, idTrem, valorFrete);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteFerroviario &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.tipoTrafego == this.tipoTrafego &&
          other.responsavelFaturamento == this.responsavelFaturamento &&
          other.ferroviaEmitenteCte == this.ferroviaEmitenteCte &&
          other.fluxo == this.fluxo &&
          other.idTrem == this.idTrem &&
          other.valorFrete == this.valorFrete);
}

class CteFerroviariosCompanion extends UpdateCompanion<CteFerroviario> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> tipoTrafego;
  final Value<String?> responsavelFaturamento;
  final Value<String?> ferroviaEmitenteCte;
  final Value<String?> fluxo;
  final Value<String?> idTrem;
  final Value<double?> valorFrete;
  const CteFerroviariosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.tipoTrafego = const Value.absent(),
    this.responsavelFaturamento = const Value.absent(),
    this.ferroviaEmitenteCte = const Value.absent(),
    this.fluxo = const Value.absent(),
    this.idTrem = const Value.absent(),
    this.valorFrete = const Value.absent(),
  });
  CteFerroviariosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.tipoTrafego = const Value.absent(),
    this.responsavelFaturamento = const Value.absent(),
    this.ferroviaEmitenteCte = const Value.absent(),
    this.fluxo = const Value.absent(),
    this.idTrem = const Value.absent(),
    this.valorFrete = const Value.absent(),
  });
  static Insertable<CteFerroviario> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? tipoTrafego,
    Expression<String>? responsavelFaturamento,
    Expression<String>? ferroviaEmitenteCte,
    Expression<String>? fluxo,
    Expression<String>? idTrem,
    Expression<double>? valorFrete,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (tipoTrafego != null) 'tipo_trafego': tipoTrafego,
      if (responsavelFaturamento != null)
        'responsavel_faturamento': responsavelFaturamento,
      if (ferroviaEmitenteCte != null)
        'ferrovia_emitente_cte': ferroviaEmitenteCte,
      if (fluxo != null) 'fluxo': fluxo,
      if (idTrem != null) 'id_trem': idTrem,
      if (valorFrete != null) 'valor_frete': valorFrete,
    });
  }

  CteFerroviariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? tipoTrafego,
      Value<String?>? responsavelFaturamento,
      Value<String?>? ferroviaEmitenteCte,
      Value<String?>? fluxo,
      Value<String?>? idTrem,
      Value<double?>? valorFrete}) {
    return CteFerroviariosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      tipoTrafego: tipoTrafego ?? this.tipoTrafego,
      responsavelFaturamento:
          responsavelFaturamento ?? this.responsavelFaturamento,
      ferroviaEmitenteCte: ferroviaEmitenteCte ?? this.ferroviaEmitenteCte,
      fluxo: fluxo ?? this.fluxo,
      idTrem: idTrem ?? this.idTrem,
      valorFrete: valorFrete ?? this.valorFrete,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (tipoTrafego.present) {
      map['tipo_trafego'] = Variable<String>(tipoTrafego.value);
    }
    if (responsavelFaturamento.present) {
      map['responsavel_faturamento'] =
          Variable<String>(responsavelFaturamento.value);
    }
    if (ferroviaEmitenteCte.present) {
      map['ferrovia_emitente_cte'] =
          Variable<String>(ferroviaEmitenteCte.value);
    }
    if (fluxo.present) {
      map['fluxo'] = Variable<String>(fluxo.value);
    }
    if (idTrem.present) {
      map['id_trem'] = Variable<String>(idTrem.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteFerroviariosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('tipoTrafego: $tipoTrafego, ')
          ..write('responsavelFaturamento: $responsavelFaturamento, ')
          ..write('ferroviaEmitenteCte: $ferroviaEmitenteCte, ')
          ..write('fluxo: $fluxo, ')
          ..write('idTrem: $idTrem, ')
          ..write('valorFrete: $valorFrete')
          ..write(')'))
        .toString();
  }
}

class $CteDutoviariosTable extends CteDutoviarios
    with TableInfo<$CteDutoviariosTable, CteDutoviario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteDutoviariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorTarifaMeta =
      const VerificationMeta('valorTarifa');
  @override
  late final GeneratedColumn<double> valorTarifa = GeneratedColumn<double>(
      'valor_tarifa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, valorTarifa, dataInicio, dataFim];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_dutoviario';
  @override
  VerificationContext validateIntegrity(Insertable<CteDutoviario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('valor_tarifa')) {
      context.handle(
          _valorTarifaMeta,
          valorTarifa.isAcceptableOrUnknown(
              data['valor_tarifa']!, _valorTarifaMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteDutoviario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteDutoviario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      valorTarifa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_tarifa']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
    );
  }

  @override
  $CteDutoviariosTable createAlias(String alias) {
    return $CteDutoviariosTable(attachedDatabase, alias);
  }
}

class CteDutoviario extends DataClass implements Insertable<CteDutoviario> {
  final int? id;
  final int? idCteCabecalho;
  final double? valorTarifa;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  const CteDutoviario(
      {this.id,
      this.idCteCabecalho,
      this.valorTarifa,
      this.dataInicio,
      this.dataFim});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || valorTarifa != null) {
      map['valor_tarifa'] = Variable<double>(valorTarifa);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    return map;
  }

  factory CteDutoviario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteDutoviario(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      valorTarifa: serializer.fromJson<double?>(json['valorTarifa']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'valorTarifa': serializer.toJson<double?>(valorTarifa),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
    };
  }

  CteDutoviario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<double?> valorTarifa = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent()}) =>
      CteDutoviario(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        valorTarifa: valorTarifa.present ? valorTarifa.value : this.valorTarifa,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
      );
  @override
  String toString() {
    return (StringBuffer('CteDutoviario(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('valorTarifa: $valorTarifa, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteCabecalho, valorTarifa, dataInicio, dataFim);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteDutoviario &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.valorTarifa == this.valorTarifa &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim);
}

class CteDutoviariosCompanion extends UpdateCompanion<CteDutoviario> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<double?> valorTarifa;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  const CteDutoviariosCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.valorTarifa = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
  });
  CteDutoviariosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.valorTarifa = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
  });
  static Insertable<CteDutoviario> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<double>? valorTarifa,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (valorTarifa != null) 'valor_tarifa': valorTarifa,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
    });
  }

  CteDutoviariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<double?>? valorTarifa,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim}) {
    return CteDutoviariosCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      valorTarifa: valorTarifa ?? this.valorTarifa,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (valorTarifa.present) {
      map['valor_tarifa'] = Variable<double>(valorTarifa.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteDutoviariosCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('valorTarifa: $valorTarifa, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim')
          ..write(')'))
        .toString();
  }
}

class $CteMultimodalsTable extends CteMultimodals
    with TableInfo<$CteMultimodalsTable, CteMultimodal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteMultimodalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteCabecalhoMeta =
      const VerificationMeta('idCteCabecalho');
  @override
  late final GeneratedColumn<int> idCteCabecalho = GeneratedColumn<int>(
      'id_cte_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cotmMeta = const VerificationMeta('cotm');
  @override
  late final GeneratedColumn<String> cotm = GeneratedColumn<String>(
      'cotm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _indicadorNegociavelMeta =
      const VerificationMeta('indicadorNegociavel');
  @override
  late final GeneratedColumn<String> indicadorNegociavel =
      GeneratedColumn<String>('indicador_negociavel', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteCabecalho, cotm, indicadorNegociavel];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_multimodal';
  @override
  VerificationContext validateIntegrity(Insertable<CteMultimodal> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_cabecalho')) {
      context.handle(
          _idCteCabecalhoMeta,
          idCteCabecalho.isAcceptableOrUnknown(
              data['id_cte_cabecalho']!, _idCteCabecalhoMeta));
    }
    if (data.containsKey('cotm')) {
      context.handle(
          _cotmMeta, cotm.isAcceptableOrUnknown(data['cotm']!, _cotmMeta));
    }
    if (data.containsKey('indicador_negociavel')) {
      context.handle(
          _indicadorNegociavelMeta,
          indicadorNegociavel.isAcceptableOrUnknown(
              data['indicador_negociavel']!, _indicadorNegociavelMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteMultimodal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteMultimodal(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_cabecalho']),
      cotm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cotm']),
      indicadorNegociavel: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}indicador_negociavel']),
    );
  }

  @override
  $CteMultimodalsTable createAlias(String alias) {
    return $CteMultimodalsTable(attachedDatabase, alias);
  }
}

class CteMultimodal extends DataClass implements Insertable<CteMultimodal> {
  final int? id;
  final int? idCteCabecalho;
  final String? cotm;
  final String? indicadorNegociavel;
  const CteMultimodal(
      {this.id, this.idCteCabecalho, this.cotm, this.indicadorNegociavel});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteCabecalho != null) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho);
    }
    if (!nullToAbsent || cotm != null) {
      map['cotm'] = Variable<String>(cotm);
    }
    if (!nullToAbsent || indicadorNegociavel != null) {
      map['indicador_negociavel'] = Variable<String>(indicadorNegociavel);
    }
    return map;
  }

  factory CteMultimodal.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteMultimodal(
      id: serializer.fromJson<int?>(json['id']),
      idCteCabecalho: serializer.fromJson<int?>(json['idCteCabecalho']),
      cotm: serializer.fromJson<String?>(json['cotm']),
      indicadorNegociavel:
          serializer.fromJson<String?>(json['indicadorNegociavel']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteCabecalho': serializer.toJson<int?>(idCteCabecalho),
      'cotm': serializer.toJson<String?>(cotm),
      'indicadorNegociavel': serializer.toJson<String?>(indicadorNegociavel),
    };
  }

  CteMultimodal copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteCabecalho = const Value.absent(),
          Value<String?> cotm = const Value.absent(),
          Value<String?> indicadorNegociavel = const Value.absent()}) =>
      CteMultimodal(
        id: id.present ? id.value : this.id,
        idCteCabecalho:
            idCteCabecalho.present ? idCteCabecalho.value : this.idCteCabecalho,
        cotm: cotm.present ? cotm.value : this.cotm,
        indicadorNegociavel: indicadorNegociavel.present
            ? indicadorNegociavel.value
            : this.indicadorNegociavel,
      );
  @override
  String toString() {
    return (StringBuffer('CteMultimodal(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cotm: $cotm, ')
          ..write('indicadorNegociavel: $indicadorNegociavel')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteCabecalho, cotm, indicadorNegociavel);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteMultimodal &&
          other.id == this.id &&
          other.idCteCabecalho == this.idCteCabecalho &&
          other.cotm == this.cotm &&
          other.indicadorNegociavel == this.indicadorNegociavel);
}

class CteMultimodalsCompanion extends UpdateCompanion<CteMultimodal> {
  final Value<int?> id;
  final Value<int?> idCteCabecalho;
  final Value<String?> cotm;
  final Value<String?> indicadorNegociavel;
  const CteMultimodalsCompanion({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cotm = const Value.absent(),
    this.indicadorNegociavel = const Value.absent(),
  });
  CteMultimodalsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteCabecalho = const Value.absent(),
    this.cotm = const Value.absent(),
    this.indicadorNegociavel = const Value.absent(),
  });
  static Insertable<CteMultimodal> custom({
    Expression<int>? id,
    Expression<int>? idCteCabecalho,
    Expression<String>? cotm,
    Expression<String>? indicadorNegociavel,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteCabecalho != null) 'id_cte_cabecalho': idCteCabecalho,
      if (cotm != null) 'cotm': cotm,
      if (indicadorNegociavel != null)
        'indicador_negociavel': indicadorNegociavel,
    });
  }

  CteMultimodalsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteCabecalho,
      Value<String?>? cotm,
      Value<String?>? indicadorNegociavel}) {
    return CteMultimodalsCompanion(
      id: id ?? this.id,
      idCteCabecalho: idCteCabecalho ?? this.idCteCabecalho,
      cotm: cotm ?? this.cotm,
      indicadorNegociavel: indicadorNegociavel ?? this.indicadorNegociavel,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteCabecalho.present) {
      map['id_cte_cabecalho'] = Variable<int>(idCteCabecalho.value);
    }
    if (cotm.present) {
      map['cotm'] = Variable<String>(cotm.value);
    }
    if (indicadorNegociavel.present) {
      map['indicador_negociavel'] = Variable<String>(indicadorNegociavel.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteMultimodalsCompanion(')
          ..write('id: $id, ')
          ..write('idCteCabecalho: $idCteCabecalho, ')
          ..write('cotm: $cotm, ')
          ..write('indicadorNegociavel: $indicadorNegociavel')
          ..write(')'))
        .toString();
  }
}

class $CteCabecalhosTable extends CteCabecalhos
    with TableInfo<$CteCabecalhosTable, CteCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _naturezaOperacaoMeta =
      const VerificationMeta('naturezaOperacao');
  @override
  late final GeneratedColumn<String> naturezaOperacao = GeneratedColumn<String>(
      'natureza_operacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _chaveAcessoMeta =
      const VerificationMeta('chaveAcesso');
  @override
  late final GeneratedColumn<String> chaveAcesso = GeneratedColumn<String>(
      'chave_acesso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoChaveAcessoMeta =
      const VerificationMeta('digitoChaveAcesso');
  @override
  late final GeneratedColumn<String> digitoChaveAcesso =
      GeneratedColumn<String>('digito_chave_acesso', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoNumericoMeta =
      const VerificationMeta('codigoNumerico');
  @override
  late final GeneratedColumn<String> codigoNumerico = GeneratedColumn<String>(
      'codigo_numerico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 9),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataHoraEmissaoMeta =
      const VerificationMeta('dataHoraEmissao');
  @override
  late final GeneratedColumn<DateTime> dataHoraEmissao =
      GeneratedColumn<DateTime>('data_hora_emissao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ufEmitenteMeta =
      const VerificationMeta('ufEmitente');
  @override
  late final GeneratedColumn<String> ufEmitente = GeneratedColumn<String>(
      'uf_emitente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cfopMeta = const VerificationMeta('cfop');
  @override
  late final GeneratedColumn<int> cfop = GeneratedColumn<int>(
      'cfop', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _formaPagamentoMeta =
      const VerificationMeta('formaPagamento');
  @override
  late final GeneratedColumn<String> formaPagamento = GeneratedColumn<String>(
      'forma_pagamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modeloMeta = const VerificationMeta('modelo');
  @override
  late final GeneratedColumn<String> modelo = GeneratedColumn<String>(
      'modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formatoImpressaoDacteMeta =
      const VerificationMeta('formatoImpressaoDacte');
  @override
  late final GeneratedColumn<String> formatoImpressaoDacte =
      GeneratedColumn<String>('formato_impressao_dacte', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tipoEmissaoMeta =
      const VerificationMeta('tipoEmissao');
  @override
  late final GeneratedColumn<String> tipoEmissao = GeneratedColumn<String>(
      'tipo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ambienteMeta =
      const VerificationMeta('ambiente');
  @override
  late final GeneratedColumn<String> ambiente = GeneratedColumn<String>(
      'ambiente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoCteMeta =
      const VerificationMeta('tipoCte');
  @override
  late final GeneratedColumn<String> tipoCte = GeneratedColumn<String>(
      'tipo_cte', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _processoEmissaoMeta =
      const VerificationMeta('processoEmissao');
  @override
  late final GeneratedColumn<String> processoEmissao = GeneratedColumn<String>(
      'processo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _versaoProcessoEmissaoMeta =
      const VerificationMeta('versaoProcessoEmissao');
  @override
  late final GeneratedColumn<String> versaoProcessoEmissao =
      GeneratedColumn<String>('versao_processo_emissao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _chaveReferenciadoMeta =
      const VerificationMeta('chaveReferenciado');
  @override
  late final GeneratedColumn<String> chaveReferenciado =
      GeneratedColumn<String>('chave_referenciado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 44),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioEnvioMeta =
      const VerificationMeta('codigoMunicipioEnvio');
  @override
  late final GeneratedColumn<int> codigoMunicipioEnvio = GeneratedColumn<int>(
      'codigo_municipio_envio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioEnvioMeta =
      const VerificationMeta('nomeMunicipioEnvio');
  @override
  late final GeneratedColumn<String> nomeMunicipioEnvio =
      GeneratedColumn<String>('nome_municipio_envio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ufEnvioMeta =
      const VerificationMeta('ufEnvio');
  @override
  late final GeneratedColumn<String> ufEnvio = GeneratedColumn<String>(
      'uf_envio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modalMeta = const VerificationMeta('modal');
  @override
  late final GeneratedColumn<String> modal = GeneratedColumn<String>(
      'modal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoServicoMeta =
      const VerificationMeta('tipoServico');
  @override
  late final GeneratedColumn<String> tipoServico = GeneratedColumn<String>(
      'tipo_servico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioIniPrestacaoMeta =
      const VerificationMeta('codigoMunicipioIniPrestacao');
  @override
  late final GeneratedColumn<int> codigoMunicipioIniPrestacao =
      GeneratedColumn<int>('codigo_municipio_ini_prestacao', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioIniPrestacaoMeta =
      const VerificationMeta('nomeMunicipioIniPrestacao');
  @override
  late final GeneratedColumn<String> nomeMunicipioIniPrestacao =
      GeneratedColumn<String>('nome_municipio_ini_prestacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ufIniPrestacaoMeta =
      const VerificationMeta('ufIniPrestacao');
  @override
  late final GeneratedColumn<String> ufIniPrestacao = GeneratedColumn<String>(
      'uf_ini_prestacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioFimPrestacaoMeta =
      const VerificationMeta('codigoMunicipioFimPrestacao');
  @override
  late final GeneratedColumn<int> codigoMunicipioFimPrestacao =
      GeneratedColumn<int>('codigo_municipio_fim_prestacao', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioFimPrestacaoMeta =
      const VerificationMeta('nomeMunicipioFimPrestacao');
  @override
  late final GeneratedColumn<String> nomeMunicipioFimPrestacao =
      GeneratedColumn<String>('nome_municipio_fim_prestacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ufFimPrestacaoMeta =
      const VerificationMeta('ufFimPrestacao');
  @override
  late final GeneratedColumn<String> ufFimPrestacao = GeneratedColumn<String>(
      'uf_fim_prestacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _retiraMeta = const VerificationMeta('retira');
  @override
  late final GeneratedColumn<String> retira = GeneratedColumn<String>(
      'retira', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _retiraDetalheMeta =
      const VerificationMeta('retiraDetalhe');
  @override
  late final GeneratedColumn<String> retiraDetalhe = GeneratedColumn<String>(
      'retira_detalhe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 160),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tomadorMeta =
      const VerificationMeta('tomador');
  @override
  late final GeneratedColumn<String> tomador = GeneratedColumn<String>(
      'tomador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEntradaContingenciaMeta =
      const VerificationMeta('dataEntradaContingencia');
  @override
  late final GeneratedColumn<DateTime> dataEntradaContingencia =
      GeneratedColumn<DateTime>('data_entrada_contingencia', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _justificativaContingenciaMeta =
      const VerificationMeta('justificativaContingencia');
  @override
  late final GeneratedColumn<String> justificativaContingencia =
      GeneratedColumn<String>('justificativa_contingencia', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 255),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _caracAdicionalTransporteMeta =
      const VerificationMeta('caracAdicionalTransporte');
  @override
  late final GeneratedColumn<String> caracAdicionalTransporte =
      GeneratedColumn<String>('carac_adicional_transporte', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 15),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _caracAdicionalServicoMeta =
      const VerificationMeta('caracAdicionalServico');
  @override
  late final GeneratedColumn<String> caracAdicionalServico =
      GeneratedColumn<String>('carac_adicional_servico', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _funcionarioEmissorMeta =
      const VerificationMeta('funcionarioEmissor');
  @override
  late final GeneratedColumn<String> funcionarioEmissor =
      GeneratedColumn<String>('funcionario_emissor', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _fluxoOrigemMeta =
      const VerificationMeta('fluxoOrigem');
  @override
  late final GeneratedColumn<String> fluxoOrigem = GeneratedColumn<String>(
      'fluxo_origem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entregaTipoPeriodoMeta =
      const VerificationMeta('entregaTipoPeriodo');
  @override
  late final GeneratedColumn<String> entregaTipoPeriodo =
      GeneratedColumn<String>('entrega_tipo_periodo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _entregaDataProgramadaMeta =
      const VerificationMeta('entregaDataProgramada');
  @override
  late final GeneratedColumn<DateTime> entregaDataProgramada =
      GeneratedColumn<DateTime>('entrega_data_programada', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _entregaDataInicialMeta =
      const VerificationMeta('entregaDataInicial');
  @override
  late final GeneratedColumn<DateTime> entregaDataInicial =
      GeneratedColumn<DateTime>('entrega_data_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _entregaDataFinalMeta =
      const VerificationMeta('entregaDataFinal');
  @override
  late final GeneratedColumn<DateTime> entregaDataFinal =
      GeneratedColumn<DateTime>('entrega_data_final', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _entregaTipoHoraMeta =
      const VerificationMeta('entregaTipoHora');
  @override
  late final GeneratedColumn<String> entregaTipoHora = GeneratedColumn<String>(
      'entrega_tipo_hora', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _entregaHoraProgramadaMeta =
      const VerificationMeta('entregaHoraProgramada');
  @override
  late final GeneratedColumn<String> entregaHoraProgramada =
      GeneratedColumn<String>('entrega_hora_programada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _entregaHoraInicialMeta =
      const VerificationMeta('entregaHoraInicial');
  @override
  late final GeneratedColumn<String> entregaHoraInicial =
      GeneratedColumn<String>('entrega_hora_inicial', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _entregaHoraFinalMeta =
      const VerificationMeta('entregaHoraFinal');
  @override
  late final GeneratedColumn<String> entregaHoraFinal = GeneratedColumn<String>(
      'entrega_hora_final', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioOrigemCalculoMeta =
      const VerificationMeta('municipioOrigemCalculo');
  @override
  late final GeneratedColumn<String> municipioOrigemCalculo =
      GeneratedColumn<String>('municipio_origem_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 40),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _municipioDestinoCalculoMeta =
      const VerificationMeta('municipioDestinoCalculo');
  @override
  late final GeneratedColumn<String> municipioDestinoCalculo =
      GeneratedColumn<String>('municipio_destino_calculo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 40),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _observacoesGeraisMeta =
      const VerificationMeta('observacoesGerais');
  @override
  late final GeneratedColumn<String> observacoesGerais =
      GeneratedColumn<String>('observacoes_gerais', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalServicoMeta =
      const VerificationMeta('valorTotalServico');
  @override
  late final GeneratedColumn<double> valorTotalServico =
      GeneratedColumn<double>('valor_total_servico', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorReceberMeta =
      const VerificationMeta('valorReceber');
  @override
  late final GeneratedColumn<double> valorReceber = GeneratedColumn<double>(
      'valor_receber', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cstMeta = const VerificationMeta('cst');
  @override
  late final GeneratedColumn<String> cst = GeneratedColumn<String>(
      'cst', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsMeta =
      const VerificationMeta('baseCalculoIcms');
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
      'base_calculo_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsMeta =
      const VerificationMeta('aliquotaIcms');
  @override
  late final GeneratedColumn<double> aliquotaIcms = GeneratedColumn<double>(
      'aliquota_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsMeta =
      const VerificationMeta('valorIcms');
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
      'valor_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _percentualReducaoBcIcmsMeta =
      const VerificationMeta('percentualReducaoBcIcms');
  @override
  late final GeneratedColumn<double> percentualReducaoBcIcms =
      GeneratedColumn<double>('percentual_reducao_bc_icms', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcIcmsStRetidoMeta =
      const VerificationMeta('valorBcIcmsStRetido');
  @override
  late final GeneratedColumn<double> valorBcIcmsStRetido =
      GeneratedColumn<double>('valor_bc_icms_st_retido', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsStRetidoMeta =
      const VerificationMeta('valorIcmsStRetido');
  @override
  late final GeneratedColumn<double> valorIcmsStRetido =
      GeneratedColumn<double>('valor_icms_st_retido', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsStRetidoMeta =
      const VerificationMeta('aliquotaIcmsStRetido');
  @override
  late final GeneratedColumn<double> aliquotaIcmsStRetido =
      GeneratedColumn<double>('aliquota_icms_st_retido', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCreditoPresumidoIcmsMeta =
      const VerificationMeta('valorCreditoPresumidoIcms');
  @override
  late final GeneratedColumn<double> valorCreditoPresumidoIcms =
      GeneratedColumn<double>('valor_credito_presumido_icms', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _percentualBcIcmsOutraUfMeta =
      const VerificationMeta('percentualBcIcmsOutraUf');
  @override
  late final GeneratedColumn<double> percentualBcIcmsOutraUf =
      GeneratedColumn<double>('percentual_bc_icms_outra_uf', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcIcmsOutraUfMeta =
      const VerificationMeta('valorBcIcmsOutraUf');
  @override
  late final GeneratedColumn<double> valorBcIcmsOutraUf =
      GeneratedColumn<double>('valor_bc_icms_outra_uf', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsOutraUfMeta =
      const VerificationMeta('aliquotaIcmsOutraUf');
  @override
  late final GeneratedColumn<double> aliquotaIcmsOutraUf =
      GeneratedColumn<double>('aliquota_icms_outra_uf', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsOutraUfMeta =
      const VerificationMeta('valorIcmsOutraUf');
  @override
  late final GeneratedColumn<double> valorIcmsOutraUf = GeneratedColumn<double>(
      'valor_icms_outra_uf', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _simplesNacionalIndicadorMeta =
      const VerificationMeta('simplesNacionalIndicador');
  @override
  late final GeneratedColumn<String> simplesNacionalIndicador =
      GeneratedColumn<String>('simples_nacional_indicador', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _simplesNacionalTotalMeta =
      const VerificationMeta('simplesNacionalTotal');
  @override
  late final GeneratedColumn<double> simplesNacionalTotal =
      GeneratedColumn<double>('simples_nacional_total', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _informacoesAddFiscoMeta =
      const VerificationMeta('informacoesAddFisco');
  @override
  late final GeneratedColumn<String> informacoesAddFisco =
      GeneratedColumn<String>('informacoes_add_fisco', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalCargaMeta =
      const VerificationMeta('valorTotalCarga');
  @override
  late final GeneratedColumn<double> valorTotalCarga = GeneratedColumn<double>(
      'valor_total_carga', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _produtoPredominanteMeta =
      const VerificationMeta('produtoPredominante');
  @override
  late final GeneratedColumn<String> produtoPredominante =
      GeneratedColumn<String>('produto_predominante', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cargaOutrasCaracteristicasMeta =
      const VerificationMeta('cargaOutrasCaracteristicas');
  @override
  late final GeneratedColumn<String> cargaOutrasCaracteristicas =
      GeneratedColumn<String>('carga_outras_caracteristicas', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _modalVersaoLayoutMeta =
      const VerificationMeta('modalVersaoLayout');
  @override
  late final GeneratedColumn<int> modalVersaoLayout = GeneratedColumn<int>(
      'modal_versao_layout', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _chaveCteSubstituidoMeta =
      const VerificationMeta('chaveCteSubstituido');
  @override
  late final GeneratedColumn<String> chaveCteSubstituido =
      GeneratedColumn<String>('chave_cte_substituido', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 44),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        naturezaOperacao,
        chaveAcesso,
        digitoChaveAcesso,
        codigoNumerico,
        serie,
        numero,
        dataHoraEmissao,
        ufEmitente,
        cfop,
        formaPagamento,
        modelo,
        formatoImpressaoDacte,
        tipoEmissao,
        ambiente,
        tipoCte,
        processoEmissao,
        versaoProcessoEmissao,
        chaveReferenciado,
        codigoMunicipioEnvio,
        nomeMunicipioEnvio,
        ufEnvio,
        modal,
        tipoServico,
        codigoMunicipioIniPrestacao,
        nomeMunicipioIniPrestacao,
        ufIniPrestacao,
        codigoMunicipioFimPrestacao,
        nomeMunicipioFimPrestacao,
        ufFimPrestacao,
        retira,
        retiraDetalhe,
        tomador,
        dataEntradaContingencia,
        justificativaContingencia,
        caracAdicionalTransporte,
        caracAdicionalServico,
        funcionarioEmissor,
        fluxoOrigem,
        entregaTipoPeriodo,
        entregaDataProgramada,
        entregaDataInicial,
        entregaDataFinal,
        entregaTipoHora,
        entregaHoraProgramada,
        entregaHoraInicial,
        entregaHoraFinal,
        municipioOrigemCalculo,
        municipioDestinoCalculo,
        observacoesGerais,
        valorTotalServico,
        valorReceber,
        cst,
        baseCalculoIcms,
        aliquotaIcms,
        valorIcms,
        percentualReducaoBcIcms,
        valorBcIcmsStRetido,
        valorIcmsStRetido,
        aliquotaIcmsStRetido,
        valorCreditoPresumidoIcms,
        percentualBcIcmsOutraUf,
        valorBcIcmsOutraUf,
        aliquotaIcmsOutraUf,
        valorIcmsOutraUf,
        simplesNacionalIndicador,
        simplesNacionalTotal,
        informacoesAddFisco,
        valorTotalCarga,
        produtoPredominante,
        cargaOutrasCaracteristicas,
        modalVersaoLayout,
        chaveCteSubstituido
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<CteCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('natureza_operacao')) {
      context.handle(
          _naturezaOperacaoMeta,
          naturezaOperacao.isAcceptableOrUnknown(
              data['natureza_operacao']!, _naturezaOperacaoMeta));
    }
    if (data.containsKey('chave_acesso')) {
      context.handle(
          _chaveAcessoMeta,
          chaveAcesso.isAcceptableOrUnknown(
              data['chave_acesso']!, _chaveAcessoMeta));
    }
    if (data.containsKey('digito_chave_acesso')) {
      context.handle(
          _digitoChaveAcessoMeta,
          digitoChaveAcesso.isAcceptableOrUnknown(
              data['digito_chave_acesso']!, _digitoChaveAcessoMeta));
    }
    if (data.containsKey('codigo_numerico')) {
      context.handle(
          _codigoNumericoMeta,
          codigoNumerico.isAcceptableOrUnknown(
              data['codigo_numerico']!, _codigoNumericoMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_hora_emissao')) {
      context.handle(
          _dataHoraEmissaoMeta,
          dataHoraEmissao.isAcceptableOrUnknown(
              data['data_hora_emissao']!, _dataHoraEmissaoMeta));
    }
    if (data.containsKey('uf_emitente')) {
      context.handle(
          _ufEmitenteMeta,
          ufEmitente.isAcceptableOrUnknown(
              data['uf_emitente']!, _ufEmitenteMeta));
    }
    if (data.containsKey('cfop')) {
      context.handle(
          _cfopMeta, cfop.isAcceptableOrUnknown(data['cfop']!, _cfopMeta));
    }
    if (data.containsKey('forma_pagamento')) {
      context.handle(
          _formaPagamentoMeta,
          formaPagamento.isAcceptableOrUnknown(
              data['forma_pagamento']!, _formaPagamentoMeta));
    }
    if (data.containsKey('modelo')) {
      context.handle(_modeloMeta,
          modelo.isAcceptableOrUnknown(data['modelo']!, _modeloMeta));
    }
    if (data.containsKey('formato_impressao_dacte')) {
      context.handle(
          _formatoImpressaoDacteMeta,
          formatoImpressaoDacte.isAcceptableOrUnknown(
              data['formato_impressao_dacte']!, _formatoImpressaoDacteMeta));
    }
    if (data.containsKey('tipo_emissao')) {
      context.handle(
          _tipoEmissaoMeta,
          tipoEmissao.isAcceptableOrUnknown(
              data['tipo_emissao']!, _tipoEmissaoMeta));
    }
    if (data.containsKey('ambiente')) {
      context.handle(_ambienteMeta,
          ambiente.isAcceptableOrUnknown(data['ambiente']!, _ambienteMeta));
    }
    if (data.containsKey('tipo_cte')) {
      context.handle(_tipoCteMeta,
          tipoCte.isAcceptableOrUnknown(data['tipo_cte']!, _tipoCteMeta));
    }
    if (data.containsKey('processo_emissao')) {
      context.handle(
          _processoEmissaoMeta,
          processoEmissao.isAcceptableOrUnknown(
              data['processo_emissao']!, _processoEmissaoMeta));
    }
    if (data.containsKey('versao_processo_emissao')) {
      context.handle(
          _versaoProcessoEmissaoMeta,
          versaoProcessoEmissao.isAcceptableOrUnknown(
              data['versao_processo_emissao']!, _versaoProcessoEmissaoMeta));
    }
    if (data.containsKey('chave_referenciado')) {
      context.handle(
          _chaveReferenciadoMeta,
          chaveReferenciado.isAcceptableOrUnknown(
              data['chave_referenciado']!, _chaveReferenciadoMeta));
    }
    if (data.containsKey('codigo_municipio_envio')) {
      context.handle(
          _codigoMunicipioEnvioMeta,
          codigoMunicipioEnvio.isAcceptableOrUnknown(
              data['codigo_municipio_envio']!, _codigoMunicipioEnvioMeta));
    }
    if (data.containsKey('nome_municipio_envio')) {
      context.handle(
          _nomeMunicipioEnvioMeta,
          nomeMunicipioEnvio.isAcceptableOrUnknown(
              data['nome_municipio_envio']!, _nomeMunicipioEnvioMeta));
    }
    if (data.containsKey('uf_envio')) {
      context.handle(_ufEnvioMeta,
          ufEnvio.isAcceptableOrUnknown(data['uf_envio']!, _ufEnvioMeta));
    }
    if (data.containsKey('modal')) {
      context.handle(
          _modalMeta, modal.isAcceptableOrUnknown(data['modal']!, _modalMeta));
    }
    if (data.containsKey('tipo_servico')) {
      context.handle(
          _tipoServicoMeta,
          tipoServico.isAcceptableOrUnknown(
              data['tipo_servico']!, _tipoServicoMeta));
    }
    if (data.containsKey('codigo_municipio_ini_prestacao')) {
      context.handle(
          _codigoMunicipioIniPrestacaoMeta,
          codigoMunicipioIniPrestacao.isAcceptableOrUnknown(
              data['codigo_municipio_ini_prestacao']!,
              _codigoMunicipioIniPrestacaoMeta));
    }
    if (data.containsKey('nome_municipio_ini_prestacao')) {
      context.handle(
          _nomeMunicipioIniPrestacaoMeta,
          nomeMunicipioIniPrestacao.isAcceptableOrUnknown(
              data['nome_municipio_ini_prestacao']!,
              _nomeMunicipioIniPrestacaoMeta));
    }
    if (data.containsKey('uf_ini_prestacao')) {
      context.handle(
          _ufIniPrestacaoMeta,
          ufIniPrestacao.isAcceptableOrUnknown(
              data['uf_ini_prestacao']!, _ufIniPrestacaoMeta));
    }
    if (data.containsKey('codigo_municipio_fim_prestacao')) {
      context.handle(
          _codigoMunicipioFimPrestacaoMeta,
          codigoMunicipioFimPrestacao.isAcceptableOrUnknown(
              data['codigo_municipio_fim_prestacao']!,
              _codigoMunicipioFimPrestacaoMeta));
    }
    if (data.containsKey('nome_municipio_fim_prestacao')) {
      context.handle(
          _nomeMunicipioFimPrestacaoMeta,
          nomeMunicipioFimPrestacao.isAcceptableOrUnknown(
              data['nome_municipio_fim_prestacao']!,
              _nomeMunicipioFimPrestacaoMeta));
    }
    if (data.containsKey('uf_fim_prestacao')) {
      context.handle(
          _ufFimPrestacaoMeta,
          ufFimPrestacao.isAcceptableOrUnknown(
              data['uf_fim_prestacao']!, _ufFimPrestacaoMeta));
    }
    if (data.containsKey('retira')) {
      context.handle(_retiraMeta,
          retira.isAcceptableOrUnknown(data['retira']!, _retiraMeta));
    }
    if (data.containsKey('retira_detalhe')) {
      context.handle(
          _retiraDetalheMeta,
          retiraDetalhe.isAcceptableOrUnknown(
              data['retira_detalhe']!, _retiraDetalheMeta));
    }
    if (data.containsKey('tomador')) {
      context.handle(_tomadorMeta,
          tomador.isAcceptableOrUnknown(data['tomador']!, _tomadorMeta));
    }
    if (data.containsKey('data_entrada_contingencia')) {
      context.handle(
          _dataEntradaContingenciaMeta,
          dataEntradaContingencia.isAcceptableOrUnknown(
              data['data_entrada_contingencia']!,
              _dataEntradaContingenciaMeta));
    }
    if (data.containsKey('justificativa_contingencia')) {
      context.handle(
          _justificativaContingenciaMeta,
          justificativaContingencia.isAcceptableOrUnknown(
              data['justificativa_contingencia']!,
              _justificativaContingenciaMeta));
    }
    if (data.containsKey('carac_adicional_transporte')) {
      context.handle(
          _caracAdicionalTransporteMeta,
          caracAdicionalTransporte.isAcceptableOrUnknown(
              data['carac_adicional_transporte']!,
              _caracAdicionalTransporteMeta));
    }
    if (data.containsKey('carac_adicional_servico')) {
      context.handle(
          _caracAdicionalServicoMeta,
          caracAdicionalServico.isAcceptableOrUnknown(
              data['carac_adicional_servico']!, _caracAdicionalServicoMeta));
    }
    if (data.containsKey('funcionario_emissor')) {
      context.handle(
          _funcionarioEmissorMeta,
          funcionarioEmissor.isAcceptableOrUnknown(
              data['funcionario_emissor']!, _funcionarioEmissorMeta));
    }
    if (data.containsKey('fluxo_origem')) {
      context.handle(
          _fluxoOrigemMeta,
          fluxoOrigem.isAcceptableOrUnknown(
              data['fluxo_origem']!, _fluxoOrigemMeta));
    }
    if (data.containsKey('entrega_tipo_periodo')) {
      context.handle(
          _entregaTipoPeriodoMeta,
          entregaTipoPeriodo.isAcceptableOrUnknown(
              data['entrega_tipo_periodo']!, _entregaTipoPeriodoMeta));
    }
    if (data.containsKey('entrega_data_programada')) {
      context.handle(
          _entregaDataProgramadaMeta,
          entregaDataProgramada.isAcceptableOrUnknown(
              data['entrega_data_programada']!, _entregaDataProgramadaMeta));
    }
    if (data.containsKey('entrega_data_inicial')) {
      context.handle(
          _entregaDataInicialMeta,
          entregaDataInicial.isAcceptableOrUnknown(
              data['entrega_data_inicial']!, _entregaDataInicialMeta));
    }
    if (data.containsKey('entrega_data_final')) {
      context.handle(
          _entregaDataFinalMeta,
          entregaDataFinal.isAcceptableOrUnknown(
              data['entrega_data_final']!, _entregaDataFinalMeta));
    }
    if (data.containsKey('entrega_tipo_hora')) {
      context.handle(
          _entregaTipoHoraMeta,
          entregaTipoHora.isAcceptableOrUnknown(
              data['entrega_tipo_hora']!, _entregaTipoHoraMeta));
    }
    if (data.containsKey('entrega_hora_programada')) {
      context.handle(
          _entregaHoraProgramadaMeta,
          entregaHoraProgramada.isAcceptableOrUnknown(
              data['entrega_hora_programada']!, _entregaHoraProgramadaMeta));
    }
    if (data.containsKey('entrega_hora_inicial')) {
      context.handle(
          _entregaHoraInicialMeta,
          entregaHoraInicial.isAcceptableOrUnknown(
              data['entrega_hora_inicial']!, _entregaHoraInicialMeta));
    }
    if (data.containsKey('entrega_hora_final')) {
      context.handle(
          _entregaHoraFinalMeta,
          entregaHoraFinal.isAcceptableOrUnknown(
              data['entrega_hora_final']!, _entregaHoraFinalMeta));
    }
    if (data.containsKey('municipio_origem_calculo')) {
      context.handle(
          _municipioOrigemCalculoMeta,
          municipioOrigemCalculo.isAcceptableOrUnknown(
              data['municipio_origem_calculo']!, _municipioOrigemCalculoMeta));
    }
    if (data.containsKey('municipio_destino_calculo')) {
      context.handle(
          _municipioDestinoCalculoMeta,
          municipioDestinoCalculo.isAcceptableOrUnknown(
              data['municipio_destino_calculo']!,
              _municipioDestinoCalculoMeta));
    }
    if (data.containsKey('observacoes_gerais')) {
      context.handle(
          _observacoesGeraisMeta,
          observacoesGerais.isAcceptableOrUnknown(
              data['observacoes_gerais']!, _observacoesGeraisMeta));
    }
    if (data.containsKey('valor_total_servico')) {
      context.handle(
          _valorTotalServicoMeta,
          valorTotalServico.isAcceptableOrUnknown(
              data['valor_total_servico']!, _valorTotalServicoMeta));
    }
    if (data.containsKey('valor_receber')) {
      context.handle(
          _valorReceberMeta,
          valorReceber.isAcceptableOrUnknown(
              data['valor_receber']!, _valorReceberMeta));
    }
    if (data.containsKey('cst')) {
      context.handle(
          _cstMeta, cst.isAcceptableOrUnknown(data['cst']!, _cstMeta));
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
          _baseCalculoIcmsMeta,
          baseCalculoIcms.isAcceptableOrUnknown(
              data['base_calculo_icms']!, _baseCalculoIcmsMeta));
    }
    if (data.containsKey('aliquota_icms')) {
      context.handle(
          _aliquotaIcmsMeta,
          aliquotaIcms.isAcceptableOrUnknown(
              data['aliquota_icms']!, _aliquotaIcmsMeta));
    }
    if (data.containsKey('valor_icms')) {
      context.handle(_valorIcmsMeta,
          valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta));
    }
    if (data.containsKey('percentual_reducao_bc_icms')) {
      context.handle(
          _percentualReducaoBcIcmsMeta,
          percentualReducaoBcIcms.isAcceptableOrUnknown(
              data['percentual_reducao_bc_icms']!,
              _percentualReducaoBcIcmsMeta));
    }
    if (data.containsKey('valor_bc_icms_st_retido')) {
      context.handle(
          _valorBcIcmsStRetidoMeta,
          valorBcIcmsStRetido.isAcceptableOrUnknown(
              data['valor_bc_icms_st_retido']!, _valorBcIcmsStRetidoMeta));
    }
    if (data.containsKey('valor_icms_st_retido')) {
      context.handle(
          _valorIcmsStRetidoMeta,
          valorIcmsStRetido.isAcceptableOrUnknown(
              data['valor_icms_st_retido']!, _valorIcmsStRetidoMeta));
    }
    if (data.containsKey('aliquota_icms_st_retido')) {
      context.handle(
          _aliquotaIcmsStRetidoMeta,
          aliquotaIcmsStRetido.isAcceptableOrUnknown(
              data['aliquota_icms_st_retido']!, _aliquotaIcmsStRetidoMeta));
    }
    if (data.containsKey('valor_credito_presumido_icms')) {
      context.handle(
          _valorCreditoPresumidoIcmsMeta,
          valorCreditoPresumidoIcms.isAcceptableOrUnknown(
              data['valor_credito_presumido_icms']!,
              _valorCreditoPresumidoIcmsMeta));
    }
    if (data.containsKey('percentual_bc_icms_outra_uf')) {
      context.handle(
          _percentualBcIcmsOutraUfMeta,
          percentualBcIcmsOutraUf.isAcceptableOrUnknown(
              data['percentual_bc_icms_outra_uf']!,
              _percentualBcIcmsOutraUfMeta));
    }
    if (data.containsKey('valor_bc_icms_outra_uf')) {
      context.handle(
          _valorBcIcmsOutraUfMeta,
          valorBcIcmsOutraUf.isAcceptableOrUnknown(
              data['valor_bc_icms_outra_uf']!, _valorBcIcmsOutraUfMeta));
    }
    if (data.containsKey('aliquota_icms_outra_uf')) {
      context.handle(
          _aliquotaIcmsOutraUfMeta,
          aliquotaIcmsOutraUf.isAcceptableOrUnknown(
              data['aliquota_icms_outra_uf']!, _aliquotaIcmsOutraUfMeta));
    }
    if (data.containsKey('valor_icms_outra_uf')) {
      context.handle(
          _valorIcmsOutraUfMeta,
          valorIcmsOutraUf.isAcceptableOrUnknown(
              data['valor_icms_outra_uf']!, _valorIcmsOutraUfMeta));
    }
    if (data.containsKey('simples_nacional_indicador')) {
      context.handle(
          _simplesNacionalIndicadorMeta,
          simplesNacionalIndicador.isAcceptableOrUnknown(
              data['simples_nacional_indicador']!,
              _simplesNacionalIndicadorMeta));
    }
    if (data.containsKey('simples_nacional_total')) {
      context.handle(
          _simplesNacionalTotalMeta,
          simplesNacionalTotal.isAcceptableOrUnknown(
              data['simples_nacional_total']!, _simplesNacionalTotalMeta));
    }
    if (data.containsKey('informacoes_add_fisco')) {
      context.handle(
          _informacoesAddFiscoMeta,
          informacoesAddFisco.isAcceptableOrUnknown(
              data['informacoes_add_fisco']!, _informacoesAddFiscoMeta));
    }
    if (data.containsKey('valor_total_carga')) {
      context.handle(
          _valorTotalCargaMeta,
          valorTotalCarga.isAcceptableOrUnknown(
              data['valor_total_carga']!, _valorTotalCargaMeta));
    }
    if (data.containsKey('produto_predominante')) {
      context.handle(
          _produtoPredominanteMeta,
          produtoPredominante.isAcceptableOrUnknown(
              data['produto_predominante']!, _produtoPredominanteMeta));
    }
    if (data.containsKey('carga_outras_caracteristicas')) {
      context.handle(
          _cargaOutrasCaracteristicasMeta,
          cargaOutrasCaracteristicas.isAcceptableOrUnknown(
              data['carga_outras_caracteristicas']!,
              _cargaOutrasCaracteristicasMeta));
    }
    if (data.containsKey('modal_versao_layout')) {
      context.handle(
          _modalVersaoLayoutMeta,
          modalVersaoLayout.isAcceptableOrUnknown(
              data['modal_versao_layout']!, _modalVersaoLayoutMeta));
    }
    if (data.containsKey('chave_cte_substituido')) {
      context.handle(
          _chaveCteSubstituidoMeta,
          chaveCteSubstituido.isAcceptableOrUnknown(
              data['chave_cte_substituido']!, _chaveCteSubstituidoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      naturezaOperacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}natureza_operacao']),
      chaveAcesso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_acesso']),
      digitoChaveAcesso: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}digito_chave_acesso']),
      codigoNumerico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_numerico']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataHoraEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_hora_emissao']),
      ufEmitente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_emitente']),
      cfop: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop']),
      formaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}forma_pagamento']),
      modelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modelo']),
      formatoImpressaoDacte: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}formato_impressao_dacte']),
      tipoEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_emissao']),
      ambiente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ambiente']),
      tipoCte: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_cte']),
      processoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}processo_emissao']),
      versaoProcessoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}versao_processo_emissao']),
      chaveReferenciado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}chave_referenciado']),
      codigoMunicipioEnvio: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}codigo_municipio_envio']),
      nomeMunicipioEnvio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}nome_municipio_envio']),
      ufEnvio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_envio']),
      modal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modal']),
      tipoServico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_servico']),
      codigoMunicipioIniPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}codigo_municipio_ini_prestacao']),
      nomeMunicipioIniPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}nome_municipio_ini_prestacao']),
      ufIniPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}uf_ini_prestacao']),
      codigoMunicipioFimPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}codigo_municipio_fim_prestacao']),
      nomeMunicipioFimPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}nome_municipio_fim_prestacao']),
      ufFimPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}uf_fim_prestacao']),
      retira: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}retira']),
      retiraDetalhe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}retira_detalhe']),
      tomador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tomador']),
      dataEntradaContingencia: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_entrada_contingencia']),
      justificativaContingencia: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}justificativa_contingencia']),
      caracAdicionalTransporte: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}carac_adicional_transporte']),
      caracAdicionalServico: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}carac_adicional_servico']),
      funcionarioEmissor: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcionario_emissor']),
      fluxoOrigem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fluxo_origem']),
      entregaTipoPeriodo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}entrega_tipo_periodo']),
      entregaDataProgramada: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}entrega_data_programada']),
      entregaDataInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}entrega_data_inicial']),
      entregaDataFinal: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}entrega_data_final']),
      entregaTipoHora: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}entrega_tipo_hora']),
      entregaHoraProgramada: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}entrega_hora_programada']),
      entregaHoraInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}entrega_hora_inicial']),
      entregaHoraFinal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}entrega_hora_final']),
      municipioOrigemCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}municipio_origem_calculo']),
      municipioDestinoCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}municipio_destino_calculo']),
      observacoesGerais: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}observacoes_gerais']),
      valorTotalServico: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_servico']),
      valorReceber: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_receber']),
      cst: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst']),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms']),
      aliquotaIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota_icms']),
      valorIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms']),
      percentualReducaoBcIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_reducao_bc_icms']),
      valorBcIcmsStRetido: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_icms_st_retido']),
      valorIcmsStRetido: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_st_retido']),
      aliquotaIcmsStRetido: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}aliquota_icms_st_retido']),
      valorCreditoPresumidoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_credito_presumido_icms']),
      percentualBcIcmsOutraUf: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}percentual_bc_icms_outra_uf']),
      valorBcIcmsOutraUf: attachedDatabase.typeMapping.read(DriftSqlType.double,
          data['${effectivePrefix}valor_bc_icms_outra_uf']),
      aliquotaIcmsOutraUf: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}aliquota_icms_outra_uf']),
      valorIcmsOutraUf: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_outra_uf']),
      simplesNacionalIndicador: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}simples_nacional_indicador']),
      simplesNacionalTotal: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}simples_nacional_total']),
      informacoesAddFisco: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}informacoes_add_fisco']),
      valorTotalCarga: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_carga']),
      produtoPredominante: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}produto_predominante']),
      cargaOutrasCaracteristicas: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}carga_outras_caracteristicas']),
      modalVersaoLayout: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}modal_versao_layout']),
      chaveCteSubstituido: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}chave_cte_substituido']),
    );
  }

  @override
  $CteCabecalhosTable createAlias(String alias) {
    return $CteCabecalhosTable(attachedDatabase, alias);
  }
}

class CteCabecalho extends DataClass implements Insertable<CteCabecalho> {
  final int? id;
  final String? naturezaOperacao;
  final String? chaveAcesso;
  final String? digitoChaveAcesso;
  final String? codigoNumerico;
  final String? serie;
  final String? numero;
  final DateTime? dataHoraEmissao;
  final String? ufEmitente;
  final int? cfop;
  final String? formaPagamento;
  final String? modelo;
  final String? formatoImpressaoDacte;
  final String? tipoEmissao;
  final String? ambiente;
  final String? tipoCte;
  final String? processoEmissao;
  final String? versaoProcessoEmissao;
  final String? chaveReferenciado;
  final int? codigoMunicipioEnvio;
  final String? nomeMunicipioEnvio;
  final String? ufEnvio;
  final String? modal;
  final String? tipoServico;
  final int? codigoMunicipioIniPrestacao;
  final String? nomeMunicipioIniPrestacao;
  final String? ufIniPrestacao;
  final int? codigoMunicipioFimPrestacao;
  final String? nomeMunicipioFimPrestacao;
  final String? ufFimPrestacao;
  final String? retira;
  final String? retiraDetalhe;
  final String? tomador;
  final DateTime? dataEntradaContingencia;
  final String? justificativaContingencia;
  final String? caracAdicionalTransporte;
  final String? caracAdicionalServico;
  final String? funcionarioEmissor;
  final String? fluxoOrigem;
  final String? entregaTipoPeriodo;
  final DateTime? entregaDataProgramada;
  final DateTime? entregaDataInicial;
  final DateTime? entregaDataFinal;
  final String? entregaTipoHora;
  final String? entregaHoraProgramada;
  final String? entregaHoraInicial;
  final String? entregaHoraFinal;
  final String? municipioOrigemCalculo;
  final String? municipioDestinoCalculo;
  final String? observacoesGerais;
  final double? valorTotalServico;
  final double? valorReceber;
  final String? cst;
  final double? baseCalculoIcms;
  final double? aliquotaIcms;
  final double? valorIcms;
  final double? percentualReducaoBcIcms;
  final double? valorBcIcmsStRetido;
  final double? valorIcmsStRetido;
  final double? aliquotaIcmsStRetido;
  final double? valorCreditoPresumidoIcms;
  final double? percentualBcIcmsOutraUf;
  final double? valorBcIcmsOutraUf;
  final double? aliquotaIcmsOutraUf;
  final double? valorIcmsOutraUf;
  final String? simplesNacionalIndicador;
  final double? simplesNacionalTotal;
  final String? informacoesAddFisco;
  final double? valorTotalCarga;
  final String? produtoPredominante;
  final String? cargaOutrasCaracteristicas;
  final int? modalVersaoLayout;
  final String? chaveCteSubstituido;
  const CteCabecalho(
      {this.id,
      this.naturezaOperacao,
      this.chaveAcesso,
      this.digitoChaveAcesso,
      this.codigoNumerico,
      this.serie,
      this.numero,
      this.dataHoraEmissao,
      this.ufEmitente,
      this.cfop,
      this.formaPagamento,
      this.modelo,
      this.formatoImpressaoDacte,
      this.tipoEmissao,
      this.ambiente,
      this.tipoCte,
      this.processoEmissao,
      this.versaoProcessoEmissao,
      this.chaveReferenciado,
      this.codigoMunicipioEnvio,
      this.nomeMunicipioEnvio,
      this.ufEnvio,
      this.modal,
      this.tipoServico,
      this.codigoMunicipioIniPrestacao,
      this.nomeMunicipioIniPrestacao,
      this.ufIniPrestacao,
      this.codigoMunicipioFimPrestacao,
      this.nomeMunicipioFimPrestacao,
      this.ufFimPrestacao,
      this.retira,
      this.retiraDetalhe,
      this.tomador,
      this.dataEntradaContingencia,
      this.justificativaContingencia,
      this.caracAdicionalTransporte,
      this.caracAdicionalServico,
      this.funcionarioEmissor,
      this.fluxoOrigem,
      this.entregaTipoPeriodo,
      this.entregaDataProgramada,
      this.entregaDataInicial,
      this.entregaDataFinal,
      this.entregaTipoHora,
      this.entregaHoraProgramada,
      this.entregaHoraInicial,
      this.entregaHoraFinal,
      this.municipioOrigemCalculo,
      this.municipioDestinoCalculo,
      this.observacoesGerais,
      this.valorTotalServico,
      this.valorReceber,
      this.cst,
      this.baseCalculoIcms,
      this.aliquotaIcms,
      this.valorIcms,
      this.percentualReducaoBcIcms,
      this.valorBcIcmsStRetido,
      this.valorIcmsStRetido,
      this.aliquotaIcmsStRetido,
      this.valorCreditoPresumidoIcms,
      this.percentualBcIcmsOutraUf,
      this.valorBcIcmsOutraUf,
      this.aliquotaIcmsOutraUf,
      this.valorIcmsOutraUf,
      this.simplesNacionalIndicador,
      this.simplesNacionalTotal,
      this.informacoesAddFisco,
      this.valorTotalCarga,
      this.produtoPredominante,
      this.cargaOutrasCaracteristicas,
      this.modalVersaoLayout,
      this.chaveCteSubstituido});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || naturezaOperacao != null) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao);
    }
    if (!nullToAbsent || chaveAcesso != null) {
      map['chave_acesso'] = Variable<String>(chaveAcesso);
    }
    if (!nullToAbsent || digitoChaveAcesso != null) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso);
    }
    if (!nullToAbsent || codigoNumerico != null) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataHoraEmissao != null) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao);
    }
    if (!nullToAbsent || ufEmitente != null) {
      map['uf_emitente'] = Variable<String>(ufEmitente);
    }
    if (!nullToAbsent || cfop != null) {
      map['cfop'] = Variable<int>(cfop);
    }
    if (!nullToAbsent || formaPagamento != null) {
      map['forma_pagamento'] = Variable<String>(formaPagamento);
    }
    if (!nullToAbsent || modelo != null) {
      map['modelo'] = Variable<String>(modelo);
    }
    if (!nullToAbsent || formatoImpressaoDacte != null) {
      map['formato_impressao_dacte'] = Variable<String>(formatoImpressaoDacte);
    }
    if (!nullToAbsent || tipoEmissao != null) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao);
    }
    if (!nullToAbsent || ambiente != null) {
      map['ambiente'] = Variable<String>(ambiente);
    }
    if (!nullToAbsent || tipoCte != null) {
      map['tipo_cte'] = Variable<String>(tipoCte);
    }
    if (!nullToAbsent || processoEmissao != null) {
      map['processo_emissao'] = Variable<String>(processoEmissao);
    }
    if (!nullToAbsent || versaoProcessoEmissao != null) {
      map['versao_processo_emissao'] = Variable<String>(versaoProcessoEmissao);
    }
    if (!nullToAbsent || chaveReferenciado != null) {
      map['chave_referenciado'] = Variable<String>(chaveReferenciado);
    }
    if (!nullToAbsent || codigoMunicipioEnvio != null) {
      map['codigo_municipio_envio'] = Variable<int>(codigoMunicipioEnvio);
    }
    if (!nullToAbsent || nomeMunicipioEnvio != null) {
      map['nome_municipio_envio'] = Variable<String>(nomeMunicipioEnvio);
    }
    if (!nullToAbsent || ufEnvio != null) {
      map['uf_envio'] = Variable<String>(ufEnvio);
    }
    if (!nullToAbsent || modal != null) {
      map['modal'] = Variable<String>(modal);
    }
    if (!nullToAbsent || tipoServico != null) {
      map['tipo_servico'] = Variable<String>(tipoServico);
    }
    if (!nullToAbsent || codigoMunicipioIniPrestacao != null) {
      map['codigo_municipio_ini_prestacao'] =
          Variable<int>(codigoMunicipioIniPrestacao);
    }
    if (!nullToAbsent || nomeMunicipioIniPrestacao != null) {
      map['nome_municipio_ini_prestacao'] =
          Variable<String>(nomeMunicipioIniPrestacao);
    }
    if (!nullToAbsent || ufIniPrestacao != null) {
      map['uf_ini_prestacao'] = Variable<String>(ufIniPrestacao);
    }
    if (!nullToAbsent || codigoMunicipioFimPrestacao != null) {
      map['codigo_municipio_fim_prestacao'] =
          Variable<int>(codigoMunicipioFimPrestacao);
    }
    if (!nullToAbsent || nomeMunicipioFimPrestacao != null) {
      map['nome_municipio_fim_prestacao'] =
          Variable<String>(nomeMunicipioFimPrestacao);
    }
    if (!nullToAbsent || ufFimPrestacao != null) {
      map['uf_fim_prestacao'] = Variable<String>(ufFimPrestacao);
    }
    if (!nullToAbsent || retira != null) {
      map['retira'] = Variable<String>(retira);
    }
    if (!nullToAbsent || retiraDetalhe != null) {
      map['retira_detalhe'] = Variable<String>(retiraDetalhe);
    }
    if (!nullToAbsent || tomador != null) {
      map['tomador'] = Variable<String>(tomador);
    }
    if (!nullToAbsent || dataEntradaContingencia != null) {
      map['data_entrada_contingencia'] =
          Variable<DateTime>(dataEntradaContingencia);
    }
    if (!nullToAbsent || justificativaContingencia != null) {
      map['justificativa_contingencia'] =
          Variable<String>(justificativaContingencia);
    }
    if (!nullToAbsent || caracAdicionalTransporte != null) {
      map['carac_adicional_transporte'] =
          Variable<String>(caracAdicionalTransporte);
    }
    if (!nullToAbsent || caracAdicionalServico != null) {
      map['carac_adicional_servico'] = Variable<String>(caracAdicionalServico);
    }
    if (!nullToAbsent || funcionarioEmissor != null) {
      map['funcionario_emissor'] = Variable<String>(funcionarioEmissor);
    }
    if (!nullToAbsent || fluxoOrigem != null) {
      map['fluxo_origem'] = Variable<String>(fluxoOrigem);
    }
    if (!nullToAbsent || entregaTipoPeriodo != null) {
      map['entrega_tipo_periodo'] = Variable<String>(entregaTipoPeriodo);
    }
    if (!nullToAbsent || entregaDataProgramada != null) {
      map['entrega_data_programada'] =
          Variable<DateTime>(entregaDataProgramada);
    }
    if (!nullToAbsent || entregaDataInicial != null) {
      map['entrega_data_inicial'] = Variable<DateTime>(entregaDataInicial);
    }
    if (!nullToAbsent || entregaDataFinal != null) {
      map['entrega_data_final'] = Variable<DateTime>(entregaDataFinal);
    }
    if (!nullToAbsent || entregaTipoHora != null) {
      map['entrega_tipo_hora'] = Variable<String>(entregaTipoHora);
    }
    if (!nullToAbsent || entregaHoraProgramada != null) {
      map['entrega_hora_programada'] = Variable<String>(entregaHoraProgramada);
    }
    if (!nullToAbsent || entregaHoraInicial != null) {
      map['entrega_hora_inicial'] = Variable<String>(entregaHoraInicial);
    }
    if (!nullToAbsent || entregaHoraFinal != null) {
      map['entrega_hora_final'] = Variable<String>(entregaHoraFinal);
    }
    if (!nullToAbsent || municipioOrigemCalculo != null) {
      map['municipio_origem_calculo'] =
          Variable<String>(municipioOrigemCalculo);
    }
    if (!nullToAbsent || municipioDestinoCalculo != null) {
      map['municipio_destino_calculo'] =
          Variable<String>(municipioDestinoCalculo);
    }
    if (!nullToAbsent || observacoesGerais != null) {
      map['observacoes_gerais'] = Variable<String>(observacoesGerais);
    }
    if (!nullToAbsent || valorTotalServico != null) {
      map['valor_total_servico'] = Variable<double>(valorTotalServico);
    }
    if (!nullToAbsent || valorReceber != null) {
      map['valor_receber'] = Variable<double>(valorReceber);
    }
    if (!nullToAbsent || cst != null) {
      map['cst'] = Variable<String>(cst);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || aliquotaIcms != null) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || percentualReducaoBcIcms != null) {
      map['percentual_reducao_bc_icms'] =
          Variable<double>(percentualReducaoBcIcms);
    }
    if (!nullToAbsent || valorBcIcmsStRetido != null) {
      map['valor_bc_icms_st_retido'] = Variable<double>(valorBcIcmsStRetido);
    }
    if (!nullToAbsent || valorIcmsStRetido != null) {
      map['valor_icms_st_retido'] = Variable<double>(valorIcmsStRetido);
    }
    if (!nullToAbsent || aliquotaIcmsStRetido != null) {
      map['aliquota_icms_st_retido'] = Variable<double>(aliquotaIcmsStRetido);
    }
    if (!nullToAbsent || valorCreditoPresumidoIcms != null) {
      map['valor_credito_presumido_icms'] =
          Variable<double>(valorCreditoPresumidoIcms);
    }
    if (!nullToAbsent || percentualBcIcmsOutraUf != null) {
      map['percentual_bc_icms_outra_uf'] =
          Variable<double>(percentualBcIcmsOutraUf);
    }
    if (!nullToAbsent || valorBcIcmsOutraUf != null) {
      map['valor_bc_icms_outra_uf'] = Variable<double>(valorBcIcmsOutraUf);
    }
    if (!nullToAbsent || aliquotaIcmsOutraUf != null) {
      map['aliquota_icms_outra_uf'] = Variable<double>(aliquotaIcmsOutraUf);
    }
    if (!nullToAbsent || valorIcmsOutraUf != null) {
      map['valor_icms_outra_uf'] = Variable<double>(valorIcmsOutraUf);
    }
    if (!nullToAbsent || simplesNacionalIndicador != null) {
      map['simples_nacional_indicador'] =
          Variable<String>(simplesNacionalIndicador);
    }
    if (!nullToAbsent || simplesNacionalTotal != null) {
      map['simples_nacional_total'] = Variable<double>(simplesNacionalTotal);
    }
    if (!nullToAbsent || informacoesAddFisco != null) {
      map['informacoes_add_fisco'] = Variable<String>(informacoesAddFisco);
    }
    if (!nullToAbsent || valorTotalCarga != null) {
      map['valor_total_carga'] = Variable<double>(valorTotalCarga);
    }
    if (!nullToAbsent || produtoPredominante != null) {
      map['produto_predominante'] = Variable<String>(produtoPredominante);
    }
    if (!nullToAbsent || cargaOutrasCaracteristicas != null) {
      map['carga_outras_caracteristicas'] =
          Variable<String>(cargaOutrasCaracteristicas);
    }
    if (!nullToAbsent || modalVersaoLayout != null) {
      map['modal_versao_layout'] = Variable<int>(modalVersaoLayout);
    }
    if (!nullToAbsent || chaveCteSubstituido != null) {
      map['chave_cte_substituido'] = Variable<String>(chaveCteSubstituido);
    }
    return map;
  }

  factory CteCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      naturezaOperacao: serializer.fromJson<String?>(json['naturezaOperacao']),
      chaveAcesso: serializer.fromJson<String?>(json['chaveAcesso']),
      digitoChaveAcesso:
          serializer.fromJson<String?>(json['digitoChaveAcesso']),
      codigoNumerico: serializer.fromJson<String?>(json['codigoNumerico']),
      serie: serializer.fromJson<String?>(json['serie']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataHoraEmissao: serializer.fromJson<DateTime?>(json['dataHoraEmissao']),
      ufEmitente: serializer.fromJson<String?>(json['ufEmitente']),
      cfop: serializer.fromJson<int?>(json['cfop']),
      formaPagamento: serializer.fromJson<String?>(json['formaPagamento']),
      modelo: serializer.fromJson<String?>(json['modelo']),
      formatoImpressaoDacte:
          serializer.fromJson<String?>(json['formatoImpressaoDacte']),
      tipoEmissao: serializer.fromJson<String?>(json['tipoEmissao']),
      ambiente: serializer.fromJson<String?>(json['ambiente']),
      tipoCte: serializer.fromJson<String?>(json['tipoCte']),
      processoEmissao: serializer.fromJson<String?>(json['processoEmissao']),
      versaoProcessoEmissao:
          serializer.fromJson<String?>(json['versaoProcessoEmissao']),
      chaveReferenciado:
          serializer.fromJson<String?>(json['chaveReferenciado']),
      codigoMunicipioEnvio:
          serializer.fromJson<int?>(json['codigoMunicipioEnvio']),
      nomeMunicipioEnvio:
          serializer.fromJson<String?>(json['nomeMunicipioEnvio']),
      ufEnvio: serializer.fromJson<String?>(json['ufEnvio']),
      modal: serializer.fromJson<String?>(json['modal']),
      tipoServico: serializer.fromJson<String?>(json['tipoServico']),
      codigoMunicipioIniPrestacao:
          serializer.fromJson<int?>(json['codigoMunicipioIniPrestacao']),
      nomeMunicipioIniPrestacao:
          serializer.fromJson<String?>(json['nomeMunicipioIniPrestacao']),
      ufIniPrestacao: serializer.fromJson<String?>(json['ufIniPrestacao']),
      codigoMunicipioFimPrestacao:
          serializer.fromJson<int?>(json['codigoMunicipioFimPrestacao']),
      nomeMunicipioFimPrestacao:
          serializer.fromJson<String?>(json['nomeMunicipioFimPrestacao']),
      ufFimPrestacao: serializer.fromJson<String?>(json['ufFimPrestacao']),
      retira: serializer.fromJson<String?>(json['retira']),
      retiraDetalhe: serializer.fromJson<String?>(json['retiraDetalhe']),
      tomador: serializer.fromJson<String?>(json['tomador']),
      dataEntradaContingencia:
          serializer.fromJson<DateTime?>(json['dataEntradaContingencia']),
      justificativaContingencia:
          serializer.fromJson<String?>(json['justificativaContingencia']),
      caracAdicionalTransporte:
          serializer.fromJson<String?>(json['caracAdicionalTransporte']),
      caracAdicionalServico:
          serializer.fromJson<String?>(json['caracAdicionalServico']),
      funcionarioEmissor:
          serializer.fromJson<String?>(json['funcionarioEmissor']),
      fluxoOrigem: serializer.fromJson<String?>(json['fluxoOrigem']),
      entregaTipoPeriodo:
          serializer.fromJson<String?>(json['entregaTipoPeriodo']),
      entregaDataProgramada:
          serializer.fromJson<DateTime?>(json['entregaDataProgramada']),
      entregaDataInicial:
          serializer.fromJson<DateTime?>(json['entregaDataInicial']),
      entregaDataFinal:
          serializer.fromJson<DateTime?>(json['entregaDataFinal']),
      entregaTipoHora: serializer.fromJson<String?>(json['entregaTipoHora']),
      entregaHoraProgramada:
          serializer.fromJson<String?>(json['entregaHoraProgramada']),
      entregaHoraInicial:
          serializer.fromJson<String?>(json['entregaHoraInicial']),
      entregaHoraFinal: serializer.fromJson<String?>(json['entregaHoraFinal']),
      municipioOrigemCalculo:
          serializer.fromJson<String?>(json['municipioOrigemCalculo']),
      municipioDestinoCalculo:
          serializer.fromJson<String?>(json['municipioDestinoCalculo']),
      observacoesGerais:
          serializer.fromJson<String?>(json['observacoesGerais']),
      valorTotalServico:
          serializer.fromJson<double?>(json['valorTotalServico']),
      valorReceber: serializer.fromJson<double?>(json['valorReceber']),
      cst: serializer.fromJson<String?>(json['cst']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      aliquotaIcms: serializer.fromJson<double?>(json['aliquotaIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      percentualReducaoBcIcms:
          serializer.fromJson<double?>(json['percentualReducaoBcIcms']),
      valorBcIcmsStRetido:
          serializer.fromJson<double?>(json['valorBcIcmsStRetido']),
      valorIcmsStRetido:
          serializer.fromJson<double?>(json['valorIcmsStRetido']),
      aliquotaIcmsStRetido:
          serializer.fromJson<double?>(json['aliquotaIcmsStRetido']),
      valorCreditoPresumidoIcms:
          serializer.fromJson<double?>(json['valorCreditoPresumidoIcms']),
      percentualBcIcmsOutraUf:
          serializer.fromJson<double?>(json['percentualBcIcmsOutraUf']),
      valorBcIcmsOutraUf:
          serializer.fromJson<double?>(json['valorBcIcmsOutraUf']),
      aliquotaIcmsOutraUf:
          serializer.fromJson<double?>(json['aliquotaIcmsOutraUf']),
      valorIcmsOutraUf: serializer.fromJson<double?>(json['valorIcmsOutraUf']),
      simplesNacionalIndicador:
          serializer.fromJson<String?>(json['simplesNacionalIndicador']),
      simplesNacionalTotal:
          serializer.fromJson<double?>(json['simplesNacionalTotal']),
      informacoesAddFisco:
          serializer.fromJson<String?>(json['informacoesAddFisco']),
      valorTotalCarga: serializer.fromJson<double?>(json['valorTotalCarga']),
      produtoPredominante:
          serializer.fromJson<String?>(json['produtoPredominante']),
      cargaOutrasCaracteristicas:
          serializer.fromJson<String?>(json['cargaOutrasCaracteristicas']),
      modalVersaoLayout: serializer.fromJson<int?>(json['modalVersaoLayout']),
      chaveCteSubstituido:
          serializer.fromJson<String?>(json['chaveCteSubstituido']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'naturezaOperacao': serializer.toJson<String?>(naturezaOperacao),
      'chaveAcesso': serializer.toJson<String?>(chaveAcesso),
      'digitoChaveAcesso': serializer.toJson<String?>(digitoChaveAcesso),
      'codigoNumerico': serializer.toJson<String?>(codigoNumerico),
      'serie': serializer.toJson<String?>(serie),
      'numero': serializer.toJson<String?>(numero),
      'dataHoraEmissao': serializer.toJson<DateTime?>(dataHoraEmissao),
      'ufEmitente': serializer.toJson<String?>(ufEmitente),
      'cfop': serializer.toJson<int?>(cfop),
      'formaPagamento': serializer.toJson<String?>(formaPagamento),
      'modelo': serializer.toJson<String?>(modelo),
      'formatoImpressaoDacte':
          serializer.toJson<String?>(formatoImpressaoDacte),
      'tipoEmissao': serializer.toJson<String?>(tipoEmissao),
      'ambiente': serializer.toJson<String?>(ambiente),
      'tipoCte': serializer.toJson<String?>(tipoCte),
      'processoEmissao': serializer.toJson<String?>(processoEmissao),
      'versaoProcessoEmissao':
          serializer.toJson<String?>(versaoProcessoEmissao),
      'chaveReferenciado': serializer.toJson<String?>(chaveReferenciado),
      'codigoMunicipioEnvio': serializer.toJson<int?>(codigoMunicipioEnvio),
      'nomeMunicipioEnvio': serializer.toJson<String?>(nomeMunicipioEnvio),
      'ufEnvio': serializer.toJson<String?>(ufEnvio),
      'modal': serializer.toJson<String?>(modal),
      'tipoServico': serializer.toJson<String?>(tipoServico),
      'codigoMunicipioIniPrestacao':
          serializer.toJson<int?>(codigoMunicipioIniPrestacao),
      'nomeMunicipioIniPrestacao':
          serializer.toJson<String?>(nomeMunicipioIniPrestacao),
      'ufIniPrestacao': serializer.toJson<String?>(ufIniPrestacao),
      'codigoMunicipioFimPrestacao':
          serializer.toJson<int?>(codigoMunicipioFimPrestacao),
      'nomeMunicipioFimPrestacao':
          serializer.toJson<String?>(nomeMunicipioFimPrestacao),
      'ufFimPrestacao': serializer.toJson<String?>(ufFimPrestacao),
      'retira': serializer.toJson<String?>(retira),
      'retiraDetalhe': serializer.toJson<String?>(retiraDetalhe),
      'tomador': serializer.toJson<String?>(tomador),
      'dataEntradaContingencia':
          serializer.toJson<DateTime?>(dataEntradaContingencia),
      'justificativaContingencia':
          serializer.toJson<String?>(justificativaContingencia),
      'caracAdicionalTransporte':
          serializer.toJson<String?>(caracAdicionalTransporte),
      'caracAdicionalServico':
          serializer.toJson<String?>(caracAdicionalServico),
      'funcionarioEmissor': serializer.toJson<String?>(funcionarioEmissor),
      'fluxoOrigem': serializer.toJson<String?>(fluxoOrigem),
      'entregaTipoPeriodo': serializer.toJson<String?>(entregaTipoPeriodo),
      'entregaDataProgramada':
          serializer.toJson<DateTime?>(entregaDataProgramada),
      'entregaDataInicial': serializer.toJson<DateTime?>(entregaDataInicial),
      'entregaDataFinal': serializer.toJson<DateTime?>(entregaDataFinal),
      'entregaTipoHora': serializer.toJson<String?>(entregaTipoHora),
      'entregaHoraProgramada':
          serializer.toJson<String?>(entregaHoraProgramada),
      'entregaHoraInicial': serializer.toJson<String?>(entregaHoraInicial),
      'entregaHoraFinal': serializer.toJson<String?>(entregaHoraFinal),
      'municipioOrigemCalculo':
          serializer.toJson<String?>(municipioOrigemCalculo),
      'municipioDestinoCalculo':
          serializer.toJson<String?>(municipioDestinoCalculo),
      'observacoesGerais': serializer.toJson<String?>(observacoesGerais),
      'valorTotalServico': serializer.toJson<double?>(valorTotalServico),
      'valorReceber': serializer.toJson<double?>(valorReceber),
      'cst': serializer.toJson<String?>(cst),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'aliquotaIcms': serializer.toJson<double?>(aliquotaIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'percentualReducaoBcIcms':
          serializer.toJson<double?>(percentualReducaoBcIcms),
      'valorBcIcmsStRetido': serializer.toJson<double?>(valorBcIcmsStRetido),
      'valorIcmsStRetido': serializer.toJson<double?>(valorIcmsStRetido),
      'aliquotaIcmsStRetido': serializer.toJson<double?>(aliquotaIcmsStRetido),
      'valorCreditoPresumidoIcms':
          serializer.toJson<double?>(valorCreditoPresumidoIcms),
      'percentualBcIcmsOutraUf':
          serializer.toJson<double?>(percentualBcIcmsOutraUf),
      'valorBcIcmsOutraUf': serializer.toJson<double?>(valorBcIcmsOutraUf),
      'aliquotaIcmsOutraUf': serializer.toJson<double?>(aliquotaIcmsOutraUf),
      'valorIcmsOutraUf': serializer.toJson<double?>(valorIcmsOutraUf),
      'simplesNacionalIndicador':
          serializer.toJson<String?>(simplesNacionalIndicador),
      'simplesNacionalTotal': serializer.toJson<double?>(simplesNacionalTotal),
      'informacoesAddFisco': serializer.toJson<String?>(informacoesAddFisco),
      'valorTotalCarga': serializer.toJson<double?>(valorTotalCarga),
      'produtoPredominante': serializer.toJson<String?>(produtoPredominante),
      'cargaOutrasCaracteristicas':
          serializer.toJson<String?>(cargaOutrasCaracteristicas),
      'modalVersaoLayout': serializer.toJson<int?>(modalVersaoLayout),
      'chaveCteSubstituido': serializer.toJson<String?>(chaveCteSubstituido),
    };
  }

  CteCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> naturezaOperacao = const Value.absent(),
          Value<String?> chaveAcesso = const Value.absent(),
          Value<String?> digitoChaveAcesso = const Value.absent(),
          Value<String?> codigoNumerico = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataHoraEmissao = const Value.absent(),
          Value<String?> ufEmitente = const Value.absent(),
          Value<int?> cfop = const Value.absent(),
          Value<String?> formaPagamento = const Value.absent(),
          Value<String?> modelo = const Value.absent(),
          Value<String?> formatoImpressaoDacte = const Value.absent(),
          Value<String?> tipoEmissao = const Value.absent(),
          Value<String?> ambiente = const Value.absent(),
          Value<String?> tipoCte = const Value.absent(),
          Value<String?> processoEmissao = const Value.absent(),
          Value<String?> versaoProcessoEmissao = const Value.absent(),
          Value<String?> chaveReferenciado = const Value.absent(),
          Value<int?> codigoMunicipioEnvio = const Value.absent(),
          Value<String?> nomeMunicipioEnvio = const Value.absent(),
          Value<String?> ufEnvio = const Value.absent(),
          Value<String?> modal = const Value.absent(),
          Value<String?> tipoServico = const Value.absent(),
          Value<int?> codigoMunicipioIniPrestacao = const Value.absent(),
          Value<String?> nomeMunicipioIniPrestacao = const Value.absent(),
          Value<String?> ufIniPrestacao = const Value.absent(),
          Value<int?> codigoMunicipioFimPrestacao = const Value.absent(),
          Value<String?> nomeMunicipioFimPrestacao = const Value.absent(),
          Value<String?> ufFimPrestacao = const Value.absent(),
          Value<String?> retira = const Value.absent(),
          Value<String?> retiraDetalhe = const Value.absent(),
          Value<String?> tomador = const Value.absent(),
          Value<DateTime?> dataEntradaContingencia = const Value.absent(),
          Value<String?> justificativaContingencia = const Value.absent(),
          Value<String?> caracAdicionalTransporte = const Value.absent(),
          Value<String?> caracAdicionalServico = const Value.absent(),
          Value<String?> funcionarioEmissor = const Value.absent(),
          Value<String?> fluxoOrigem = const Value.absent(),
          Value<String?> entregaTipoPeriodo = const Value.absent(),
          Value<DateTime?> entregaDataProgramada = const Value.absent(),
          Value<DateTime?> entregaDataInicial = const Value.absent(),
          Value<DateTime?> entregaDataFinal = const Value.absent(),
          Value<String?> entregaTipoHora = const Value.absent(),
          Value<String?> entregaHoraProgramada = const Value.absent(),
          Value<String?> entregaHoraInicial = const Value.absent(),
          Value<String?> entregaHoraFinal = const Value.absent(),
          Value<String?> municipioOrigemCalculo = const Value.absent(),
          Value<String?> municipioDestinoCalculo = const Value.absent(),
          Value<String?> observacoesGerais = const Value.absent(),
          Value<double?> valorTotalServico = const Value.absent(),
          Value<double?> valorReceber = const Value.absent(),
          Value<String?> cst = const Value.absent(),
          Value<double?> baseCalculoIcms = const Value.absent(),
          Value<double?> aliquotaIcms = const Value.absent(),
          Value<double?> valorIcms = const Value.absent(),
          Value<double?> percentualReducaoBcIcms = const Value.absent(),
          Value<double?> valorBcIcmsStRetido = const Value.absent(),
          Value<double?> valorIcmsStRetido = const Value.absent(),
          Value<double?> aliquotaIcmsStRetido = const Value.absent(),
          Value<double?> valorCreditoPresumidoIcms = const Value.absent(),
          Value<double?> percentualBcIcmsOutraUf = const Value.absent(),
          Value<double?> valorBcIcmsOutraUf = const Value.absent(),
          Value<double?> aliquotaIcmsOutraUf = const Value.absent(),
          Value<double?> valorIcmsOutraUf = const Value.absent(),
          Value<String?> simplesNacionalIndicador = const Value.absent(),
          Value<double?> simplesNacionalTotal = const Value.absent(),
          Value<String?> informacoesAddFisco = const Value.absent(),
          Value<double?> valorTotalCarga = const Value.absent(),
          Value<String?> produtoPredominante = const Value.absent(),
          Value<String?> cargaOutrasCaracteristicas = const Value.absent(),
          Value<int?> modalVersaoLayout = const Value.absent(),
          Value<String?> chaveCteSubstituido = const Value.absent()}) =>
      CteCabecalho(
        id: id.present ? id.value : this.id,
        naturezaOperacao: naturezaOperacao.present
            ? naturezaOperacao.value
            : this.naturezaOperacao,
        chaveAcesso: chaveAcesso.present ? chaveAcesso.value : this.chaveAcesso,
        digitoChaveAcesso: digitoChaveAcesso.present
            ? digitoChaveAcesso.value
            : this.digitoChaveAcesso,
        codigoNumerico:
            codigoNumerico.present ? codigoNumerico.value : this.codigoNumerico,
        serie: serie.present ? serie.value : this.serie,
        numero: numero.present ? numero.value : this.numero,
        dataHoraEmissao: dataHoraEmissao.present
            ? dataHoraEmissao.value
            : this.dataHoraEmissao,
        ufEmitente: ufEmitente.present ? ufEmitente.value : this.ufEmitente,
        cfop: cfop.present ? cfop.value : this.cfop,
        formaPagamento:
            formaPagamento.present ? formaPagamento.value : this.formaPagamento,
        modelo: modelo.present ? modelo.value : this.modelo,
        formatoImpressaoDacte: formatoImpressaoDacte.present
            ? formatoImpressaoDacte.value
            : this.formatoImpressaoDacte,
        tipoEmissao: tipoEmissao.present ? tipoEmissao.value : this.tipoEmissao,
        ambiente: ambiente.present ? ambiente.value : this.ambiente,
        tipoCte: tipoCte.present ? tipoCte.value : this.tipoCte,
        processoEmissao: processoEmissao.present
            ? processoEmissao.value
            : this.processoEmissao,
        versaoProcessoEmissao: versaoProcessoEmissao.present
            ? versaoProcessoEmissao.value
            : this.versaoProcessoEmissao,
        chaveReferenciado: chaveReferenciado.present
            ? chaveReferenciado.value
            : this.chaveReferenciado,
        codigoMunicipioEnvio: codigoMunicipioEnvio.present
            ? codigoMunicipioEnvio.value
            : this.codigoMunicipioEnvio,
        nomeMunicipioEnvio: nomeMunicipioEnvio.present
            ? nomeMunicipioEnvio.value
            : this.nomeMunicipioEnvio,
        ufEnvio: ufEnvio.present ? ufEnvio.value : this.ufEnvio,
        modal: modal.present ? modal.value : this.modal,
        tipoServico: tipoServico.present ? tipoServico.value : this.tipoServico,
        codigoMunicipioIniPrestacao: codigoMunicipioIniPrestacao.present
            ? codigoMunicipioIniPrestacao.value
            : this.codigoMunicipioIniPrestacao,
        nomeMunicipioIniPrestacao: nomeMunicipioIniPrestacao.present
            ? nomeMunicipioIniPrestacao.value
            : this.nomeMunicipioIniPrestacao,
        ufIniPrestacao:
            ufIniPrestacao.present ? ufIniPrestacao.value : this.ufIniPrestacao,
        codigoMunicipioFimPrestacao: codigoMunicipioFimPrestacao.present
            ? codigoMunicipioFimPrestacao.value
            : this.codigoMunicipioFimPrestacao,
        nomeMunicipioFimPrestacao: nomeMunicipioFimPrestacao.present
            ? nomeMunicipioFimPrestacao.value
            : this.nomeMunicipioFimPrestacao,
        ufFimPrestacao:
            ufFimPrestacao.present ? ufFimPrestacao.value : this.ufFimPrestacao,
        retira: retira.present ? retira.value : this.retira,
        retiraDetalhe:
            retiraDetalhe.present ? retiraDetalhe.value : this.retiraDetalhe,
        tomador: tomador.present ? tomador.value : this.tomador,
        dataEntradaContingencia: dataEntradaContingencia.present
            ? dataEntradaContingencia.value
            : this.dataEntradaContingencia,
        justificativaContingencia: justificativaContingencia.present
            ? justificativaContingencia.value
            : this.justificativaContingencia,
        caracAdicionalTransporte: caracAdicionalTransporte.present
            ? caracAdicionalTransporte.value
            : this.caracAdicionalTransporte,
        caracAdicionalServico: caracAdicionalServico.present
            ? caracAdicionalServico.value
            : this.caracAdicionalServico,
        funcionarioEmissor: funcionarioEmissor.present
            ? funcionarioEmissor.value
            : this.funcionarioEmissor,
        fluxoOrigem: fluxoOrigem.present ? fluxoOrigem.value : this.fluxoOrigem,
        entregaTipoPeriodo: entregaTipoPeriodo.present
            ? entregaTipoPeriodo.value
            : this.entregaTipoPeriodo,
        entregaDataProgramada: entregaDataProgramada.present
            ? entregaDataProgramada.value
            : this.entregaDataProgramada,
        entregaDataInicial: entregaDataInicial.present
            ? entregaDataInicial.value
            : this.entregaDataInicial,
        entregaDataFinal: entregaDataFinal.present
            ? entregaDataFinal.value
            : this.entregaDataFinal,
        entregaTipoHora: entregaTipoHora.present
            ? entregaTipoHora.value
            : this.entregaTipoHora,
        entregaHoraProgramada: entregaHoraProgramada.present
            ? entregaHoraProgramada.value
            : this.entregaHoraProgramada,
        entregaHoraInicial: entregaHoraInicial.present
            ? entregaHoraInicial.value
            : this.entregaHoraInicial,
        entregaHoraFinal: entregaHoraFinal.present
            ? entregaHoraFinal.value
            : this.entregaHoraFinal,
        municipioOrigemCalculo: municipioOrigemCalculo.present
            ? municipioOrigemCalculo.value
            : this.municipioOrigemCalculo,
        municipioDestinoCalculo: municipioDestinoCalculo.present
            ? municipioDestinoCalculo.value
            : this.municipioDestinoCalculo,
        observacoesGerais: observacoesGerais.present
            ? observacoesGerais.value
            : this.observacoesGerais,
        valorTotalServico: valorTotalServico.present
            ? valorTotalServico.value
            : this.valorTotalServico,
        valorReceber:
            valorReceber.present ? valorReceber.value : this.valorReceber,
        cst: cst.present ? cst.value : this.cst,
        baseCalculoIcms: baseCalculoIcms.present
            ? baseCalculoIcms.value
            : this.baseCalculoIcms,
        aliquotaIcms:
            aliquotaIcms.present ? aliquotaIcms.value : this.aliquotaIcms,
        valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
        percentualReducaoBcIcms: percentualReducaoBcIcms.present
            ? percentualReducaoBcIcms.value
            : this.percentualReducaoBcIcms,
        valorBcIcmsStRetido: valorBcIcmsStRetido.present
            ? valorBcIcmsStRetido.value
            : this.valorBcIcmsStRetido,
        valorIcmsStRetido: valorIcmsStRetido.present
            ? valorIcmsStRetido.value
            : this.valorIcmsStRetido,
        aliquotaIcmsStRetido: aliquotaIcmsStRetido.present
            ? aliquotaIcmsStRetido.value
            : this.aliquotaIcmsStRetido,
        valorCreditoPresumidoIcms: valorCreditoPresumidoIcms.present
            ? valorCreditoPresumidoIcms.value
            : this.valorCreditoPresumidoIcms,
        percentualBcIcmsOutraUf: percentualBcIcmsOutraUf.present
            ? percentualBcIcmsOutraUf.value
            : this.percentualBcIcmsOutraUf,
        valorBcIcmsOutraUf: valorBcIcmsOutraUf.present
            ? valorBcIcmsOutraUf.value
            : this.valorBcIcmsOutraUf,
        aliquotaIcmsOutraUf: aliquotaIcmsOutraUf.present
            ? aliquotaIcmsOutraUf.value
            : this.aliquotaIcmsOutraUf,
        valorIcmsOutraUf: valorIcmsOutraUf.present
            ? valorIcmsOutraUf.value
            : this.valorIcmsOutraUf,
        simplesNacionalIndicador: simplesNacionalIndicador.present
            ? simplesNacionalIndicador.value
            : this.simplesNacionalIndicador,
        simplesNacionalTotal: simplesNacionalTotal.present
            ? simplesNacionalTotal.value
            : this.simplesNacionalTotal,
        informacoesAddFisco: informacoesAddFisco.present
            ? informacoesAddFisco.value
            : this.informacoesAddFisco,
        valorTotalCarga: valorTotalCarga.present
            ? valorTotalCarga.value
            : this.valorTotalCarga,
        produtoPredominante: produtoPredominante.present
            ? produtoPredominante.value
            : this.produtoPredominante,
        cargaOutrasCaracteristicas: cargaOutrasCaracteristicas.present
            ? cargaOutrasCaracteristicas.value
            : this.cargaOutrasCaracteristicas,
        modalVersaoLayout: modalVersaoLayout.present
            ? modalVersaoLayout.value
            : this.modalVersaoLayout,
        chaveCteSubstituido: chaveCteSubstituido.present
            ? chaveCteSubstituido.value
            : this.chaveCteSubstituido,
      );
  @override
  String toString() {
    return (StringBuffer('CteCabecalho(')
          ..write('id: $id, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('cfop: $cfop, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('modelo: $modelo, ')
          ..write('formatoImpressaoDacte: $formatoImpressaoDacte, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('ambiente: $ambiente, ')
          ..write('tipoCte: $tipoCte, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('chaveReferenciado: $chaveReferenciado, ')
          ..write('codigoMunicipioEnvio: $codigoMunicipioEnvio, ')
          ..write('nomeMunicipioEnvio: $nomeMunicipioEnvio, ')
          ..write('ufEnvio: $ufEnvio, ')
          ..write('modal: $modal, ')
          ..write('tipoServico: $tipoServico, ')
          ..write('codigoMunicipioIniPrestacao: $codigoMunicipioIniPrestacao, ')
          ..write('nomeMunicipioIniPrestacao: $nomeMunicipioIniPrestacao, ')
          ..write('ufIniPrestacao: $ufIniPrestacao, ')
          ..write('codigoMunicipioFimPrestacao: $codigoMunicipioFimPrestacao, ')
          ..write('nomeMunicipioFimPrestacao: $nomeMunicipioFimPrestacao, ')
          ..write('ufFimPrestacao: $ufFimPrestacao, ')
          ..write('retira: $retira, ')
          ..write('retiraDetalhe: $retiraDetalhe, ')
          ..write('tomador: $tomador, ')
          ..write('dataEntradaContingencia: $dataEntradaContingencia, ')
          ..write('justificativaContingencia: $justificativaContingencia, ')
          ..write('caracAdicionalTransporte: $caracAdicionalTransporte, ')
          ..write('caracAdicionalServico: $caracAdicionalServico, ')
          ..write('funcionarioEmissor: $funcionarioEmissor, ')
          ..write('fluxoOrigem: $fluxoOrigem, ')
          ..write('entregaTipoPeriodo: $entregaTipoPeriodo, ')
          ..write('entregaDataProgramada: $entregaDataProgramada, ')
          ..write('entregaDataInicial: $entregaDataInicial, ')
          ..write('entregaDataFinal: $entregaDataFinal, ')
          ..write('entregaTipoHora: $entregaTipoHora, ')
          ..write('entregaHoraProgramada: $entregaHoraProgramada, ')
          ..write('entregaHoraInicial: $entregaHoraInicial, ')
          ..write('entregaHoraFinal: $entregaHoraFinal, ')
          ..write('municipioOrigemCalculo: $municipioOrigemCalculo, ')
          ..write('municipioDestinoCalculo: $municipioDestinoCalculo, ')
          ..write('observacoesGerais: $observacoesGerais, ')
          ..write('valorTotalServico: $valorTotalServico, ')
          ..write('valorReceber: $valorReceber, ')
          ..write('cst: $cst, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('percentualReducaoBcIcms: $percentualReducaoBcIcms, ')
          ..write('valorBcIcmsStRetido: $valorBcIcmsStRetido, ')
          ..write('valorIcmsStRetido: $valorIcmsStRetido, ')
          ..write('aliquotaIcmsStRetido: $aliquotaIcmsStRetido, ')
          ..write('valorCreditoPresumidoIcms: $valorCreditoPresumidoIcms, ')
          ..write('percentualBcIcmsOutraUf: $percentualBcIcmsOutraUf, ')
          ..write('valorBcIcmsOutraUf: $valorBcIcmsOutraUf, ')
          ..write('aliquotaIcmsOutraUf: $aliquotaIcmsOutraUf, ')
          ..write('valorIcmsOutraUf: $valorIcmsOutraUf, ')
          ..write('simplesNacionalIndicador: $simplesNacionalIndicador, ')
          ..write('simplesNacionalTotal: $simplesNacionalTotal, ')
          ..write('informacoesAddFisco: $informacoesAddFisco, ')
          ..write('valorTotalCarga: $valorTotalCarga, ')
          ..write('produtoPredominante: $produtoPredominante, ')
          ..write('cargaOutrasCaracteristicas: $cargaOutrasCaracteristicas, ')
          ..write('modalVersaoLayout: $modalVersaoLayout, ')
          ..write('chaveCteSubstituido: $chaveCteSubstituido')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        naturezaOperacao,
        chaveAcesso,
        digitoChaveAcesso,
        codigoNumerico,
        serie,
        numero,
        dataHoraEmissao,
        ufEmitente,
        cfop,
        formaPagamento,
        modelo,
        formatoImpressaoDacte,
        tipoEmissao,
        ambiente,
        tipoCte,
        processoEmissao,
        versaoProcessoEmissao,
        chaveReferenciado,
        codigoMunicipioEnvio,
        nomeMunicipioEnvio,
        ufEnvio,
        modal,
        tipoServico,
        codigoMunicipioIniPrestacao,
        nomeMunicipioIniPrestacao,
        ufIniPrestacao,
        codigoMunicipioFimPrestacao,
        nomeMunicipioFimPrestacao,
        ufFimPrestacao,
        retira,
        retiraDetalhe,
        tomador,
        dataEntradaContingencia,
        justificativaContingencia,
        caracAdicionalTransporte,
        caracAdicionalServico,
        funcionarioEmissor,
        fluxoOrigem,
        entregaTipoPeriodo,
        entregaDataProgramada,
        entregaDataInicial,
        entregaDataFinal,
        entregaTipoHora,
        entregaHoraProgramada,
        entregaHoraInicial,
        entregaHoraFinal,
        municipioOrigemCalculo,
        municipioDestinoCalculo,
        observacoesGerais,
        valorTotalServico,
        valorReceber,
        cst,
        baseCalculoIcms,
        aliquotaIcms,
        valorIcms,
        percentualReducaoBcIcms,
        valorBcIcmsStRetido,
        valorIcmsStRetido,
        aliquotaIcmsStRetido,
        valorCreditoPresumidoIcms,
        percentualBcIcmsOutraUf,
        valorBcIcmsOutraUf,
        aliquotaIcmsOutraUf,
        valorIcmsOutraUf,
        simplesNacionalIndicador,
        simplesNacionalTotal,
        informacoesAddFisco,
        valorTotalCarga,
        produtoPredominante,
        cargaOutrasCaracteristicas,
        modalVersaoLayout,
        chaveCteSubstituido
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteCabecalho &&
          other.id == this.id &&
          other.naturezaOperacao == this.naturezaOperacao &&
          other.chaveAcesso == this.chaveAcesso &&
          other.digitoChaveAcesso == this.digitoChaveAcesso &&
          other.codigoNumerico == this.codigoNumerico &&
          other.serie == this.serie &&
          other.numero == this.numero &&
          other.dataHoraEmissao == this.dataHoraEmissao &&
          other.ufEmitente == this.ufEmitente &&
          other.cfop == this.cfop &&
          other.formaPagamento == this.formaPagamento &&
          other.modelo == this.modelo &&
          other.formatoImpressaoDacte == this.formatoImpressaoDacte &&
          other.tipoEmissao == this.tipoEmissao &&
          other.ambiente == this.ambiente &&
          other.tipoCte == this.tipoCte &&
          other.processoEmissao == this.processoEmissao &&
          other.versaoProcessoEmissao == this.versaoProcessoEmissao &&
          other.chaveReferenciado == this.chaveReferenciado &&
          other.codigoMunicipioEnvio == this.codigoMunicipioEnvio &&
          other.nomeMunicipioEnvio == this.nomeMunicipioEnvio &&
          other.ufEnvio == this.ufEnvio &&
          other.modal == this.modal &&
          other.tipoServico == this.tipoServico &&
          other.codigoMunicipioIniPrestacao ==
              this.codigoMunicipioIniPrestacao &&
          other.nomeMunicipioIniPrestacao == this.nomeMunicipioIniPrestacao &&
          other.ufIniPrestacao == this.ufIniPrestacao &&
          other.codigoMunicipioFimPrestacao ==
              this.codigoMunicipioFimPrestacao &&
          other.nomeMunicipioFimPrestacao == this.nomeMunicipioFimPrestacao &&
          other.ufFimPrestacao == this.ufFimPrestacao &&
          other.retira == this.retira &&
          other.retiraDetalhe == this.retiraDetalhe &&
          other.tomador == this.tomador &&
          other.dataEntradaContingencia == this.dataEntradaContingencia &&
          other.justificativaContingencia == this.justificativaContingencia &&
          other.caracAdicionalTransporte == this.caracAdicionalTransporte &&
          other.caracAdicionalServico == this.caracAdicionalServico &&
          other.funcionarioEmissor == this.funcionarioEmissor &&
          other.fluxoOrigem == this.fluxoOrigem &&
          other.entregaTipoPeriodo == this.entregaTipoPeriodo &&
          other.entregaDataProgramada == this.entregaDataProgramada &&
          other.entregaDataInicial == this.entregaDataInicial &&
          other.entregaDataFinal == this.entregaDataFinal &&
          other.entregaTipoHora == this.entregaTipoHora &&
          other.entregaHoraProgramada == this.entregaHoraProgramada &&
          other.entregaHoraInicial == this.entregaHoraInicial &&
          other.entregaHoraFinal == this.entregaHoraFinal &&
          other.municipioOrigemCalculo == this.municipioOrigemCalculo &&
          other.municipioDestinoCalculo == this.municipioDestinoCalculo &&
          other.observacoesGerais == this.observacoesGerais &&
          other.valorTotalServico == this.valorTotalServico &&
          other.valorReceber == this.valorReceber &&
          other.cst == this.cst &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.aliquotaIcms == this.aliquotaIcms &&
          other.valorIcms == this.valorIcms &&
          other.percentualReducaoBcIcms == this.percentualReducaoBcIcms &&
          other.valorBcIcmsStRetido == this.valorBcIcmsStRetido &&
          other.valorIcmsStRetido == this.valorIcmsStRetido &&
          other.aliquotaIcmsStRetido == this.aliquotaIcmsStRetido &&
          other.valorCreditoPresumidoIcms == this.valorCreditoPresumidoIcms &&
          other.percentualBcIcmsOutraUf == this.percentualBcIcmsOutraUf &&
          other.valorBcIcmsOutraUf == this.valorBcIcmsOutraUf &&
          other.aliquotaIcmsOutraUf == this.aliquotaIcmsOutraUf &&
          other.valorIcmsOutraUf == this.valorIcmsOutraUf &&
          other.simplesNacionalIndicador == this.simplesNacionalIndicador &&
          other.simplesNacionalTotal == this.simplesNacionalTotal &&
          other.informacoesAddFisco == this.informacoesAddFisco &&
          other.valorTotalCarga == this.valorTotalCarga &&
          other.produtoPredominante == this.produtoPredominante &&
          other.cargaOutrasCaracteristicas == this.cargaOutrasCaracteristicas &&
          other.modalVersaoLayout == this.modalVersaoLayout &&
          other.chaveCteSubstituido == this.chaveCteSubstituido);
}

class CteCabecalhosCompanion extends UpdateCompanion<CteCabecalho> {
  final Value<int?> id;
  final Value<String?> naturezaOperacao;
  final Value<String?> chaveAcesso;
  final Value<String?> digitoChaveAcesso;
  final Value<String?> codigoNumerico;
  final Value<String?> serie;
  final Value<String?> numero;
  final Value<DateTime?> dataHoraEmissao;
  final Value<String?> ufEmitente;
  final Value<int?> cfop;
  final Value<String?> formaPagamento;
  final Value<String?> modelo;
  final Value<String?> formatoImpressaoDacte;
  final Value<String?> tipoEmissao;
  final Value<String?> ambiente;
  final Value<String?> tipoCte;
  final Value<String?> processoEmissao;
  final Value<String?> versaoProcessoEmissao;
  final Value<String?> chaveReferenciado;
  final Value<int?> codigoMunicipioEnvio;
  final Value<String?> nomeMunicipioEnvio;
  final Value<String?> ufEnvio;
  final Value<String?> modal;
  final Value<String?> tipoServico;
  final Value<int?> codigoMunicipioIniPrestacao;
  final Value<String?> nomeMunicipioIniPrestacao;
  final Value<String?> ufIniPrestacao;
  final Value<int?> codigoMunicipioFimPrestacao;
  final Value<String?> nomeMunicipioFimPrestacao;
  final Value<String?> ufFimPrestacao;
  final Value<String?> retira;
  final Value<String?> retiraDetalhe;
  final Value<String?> tomador;
  final Value<DateTime?> dataEntradaContingencia;
  final Value<String?> justificativaContingencia;
  final Value<String?> caracAdicionalTransporte;
  final Value<String?> caracAdicionalServico;
  final Value<String?> funcionarioEmissor;
  final Value<String?> fluxoOrigem;
  final Value<String?> entregaTipoPeriodo;
  final Value<DateTime?> entregaDataProgramada;
  final Value<DateTime?> entregaDataInicial;
  final Value<DateTime?> entregaDataFinal;
  final Value<String?> entregaTipoHora;
  final Value<String?> entregaHoraProgramada;
  final Value<String?> entregaHoraInicial;
  final Value<String?> entregaHoraFinal;
  final Value<String?> municipioOrigemCalculo;
  final Value<String?> municipioDestinoCalculo;
  final Value<String?> observacoesGerais;
  final Value<double?> valorTotalServico;
  final Value<double?> valorReceber;
  final Value<String?> cst;
  final Value<double?> baseCalculoIcms;
  final Value<double?> aliquotaIcms;
  final Value<double?> valorIcms;
  final Value<double?> percentualReducaoBcIcms;
  final Value<double?> valorBcIcmsStRetido;
  final Value<double?> valorIcmsStRetido;
  final Value<double?> aliquotaIcmsStRetido;
  final Value<double?> valorCreditoPresumidoIcms;
  final Value<double?> percentualBcIcmsOutraUf;
  final Value<double?> valorBcIcmsOutraUf;
  final Value<double?> aliquotaIcmsOutraUf;
  final Value<double?> valorIcmsOutraUf;
  final Value<String?> simplesNacionalIndicador;
  final Value<double?> simplesNacionalTotal;
  final Value<String?> informacoesAddFisco;
  final Value<double?> valorTotalCarga;
  final Value<String?> produtoPredominante;
  final Value<String?> cargaOutrasCaracteristicas;
  final Value<int?> modalVersaoLayout;
  final Value<String?> chaveCteSubstituido;
  const CteCabecalhosCompanion({
    this.id = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.cfop = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.modelo = const Value.absent(),
    this.formatoImpressaoDacte = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.tipoCte = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.chaveReferenciado = const Value.absent(),
    this.codigoMunicipioEnvio = const Value.absent(),
    this.nomeMunicipioEnvio = const Value.absent(),
    this.ufEnvio = const Value.absent(),
    this.modal = const Value.absent(),
    this.tipoServico = const Value.absent(),
    this.codigoMunicipioIniPrestacao = const Value.absent(),
    this.nomeMunicipioIniPrestacao = const Value.absent(),
    this.ufIniPrestacao = const Value.absent(),
    this.codigoMunicipioFimPrestacao = const Value.absent(),
    this.nomeMunicipioFimPrestacao = const Value.absent(),
    this.ufFimPrestacao = const Value.absent(),
    this.retira = const Value.absent(),
    this.retiraDetalhe = const Value.absent(),
    this.tomador = const Value.absent(),
    this.dataEntradaContingencia = const Value.absent(),
    this.justificativaContingencia = const Value.absent(),
    this.caracAdicionalTransporte = const Value.absent(),
    this.caracAdicionalServico = const Value.absent(),
    this.funcionarioEmissor = const Value.absent(),
    this.fluxoOrigem = const Value.absent(),
    this.entregaTipoPeriodo = const Value.absent(),
    this.entregaDataProgramada = const Value.absent(),
    this.entregaDataInicial = const Value.absent(),
    this.entregaDataFinal = const Value.absent(),
    this.entregaTipoHora = const Value.absent(),
    this.entregaHoraProgramada = const Value.absent(),
    this.entregaHoraInicial = const Value.absent(),
    this.entregaHoraFinal = const Value.absent(),
    this.municipioOrigemCalculo = const Value.absent(),
    this.municipioDestinoCalculo = const Value.absent(),
    this.observacoesGerais = const Value.absent(),
    this.valorTotalServico = const Value.absent(),
    this.valorReceber = const Value.absent(),
    this.cst = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.percentualReducaoBcIcms = const Value.absent(),
    this.valorBcIcmsStRetido = const Value.absent(),
    this.valorIcmsStRetido = const Value.absent(),
    this.aliquotaIcmsStRetido = const Value.absent(),
    this.valorCreditoPresumidoIcms = const Value.absent(),
    this.percentualBcIcmsOutraUf = const Value.absent(),
    this.valorBcIcmsOutraUf = const Value.absent(),
    this.aliquotaIcmsOutraUf = const Value.absent(),
    this.valorIcmsOutraUf = const Value.absent(),
    this.simplesNacionalIndicador = const Value.absent(),
    this.simplesNacionalTotal = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
    this.valorTotalCarga = const Value.absent(),
    this.produtoPredominante = const Value.absent(),
    this.cargaOutrasCaracteristicas = const Value.absent(),
    this.modalVersaoLayout = const Value.absent(),
    this.chaveCteSubstituido = const Value.absent(),
  });
  CteCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.cfop = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.modelo = const Value.absent(),
    this.formatoImpressaoDacte = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.tipoCte = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.chaveReferenciado = const Value.absent(),
    this.codigoMunicipioEnvio = const Value.absent(),
    this.nomeMunicipioEnvio = const Value.absent(),
    this.ufEnvio = const Value.absent(),
    this.modal = const Value.absent(),
    this.tipoServico = const Value.absent(),
    this.codigoMunicipioIniPrestacao = const Value.absent(),
    this.nomeMunicipioIniPrestacao = const Value.absent(),
    this.ufIniPrestacao = const Value.absent(),
    this.codigoMunicipioFimPrestacao = const Value.absent(),
    this.nomeMunicipioFimPrestacao = const Value.absent(),
    this.ufFimPrestacao = const Value.absent(),
    this.retira = const Value.absent(),
    this.retiraDetalhe = const Value.absent(),
    this.tomador = const Value.absent(),
    this.dataEntradaContingencia = const Value.absent(),
    this.justificativaContingencia = const Value.absent(),
    this.caracAdicionalTransporte = const Value.absent(),
    this.caracAdicionalServico = const Value.absent(),
    this.funcionarioEmissor = const Value.absent(),
    this.fluxoOrigem = const Value.absent(),
    this.entregaTipoPeriodo = const Value.absent(),
    this.entregaDataProgramada = const Value.absent(),
    this.entregaDataInicial = const Value.absent(),
    this.entregaDataFinal = const Value.absent(),
    this.entregaTipoHora = const Value.absent(),
    this.entregaHoraProgramada = const Value.absent(),
    this.entregaHoraInicial = const Value.absent(),
    this.entregaHoraFinal = const Value.absent(),
    this.municipioOrigemCalculo = const Value.absent(),
    this.municipioDestinoCalculo = const Value.absent(),
    this.observacoesGerais = const Value.absent(),
    this.valorTotalServico = const Value.absent(),
    this.valorReceber = const Value.absent(),
    this.cst = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.percentualReducaoBcIcms = const Value.absent(),
    this.valorBcIcmsStRetido = const Value.absent(),
    this.valorIcmsStRetido = const Value.absent(),
    this.aliquotaIcmsStRetido = const Value.absent(),
    this.valorCreditoPresumidoIcms = const Value.absent(),
    this.percentualBcIcmsOutraUf = const Value.absent(),
    this.valorBcIcmsOutraUf = const Value.absent(),
    this.aliquotaIcmsOutraUf = const Value.absent(),
    this.valorIcmsOutraUf = const Value.absent(),
    this.simplesNacionalIndicador = const Value.absent(),
    this.simplesNacionalTotal = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
    this.valorTotalCarga = const Value.absent(),
    this.produtoPredominante = const Value.absent(),
    this.cargaOutrasCaracteristicas = const Value.absent(),
    this.modalVersaoLayout = const Value.absent(),
    this.chaveCteSubstituido = const Value.absent(),
  });
  static Insertable<CteCabecalho> custom({
    Expression<int>? id,
    Expression<String>? naturezaOperacao,
    Expression<String>? chaveAcesso,
    Expression<String>? digitoChaveAcesso,
    Expression<String>? codigoNumerico,
    Expression<String>? serie,
    Expression<String>? numero,
    Expression<DateTime>? dataHoraEmissao,
    Expression<String>? ufEmitente,
    Expression<int>? cfop,
    Expression<String>? formaPagamento,
    Expression<String>? modelo,
    Expression<String>? formatoImpressaoDacte,
    Expression<String>? tipoEmissao,
    Expression<String>? ambiente,
    Expression<String>? tipoCte,
    Expression<String>? processoEmissao,
    Expression<String>? versaoProcessoEmissao,
    Expression<String>? chaveReferenciado,
    Expression<int>? codigoMunicipioEnvio,
    Expression<String>? nomeMunicipioEnvio,
    Expression<String>? ufEnvio,
    Expression<String>? modal,
    Expression<String>? tipoServico,
    Expression<int>? codigoMunicipioIniPrestacao,
    Expression<String>? nomeMunicipioIniPrestacao,
    Expression<String>? ufIniPrestacao,
    Expression<int>? codigoMunicipioFimPrestacao,
    Expression<String>? nomeMunicipioFimPrestacao,
    Expression<String>? ufFimPrestacao,
    Expression<String>? retira,
    Expression<String>? retiraDetalhe,
    Expression<String>? tomador,
    Expression<DateTime>? dataEntradaContingencia,
    Expression<String>? justificativaContingencia,
    Expression<String>? caracAdicionalTransporte,
    Expression<String>? caracAdicionalServico,
    Expression<String>? funcionarioEmissor,
    Expression<String>? fluxoOrigem,
    Expression<String>? entregaTipoPeriodo,
    Expression<DateTime>? entregaDataProgramada,
    Expression<DateTime>? entregaDataInicial,
    Expression<DateTime>? entregaDataFinal,
    Expression<String>? entregaTipoHora,
    Expression<String>? entregaHoraProgramada,
    Expression<String>? entregaHoraInicial,
    Expression<String>? entregaHoraFinal,
    Expression<String>? municipioOrigemCalculo,
    Expression<String>? municipioDestinoCalculo,
    Expression<String>? observacoesGerais,
    Expression<double>? valorTotalServico,
    Expression<double>? valorReceber,
    Expression<String>? cst,
    Expression<double>? baseCalculoIcms,
    Expression<double>? aliquotaIcms,
    Expression<double>? valorIcms,
    Expression<double>? percentualReducaoBcIcms,
    Expression<double>? valorBcIcmsStRetido,
    Expression<double>? valorIcmsStRetido,
    Expression<double>? aliquotaIcmsStRetido,
    Expression<double>? valorCreditoPresumidoIcms,
    Expression<double>? percentualBcIcmsOutraUf,
    Expression<double>? valorBcIcmsOutraUf,
    Expression<double>? aliquotaIcmsOutraUf,
    Expression<double>? valorIcmsOutraUf,
    Expression<String>? simplesNacionalIndicador,
    Expression<double>? simplesNacionalTotal,
    Expression<String>? informacoesAddFisco,
    Expression<double>? valorTotalCarga,
    Expression<String>? produtoPredominante,
    Expression<String>? cargaOutrasCaracteristicas,
    Expression<int>? modalVersaoLayout,
    Expression<String>? chaveCteSubstituido,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (naturezaOperacao != null) 'natureza_operacao': naturezaOperacao,
      if (chaveAcesso != null) 'chave_acesso': chaveAcesso,
      if (digitoChaveAcesso != null) 'digito_chave_acesso': digitoChaveAcesso,
      if (codigoNumerico != null) 'codigo_numerico': codigoNumerico,
      if (serie != null) 'serie': serie,
      if (numero != null) 'numero': numero,
      if (dataHoraEmissao != null) 'data_hora_emissao': dataHoraEmissao,
      if (ufEmitente != null) 'uf_emitente': ufEmitente,
      if (cfop != null) 'cfop': cfop,
      if (formaPagamento != null) 'forma_pagamento': formaPagamento,
      if (modelo != null) 'modelo': modelo,
      if (formatoImpressaoDacte != null)
        'formato_impressao_dacte': formatoImpressaoDacte,
      if (tipoEmissao != null) 'tipo_emissao': tipoEmissao,
      if (ambiente != null) 'ambiente': ambiente,
      if (tipoCte != null) 'tipo_cte': tipoCte,
      if (processoEmissao != null) 'processo_emissao': processoEmissao,
      if (versaoProcessoEmissao != null)
        'versao_processo_emissao': versaoProcessoEmissao,
      if (chaveReferenciado != null) 'chave_referenciado': chaveReferenciado,
      if (codigoMunicipioEnvio != null)
        'codigo_municipio_envio': codigoMunicipioEnvio,
      if (nomeMunicipioEnvio != null)
        'nome_municipio_envio': nomeMunicipioEnvio,
      if (ufEnvio != null) 'uf_envio': ufEnvio,
      if (modal != null) 'modal': modal,
      if (tipoServico != null) 'tipo_servico': tipoServico,
      if (codigoMunicipioIniPrestacao != null)
        'codigo_municipio_ini_prestacao': codigoMunicipioIniPrestacao,
      if (nomeMunicipioIniPrestacao != null)
        'nome_municipio_ini_prestacao': nomeMunicipioIniPrestacao,
      if (ufIniPrestacao != null) 'uf_ini_prestacao': ufIniPrestacao,
      if (codigoMunicipioFimPrestacao != null)
        'codigo_municipio_fim_prestacao': codigoMunicipioFimPrestacao,
      if (nomeMunicipioFimPrestacao != null)
        'nome_municipio_fim_prestacao': nomeMunicipioFimPrestacao,
      if (ufFimPrestacao != null) 'uf_fim_prestacao': ufFimPrestacao,
      if (retira != null) 'retira': retira,
      if (retiraDetalhe != null) 'retira_detalhe': retiraDetalhe,
      if (tomador != null) 'tomador': tomador,
      if (dataEntradaContingencia != null)
        'data_entrada_contingencia': dataEntradaContingencia,
      if (justificativaContingencia != null)
        'justificativa_contingencia': justificativaContingencia,
      if (caracAdicionalTransporte != null)
        'carac_adicional_transporte': caracAdicionalTransporte,
      if (caracAdicionalServico != null)
        'carac_adicional_servico': caracAdicionalServico,
      if (funcionarioEmissor != null) 'funcionario_emissor': funcionarioEmissor,
      if (fluxoOrigem != null) 'fluxo_origem': fluxoOrigem,
      if (entregaTipoPeriodo != null)
        'entrega_tipo_periodo': entregaTipoPeriodo,
      if (entregaDataProgramada != null)
        'entrega_data_programada': entregaDataProgramada,
      if (entregaDataInicial != null)
        'entrega_data_inicial': entregaDataInicial,
      if (entregaDataFinal != null) 'entrega_data_final': entregaDataFinal,
      if (entregaTipoHora != null) 'entrega_tipo_hora': entregaTipoHora,
      if (entregaHoraProgramada != null)
        'entrega_hora_programada': entregaHoraProgramada,
      if (entregaHoraInicial != null)
        'entrega_hora_inicial': entregaHoraInicial,
      if (entregaHoraFinal != null) 'entrega_hora_final': entregaHoraFinal,
      if (municipioOrigemCalculo != null)
        'municipio_origem_calculo': municipioOrigemCalculo,
      if (municipioDestinoCalculo != null)
        'municipio_destino_calculo': municipioDestinoCalculo,
      if (observacoesGerais != null) 'observacoes_gerais': observacoesGerais,
      if (valorTotalServico != null) 'valor_total_servico': valorTotalServico,
      if (valorReceber != null) 'valor_receber': valorReceber,
      if (cst != null) 'cst': cst,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (aliquotaIcms != null) 'aliquota_icms': aliquotaIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (percentualReducaoBcIcms != null)
        'percentual_reducao_bc_icms': percentualReducaoBcIcms,
      if (valorBcIcmsStRetido != null)
        'valor_bc_icms_st_retido': valorBcIcmsStRetido,
      if (valorIcmsStRetido != null) 'valor_icms_st_retido': valorIcmsStRetido,
      if (aliquotaIcmsStRetido != null)
        'aliquota_icms_st_retido': aliquotaIcmsStRetido,
      if (valorCreditoPresumidoIcms != null)
        'valor_credito_presumido_icms': valorCreditoPresumidoIcms,
      if (percentualBcIcmsOutraUf != null)
        'percentual_bc_icms_outra_uf': percentualBcIcmsOutraUf,
      if (valorBcIcmsOutraUf != null)
        'valor_bc_icms_outra_uf': valorBcIcmsOutraUf,
      if (aliquotaIcmsOutraUf != null)
        'aliquota_icms_outra_uf': aliquotaIcmsOutraUf,
      if (valorIcmsOutraUf != null) 'valor_icms_outra_uf': valorIcmsOutraUf,
      if (simplesNacionalIndicador != null)
        'simples_nacional_indicador': simplesNacionalIndicador,
      if (simplesNacionalTotal != null)
        'simples_nacional_total': simplesNacionalTotal,
      if (informacoesAddFisco != null)
        'informacoes_add_fisco': informacoesAddFisco,
      if (valorTotalCarga != null) 'valor_total_carga': valorTotalCarga,
      if (produtoPredominante != null)
        'produto_predominante': produtoPredominante,
      if (cargaOutrasCaracteristicas != null)
        'carga_outras_caracteristicas': cargaOutrasCaracteristicas,
      if (modalVersaoLayout != null) 'modal_versao_layout': modalVersaoLayout,
      if (chaveCteSubstituido != null)
        'chave_cte_substituido': chaveCteSubstituido,
    });
  }

  CteCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? naturezaOperacao,
      Value<String?>? chaveAcesso,
      Value<String?>? digitoChaveAcesso,
      Value<String?>? codigoNumerico,
      Value<String?>? serie,
      Value<String?>? numero,
      Value<DateTime?>? dataHoraEmissao,
      Value<String?>? ufEmitente,
      Value<int?>? cfop,
      Value<String?>? formaPagamento,
      Value<String?>? modelo,
      Value<String?>? formatoImpressaoDacte,
      Value<String?>? tipoEmissao,
      Value<String?>? ambiente,
      Value<String?>? tipoCte,
      Value<String?>? processoEmissao,
      Value<String?>? versaoProcessoEmissao,
      Value<String?>? chaveReferenciado,
      Value<int?>? codigoMunicipioEnvio,
      Value<String?>? nomeMunicipioEnvio,
      Value<String?>? ufEnvio,
      Value<String?>? modal,
      Value<String?>? tipoServico,
      Value<int?>? codigoMunicipioIniPrestacao,
      Value<String?>? nomeMunicipioIniPrestacao,
      Value<String?>? ufIniPrestacao,
      Value<int?>? codigoMunicipioFimPrestacao,
      Value<String?>? nomeMunicipioFimPrestacao,
      Value<String?>? ufFimPrestacao,
      Value<String?>? retira,
      Value<String?>? retiraDetalhe,
      Value<String?>? tomador,
      Value<DateTime?>? dataEntradaContingencia,
      Value<String?>? justificativaContingencia,
      Value<String?>? caracAdicionalTransporte,
      Value<String?>? caracAdicionalServico,
      Value<String?>? funcionarioEmissor,
      Value<String?>? fluxoOrigem,
      Value<String?>? entregaTipoPeriodo,
      Value<DateTime?>? entregaDataProgramada,
      Value<DateTime?>? entregaDataInicial,
      Value<DateTime?>? entregaDataFinal,
      Value<String?>? entregaTipoHora,
      Value<String?>? entregaHoraProgramada,
      Value<String?>? entregaHoraInicial,
      Value<String?>? entregaHoraFinal,
      Value<String?>? municipioOrigemCalculo,
      Value<String?>? municipioDestinoCalculo,
      Value<String?>? observacoesGerais,
      Value<double?>? valorTotalServico,
      Value<double?>? valorReceber,
      Value<String?>? cst,
      Value<double?>? baseCalculoIcms,
      Value<double?>? aliquotaIcms,
      Value<double?>? valorIcms,
      Value<double?>? percentualReducaoBcIcms,
      Value<double?>? valorBcIcmsStRetido,
      Value<double?>? valorIcmsStRetido,
      Value<double?>? aliquotaIcmsStRetido,
      Value<double?>? valorCreditoPresumidoIcms,
      Value<double?>? percentualBcIcmsOutraUf,
      Value<double?>? valorBcIcmsOutraUf,
      Value<double?>? aliquotaIcmsOutraUf,
      Value<double?>? valorIcmsOutraUf,
      Value<String?>? simplesNacionalIndicador,
      Value<double?>? simplesNacionalTotal,
      Value<String?>? informacoesAddFisco,
      Value<double?>? valorTotalCarga,
      Value<String?>? produtoPredominante,
      Value<String?>? cargaOutrasCaracteristicas,
      Value<int?>? modalVersaoLayout,
      Value<String?>? chaveCteSubstituido}) {
    return CteCabecalhosCompanion(
      id: id ?? this.id,
      naturezaOperacao: naturezaOperacao ?? this.naturezaOperacao,
      chaveAcesso: chaveAcesso ?? this.chaveAcesso,
      digitoChaveAcesso: digitoChaveAcesso ?? this.digitoChaveAcesso,
      codigoNumerico: codigoNumerico ?? this.codigoNumerico,
      serie: serie ?? this.serie,
      numero: numero ?? this.numero,
      dataHoraEmissao: dataHoraEmissao ?? this.dataHoraEmissao,
      ufEmitente: ufEmitente ?? this.ufEmitente,
      cfop: cfop ?? this.cfop,
      formaPagamento: formaPagamento ?? this.formaPagamento,
      modelo: modelo ?? this.modelo,
      formatoImpressaoDacte:
          formatoImpressaoDacte ?? this.formatoImpressaoDacte,
      tipoEmissao: tipoEmissao ?? this.tipoEmissao,
      ambiente: ambiente ?? this.ambiente,
      tipoCte: tipoCte ?? this.tipoCte,
      processoEmissao: processoEmissao ?? this.processoEmissao,
      versaoProcessoEmissao:
          versaoProcessoEmissao ?? this.versaoProcessoEmissao,
      chaveReferenciado: chaveReferenciado ?? this.chaveReferenciado,
      codigoMunicipioEnvio: codigoMunicipioEnvio ?? this.codigoMunicipioEnvio,
      nomeMunicipioEnvio: nomeMunicipioEnvio ?? this.nomeMunicipioEnvio,
      ufEnvio: ufEnvio ?? this.ufEnvio,
      modal: modal ?? this.modal,
      tipoServico: tipoServico ?? this.tipoServico,
      codigoMunicipioIniPrestacao:
          codigoMunicipioIniPrestacao ?? this.codigoMunicipioIniPrestacao,
      nomeMunicipioIniPrestacao:
          nomeMunicipioIniPrestacao ?? this.nomeMunicipioIniPrestacao,
      ufIniPrestacao: ufIniPrestacao ?? this.ufIniPrestacao,
      codigoMunicipioFimPrestacao:
          codigoMunicipioFimPrestacao ?? this.codigoMunicipioFimPrestacao,
      nomeMunicipioFimPrestacao:
          nomeMunicipioFimPrestacao ?? this.nomeMunicipioFimPrestacao,
      ufFimPrestacao: ufFimPrestacao ?? this.ufFimPrestacao,
      retira: retira ?? this.retira,
      retiraDetalhe: retiraDetalhe ?? this.retiraDetalhe,
      tomador: tomador ?? this.tomador,
      dataEntradaContingencia:
          dataEntradaContingencia ?? this.dataEntradaContingencia,
      justificativaContingencia:
          justificativaContingencia ?? this.justificativaContingencia,
      caracAdicionalTransporte:
          caracAdicionalTransporte ?? this.caracAdicionalTransporte,
      caracAdicionalServico:
          caracAdicionalServico ?? this.caracAdicionalServico,
      funcionarioEmissor: funcionarioEmissor ?? this.funcionarioEmissor,
      fluxoOrigem: fluxoOrigem ?? this.fluxoOrigem,
      entregaTipoPeriodo: entregaTipoPeriodo ?? this.entregaTipoPeriodo,
      entregaDataProgramada:
          entregaDataProgramada ?? this.entregaDataProgramada,
      entregaDataInicial: entregaDataInicial ?? this.entregaDataInicial,
      entregaDataFinal: entregaDataFinal ?? this.entregaDataFinal,
      entregaTipoHora: entregaTipoHora ?? this.entregaTipoHora,
      entregaHoraProgramada:
          entregaHoraProgramada ?? this.entregaHoraProgramada,
      entregaHoraInicial: entregaHoraInicial ?? this.entregaHoraInicial,
      entregaHoraFinal: entregaHoraFinal ?? this.entregaHoraFinal,
      municipioOrigemCalculo:
          municipioOrigemCalculo ?? this.municipioOrigemCalculo,
      municipioDestinoCalculo:
          municipioDestinoCalculo ?? this.municipioDestinoCalculo,
      observacoesGerais: observacoesGerais ?? this.observacoesGerais,
      valorTotalServico: valorTotalServico ?? this.valorTotalServico,
      valorReceber: valorReceber ?? this.valorReceber,
      cst: cst ?? this.cst,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      aliquotaIcms: aliquotaIcms ?? this.aliquotaIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      percentualReducaoBcIcms:
          percentualReducaoBcIcms ?? this.percentualReducaoBcIcms,
      valorBcIcmsStRetido: valorBcIcmsStRetido ?? this.valorBcIcmsStRetido,
      valorIcmsStRetido: valorIcmsStRetido ?? this.valorIcmsStRetido,
      aliquotaIcmsStRetido: aliquotaIcmsStRetido ?? this.aliquotaIcmsStRetido,
      valorCreditoPresumidoIcms:
          valorCreditoPresumidoIcms ?? this.valorCreditoPresumidoIcms,
      percentualBcIcmsOutraUf:
          percentualBcIcmsOutraUf ?? this.percentualBcIcmsOutraUf,
      valorBcIcmsOutraUf: valorBcIcmsOutraUf ?? this.valorBcIcmsOutraUf,
      aliquotaIcmsOutraUf: aliquotaIcmsOutraUf ?? this.aliquotaIcmsOutraUf,
      valorIcmsOutraUf: valorIcmsOutraUf ?? this.valorIcmsOutraUf,
      simplesNacionalIndicador:
          simplesNacionalIndicador ?? this.simplesNacionalIndicador,
      simplesNacionalTotal: simplesNacionalTotal ?? this.simplesNacionalTotal,
      informacoesAddFisco: informacoesAddFisco ?? this.informacoesAddFisco,
      valorTotalCarga: valorTotalCarga ?? this.valorTotalCarga,
      produtoPredominante: produtoPredominante ?? this.produtoPredominante,
      cargaOutrasCaracteristicas:
          cargaOutrasCaracteristicas ?? this.cargaOutrasCaracteristicas,
      modalVersaoLayout: modalVersaoLayout ?? this.modalVersaoLayout,
      chaveCteSubstituido: chaveCteSubstituido ?? this.chaveCteSubstituido,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (naturezaOperacao.present) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao.value);
    }
    if (chaveAcesso.present) {
      map['chave_acesso'] = Variable<String>(chaveAcesso.value);
    }
    if (digitoChaveAcesso.present) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso.value);
    }
    if (codigoNumerico.present) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataHoraEmissao.present) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao.value);
    }
    if (ufEmitente.present) {
      map['uf_emitente'] = Variable<String>(ufEmitente.value);
    }
    if (cfop.present) {
      map['cfop'] = Variable<int>(cfop.value);
    }
    if (formaPagamento.present) {
      map['forma_pagamento'] = Variable<String>(formaPagamento.value);
    }
    if (modelo.present) {
      map['modelo'] = Variable<String>(modelo.value);
    }
    if (formatoImpressaoDacte.present) {
      map['formato_impressao_dacte'] =
          Variable<String>(formatoImpressaoDacte.value);
    }
    if (tipoEmissao.present) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao.value);
    }
    if (ambiente.present) {
      map['ambiente'] = Variable<String>(ambiente.value);
    }
    if (tipoCte.present) {
      map['tipo_cte'] = Variable<String>(tipoCte.value);
    }
    if (processoEmissao.present) {
      map['processo_emissao'] = Variable<String>(processoEmissao.value);
    }
    if (versaoProcessoEmissao.present) {
      map['versao_processo_emissao'] =
          Variable<String>(versaoProcessoEmissao.value);
    }
    if (chaveReferenciado.present) {
      map['chave_referenciado'] = Variable<String>(chaveReferenciado.value);
    }
    if (codigoMunicipioEnvio.present) {
      map['codigo_municipio_envio'] = Variable<int>(codigoMunicipioEnvio.value);
    }
    if (nomeMunicipioEnvio.present) {
      map['nome_municipio_envio'] = Variable<String>(nomeMunicipioEnvio.value);
    }
    if (ufEnvio.present) {
      map['uf_envio'] = Variable<String>(ufEnvio.value);
    }
    if (modal.present) {
      map['modal'] = Variable<String>(modal.value);
    }
    if (tipoServico.present) {
      map['tipo_servico'] = Variable<String>(tipoServico.value);
    }
    if (codigoMunicipioIniPrestacao.present) {
      map['codigo_municipio_ini_prestacao'] =
          Variable<int>(codigoMunicipioIniPrestacao.value);
    }
    if (nomeMunicipioIniPrestacao.present) {
      map['nome_municipio_ini_prestacao'] =
          Variable<String>(nomeMunicipioIniPrestacao.value);
    }
    if (ufIniPrestacao.present) {
      map['uf_ini_prestacao'] = Variable<String>(ufIniPrestacao.value);
    }
    if (codigoMunicipioFimPrestacao.present) {
      map['codigo_municipio_fim_prestacao'] =
          Variable<int>(codigoMunicipioFimPrestacao.value);
    }
    if (nomeMunicipioFimPrestacao.present) {
      map['nome_municipio_fim_prestacao'] =
          Variable<String>(nomeMunicipioFimPrestacao.value);
    }
    if (ufFimPrestacao.present) {
      map['uf_fim_prestacao'] = Variable<String>(ufFimPrestacao.value);
    }
    if (retira.present) {
      map['retira'] = Variable<String>(retira.value);
    }
    if (retiraDetalhe.present) {
      map['retira_detalhe'] = Variable<String>(retiraDetalhe.value);
    }
    if (tomador.present) {
      map['tomador'] = Variable<String>(tomador.value);
    }
    if (dataEntradaContingencia.present) {
      map['data_entrada_contingencia'] =
          Variable<DateTime>(dataEntradaContingencia.value);
    }
    if (justificativaContingencia.present) {
      map['justificativa_contingencia'] =
          Variable<String>(justificativaContingencia.value);
    }
    if (caracAdicionalTransporte.present) {
      map['carac_adicional_transporte'] =
          Variable<String>(caracAdicionalTransporte.value);
    }
    if (caracAdicionalServico.present) {
      map['carac_adicional_servico'] =
          Variable<String>(caracAdicionalServico.value);
    }
    if (funcionarioEmissor.present) {
      map['funcionario_emissor'] = Variable<String>(funcionarioEmissor.value);
    }
    if (fluxoOrigem.present) {
      map['fluxo_origem'] = Variable<String>(fluxoOrigem.value);
    }
    if (entregaTipoPeriodo.present) {
      map['entrega_tipo_periodo'] = Variable<String>(entregaTipoPeriodo.value);
    }
    if (entregaDataProgramada.present) {
      map['entrega_data_programada'] =
          Variable<DateTime>(entregaDataProgramada.value);
    }
    if (entregaDataInicial.present) {
      map['entrega_data_inicial'] =
          Variable<DateTime>(entregaDataInicial.value);
    }
    if (entregaDataFinal.present) {
      map['entrega_data_final'] = Variable<DateTime>(entregaDataFinal.value);
    }
    if (entregaTipoHora.present) {
      map['entrega_tipo_hora'] = Variable<String>(entregaTipoHora.value);
    }
    if (entregaHoraProgramada.present) {
      map['entrega_hora_programada'] =
          Variable<String>(entregaHoraProgramada.value);
    }
    if (entregaHoraInicial.present) {
      map['entrega_hora_inicial'] = Variable<String>(entregaHoraInicial.value);
    }
    if (entregaHoraFinal.present) {
      map['entrega_hora_final'] = Variable<String>(entregaHoraFinal.value);
    }
    if (municipioOrigemCalculo.present) {
      map['municipio_origem_calculo'] =
          Variable<String>(municipioOrigemCalculo.value);
    }
    if (municipioDestinoCalculo.present) {
      map['municipio_destino_calculo'] =
          Variable<String>(municipioDestinoCalculo.value);
    }
    if (observacoesGerais.present) {
      map['observacoes_gerais'] = Variable<String>(observacoesGerais.value);
    }
    if (valorTotalServico.present) {
      map['valor_total_servico'] = Variable<double>(valorTotalServico.value);
    }
    if (valorReceber.present) {
      map['valor_receber'] = Variable<double>(valorReceber.value);
    }
    if (cst.present) {
      map['cst'] = Variable<String>(cst.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (aliquotaIcms.present) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (percentualReducaoBcIcms.present) {
      map['percentual_reducao_bc_icms'] =
          Variable<double>(percentualReducaoBcIcms.value);
    }
    if (valorBcIcmsStRetido.present) {
      map['valor_bc_icms_st_retido'] =
          Variable<double>(valorBcIcmsStRetido.value);
    }
    if (valorIcmsStRetido.present) {
      map['valor_icms_st_retido'] = Variable<double>(valorIcmsStRetido.value);
    }
    if (aliquotaIcmsStRetido.present) {
      map['aliquota_icms_st_retido'] =
          Variable<double>(aliquotaIcmsStRetido.value);
    }
    if (valorCreditoPresumidoIcms.present) {
      map['valor_credito_presumido_icms'] =
          Variable<double>(valorCreditoPresumidoIcms.value);
    }
    if (percentualBcIcmsOutraUf.present) {
      map['percentual_bc_icms_outra_uf'] =
          Variable<double>(percentualBcIcmsOutraUf.value);
    }
    if (valorBcIcmsOutraUf.present) {
      map['valor_bc_icms_outra_uf'] =
          Variable<double>(valorBcIcmsOutraUf.value);
    }
    if (aliquotaIcmsOutraUf.present) {
      map['aliquota_icms_outra_uf'] =
          Variable<double>(aliquotaIcmsOutraUf.value);
    }
    if (valorIcmsOutraUf.present) {
      map['valor_icms_outra_uf'] = Variable<double>(valorIcmsOutraUf.value);
    }
    if (simplesNacionalIndicador.present) {
      map['simples_nacional_indicador'] =
          Variable<String>(simplesNacionalIndicador.value);
    }
    if (simplesNacionalTotal.present) {
      map['simples_nacional_total'] =
          Variable<double>(simplesNacionalTotal.value);
    }
    if (informacoesAddFisco.present) {
      map['informacoes_add_fisco'] =
          Variable<String>(informacoesAddFisco.value);
    }
    if (valorTotalCarga.present) {
      map['valor_total_carga'] = Variable<double>(valorTotalCarga.value);
    }
    if (produtoPredominante.present) {
      map['produto_predominante'] = Variable<String>(produtoPredominante.value);
    }
    if (cargaOutrasCaracteristicas.present) {
      map['carga_outras_caracteristicas'] =
          Variable<String>(cargaOutrasCaracteristicas.value);
    }
    if (modalVersaoLayout.present) {
      map['modal_versao_layout'] = Variable<int>(modalVersaoLayout.value);
    }
    if (chaveCteSubstituido.present) {
      map['chave_cte_substituido'] =
          Variable<String>(chaveCteSubstituido.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('cfop: $cfop, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('modelo: $modelo, ')
          ..write('formatoImpressaoDacte: $formatoImpressaoDacte, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('ambiente: $ambiente, ')
          ..write('tipoCte: $tipoCte, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('chaveReferenciado: $chaveReferenciado, ')
          ..write('codigoMunicipioEnvio: $codigoMunicipioEnvio, ')
          ..write('nomeMunicipioEnvio: $nomeMunicipioEnvio, ')
          ..write('ufEnvio: $ufEnvio, ')
          ..write('modal: $modal, ')
          ..write('tipoServico: $tipoServico, ')
          ..write('codigoMunicipioIniPrestacao: $codigoMunicipioIniPrestacao, ')
          ..write('nomeMunicipioIniPrestacao: $nomeMunicipioIniPrestacao, ')
          ..write('ufIniPrestacao: $ufIniPrestacao, ')
          ..write('codigoMunicipioFimPrestacao: $codigoMunicipioFimPrestacao, ')
          ..write('nomeMunicipioFimPrestacao: $nomeMunicipioFimPrestacao, ')
          ..write('ufFimPrestacao: $ufFimPrestacao, ')
          ..write('retira: $retira, ')
          ..write('retiraDetalhe: $retiraDetalhe, ')
          ..write('tomador: $tomador, ')
          ..write('dataEntradaContingencia: $dataEntradaContingencia, ')
          ..write('justificativaContingencia: $justificativaContingencia, ')
          ..write('caracAdicionalTransporte: $caracAdicionalTransporte, ')
          ..write('caracAdicionalServico: $caracAdicionalServico, ')
          ..write('funcionarioEmissor: $funcionarioEmissor, ')
          ..write('fluxoOrigem: $fluxoOrigem, ')
          ..write('entregaTipoPeriodo: $entregaTipoPeriodo, ')
          ..write('entregaDataProgramada: $entregaDataProgramada, ')
          ..write('entregaDataInicial: $entregaDataInicial, ')
          ..write('entregaDataFinal: $entregaDataFinal, ')
          ..write('entregaTipoHora: $entregaTipoHora, ')
          ..write('entregaHoraProgramada: $entregaHoraProgramada, ')
          ..write('entregaHoraInicial: $entregaHoraInicial, ')
          ..write('entregaHoraFinal: $entregaHoraFinal, ')
          ..write('municipioOrigemCalculo: $municipioOrigemCalculo, ')
          ..write('municipioDestinoCalculo: $municipioDestinoCalculo, ')
          ..write('observacoesGerais: $observacoesGerais, ')
          ..write('valorTotalServico: $valorTotalServico, ')
          ..write('valorReceber: $valorReceber, ')
          ..write('cst: $cst, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('percentualReducaoBcIcms: $percentualReducaoBcIcms, ')
          ..write('valorBcIcmsStRetido: $valorBcIcmsStRetido, ')
          ..write('valorIcmsStRetido: $valorIcmsStRetido, ')
          ..write('aliquotaIcmsStRetido: $aliquotaIcmsStRetido, ')
          ..write('valorCreditoPresumidoIcms: $valorCreditoPresumidoIcms, ')
          ..write('percentualBcIcmsOutraUf: $percentualBcIcmsOutraUf, ')
          ..write('valorBcIcmsOutraUf: $valorBcIcmsOutraUf, ')
          ..write('aliquotaIcmsOutraUf: $aliquotaIcmsOutraUf, ')
          ..write('valorIcmsOutraUf: $valorIcmsOutraUf, ')
          ..write('simplesNacionalIndicador: $simplesNacionalIndicador, ')
          ..write('simplesNacionalTotal: $simplesNacionalTotal, ')
          ..write('informacoesAddFisco: $informacoesAddFisco, ')
          ..write('valorTotalCarga: $valorTotalCarga, ')
          ..write('produtoPredominante: $produtoPredominante, ')
          ..write('cargaOutrasCaracteristicas: $cargaOutrasCaracteristicas, ')
          ..write('modalVersaoLayout: $modalVersaoLayout, ')
          ..write('chaveCteSubstituido: $chaveCteSubstituido')
          ..write(')'))
        .toString();
  }
}

class $CteInformacaoNfTransportesTable extends CteInformacaoNfTransportes
    with
        TableInfo<$CteInformacaoNfTransportesTable, CteInformacaoNfTransporte> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteInformacaoNfTransportesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteInformacaoNfMeta =
      const VerificationMeta('idCteInformacaoNf');
  @override
  late final GeneratedColumn<int> idCteInformacaoNf = GeneratedColumn<int>(
      'id_cte_informacao_nf', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoUnidadeTransporteMeta =
      const VerificationMeta('tipoUnidadeTransporte');
  @override
  late final GeneratedColumn<String> tipoUnidadeTransporte =
      GeneratedColumn<String>('tipo_unidade_transporte', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _idUnidadeTransporteMeta =
      const VerificationMeta('idUnidadeTransporte');
  @override
  late final GeneratedColumn<String> idUnidadeTransporte =
      GeneratedColumn<String>('id_unidade_transporte', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteInformacaoNf, tipoUnidadeTransporte, idUnidadeTransporte];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_informacao_nf_transporte';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteInformacaoNfTransporte> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_informacao_nf')) {
      context.handle(
          _idCteInformacaoNfMeta,
          idCteInformacaoNf.isAcceptableOrUnknown(
              data['id_cte_informacao_nf']!, _idCteInformacaoNfMeta));
    }
    if (data.containsKey('tipo_unidade_transporte')) {
      context.handle(
          _tipoUnidadeTransporteMeta,
          tipoUnidadeTransporte.isAcceptableOrUnknown(
              data['tipo_unidade_transporte']!, _tipoUnidadeTransporteMeta));
    }
    if (data.containsKey('id_unidade_transporte')) {
      context.handle(
          _idUnidadeTransporteMeta,
          idUnidadeTransporte.isAcceptableOrUnknown(
              data['id_unidade_transporte']!, _idUnidadeTransporteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteInformacaoNfTransporte map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteInformacaoNfTransporte(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteInformacaoNf: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_cte_informacao_nf']),
      tipoUnidadeTransporte: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}tipo_unidade_transporte']),
      idUnidadeTransporte: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}id_unidade_transporte']),
    );
  }

  @override
  $CteInformacaoNfTransportesTable createAlias(String alias) {
    return $CteInformacaoNfTransportesTable(attachedDatabase, alias);
  }
}

class CteInformacaoNfTransporte extends DataClass
    implements Insertable<CteInformacaoNfTransporte> {
  final int? id;
  final int? idCteInformacaoNf;
  final String? tipoUnidadeTransporte;
  final String? idUnidadeTransporte;
  const CteInformacaoNfTransporte(
      {this.id,
      this.idCteInformacaoNf,
      this.tipoUnidadeTransporte,
      this.idUnidadeTransporte});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteInformacaoNf != null) {
      map['id_cte_informacao_nf'] = Variable<int>(idCteInformacaoNf);
    }
    if (!nullToAbsent || tipoUnidadeTransporte != null) {
      map['tipo_unidade_transporte'] = Variable<String>(tipoUnidadeTransporte);
    }
    if (!nullToAbsent || idUnidadeTransporte != null) {
      map['id_unidade_transporte'] = Variable<String>(idUnidadeTransporte);
    }
    return map;
  }

  factory CteInformacaoNfTransporte.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteInformacaoNfTransporte(
      id: serializer.fromJson<int?>(json['id']),
      idCteInformacaoNf: serializer.fromJson<int?>(json['idCteInformacaoNf']),
      tipoUnidadeTransporte:
          serializer.fromJson<String?>(json['tipoUnidadeTransporte']),
      idUnidadeTransporte:
          serializer.fromJson<String?>(json['idUnidadeTransporte']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteInformacaoNf': serializer.toJson<int?>(idCteInformacaoNf),
      'tipoUnidadeTransporte':
          serializer.toJson<String?>(tipoUnidadeTransporte),
      'idUnidadeTransporte': serializer.toJson<String?>(idUnidadeTransporte),
    };
  }

  CteInformacaoNfTransporte copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteInformacaoNf = const Value.absent(),
          Value<String?> tipoUnidadeTransporte = const Value.absent(),
          Value<String?> idUnidadeTransporte = const Value.absent()}) =>
      CteInformacaoNfTransporte(
        id: id.present ? id.value : this.id,
        idCteInformacaoNf: idCteInformacaoNf.present
            ? idCteInformacaoNf.value
            : this.idCteInformacaoNf,
        tipoUnidadeTransporte: tipoUnidadeTransporte.present
            ? tipoUnidadeTransporte.value
            : this.tipoUnidadeTransporte,
        idUnidadeTransporte: idUnidadeTransporte.present
            ? idUnidadeTransporte.value
            : this.idUnidadeTransporte,
      );
  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfTransporte(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNf: $idCteInformacaoNf, ')
          ..write('tipoUnidadeTransporte: $tipoUnidadeTransporte, ')
          ..write('idUnidadeTransporte: $idUnidadeTransporte')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCteInformacaoNf, tipoUnidadeTransporte, idUnidadeTransporte);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteInformacaoNfTransporte &&
          other.id == this.id &&
          other.idCteInformacaoNf == this.idCteInformacaoNf &&
          other.tipoUnidadeTransporte == this.tipoUnidadeTransporte &&
          other.idUnidadeTransporte == this.idUnidadeTransporte);
}

class CteInformacaoNfTransportesCompanion
    extends UpdateCompanion<CteInformacaoNfTransporte> {
  final Value<int?> id;
  final Value<int?> idCteInformacaoNf;
  final Value<String?> tipoUnidadeTransporte;
  final Value<String?> idUnidadeTransporte;
  const CteInformacaoNfTransportesCompanion({
    this.id = const Value.absent(),
    this.idCteInformacaoNf = const Value.absent(),
    this.tipoUnidadeTransporte = const Value.absent(),
    this.idUnidadeTransporte = const Value.absent(),
  });
  CteInformacaoNfTransportesCompanion.insert({
    this.id = const Value.absent(),
    this.idCteInformacaoNf = const Value.absent(),
    this.tipoUnidadeTransporte = const Value.absent(),
    this.idUnidadeTransporte = const Value.absent(),
  });
  static Insertable<CteInformacaoNfTransporte> custom({
    Expression<int>? id,
    Expression<int>? idCteInformacaoNf,
    Expression<String>? tipoUnidadeTransporte,
    Expression<String>? idUnidadeTransporte,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteInformacaoNf != null) 'id_cte_informacao_nf': idCteInformacaoNf,
      if (tipoUnidadeTransporte != null)
        'tipo_unidade_transporte': tipoUnidadeTransporte,
      if (idUnidadeTransporte != null)
        'id_unidade_transporte': idUnidadeTransporte,
    });
  }

  CteInformacaoNfTransportesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteInformacaoNf,
      Value<String?>? tipoUnidadeTransporte,
      Value<String?>? idUnidadeTransporte}) {
    return CteInformacaoNfTransportesCompanion(
      id: id ?? this.id,
      idCteInformacaoNf: idCteInformacaoNf ?? this.idCteInformacaoNf,
      tipoUnidadeTransporte:
          tipoUnidadeTransporte ?? this.tipoUnidadeTransporte,
      idUnidadeTransporte: idUnidadeTransporte ?? this.idUnidadeTransporte,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteInformacaoNf.present) {
      map['id_cte_informacao_nf'] = Variable<int>(idCteInformacaoNf.value);
    }
    if (tipoUnidadeTransporte.present) {
      map['tipo_unidade_transporte'] =
          Variable<String>(tipoUnidadeTransporte.value);
    }
    if (idUnidadeTransporte.present) {
      map['id_unidade_transporte'] =
          Variable<String>(idUnidadeTransporte.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfTransportesCompanion(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNf: $idCteInformacaoNf, ')
          ..write('tipoUnidadeTransporte: $tipoUnidadeTransporte, ')
          ..write('idUnidadeTransporte: $idUnidadeTransporte')
          ..write(')'))
        .toString();
  }
}

class $CteInfNfTransporteLacresTable extends CteInfNfTransporteLacres
    with TableInfo<$CteInfNfTransporteLacresTable, CteInfNfTransporteLacre> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteInfNfTransporteLacresTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteInformacaoNfTransporteMeta =
      const VerificationMeta('idCteInformacaoNfTransporte');
  @override
  late final GeneratedColumn<int> idCteInformacaoNfTransporte =
      GeneratedColumn<int>('id_cte_informacao_nf_transporte', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteInformacaoNfTransporte, numero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_inf_nf_transporte_lacre';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteInfNfTransporteLacre> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_informacao_nf_transporte')) {
      context.handle(
          _idCteInformacaoNfTransporteMeta,
          idCteInformacaoNfTransporte.isAcceptableOrUnknown(
              data['id_cte_informacao_nf_transporte']!,
              _idCteInformacaoNfTransporteMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteInfNfTransporteLacre map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteInfNfTransporteLacre(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteInformacaoNfTransporte: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_cte_informacao_nf_transporte']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
    );
  }

  @override
  $CteInfNfTransporteLacresTable createAlias(String alias) {
    return $CteInfNfTransporteLacresTable(attachedDatabase, alias);
  }
}

class CteInfNfTransporteLacre extends DataClass
    implements Insertable<CteInfNfTransporteLacre> {
  final int? id;
  final int? idCteInformacaoNfTransporte;
  final String? numero;
  const CteInfNfTransporteLacre(
      {this.id, this.idCteInformacaoNfTransporte, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteInformacaoNfTransporte != null) {
      map['id_cte_informacao_nf_transporte'] =
          Variable<int>(idCteInformacaoNfTransporte);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory CteInfNfTransporteLacre.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteInfNfTransporteLacre(
      id: serializer.fromJson<int?>(json['id']),
      idCteInformacaoNfTransporte:
          serializer.fromJson<int?>(json['idCteInformacaoNfTransporte']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteInformacaoNfTransporte':
          serializer.toJson<int?>(idCteInformacaoNfTransporte),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  CteInfNfTransporteLacre copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteInformacaoNfTransporte = const Value.absent(),
          Value<String?> numero = const Value.absent()}) =>
      CteInfNfTransporteLacre(
        id: id.present ? id.value : this.id,
        idCteInformacaoNfTransporte: idCteInformacaoNfTransporte.present
            ? idCteInformacaoNfTransporte.value
            : this.idCteInformacaoNfTransporte,
        numero: numero.present ? numero.value : this.numero,
      );
  @override
  String toString() {
    return (StringBuffer('CteInfNfTransporteLacre(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNfTransporte: $idCteInformacaoNfTransporte, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteInformacaoNfTransporte, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteInfNfTransporteLacre &&
          other.id == this.id &&
          other.idCteInformacaoNfTransporte ==
              this.idCteInformacaoNfTransporte &&
          other.numero == this.numero);
}

class CteInfNfTransporteLacresCompanion
    extends UpdateCompanion<CteInfNfTransporteLacre> {
  final Value<int?> id;
  final Value<int?> idCteInformacaoNfTransporte;
  final Value<String?> numero;
  const CteInfNfTransporteLacresCompanion({
    this.id = const Value.absent(),
    this.idCteInformacaoNfTransporte = const Value.absent(),
    this.numero = const Value.absent(),
  });
  CteInfNfTransporteLacresCompanion.insert({
    this.id = const Value.absent(),
    this.idCteInformacaoNfTransporte = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<CteInfNfTransporteLacre> custom({
    Expression<int>? id,
    Expression<int>? idCteInformacaoNfTransporte,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteInformacaoNfTransporte != null)
        'id_cte_informacao_nf_transporte': idCteInformacaoNfTransporte,
      if (numero != null) 'numero': numero,
    });
  }

  CteInfNfTransporteLacresCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteInformacaoNfTransporte,
      Value<String?>? numero}) {
    return CteInfNfTransporteLacresCompanion(
      id: id ?? this.id,
      idCteInformacaoNfTransporte:
          idCteInformacaoNfTransporte ?? this.idCteInformacaoNfTransporte,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteInformacaoNfTransporte.present) {
      map['id_cte_informacao_nf_transporte'] =
          Variable<int>(idCteInformacaoNfTransporte.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteInfNfTransporteLacresCompanion(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNfTransporte: $idCteInformacaoNfTransporte, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $CteInformacaoNfCargasTable extends CteInformacaoNfCargas
    with TableInfo<$CteInformacaoNfCargasTable, CteInformacaoNfCarga> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteInformacaoNfCargasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteInformacaoNfMeta =
      const VerificationMeta('idCteInformacaoNf');
  @override
  late final GeneratedColumn<int> idCteInformacaoNf = GeneratedColumn<int>(
      'id_cte_informacao_nf', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoUnidadeCargaMeta =
      const VerificationMeta('tipoUnidadeCarga');
  @override
  late final GeneratedColumn<String> tipoUnidadeCarga = GeneratedColumn<String>(
      'tipo_unidade_carga', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idUnidadeCargaMeta =
      const VerificationMeta('idUnidadeCarga');
  @override
  late final GeneratedColumn<String> idUnidadeCarga = GeneratedColumn<String>(
      'id_unidade_carga', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteInformacaoNf, tipoUnidadeCarga, idUnidadeCarga];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_informacao_nf_carga';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteInformacaoNfCarga> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_informacao_nf')) {
      context.handle(
          _idCteInformacaoNfMeta,
          idCteInformacaoNf.isAcceptableOrUnknown(
              data['id_cte_informacao_nf']!, _idCteInformacaoNfMeta));
    }
    if (data.containsKey('tipo_unidade_carga')) {
      context.handle(
          _tipoUnidadeCargaMeta,
          tipoUnidadeCarga.isAcceptableOrUnknown(
              data['tipo_unidade_carga']!, _tipoUnidadeCargaMeta));
    }
    if (data.containsKey('id_unidade_carga')) {
      context.handle(
          _idUnidadeCargaMeta,
          idUnidadeCarga.isAcceptableOrUnknown(
              data['id_unidade_carga']!, _idUnidadeCargaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteInformacaoNfCarga map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteInformacaoNfCarga(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteInformacaoNf: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_cte_informacao_nf']),
      tipoUnidadeCarga: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tipo_unidade_carga']),
      idUnidadeCarga: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}id_unidade_carga']),
    );
  }

  @override
  $CteInformacaoNfCargasTable createAlias(String alias) {
    return $CteInformacaoNfCargasTable(attachedDatabase, alias);
  }
}

class CteInformacaoNfCarga extends DataClass
    implements Insertable<CteInformacaoNfCarga> {
  final int? id;
  final int? idCteInformacaoNf;
  final String? tipoUnidadeCarga;
  final String? idUnidadeCarga;
  const CteInformacaoNfCarga(
      {this.id,
      this.idCteInformacaoNf,
      this.tipoUnidadeCarga,
      this.idUnidadeCarga});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteInformacaoNf != null) {
      map['id_cte_informacao_nf'] = Variable<int>(idCteInformacaoNf);
    }
    if (!nullToAbsent || tipoUnidadeCarga != null) {
      map['tipo_unidade_carga'] = Variable<String>(tipoUnidadeCarga);
    }
    if (!nullToAbsent || idUnidadeCarga != null) {
      map['id_unidade_carga'] = Variable<String>(idUnidadeCarga);
    }
    return map;
  }

  factory CteInformacaoNfCarga.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteInformacaoNfCarga(
      id: serializer.fromJson<int?>(json['id']),
      idCteInformacaoNf: serializer.fromJson<int?>(json['idCteInformacaoNf']),
      tipoUnidadeCarga: serializer.fromJson<String?>(json['tipoUnidadeCarga']),
      idUnidadeCarga: serializer.fromJson<String?>(json['idUnidadeCarga']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteInformacaoNf': serializer.toJson<int?>(idCteInformacaoNf),
      'tipoUnidadeCarga': serializer.toJson<String?>(tipoUnidadeCarga),
      'idUnidadeCarga': serializer.toJson<String?>(idUnidadeCarga),
    };
  }

  CteInformacaoNfCarga copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteInformacaoNf = const Value.absent(),
          Value<String?> tipoUnidadeCarga = const Value.absent(),
          Value<String?> idUnidadeCarga = const Value.absent()}) =>
      CteInformacaoNfCarga(
        id: id.present ? id.value : this.id,
        idCteInformacaoNf: idCteInformacaoNf.present
            ? idCteInformacaoNf.value
            : this.idCteInformacaoNf,
        tipoUnidadeCarga: tipoUnidadeCarga.present
            ? tipoUnidadeCarga.value
            : this.tipoUnidadeCarga,
        idUnidadeCarga:
            idUnidadeCarga.present ? idUnidadeCarga.value : this.idUnidadeCarga,
      );
  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfCarga(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNf: $idCteInformacaoNf, ')
          ..write('tipoUnidadeCarga: $tipoUnidadeCarga, ')
          ..write('idUnidadeCarga: $idUnidadeCarga')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteInformacaoNf, tipoUnidadeCarga, idUnidadeCarga);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteInformacaoNfCarga &&
          other.id == this.id &&
          other.idCteInformacaoNf == this.idCteInformacaoNf &&
          other.tipoUnidadeCarga == this.tipoUnidadeCarga &&
          other.idUnidadeCarga == this.idUnidadeCarga);
}

class CteInformacaoNfCargasCompanion
    extends UpdateCompanion<CteInformacaoNfCarga> {
  final Value<int?> id;
  final Value<int?> idCteInformacaoNf;
  final Value<String?> tipoUnidadeCarga;
  final Value<String?> idUnidadeCarga;
  const CteInformacaoNfCargasCompanion({
    this.id = const Value.absent(),
    this.idCteInformacaoNf = const Value.absent(),
    this.tipoUnidadeCarga = const Value.absent(),
    this.idUnidadeCarga = const Value.absent(),
  });
  CteInformacaoNfCargasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteInformacaoNf = const Value.absent(),
    this.tipoUnidadeCarga = const Value.absent(),
    this.idUnidadeCarga = const Value.absent(),
  });
  static Insertable<CteInformacaoNfCarga> custom({
    Expression<int>? id,
    Expression<int>? idCteInformacaoNf,
    Expression<String>? tipoUnidadeCarga,
    Expression<String>? idUnidadeCarga,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteInformacaoNf != null) 'id_cte_informacao_nf': idCteInformacaoNf,
      if (tipoUnidadeCarga != null) 'tipo_unidade_carga': tipoUnidadeCarga,
      if (idUnidadeCarga != null) 'id_unidade_carga': idUnidadeCarga,
    });
  }

  CteInformacaoNfCargasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteInformacaoNf,
      Value<String?>? tipoUnidadeCarga,
      Value<String?>? idUnidadeCarga}) {
    return CteInformacaoNfCargasCompanion(
      id: id ?? this.id,
      idCteInformacaoNf: idCteInformacaoNf ?? this.idCteInformacaoNf,
      tipoUnidadeCarga: tipoUnidadeCarga ?? this.tipoUnidadeCarga,
      idUnidadeCarga: idUnidadeCarga ?? this.idUnidadeCarga,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteInformacaoNf.present) {
      map['id_cte_informacao_nf'] = Variable<int>(idCteInformacaoNf.value);
    }
    if (tipoUnidadeCarga.present) {
      map['tipo_unidade_carga'] = Variable<String>(tipoUnidadeCarga.value);
    }
    if (idUnidadeCarga.present) {
      map['id_unidade_carga'] = Variable<String>(idUnidadeCarga.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteInformacaoNfCargasCompanion(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNf: $idCteInformacaoNf, ')
          ..write('tipoUnidadeCarga: $tipoUnidadeCarga, ')
          ..write('idUnidadeCarga: $idUnidadeCarga')
          ..write(')'))
        .toString();
  }
}

class $CteInfNfCargaLacresTable extends CteInfNfCargaLacres
    with TableInfo<$CteInfNfCargaLacresTable, CteInfNfCargaLacre> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteInfNfCargaLacresTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteInformacaoNfCargaMeta =
      const VerificationMeta('idCteInformacaoNfCarga');
  @override
  late final GeneratedColumn<int> idCteInformacaoNfCarga = GeneratedColumn<int>(
      'id_cte_informacao_nf_carga', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeRateadaMeta =
      const VerificationMeta('quantidadeRateada');
  @override
  late final GeneratedColumn<double> quantidadeRateada =
      GeneratedColumn<double>('quantidade_rateada', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCteInformacaoNfCarga, numero, quantidadeRateada];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_inf_nf_carga_lacre';
  @override
  VerificationContext validateIntegrity(Insertable<CteInfNfCargaLacre> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_informacao_nf_carga')) {
      context.handle(
          _idCteInformacaoNfCargaMeta,
          idCteInformacaoNfCarga.isAcceptableOrUnknown(
              data['id_cte_informacao_nf_carga']!,
              _idCteInformacaoNfCargaMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('quantidade_rateada')) {
      context.handle(
          _quantidadeRateadaMeta,
          quantidadeRateada.isAcceptableOrUnknown(
              data['quantidade_rateada']!, _quantidadeRateadaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteInfNfCargaLacre map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteInfNfCargaLacre(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteInformacaoNfCarga: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_cte_informacao_nf_carga']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      quantidadeRateada: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_rateada']),
    );
  }

  @override
  $CteInfNfCargaLacresTable createAlias(String alias) {
    return $CteInfNfCargaLacresTable(attachedDatabase, alias);
  }
}

class CteInfNfCargaLacre extends DataClass
    implements Insertable<CteInfNfCargaLacre> {
  final int? id;
  final int? idCteInformacaoNfCarga;
  final String? numero;
  final double? quantidadeRateada;
  const CteInfNfCargaLacre(
      {this.id,
      this.idCteInformacaoNfCarga,
      this.numero,
      this.quantidadeRateada});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteInformacaoNfCarga != null) {
      map['id_cte_informacao_nf_carga'] = Variable<int>(idCteInformacaoNfCarga);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || quantidadeRateada != null) {
      map['quantidade_rateada'] = Variable<double>(quantidadeRateada);
    }
    return map;
  }

  factory CteInfNfCargaLacre.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteInfNfCargaLacre(
      id: serializer.fromJson<int?>(json['id']),
      idCteInformacaoNfCarga:
          serializer.fromJson<int?>(json['idCteInformacaoNfCarga']),
      numero: serializer.fromJson<String?>(json['numero']),
      quantidadeRateada:
          serializer.fromJson<double?>(json['quantidadeRateada']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteInformacaoNfCarga': serializer.toJson<int?>(idCteInformacaoNfCarga),
      'numero': serializer.toJson<String?>(numero),
      'quantidadeRateada': serializer.toJson<double?>(quantidadeRateada),
    };
  }

  CteInfNfCargaLacre copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteInformacaoNfCarga = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<double?> quantidadeRateada = const Value.absent()}) =>
      CteInfNfCargaLacre(
        id: id.present ? id.value : this.id,
        idCteInformacaoNfCarga: idCteInformacaoNfCarga.present
            ? idCteInformacaoNfCarga.value
            : this.idCteInformacaoNfCarga,
        numero: numero.present ? numero.value : this.numero,
        quantidadeRateada: quantidadeRateada.present
            ? quantidadeRateada.value
            : this.quantidadeRateada,
      );
  @override
  String toString() {
    return (StringBuffer('CteInfNfCargaLacre(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNfCarga: $idCteInformacaoNfCarga, ')
          ..write('numero: $numero, ')
          ..write('quantidadeRateada: $quantidadeRateada')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCteInformacaoNfCarga, numero, quantidadeRateada);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteInfNfCargaLacre &&
          other.id == this.id &&
          other.idCteInformacaoNfCarga == this.idCteInformacaoNfCarga &&
          other.numero == this.numero &&
          other.quantidadeRateada == this.quantidadeRateada);
}

class CteInfNfCargaLacresCompanion extends UpdateCompanion<CteInfNfCargaLacre> {
  final Value<int?> id;
  final Value<int?> idCteInformacaoNfCarga;
  final Value<String?> numero;
  final Value<double?> quantidadeRateada;
  const CteInfNfCargaLacresCompanion({
    this.id = const Value.absent(),
    this.idCteInformacaoNfCarga = const Value.absent(),
    this.numero = const Value.absent(),
    this.quantidadeRateada = const Value.absent(),
  });
  CteInfNfCargaLacresCompanion.insert({
    this.id = const Value.absent(),
    this.idCteInformacaoNfCarga = const Value.absent(),
    this.numero = const Value.absent(),
    this.quantidadeRateada = const Value.absent(),
  });
  static Insertable<CteInfNfCargaLacre> custom({
    Expression<int>? id,
    Expression<int>? idCteInformacaoNfCarga,
    Expression<String>? numero,
    Expression<double>? quantidadeRateada,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteInformacaoNfCarga != null)
        'id_cte_informacao_nf_carga': idCteInformacaoNfCarga,
      if (numero != null) 'numero': numero,
      if (quantidadeRateada != null) 'quantidade_rateada': quantidadeRateada,
    });
  }

  CteInfNfCargaLacresCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteInformacaoNfCarga,
      Value<String?>? numero,
      Value<double?>? quantidadeRateada}) {
    return CteInfNfCargaLacresCompanion(
      id: id ?? this.id,
      idCteInformacaoNfCarga:
          idCteInformacaoNfCarga ?? this.idCteInformacaoNfCarga,
      numero: numero ?? this.numero,
      quantidadeRateada: quantidadeRateada ?? this.quantidadeRateada,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteInformacaoNfCarga.present) {
      map['id_cte_informacao_nf_carga'] =
          Variable<int>(idCteInformacaoNfCarga.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (quantidadeRateada.present) {
      map['quantidade_rateada'] = Variable<double>(quantidadeRateada.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteInfNfCargaLacresCompanion(')
          ..write('id: $id, ')
          ..write('idCteInformacaoNfCarga: $idCteInformacaoNfCarga, ')
          ..write('numero: $numero, ')
          ..write('quantidadeRateada: $quantidadeRateada')
          ..write(')'))
        .toString();
  }
}

class $CteDocumentoAnteriorIdsTable extends CteDocumentoAnteriorIds
    with TableInfo<$CteDocumentoAnteriorIdsTable, CteDocumentoAnteriorId> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteDocumentoAnteriorIdsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteDocumentoAnteriorMeta =
      const VerificationMeta('idCteDocumentoAnterior');
  @override
  late final GeneratedColumn<int> idCteDocumentoAnterior = GeneratedColumn<int>(
      'id_cte_documento_anterior', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _subserieMeta =
      const VerificationMeta('subserie');
  @override
  late final GeneratedColumn<String> subserie = GeneratedColumn<String>(
      'subserie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _chaveCteMeta =
      const VerificationMeta('chaveCte');
  @override
  late final GeneratedColumn<String> chaveCte = GeneratedColumn<String>(
      'chave_cte', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteDocumentoAnterior,
        tipo,
        serie,
        subserie,
        numero,
        dataEmissao,
        chaveCte
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_documento_anterior_id';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteDocumentoAnteriorId> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_documento_anterior')) {
      context.handle(
          _idCteDocumentoAnteriorMeta,
          idCteDocumentoAnterior.isAcceptableOrUnknown(
              data['id_cte_documento_anterior']!, _idCteDocumentoAnteriorMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('subserie')) {
      context.handle(_subserieMeta,
          subserie.isAcceptableOrUnknown(data['subserie']!, _subserieMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('chave_cte')) {
      context.handle(_chaveCteMeta,
          chaveCte.isAcceptableOrUnknown(data['chave_cte']!, _chaveCteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteDocumentoAnteriorId map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteDocumentoAnteriorId(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteDocumentoAnterior: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_cte_documento_anterior']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      subserie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}subserie']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      chaveCte: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_cte']),
    );
  }

  @override
  $CteDocumentoAnteriorIdsTable createAlias(String alias) {
    return $CteDocumentoAnteriorIdsTable(attachedDatabase, alias);
  }
}

class CteDocumentoAnteriorId extends DataClass
    implements Insertable<CteDocumentoAnteriorId> {
  final int? id;
  final int? idCteDocumentoAnterior;
  final String? tipo;
  final String? serie;
  final String? subserie;
  final String? numero;
  final DateTime? dataEmissao;
  final String? chaveCte;
  const CteDocumentoAnteriorId(
      {this.id,
      this.idCteDocumentoAnterior,
      this.tipo,
      this.serie,
      this.subserie,
      this.numero,
      this.dataEmissao,
      this.chaveCte});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteDocumentoAnterior != null) {
      map['id_cte_documento_anterior'] = Variable<int>(idCteDocumentoAnterior);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || subserie != null) {
      map['subserie'] = Variable<String>(subserie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || chaveCte != null) {
      map['chave_cte'] = Variable<String>(chaveCte);
    }
    return map;
  }

  factory CteDocumentoAnteriorId.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteDocumentoAnteriorId(
      id: serializer.fromJson<int?>(json['id']),
      idCteDocumentoAnterior:
          serializer.fromJson<int?>(json['idCteDocumentoAnterior']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      serie: serializer.fromJson<String?>(json['serie']),
      subserie: serializer.fromJson<String?>(json['subserie']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      chaveCte: serializer.fromJson<String?>(json['chaveCte']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteDocumentoAnterior': serializer.toJson<int?>(idCteDocumentoAnterior),
      'tipo': serializer.toJson<String?>(tipo),
      'serie': serializer.toJson<String?>(serie),
      'subserie': serializer.toJson<String?>(subserie),
      'numero': serializer.toJson<String?>(numero),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'chaveCte': serializer.toJson<String?>(chaveCte),
    };
  }

  CteDocumentoAnteriorId copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteDocumentoAnterior = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> subserie = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<String?> chaveCte = const Value.absent()}) =>
      CteDocumentoAnteriorId(
        id: id.present ? id.value : this.id,
        idCteDocumentoAnterior: idCteDocumentoAnterior.present
            ? idCteDocumentoAnterior.value
            : this.idCteDocumentoAnterior,
        tipo: tipo.present ? tipo.value : this.tipo,
        serie: serie.present ? serie.value : this.serie,
        subserie: subserie.present ? subserie.value : this.subserie,
        numero: numero.present ? numero.value : this.numero,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        chaveCte: chaveCte.present ? chaveCte.value : this.chaveCte,
      );
  @override
  String toString() {
    return (StringBuffer('CteDocumentoAnteriorId(')
          ..write('id: $id, ')
          ..write('idCteDocumentoAnterior: $idCteDocumentoAnterior, ')
          ..write('tipo: $tipo, ')
          ..write('serie: $serie, ')
          ..write('subserie: $subserie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('chaveCte: $chaveCte')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteDocumentoAnterior, tipo, serie,
      subserie, numero, dataEmissao, chaveCte);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteDocumentoAnteriorId &&
          other.id == this.id &&
          other.idCteDocumentoAnterior == this.idCteDocumentoAnterior &&
          other.tipo == this.tipo &&
          other.serie == this.serie &&
          other.subserie == this.subserie &&
          other.numero == this.numero &&
          other.dataEmissao == this.dataEmissao &&
          other.chaveCte == this.chaveCte);
}

class CteDocumentoAnteriorIdsCompanion
    extends UpdateCompanion<CteDocumentoAnteriorId> {
  final Value<int?> id;
  final Value<int?> idCteDocumentoAnterior;
  final Value<String?> tipo;
  final Value<String?> serie;
  final Value<String?> subserie;
  final Value<String?> numero;
  final Value<DateTime?> dataEmissao;
  final Value<String?> chaveCte;
  const CteDocumentoAnteriorIdsCompanion({
    this.id = const Value.absent(),
    this.idCteDocumentoAnterior = const Value.absent(),
    this.tipo = const Value.absent(),
    this.serie = const Value.absent(),
    this.subserie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.chaveCte = const Value.absent(),
  });
  CteDocumentoAnteriorIdsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteDocumentoAnterior = const Value.absent(),
    this.tipo = const Value.absent(),
    this.serie = const Value.absent(),
    this.subserie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.chaveCte = const Value.absent(),
  });
  static Insertable<CteDocumentoAnteriorId> custom({
    Expression<int>? id,
    Expression<int>? idCteDocumentoAnterior,
    Expression<String>? tipo,
    Expression<String>? serie,
    Expression<String>? subserie,
    Expression<String>? numero,
    Expression<DateTime>? dataEmissao,
    Expression<String>? chaveCte,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteDocumentoAnterior != null)
        'id_cte_documento_anterior': idCteDocumentoAnterior,
      if (tipo != null) 'tipo': tipo,
      if (serie != null) 'serie': serie,
      if (subserie != null) 'subserie': subserie,
      if (numero != null) 'numero': numero,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (chaveCte != null) 'chave_cte': chaveCte,
    });
  }

  CteDocumentoAnteriorIdsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteDocumentoAnterior,
      Value<String?>? tipo,
      Value<String?>? serie,
      Value<String?>? subserie,
      Value<String?>? numero,
      Value<DateTime?>? dataEmissao,
      Value<String?>? chaveCte}) {
    return CteDocumentoAnteriorIdsCompanion(
      id: id ?? this.id,
      idCteDocumentoAnterior:
          idCteDocumentoAnterior ?? this.idCteDocumentoAnterior,
      tipo: tipo ?? this.tipo,
      serie: serie ?? this.serie,
      subserie: subserie ?? this.subserie,
      numero: numero ?? this.numero,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      chaveCte: chaveCte ?? this.chaveCte,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteDocumentoAnterior.present) {
      map['id_cte_documento_anterior'] =
          Variable<int>(idCteDocumentoAnterior.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (subserie.present) {
      map['subserie'] = Variable<String>(subserie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (chaveCte.present) {
      map['chave_cte'] = Variable<String>(chaveCte.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteDocumentoAnteriorIdsCompanion(')
          ..write('id: $id, ')
          ..write('idCteDocumentoAnterior: $idCteDocumentoAnterior, ')
          ..write('tipo: $tipo, ')
          ..write('serie: $serie, ')
          ..write('subserie: $subserie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('chaveCte: $chaveCte')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviarioOccsTable extends CteRodoviarioOccs
    with TableInfo<$CteRodoviarioOccsTable, CteRodoviarioOcc> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviarioOccsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteRodoviarioMeta =
      const VerificationMeta('idCteRodoviario');
  @override
  late final GeneratedColumn<int> idCteRodoviario = GeneratedColumn<int>(
      'id_cte_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
      'numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteRodoviario,
        serie,
        numero,
        dataEmissao,
        cnpj,
        codigoInterno,
        ie,
        uf,
        telefone
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario_occ';
  @override
  VerificationContext validateIntegrity(Insertable<CteRodoviarioOcc> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_rodoviario')) {
      context.handle(
          _idCteRodoviarioMeta,
          idCteRodoviario.isAcceptableOrUnknown(
              data['id_cte_rodoviario']!, _idCteRodoviarioMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviarioOcc map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviarioOcc(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_rodoviario']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
    );
  }

  @override
  $CteRodoviarioOccsTable createAlias(String alias) {
    return $CteRodoviarioOccsTable(attachedDatabase, alias);
  }
}

class CteRodoviarioOcc extends DataClass
    implements Insertable<CteRodoviarioOcc> {
  final int? id;
  final int? idCteRodoviario;
  final String? serie;
  final int? numero;
  final DateTime? dataEmissao;
  final String? cnpj;
  final String? codigoInterno;
  final String? ie;
  final String? uf;
  final String? telefone;
  const CteRodoviarioOcc(
      {this.id,
      this.idCteRodoviario,
      this.serie,
      this.numero,
      this.dataEmissao,
      this.cnpj,
      this.codigoInterno,
      this.ie,
      this.uf,
      this.telefone});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteRodoviario != null) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    return map;
  }

  factory CteRodoviarioOcc.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviarioOcc(
      id: serializer.fromJson<int?>(json['id']),
      idCteRodoviario: serializer.fromJson<int?>(json['idCteRodoviario']),
      serie: serializer.fromJson<String?>(json['serie']),
      numero: serializer.fromJson<int?>(json['numero']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      ie: serializer.fromJson<String?>(json['ie']),
      uf: serializer.fromJson<String?>(json['uf']),
      telefone: serializer.fromJson<String?>(json['telefone']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteRodoviario': serializer.toJson<int?>(idCteRodoviario),
      'serie': serializer.toJson<String?>(serie),
      'numero': serializer.toJson<int?>(numero),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'cnpj': serializer.toJson<String?>(cnpj),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'ie': serializer.toJson<String?>(ie),
      'uf': serializer.toJson<String?>(uf),
      'telefone': serializer.toJson<String?>(telefone),
    };
  }

  CteRodoviarioOcc copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteRodoviario = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<int?> numero = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> telefone = const Value.absent()}) =>
      CteRodoviarioOcc(
        id: id.present ? id.value : this.id,
        idCteRodoviario: idCteRodoviario.present
            ? idCteRodoviario.value
            : this.idCteRodoviario,
        serie: serie.present ? serie.value : this.serie,
        numero: numero.present ? numero.value : this.numero,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        ie: ie.present ? ie.value : this.ie,
        uf: uf.present ? uf.value : this.uf,
        telefone: telefone.present ? telefone.value : this.telefone,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviarioOcc(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('cnpj: $cnpj, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('ie: $ie, ')
          ..write('uf: $uf, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteRodoviario, serie, numero,
      dataEmissao, cnpj, codigoInterno, ie, uf, telefone);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviarioOcc &&
          other.id == this.id &&
          other.idCteRodoviario == this.idCteRodoviario &&
          other.serie == this.serie &&
          other.numero == this.numero &&
          other.dataEmissao == this.dataEmissao &&
          other.cnpj == this.cnpj &&
          other.codigoInterno == this.codigoInterno &&
          other.ie == this.ie &&
          other.uf == this.uf &&
          other.telefone == this.telefone);
}

class CteRodoviarioOccsCompanion extends UpdateCompanion<CteRodoviarioOcc> {
  final Value<int?> id;
  final Value<int?> idCteRodoviario;
  final Value<String?> serie;
  final Value<int?> numero;
  final Value<DateTime?> dataEmissao;
  final Value<String?> cnpj;
  final Value<String?> codigoInterno;
  final Value<String?> ie;
  final Value<String?> uf;
  final Value<String?> telefone;
  const CteRodoviarioOccsCompanion({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.ie = const Value.absent(),
    this.uf = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  CteRodoviarioOccsCompanion.insert({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.ie = const Value.absent(),
    this.uf = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  static Insertable<CteRodoviarioOcc> custom({
    Expression<int>? id,
    Expression<int>? idCteRodoviario,
    Expression<String>? serie,
    Expression<int>? numero,
    Expression<DateTime>? dataEmissao,
    Expression<String>? cnpj,
    Expression<String>? codigoInterno,
    Expression<String>? ie,
    Expression<String>? uf,
    Expression<String>? telefone,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteRodoviario != null) 'id_cte_rodoviario': idCteRodoviario,
      if (serie != null) 'serie': serie,
      if (numero != null) 'numero': numero,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (cnpj != null) 'cnpj': cnpj,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (ie != null) 'ie': ie,
      if (uf != null) 'uf': uf,
      if (telefone != null) 'telefone': telefone,
    });
  }

  CteRodoviarioOccsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteRodoviario,
      Value<String?>? serie,
      Value<int?>? numero,
      Value<DateTime?>? dataEmissao,
      Value<String?>? cnpj,
      Value<String?>? codigoInterno,
      Value<String?>? ie,
      Value<String?>? uf,
      Value<String?>? telefone}) {
    return CteRodoviarioOccsCompanion(
      id: id ?? this.id,
      idCteRodoviario: idCteRodoviario ?? this.idCteRodoviario,
      serie: serie ?? this.serie,
      numero: numero ?? this.numero,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      cnpj: cnpj ?? this.cnpj,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      ie: ie ?? this.ie,
      uf: uf ?? this.uf,
      telefone: telefone ?? this.telefone,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteRodoviario.present) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviarioOccsCompanion(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('cnpj: $cnpj, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('ie: $ie, ')
          ..write('uf: $uf, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviarioPedagiosTable extends CteRodoviarioPedagios
    with TableInfo<$CteRodoviarioPedagiosTable, CteRodoviarioPedagio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviarioPedagiosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteRodoviarioMeta =
      const VerificationMeta('idCteRodoviario');
  @override
  late final GeneratedColumn<int> idCteRodoviario = GeneratedColumn<int>(
      'id_cte_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjFornecedorMeta =
      const VerificationMeta('cnpjFornecedor');
  @override
  late final GeneratedColumn<String> cnpjFornecedor = GeneratedColumn<String>(
      'cnpj_fornecedor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _comprovanteCompraMeta =
      const VerificationMeta('comprovanteCompra');
  @override
  late final GeneratedColumn<String> comprovanteCompra =
      GeneratedColumn<String>('comprovante_compra', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _cnpjResponsavelMeta =
      const VerificationMeta('cnpjResponsavel');
  @override
  late final GeneratedColumn<String> cnpjResponsavel = GeneratedColumn<String>(
      'cnpj_responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteRodoviario,
        cnpjFornecedor,
        comprovanteCompra,
        cnpjResponsavel,
        valor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario_pedagio';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteRodoviarioPedagio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_rodoviario')) {
      context.handle(
          _idCteRodoviarioMeta,
          idCteRodoviario.isAcceptableOrUnknown(
              data['id_cte_rodoviario']!, _idCteRodoviarioMeta));
    }
    if (data.containsKey('cnpj_fornecedor')) {
      context.handle(
          _cnpjFornecedorMeta,
          cnpjFornecedor.isAcceptableOrUnknown(
              data['cnpj_fornecedor']!, _cnpjFornecedorMeta));
    }
    if (data.containsKey('comprovante_compra')) {
      context.handle(
          _comprovanteCompraMeta,
          comprovanteCompra.isAcceptableOrUnknown(
              data['comprovante_compra']!, _comprovanteCompraMeta));
    }
    if (data.containsKey('cnpj_responsavel')) {
      context.handle(
          _cnpjResponsavelMeta,
          cnpjResponsavel.isAcceptableOrUnknown(
              data['cnpj_responsavel']!, _cnpjResponsavelMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviarioPedagio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviarioPedagio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_rodoviario']),
      cnpjFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj_fornecedor']),
      comprovanteCompra: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}comprovante_compra']),
      cnpjResponsavel: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cnpj_responsavel']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $CteRodoviarioPedagiosTable createAlias(String alias) {
    return $CteRodoviarioPedagiosTable(attachedDatabase, alias);
  }
}

class CteRodoviarioPedagio extends DataClass
    implements Insertable<CteRodoviarioPedagio> {
  final int? id;
  final int? idCteRodoviario;
  final String? cnpjFornecedor;
  final String? comprovanteCompra;
  final String? cnpjResponsavel;
  final double? valor;
  const CteRodoviarioPedagio(
      {this.id,
      this.idCteRodoviario,
      this.cnpjFornecedor,
      this.comprovanteCompra,
      this.cnpjResponsavel,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteRodoviario != null) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario);
    }
    if (!nullToAbsent || cnpjFornecedor != null) {
      map['cnpj_fornecedor'] = Variable<String>(cnpjFornecedor);
    }
    if (!nullToAbsent || comprovanteCompra != null) {
      map['comprovante_compra'] = Variable<String>(comprovanteCompra);
    }
    if (!nullToAbsent || cnpjResponsavel != null) {
      map['cnpj_responsavel'] = Variable<String>(cnpjResponsavel);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory CteRodoviarioPedagio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviarioPedagio(
      id: serializer.fromJson<int?>(json['id']),
      idCteRodoviario: serializer.fromJson<int?>(json['idCteRodoviario']),
      cnpjFornecedor: serializer.fromJson<String?>(json['cnpjFornecedor']),
      comprovanteCompra:
          serializer.fromJson<String?>(json['comprovanteCompra']),
      cnpjResponsavel: serializer.fromJson<String?>(json['cnpjResponsavel']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteRodoviario': serializer.toJson<int?>(idCteRodoviario),
      'cnpjFornecedor': serializer.toJson<String?>(cnpjFornecedor),
      'comprovanteCompra': serializer.toJson<String?>(comprovanteCompra),
      'cnpjResponsavel': serializer.toJson<String?>(cnpjResponsavel),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  CteRodoviarioPedagio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteRodoviario = const Value.absent(),
          Value<String?> cnpjFornecedor = const Value.absent(),
          Value<String?> comprovanteCompra = const Value.absent(),
          Value<String?> cnpjResponsavel = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      CteRodoviarioPedagio(
        id: id.present ? id.value : this.id,
        idCteRodoviario: idCteRodoviario.present
            ? idCteRodoviario.value
            : this.idCteRodoviario,
        cnpjFornecedor:
            cnpjFornecedor.present ? cnpjFornecedor.value : this.cnpjFornecedor,
        comprovanteCompra: comprovanteCompra.present
            ? comprovanteCompra.value
            : this.comprovanteCompra,
        cnpjResponsavel: cnpjResponsavel.present
            ? cnpjResponsavel.value
            : this.cnpjResponsavel,
        valor: valor.present ? valor.value : this.valor,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviarioPedagio(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('cnpjFornecedor: $cnpjFornecedor, ')
          ..write('comprovanteCompra: $comprovanteCompra, ')
          ..write('cnpjResponsavel: $cnpjResponsavel, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteRodoviario, cnpjFornecedor,
      comprovanteCompra, cnpjResponsavel, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviarioPedagio &&
          other.id == this.id &&
          other.idCteRodoviario == this.idCteRodoviario &&
          other.cnpjFornecedor == this.cnpjFornecedor &&
          other.comprovanteCompra == this.comprovanteCompra &&
          other.cnpjResponsavel == this.cnpjResponsavel &&
          other.valor == this.valor);
}

class CteRodoviarioPedagiosCompanion
    extends UpdateCompanion<CteRodoviarioPedagio> {
  final Value<int?> id;
  final Value<int?> idCteRodoviario;
  final Value<String?> cnpjFornecedor;
  final Value<String?> comprovanteCompra;
  final Value<String?> cnpjResponsavel;
  final Value<double?> valor;
  const CteRodoviarioPedagiosCompanion({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.cnpjFornecedor = const Value.absent(),
    this.comprovanteCompra = const Value.absent(),
    this.cnpjResponsavel = const Value.absent(),
    this.valor = const Value.absent(),
  });
  CteRodoviarioPedagiosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.cnpjFornecedor = const Value.absent(),
    this.comprovanteCompra = const Value.absent(),
    this.cnpjResponsavel = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<CteRodoviarioPedagio> custom({
    Expression<int>? id,
    Expression<int>? idCteRodoviario,
    Expression<String>? cnpjFornecedor,
    Expression<String>? comprovanteCompra,
    Expression<String>? cnpjResponsavel,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteRodoviario != null) 'id_cte_rodoviario': idCteRodoviario,
      if (cnpjFornecedor != null) 'cnpj_fornecedor': cnpjFornecedor,
      if (comprovanteCompra != null) 'comprovante_compra': comprovanteCompra,
      if (cnpjResponsavel != null) 'cnpj_responsavel': cnpjResponsavel,
      if (valor != null) 'valor': valor,
    });
  }

  CteRodoviarioPedagiosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteRodoviario,
      Value<String?>? cnpjFornecedor,
      Value<String?>? comprovanteCompra,
      Value<String?>? cnpjResponsavel,
      Value<double?>? valor}) {
    return CteRodoviarioPedagiosCompanion(
      id: id ?? this.id,
      idCteRodoviario: idCteRodoviario ?? this.idCteRodoviario,
      cnpjFornecedor: cnpjFornecedor ?? this.cnpjFornecedor,
      comprovanteCompra: comprovanteCompra ?? this.comprovanteCompra,
      cnpjResponsavel: cnpjResponsavel ?? this.cnpjResponsavel,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteRodoviario.present) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario.value);
    }
    if (cnpjFornecedor.present) {
      map['cnpj_fornecedor'] = Variable<String>(cnpjFornecedor.value);
    }
    if (comprovanteCompra.present) {
      map['comprovante_compra'] = Variable<String>(comprovanteCompra.value);
    }
    if (cnpjResponsavel.present) {
      map['cnpj_responsavel'] = Variable<String>(cnpjResponsavel.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviarioPedagiosCompanion(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('cnpjFornecedor: $cnpjFornecedor, ')
          ..write('comprovanteCompra: $comprovanteCompra, ')
          ..write('cnpjResponsavel: $cnpjResponsavel, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviarioVeiculosTable extends CteRodoviarioVeiculos
    with TableInfo<$CteRodoviarioVeiculosTable, CteRodoviarioVeiculo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviarioVeiculosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteRodoviarioMeta =
      const VerificationMeta('idCteRodoviario');
  @override
  late final GeneratedColumn<int> idCteRodoviario = GeneratedColumn<int>(
      'id_cte_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _renavamMeta =
      const VerificationMeta('renavam');
  @override
  late final GeneratedColumn<String> renavam = GeneratedColumn<String>(
      'renavam', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _placaMeta = const VerificationMeta('placa');
  @override
  late final GeneratedColumn<String> placa = GeneratedColumn<String>(
      'placa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _taraMeta = const VerificationMeta('tara');
  @override
  late final GeneratedColumn<int> tara = GeneratedColumn<int>(
      'tara', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _capacidadeKgMeta =
      const VerificationMeta('capacidadeKg');
  @override
  late final GeneratedColumn<int> capacidadeKg = GeneratedColumn<int>(
      'capacidade_kg', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _capacidadeM3Meta =
      const VerificationMeta('capacidadeM3');
  @override
  late final GeneratedColumn<int> capacidadeM3 = GeneratedColumn<int>(
      'capacidade_m3', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoPropriedadeMeta =
      const VerificationMeta('tipoPropriedade');
  @override
  late final GeneratedColumn<String> tipoPropriedade = GeneratedColumn<String>(
      'tipo_propriedade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoVeiculoMeta =
      const VerificationMeta('tipoVeiculo');
  @override
  late final GeneratedColumn<String> tipoVeiculo = GeneratedColumn<String>(
      'tipo_veiculo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoRodadoMeta =
      const VerificationMeta('tipoRodado');
  @override
  late final GeneratedColumn<String> tipoRodado = GeneratedColumn<String>(
      'tipo_rodado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoCarroceriaMeta =
      const VerificationMeta('tipoCarroceria');
  @override
  late final GeneratedColumn<String> tipoCarroceria = GeneratedColumn<String>(
      'tipo_carroceria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioCpfMeta =
      const VerificationMeta('proprietarioCpf');
  @override
  late final GeneratedColumn<String> proprietarioCpf = GeneratedColumn<String>(
      'proprietario_cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioCnpjMeta =
      const VerificationMeta('proprietarioCnpj');
  @override
  late final GeneratedColumn<String> proprietarioCnpj = GeneratedColumn<String>(
      'proprietario_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioRntrcMeta =
      const VerificationMeta('proprietarioRntrc');
  @override
  late final GeneratedColumn<String> proprietarioRntrc =
      GeneratedColumn<String>('proprietario_rntrc', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _proprietarioNomeMeta =
      const VerificationMeta('proprietarioNome');
  @override
  late final GeneratedColumn<String> proprietarioNome = GeneratedColumn<String>(
      'proprietario_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioIeMeta =
      const VerificationMeta('proprietarioIe');
  @override
  late final GeneratedColumn<String> proprietarioIe = GeneratedColumn<String>(
      'proprietario_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioUfMeta =
      const VerificationMeta('proprietarioUf');
  @override
  late final GeneratedColumn<String> proprietarioUf = GeneratedColumn<String>(
      'proprietario_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioTipoMeta =
      const VerificationMeta('proprietarioTipo');
  @override
  late final GeneratedColumn<String> proprietarioTipo = GeneratedColumn<String>(
      'proprietario_tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteRodoviario,
        codigoInterno,
        renavam,
        placa,
        tara,
        capacidadeKg,
        capacidadeM3,
        tipoPropriedade,
        tipoVeiculo,
        tipoRodado,
        tipoCarroceria,
        uf,
        proprietarioCpf,
        proprietarioCnpj,
        proprietarioRntrc,
        proprietarioNome,
        proprietarioIe,
        proprietarioUf,
        proprietarioTipo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario_veiculo';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteRodoviarioVeiculo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_rodoviario')) {
      context.handle(
          _idCteRodoviarioMeta,
          idCteRodoviario.isAcceptableOrUnknown(
              data['id_cte_rodoviario']!, _idCteRodoviarioMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('renavam')) {
      context.handle(_renavamMeta,
          renavam.isAcceptableOrUnknown(data['renavam']!, _renavamMeta));
    }
    if (data.containsKey('placa')) {
      context.handle(
          _placaMeta, placa.isAcceptableOrUnknown(data['placa']!, _placaMeta));
    }
    if (data.containsKey('tara')) {
      context.handle(
          _taraMeta, tara.isAcceptableOrUnknown(data['tara']!, _taraMeta));
    }
    if (data.containsKey('capacidade_kg')) {
      context.handle(
          _capacidadeKgMeta,
          capacidadeKg.isAcceptableOrUnknown(
              data['capacidade_kg']!, _capacidadeKgMeta));
    }
    if (data.containsKey('capacidade_m3')) {
      context.handle(
          _capacidadeM3Meta,
          capacidadeM3.isAcceptableOrUnknown(
              data['capacidade_m3']!, _capacidadeM3Meta));
    }
    if (data.containsKey('tipo_propriedade')) {
      context.handle(
          _tipoPropriedadeMeta,
          tipoPropriedade.isAcceptableOrUnknown(
              data['tipo_propriedade']!, _tipoPropriedadeMeta));
    }
    if (data.containsKey('tipo_veiculo')) {
      context.handle(
          _tipoVeiculoMeta,
          tipoVeiculo.isAcceptableOrUnknown(
              data['tipo_veiculo']!, _tipoVeiculoMeta));
    }
    if (data.containsKey('tipo_rodado')) {
      context.handle(
          _tipoRodadoMeta,
          tipoRodado.isAcceptableOrUnknown(
              data['tipo_rodado']!, _tipoRodadoMeta));
    }
    if (data.containsKey('tipo_carroceria')) {
      context.handle(
          _tipoCarroceriaMeta,
          tipoCarroceria.isAcceptableOrUnknown(
              data['tipo_carroceria']!, _tipoCarroceriaMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('proprietario_cpf')) {
      context.handle(
          _proprietarioCpfMeta,
          proprietarioCpf.isAcceptableOrUnknown(
              data['proprietario_cpf']!, _proprietarioCpfMeta));
    }
    if (data.containsKey('proprietario_cnpj')) {
      context.handle(
          _proprietarioCnpjMeta,
          proprietarioCnpj.isAcceptableOrUnknown(
              data['proprietario_cnpj']!, _proprietarioCnpjMeta));
    }
    if (data.containsKey('proprietario_rntrc')) {
      context.handle(
          _proprietarioRntrcMeta,
          proprietarioRntrc.isAcceptableOrUnknown(
              data['proprietario_rntrc']!, _proprietarioRntrcMeta));
    }
    if (data.containsKey('proprietario_nome')) {
      context.handle(
          _proprietarioNomeMeta,
          proprietarioNome.isAcceptableOrUnknown(
              data['proprietario_nome']!, _proprietarioNomeMeta));
    }
    if (data.containsKey('proprietario_ie')) {
      context.handle(
          _proprietarioIeMeta,
          proprietarioIe.isAcceptableOrUnknown(
              data['proprietario_ie']!, _proprietarioIeMeta));
    }
    if (data.containsKey('proprietario_uf')) {
      context.handle(
          _proprietarioUfMeta,
          proprietarioUf.isAcceptableOrUnknown(
              data['proprietario_uf']!, _proprietarioUfMeta));
    }
    if (data.containsKey('proprietario_tipo')) {
      context.handle(
          _proprietarioTipoMeta,
          proprietarioTipo.isAcceptableOrUnknown(
              data['proprietario_tipo']!, _proprietarioTipoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviarioVeiculo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviarioVeiculo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_rodoviario']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      renavam: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}renavam']),
      placa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}placa']),
      tara: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}tara']),
      capacidadeKg: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}capacidade_kg']),
      capacidadeM3: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}capacidade_m3']),
      tipoPropriedade: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tipo_propriedade']),
      tipoVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_veiculo']),
      tipoRodado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_rodado']),
      tipoCarroceria: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_carroceria']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      proprietarioCpf: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_cpf']),
      proprietarioCnpj: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_cnpj']),
      proprietarioRntrc: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_rntrc']),
      proprietarioNome: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_nome']),
      proprietarioIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}proprietario_ie']),
      proprietarioUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}proprietario_uf']),
      proprietarioTipo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_tipo']),
    );
  }

  @override
  $CteRodoviarioVeiculosTable createAlias(String alias) {
    return $CteRodoviarioVeiculosTable(attachedDatabase, alias);
  }
}

class CteRodoviarioVeiculo extends DataClass
    implements Insertable<CteRodoviarioVeiculo> {
  final int? id;
  final int? idCteRodoviario;
  final String? codigoInterno;
  final String? renavam;
  final String? placa;
  final int? tara;
  final int? capacidadeKg;
  final int? capacidadeM3;
  final String? tipoPropriedade;
  final String? tipoVeiculo;
  final String? tipoRodado;
  final String? tipoCarroceria;
  final String? uf;
  final String? proprietarioCpf;
  final String? proprietarioCnpj;
  final String? proprietarioRntrc;
  final String? proprietarioNome;
  final String? proprietarioIe;
  final String? proprietarioUf;
  final String? proprietarioTipo;
  const CteRodoviarioVeiculo(
      {this.id,
      this.idCteRodoviario,
      this.codigoInterno,
      this.renavam,
      this.placa,
      this.tara,
      this.capacidadeKg,
      this.capacidadeM3,
      this.tipoPropriedade,
      this.tipoVeiculo,
      this.tipoRodado,
      this.tipoCarroceria,
      this.uf,
      this.proprietarioCpf,
      this.proprietarioCnpj,
      this.proprietarioRntrc,
      this.proprietarioNome,
      this.proprietarioIe,
      this.proprietarioUf,
      this.proprietarioTipo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteRodoviario != null) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || renavam != null) {
      map['renavam'] = Variable<String>(renavam);
    }
    if (!nullToAbsent || placa != null) {
      map['placa'] = Variable<String>(placa);
    }
    if (!nullToAbsent || tara != null) {
      map['tara'] = Variable<int>(tara);
    }
    if (!nullToAbsent || capacidadeKg != null) {
      map['capacidade_kg'] = Variable<int>(capacidadeKg);
    }
    if (!nullToAbsent || capacidadeM3 != null) {
      map['capacidade_m3'] = Variable<int>(capacidadeM3);
    }
    if (!nullToAbsent || tipoPropriedade != null) {
      map['tipo_propriedade'] = Variable<String>(tipoPropriedade);
    }
    if (!nullToAbsent || tipoVeiculo != null) {
      map['tipo_veiculo'] = Variable<String>(tipoVeiculo);
    }
    if (!nullToAbsent || tipoRodado != null) {
      map['tipo_rodado'] = Variable<String>(tipoRodado);
    }
    if (!nullToAbsent || tipoCarroceria != null) {
      map['tipo_carroceria'] = Variable<String>(tipoCarroceria);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || proprietarioCpf != null) {
      map['proprietario_cpf'] = Variable<String>(proprietarioCpf);
    }
    if (!nullToAbsent || proprietarioCnpj != null) {
      map['proprietario_cnpj'] = Variable<String>(proprietarioCnpj);
    }
    if (!nullToAbsent || proprietarioRntrc != null) {
      map['proprietario_rntrc'] = Variable<String>(proprietarioRntrc);
    }
    if (!nullToAbsent || proprietarioNome != null) {
      map['proprietario_nome'] = Variable<String>(proprietarioNome);
    }
    if (!nullToAbsent || proprietarioIe != null) {
      map['proprietario_ie'] = Variable<String>(proprietarioIe);
    }
    if (!nullToAbsent || proprietarioUf != null) {
      map['proprietario_uf'] = Variable<String>(proprietarioUf);
    }
    if (!nullToAbsent || proprietarioTipo != null) {
      map['proprietario_tipo'] = Variable<String>(proprietarioTipo);
    }
    return map;
  }

  factory CteRodoviarioVeiculo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviarioVeiculo(
      id: serializer.fromJson<int?>(json['id']),
      idCteRodoviario: serializer.fromJson<int?>(json['idCteRodoviario']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      renavam: serializer.fromJson<String?>(json['renavam']),
      placa: serializer.fromJson<String?>(json['placa']),
      tara: serializer.fromJson<int?>(json['tara']),
      capacidadeKg: serializer.fromJson<int?>(json['capacidadeKg']),
      capacidadeM3: serializer.fromJson<int?>(json['capacidadeM3']),
      tipoPropriedade: serializer.fromJson<String?>(json['tipoPropriedade']),
      tipoVeiculo: serializer.fromJson<String?>(json['tipoVeiculo']),
      tipoRodado: serializer.fromJson<String?>(json['tipoRodado']),
      tipoCarroceria: serializer.fromJson<String?>(json['tipoCarroceria']),
      uf: serializer.fromJson<String?>(json['uf']),
      proprietarioCpf: serializer.fromJson<String?>(json['proprietarioCpf']),
      proprietarioCnpj: serializer.fromJson<String?>(json['proprietarioCnpj']),
      proprietarioRntrc:
          serializer.fromJson<String?>(json['proprietarioRntrc']),
      proprietarioNome: serializer.fromJson<String?>(json['proprietarioNome']),
      proprietarioIe: serializer.fromJson<String?>(json['proprietarioIe']),
      proprietarioUf: serializer.fromJson<String?>(json['proprietarioUf']),
      proprietarioTipo: serializer.fromJson<String?>(json['proprietarioTipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteRodoviario': serializer.toJson<int?>(idCteRodoviario),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'renavam': serializer.toJson<String?>(renavam),
      'placa': serializer.toJson<String?>(placa),
      'tara': serializer.toJson<int?>(tara),
      'capacidadeKg': serializer.toJson<int?>(capacidadeKg),
      'capacidadeM3': serializer.toJson<int?>(capacidadeM3),
      'tipoPropriedade': serializer.toJson<String?>(tipoPropriedade),
      'tipoVeiculo': serializer.toJson<String?>(tipoVeiculo),
      'tipoRodado': serializer.toJson<String?>(tipoRodado),
      'tipoCarroceria': serializer.toJson<String?>(tipoCarroceria),
      'uf': serializer.toJson<String?>(uf),
      'proprietarioCpf': serializer.toJson<String?>(proprietarioCpf),
      'proprietarioCnpj': serializer.toJson<String?>(proprietarioCnpj),
      'proprietarioRntrc': serializer.toJson<String?>(proprietarioRntrc),
      'proprietarioNome': serializer.toJson<String?>(proprietarioNome),
      'proprietarioIe': serializer.toJson<String?>(proprietarioIe),
      'proprietarioUf': serializer.toJson<String?>(proprietarioUf),
      'proprietarioTipo': serializer.toJson<String?>(proprietarioTipo),
    };
  }

  CteRodoviarioVeiculo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteRodoviario = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<String?> renavam = const Value.absent(),
          Value<String?> placa = const Value.absent(),
          Value<int?> tara = const Value.absent(),
          Value<int?> capacidadeKg = const Value.absent(),
          Value<int?> capacidadeM3 = const Value.absent(),
          Value<String?> tipoPropriedade = const Value.absent(),
          Value<String?> tipoVeiculo = const Value.absent(),
          Value<String?> tipoRodado = const Value.absent(),
          Value<String?> tipoCarroceria = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> proprietarioCpf = const Value.absent(),
          Value<String?> proprietarioCnpj = const Value.absent(),
          Value<String?> proprietarioRntrc = const Value.absent(),
          Value<String?> proprietarioNome = const Value.absent(),
          Value<String?> proprietarioIe = const Value.absent(),
          Value<String?> proprietarioUf = const Value.absent(),
          Value<String?> proprietarioTipo = const Value.absent()}) =>
      CteRodoviarioVeiculo(
        id: id.present ? id.value : this.id,
        idCteRodoviario: idCteRodoviario.present
            ? idCteRodoviario.value
            : this.idCteRodoviario,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        renavam: renavam.present ? renavam.value : this.renavam,
        placa: placa.present ? placa.value : this.placa,
        tara: tara.present ? tara.value : this.tara,
        capacidadeKg:
            capacidadeKg.present ? capacidadeKg.value : this.capacidadeKg,
        capacidadeM3:
            capacidadeM3.present ? capacidadeM3.value : this.capacidadeM3,
        tipoPropriedade: tipoPropriedade.present
            ? tipoPropriedade.value
            : this.tipoPropriedade,
        tipoVeiculo: tipoVeiculo.present ? tipoVeiculo.value : this.tipoVeiculo,
        tipoRodado: tipoRodado.present ? tipoRodado.value : this.tipoRodado,
        tipoCarroceria:
            tipoCarroceria.present ? tipoCarroceria.value : this.tipoCarroceria,
        uf: uf.present ? uf.value : this.uf,
        proprietarioCpf: proprietarioCpf.present
            ? proprietarioCpf.value
            : this.proprietarioCpf,
        proprietarioCnpj: proprietarioCnpj.present
            ? proprietarioCnpj.value
            : this.proprietarioCnpj,
        proprietarioRntrc: proprietarioRntrc.present
            ? proprietarioRntrc.value
            : this.proprietarioRntrc,
        proprietarioNome: proprietarioNome.present
            ? proprietarioNome.value
            : this.proprietarioNome,
        proprietarioIe:
            proprietarioIe.present ? proprietarioIe.value : this.proprietarioIe,
        proprietarioUf:
            proprietarioUf.present ? proprietarioUf.value : this.proprietarioUf,
        proprietarioTipo: proprietarioTipo.present
            ? proprietarioTipo.value
            : this.proprietarioTipo,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviarioVeiculo(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('renavam: $renavam, ')
          ..write('placa: $placa, ')
          ..write('tara: $tara, ')
          ..write('capacidadeKg: $capacidadeKg, ')
          ..write('capacidadeM3: $capacidadeM3, ')
          ..write('tipoPropriedade: $tipoPropriedade, ')
          ..write('tipoVeiculo: $tipoVeiculo, ')
          ..write('tipoRodado: $tipoRodado, ')
          ..write('tipoCarroceria: $tipoCarroceria, ')
          ..write('uf: $uf, ')
          ..write('proprietarioCpf: $proprietarioCpf, ')
          ..write('proprietarioCnpj: $proprietarioCnpj, ')
          ..write('proprietarioRntrc: $proprietarioRntrc, ')
          ..write('proprietarioNome: $proprietarioNome, ')
          ..write('proprietarioIe: $proprietarioIe, ')
          ..write('proprietarioUf: $proprietarioUf, ')
          ..write('proprietarioTipo: $proprietarioTipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteRodoviario,
      codigoInterno,
      renavam,
      placa,
      tara,
      capacidadeKg,
      capacidadeM3,
      tipoPropriedade,
      tipoVeiculo,
      tipoRodado,
      tipoCarroceria,
      uf,
      proprietarioCpf,
      proprietarioCnpj,
      proprietarioRntrc,
      proprietarioNome,
      proprietarioIe,
      proprietarioUf,
      proprietarioTipo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviarioVeiculo &&
          other.id == this.id &&
          other.idCteRodoviario == this.idCteRodoviario &&
          other.codigoInterno == this.codigoInterno &&
          other.renavam == this.renavam &&
          other.placa == this.placa &&
          other.tara == this.tara &&
          other.capacidadeKg == this.capacidadeKg &&
          other.capacidadeM3 == this.capacidadeM3 &&
          other.tipoPropriedade == this.tipoPropriedade &&
          other.tipoVeiculo == this.tipoVeiculo &&
          other.tipoRodado == this.tipoRodado &&
          other.tipoCarroceria == this.tipoCarroceria &&
          other.uf == this.uf &&
          other.proprietarioCpf == this.proprietarioCpf &&
          other.proprietarioCnpj == this.proprietarioCnpj &&
          other.proprietarioRntrc == this.proprietarioRntrc &&
          other.proprietarioNome == this.proprietarioNome &&
          other.proprietarioIe == this.proprietarioIe &&
          other.proprietarioUf == this.proprietarioUf &&
          other.proprietarioTipo == this.proprietarioTipo);
}

class CteRodoviarioVeiculosCompanion
    extends UpdateCompanion<CteRodoviarioVeiculo> {
  final Value<int?> id;
  final Value<int?> idCteRodoviario;
  final Value<String?> codigoInterno;
  final Value<String?> renavam;
  final Value<String?> placa;
  final Value<int?> tara;
  final Value<int?> capacidadeKg;
  final Value<int?> capacidadeM3;
  final Value<String?> tipoPropriedade;
  final Value<String?> tipoVeiculo;
  final Value<String?> tipoRodado;
  final Value<String?> tipoCarroceria;
  final Value<String?> uf;
  final Value<String?> proprietarioCpf;
  final Value<String?> proprietarioCnpj;
  final Value<String?> proprietarioRntrc;
  final Value<String?> proprietarioNome;
  final Value<String?> proprietarioIe;
  final Value<String?> proprietarioUf;
  final Value<String?> proprietarioTipo;
  const CteRodoviarioVeiculosCompanion({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.renavam = const Value.absent(),
    this.placa = const Value.absent(),
    this.tara = const Value.absent(),
    this.capacidadeKg = const Value.absent(),
    this.capacidadeM3 = const Value.absent(),
    this.tipoPropriedade = const Value.absent(),
    this.tipoVeiculo = const Value.absent(),
    this.tipoRodado = const Value.absent(),
    this.tipoCarroceria = const Value.absent(),
    this.uf = const Value.absent(),
    this.proprietarioCpf = const Value.absent(),
    this.proprietarioCnpj = const Value.absent(),
    this.proprietarioRntrc = const Value.absent(),
    this.proprietarioNome = const Value.absent(),
    this.proprietarioIe = const Value.absent(),
    this.proprietarioUf = const Value.absent(),
    this.proprietarioTipo = const Value.absent(),
  });
  CteRodoviarioVeiculosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.renavam = const Value.absent(),
    this.placa = const Value.absent(),
    this.tara = const Value.absent(),
    this.capacidadeKg = const Value.absent(),
    this.capacidadeM3 = const Value.absent(),
    this.tipoPropriedade = const Value.absent(),
    this.tipoVeiculo = const Value.absent(),
    this.tipoRodado = const Value.absent(),
    this.tipoCarroceria = const Value.absent(),
    this.uf = const Value.absent(),
    this.proprietarioCpf = const Value.absent(),
    this.proprietarioCnpj = const Value.absent(),
    this.proprietarioRntrc = const Value.absent(),
    this.proprietarioNome = const Value.absent(),
    this.proprietarioIe = const Value.absent(),
    this.proprietarioUf = const Value.absent(),
    this.proprietarioTipo = const Value.absent(),
  });
  static Insertable<CteRodoviarioVeiculo> custom({
    Expression<int>? id,
    Expression<int>? idCteRodoviario,
    Expression<String>? codigoInterno,
    Expression<String>? renavam,
    Expression<String>? placa,
    Expression<int>? tara,
    Expression<int>? capacidadeKg,
    Expression<int>? capacidadeM3,
    Expression<String>? tipoPropriedade,
    Expression<String>? tipoVeiculo,
    Expression<String>? tipoRodado,
    Expression<String>? tipoCarroceria,
    Expression<String>? uf,
    Expression<String>? proprietarioCpf,
    Expression<String>? proprietarioCnpj,
    Expression<String>? proprietarioRntrc,
    Expression<String>? proprietarioNome,
    Expression<String>? proprietarioIe,
    Expression<String>? proprietarioUf,
    Expression<String>? proprietarioTipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteRodoviario != null) 'id_cte_rodoviario': idCteRodoviario,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (renavam != null) 'renavam': renavam,
      if (placa != null) 'placa': placa,
      if (tara != null) 'tara': tara,
      if (capacidadeKg != null) 'capacidade_kg': capacidadeKg,
      if (capacidadeM3 != null) 'capacidade_m3': capacidadeM3,
      if (tipoPropriedade != null) 'tipo_propriedade': tipoPropriedade,
      if (tipoVeiculo != null) 'tipo_veiculo': tipoVeiculo,
      if (tipoRodado != null) 'tipo_rodado': tipoRodado,
      if (tipoCarroceria != null) 'tipo_carroceria': tipoCarroceria,
      if (uf != null) 'uf': uf,
      if (proprietarioCpf != null) 'proprietario_cpf': proprietarioCpf,
      if (proprietarioCnpj != null) 'proprietario_cnpj': proprietarioCnpj,
      if (proprietarioRntrc != null) 'proprietario_rntrc': proprietarioRntrc,
      if (proprietarioNome != null) 'proprietario_nome': proprietarioNome,
      if (proprietarioIe != null) 'proprietario_ie': proprietarioIe,
      if (proprietarioUf != null) 'proprietario_uf': proprietarioUf,
      if (proprietarioTipo != null) 'proprietario_tipo': proprietarioTipo,
    });
  }

  CteRodoviarioVeiculosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteRodoviario,
      Value<String?>? codigoInterno,
      Value<String?>? renavam,
      Value<String?>? placa,
      Value<int?>? tara,
      Value<int?>? capacidadeKg,
      Value<int?>? capacidadeM3,
      Value<String?>? tipoPropriedade,
      Value<String?>? tipoVeiculo,
      Value<String?>? tipoRodado,
      Value<String?>? tipoCarroceria,
      Value<String?>? uf,
      Value<String?>? proprietarioCpf,
      Value<String?>? proprietarioCnpj,
      Value<String?>? proprietarioRntrc,
      Value<String?>? proprietarioNome,
      Value<String?>? proprietarioIe,
      Value<String?>? proprietarioUf,
      Value<String?>? proprietarioTipo}) {
    return CteRodoviarioVeiculosCompanion(
      id: id ?? this.id,
      idCteRodoviario: idCteRodoviario ?? this.idCteRodoviario,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      renavam: renavam ?? this.renavam,
      placa: placa ?? this.placa,
      tara: tara ?? this.tara,
      capacidadeKg: capacidadeKg ?? this.capacidadeKg,
      capacidadeM3: capacidadeM3 ?? this.capacidadeM3,
      tipoPropriedade: tipoPropriedade ?? this.tipoPropriedade,
      tipoVeiculo: tipoVeiculo ?? this.tipoVeiculo,
      tipoRodado: tipoRodado ?? this.tipoRodado,
      tipoCarroceria: tipoCarroceria ?? this.tipoCarroceria,
      uf: uf ?? this.uf,
      proprietarioCpf: proprietarioCpf ?? this.proprietarioCpf,
      proprietarioCnpj: proprietarioCnpj ?? this.proprietarioCnpj,
      proprietarioRntrc: proprietarioRntrc ?? this.proprietarioRntrc,
      proprietarioNome: proprietarioNome ?? this.proprietarioNome,
      proprietarioIe: proprietarioIe ?? this.proprietarioIe,
      proprietarioUf: proprietarioUf ?? this.proprietarioUf,
      proprietarioTipo: proprietarioTipo ?? this.proprietarioTipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteRodoviario.present) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (renavam.present) {
      map['renavam'] = Variable<String>(renavam.value);
    }
    if (placa.present) {
      map['placa'] = Variable<String>(placa.value);
    }
    if (tara.present) {
      map['tara'] = Variable<int>(tara.value);
    }
    if (capacidadeKg.present) {
      map['capacidade_kg'] = Variable<int>(capacidadeKg.value);
    }
    if (capacidadeM3.present) {
      map['capacidade_m3'] = Variable<int>(capacidadeM3.value);
    }
    if (tipoPropriedade.present) {
      map['tipo_propriedade'] = Variable<String>(tipoPropriedade.value);
    }
    if (tipoVeiculo.present) {
      map['tipo_veiculo'] = Variable<String>(tipoVeiculo.value);
    }
    if (tipoRodado.present) {
      map['tipo_rodado'] = Variable<String>(tipoRodado.value);
    }
    if (tipoCarroceria.present) {
      map['tipo_carroceria'] = Variable<String>(tipoCarroceria.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (proprietarioCpf.present) {
      map['proprietario_cpf'] = Variable<String>(proprietarioCpf.value);
    }
    if (proprietarioCnpj.present) {
      map['proprietario_cnpj'] = Variable<String>(proprietarioCnpj.value);
    }
    if (proprietarioRntrc.present) {
      map['proprietario_rntrc'] = Variable<String>(proprietarioRntrc.value);
    }
    if (proprietarioNome.present) {
      map['proprietario_nome'] = Variable<String>(proprietarioNome.value);
    }
    if (proprietarioIe.present) {
      map['proprietario_ie'] = Variable<String>(proprietarioIe.value);
    }
    if (proprietarioUf.present) {
      map['proprietario_uf'] = Variable<String>(proprietarioUf.value);
    }
    if (proprietarioTipo.present) {
      map['proprietario_tipo'] = Variable<String>(proprietarioTipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviarioVeiculosCompanion(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('renavam: $renavam, ')
          ..write('placa: $placa, ')
          ..write('tara: $tara, ')
          ..write('capacidadeKg: $capacidadeKg, ')
          ..write('capacidadeM3: $capacidadeM3, ')
          ..write('tipoPropriedade: $tipoPropriedade, ')
          ..write('tipoVeiculo: $tipoVeiculo, ')
          ..write('tipoRodado: $tipoRodado, ')
          ..write('tipoCarroceria: $tipoCarroceria, ')
          ..write('uf: $uf, ')
          ..write('proprietarioCpf: $proprietarioCpf, ')
          ..write('proprietarioCnpj: $proprietarioCnpj, ')
          ..write('proprietarioRntrc: $proprietarioRntrc, ')
          ..write('proprietarioNome: $proprietarioNome, ')
          ..write('proprietarioIe: $proprietarioIe, ')
          ..write('proprietarioUf: $proprietarioUf, ')
          ..write('proprietarioTipo: $proprietarioTipo')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviarioLacresTable extends CteRodoviarioLacres
    with TableInfo<$CteRodoviarioLacresTable, CteRodoviarioLacre> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviarioLacresTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteRodoviarioMeta =
      const VerificationMeta('idCteRodoviario');
  @override
  late final GeneratedColumn<int> idCteRodoviario = GeneratedColumn<int>(
      'id_cte_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idCteRodoviario, numero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario_lacre';
  @override
  VerificationContext validateIntegrity(Insertable<CteRodoviarioLacre> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_rodoviario')) {
      context.handle(
          _idCteRodoviarioMeta,
          idCteRodoviario.isAcceptableOrUnknown(
              data['id_cte_rodoviario']!, _idCteRodoviarioMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviarioLacre map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviarioLacre(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_rodoviario']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
    );
  }

  @override
  $CteRodoviarioLacresTable createAlias(String alias) {
    return $CteRodoviarioLacresTable(attachedDatabase, alias);
  }
}

class CteRodoviarioLacre extends DataClass
    implements Insertable<CteRodoviarioLacre> {
  final int? id;
  final int? idCteRodoviario;
  final String? numero;
  const CteRodoviarioLacre({this.id, this.idCteRodoviario, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteRodoviario != null) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory CteRodoviarioLacre.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviarioLacre(
      id: serializer.fromJson<int?>(json['id']),
      idCteRodoviario: serializer.fromJson<int?>(json['idCteRodoviario']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteRodoviario': serializer.toJson<int?>(idCteRodoviario),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  CteRodoviarioLacre copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteRodoviario = const Value.absent(),
          Value<String?> numero = const Value.absent()}) =>
      CteRodoviarioLacre(
        id: id.present ? id.value : this.id,
        idCteRodoviario: idCteRodoviario.present
            ? idCteRodoviario.value
            : this.idCteRodoviario,
        numero: numero.present ? numero.value : this.numero,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviarioLacre(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteRodoviario, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviarioLacre &&
          other.id == this.id &&
          other.idCteRodoviario == this.idCteRodoviario &&
          other.numero == this.numero);
}

class CteRodoviarioLacresCompanion extends UpdateCompanion<CteRodoviarioLacre> {
  final Value<int?> id;
  final Value<int?> idCteRodoviario;
  final Value<String?> numero;
  const CteRodoviarioLacresCompanion({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.numero = const Value.absent(),
  });
  CteRodoviarioLacresCompanion.insert({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<CteRodoviarioLacre> custom({
    Expression<int>? id,
    Expression<int>? idCteRodoviario,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteRodoviario != null) 'id_cte_rodoviario': idCteRodoviario,
      if (numero != null) 'numero': numero,
    });
  }

  CteRodoviarioLacresCompanion copyWith(
      {Value<int?>? id, Value<int?>? idCteRodoviario, Value<String?>? numero}) {
    return CteRodoviarioLacresCompanion(
      id: id ?? this.id,
      idCteRodoviario: idCteRodoviario ?? this.idCteRodoviario,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteRodoviario.present) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviarioLacresCompanion(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $CteRodoviarioMotoristasTable extends CteRodoviarioMotoristas
    with TableInfo<$CteRodoviarioMotoristasTable, CteRodoviarioMotorista> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteRodoviarioMotoristasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteRodoviarioMeta =
      const VerificationMeta('idCteRodoviario');
  @override
  late final GeneratedColumn<int> idCteRodoviario = GeneratedColumn<int>(
      'id_cte_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idCteRodoviario, nome, cpf];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_rodoviario_motorista';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteRodoviarioMotorista> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_rodoviario')) {
      context.handle(
          _idCteRodoviarioMeta,
          idCteRodoviario.isAcceptableOrUnknown(
              data['id_cte_rodoviario']!, _idCteRodoviarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteRodoviarioMotorista map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteRodoviarioMotorista(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_rodoviario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
    );
  }

  @override
  $CteRodoviarioMotoristasTable createAlias(String alias) {
    return $CteRodoviarioMotoristasTable(attachedDatabase, alias);
  }
}

class CteRodoviarioMotorista extends DataClass
    implements Insertable<CteRodoviarioMotorista> {
  final int? id;
  final int? idCteRodoviario;
  final String? nome;
  final String? cpf;
  const CteRodoviarioMotorista(
      {this.id, this.idCteRodoviario, this.nome, this.cpf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteRodoviario != null) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    return map;
  }

  factory CteRodoviarioMotorista.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteRodoviarioMotorista(
      id: serializer.fromJson<int?>(json['id']),
      idCteRodoviario: serializer.fromJson<int?>(json['idCteRodoviario']),
      nome: serializer.fromJson<String?>(json['nome']),
      cpf: serializer.fromJson<String?>(json['cpf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteRodoviario': serializer.toJson<int?>(idCteRodoviario),
      'nome': serializer.toJson<String?>(nome),
      'cpf': serializer.toJson<String?>(cpf),
    };
  }

  CteRodoviarioMotorista copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteRodoviario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> cpf = const Value.absent()}) =>
      CteRodoviarioMotorista(
        id: id.present ? id.value : this.id,
        idCteRodoviario: idCteRodoviario.present
            ? idCteRodoviario.value
            : this.idCteRodoviario,
        nome: nome.present ? nome.value : this.nome,
        cpf: cpf.present ? cpf.value : this.cpf,
      );
  @override
  String toString() {
    return (StringBuffer('CteRodoviarioMotorista(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteRodoviario, nome, cpf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteRodoviarioMotorista &&
          other.id == this.id &&
          other.idCteRodoviario == this.idCteRodoviario &&
          other.nome == this.nome &&
          other.cpf == this.cpf);
}

class CteRodoviarioMotoristasCompanion
    extends UpdateCompanion<CteRodoviarioMotorista> {
  final Value<int?> id;
  final Value<int?> idCteRodoviario;
  final Value<String?> nome;
  final Value<String?> cpf;
  const CteRodoviarioMotoristasCompanion({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
  });
  CteRodoviarioMotoristasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteRodoviario = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
  });
  static Insertable<CteRodoviarioMotorista> custom({
    Expression<int>? id,
    Expression<int>? idCteRodoviario,
    Expression<String>? nome,
    Expression<String>? cpf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteRodoviario != null) 'id_cte_rodoviario': idCteRodoviario,
      if (nome != null) 'nome': nome,
      if (cpf != null) 'cpf': cpf,
    });
  }

  CteRodoviarioMotoristasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteRodoviario,
      Value<String?>? nome,
      Value<String?>? cpf}) {
    return CteRodoviarioMotoristasCompanion(
      id: id ?? this.id,
      idCteRodoviario: idCteRodoviario ?? this.idCteRodoviario,
      nome: nome ?? this.nome,
      cpf: cpf ?? this.cpf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteRodoviario.present) {
      map['id_cte_rodoviario'] = Variable<int>(idCteRodoviario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteRodoviarioMotoristasCompanion(')
          ..write('id: $id, ')
          ..write('idCteRodoviario: $idCteRodoviario, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf')
          ..write(')'))
        .toString();
  }
}

class $CteAquaviarioBalsasTable extends CteAquaviarioBalsas
    with TableInfo<$CteAquaviarioBalsasTable, CteAquaviarioBalsa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteAquaviarioBalsasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteAquaviarioMeta =
      const VerificationMeta('idCteAquaviario');
  @override
  late final GeneratedColumn<int> idCteAquaviario = GeneratedColumn<int>(
      'id_cte_aquaviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBalsaMeta =
      const VerificationMeta('idBalsa');
  @override
  late final GeneratedColumn<String> idBalsa = GeneratedColumn<String>(
      'id_balsa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroViagemMeta =
      const VerificationMeta('numeroViagem');
  @override
  late final GeneratedColumn<int> numeroViagem = GeneratedColumn<int>(
      'numero_viagem', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _direcaoMeta =
      const VerificationMeta('direcao');
  @override
  late final GeneratedColumn<String> direcao = GeneratedColumn<String>(
      'direcao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _portoEmbarqueMeta =
      const VerificationMeta('portoEmbarque');
  @override
  late final GeneratedColumn<String> portoEmbarque = GeneratedColumn<String>(
      'porto_embarque', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _portoTransbordoMeta =
      const VerificationMeta('portoTransbordo');
  @override
  late final GeneratedColumn<String> portoTransbordo = GeneratedColumn<String>(
      'porto_transbordo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _portoDestinoMeta =
      const VerificationMeta('portoDestino');
  @override
  late final GeneratedColumn<String> portoDestino = GeneratedColumn<String>(
      'porto_destino', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoNavegacaoMeta =
      const VerificationMeta('tipoNavegacao');
  @override
  late final GeneratedColumn<String> tipoNavegacao = GeneratedColumn<String>(
      'tipo_navegacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _irinMeta = const VerificationMeta('irin');
  @override
  late final GeneratedColumn<String> irin = GeneratedColumn<String>(
      'irin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteAquaviario,
        idBalsa,
        numeroViagem,
        direcao,
        portoEmbarque,
        portoTransbordo,
        portoDestino,
        tipoNavegacao,
        irin
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_aquaviario_balsa';
  @override
  VerificationContext validateIntegrity(Insertable<CteAquaviarioBalsa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_aquaviario')) {
      context.handle(
          _idCteAquaviarioMeta,
          idCteAquaviario.isAcceptableOrUnknown(
              data['id_cte_aquaviario']!, _idCteAquaviarioMeta));
    }
    if (data.containsKey('id_balsa')) {
      context.handle(_idBalsaMeta,
          idBalsa.isAcceptableOrUnknown(data['id_balsa']!, _idBalsaMeta));
    }
    if (data.containsKey('numero_viagem')) {
      context.handle(
          _numeroViagemMeta,
          numeroViagem.isAcceptableOrUnknown(
              data['numero_viagem']!, _numeroViagemMeta));
    }
    if (data.containsKey('direcao')) {
      context.handle(_direcaoMeta,
          direcao.isAcceptableOrUnknown(data['direcao']!, _direcaoMeta));
    }
    if (data.containsKey('porto_embarque')) {
      context.handle(
          _portoEmbarqueMeta,
          portoEmbarque.isAcceptableOrUnknown(
              data['porto_embarque']!, _portoEmbarqueMeta));
    }
    if (data.containsKey('porto_transbordo')) {
      context.handle(
          _portoTransbordoMeta,
          portoTransbordo.isAcceptableOrUnknown(
              data['porto_transbordo']!, _portoTransbordoMeta));
    }
    if (data.containsKey('porto_destino')) {
      context.handle(
          _portoDestinoMeta,
          portoDestino.isAcceptableOrUnknown(
              data['porto_destino']!, _portoDestinoMeta));
    }
    if (data.containsKey('tipo_navegacao')) {
      context.handle(
          _tipoNavegacaoMeta,
          tipoNavegacao.isAcceptableOrUnknown(
              data['tipo_navegacao']!, _tipoNavegacaoMeta));
    }
    if (data.containsKey('irin')) {
      context.handle(
          _irinMeta, irin.isAcceptableOrUnknown(data['irin']!, _irinMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteAquaviarioBalsa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteAquaviarioBalsa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteAquaviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_aquaviario']),
      idBalsa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id_balsa']),
      numeroViagem: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_viagem']),
      direcao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}direcao']),
      portoEmbarque: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}porto_embarque']),
      portoTransbordo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}porto_transbordo']),
      portoDestino: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}porto_destino']),
      tipoNavegacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_navegacao']),
      irin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}irin']),
    );
  }

  @override
  $CteAquaviarioBalsasTable createAlias(String alias) {
    return $CteAquaviarioBalsasTable(attachedDatabase, alias);
  }
}

class CteAquaviarioBalsa extends DataClass
    implements Insertable<CteAquaviarioBalsa> {
  final int? id;
  final int? idCteAquaviario;
  final String? idBalsa;
  final int? numeroViagem;
  final String? direcao;
  final String? portoEmbarque;
  final String? portoTransbordo;
  final String? portoDestino;
  final String? tipoNavegacao;
  final String? irin;
  const CteAquaviarioBalsa(
      {this.id,
      this.idCteAquaviario,
      this.idBalsa,
      this.numeroViagem,
      this.direcao,
      this.portoEmbarque,
      this.portoTransbordo,
      this.portoDestino,
      this.tipoNavegacao,
      this.irin});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteAquaviario != null) {
      map['id_cte_aquaviario'] = Variable<int>(idCteAquaviario);
    }
    if (!nullToAbsent || idBalsa != null) {
      map['id_balsa'] = Variable<String>(idBalsa);
    }
    if (!nullToAbsent || numeroViagem != null) {
      map['numero_viagem'] = Variable<int>(numeroViagem);
    }
    if (!nullToAbsent || direcao != null) {
      map['direcao'] = Variable<String>(direcao);
    }
    if (!nullToAbsent || portoEmbarque != null) {
      map['porto_embarque'] = Variable<String>(portoEmbarque);
    }
    if (!nullToAbsent || portoTransbordo != null) {
      map['porto_transbordo'] = Variable<String>(portoTransbordo);
    }
    if (!nullToAbsent || portoDestino != null) {
      map['porto_destino'] = Variable<String>(portoDestino);
    }
    if (!nullToAbsent || tipoNavegacao != null) {
      map['tipo_navegacao'] = Variable<String>(tipoNavegacao);
    }
    if (!nullToAbsent || irin != null) {
      map['irin'] = Variable<String>(irin);
    }
    return map;
  }

  factory CteAquaviarioBalsa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteAquaviarioBalsa(
      id: serializer.fromJson<int?>(json['id']),
      idCteAquaviario: serializer.fromJson<int?>(json['idCteAquaviario']),
      idBalsa: serializer.fromJson<String?>(json['idBalsa']),
      numeroViagem: serializer.fromJson<int?>(json['numeroViagem']),
      direcao: serializer.fromJson<String?>(json['direcao']),
      portoEmbarque: serializer.fromJson<String?>(json['portoEmbarque']),
      portoTransbordo: serializer.fromJson<String?>(json['portoTransbordo']),
      portoDestino: serializer.fromJson<String?>(json['portoDestino']),
      tipoNavegacao: serializer.fromJson<String?>(json['tipoNavegacao']),
      irin: serializer.fromJson<String?>(json['irin']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteAquaviario': serializer.toJson<int?>(idCteAquaviario),
      'idBalsa': serializer.toJson<String?>(idBalsa),
      'numeroViagem': serializer.toJson<int?>(numeroViagem),
      'direcao': serializer.toJson<String?>(direcao),
      'portoEmbarque': serializer.toJson<String?>(portoEmbarque),
      'portoTransbordo': serializer.toJson<String?>(portoTransbordo),
      'portoDestino': serializer.toJson<String?>(portoDestino),
      'tipoNavegacao': serializer.toJson<String?>(tipoNavegacao),
      'irin': serializer.toJson<String?>(irin),
    };
  }

  CteAquaviarioBalsa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteAquaviario = const Value.absent(),
          Value<String?> idBalsa = const Value.absent(),
          Value<int?> numeroViagem = const Value.absent(),
          Value<String?> direcao = const Value.absent(),
          Value<String?> portoEmbarque = const Value.absent(),
          Value<String?> portoTransbordo = const Value.absent(),
          Value<String?> portoDestino = const Value.absent(),
          Value<String?> tipoNavegacao = const Value.absent(),
          Value<String?> irin = const Value.absent()}) =>
      CteAquaviarioBalsa(
        id: id.present ? id.value : this.id,
        idCteAquaviario: idCteAquaviario.present
            ? idCteAquaviario.value
            : this.idCteAquaviario,
        idBalsa: idBalsa.present ? idBalsa.value : this.idBalsa,
        numeroViagem:
            numeroViagem.present ? numeroViagem.value : this.numeroViagem,
        direcao: direcao.present ? direcao.value : this.direcao,
        portoEmbarque:
            portoEmbarque.present ? portoEmbarque.value : this.portoEmbarque,
        portoTransbordo: portoTransbordo.present
            ? portoTransbordo.value
            : this.portoTransbordo,
        portoDestino:
            portoDestino.present ? portoDestino.value : this.portoDestino,
        tipoNavegacao:
            tipoNavegacao.present ? tipoNavegacao.value : this.tipoNavegacao,
        irin: irin.present ? irin.value : this.irin,
      );
  @override
  String toString() {
    return (StringBuffer('CteAquaviarioBalsa(')
          ..write('id: $id, ')
          ..write('idCteAquaviario: $idCteAquaviario, ')
          ..write('idBalsa: $idBalsa, ')
          ..write('numeroViagem: $numeroViagem, ')
          ..write('direcao: $direcao, ')
          ..write('portoEmbarque: $portoEmbarque, ')
          ..write('portoTransbordo: $portoTransbordo, ')
          ..write('portoDestino: $portoDestino, ')
          ..write('tipoNavegacao: $tipoNavegacao, ')
          ..write('irin: $irin')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteAquaviario,
      idBalsa,
      numeroViagem,
      direcao,
      portoEmbarque,
      portoTransbordo,
      portoDestino,
      tipoNavegacao,
      irin);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteAquaviarioBalsa &&
          other.id == this.id &&
          other.idCteAquaviario == this.idCteAquaviario &&
          other.idBalsa == this.idBalsa &&
          other.numeroViagem == this.numeroViagem &&
          other.direcao == this.direcao &&
          other.portoEmbarque == this.portoEmbarque &&
          other.portoTransbordo == this.portoTransbordo &&
          other.portoDestino == this.portoDestino &&
          other.tipoNavegacao == this.tipoNavegacao &&
          other.irin == this.irin);
}

class CteAquaviarioBalsasCompanion extends UpdateCompanion<CteAquaviarioBalsa> {
  final Value<int?> id;
  final Value<int?> idCteAquaviario;
  final Value<String?> idBalsa;
  final Value<int?> numeroViagem;
  final Value<String?> direcao;
  final Value<String?> portoEmbarque;
  final Value<String?> portoTransbordo;
  final Value<String?> portoDestino;
  final Value<String?> tipoNavegacao;
  final Value<String?> irin;
  const CteAquaviarioBalsasCompanion({
    this.id = const Value.absent(),
    this.idCteAquaviario = const Value.absent(),
    this.idBalsa = const Value.absent(),
    this.numeroViagem = const Value.absent(),
    this.direcao = const Value.absent(),
    this.portoEmbarque = const Value.absent(),
    this.portoTransbordo = const Value.absent(),
    this.portoDestino = const Value.absent(),
    this.tipoNavegacao = const Value.absent(),
    this.irin = const Value.absent(),
  });
  CteAquaviarioBalsasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteAquaviario = const Value.absent(),
    this.idBalsa = const Value.absent(),
    this.numeroViagem = const Value.absent(),
    this.direcao = const Value.absent(),
    this.portoEmbarque = const Value.absent(),
    this.portoTransbordo = const Value.absent(),
    this.portoDestino = const Value.absent(),
    this.tipoNavegacao = const Value.absent(),
    this.irin = const Value.absent(),
  });
  static Insertable<CteAquaviarioBalsa> custom({
    Expression<int>? id,
    Expression<int>? idCteAquaviario,
    Expression<String>? idBalsa,
    Expression<int>? numeroViagem,
    Expression<String>? direcao,
    Expression<String>? portoEmbarque,
    Expression<String>? portoTransbordo,
    Expression<String>? portoDestino,
    Expression<String>? tipoNavegacao,
    Expression<String>? irin,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteAquaviario != null) 'id_cte_aquaviario': idCteAquaviario,
      if (idBalsa != null) 'id_balsa': idBalsa,
      if (numeroViagem != null) 'numero_viagem': numeroViagem,
      if (direcao != null) 'direcao': direcao,
      if (portoEmbarque != null) 'porto_embarque': portoEmbarque,
      if (portoTransbordo != null) 'porto_transbordo': portoTransbordo,
      if (portoDestino != null) 'porto_destino': portoDestino,
      if (tipoNavegacao != null) 'tipo_navegacao': tipoNavegacao,
      if (irin != null) 'irin': irin,
    });
  }

  CteAquaviarioBalsasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteAquaviario,
      Value<String?>? idBalsa,
      Value<int?>? numeroViagem,
      Value<String?>? direcao,
      Value<String?>? portoEmbarque,
      Value<String?>? portoTransbordo,
      Value<String?>? portoDestino,
      Value<String?>? tipoNavegacao,
      Value<String?>? irin}) {
    return CteAquaviarioBalsasCompanion(
      id: id ?? this.id,
      idCteAquaviario: idCteAquaviario ?? this.idCteAquaviario,
      idBalsa: idBalsa ?? this.idBalsa,
      numeroViagem: numeroViagem ?? this.numeroViagem,
      direcao: direcao ?? this.direcao,
      portoEmbarque: portoEmbarque ?? this.portoEmbarque,
      portoTransbordo: portoTransbordo ?? this.portoTransbordo,
      portoDestino: portoDestino ?? this.portoDestino,
      tipoNavegacao: tipoNavegacao ?? this.tipoNavegacao,
      irin: irin ?? this.irin,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteAquaviario.present) {
      map['id_cte_aquaviario'] = Variable<int>(idCteAquaviario.value);
    }
    if (idBalsa.present) {
      map['id_balsa'] = Variable<String>(idBalsa.value);
    }
    if (numeroViagem.present) {
      map['numero_viagem'] = Variable<int>(numeroViagem.value);
    }
    if (direcao.present) {
      map['direcao'] = Variable<String>(direcao.value);
    }
    if (portoEmbarque.present) {
      map['porto_embarque'] = Variable<String>(portoEmbarque.value);
    }
    if (portoTransbordo.present) {
      map['porto_transbordo'] = Variable<String>(portoTransbordo.value);
    }
    if (portoDestino.present) {
      map['porto_destino'] = Variable<String>(portoDestino.value);
    }
    if (tipoNavegacao.present) {
      map['tipo_navegacao'] = Variable<String>(tipoNavegacao.value);
    }
    if (irin.present) {
      map['irin'] = Variable<String>(irin.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteAquaviarioBalsasCompanion(')
          ..write('id: $id, ')
          ..write('idCteAquaviario: $idCteAquaviario, ')
          ..write('idBalsa: $idBalsa, ')
          ..write('numeroViagem: $numeroViagem, ')
          ..write('direcao: $direcao, ')
          ..write('portoEmbarque: $portoEmbarque, ')
          ..write('portoTransbordo: $portoTransbordo, ')
          ..write('portoDestino: $portoDestino, ')
          ..write('tipoNavegacao: $tipoNavegacao, ')
          ..write('irin: $irin')
          ..write(')'))
        .toString();
  }
}

class $CteFerroviarioFerroviasTable extends CteFerroviarioFerrovias
    with TableInfo<$CteFerroviarioFerroviasTable, CteFerroviarioFerrovia> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteFerroviarioFerroviasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteFerroviarioMeta =
      const VerificationMeta('idCteFerroviario');
  @override
  late final GeneratedColumn<int> idCteFerroviario = GeneratedColumn<int>(
      'id_cte_ferroviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
      'ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteFerroviario,
        cnpj,
        codigoInterno,
        ie,
        nome,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        uf,
        cep
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_ferroviario_ferrovia';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteFerroviarioFerrovia> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_ferroviario')) {
      context.handle(
          _idCteFerroviarioMeta,
          idCteFerroviario.isAcceptableOrUnknown(
              data['id_cte_ferroviario']!, _idCteFerroviarioMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteFerroviarioFerrovia map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteFerroviarioFerrovia(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteFerroviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_ferroviario']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ie']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
    );
  }

  @override
  $CteFerroviarioFerroviasTable createAlias(String alias) {
    return $CteFerroviarioFerroviasTable(attachedDatabase, alias);
  }
}

class CteFerroviarioFerrovia extends DataClass
    implements Insertable<CteFerroviarioFerrovia> {
  final int? id;
  final int? idCteFerroviario;
  final String? cnpj;
  final String? codigoInterno;
  final String? ie;
  final String? nome;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  const CteFerroviarioFerrovia(
      {this.id,
      this.idCteFerroviario,
      this.cnpj,
      this.codigoInterno,
      this.ie,
      this.nome,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.uf,
      this.cep});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteFerroviario != null) {
      map['id_cte_ferroviario'] = Variable<int>(idCteFerroviario);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    return map;
  }

  factory CteFerroviarioFerrovia.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteFerroviarioFerrovia(
      id: serializer.fromJson<int?>(json['id']),
      idCteFerroviario: serializer.fromJson<int?>(json['idCteFerroviario']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteFerroviario': serializer.toJson<int?>(idCteFerroviario),
      'cnpj': serializer.toJson<String?>(cnpj),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
    };
  }

  CteFerroviarioFerrovia copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteFerroviario = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<String?> ie = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> cep = const Value.absent()}) =>
      CteFerroviarioFerrovia(
        id: id.present ? id.value : this.id,
        idCteFerroviario: idCteFerroviario.present
            ? idCteFerroviario.value
            : this.idCteFerroviario,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        ie: ie.present ? ie.value : this.ie,
        nome: nome.present ? nome.value : this.nome,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        uf: uf.present ? uf.value : this.uf,
        cep: cep.present ? cep.value : this.cep,
      );
  @override
  String toString() {
    return (StringBuffer('CteFerroviarioFerrovia(')
          ..write('id: $id, ')
          ..write('idCteFerroviario: $idCteFerroviario, ')
          ..write('cnpj: $cnpj, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCteFerroviario,
      cnpj,
      codigoInterno,
      ie,
      nome,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      uf,
      cep);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteFerroviarioFerrovia &&
          other.id == this.id &&
          other.idCteFerroviario == this.idCteFerroviario &&
          other.cnpj == this.cnpj &&
          other.codigoInterno == this.codigoInterno &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep);
}

class CteFerroviarioFerroviasCompanion
    extends UpdateCompanion<CteFerroviarioFerrovia> {
  final Value<int?> id;
  final Value<int?> idCteFerroviario;
  final Value<String?> cnpj;
  final Value<String?> codigoInterno;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  const CteFerroviarioFerroviasCompanion({
    this.id = const Value.absent(),
    this.idCteFerroviario = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
  });
  CteFerroviarioFerroviasCompanion.insert({
    this.id = const Value.absent(),
    this.idCteFerroviario = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
  });
  static Insertable<CteFerroviarioFerrovia> custom({
    Expression<int>? id,
    Expression<int>? idCteFerroviario,
    Expression<String>? cnpj,
    Expression<String>? codigoInterno,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteFerroviario != null) 'id_cte_ferroviario': idCteFerroviario,
      if (cnpj != null) 'cnpj': cnpj,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
    });
  }

  CteFerroviarioFerroviasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteFerroviario,
      Value<String?>? cnpj,
      Value<String?>? codigoInterno,
      Value<String?>? ie,
      Value<String?>? nome,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<int?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? uf,
      Value<String?>? cep}) {
    return CteFerroviarioFerroviasCompanion(
      id: id ?? this.id,
      idCteFerroviario: idCteFerroviario ?? this.idCteFerroviario,
      cnpj: cnpj ?? this.cnpj,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteFerroviario.present) {
      map['id_cte_ferroviario'] = Variable<int>(idCteFerroviario.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteFerroviarioFerroviasCompanion(')
          ..write('id: $id, ')
          ..write('idCteFerroviario: $idCteFerroviario, ')
          ..write('cnpj: $cnpj, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep')
          ..write(')'))
        .toString();
  }
}

class $CteFerroviarioVagaosTable extends CteFerroviarioVagaos
    with TableInfo<$CteFerroviarioVagaosTable, CteFerroviarioVagao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CteFerroviarioVagaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCteFerroviarioMeta =
      const VerificationMeta('idCteFerroviario');
  @override
  late final GeneratedColumn<int> idCteFerroviario = GeneratedColumn<int>(
      'id_cte_ferroviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroVagaoMeta =
      const VerificationMeta('numeroVagao');
  @override
  late final GeneratedColumn<int> numeroVagao = GeneratedColumn<int>(
      'numero_vagao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _capacidadeMeta =
      const VerificationMeta('capacidade');
  @override
  late final GeneratedColumn<double> capacidade = GeneratedColumn<double>(
      'capacidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _tipoVagaoMeta =
      const VerificationMeta('tipoVagao');
  @override
  late final GeneratedColumn<String> tipoVagao = GeneratedColumn<String>(
      'tipo_vagao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _pesoRealMeta =
      const VerificationMeta('pesoReal');
  @override
  late final GeneratedColumn<double> pesoReal = GeneratedColumn<double>(
      'peso_real', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pesoBcMeta = const VerificationMeta('pesoBc');
  @override
  late final GeneratedColumn<double> pesoBc = GeneratedColumn<double>(
      'peso_bc', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCteFerroviario,
        numeroVagao,
        capacidade,
        tipoVagao,
        pesoReal,
        pesoBc
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cte_ferroviario_vagao';
  @override
  VerificationContext validateIntegrity(
      Insertable<CteFerroviarioVagao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cte_ferroviario')) {
      context.handle(
          _idCteFerroviarioMeta,
          idCteFerroviario.isAcceptableOrUnknown(
              data['id_cte_ferroviario']!, _idCteFerroviarioMeta));
    }
    if (data.containsKey('numero_vagao')) {
      context.handle(
          _numeroVagaoMeta,
          numeroVagao.isAcceptableOrUnknown(
              data['numero_vagao']!, _numeroVagaoMeta));
    }
    if (data.containsKey('capacidade')) {
      context.handle(
          _capacidadeMeta,
          capacidade.isAcceptableOrUnknown(
              data['capacidade']!, _capacidadeMeta));
    }
    if (data.containsKey('tipo_vagao')) {
      context.handle(_tipoVagaoMeta,
          tipoVagao.isAcceptableOrUnknown(data['tipo_vagao']!, _tipoVagaoMeta));
    }
    if (data.containsKey('peso_real')) {
      context.handle(_pesoRealMeta,
          pesoReal.isAcceptableOrUnknown(data['peso_real']!, _pesoRealMeta));
    }
    if (data.containsKey('peso_bc')) {
      context.handle(_pesoBcMeta,
          pesoBc.isAcceptableOrUnknown(data['peso_bc']!, _pesoBcMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CteFerroviarioVagao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CteFerroviarioVagao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCteFerroviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cte_ferroviario']),
      numeroVagao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_vagao']),
      capacidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}capacidade']),
      tipoVagao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_vagao']),
      pesoReal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}peso_real']),
      pesoBc: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}peso_bc']),
    );
  }

  @override
  $CteFerroviarioVagaosTable createAlias(String alias) {
    return $CteFerroviarioVagaosTable(attachedDatabase, alias);
  }
}

class CteFerroviarioVagao extends DataClass
    implements Insertable<CteFerroviarioVagao> {
  final int? id;
  final int? idCteFerroviario;
  final int? numeroVagao;
  final double? capacidade;
  final String? tipoVagao;
  final double? pesoReal;
  final double? pesoBc;
  const CteFerroviarioVagao(
      {this.id,
      this.idCteFerroviario,
      this.numeroVagao,
      this.capacidade,
      this.tipoVagao,
      this.pesoReal,
      this.pesoBc});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCteFerroviario != null) {
      map['id_cte_ferroviario'] = Variable<int>(idCteFerroviario);
    }
    if (!nullToAbsent || numeroVagao != null) {
      map['numero_vagao'] = Variable<int>(numeroVagao);
    }
    if (!nullToAbsent || capacidade != null) {
      map['capacidade'] = Variable<double>(capacidade);
    }
    if (!nullToAbsent || tipoVagao != null) {
      map['tipo_vagao'] = Variable<String>(tipoVagao);
    }
    if (!nullToAbsent || pesoReal != null) {
      map['peso_real'] = Variable<double>(pesoReal);
    }
    if (!nullToAbsent || pesoBc != null) {
      map['peso_bc'] = Variable<double>(pesoBc);
    }
    return map;
  }

  factory CteFerroviarioVagao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CteFerroviarioVagao(
      id: serializer.fromJson<int?>(json['id']),
      idCteFerroviario: serializer.fromJson<int?>(json['idCteFerroviario']),
      numeroVagao: serializer.fromJson<int?>(json['numeroVagao']),
      capacidade: serializer.fromJson<double?>(json['capacidade']),
      tipoVagao: serializer.fromJson<String?>(json['tipoVagao']),
      pesoReal: serializer.fromJson<double?>(json['pesoReal']),
      pesoBc: serializer.fromJson<double?>(json['pesoBc']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCteFerroviario': serializer.toJson<int?>(idCteFerroviario),
      'numeroVagao': serializer.toJson<int?>(numeroVagao),
      'capacidade': serializer.toJson<double?>(capacidade),
      'tipoVagao': serializer.toJson<String?>(tipoVagao),
      'pesoReal': serializer.toJson<double?>(pesoReal),
      'pesoBc': serializer.toJson<double?>(pesoBc),
    };
  }

  CteFerroviarioVagao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCteFerroviario = const Value.absent(),
          Value<int?> numeroVagao = const Value.absent(),
          Value<double?> capacidade = const Value.absent(),
          Value<String?> tipoVagao = const Value.absent(),
          Value<double?> pesoReal = const Value.absent(),
          Value<double?> pesoBc = const Value.absent()}) =>
      CteFerroviarioVagao(
        id: id.present ? id.value : this.id,
        idCteFerroviario: idCteFerroviario.present
            ? idCteFerroviario.value
            : this.idCteFerroviario,
        numeroVagao: numeroVagao.present ? numeroVagao.value : this.numeroVagao,
        capacidade: capacidade.present ? capacidade.value : this.capacidade,
        tipoVagao: tipoVagao.present ? tipoVagao.value : this.tipoVagao,
        pesoReal: pesoReal.present ? pesoReal.value : this.pesoReal,
        pesoBc: pesoBc.present ? pesoBc.value : this.pesoBc,
      );
  @override
  String toString() {
    return (StringBuffer('CteFerroviarioVagao(')
          ..write('id: $id, ')
          ..write('idCteFerroviario: $idCteFerroviario, ')
          ..write('numeroVagao: $numeroVagao, ')
          ..write('capacidade: $capacidade, ')
          ..write('tipoVagao: $tipoVagao, ')
          ..write('pesoReal: $pesoReal, ')
          ..write('pesoBc: $pesoBc')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCteFerroviario, numeroVagao, capacidade,
      tipoVagao, pesoReal, pesoBc);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CteFerroviarioVagao &&
          other.id == this.id &&
          other.idCteFerroviario == this.idCteFerroviario &&
          other.numeroVagao == this.numeroVagao &&
          other.capacidade == this.capacidade &&
          other.tipoVagao == this.tipoVagao &&
          other.pesoReal == this.pesoReal &&
          other.pesoBc == this.pesoBc);
}

class CteFerroviarioVagaosCompanion
    extends UpdateCompanion<CteFerroviarioVagao> {
  final Value<int?> id;
  final Value<int?> idCteFerroviario;
  final Value<int?> numeroVagao;
  final Value<double?> capacidade;
  final Value<String?> tipoVagao;
  final Value<double?> pesoReal;
  final Value<double?> pesoBc;
  const CteFerroviarioVagaosCompanion({
    this.id = const Value.absent(),
    this.idCteFerroviario = const Value.absent(),
    this.numeroVagao = const Value.absent(),
    this.capacidade = const Value.absent(),
    this.tipoVagao = const Value.absent(),
    this.pesoReal = const Value.absent(),
    this.pesoBc = const Value.absent(),
  });
  CteFerroviarioVagaosCompanion.insert({
    this.id = const Value.absent(),
    this.idCteFerroviario = const Value.absent(),
    this.numeroVagao = const Value.absent(),
    this.capacidade = const Value.absent(),
    this.tipoVagao = const Value.absent(),
    this.pesoReal = const Value.absent(),
    this.pesoBc = const Value.absent(),
  });
  static Insertable<CteFerroviarioVagao> custom({
    Expression<int>? id,
    Expression<int>? idCteFerroviario,
    Expression<int>? numeroVagao,
    Expression<double>? capacidade,
    Expression<String>? tipoVagao,
    Expression<double>? pesoReal,
    Expression<double>? pesoBc,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCteFerroviario != null) 'id_cte_ferroviario': idCteFerroviario,
      if (numeroVagao != null) 'numero_vagao': numeroVagao,
      if (capacidade != null) 'capacidade': capacidade,
      if (tipoVagao != null) 'tipo_vagao': tipoVagao,
      if (pesoReal != null) 'peso_real': pesoReal,
      if (pesoBc != null) 'peso_bc': pesoBc,
    });
  }

  CteFerroviarioVagaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCteFerroviario,
      Value<int?>? numeroVagao,
      Value<double?>? capacidade,
      Value<String?>? tipoVagao,
      Value<double?>? pesoReal,
      Value<double?>? pesoBc}) {
    return CteFerroviarioVagaosCompanion(
      id: id ?? this.id,
      idCteFerroviario: idCteFerroviario ?? this.idCteFerroviario,
      numeroVagao: numeroVagao ?? this.numeroVagao,
      capacidade: capacidade ?? this.capacidade,
      tipoVagao: tipoVagao ?? this.tipoVagao,
      pesoReal: pesoReal ?? this.pesoReal,
      pesoBc: pesoBc ?? this.pesoBc,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCteFerroviario.present) {
      map['id_cte_ferroviario'] = Variable<int>(idCteFerroviario.value);
    }
    if (numeroVagao.present) {
      map['numero_vagao'] = Variable<int>(numeroVagao.value);
    }
    if (capacidade.present) {
      map['capacidade'] = Variable<double>(capacidade.value);
    }
    if (tipoVagao.present) {
      map['tipo_vagao'] = Variable<String>(tipoVagao.value);
    }
    if (pesoReal.present) {
      map['peso_real'] = Variable<double>(pesoReal.value);
    }
    if (pesoBc.present) {
      map['peso_bc'] = Variable<double>(pesoBc.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CteFerroviarioVagaosCompanion(')
          ..write('id: $id, ')
          ..write('idCteFerroviario: $idCteFerroviario, ')
          ..write('numeroVagao: $numeroVagao, ')
          ..write('capacidade: $capacidade, ')
          ..write('tipoVagao: $tipoVagao, ')
          ..write('pesoReal: $pesoReal, ')
          ..write('pesoBc: $pesoBc')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $CteEmitentesTable cteEmitentes = $CteEmitentesTable(this);
  late final $CteLocalColetasTable cteLocalColetas =
      $CteLocalColetasTable(this);
  late final $CteTomadorsTable cteTomadors = $CteTomadorsTable(this);
  late final $CtePassagemsTable ctePassagems = $CtePassagemsTable(this);
  late final $CteRemetentesTable cteRemetentes = $CteRemetentesTable(this);
  late final $CteExpedidorsTable cteExpedidors = $CteExpedidorsTable(this);
  late final $CteRecebedorsTable cteRecebedors = $CteRecebedorsTable(this);
  late final $CteDestinatariosTable cteDestinatarios =
      $CteDestinatariosTable(this);
  late final $CteLocalEntregasTable cteLocalEntregas =
      $CteLocalEntregasTable(this);
  late final $CteComponentesTable cteComponentes = $CteComponentesTable(this);
  late final $CteCargasTable cteCargas = $CteCargasTable(this);
  late final $CteInformacaoNfOutrossTable cteInformacaoNfOutross =
      $CteInformacaoNfOutrossTable(this);
  late final $CteSegurosTable cteSeguros = $CteSegurosTable(this);
  late final $CtePerigososTable ctePerigosos = $CtePerigososTable(this);
  late final $CteVeiculoNovosTable cteVeiculoNovos =
      $CteVeiculoNovosTable(this);
  late final $CteFaturasTable cteFaturas = $CteFaturasTable(this);
  late final $CteDuplicatasTable cteDuplicatas = $CteDuplicatasTable(this);
  late final $CteRodoviariosTable cteRodoviarios = $CteRodoviariosTable(this);
  late final $CteAereosTable cteAereos = $CteAereosTable(this);
  late final $CteAquaviariosTable cteAquaviarios = $CteAquaviariosTable(this);
  late final $CteFerroviariosTable cteFerroviarios =
      $CteFerroviariosTable(this);
  late final $CteDutoviariosTable cteDutoviarios = $CteDutoviariosTable(this);
  late final $CteMultimodalsTable cteMultimodals = $CteMultimodalsTable(this);
  late final $CteCabecalhosTable cteCabecalhos = $CteCabecalhosTable(this);
  late final $CteInformacaoNfTransportesTable cteInformacaoNfTransportes =
      $CteInformacaoNfTransportesTable(this);
  late final $CteInfNfTransporteLacresTable cteInfNfTransporteLacres =
      $CteInfNfTransporteLacresTable(this);
  late final $CteInformacaoNfCargasTable cteInformacaoNfCargas =
      $CteInformacaoNfCargasTable(this);
  late final $CteInfNfCargaLacresTable cteInfNfCargaLacres =
      $CteInfNfCargaLacresTable(this);
  late final $CteDocumentoAnteriorIdsTable cteDocumentoAnteriorIds =
      $CteDocumentoAnteriorIdsTable(this);
  late final $CteRodoviarioOccsTable cteRodoviarioOccs =
      $CteRodoviarioOccsTable(this);
  late final $CteRodoviarioPedagiosTable cteRodoviarioPedagios =
      $CteRodoviarioPedagiosTable(this);
  late final $CteRodoviarioVeiculosTable cteRodoviarioVeiculos =
      $CteRodoviarioVeiculosTable(this);
  late final $CteRodoviarioLacresTable cteRodoviarioLacres =
      $CteRodoviarioLacresTable(this);
  late final $CteRodoviarioMotoristasTable cteRodoviarioMotoristas =
      $CteRodoviarioMotoristasTable(this);
  late final $CteAquaviarioBalsasTable cteAquaviarioBalsas =
      $CteAquaviarioBalsasTable(this);
  late final $CteFerroviarioFerroviasTable cteFerroviarioFerrovias =
      $CteFerroviarioFerroviasTable(this);
  late final $CteFerroviarioVagaosTable cteFerroviarioVagaos =
      $CteFerroviarioVagaosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final CteCabecalhoDao cteCabecalhoDao =
      CteCabecalhoDao(this as AppDatabase);
  late final CteInformacaoNfTransporteDao cteInformacaoNfTransporteDao =
      CteInformacaoNfTransporteDao(this as AppDatabase);
  late final CteInfNfTransporteLacreDao cteInfNfTransporteLacreDao =
      CteInfNfTransporteLacreDao(this as AppDatabase);
  late final CteInformacaoNfCargaDao cteInformacaoNfCargaDao =
      CteInformacaoNfCargaDao(this as AppDatabase);
  late final CteInfNfCargaLacreDao cteInfNfCargaLacreDao =
      CteInfNfCargaLacreDao(this as AppDatabase);
  late final CteDocumentoAnteriorIdDao cteDocumentoAnteriorIdDao =
      CteDocumentoAnteriorIdDao(this as AppDatabase);
  late final CteRodoviarioOccDao cteRodoviarioOccDao =
      CteRodoviarioOccDao(this as AppDatabase);
  late final CteRodoviarioPedagioDao cteRodoviarioPedagioDao =
      CteRodoviarioPedagioDao(this as AppDatabase);
  late final CteRodoviarioVeiculoDao cteRodoviarioVeiculoDao =
      CteRodoviarioVeiculoDao(this as AppDatabase);
  late final CteRodoviarioLacreDao cteRodoviarioLacreDao =
      CteRodoviarioLacreDao(this as AppDatabase);
  late final CteRodoviarioMotoristaDao cteRodoviarioMotoristaDao =
      CteRodoviarioMotoristaDao(this as AppDatabase);
  late final CteAquaviarioBalsaDao cteAquaviarioBalsaDao =
      CteAquaviarioBalsaDao(this as AppDatabase);
  late final CteFerroviarioFerroviaDao cteFerroviarioFerroviaDao =
      CteFerroviarioFerroviaDao(this as AppDatabase);
  late final CteFerroviarioVagaoDao cteFerroviarioVagaoDao =
      CteFerroviarioVagaoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        cteEmitentes,
        cteLocalColetas,
        cteTomadors,
        ctePassagems,
        cteRemetentes,
        cteExpedidors,
        cteRecebedors,
        cteDestinatarios,
        cteLocalEntregas,
        cteComponentes,
        cteCargas,
        cteInformacaoNfOutross,
        cteSeguros,
        ctePerigosos,
        cteVeiculoNovos,
        cteFaturas,
        cteDuplicatas,
        cteRodoviarios,
        cteAereos,
        cteAquaviarios,
        cteFerroviarios,
        cteDutoviarios,
        cteMultimodals,
        cteCabecalhos,
        cteInformacaoNfTransportes,
        cteInfNfTransporteLacres,
        cteInformacaoNfCargas,
        cteInfNfCargaLacres,
        cteDocumentoAnteriorIds,
        cteRodoviarioOccs,
        cteRodoviarioPedagios,
        cteRodoviarioVeiculos,
        cteRodoviarioLacres,
        cteRodoviarioMotoristas,
        cteAquaviarioBalsas,
        cteFerroviarioFerrovias,
        cteFerroviarioVagaos,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
