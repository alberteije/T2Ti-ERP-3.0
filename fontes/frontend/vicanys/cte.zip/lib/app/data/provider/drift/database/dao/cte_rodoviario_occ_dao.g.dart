// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_rodoviario_occ_dao.dart';

// ignore_for_file: type=lint
mixin _$CteRodoviarioOccDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteRodoviarioOccsTable get cteRodoviarioOccs =>
      attachedDatabase.cteRodoviarioOccs;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
}
