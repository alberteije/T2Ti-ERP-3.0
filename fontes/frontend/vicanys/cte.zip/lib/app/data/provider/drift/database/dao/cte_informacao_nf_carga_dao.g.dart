// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_informacao_nf_carga_dao.dart';

// ignore_for_file: type=lint
mixin _$CteInformacaoNfCargaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteInformacaoNfCargasTable get cteInformacaoNfCargas =>
      attachedDatabase.cteInformacaoNfCargas;
  $CteInformacaoNfOutrossTable get cteInformacaoNfOutross =>
      attachedDatabase.cteInformacaoNfOutross;
}
