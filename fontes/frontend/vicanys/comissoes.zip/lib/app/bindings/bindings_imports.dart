export 'login_bindings.dart';
export 'comissao_perfil_bindings.dart';
export 'comissao_objetivo_bindings.dart';