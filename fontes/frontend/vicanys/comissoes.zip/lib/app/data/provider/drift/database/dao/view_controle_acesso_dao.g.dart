// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_controle_acesso_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewControleAcessoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewControleAcessosTable get viewControleAcessos =>
      attachedDatabase.viewControleAcessos;
}
