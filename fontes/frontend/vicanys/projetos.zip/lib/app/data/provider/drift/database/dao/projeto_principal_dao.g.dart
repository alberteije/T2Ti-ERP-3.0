// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'projeto_principal_dao.dart';

// ignore_for_file: type=lint
mixin _$ProjetoPrincipalDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProjetoPrincipalsTable get projetoPrincipals =>
      attachedDatabase.projetoPrincipals;
  $ProjetoCronogramasTable get projetoCronogramas =>
      attachedDatabase.projetoCronogramas;
  $ProjetoRiscosTable get projetoRiscos => attachedDatabase.projetoRiscos;
  $ProjetoCustosTable get projetoCustos => attachedDatabase.projetoCustos;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
  $ProjetoStakeholderssTable get projetoStakeholderss =>
      attachedDatabase.projetoStakeholderss;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
