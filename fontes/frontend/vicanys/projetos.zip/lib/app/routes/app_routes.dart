abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const projetoPrincipalListPage = '/projetoPrincipalListPage'; 
	static const projetoPrincipalTabPage = '/projetoPrincipalTabPage';
}