abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const compraRequisicaoListPage = '/compraRequisicaoListPage'; 
	static const compraRequisicaoTabPage = '/compraRequisicaoTabPage';
	static const compraCotacaoListPage = '/compraCotacaoListPage'; 
	static const compraCotacaoTabPage = '/compraCotacaoTabPage';
	static const compraPedidoListPage = '/compraPedidoListPage'; 
	static const compraPedidoTabPage = '/compraPedidoTabPage';
	static const compraTipoRequisicaoListPage = '/compraTipoRequisicaoListPage'; 
	static const compraTipoRequisicaoEditPage = '/compraTipoRequisicaoEditPage';
	static const compraTipoPedidoListPage = '/compraTipoPedidoListPage'; 
	static const compraTipoPedidoEditPage = '/compraTipoPedidoEditPage';
}