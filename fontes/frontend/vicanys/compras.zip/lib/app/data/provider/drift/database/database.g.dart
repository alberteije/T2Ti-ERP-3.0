// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $CompraRequisicaoDetalhesTable extends CompraRequisicaoDetalhes
    with TableInfo<$CompraRequisicaoDetalhesTable, CompraRequisicaoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraRequisicaoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraRequisicaoMeta =
      const VerificationMeta('idCompraRequisicao');
  @override
  late final GeneratedColumn<int> idCompraRequisicao = GeneratedColumn<int>(
      'id_compra_requisicao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCompraRequisicao, idProduto, quantidade];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_requisicao_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<CompraRequisicaoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_requisicao')) {
      context.handle(
          _idCompraRequisicaoMeta,
          idCompraRequisicao.isAcceptableOrUnknown(
              data['id_compra_requisicao']!, _idCompraRequisicaoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraRequisicaoDetalhe map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraRequisicaoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraRequisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_compra_requisicao']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
    );
  }

  @override
  $CompraRequisicaoDetalhesTable createAlias(String alias) {
    return $CompraRequisicaoDetalhesTable(attachedDatabase, alias);
  }
}

class CompraRequisicaoDetalhe extends DataClass
    implements Insertable<CompraRequisicaoDetalhe> {
  final int? id;
  final int? idCompraRequisicao;
  final int? idProduto;
  final double? quantidade;
  const CompraRequisicaoDetalhe(
      {this.id, this.idCompraRequisicao, this.idProduto, this.quantidade});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraRequisicao != null) {
      map['id_compra_requisicao'] = Variable<int>(idCompraRequisicao);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    return map;
  }

  factory CompraRequisicaoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraRequisicaoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idCompraRequisicao: serializer.fromJson<int?>(json['idCompraRequisicao']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraRequisicao': serializer.toJson<int?>(idCompraRequisicao),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
    };
  }

  CompraRequisicaoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraRequisicao = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> quantidade = const Value.absent()}) =>
      CompraRequisicaoDetalhe(
        id: id.present ? id.value : this.id,
        idCompraRequisicao: idCompraRequisicao.present
            ? idCompraRequisicao.value
            : this.idCompraRequisicao,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
      );
  @override
  String toString() {
    return (StringBuffer('CompraRequisicaoDetalhe(')
          ..write('id: $id, ')
          ..write('idCompraRequisicao: $idCompraRequisicao, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCompraRequisicao, idProduto, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraRequisicaoDetalhe &&
          other.id == this.id &&
          other.idCompraRequisicao == this.idCompraRequisicao &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade);
}

class CompraRequisicaoDetalhesCompanion
    extends UpdateCompanion<CompraRequisicaoDetalhe> {
  final Value<int?> id;
  final Value<int?> idCompraRequisicao;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  const CompraRequisicaoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idCompraRequisicao = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  CompraRequisicaoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraRequisicao = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<CompraRequisicaoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idCompraRequisicao,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraRequisicao != null)
        'id_compra_requisicao': idCompraRequisicao,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  CompraRequisicaoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraRequisicao,
      Value<int?>? idProduto,
      Value<double?>? quantidade}) {
    return CompraRequisicaoDetalhesCompanion(
      id: id ?? this.id,
      idCompraRequisicao: idCompraRequisicao ?? this.idCompraRequisicao,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraRequisicao.present) {
      map['id_compra_requisicao'] = Variable<int>(idCompraRequisicao.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraRequisicaoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idCompraRequisicao: $idCompraRequisicao, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $CompraFornecedorCotacaosTable extends CompraFornecedorCotacaos
    with TableInfo<$CompraFornecedorCotacaosTable, CompraFornecedorCotacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraFornecedorCotacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraCotacaoMeta =
      const VerificationMeta('idCompraCotacao');
  @override
  late final GeneratedColumn<int> idCompraCotacao = GeneratedColumn<int>(
      'id_compra_cotacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFornecedorMeta =
      const VerificationMeta('idFornecedor');
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
      'id_fornecedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 32),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _prazoEntregaMeta =
      const VerificationMeta('prazoEntrega');
  @override
  late final GeneratedColumn<String> prazoEntrega = GeneratedColumn<String>(
      'prazo_entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _vendaCondicoesPagamentoMeta =
      const VerificationMeta('vendaCondicoesPagamento');
  @override
  late final GeneratedColumn<String> vendaCondicoesPagamento =
      GeneratedColumn<String>('venda_condicoes_pagamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 50),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCompraCotacao,
        idFornecedor,
        codigo,
        prazoEntrega,
        vendaCondicoesPagamento,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_fornecedor_cotacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<CompraFornecedorCotacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_cotacao')) {
      context.handle(
          _idCompraCotacaoMeta,
          idCompraCotacao.isAcceptableOrUnknown(
              data['id_compra_cotacao']!, _idCompraCotacaoMeta));
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
          _idFornecedorMeta,
          idFornecedor.isAcceptableOrUnknown(
              data['id_fornecedor']!, _idFornecedorMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('prazo_entrega')) {
      context.handle(
          _prazoEntregaMeta,
          prazoEntrega.isAcceptableOrUnknown(
              data['prazo_entrega']!, _prazoEntregaMeta));
    }
    if (data.containsKey('venda_condicoes_pagamento')) {
      context.handle(
          _vendaCondicoesPagamentoMeta,
          vendaCondicoesPagamento.isAcceptableOrUnknown(
              data['venda_condicoes_pagamento']!,
              _vendaCondicoesPagamentoMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraFornecedorCotacao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraFornecedorCotacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraCotacao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_compra_cotacao']),
      idFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fornecedor']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      prazoEntrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}prazo_entrega']),
      vendaCondicoesPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}venda_condicoes_pagamento']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
    );
  }

  @override
  $CompraFornecedorCotacaosTable createAlias(String alias) {
    return $CompraFornecedorCotacaosTable(attachedDatabase, alias);
  }
}

class CompraFornecedorCotacao extends DataClass
    implements Insertable<CompraFornecedorCotacao> {
  final int? id;
  final int? idCompraCotacao;
  final int? idFornecedor;
  final String? codigo;
  final String? prazoEntrega;
  final String? vendaCondicoesPagamento;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  const CompraFornecedorCotacao(
      {this.id,
      this.idCompraCotacao,
      this.idFornecedor,
      this.codigo,
      this.prazoEntrega,
      this.vendaCondicoesPagamento,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraCotacao != null) {
      map['id_compra_cotacao'] = Variable<int>(idCompraCotacao);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || prazoEntrega != null) {
      map['prazo_entrega'] = Variable<String>(prazoEntrega);
    }
    if (!nullToAbsent || vendaCondicoesPagamento != null) {
      map['venda_condicoes_pagamento'] =
          Variable<String>(vendaCondicoesPagamento);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    return map;
  }

  factory CompraFornecedorCotacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraFornecedorCotacao(
      id: serializer.fromJson<int?>(json['id']),
      idCompraCotacao: serializer.fromJson<int?>(json['idCompraCotacao']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      prazoEntrega: serializer.fromJson<String?>(json['prazoEntrega']),
      vendaCondicoesPagamento:
          serializer.fromJson<String?>(json['vendaCondicoesPagamento']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraCotacao': serializer.toJson<int?>(idCompraCotacao),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'codigo': serializer.toJson<String?>(codigo),
      'prazoEntrega': serializer.toJson<String?>(prazoEntrega),
      'vendaCondicoesPagamento':
          serializer.toJson<String?>(vendaCondicoesPagamento),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
    };
  }

  CompraFornecedorCotacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraCotacao = const Value.absent(),
          Value<int?> idFornecedor = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> prazoEntrega = const Value.absent(),
          Value<String?> vendaCondicoesPagamento = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent()}) =>
      CompraFornecedorCotacao(
        id: id.present ? id.value : this.id,
        idCompraCotacao: idCompraCotacao.present
            ? idCompraCotacao.value
            : this.idCompraCotacao,
        idFornecedor:
            idFornecedor.present ? idFornecedor.value : this.idFornecedor,
        codigo: codigo.present ? codigo.value : this.codigo,
        prazoEntrega:
            prazoEntrega.present ? prazoEntrega.value : this.prazoEntrega,
        vendaCondicoesPagamento: vendaCondicoesPagamento.present
            ? vendaCondicoesPagamento.value
            : this.vendaCondicoesPagamento,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
      );
  @override
  String toString() {
    return (StringBuffer('CompraFornecedorCotacao(')
          ..write('id: $id, ')
          ..write('idCompraCotacao: $idCompraCotacao, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('codigo: $codigo, ')
          ..write('prazoEntrega: $prazoEntrega, ')
          ..write('vendaCondicoesPagamento: $vendaCondicoesPagamento, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCompraCotacao,
      idFornecedor,
      codigo,
      prazoEntrega,
      vendaCondicoesPagamento,
      valorSubtotal,
      taxaDesconto,
      valorDesconto,
      valorTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraFornecedorCotacao &&
          other.id == this.id &&
          other.idCompraCotacao == this.idCompraCotacao &&
          other.idFornecedor == this.idFornecedor &&
          other.codigo == this.codigo &&
          other.prazoEntrega == this.prazoEntrega &&
          other.vendaCondicoesPagamento == this.vendaCondicoesPagamento &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal);
}

class CompraFornecedorCotacaosCompanion
    extends UpdateCompanion<CompraFornecedorCotacao> {
  final Value<int?> id;
  final Value<int?> idCompraCotacao;
  final Value<int?> idFornecedor;
  final Value<String?> codigo;
  final Value<String?> prazoEntrega;
  final Value<String?> vendaCondicoesPagamento;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  const CompraFornecedorCotacaosCompanion({
    this.id = const Value.absent(),
    this.idCompraCotacao = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.codigo = const Value.absent(),
    this.prazoEntrega = const Value.absent(),
    this.vendaCondicoesPagamento = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  CompraFornecedorCotacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraCotacao = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.codigo = const Value.absent(),
    this.prazoEntrega = const Value.absent(),
    this.vendaCondicoesPagamento = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  static Insertable<CompraFornecedorCotacao> custom({
    Expression<int>? id,
    Expression<int>? idCompraCotacao,
    Expression<int>? idFornecedor,
    Expression<String>? codigo,
    Expression<String>? prazoEntrega,
    Expression<String>? vendaCondicoesPagamento,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraCotacao != null) 'id_compra_cotacao': idCompraCotacao,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (codigo != null) 'codigo': codigo,
      if (prazoEntrega != null) 'prazo_entrega': prazoEntrega,
      if (vendaCondicoesPagamento != null)
        'venda_condicoes_pagamento': vendaCondicoesPagamento,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
    });
  }

  CompraFornecedorCotacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraCotacao,
      Value<int?>? idFornecedor,
      Value<String?>? codigo,
      Value<String?>? prazoEntrega,
      Value<String?>? vendaCondicoesPagamento,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal}) {
    return CompraFornecedorCotacaosCompanion(
      id: id ?? this.id,
      idCompraCotacao: idCompraCotacao ?? this.idCompraCotacao,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      codigo: codigo ?? this.codigo,
      prazoEntrega: prazoEntrega ?? this.prazoEntrega,
      vendaCondicoesPagamento:
          vendaCondicoesPagamento ?? this.vendaCondicoesPagamento,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraCotacao.present) {
      map['id_compra_cotacao'] = Variable<int>(idCompraCotacao.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (prazoEntrega.present) {
      map['prazo_entrega'] = Variable<String>(prazoEntrega.value);
    }
    if (vendaCondicoesPagamento.present) {
      map['venda_condicoes_pagamento'] =
          Variable<String>(vendaCondicoesPagamento.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraFornecedorCotacaosCompanion(')
          ..write('id: $id, ')
          ..write('idCompraCotacao: $idCompraCotacao, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('codigo: $codigo, ')
          ..write('prazoEntrega: $prazoEntrega, ')
          ..write('vendaCondicoesPagamento: $vendaCondicoesPagamento, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }
}

class $CompraCotacaoDetalhesTable extends CompraCotacaoDetalhes
    with TableInfo<$CompraCotacaoDetalhesTable, CompraCotacaoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraCotacaoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraCotacaoMeta =
      const VerificationMeta('idCompraCotacao');
  @override
  late final GeneratedColumn<int> idCompraCotacao = GeneratedColumn<int>(
      'id_compra_cotacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProduto,
        idCompraCotacao,
        quantidade,
        valorUnitario,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_cotacao_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<CompraCotacaoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('id_compra_cotacao')) {
      context.handle(
          _idCompraCotacaoMeta,
          idCompraCotacao.isAcceptableOrUnknown(
              data['id_compra_cotacao']!, _idCompraCotacaoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraCotacaoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraCotacaoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      idCompraCotacao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_compra_cotacao']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
    );
  }

  @override
  $CompraCotacaoDetalhesTable createAlias(String alias) {
    return $CompraCotacaoDetalhesTable(attachedDatabase, alias);
  }
}

class CompraCotacaoDetalhe extends DataClass
    implements Insertable<CompraCotacaoDetalhe> {
  final int? id;
  final int? idProduto;
  final int? idCompraCotacao;
  final double? quantidade;
  final double? valorUnitario;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  const CompraCotacaoDetalhe(
      {this.id,
      this.idProduto,
      this.idCompraCotacao,
      this.quantidade,
      this.valorUnitario,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || idCompraCotacao != null) {
      map['id_compra_cotacao'] = Variable<int>(idCompraCotacao);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    return map;
  }

  factory CompraCotacaoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraCotacaoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      idCompraCotacao: serializer.fromJson<int?>(json['idCompraCotacao']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProduto': serializer.toJson<int?>(idProduto),
      'idCompraCotacao': serializer.toJson<int?>(idCompraCotacao),
      'quantidade': serializer.toJson<double?>(quantidade),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
    };
  }

  CompraCotacaoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<int?> idCompraCotacao = const Value.absent(),
          Value<double?> quantidade = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent()}) =>
      CompraCotacaoDetalhe(
        id: id.present ? id.value : this.id,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        idCompraCotacao: idCompraCotacao.present
            ? idCompraCotacao.value
            : this.idCompraCotacao,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
      );
  @override
  String toString() {
    return (StringBuffer('CompraCotacaoDetalhe(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('idCompraCotacao: $idCompraCotacao, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProduto, idCompraCotacao, quantidade,
      valorUnitario, valorSubtotal, taxaDesconto, valorDesconto, valorTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraCotacaoDetalhe &&
          other.id == this.id &&
          other.idProduto == this.idProduto &&
          other.idCompraCotacao == this.idCompraCotacao &&
          other.quantidade == this.quantidade &&
          other.valorUnitario == this.valorUnitario &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal);
}

class CompraCotacaoDetalhesCompanion
    extends UpdateCompanion<CompraCotacaoDetalhe> {
  final Value<int?> id;
  final Value<int?> idProduto;
  final Value<int?> idCompraCotacao;
  final Value<double?> quantidade;
  final Value<double?> valorUnitario;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  const CompraCotacaoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idCompraCotacao = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  CompraCotacaoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idCompraCotacao = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  static Insertable<CompraCotacaoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idProduto,
    Expression<int>? idCompraCotacao,
    Expression<double>? quantidade,
    Expression<double>? valorUnitario,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProduto != null) 'id_produto': idProduto,
      if (idCompraCotacao != null) 'id_compra_cotacao': idCompraCotacao,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
    });
  }

  CompraCotacaoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProduto,
      Value<int?>? idCompraCotacao,
      Value<double?>? quantidade,
      Value<double?>? valorUnitario,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal}) {
    return CompraCotacaoDetalhesCompanion(
      id: id ?? this.id,
      idProduto: idProduto ?? this.idProduto,
      idCompraCotacao: idCompraCotacao ?? this.idCompraCotacao,
      quantidade: quantidade ?? this.quantidade,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (idCompraCotacao.present) {
      map['id_compra_cotacao'] = Variable<int>(idCompraCotacao.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraCotacaoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('idCompraCotacao: $idCompraCotacao, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }
}

class $CompraPedidoDetalhesTable extends CompraPedidoDetalhes
    with TableInfo<$CompraPedidoDetalhesTable, CompraPedidoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraPedidoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraPedidoMeta =
      const VerificationMeta('idCompraPedido');
  @override
  late final GeneratedColumn<int> idCompraPedido = GeneratedColumn<int>(
      'id_compra_pedido', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cstMeta = const VerificationMeta('cst');
  @override
  late final GeneratedColumn<String> cst = GeneratedColumn<String>(
      'cst', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _csosnMeta = const VerificationMeta('csosn');
  @override
  late final GeneratedColumn<String> csosn = GeneratedColumn<String>(
      'csosn', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cfopMeta = const VerificationMeta('cfop');
  @override
  late final GeneratedColumn<int> cfop = GeneratedColumn<int>(
      'cfop', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsMeta =
      const VerificationMeta('baseCalculoIcms');
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
      'base_calculo_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsMeta =
      const VerificationMeta('valorIcms');
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
      'valor_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIpiMeta =
      const VerificationMeta('valorIpi');
  @override
  late final GeneratedColumn<double> valorIpi = GeneratedColumn<double>(
      'valor_ipi', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIcmsMeta =
      const VerificationMeta('aliquotaIcms');
  @override
  late final GeneratedColumn<double> aliquotaIcms = GeneratedColumn<double>(
      'aliquota_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaIpiMeta =
      const VerificationMeta('aliquotaIpi');
  @override
  late final GeneratedColumn<double> aliquotaIpi = GeneratedColumn<double>(
      'aliquota_ipi', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCompraPedido,
        idProduto,
        quantidade,
        valorUnitario,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        cst,
        csosn,
        cfop,
        baseCalculoIcms,
        valorIcms,
        valorIpi,
        aliquotaIcms,
        aliquotaIpi
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_pedido_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<CompraPedidoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_pedido')) {
      context.handle(
          _idCompraPedidoMeta,
          idCompraPedido.isAcceptableOrUnknown(
              data['id_compra_pedido']!, _idCompraPedidoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('cst')) {
      context.handle(
          _cstMeta, cst.isAcceptableOrUnknown(data['cst']!, _cstMeta));
    }
    if (data.containsKey('csosn')) {
      context.handle(
          _csosnMeta, csosn.isAcceptableOrUnknown(data['csosn']!, _csosnMeta));
    }
    if (data.containsKey('cfop')) {
      context.handle(
          _cfopMeta, cfop.isAcceptableOrUnknown(data['cfop']!, _cfopMeta));
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
          _baseCalculoIcmsMeta,
          baseCalculoIcms.isAcceptableOrUnknown(
              data['base_calculo_icms']!, _baseCalculoIcmsMeta));
    }
    if (data.containsKey('valor_icms')) {
      context.handle(_valorIcmsMeta,
          valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta));
    }
    if (data.containsKey('valor_ipi')) {
      context.handle(_valorIpiMeta,
          valorIpi.isAcceptableOrUnknown(data['valor_ipi']!, _valorIpiMeta));
    }
    if (data.containsKey('aliquota_icms')) {
      context.handle(
          _aliquotaIcmsMeta,
          aliquotaIcms.isAcceptableOrUnknown(
              data['aliquota_icms']!, _aliquotaIcmsMeta));
    }
    if (data.containsKey('aliquota_ipi')) {
      context.handle(
          _aliquotaIpiMeta,
          aliquotaIpi.isAcceptableOrUnknown(
              data['aliquota_ipi']!, _aliquotaIpiMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraPedidoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraPedidoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraPedido: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_compra_pedido']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      cst: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst']),
      csosn: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}csosn']),
      cfop: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop']),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms']),
      valorIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms']),
      valorIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_ipi']),
      aliquotaIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota_icms']),
      aliquotaIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota_ipi']),
    );
  }

  @override
  $CompraPedidoDetalhesTable createAlias(String alias) {
    return $CompraPedidoDetalhesTable(attachedDatabase, alias);
  }
}

class CompraPedidoDetalhe extends DataClass
    implements Insertable<CompraPedidoDetalhe> {
  final int? id;
  final int? idCompraPedido;
  final int? idProduto;
  final double? quantidade;
  final double? valorUnitario;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  final String? cst;
  final String? csosn;
  final int? cfop;
  final double? baseCalculoIcms;
  final double? valorIcms;
  final double? valorIpi;
  final double? aliquotaIcms;
  final double? aliquotaIpi;
  const CompraPedidoDetalhe(
      {this.id,
      this.idCompraPedido,
      this.idProduto,
      this.quantidade,
      this.valorUnitario,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal,
      this.cst,
      this.csosn,
      this.cfop,
      this.baseCalculoIcms,
      this.valorIcms,
      this.valorIpi,
      this.aliquotaIcms,
      this.aliquotaIpi});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraPedido != null) {
      map['id_compra_pedido'] = Variable<int>(idCompraPedido);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || cst != null) {
      map['cst'] = Variable<String>(cst);
    }
    if (!nullToAbsent || csosn != null) {
      map['csosn'] = Variable<String>(csosn);
    }
    if (!nullToAbsent || cfop != null) {
      map['cfop'] = Variable<int>(cfop);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || valorIpi != null) {
      map['valor_ipi'] = Variable<double>(valorIpi);
    }
    if (!nullToAbsent || aliquotaIcms != null) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms);
    }
    if (!nullToAbsent || aliquotaIpi != null) {
      map['aliquota_ipi'] = Variable<double>(aliquotaIpi);
    }
    return map;
  }

  factory CompraPedidoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraPedidoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idCompraPedido: serializer.fromJson<int?>(json['idCompraPedido']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      cst: serializer.fromJson<String?>(json['cst']),
      csosn: serializer.fromJson<String?>(json['csosn']),
      cfop: serializer.fromJson<int?>(json['cfop']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      valorIpi: serializer.fromJson<double?>(json['valorIpi']),
      aliquotaIcms: serializer.fromJson<double?>(json['aliquotaIcms']),
      aliquotaIpi: serializer.fromJson<double?>(json['aliquotaIpi']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraPedido': serializer.toJson<int?>(idCompraPedido),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'cst': serializer.toJson<String?>(cst),
      'csosn': serializer.toJson<String?>(csosn),
      'cfop': serializer.toJson<int?>(cfop),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'valorIpi': serializer.toJson<double?>(valorIpi),
      'aliquotaIcms': serializer.toJson<double?>(aliquotaIcms),
      'aliquotaIpi': serializer.toJson<double?>(aliquotaIpi),
    };
  }

  CompraPedidoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraPedido = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> quantidade = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<String?> cst = const Value.absent(),
          Value<String?> csosn = const Value.absent(),
          Value<int?> cfop = const Value.absent(),
          Value<double?> baseCalculoIcms = const Value.absent(),
          Value<double?> valorIcms = const Value.absent(),
          Value<double?> valorIpi = const Value.absent(),
          Value<double?> aliquotaIcms = const Value.absent(),
          Value<double?> aliquotaIpi = const Value.absent()}) =>
      CompraPedidoDetalhe(
        id: id.present ? id.value : this.id,
        idCompraPedido:
            idCompraPedido.present ? idCompraPedido.value : this.idCompraPedido,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        cst: cst.present ? cst.value : this.cst,
        csosn: csosn.present ? csosn.value : this.csosn,
        cfop: cfop.present ? cfop.value : this.cfop,
        baseCalculoIcms: baseCalculoIcms.present
            ? baseCalculoIcms.value
            : this.baseCalculoIcms,
        valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
        valorIpi: valorIpi.present ? valorIpi.value : this.valorIpi,
        aliquotaIcms:
            aliquotaIcms.present ? aliquotaIcms.value : this.aliquotaIcms,
        aliquotaIpi: aliquotaIpi.present ? aliquotaIpi.value : this.aliquotaIpi,
      );
  @override
  String toString() {
    return (StringBuffer('CompraPedidoDetalhe(')
          ..write('id: $id, ')
          ..write('idCompraPedido: $idCompraPedido, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('cfop: $cfop, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('aliquotaIpi: $aliquotaIpi')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCompraPedido,
      idProduto,
      quantidade,
      valorUnitario,
      valorSubtotal,
      taxaDesconto,
      valorDesconto,
      valorTotal,
      cst,
      csosn,
      cfop,
      baseCalculoIcms,
      valorIcms,
      valorIpi,
      aliquotaIcms,
      aliquotaIpi);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraPedidoDetalhe &&
          other.id == this.id &&
          other.idCompraPedido == this.idCompraPedido &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.valorUnitario == this.valorUnitario &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal &&
          other.cst == this.cst &&
          other.csosn == this.csosn &&
          other.cfop == this.cfop &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.valorIcms == this.valorIcms &&
          other.valorIpi == this.valorIpi &&
          other.aliquotaIcms == this.aliquotaIcms &&
          other.aliquotaIpi == this.aliquotaIpi);
}

class CompraPedidoDetalhesCompanion
    extends UpdateCompanion<CompraPedidoDetalhe> {
  final Value<int?> id;
  final Value<int?> idCompraPedido;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  final Value<double?> valorUnitario;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  final Value<String?> cst;
  final Value<String?> csosn;
  final Value<int?> cfop;
  final Value<double?> baseCalculoIcms;
  final Value<double?> valorIcms;
  final Value<double?> valorIpi;
  final Value<double?> aliquotaIcms;
  final Value<double?> aliquotaIpi;
  const CompraPedidoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idCompraPedido = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.cfop = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.aliquotaIpi = const Value.absent(),
  });
  CompraPedidoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraPedido = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.cst = const Value.absent(),
    this.csosn = const Value.absent(),
    this.cfop = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.aliquotaIpi = const Value.absent(),
  });
  static Insertable<CompraPedidoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idCompraPedido,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
    Expression<double>? valorUnitario,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
    Expression<String>? cst,
    Expression<String>? csosn,
    Expression<int>? cfop,
    Expression<double>? baseCalculoIcms,
    Expression<double>? valorIcms,
    Expression<double>? valorIpi,
    Expression<double>? aliquotaIcms,
    Expression<double>? aliquotaIpi,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraPedido != null) 'id_compra_pedido': idCompraPedido,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (cst != null) 'cst': cst,
      if (csosn != null) 'csosn': csosn,
      if (cfop != null) 'cfop': cfop,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (valorIpi != null) 'valor_ipi': valorIpi,
      if (aliquotaIcms != null) 'aliquota_icms': aliquotaIcms,
      if (aliquotaIpi != null) 'aliquota_ipi': aliquotaIpi,
    });
  }

  CompraPedidoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraPedido,
      Value<int?>? idProduto,
      Value<double?>? quantidade,
      Value<double?>? valorUnitario,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal,
      Value<String?>? cst,
      Value<String?>? csosn,
      Value<int?>? cfop,
      Value<double?>? baseCalculoIcms,
      Value<double?>? valorIcms,
      Value<double?>? valorIpi,
      Value<double?>? aliquotaIcms,
      Value<double?>? aliquotaIpi}) {
    return CompraPedidoDetalhesCompanion(
      id: id ?? this.id,
      idCompraPedido: idCompraPedido ?? this.idCompraPedido,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
      cst: cst ?? this.cst,
      csosn: csosn ?? this.csosn,
      cfop: cfop ?? this.cfop,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      valorIpi: valorIpi ?? this.valorIpi,
      aliquotaIcms: aliquotaIcms ?? this.aliquotaIcms,
      aliquotaIpi: aliquotaIpi ?? this.aliquotaIpi,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraPedido.present) {
      map['id_compra_pedido'] = Variable<int>(idCompraPedido.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (cst.present) {
      map['cst'] = Variable<String>(cst.value);
    }
    if (csosn.present) {
      map['csosn'] = Variable<String>(csosn.value);
    }
    if (cfop.present) {
      map['cfop'] = Variable<int>(cfop.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (valorIpi.present) {
      map['valor_ipi'] = Variable<double>(valorIpi.value);
    }
    if (aliquotaIcms.present) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms.value);
    }
    if (aliquotaIpi.present) {
      map['aliquota_ipi'] = Variable<double>(aliquotaIpi.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraPedidoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idCompraPedido: $idCompraPedido, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('cst: $cst, ')
          ..write('csosn: $csosn, ')
          ..write('cfop: $cfop, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('aliquotaIpi: $aliquotaIpi')
          ..write(')'))
        .toString();
  }
}

class $CompraRequisicaosTable extends CompraRequisicaos
    with TableInfo<$CompraRequisicaosTable, CompraRequisicao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraRequisicaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraTipoRequisicaoMeta =
      const VerificationMeta('idCompraTipoRequisicao');
  @override
  late final GeneratedColumn<int> idCompraTipoRequisicao = GeneratedColumn<int>(
      'id_compra_tipo_requisicao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataRequisicaoMeta =
      const VerificationMeta('dataRequisicao');
  @override
  late final GeneratedColumn<DateTime> dataRequisicao =
      GeneratedColumn<DateTime>('data_requisicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCompraTipoRequisicao,
        idColaborador,
        descricao,
        dataRequisicao,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_requisicao';
  @override
  VerificationContext validateIntegrity(Insertable<CompraRequisicao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_tipo_requisicao')) {
      context.handle(
          _idCompraTipoRequisicaoMeta,
          idCompraTipoRequisicao.isAcceptableOrUnknown(
              data['id_compra_tipo_requisicao']!, _idCompraTipoRequisicaoMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('data_requisicao')) {
      context.handle(
          _dataRequisicaoMeta,
          dataRequisicao.isAcceptableOrUnknown(
              data['data_requisicao']!, _dataRequisicaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraRequisicao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraRequisicao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraTipoRequisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_compra_tipo_requisicao']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      dataRequisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_requisicao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $CompraRequisicaosTable createAlias(String alias) {
    return $CompraRequisicaosTable(attachedDatabase, alias);
  }
}

class CompraRequisicao extends DataClass
    implements Insertable<CompraRequisicao> {
  final int? id;
  final int? idCompraTipoRequisicao;
  final int? idColaborador;
  final String? descricao;
  final DateTime? dataRequisicao;
  final String? observacao;
  const CompraRequisicao(
      {this.id,
      this.idCompraTipoRequisicao,
      this.idColaborador,
      this.descricao,
      this.dataRequisicao,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraTipoRequisicao != null) {
      map['id_compra_tipo_requisicao'] = Variable<int>(idCompraTipoRequisicao);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || dataRequisicao != null) {
      map['data_requisicao'] = Variable<DateTime>(dataRequisicao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory CompraRequisicao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraRequisicao(
      id: serializer.fromJson<int?>(json['id']),
      idCompraTipoRequisicao:
          serializer.fromJson<int?>(json['idCompraTipoRequisicao']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      dataRequisicao: serializer.fromJson<DateTime?>(json['dataRequisicao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraTipoRequisicao': serializer.toJson<int?>(idCompraTipoRequisicao),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'descricao': serializer.toJson<String?>(descricao),
      'dataRequisicao': serializer.toJson<DateTime?>(dataRequisicao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  CompraRequisicao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraTipoRequisicao = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<DateTime?> dataRequisicao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      CompraRequisicao(
        id: id.present ? id.value : this.id,
        idCompraTipoRequisicao: idCompraTipoRequisicao.present
            ? idCompraTipoRequisicao.value
            : this.idCompraTipoRequisicao,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        descricao: descricao.present ? descricao.value : this.descricao,
        dataRequisicao:
            dataRequisicao.present ? dataRequisicao.value : this.dataRequisicao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('CompraRequisicao(')
          ..write('id: $id, ')
          ..write('idCompraTipoRequisicao: $idCompraTipoRequisicao, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('descricao: $descricao, ')
          ..write('dataRequisicao: $dataRequisicao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCompraTipoRequisicao, idColaborador,
      descricao, dataRequisicao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraRequisicao &&
          other.id == this.id &&
          other.idCompraTipoRequisicao == this.idCompraTipoRequisicao &&
          other.idColaborador == this.idColaborador &&
          other.descricao == this.descricao &&
          other.dataRequisicao == this.dataRequisicao &&
          other.observacao == this.observacao);
}

class CompraRequisicaosCompanion extends UpdateCompanion<CompraRequisicao> {
  final Value<int?> id;
  final Value<int?> idCompraTipoRequisicao;
  final Value<int?> idColaborador;
  final Value<String?> descricao;
  final Value<DateTime?> dataRequisicao;
  final Value<String?> observacao;
  const CompraRequisicaosCompanion({
    this.id = const Value.absent(),
    this.idCompraTipoRequisicao = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataRequisicao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  CompraRequisicaosCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraTipoRequisicao = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataRequisicao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<CompraRequisicao> custom({
    Expression<int>? id,
    Expression<int>? idCompraTipoRequisicao,
    Expression<int>? idColaborador,
    Expression<String>? descricao,
    Expression<DateTime>? dataRequisicao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraTipoRequisicao != null)
        'id_compra_tipo_requisicao': idCompraTipoRequisicao,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (descricao != null) 'descricao': descricao,
      if (dataRequisicao != null) 'data_requisicao': dataRequisicao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  CompraRequisicaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraTipoRequisicao,
      Value<int?>? idColaborador,
      Value<String?>? descricao,
      Value<DateTime?>? dataRequisicao,
      Value<String?>? observacao}) {
    return CompraRequisicaosCompanion(
      id: id ?? this.id,
      idCompraTipoRequisicao:
          idCompraTipoRequisicao ?? this.idCompraTipoRequisicao,
      idColaborador: idColaborador ?? this.idColaborador,
      descricao: descricao ?? this.descricao,
      dataRequisicao: dataRequisicao ?? this.dataRequisicao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraTipoRequisicao.present) {
      map['id_compra_tipo_requisicao'] =
          Variable<int>(idCompraTipoRequisicao.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (dataRequisicao.present) {
      map['data_requisicao'] = Variable<DateTime>(dataRequisicao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraRequisicaosCompanion(')
          ..write('id: $id, ')
          ..write('idCompraTipoRequisicao: $idCompraTipoRequisicao, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('descricao: $descricao, ')
          ..write('dataRequisicao: $dataRequisicao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $CompraCotacaosTable extends CompraCotacaos
    with TableInfo<$CompraCotacaosTable, CompraCotacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraCotacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraRequisicaoMeta =
      const VerificationMeta('idCompraRequisicao');
  @override
  late final GeneratedColumn<int> idCompraRequisicao = GeneratedColumn<int>(
      'id_compra_requisicao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataCotacaoMeta =
      const VerificationMeta('dataCotacao');
  @override
  late final GeneratedColumn<DateTime> dataCotacao = GeneratedColumn<DateTime>(
      'data_cotacao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCompraRequisicao, dataCotacao, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_cotacao';
  @override
  VerificationContext validateIntegrity(Insertable<CompraCotacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_requisicao')) {
      context.handle(
          _idCompraRequisicaoMeta,
          idCompraRequisicao.isAcceptableOrUnknown(
              data['id_compra_requisicao']!, _idCompraRequisicaoMeta));
    }
    if (data.containsKey('data_cotacao')) {
      context.handle(
          _dataCotacaoMeta,
          dataCotacao.isAcceptableOrUnknown(
              data['data_cotacao']!, _dataCotacaoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraCotacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraCotacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraRequisicao: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_compra_requisicao']),
      dataCotacao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cotacao']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $CompraCotacaosTable createAlias(String alias) {
    return $CompraCotacaosTable(attachedDatabase, alias);
  }
}

class CompraCotacao extends DataClass implements Insertable<CompraCotacao> {
  final int? id;
  final int? idCompraRequisicao;
  final DateTime? dataCotacao;
  final String? descricao;
  const CompraCotacao(
      {this.id, this.idCompraRequisicao, this.dataCotacao, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraRequisicao != null) {
      map['id_compra_requisicao'] = Variable<int>(idCompraRequisicao);
    }
    if (!nullToAbsent || dataCotacao != null) {
      map['data_cotacao'] = Variable<DateTime>(dataCotacao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory CompraCotacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraCotacao(
      id: serializer.fromJson<int?>(json['id']),
      idCompraRequisicao: serializer.fromJson<int?>(json['idCompraRequisicao']),
      dataCotacao: serializer.fromJson<DateTime?>(json['dataCotacao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraRequisicao': serializer.toJson<int?>(idCompraRequisicao),
      'dataCotacao': serializer.toJson<DateTime?>(dataCotacao),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  CompraCotacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraRequisicao = const Value.absent(),
          Value<DateTime?> dataCotacao = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      CompraCotacao(
        id: id.present ? id.value : this.id,
        idCompraRequisicao: idCompraRequisicao.present
            ? idCompraRequisicao.value
            : this.idCompraRequisicao,
        dataCotacao: dataCotacao.present ? dataCotacao.value : this.dataCotacao,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('CompraCotacao(')
          ..write('id: $id, ')
          ..write('idCompraRequisicao: $idCompraRequisicao, ')
          ..write('dataCotacao: $dataCotacao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCompraRequisicao, dataCotacao, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraCotacao &&
          other.id == this.id &&
          other.idCompraRequisicao == this.idCompraRequisicao &&
          other.dataCotacao == this.dataCotacao &&
          other.descricao == this.descricao);
}

class CompraCotacaosCompanion extends UpdateCompanion<CompraCotacao> {
  final Value<int?> id;
  final Value<int?> idCompraRequisicao;
  final Value<DateTime?> dataCotacao;
  final Value<String?> descricao;
  const CompraCotacaosCompanion({
    this.id = const Value.absent(),
    this.idCompraRequisicao = const Value.absent(),
    this.dataCotacao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  CompraCotacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraRequisicao = const Value.absent(),
    this.dataCotacao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<CompraCotacao> custom({
    Expression<int>? id,
    Expression<int>? idCompraRequisicao,
    Expression<DateTime>? dataCotacao,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraRequisicao != null)
        'id_compra_requisicao': idCompraRequisicao,
      if (dataCotacao != null) 'data_cotacao': dataCotacao,
      if (descricao != null) 'descricao': descricao,
    });
  }

  CompraCotacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraRequisicao,
      Value<DateTime?>? dataCotacao,
      Value<String?>? descricao}) {
    return CompraCotacaosCompanion(
      id: id ?? this.id,
      idCompraRequisicao: idCompraRequisicao ?? this.idCompraRequisicao,
      dataCotacao: dataCotacao ?? this.dataCotacao,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraRequisicao.present) {
      map['id_compra_requisicao'] = Variable<int>(idCompraRequisicao.value);
    }
    if (dataCotacao.present) {
      map['data_cotacao'] = Variable<DateTime>(dataCotacao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraCotacaosCompanion(')
          ..write('id: $id, ')
          ..write('idCompraRequisicao: $idCompraRequisicao, ')
          ..write('dataCotacao: $dataCotacao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $CompraPedidosTable extends CompraPedidos
    with TableInfo<$CompraPedidosTable, CompraPedido> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraPedidosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCompraTipoPedidoMeta =
      const VerificationMeta('idCompraTipoPedido');
  @override
  late final GeneratedColumn<int> idCompraTipoPedido = GeneratedColumn<int>(
      'id_compra_tipo_pedido', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFornecedorMeta =
      const VerificationMeta('idFornecedor');
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
      'id_fornecedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoCotacaoMeta =
      const VerificationMeta('codigoCotacao');
  @override
  late final GeneratedColumn<String> codigoCotacao = GeneratedColumn<String>(
      'codigo_cotacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 32),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataPedidoMeta =
      const VerificationMeta('dataPedido');
  @override
  late final GeneratedColumn<DateTime> dataPedido = GeneratedColumn<DateTime>(
      'data_pedido', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaEntregaMeta =
      const VerificationMeta('dataPrevistaEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevistaEntrega =
      GeneratedColumn<DateTime>('data_prevista_entrega', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevisaoPagamentoMeta =
      const VerificationMeta('dataPrevisaoPagamento');
  @override
  late final GeneratedColumn<DateTime> dataPrevisaoPagamento =
      GeneratedColumn<DateTime>('data_previsao_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _localEntregaMeta =
      const VerificationMeta('localEntrega');
  @override
  late final GeneratedColumn<String> localEntrega = GeneratedColumn<String>(
      'local_entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _localCobrancaMeta =
      const VerificationMeta('localCobranca');
  @override
  late final GeneratedColumn<String> localCobranca = GeneratedColumn<String>(
      'local_cobranca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contatoMeta =
      const VerificationMeta('contato');
  @override
  late final GeneratedColumn<String> contato = GeneratedColumn<String>(
      'contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _tipoFreteMeta =
      const VerificationMeta('tipoFrete');
  @override
  late final GeneratedColumn<String> tipoFrete = GeneratedColumn<String>(
      'tipo_frete', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formaPagamentoMeta =
      const VerificationMeta('formaPagamento');
  @override
  late final GeneratedColumn<String> formaPagamento = GeneratedColumn<String>(
      'forma_pagamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsMeta =
      const VerificationMeta('baseCalculoIcms');
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
      'base_calculo_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsMeta =
      const VerificationMeta('valorIcms');
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
      'valor_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsStMeta =
      const VerificationMeta('baseCalculoIcmsSt');
  @override
  late final GeneratedColumn<double> baseCalculoIcmsSt =
      GeneratedColumn<double>('base_calculo_icms_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsStMeta =
      const VerificationMeta('valorIcmsSt');
  @override
  late final GeneratedColumn<double> valorIcmsSt = GeneratedColumn<double>(
      'valor_icms_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalProdutosMeta =
      const VerificationMeta('valorTotalProdutos');
  @override
  late final GeneratedColumn<double> valorTotalProdutos =
      GeneratedColumn<double>('valor_total_produtos', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSeguroMeta =
      const VerificationMeta('valorSeguro');
  @override
  late final GeneratedColumn<double> valorSeguro = GeneratedColumn<double>(
      'valor_seguro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorOutrasDespesasMeta =
      const VerificationMeta('valorOutrasDespesas');
  @override
  late final GeneratedColumn<double> valorOutrasDespesas =
      GeneratedColumn<double>('valor_outras_despesas', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIpiMeta =
      const VerificationMeta('valorIpi');
  @override
  late final GeneratedColumn<double> valorIpi = GeneratedColumn<double>(
      'valor_ipi', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalNfMeta =
      const VerificationMeta('valorTotalNf');
  @override
  late final GeneratedColumn<double> valorTotalNf = GeneratedColumn<double>(
      'valor_total_nf', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeParcelasMeta =
      const VerificationMeta('quantidadeParcelas');
  @override
  late final GeneratedColumn<int> quantidadeParcelas = GeneratedColumn<int>(
      'quantidade_parcelas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diaPrimeiroVencimentoMeta =
      const VerificationMeta('diaPrimeiroVencimento');
  @override
  late final GeneratedColumn<String> diaPrimeiroVencimento =
      GeneratedColumn<String>('dia_primeiro_vencimento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _intervaloEntreParcelasMeta =
      const VerificationMeta('intervaloEntreParcelas');
  @override
  late final GeneratedColumn<int> intervaloEntreParcelas = GeneratedColumn<int>(
      'intervalo_entre_parcelas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diaFixoParcelaMeta =
      const VerificationMeta('diaFixoParcela');
  @override
  late final GeneratedColumn<String> diaFixoParcela = GeneratedColumn<String>(
      'dia_fixo_parcela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCompraTipoPedido,
        idColaborador,
        idFornecedor,
        codigoCotacao,
        dataPedido,
        dataPrevistaEntrega,
        dataPrevisaoPagamento,
        localEntrega,
        localCobranca,
        contato,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        tipoFrete,
        formaPagamento,
        baseCalculoIcms,
        valorIcms,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalProdutos,
        valorFrete,
        valorSeguro,
        valorOutrasDespesas,
        valorIpi,
        valorTotalNf,
        quantidadeParcelas,
        diaPrimeiroVencimento,
        intervaloEntreParcelas,
        diaFixoParcela
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_pedido';
  @override
  VerificationContext validateIntegrity(Insertable<CompraPedido> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_compra_tipo_pedido')) {
      context.handle(
          _idCompraTipoPedidoMeta,
          idCompraTipoPedido.isAcceptableOrUnknown(
              data['id_compra_tipo_pedido']!, _idCompraTipoPedidoMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
          _idFornecedorMeta,
          idFornecedor.isAcceptableOrUnknown(
              data['id_fornecedor']!, _idFornecedorMeta));
    }
    if (data.containsKey('codigo_cotacao')) {
      context.handle(
          _codigoCotacaoMeta,
          codigoCotacao.isAcceptableOrUnknown(
              data['codigo_cotacao']!, _codigoCotacaoMeta));
    }
    if (data.containsKey('data_pedido')) {
      context.handle(
          _dataPedidoMeta,
          dataPedido.isAcceptableOrUnknown(
              data['data_pedido']!, _dataPedidoMeta));
    }
    if (data.containsKey('data_prevista_entrega')) {
      context.handle(
          _dataPrevistaEntregaMeta,
          dataPrevistaEntrega.isAcceptableOrUnknown(
              data['data_prevista_entrega']!, _dataPrevistaEntregaMeta));
    }
    if (data.containsKey('data_previsao_pagamento')) {
      context.handle(
          _dataPrevisaoPagamentoMeta,
          dataPrevisaoPagamento.isAcceptableOrUnknown(
              data['data_previsao_pagamento']!, _dataPrevisaoPagamentoMeta));
    }
    if (data.containsKey('local_entrega')) {
      context.handle(
          _localEntregaMeta,
          localEntrega.isAcceptableOrUnknown(
              data['local_entrega']!, _localEntregaMeta));
    }
    if (data.containsKey('local_cobranca')) {
      context.handle(
          _localCobrancaMeta,
          localCobranca.isAcceptableOrUnknown(
              data['local_cobranca']!, _localCobrancaMeta));
    }
    if (data.containsKey('contato')) {
      context.handle(_contatoMeta,
          contato.isAcceptableOrUnknown(data['contato']!, _contatoMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('tipo_frete')) {
      context.handle(_tipoFreteMeta,
          tipoFrete.isAcceptableOrUnknown(data['tipo_frete']!, _tipoFreteMeta));
    }
    if (data.containsKey('forma_pagamento')) {
      context.handle(
          _formaPagamentoMeta,
          formaPagamento.isAcceptableOrUnknown(
              data['forma_pagamento']!, _formaPagamentoMeta));
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
          _baseCalculoIcmsMeta,
          baseCalculoIcms.isAcceptableOrUnknown(
              data['base_calculo_icms']!, _baseCalculoIcmsMeta));
    }
    if (data.containsKey('valor_icms')) {
      context.handle(_valorIcmsMeta,
          valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta));
    }
    if (data.containsKey('base_calculo_icms_st')) {
      context.handle(
          _baseCalculoIcmsStMeta,
          baseCalculoIcmsSt.isAcceptableOrUnknown(
              data['base_calculo_icms_st']!, _baseCalculoIcmsStMeta));
    }
    if (data.containsKey('valor_icms_st')) {
      context.handle(
          _valorIcmsStMeta,
          valorIcmsSt.isAcceptableOrUnknown(
              data['valor_icms_st']!, _valorIcmsStMeta));
    }
    if (data.containsKey('valor_total_produtos')) {
      context.handle(
          _valorTotalProdutosMeta,
          valorTotalProdutos.isAcceptableOrUnknown(
              data['valor_total_produtos']!, _valorTotalProdutosMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    if (data.containsKey('valor_seguro')) {
      context.handle(
          _valorSeguroMeta,
          valorSeguro.isAcceptableOrUnknown(
              data['valor_seguro']!, _valorSeguroMeta));
    }
    if (data.containsKey('valor_outras_despesas')) {
      context.handle(
          _valorOutrasDespesasMeta,
          valorOutrasDespesas.isAcceptableOrUnknown(
              data['valor_outras_despesas']!, _valorOutrasDespesasMeta));
    }
    if (data.containsKey('valor_ipi')) {
      context.handle(_valorIpiMeta,
          valorIpi.isAcceptableOrUnknown(data['valor_ipi']!, _valorIpiMeta));
    }
    if (data.containsKey('valor_total_nf')) {
      context.handle(
          _valorTotalNfMeta,
          valorTotalNf.isAcceptableOrUnknown(
              data['valor_total_nf']!, _valorTotalNfMeta));
    }
    if (data.containsKey('quantidade_parcelas')) {
      context.handle(
          _quantidadeParcelasMeta,
          quantidadeParcelas.isAcceptableOrUnknown(
              data['quantidade_parcelas']!, _quantidadeParcelasMeta));
    }
    if (data.containsKey('dia_primeiro_vencimento')) {
      context.handle(
          _diaPrimeiroVencimentoMeta,
          diaPrimeiroVencimento.isAcceptableOrUnknown(
              data['dia_primeiro_vencimento']!, _diaPrimeiroVencimentoMeta));
    }
    if (data.containsKey('intervalo_entre_parcelas')) {
      context.handle(
          _intervaloEntreParcelasMeta,
          intervaloEntreParcelas.isAcceptableOrUnknown(
              data['intervalo_entre_parcelas']!, _intervaloEntreParcelasMeta));
    }
    if (data.containsKey('dia_fixo_parcela')) {
      context.handle(
          _diaFixoParcelaMeta,
          diaFixoParcela.isAcceptableOrUnknown(
              data['dia_fixo_parcela']!, _diaFixoParcelaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraPedido map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraPedido(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCompraTipoPedido: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_compra_tipo_pedido']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fornecedor']),
      codigoCotacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_cotacao']),
      dataPedido: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_pedido']),
      dataPrevistaEntrega: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prevista_entrega']),
      dataPrevisaoPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_previsao_pagamento']),
      localEntrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_entrega']),
      localCobranca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_cobranca']),
      contato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}contato']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      tipoFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_frete']),
      formaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}forma_pagamento']),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms']),
      valorIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms']),
      baseCalculoIcmsSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms_st']),
      valorIcmsSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms_st']),
      valorTotalProdutos: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_produtos']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
      valorSeguro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_seguro']),
      valorOutrasDespesas: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_outras_despesas']),
      valorIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_ipi']),
      valorTotalNf: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total_nf']),
      quantidadeParcelas: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_parcelas']),
      diaPrimeiroVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}dia_primeiro_vencimento']),
      intervaloEntreParcelas: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}intervalo_entre_parcelas']),
      diaFixoParcela: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}dia_fixo_parcela']),
    );
  }

  @override
  $CompraPedidosTable createAlias(String alias) {
    return $CompraPedidosTable(attachedDatabase, alias);
  }
}

class CompraPedido extends DataClass implements Insertable<CompraPedido> {
  final int? id;
  final int? idCompraTipoPedido;
  final int? idColaborador;
  final int? idFornecedor;
  final String? codigoCotacao;
  final DateTime? dataPedido;
  final DateTime? dataPrevistaEntrega;
  final DateTime? dataPrevisaoPagamento;
  final String? localEntrega;
  final String? localCobranca;
  final String? contato;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  final String? tipoFrete;
  final String? formaPagamento;
  final double? baseCalculoIcms;
  final double? valorIcms;
  final double? baseCalculoIcmsSt;
  final double? valorIcmsSt;
  final double? valorTotalProdutos;
  final double? valorFrete;
  final double? valorSeguro;
  final double? valorOutrasDespesas;
  final double? valorIpi;
  final double? valorTotalNf;
  final int? quantidadeParcelas;
  final String? diaPrimeiroVencimento;
  final int? intervaloEntreParcelas;
  final String? diaFixoParcela;
  const CompraPedido(
      {this.id,
      this.idCompraTipoPedido,
      this.idColaborador,
      this.idFornecedor,
      this.codigoCotacao,
      this.dataPedido,
      this.dataPrevistaEntrega,
      this.dataPrevisaoPagamento,
      this.localEntrega,
      this.localCobranca,
      this.contato,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal,
      this.tipoFrete,
      this.formaPagamento,
      this.baseCalculoIcms,
      this.valorIcms,
      this.baseCalculoIcmsSt,
      this.valorIcmsSt,
      this.valorTotalProdutos,
      this.valorFrete,
      this.valorSeguro,
      this.valorOutrasDespesas,
      this.valorIpi,
      this.valorTotalNf,
      this.quantidadeParcelas,
      this.diaPrimeiroVencimento,
      this.intervaloEntreParcelas,
      this.diaFixoParcela});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCompraTipoPedido != null) {
      map['id_compra_tipo_pedido'] = Variable<int>(idCompraTipoPedido);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || codigoCotacao != null) {
      map['codigo_cotacao'] = Variable<String>(codigoCotacao);
    }
    if (!nullToAbsent || dataPedido != null) {
      map['data_pedido'] = Variable<DateTime>(dataPedido);
    }
    if (!nullToAbsent || dataPrevistaEntrega != null) {
      map['data_prevista_entrega'] = Variable<DateTime>(dataPrevistaEntrega);
    }
    if (!nullToAbsent || dataPrevisaoPagamento != null) {
      map['data_previsao_pagamento'] =
          Variable<DateTime>(dataPrevisaoPagamento);
    }
    if (!nullToAbsent || localEntrega != null) {
      map['local_entrega'] = Variable<String>(localEntrega);
    }
    if (!nullToAbsent || localCobranca != null) {
      map['local_cobranca'] = Variable<String>(localCobranca);
    }
    if (!nullToAbsent || contato != null) {
      map['contato'] = Variable<String>(contato);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || tipoFrete != null) {
      map['tipo_frete'] = Variable<String>(tipoFrete);
    }
    if (!nullToAbsent || formaPagamento != null) {
      map['forma_pagamento'] = Variable<String>(formaPagamento);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || baseCalculoIcmsSt != null) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt);
    }
    if (!nullToAbsent || valorIcmsSt != null) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt);
    }
    if (!nullToAbsent || valorTotalProdutos != null) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    if (!nullToAbsent || valorSeguro != null) {
      map['valor_seguro'] = Variable<double>(valorSeguro);
    }
    if (!nullToAbsent || valorOutrasDespesas != null) {
      map['valor_outras_despesas'] = Variable<double>(valorOutrasDespesas);
    }
    if (!nullToAbsent || valorIpi != null) {
      map['valor_ipi'] = Variable<double>(valorIpi);
    }
    if (!nullToAbsent || valorTotalNf != null) {
      map['valor_total_nf'] = Variable<double>(valorTotalNf);
    }
    if (!nullToAbsent || quantidadeParcelas != null) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas);
    }
    if (!nullToAbsent || diaPrimeiroVencimento != null) {
      map['dia_primeiro_vencimento'] = Variable<String>(diaPrimeiroVencimento);
    }
    if (!nullToAbsent || intervaloEntreParcelas != null) {
      map['intervalo_entre_parcelas'] = Variable<int>(intervaloEntreParcelas);
    }
    if (!nullToAbsent || diaFixoParcela != null) {
      map['dia_fixo_parcela'] = Variable<String>(diaFixoParcela);
    }
    return map;
  }

  factory CompraPedido.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraPedido(
      id: serializer.fromJson<int?>(json['id']),
      idCompraTipoPedido: serializer.fromJson<int?>(json['idCompraTipoPedido']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      codigoCotacao: serializer.fromJson<String?>(json['codigoCotacao']),
      dataPedido: serializer.fromJson<DateTime?>(json['dataPedido']),
      dataPrevistaEntrega:
          serializer.fromJson<DateTime?>(json['dataPrevistaEntrega']),
      dataPrevisaoPagamento:
          serializer.fromJson<DateTime?>(json['dataPrevisaoPagamento']),
      localEntrega: serializer.fromJson<String?>(json['localEntrega']),
      localCobranca: serializer.fromJson<String?>(json['localCobranca']),
      contato: serializer.fromJson<String?>(json['contato']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      tipoFrete: serializer.fromJson<String?>(json['tipoFrete']),
      formaPagamento: serializer.fromJson<String?>(json['formaPagamento']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      baseCalculoIcmsSt:
          serializer.fromJson<double?>(json['baseCalculoIcmsSt']),
      valorIcmsSt: serializer.fromJson<double?>(json['valorIcmsSt']),
      valorTotalProdutos:
          serializer.fromJson<double?>(json['valorTotalProdutos']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
      valorSeguro: serializer.fromJson<double?>(json['valorSeguro']),
      valorOutrasDespesas:
          serializer.fromJson<double?>(json['valorOutrasDespesas']),
      valorIpi: serializer.fromJson<double?>(json['valorIpi']),
      valorTotalNf: serializer.fromJson<double?>(json['valorTotalNf']),
      quantidadeParcelas: serializer.fromJson<int?>(json['quantidadeParcelas']),
      diaPrimeiroVencimento:
          serializer.fromJson<String?>(json['diaPrimeiroVencimento']),
      intervaloEntreParcelas:
          serializer.fromJson<int?>(json['intervaloEntreParcelas']),
      diaFixoParcela: serializer.fromJson<String?>(json['diaFixoParcela']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCompraTipoPedido': serializer.toJson<int?>(idCompraTipoPedido),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'codigoCotacao': serializer.toJson<String?>(codigoCotacao),
      'dataPedido': serializer.toJson<DateTime?>(dataPedido),
      'dataPrevistaEntrega': serializer.toJson<DateTime?>(dataPrevistaEntrega),
      'dataPrevisaoPagamento':
          serializer.toJson<DateTime?>(dataPrevisaoPagamento),
      'localEntrega': serializer.toJson<String?>(localEntrega),
      'localCobranca': serializer.toJson<String?>(localCobranca),
      'contato': serializer.toJson<String?>(contato),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'tipoFrete': serializer.toJson<String?>(tipoFrete),
      'formaPagamento': serializer.toJson<String?>(formaPagamento),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'baseCalculoIcmsSt': serializer.toJson<double?>(baseCalculoIcmsSt),
      'valorIcmsSt': serializer.toJson<double?>(valorIcmsSt),
      'valorTotalProdutos': serializer.toJson<double?>(valorTotalProdutos),
      'valorFrete': serializer.toJson<double?>(valorFrete),
      'valorSeguro': serializer.toJson<double?>(valorSeguro),
      'valorOutrasDespesas': serializer.toJson<double?>(valorOutrasDespesas),
      'valorIpi': serializer.toJson<double?>(valorIpi),
      'valorTotalNf': serializer.toJson<double?>(valorTotalNf),
      'quantidadeParcelas': serializer.toJson<int?>(quantidadeParcelas),
      'diaPrimeiroVencimento':
          serializer.toJson<String?>(diaPrimeiroVencimento),
      'intervaloEntreParcelas': serializer.toJson<int?>(intervaloEntreParcelas),
      'diaFixoParcela': serializer.toJson<String?>(diaFixoParcela),
    };
  }

  CompraPedido copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCompraTipoPedido = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idFornecedor = const Value.absent(),
          Value<String?> codigoCotacao = const Value.absent(),
          Value<DateTime?> dataPedido = const Value.absent(),
          Value<DateTime?> dataPrevistaEntrega = const Value.absent(),
          Value<DateTime?> dataPrevisaoPagamento = const Value.absent(),
          Value<String?> localEntrega = const Value.absent(),
          Value<String?> localCobranca = const Value.absent(),
          Value<String?> contato = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<String?> tipoFrete = const Value.absent(),
          Value<String?> formaPagamento = const Value.absent(),
          Value<double?> baseCalculoIcms = const Value.absent(),
          Value<double?> valorIcms = const Value.absent(),
          Value<double?> baseCalculoIcmsSt = const Value.absent(),
          Value<double?> valorIcmsSt = const Value.absent(),
          Value<double?> valorTotalProdutos = const Value.absent(),
          Value<double?> valorFrete = const Value.absent(),
          Value<double?> valorSeguro = const Value.absent(),
          Value<double?> valorOutrasDespesas = const Value.absent(),
          Value<double?> valorIpi = const Value.absent(),
          Value<double?> valorTotalNf = const Value.absent(),
          Value<int?> quantidadeParcelas = const Value.absent(),
          Value<String?> diaPrimeiroVencimento = const Value.absent(),
          Value<int?> intervaloEntreParcelas = const Value.absent(),
          Value<String?> diaFixoParcela = const Value.absent()}) =>
      CompraPedido(
        id: id.present ? id.value : this.id,
        idCompraTipoPedido: idCompraTipoPedido.present
            ? idCompraTipoPedido.value
            : this.idCompraTipoPedido,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idFornecedor:
            idFornecedor.present ? idFornecedor.value : this.idFornecedor,
        codigoCotacao:
            codigoCotacao.present ? codigoCotacao.value : this.codigoCotacao,
        dataPedido: dataPedido.present ? dataPedido.value : this.dataPedido,
        dataPrevistaEntrega: dataPrevistaEntrega.present
            ? dataPrevistaEntrega.value
            : this.dataPrevistaEntrega,
        dataPrevisaoPagamento: dataPrevisaoPagamento.present
            ? dataPrevisaoPagamento.value
            : this.dataPrevisaoPagamento,
        localEntrega:
            localEntrega.present ? localEntrega.value : this.localEntrega,
        localCobranca:
            localCobranca.present ? localCobranca.value : this.localCobranca,
        contato: contato.present ? contato.value : this.contato,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        tipoFrete: tipoFrete.present ? tipoFrete.value : this.tipoFrete,
        formaPagamento:
            formaPagamento.present ? formaPagamento.value : this.formaPagamento,
        baseCalculoIcms: baseCalculoIcms.present
            ? baseCalculoIcms.value
            : this.baseCalculoIcms,
        valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
        baseCalculoIcmsSt: baseCalculoIcmsSt.present
            ? baseCalculoIcmsSt.value
            : this.baseCalculoIcmsSt,
        valorIcmsSt: valorIcmsSt.present ? valorIcmsSt.value : this.valorIcmsSt,
        valorTotalProdutos: valorTotalProdutos.present
            ? valorTotalProdutos.value
            : this.valorTotalProdutos,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
        valorSeguro: valorSeguro.present ? valorSeguro.value : this.valorSeguro,
        valorOutrasDespesas: valorOutrasDespesas.present
            ? valorOutrasDespesas.value
            : this.valorOutrasDespesas,
        valorIpi: valorIpi.present ? valorIpi.value : this.valorIpi,
        valorTotalNf:
            valorTotalNf.present ? valorTotalNf.value : this.valorTotalNf,
        quantidadeParcelas: quantidadeParcelas.present
            ? quantidadeParcelas.value
            : this.quantidadeParcelas,
        diaPrimeiroVencimento: diaPrimeiroVencimento.present
            ? diaPrimeiroVencimento.value
            : this.diaPrimeiroVencimento,
        intervaloEntreParcelas: intervaloEntreParcelas.present
            ? intervaloEntreParcelas.value
            : this.intervaloEntreParcelas,
        diaFixoParcela:
            diaFixoParcela.present ? diaFixoParcela.value : this.diaFixoParcela,
      );
  @override
  String toString() {
    return (StringBuffer('CompraPedido(')
          ..write('id: $id, ')
          ..write('idCompraTipoPedido: $idCompraTipoPedido, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('codigoCotacao: $codigoCotacao, ')
          ..write('dataPedido: $dataPedido, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('dataPrevisaoPagamento: $dataPrevisaoPagamento, ')
          ..write('localEntrega: $localEntrega, ')
          ..write('localCobranca: $localCobranca, ')
          ..write('contato: $contato, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorOutrasDespesas: $valorOutrasDespesas, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('valorTotalNf: $valorTotalNf, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('diaPrimeiroVencimento: $diaPrimeiroVencimento, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixoParcela: $diaFixoParcela')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idCompraTipoPedido,
        idColaborador,
        idFornecedor,
        codigoCotacao,
        dataPedido,
        dataPrevistaEntrega,
        dataPrevisaoPagamento,
        localEntrega,
        localCobranca,
        contato,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        tipoFrete,
        formaPagamento,
        baseCalculoIcms,
        valorIcms,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalProdutos,
        valorFrete,
        valorSeguro,
        valorOutrasDespesas,
        valorIpi,
        valorTotalNf,
        quantidadeParcelas,
        diaPrimeiroVencimento,
        intervaloEntreParcelas,
        diaFixoParcela
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraPedido &&
          other.id == this.id &&
          other.idCompraTipoPedido == this.idCompraTipoPedido &&
          other.idColaborador == this.idColaborador &&
          other.idFornecedor == this.idFornecedor &&
          other.codigoCotacao == this.codigoCotacao &&
          other.dataPedido == this.dataPedido &&
          other.dataPrevistaEntrega == this.dataPrevistaEntrega &&
          other.dataPrevisaoPagamento == this.dataPrevisaoPagamento &&
          other.localEntrega == this.localEntrega &&
          other.localCobranca == this.localCobranca &&
          other.contato == this.contato &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal &&
          other.tipoFrete == this.tipoFrete &&
          other.formaPagamento == this.formaPagamento &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.valorIcms == this.valorIcms &&
          other.baseCalculoIcmsSt == this.baseCalculoIcmsSt &&
          other.valorIcmsSt == this.valorIcmsSt &&
          other.valorTotalProdutos == this.valorTotalProdutos &&
          other.valorFrete == this.valorFrete &&
          other.valorSeguro == this.valorSeguro &&
          other.valorOutrasDespesas == this.valorOutrasDespesas &&
          other.valorIpi == this.valorIpi &&
          other.valorTotalNf == this.valorTotalNf &&
          other.quantidadeParcelas == this.quantidadeParcelas &&
          other.diaPrimeiroVencimento == this.diaPrimeiroVencimento &&
          other.intervaloEntreParcelas == this.intervaloEntreParcelas &&
          other.diaFixoParcela == this.diaFixoParcela);
}

class CompraPedidosCompanion extends UpdateCompanion<CompraPedido> {
  final Value<int?> id;
  final Value<int?> idCompraTipoPedido;
  final Value<int?> idColaborador;
  final Value<int?> idFornecedor;
  final Value<String?> codigoCotacao;
  final Value<DateTime?> dataPedido;
  final Value<DateTime?> dataPrevistaEntrega;
  final Value<DateTime?> dataPrevisaoPagamento;
  final Value<String?> localEntrega;
  final Value<String?> localCobranca;
  final Value<String?> contato;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  final Value<String?> tipoFrete;
  final Value<String?> formaPagamento;
  final Value<double?> baseCalculoIcms;
  final Value<double?> valorIcms;
  final Value<double?> baseCalculoIcmsSt;
  final Value<double?> valorIcmsSt;
  final Value<double?> valorTotalProdutos;
  final Value<double?> valorFrete;
  final Value<double?> valorSeguro;
  final Value<double?> valorOutrasDespesas;
  final Value<double?> valorIpi;
  final Value<double?> valorTotalNf;
  final Value<int?> quantidadeParcelas;
  final Value<String?> diaPrimeiroVencimento;
  final Value<int?> intervaloEntreParcelas;
  final Value<String?> diaFixoParcela;
  const CompraPedidosCompanion({
    this.id = const Value.absent(),
    this.idCompraTipoPedido = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.codigoCotacao = const Value.absent(),
    this.dataPedido = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.dataPrevisaoPagamento = const Value.absent(),
    this.localEntrega = const Value.absent(),
    this.localCobranca = const Value.absent(),
    this.contato = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorOutrasDespesas = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.valorTotalNf = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.diaPrimeiroVencimento = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixoParcela = const Value.absent(),
  });
  CompraPedidosCompanion.insert({
    this.id = const Value.absent(),
    this.idCompraTipoPedido = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.codigoCotacao = const Value.absent(),
    this.dataPedido = const Value.absent(),
    this.dataPrevistaEntrega = const Value.absent(),
    this.dataPrevisaoPagamento = const Value.absent(),
    this.localEntrega = const Value.absent(),
    this.localCobranca = const Value.absent(),
    this.contato = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorOutrasDespesas = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.valorTotalNf = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.diaPrimeiroVencimento = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.diaFixoParcela = const Value.absent(),
  });
  static Insertable<CompraPedido> custom({
    Expression<int>? id,
    Expression<int>? idCompraTipoPedido,
    Expression<int>? idColaborador,
    Expression<int>? idFornecedor,
    Expression<String>? codigoCotacao,
    Expression<DateTime>? dataPedido,
    Expression<DateTime>? dataPrevistaEntrega,
    Expression<DateTime>? dataPrevisaoPagamento,
    Expression<String>? localEntrega,
    Expression<String>? localCobranca,
    Expression<String>? contato,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
    Expression<String>? tipoFrete,
    Expression<String>? formaPagamento,
    Expression<double>? baseCalculoIcms,
    Expression<double>? valorIcms,
    Expression<double>? baseCalculoIcmsSt,
    Expression<double>? valorIcmsSt,
    Expression<double>? valorTotalProdutos,
    Expression<double>? valorFrete,
    Expression<double>? valorSeguro,
    Expression<double>? valorOutrasDespesas,
    Expression<double>? valorIpi,
    Expression<double>? valorTotalNf,
    Expression<int>? quantidadeParcelas,
    Expression<String>? diaPrimeiroVencimento,
    Expression<int>? intervaloEntreParcelas,
    Expression<String>? diaFixoParcela,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCompraTipoPedido != null)
        'id_compra_tipo_pedido': idCompraTipoPedido,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (codigoCotacao != null) 'codigo_cotacao': codigoCotacao,
      if (dataPedido != null) 'data_pedido': dataPedido,
      if (dataPrevistaEntrega != null)
        'data_prevista_entrega': dataPrevistaEntrega,
      if (dataPrevisaoPagamento != null)
        'data_previsao_pagamento': dataPrevisaoPagamento,
      if (localEntrega != null) 'local_entrega': localEntrega,
      if (localCobranca != null) 'local_cobranca': localCobranca,
      if (contato != null) 'contato': contato,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (tipoFrete != null) 'tipo_frete': tipoFrete,
      if (formaPagamento != null) 'forma_pagamento': formaPagamento,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (baseCalculoIcmsSt != null) 'base_calculo_icms_st': baseCalculoIcmsSt,
      if (valorIcmsSt != null) 'valor_icms_st': valorIcmsSt,
      if (valorTotalProdutos != null)
        'valor_total_produtos': valorTotalProdutos,
      if (valorFrete != null) 'valor_frete': valorFrete,
      if (valorSeguro != null) 'valor_seguro': valorSeguro,
      if (valorOutrasDespesas != null)
        'valor_outras_despesas': valorOutrasDespesas,
      if (valorIpi != null) 'valor_ipi': valorIpi,
      if (valorTotalNf != null) 'valor_total_nf': valorTotalNf,
      if (quantidadeParcelas != null) 'quantidade_parcelas': quantidadeParcelas,
      if (diaPrimeiroVencimento != null)
        'dia_primeiro_vencimento': diaPrimeiroVencimento,
      if (intervaloEntreParcelas != null)
        'intervalo_entre_parcelas': intervaloEntreParcelas,
      if (diaFixoParcela != null) 'dia_fixo_parcela': diaFixoParcela,
    });
  }

  CompraPedidosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCompraTipoPedido,
      Value<int?>? idColaborador,
      Value<int?>? idFornecedor,
      Value<String?>? codigoCotacao,
      Value<DateTime?>? dataPedido,
      Value<DateTime?>? dataPrevistaEntrega,
      Value<DateTime?>? dataPrevisaoPagamento,
      Value<String?>? localEntrega,
      Value<String?>? localCobranca,
      Value<String?>? contato,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal,
      Value<String?>? tipoFrete,
      Value<String?>? formaPagamento,
      Value<double?>? baseCalculoIcms,
      Value<double?>? valorIcms,
      Value<double?>? baseCalculoIcmsSt,
      Value<double?>? valorIcmsSt,
      Value<double?>? valorTotalProdutos,
      Value<double?>? valorFrete,
      Value<double?>? valorSeguro,
      Value<double?>? valorOutrasDespesas,
      Value<double?>? valorIpi,
      Value<double?>? valorTotalNf,
      Value<int?>? quantidadeParcelas,
      Value<String?>? diaPrimeiroVencimento,
      Value<int?>? intervaloEntreParcelas,
      Value<String?>? diaFixoParcela}) {
    return CompraPedidosCompanion(
      id: id ?? this.id,
      idCompraTipoPedido: idCompraTipoPedido ?? this.idCompraTipoPedido,
      idColaborador: idColaborador ?? this.idColaborador,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      codigoCotacao: codigoCotacao ?? this.codigoCotacao,
      dataPedido: dataPedido ?? this.dataPedido,
      dataPrevistaEntrega: dataPrevistaEntrega ?? this.dataPrevistaEntrega,
      dataPrevisaoPagamento:
          dataPrevisaoPagamento ?? this.dataPrevisaoPagamento,
      localEntrega: localEntrega ?? this.localEntrega,
      localCobranca: localCobranca ?? this.localCobranca,
      contato: contato ?? this.contato,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
      tipoFrete: tipoFrete ?? this.tipoFrete,
      formaPagamento: formaPagamento ?? this.formaPagamento,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      baseCalculoIcmsSt: baseCalculoIcmsSt ?? this.baseCalculoIcmsSt,
      valorIcmsSt: valorIcmsSt ?? this.valorIcmsSt,
      valorTotalProdutos: valorTotalProdutos ?? this.valorTotalProdutos,
      valorFrete: valorFrete ?? this.valorFrete,
      valorSeguro: valorSeguro ?? this.valorSeguro,
      valorOutrasDespesas: valorOutrasDespesas ?? this.valorOutrasDespesas,
      valorIpi: valorIpi ?? this.valorIpi,
      valorTotalNf: valorTotalNf ?? this.valorTotalNf,
      quantidadeParcelas: quantidadeParcelas ?? this.quantidadeParcelas,
      diaPrimeiroVencimento:
          diaPrimeiroVencimento ?? this.diaPrimeiroVencimento,
      intervaloEntreParcelas:
          intervaloEntreParcelas ?? this.intervaloEntreParcelas,
      diaFixoParcela: diaFixoParcela ?? this.diaFixoParcela,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCompraTipoPedido.present) {
      map['id_compra_tipo_pedido'] = Variable<int>(idCompraTipoPedido.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (codigoCotacao.present) {
      map['codigo_cotacao'] = Variable<String>(codigoCotacao.value);
    }
    if (dataPedido.present) {
      map['data_pedido'] = Variable<DateTime>(dataPedido.value);
    }
    if (dataPrevistaEntrega.present) {
      map['data_prevista_entrega'] =
          Variable<DateTime>(dataPrevistaEntrega.value);
    }
    if (dataPrevisaoPagamento.present) {
      map['data_previsao_pagamento'] =
          Variable<DateTime>(dataPrevisaoPagamento.value);
    }
    if (localEntrega.present) {
      map['local_entrega'] = Variable<String>(localEntrega.value);
    }
    if (localCobranca.present) {
      map['local_cobranca'] = Variable<String>(localCobranca.value);
    }
    if (contato.present) {
      map['contato'] = Variable<String>(contato.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (tipoFrete.present) {
      map['tipo_frete'] = Variable<String>(tipoFrete.value);
    }
    if (formaPagamento.present) {
      map['forma_pagamento'] = Variable<String>(formaPagamento.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (baseCalculoIcmsSt.present) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt.value);
    }
    if (valorIcmsSt.present) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt.value);
    }
    if (valorTotalProdutos.present) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    if (valorSeguro.present) {
      map['valor_seguro'] = Variable<double>(valorSeguro.value);
    }
    if (valorOutrasDespesas.present) {
      map['valor_outras_despesas'] =
          Variable<double>(valorOutrasDespesas.value);
    }
    if (valorIpi.present) {
      map['valor_ipi'] = Variable<double>(valorIpi.value);
    }
    if (valorTotalNf.present) {
      map['valor_total_nf'] = Variable<double>(valorTotalNf.value);
    }
    if (quantidadeParcelas.present) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas.value);
    }
    if (diaPrimeiroVencimento.present) {
      map['dia_primeiro_vencimento'] =
          Variable<String>(diaPrimeiroVencimento.value);
    }
    if (intervaloEntreParcelas.present) {
      map['intervalo_entre_parcelas'] =
          Variable<int>(intervaloEntreParcelas.value);
    }
    if (diaFixoParcela.present) {
      map['dia_fixo_parcela'] = Variable<String>(diaFixoParcela.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraPedidosCompanion(')
          ..write('id: $id, ')
          ..write('idCompraTipoPedido: $idCompraTipoPedido, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('codigoCotacao: $codigoCotacao, ')
          ..write('dataPedido: $dataPedido, ')
          ..write('dataPrevistaEntrega: $dataPrevistaEntrega, ')
          ..write('dataPrevisaoPagamento: $dataPrevisaoPagamento, ')
          ..write('localEntrega: $localEntrega, ')
          ..write('localCobranca: $localCobranca, ')
          ..write('contato: $contato, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorOutrasDespesas: $valorOutrasDespesas, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('valorTotalNf: $valorTotalNf, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('diaPrimeiroVencimento: $diaPrimeiroVencimento, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('diaFixoParcela: $diaFixoParcela')
          ..write(')'))
        .toString();
  }
}

class $ProdutoGruposTable extends ProdutoGrupos
    with TableInfo<$ProdutoGruposTable, ProdutoGrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoGruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_grupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoGrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoGrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoGrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoGruposTable createAlias(String alias) {
    return $ProdutoGruposTable(attachedDatabase, alias);
  }
}

class ProdutoGrupo extends DataClass implements Insertable<ProdutoGrupo> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoGrupo({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoGrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoGrupo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoGrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoGrupo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoGrupo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoGrupo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoGruposCompanion extends UpdateCompanion<ProdutoGrupo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoGruposCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoGruposCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoGrupo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoGruposCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoGruposCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoGruposCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoSubgruposTable extends ProdutoSubgrupos
    with TableInfo<$ProdutoSubgruposTable, ProdutoSubgrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoSubgruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoGrupoMeta =
      const VerificationMeta('idProdutoGrupo');
  @override
  late final GeneratedColumn<int> idProdutoGrupo = GeneratedColumn<int>(
      'id_produto_grupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idProdutoGrupo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_subgrupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoSubgrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_grupo')) {
      context.handle(
          _idProdutoGrupoMeta,
          idProdutoGrupo.isAcceptableOrUnknown(
              data['id_produto_grupo']!, _idProdutoGrupoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoSubgrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoSubgrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoGrupo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_grupo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoSubgruposTable createAlias(String alias) {
    return $ProdutoSubgruposTable(attachedDatabase, alias);
  }
}

class ProdutoSubgrupo extends DataClass implements Insertable<ProdutoSubgrupo> {
  final int? id;
  final int? idProdutoGrupo;
  final String? nome;
  final String? descricao;
  const ProdutoSubgrupo(
      {this.id, this.idProdutoGrupo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoGrupo != null) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoSubgrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoSubgrupo(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoGrupo: serializer.fromJson<int?>(json['idProdutoGrupo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoGrupo': serializer.toJson<int?>(idProdutoGrupo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoSubgrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoGrupo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoSubgrupo(
        id: id.present ? id.value : this.id,
        idProdutoGrupo:
            idProdutoGrupo.present ? idProdutoGrupo.value : this.idProdutoGrupo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoSubgrupo(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProdutoGrupo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoSubgrupo &&
          other.id == this.id &&
          other.idProdutoGrupo == this.idProdutoGrupo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoSubgruposCompanion extends UpdateCompanion<ProdutoSubgrupo> {
  final Value<int?> id;
  final Value<int?> idProdutoGrupo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoSubgruposCompanion({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoSubgruposCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoSubgrupo> custom({
    Expression<int>? id,
    Expression<int>? idProdutoGrupo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoGrupo != null) 'id_produto_grupo': idProdutoGrupo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoSubgruposCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoGrupo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return ProdutoSubgruposCompanion(
      id: id ?? this.id,
      idProdutoGrupo: idProdutoGrupo ?? this.idProdutoGrupo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoGrupo.present) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoSubgruposCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoMarcasTable extends ProdutoMarcas
    with TableInfo<$ProdutoMarcasTable, ProdutoMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_marca';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoMarcasTable createAlias(String alias) {
    return $ProdutoMarcasTable(attachedDatabase, alias);
  }
}

class ProdutoMarca extends DataClass implements Insertable<ProdutoMarca> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoMarca({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoMarca(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoMarca(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoMarca(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoMarca &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoMarcasCompanion extends UpdateCompanion<ProdutoMarca> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoMarcasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoMarca> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoMarcasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarcasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoUnidadesTable extends ProdutoUnidades
    with TableInfo<$ProdutoUnidadesTable, ProdutoUnidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoUnidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeFracionarMeta =
      const VerificationMeta('podeFracionar');
  @override
  late final GeneratedColumn<String> podeFracionar = GeneratedColumn<String>(
      'pode_fracionar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, sigla, descricao, podeFracionar];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_unidade';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoUnidade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('pode_fracionar')) {
      context.handle(
          _podeFracionarMeta,
          podeFracionar.isAcceptableOrUnknown(
              data['pode_fracionar']!, _podeFracionarMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoUnidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoUnidade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      podeFracionar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_fracionar']),
    );
  }

  @override
  $ProdutoUnidadesTable createAlias(String alias) {
    return $ProdutoUnidadesTable(attachedDatabase, alias);
  }
}

class ProdutoUnidade extends DataClass implements Insertable<ProdutoUnidade> {
  final int? id;
  final String? sigla;
  final String? descricao;
  final String? podeFracionar;
  const ProdutoUnidade(
      {this.id, this.sigla, this.descricao, this.podeFracionar});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || podeFracionar != null) {
      map['pode_fracionar'] = Variable<String>(podeFracionar);
    }
    return map;
  }

  factory ProdutoUnidade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoUnidade(
      id: serializer.fromJson<int?>(json['id']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      podeFracionar: serializer.fromJson<String?>(json['podeFracionar']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'sigla': serializer.toJson<String?>(sigla),
      'descricao': serializer.toJson<String?>(descricao),
      'podeFracionar': serializer.toJson<String?>(podeFracionar),
    };
  }

  ProdutoUnidade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> podeFracionar = const Value.absent()}) =>
      ProdutoUnidade(
        id: id.present ? id.value : this.id,
        sigla: sigla.present ? sigla.value : this.sigla,
        descricao: descricao.present ? descricao.value : this.descricao,
        podeFracionar:
            podeFracionar.present ? podeFracionar.value : this.podeFracionar,
      );
  @override
  String toString() {
    return (StringBuffer('ProdutoUnidade(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sigla, descricao, podeFracionar);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoUnidade &&
          other.id == this.id &&
          other.sigla == this.sigla &&
          other.descricao == this.descricao &&
          other.podeFracionar == this.podeFracionar);
}

class ProdutoUnidadesCompanion extends UpdateCompanion<ProdutoUnidade> {
  final Value<int?> id;
  final Value<String?> sigla;
  final Value<String?> descricao;
  final Value<String?> podeFracionar;
  const ProdutoUnidadesCompanion({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  ProdutoUnidadesCompanion.insert({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  static Insertable<ProdutoUnidade> custom({
    Expression<int>? id,
    Expression<String>? sigla,
    Expression<String>? descricao,
    Expression<String>? podeFracionar,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sigla != null) 'sigla': sigla,
      if (descricao != null) 'descricao': descricao,
      if (podeFracionar != null) 'pode_fracionar': podeFracionar,
    });
  }

  ProdutoUnidadesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? sigla,
      Value<String?>? descricao,
      Value<String?>? podeFracionar}) {
    return ProdutoUnidadesCompanion(
      id: id ?? this.id,
      sigla: sigla ?? this.sigla,
      descricao: descricao ?? this.descricao,
      podeFracionar: podeFracionar ?? this.podeFracionar,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (podeFracionar.present) {
      map['pode_fracionar'] = Variable<String>(podeFracionar.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidadesCompanion(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }
}

class $TributIcmsCustomCabsTable extends TributIcmsCustomCabs
    with TableInfo<$TributIcmsCustomCabsTable, TributIcmsCustomCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributIcmsCustomCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, descricao, origemMercadoria];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_icms_custom_cab';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributIcmsCustomCab> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributIcmsCustomCab map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributIcmsCustomCab(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
    );
  }

  @override
  $TributIcmsCustomCabsTable createAlias(String alias) {
    return $TributIcmsCustomCabsTable(attachedDatabase, alias);
  }
}

class TributIcmsCustomCab extends DataClass
    implements Insertable<TributIcmsCustomCab> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  const TributIcmsCustomCab({this.id, this.descricao, this.origemMercadoria});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    return map;
  }

  factory TributIcmsCustomCab.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributIcmsCustomCab(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
    };
  }

  TributIcmsCustomCab copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent()}) =>
      TributIcmsCustomCab(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
      );
  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCab(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributIcmsCustomCab &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria);
}

class TributIcmsCustomCabsCompanion
    extends UpdateCompanion<TributIcmsCustomCab> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  const TributIcmsCustomCabsCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  TributIcmsCustomCabsCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
  });
  static Insertable<TributIcmsCustomCab> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
    });
  }

  TributIcmsCustomCabsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria}) {
    return TributIcmsCustomCabsCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributIcmsCustomCabsCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria')
          ..write(')'))
        .toString();
  }
}

class $TributGrupoTributariosTable extends TributGrupoTributarios
    with TableInfo<$TributGrupoTributariosTable, TributGrupoTributario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TributGrupoTributariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _origemMercadoriaMeta =
      const VerificationMeta('origemMercadoria');
  @override
  late final GeneratedColumn<String> origemMercadoria = GeneratedColumn<String>(
      'origem_mercadoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, origemMercadoria, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tribut_grupo_tributario';
  @override
  VerificationContext validateIntegrity(
      Insertable<TributGrupoTributario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('origem_mercadoria')) {
      context.handle(
          _origemMercadoriaMeta,
          origemMercadoria.isAcceptableOrUnknown(
              data['origem_mercadoria']!, _origemMercadoriaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TributGrupoTributario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TributGrupoTributario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      origemMercadoria: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_mercadoria']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $TributGrupoTributariosTable createAlias(String alias) {
    return $TributGrupoTributariosTable(attachedDatabase, alias);
  }
}

class TributGrupoTributario extends DataClass
    implements Insertable<TributGrupoTributario> {
  final int? id;
  final String? descricao;
  final String? origemMercadoria;
  final String? observacao;
  const TributGrupoTributario(
      {this.id, this.descricao, this.origemMercadoria, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || origemMercadoria != null) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory TributGrupoTributario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TributGrupoTributario(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      origemMercadoria: serializer.fromJson<String?>(json['origemMercadoria']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'origemMercadoria': serializer.toJson<String?>(origemMercadoria),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  TributGrupoTributario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> origemMercadoria = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      TributGrupoTributario(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        origemMercadoria: origemMercadoria.present
            ? origemMercadoria.value
            : this.origemMercadoria,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  @override
  String toString() {
    return (StringBuffer('TributGrupoTributario(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, origemMercadoria, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TributGrupoTributario &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.origemMercadoria == this.origemMercadoria &&
          other.observacao == this.observacao);
}

class TributGrupoTributariosCompanion
    extends UpdateCompanion<TributGrupoTributario> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> origemMercadoria;
  final Value<String?> observacao;
  const TributGrupoTributariosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  TributGrupoTributariosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.origemMercadoria = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<TributGrupoTributario> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? origemMercadoria,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (origemMercadoria != null) 'origem_mercadoria': origemMercadoria,
      if (observacao != null) 'observacao': observacao,
    });
  }

  TributGrupoTributariosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? origemMercadoria,
      Value<String?>? observacao}) {
    return TributGrupoTributariosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      origemMercadoria: origemMercadoria ?? this.origemMercadoria,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (origemMercadoria.present) {
      map['origem_mercadoria'] = Variable<String>(origemMercadoria.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TributGrupoTributariosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('origemMercadoria: $origemMercadoria, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoSubgrupoMeta =
      const VerificationMeta('idProdutoSubgrupo');
  @override
  late final GeneratedColumn<int> idProdutoSubgrupo = GeneratedColumn<int>(
      'id_produto_subgrupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMarcaMeta =
      const VerificationMeta('idProdutoMarca');
  @override
  late final GeneratedColumn<int> idProdutoMarca = GeneratedColumn<int>(
      'id_produto_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoUnidadeMeta =
      const VerificationMeta('idProdutoUnidade');
  @override
  late final GeneratedColumn<int> idProdutoUnidade = GeneratedColumn<int>(
      'id_produto_unidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
      'id_tribut_icms_custom_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>('id_tribut_grupo_tributario', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
      'gtin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _codigoNcmMeta =
      const VerificationMeta('codigoNcm');
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
      'codigo_ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _estoqueMinimoMeta =
      const VerificationMeta('estoqueMinimo');
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
      'estoque_minimo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMaximoMeta =
      const VerificationMeta('estoqueMaximo');
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
      'estoque_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeEstoqueMeta =
      const VerificationMeta('quantidadeEstoque');
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>('quantidade_estoque', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProdutoSubgrupo,
        idProdutoMarca,
        idProdutoUnidade,
        idTributIcmsCustomCab,
        idTributGrupoTributario,
        nome,
        descricao,
        gtin,
        codigoInterno,
        valorCompra,
        valorVenda,
        codigoNcm,
        estoqueMinimo,
        estoqueMaximo,
        quantidadeEstoque,
        dataCadastro
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(Insertable<Produto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_subgrupo')) {
      context.handle(
          _idProdutoSubgrupoMeta,
          idProdutoSubgrupo.isAcceptableOrUnknown(
              data['id_produto_subgrupo']!, _idProdutoSubgrupoMeta));
    }
    if (data.containsKey('id_produto_marca')) {
      context.handle(
          _idProdutoMarcaMeta,
          idProdutoMarca.isAcceptableOrUnknown(
              data['id_produto_marca']!, _idProdutoMarcaMeta));
    }
    if (data.containsKey('id_produto_unidade')) {
      context.handle(
          _idProdutoUnidadeMeta,
          idProdutoUnidade.isAcceptableOrUnknown(
              data['id_produto_unidade']!, _idProdutoUnidadeMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
          _idTributIcmsCustomCabMeta,
          idTributIcmsCustomCab.isAcceptableOrUnknown(
              data['id_tribut_icms_custom_cab']!, _idTributIcmsCustomCabMeta));
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
          _idTributGrupoTributarioMeta,
          idTributGrupoTributario.isAcceptableOrUnknown(
              data['id_tribut_grupo_tributario']!,
              _idTributGrupoTributarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('gtin')) {
      context.handle(
          _gtinMeta, gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(_codigoNcmMeta,
          codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta));
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
          _estoqueMinimoMeta,
          estoqueMinimo.isAcceptableOrUnknown(
              data['estoque_minimo']!, _estoqueMinimoMeta));
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
          _estoqueMaximoMeta,
          estoqueMaximo.isAcceptableOrUnknown(
              data['estoque_maximo']!, _estoqueMaximoMeta));
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
          _quantidadeEstoqueMeta,
          quantidadeEstoque.isAcceptableOrUnknown(
              data['quantidade_estoque']!, _quantidadeEstoqueMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoSubgrupo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_produto_subgrupo']),
      idProdutoMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_marca']),
      idProdutoUnidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_unidade']),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_icms_custom_cab']),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_grupo_tributario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      gtin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gtin']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      codigoNcm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_ncm']),
      estoqueMinimo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_minimo']),
      estoqueMaximo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_maximo']),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_estoque']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idProdutoSubgrupo;
  final int? idProdutoMarca;
  final int? idProdutoUnidade;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  final DateTime? dataCadastro;
  const Produto(
      {this.id,
      this.idProdutoSubgrupo,
      this.idProdutoMarca,
      this.idProdutoUnidade,
      this.idTributIcmsCustomCab,
      this.idTributGrupoTributario,
      this.nome,
      this.descricao,
      this.gtin,
      this.codigoInterno,
      this.valorCompra,
      this.valorVenda,
      this.codigoNcm,
      this.estoqueMinimo,
      this.estoqueMaximo,
      this.quantidadeEstoque,
      this.dataCadastro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoSubgrupo != null) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo);
    }
    if (!nullToAbsent || idProdutoMarca != null) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca);
    }
    if (!nullToAbsent || idProdutoUnidade != null) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Produto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoSubgrupo: serializer.fromJson<int?>(json['idProdutoSubgrupo']),
      idProdutoMarca: serializer.fromJson<int?>(json['idProdutoMarca']),
      idProdutoUnidade: serializer.fromJson<int?>(json['idProdutoUnidade']),
      idTributIcmsCustomCab:
          serializer.fromJson<int?>(json['idTributIcmsCustomCab']),
      idTributGrupoTributario:
          serializer.fromJson<int?>(json['idTributGrupoTributario']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque:
          serializer.fromJson<double?>(json['quantidadeEstoque']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoSubgrupo': serializer.toJson<int?>(idProdutoSubgrupo),
      'idProdutoMarca': serializer.toJson<int?>(idProdutoMarca),
      'idProdutoUnidade': serializer.toJson<int?>(idProdutoUnidade),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario':
          serializer.toJson<int?>(idTributGrupoTributario),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Produto copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoSubgrupo = const Value.absent(),
          Value<int?> idProdutoMarca = const Value.absent(),
          Value<int?> idProdutoUnidade = const Value.absent(),
          Value<int?> idTributIcmsCustomCab = const Value.absent(),
          Value<int?> idTributGrupoTributario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> gtin = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> codigoNcm = const Value.absent(),
          Value<double?> estoqueMinimo = const Value.absent(),
          Value<double?> estoqueMaximo = const Value.absent(),
          Value<double?> quantidadeEstoque = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent()}) =>
      Produto(
        id: id.present ? id.value : this.id,
        idProdutoSubgrupo: idProdutoSubgrupo.present
            ? idProdutoSubgrupo.value
            : this.idProdutoSubgrupo,
        idProdutoMarca:
            idProdutoMarca.present ? idProdutoMarca.value : this.idProdutoMarca,
        idProdutoUnidade: idProdutoUnidade.present
            ? idProdutoUnidade.value
            : this.idProdutoUnidade,
        idTributIcmsCustomCab: idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
        idTributGrupoTributario: idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        gtin: gtin.present ? gtin.value : this.gtin,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
        estoqueMinimo:
            estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
        estoqueMaximo:
            estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
        quantidadeEstoque: quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
      );
  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idProdutoSubgrupo,
      idProdutoMarca,
      idProdutoUnidade,
      idTributIcmsCustomCab,
      idTributGrupoTributario,
      nome,
      descricao,
      gtin,
      codigoInterno,
      valorCompra,
      valorVenda,
      codigoNcm,
      estoqueMinimo,
      estoqueMaximo,
      quantidadeEstoque,
      dataCadastro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idProdutoSubgrupo == this.idProdutoSubgrupo &&
          other.idProdutoMarca == this.idProdutoMarca &&
          other.idProdutoUnidade == this.idProdutoUnidade &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque &&
          other.dataCadastro == this.dataCadastro);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idProdutoSubgrupo;
  final Value<int?> idProdutoMarca;
  final Value<int?> idProdutoUnidade;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  final Value<DateTime?> dataCadastro;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idProdutoSubgrupo,
    Expression<int>? idProdutoMarca,
    Expression<int>? idProdutoUnidade,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoSubgrupo != null) 'id_produto_subgrupo': idProdutoSubgrupo,
      if (idProdutoMarca != null) 'id_produto_marca': idProdutoMarca,
      if (idProdutoUnidade != null) 'id_produto_unidade': idProdutoUnidade,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  ProdutosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoSubgrupo,
      Value<int?>? idProdutoMarca,
      Value<int?>? idProdutoUnidade,
      Value<int?>? idTributIcmsCustomCab,
      Value<int?>? idTributGrupoTributario,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? gtin,
      Value<String?>? codigoInterno,
      Value<double?>? valorCompra,
      Value<double?>? valorVenda,
      Value<String?>? codigoNcm,
      Value<double?>? estoqueMinimo,
      Value<double?>? estoqueMaximo,
      Value<double?>? quantidadeEstoque,
      Value<DateTime?>? dataCadastro}) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idProdutoSubgrupo: idProdutoSubgrupo ?? this.idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca ?? this.idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade ?? this.idProdutoUnidade,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoSubgrupo.present) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo.value);
    }
    if (idProdutoMarca.present) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca.value);
    }
    if (idProdutoUnidade.present) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] =
          Variable<int>(idTributIcmsCustomCab.value);
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $CompraTipoRequisicaosTable extends CompraTipoRequisicaos
    with TableInfo<$CompraTipoRequisicaosTable, CompraTipoRequisicao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraTipoRequisicaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_tipo_requisicao';
  @override
  VerificationContext validateIntegrity(
      Insertable<CompraTipoRequisicao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraTipoRequisicao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraTipoRequisicao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $CompraTipoRequisicaosTable createAlias(String alias) {
    return $CompraTipoRequisicaosTable(attachedDatabase, alias);
  }
}

class CompraTipoRequisicao extends DataClass
    implements Insertable<CompraTipoRequisicao> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const CompraTipoRequisicao({this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory CompraTipoRequisicao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraTipoRequisicao(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  CompraTipoRequisicao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      CompraTipoRequisicao(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('CompraTipoRequisicao(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraTipoRequisicao &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class CompraTipoRequisicaosCompanion
    extends UpdateCompanion<CompraTipoRequisicao> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const CompraTipoRequisicaosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  CompraTipoRequisicaosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<CompraTipoRequisicao> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  CompraTipoRequisicaosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return CompraTipoRequisicaosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraTipoRequisicaosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $CompraTipoPedidosTable extends CompraTipoPedidos
    with TableInfo<$CompraTipoPedidosTable, CompraTipoPedido> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CompraTipoPedidosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'compra_tipo_pedido';
  @override
  VerificationContext validateIntegrity(Insertable<CompraTipoPedido> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CompraTipoPedido map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CompraTipoPedido(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $CompraTipoPedidosTable createAlias(String alias) {
    return $CompraTipoPedidosTable(attachedDatabase, alias);
  }
}

class CompraTipoPedido extends DataClass
    implements Insertable<CompraTipoPedido> {
  final int? id;
  final String? codigo;
  final String? nome;
  final String? descricao;
  const CompraTipoPedido({this.id, this.codigo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory CompraTipoPedido.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CompraTipoPedido(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  CompraTipoPedido copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      CompraTipoPedido(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('CompraTipoPedido(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CompraTipoPedido &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class CompraTipoPedidosCompanion extends UpdateCompanion<CompraTipoPedido> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const CompraTipoPedidosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  CompraTipoPedidosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<CompraTipoPedido> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  CompraTipoPedidosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return CompraTipoPedidosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CompraTipoPedidosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaFornecedorsTable extends ViewPessoaFornecedors
    with TableInfo<$ViewPessoaFornecedorsTable, ViewPessoaFornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaFornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_fornecedor';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaFornecedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaFornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaFornecedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaFornecedorsTable createAlias(String alias) {
    return $ViewPessoaFornecedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaFornecedor extends DataClass
    implements Insertable<ViewPessoaFornecedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaFornecedor(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaFornecedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaFornecedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaFornecedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaFornecedor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaFornecedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaFornecedorsCompanion
    extends UpdateCompanion<ViewPessoaFornecedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaFornecedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaFornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaFornecedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaFornecedorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaFornecedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $CompraRequisicaoDetalhesTable compraRequisicaoDetalhes =
      $CompraRequisicaoDetalhesTable(this);
  late final $CompraFornecedorCotacaosTable compraFornecedorCotacaos =
      $CompraFornecedorCotacaosTable(this);
  late final $CompraCotacaoDetalhesTable compraCotacaoDetalhes =
      $CompraCotacaoDetalhesTable(this);
  late final $CompraPedidoDetalhesTable compraPedidoDetalhes =
      $CompraPedidoDetalhesTable(this);
  late final $CompraRequisicaosTable compraRequisicaos =
      $CompraRequisicaosTable(this);
  late final $CompraCotacaosTable compraCotacaos = $CompraCotacaosTable(this);
  late final $CompraPedidosTable compraPedidos = $CompraPedidosTable(this);
  late final $ProdutoGruposTable produtoGrupos = $ProdutoGruposTable(this);
  late final $ProdutoSubgruposTable produtoSubgrupos =
      $ProdutoSubgruposTable(this);
  late final $ProdutoMarcasTable produtoMarcas = $ProdutoMarcasTable(this);
  late final $ProdutoUnidadesTable produtoUnidades =
      $ProdutoUnidadesTable(this);
  late final $TributIcmsCustomCabsTable tributIcmsCustomCabs =
      $TributIcmsCustomCabsTable(this);
  late final $TributGrupoTributariosTable tributGrupoTributarios =
      $TributGrupoTributariosTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $CompraTipoRequisicaosTable compraTipoRequisicaos =
      $CompraTipoRequisicaosTable(this);
  late final $CompraTipoPedidosTable compraTipoPedidos =
      $CompraTipoPedidosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaFornecedorsTable viewPessoaFornecedors =
      $ViewPessoaFornecedorsTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final CompraRequisicaoDao compraRequisicaoDao =
      CompraRequisicaoDao(this as AppDatabase);
  late final CompraCotacaoDao compraCotacaoDao =
      CompraCotacaoDao(this as AppDatabase);
  late final CompraPedidoDao compraPedidoDao =
      CompraPedidoDao(this as AppDatabase);
  late final ProdutoGrupoDao produtoGrupoDao =
      ProdutoGrupoDao(this as AppDatabase);
  late final ProdutoSubgrupoDao produtoSubgrupoDao =
      ProdutoSubgrupoDao(this as AppDatabase);
  late final ProdutoMarcaDao produtoMarcaDao =
      ProdutoMarcaDao(this as AppDatabase);
  late final ProdutoUnidadeDao produtoUnidadeDao =
      ProdutoUnidadeDao(this as AppDatabase);
  late final TributIcmsCustomCabDao tributIcmsCustomCabDao =
      TributIcmsCustomCabDao(this as AppDatabase);
  late final TributGrupoTributarioDao tributGrupoTributarioDao =
      TributGrupoTributarioDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final CompraTipoRequisicaoDao compraTipoRequisicaoDao =
      CompraTipoRequisicaoDao(this as AppDatabase);
  late final CompraTipoPedidoDao compraTipoPedidoDao =
      CompraTipoPedidoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaFornecedorDao viewPessoaFornecedorDao =
      ViewPessoaFornecedorDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        compraRequisicaoDetalhes,
        compraFornecedorCotacaos,
        compraCotacaoDetalhes,
        compraPedidoDetalhes,
        compraRequisicaos,
        compraCotacaos,
        compraPedidos,
        produtoGrupos,
        produtoSubgrupos,
        produtoMarcas,
        produtoUnidades,
        tributIcmsCustomCabs,
        tributGrupoTributarios,
        produtos,
        compraTipoRequisicaos,
        compraTipoPedidos,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaFornecedors,
        viewPessoaColaboradors
      ];
}
