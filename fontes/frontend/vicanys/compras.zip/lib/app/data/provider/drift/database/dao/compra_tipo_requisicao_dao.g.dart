// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'compra_tipo_requisicao_dao.dart';

// ignore_for_file: type=lint
mixin _$CompraTipoRequisicaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CompraTipoRequisicaosTable get compraTipoRequisicaos =>
      attachedDatabase.compraTipoRequisicaos;
}
