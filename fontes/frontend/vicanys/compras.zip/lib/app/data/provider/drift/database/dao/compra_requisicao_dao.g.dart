// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'compra_requisicao_dao.dart';

// ignore_for_file: type=lint
mixin _$CompraRequisicaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CompraRequisicaosTable get compraRequisicaos =>
      attachedDatabase.compraRequisicaos;
  $CompraRequisicaoDetalhesTable get compraRequisicaoDetalhes =>
      attachedDatabase.compraRequisicaoDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $CompraTipoRequisicaosTable get compraTipoRequisicaos =>
      attachedDatabase.compraTipoRequisicaos;
}
