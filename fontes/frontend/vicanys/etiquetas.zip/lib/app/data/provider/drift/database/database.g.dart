// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $EtiquetaTemplatesTable extends EtiquetaTemplates
    with TableInfo<$EtiquetaTemplatesTable, EtiquetaTemplate> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EtiquetaTemplatesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idEtiquetaLayoutMeta =
      const VerificationMeta('idEtiquetaLayout');
  @override
  late final GeneratedColumn<int> idEtiquetaLayout = GeneratedColumn<int>(
      'id_etiqueta_layout', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tabelaMeta = const VerificationMeta('tabela');
  @override
  late final GeneratedColumn<String> tabela = GeneratedColumn<String>(
      'tabela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _campoMeta = const VerificationMeta('campo');
  @override
  late final GeneratedColumn<String> campo = GeneratedColumn<String>(
      'campo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formatoMeta =
      const VerificationMeta('formato');
  @override
  late final GeneratedColumn<String> formato = GeneratedColumn<String>(
      'formato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeRepeticoesMeta =
      const VerificationMeta('quantidadeRepeticoes');
  @override
  late final GeneratedColumn<int> quantidadeRepeticoes = GeneratedColumn<int>(
      'quantidade_repeticoes', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _filtroMeta = const VerificationMeta('filtro');
  @override
  late final GeneratedColumn<String> filtro = GeneratedColumn<String>(
      'filtro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idEtiquetaLayout,
        tabela,
        campo,
        formato,
        quantidadeRepeticoes,
        filtro
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'etiqueta_template';
  @override
  VerificationContext validateIntegrity(Insertable<EtiquetaTemplate> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_etiqueta_layout')) {
      context.handle(
          _idEtiquetaLayoutMeta,
          idEtiquetaLayout.isAcceptableOrUnknown(
              data['id_etiqueta_layout']!, _idEtiquetaLayoutMeta));
    }
    if (data.containsKey('tabela')) {
      context.handle(_tabelaMeta,
          tabela.isAcceptableOrUnknown(data['tabela']!, _tabelaMeta));
    }
    if (data.containsKey('campo')) {
      context.handle(
          _campoMeta, campo.isAcceptableOrUnknown(data['campo']!, _campoMeta));
    }
    if (data.containsKey('formato')) {
      context.handle(_formatoMeta,
          formato.isAcceptableOrUnknown(data['formato']!, _formatoMeta));
    }
    if (data.containsKey('quantidade_repeticoes')) {
      context.handle(
          _quantidadeRepeticoesMeta,
          quantidadeRepeticoes.isAcceptableOrUnknown(
              data['quantidade_repeticoes']!, _quantidadeRepeticoesMeta));
    }
    if (data.containsKey('filtro')) {
      context.handle(_filtroMeta,
          filtro.isAcceptableOrUnknown(data['filtro']!, _filtroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EtiquetaTemplate map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EtiquetaTemplate(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idEtiquetaLayout: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_etiqueta_layout']),
      tabela: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tabela']),
      campo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}campo']),
      formato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}formato']),
      quantidadeRepeticoes: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_repeticoes']),
      filtro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}filtro']),
    );
  }

  @override
  $EtiquetaTemplatesTable createAlias(String alias) {
    return $EtiquetaTemplatesTable(attachedDatabase, alias);
  }
}

class EtiquetaTemplate extends DataClass
    implements Insertable<EtiquetaTemplate> {
  final int? id;
  final int? idEtiquetaLayout;
  final String? tabela;
  final String? campo;
  final String? formato;
  final int? quantidadeRepeticoes;
  final String? filtro;
  const EtiquetaTemplate(
      {this.id,
      this.idEtiquetaLayout,
      this.tabela,
      this.campo,
      this.formato,
      this.quantidadeRepeticoes,
      this.filtro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idEtiquetaLayout != null) {
      map['id_etiqueta_layout'] = Variable<int>(idEtiquetaLayout);
    }
    if (!nullToAbsent || tabela != null) {
      map['tabela'] = Variable<String>(tabela);
    }
    if (!nullToAbsent || campo != null) {
      map['campo'] = Variable<String>(campo);
    }
    if (!nullToAbsent || formato != null) {
      map['formato'] = Variable<String>(formato);
    }
    if (!nullToAbsent || quantidadeRepeticoes != null) {
      map['quantidade_repeticoes'] = Variable<int>(quantidadeRepeticoes);
    }
    if (!nullToAbsent || filtro != null) {
      map['filtro'] = Variable<String>(filtro);
    }
    return map;
  }

  factory EtiquetaTemplate.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EtiquetaTemplate(
      id: serializer.fromJson<int?>(json['id']),
      idEtiquetaLayout: serializer.fromJson<int?>(json['idEtiquetaLayout']),
      tabela: serializer.fromJson<String?>(json['tabela']),
      campo: serializer.fromJson<String?>(json['campo']),
      formato: serializer.fromJson<String?>(json['formato']),
      quantidadeRepeticoes:
          serializer.fromJson<int?>(json['quantidadeRepeticoes']),
      filtro: serializer.fromJson<String?>(json['filtro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idEtiquetaLayout': serializer.toJson<int?>(idEtiquetaLayout),
      'tabela': serializer.toJson<String?>(tabela),
      'campo': serializer.toJson<String?>(campo),
      'formato': serializer.toJson<String?>(formato),
      'quantidadeRepeticoes': serializer.toJson<int?>(quantidadeRepeticoes),
      'filtro': serializer.toJson<String?>(filtro),
    };
  }

  EtiquetaTemplate copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idEtiquetaLayout = const Value.absent(),
          Value<String?> tabela = const Value.absent(),
          Value<String?> campo = const Value.absent(),
          Value<String?> formato = const Value.absent(),
          Value<int?> quantidadeRepeticoes = const Value.absent(),
          Value<String?> filtro = const Value.absent()}) =>
      EtiquetaTemplate(
        id: id.present ? id.value : this.id,
        idEtiquetaLayout: idEtiquetaLayout.present
            ? idEtiquetaLayout.value
            : this.idEtiquetaLayout,
        tabela: tabela.present ? tabela.value : this.tabela,
        campo: campo.present ? campo.value : this.campo,
        formato: formato.present ? formato.value : this.formato,
        quantidadeRepeticoes: quantidadeRepeticoes.present
            ? quantidadeRepeticoes.value
            : this.quantidadeRepeticoes,
        filtro: filtro.present ? filtro.value : this.filtro,
      );
  @override
  String toString() {
    return (StringBuffer('EtiquetaTemplate(')
          ..write('id: $id, ')
          ..write('idEtiquetaLayout: $idEtiquetaLayout, ')
          ..write('tabela: $tabela, ')
          ..write('campo: $campo, ')
          ..write('formato: $formato, ')
          ..write('quantidadeRepeticoes: $quantidadeRepeticoes, ')
          ..write('filtro: $filtro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idEtiquetaLayout, tabela, campo, formato,
      quantidadeRepeticoes, filtro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EtiquetaTemplate &&
          other.id == this.id &&
          other.idEtiquetaLayout == this.idEtiquetaLayout &&
          other.tabela == this.tabela &&
          other.campo == this.campo &&
          other.formato == this.formato &&
          other.quantidadeRepeticoes == this.quantidadeRepeticoes &&
          other.filtro == this.filtro);
}

class EtiquetaTemplatesCompanion extends UpdateCompanion<EtiquetaTemplate> {
  final Value<int?> id;
  final Value<int?> idEtiquetaLayout;
  final Value<String?> tabela;
  final Value<String?> campo;
  final Value<String?> formato;
  final Value<int?> quantidadeRepeticoes;
  final Value<String?> filtro;
  const EtiquetaTemplatesCompanion({
    this.id = const Value.absent(),
    this.idEtiquetaLayout = const Value.absent(),
    this.tabela = const Value.absent(),
    this.campo = const Value.absent(),
    this.formato = const Value.absent(),
    this.quantidadeRepeticoes = const Value.absent(),
    this.filtro = const Value.absent(),
  });
  EtiquetaTemplatesCompanion.insert({
    this.id = const Value.absent(),
    this.idEtiquetaLayout = const Value.absent(),
    this.tabela = const Value.absent(),
    this.campo = const Value.absent(),
    this.formato = const Value.absent(),
    this.quantidadeRepeticoes = const Value.absent(),
    this.filtro = const Value.absent(),
  });
  static Insertable<EtiquetaTemplate> custom({
    Expression<int>? id,
    Expression<int>? idEtiquetaLayout,
    Expression<String>? tabela,
    Expression<String>? campo,
    Expression<String>? formato,
    Expression<int>? quantidadeRepeticoes,
    Expression<String>? filtro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idEtiquetaLayout != null) 'id_etiqueta_layout': idEtiquetaLayout,
      if (tabela != null) 'tabela': tabela,
      if (campo != null) 'campo': campo,
      if (formato != null) 'formato': formato,
      if (quantidadeRepeticoes != null)
        'quantidade_repeticoes': quantidadeRepeticoes,
      if (filtro != null) 'filtro': filtro,
    });
  }

  EtiquetaTemplatesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idEtiquetaLayout,
      Value<String?>? tabela,
      Value<String?>? campo,
      Value<String?>? formato,
      Value<int?>? quantidadeRepeticoes,
      Value<String?>? filtro}) {
    return EtiquetaTemplatesCompanion(
      id: id ?? this.id,
      idEtiquetaLayout: idEtiquetaLayout ?? this.idEtiquetaLayout,
      tabela: tabela ?? this.tabela,
      campo: campo ?? this.campo,
      formato: formato ?? this.formato,
      quantidadeRepeticoes: quantidadeRepeticoes ?? this.quantidadeRepeticoes,
      filtro: filtro ?? this.filtro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idEtiquetaLayout.present) {
      map['id_etiqueta_layout'] = Variable<int>(idEtiquetaLayout.value);
    }
    if (tabela.present) {
      map['tabela'] = Variable<String>(tabela.value);
    }
    if (campo.present) {
      map['campo'] = Variable<String>(campo.value);
    }
    if (formato.present) {
      map['formato'] = Variable<String>(formato.value);
    }
    if (quantidadeRepeticoes.present) {
      map['quantidade_repeticoes'] = Variable<int>(quantidadeRepeticoes.value);
    }
    if (filtro.present) {
      map['filtro'] = Variable<String>(filtro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EtiquetaTemplatesCompanion(')
          ..write('id: $id, ')
          ..write('idEtiquetaLayout: $idEtiquetaLayout, ')
          ..write('tabela: $tabela, ')
          ..write('campo: $campo, ')
          ..write('formato: $formato, ')
          ..write('quantidadeRepeticoes: $quantidadeRepeticoes, ')
          ..write('filtro: $filtro')
          ..write(')'))
        .toString();
  }
}

class $EtiquetaLayoutsTable extends EtiquetaLayouts
    with TableInfo<$EtiquetaLayoutsTable, EtiquetaLayout> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EtiquetaLayoutsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFormatoPapelMeta =
      const VerificationMeta('idFormatoPapel');
  @override
  late final GeneratedColumn<int> idFormatoPapel = GeneratedColumn<int>(
      'id_formato_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoFabricanteMeta =
      const VerificationMeta('codigoFabricante');
  @override
  late final GeneratedColumn<String> codigoFabricante = GeneratedColumn<String>(
      'codigo_fabricante', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeHorizontalMeta =
      const VerificationMeta('quantidadeHorizontal');
  @override
  late final GeneratedColumn<int> quantidadeHorizontal = GeneratedColumn<int>(
      'quantidade_horizontal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeVerticalMeta =
      const VerificationMeta('quantidadeVertical');
  @override
  late final GeneratedColumn<int> quantidadeVertical = GeneratedColumn<int>(
      'quantidade_vertical', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _margemSuperiorMeta =
      const VerificationMeta('margemSuperior');
  @override
  late final GeneratedColumn<int> margemSuperior = GeneratedColumn<int>(
      'margem_superior', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _margemInferiorMeta =
      const VerificationMeta('margemInferior');
  @override
  late final GeneratedColumn<int> margemInferior = GeneratedColumn<int>(
      'margem_inferior', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _margemEsquerdaMeta =
      const VerificationMeta('margemEsquerda');
  @override
  late final GeneratedColumn<int> margemEsquerda = GeneratedColumn<int>(
      'margem_esquerda', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _margemDireitaMeta =
      const VerificationMeta('margemDireita');
  @override
  late final GeneratedColumn<int> margemDireita = GeneratedColumn<int>(
      'margem_direita', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _espacamentoHorizontalMeta =
      const VerificationMeta('espacamentoHorizontal');
  @override
  late final GeneratedColumn<int> espacamentoHorizontal = GeneratedColumn<int>(
      'espacamento_horizontal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _espacamentoVerticalMeta =
      const VerificationMeta('espacamentoVertical');
  @override
  late final GeneratedColumn<int> espacamentoVertical = GeneratedColumn<int>(
      'espacamento_vertical', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFormatoPapel,
        codigoFabricante,
        quantidade,
        quantidadeHorizontal,
        quantidadeVertical,
        margemSuperior,
        margemInferior,
        margemEsquerda,
        margemDireita,
        espacamentoHorizontal,
        espacamentoVertical
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'etiqueta_layout';
  @override
  VerificationContext validateIntegrity(Insertable<EtiquetaLayout> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_formato_papel')) {
      context.handle(
          _idFormatoPapelMeta,
          idFormatoPapel.isAcceptableOrUnknown(
              data['id_formato_papel']!, _idFormatoPapelMeta));
    }
    if (data.containsKey('codigo_fabricante')) {
      context.handle(
          _codigoFabricanteMeta,
          codigoFabricante.isAcceptableOrUnknown(
              data['codigo_fabricante']!, _codigoFabricanteMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('quantidade_horizontal')) {
      context.handle(
          _quantidadeHorizontalMeta,
          quantidadeHorizontal.isAcceptableOrUnknown(
              data['quantidade_horizontal']!, _quantidadeHorizontalMeta));
    }
    if (data.containsKey('quantidade_vertical')) {
      context.handle(
          _quantidadeVerticalMeta,
          quantidadeVertical.isAcceptableOrUnknown(
              data['quantidade_vertical']!, _quantidadeVerticalMeta));
    }
    if (data.containsKey('margem_superior')) {
      context.handle(
          _margemSuperiorMeta,
          margemSuperior.isAcceptableOrUnknown(
              data['margem_superior']!, _margemSuperiorMeta));
    }
    if (data.containsKey('margem_inferior')) {
      context.handle(
          _margemInferiorMeta,
          margemInferior.isAcceptableOrUnknown(
              data['margem_inferior']!, _margemInferiorMeta));
    }
    if (data.containsKey('margem_esquerda')) {
      context.handle(
          _margemEsquerdaMeta,
          margemEsquerda.isAcceptableOrUnknown(
              data['margem_esquerda']!, _margemEsquerdaMeta));
    }
    if (data.containsKey('margem_direita')) {
      context.handle(
          _margemDireitaMeta,
          margemDireita.isAcceptableOrUnknown(
              data['margem_direita']!, _margemDireitaMeta));
    }
    if (data.containsKey('espacamento_horizontal')) {
      context.handle(
          _espacamentoHorizontalMeta,
          espacamentoHorizontal.isAcceptableOrUnknown(
              data['espacamento_horizontal']!, _espacamentoHorizontalMeta));
    }
    if (data.containsKey('espacamento_vertical')) {
      context.handle(
          _espacamentoVerticalMeta,
          espacamentoVertical.isAcceptableOrUnknown(
              data['espacamento_vertical']!, _espacamentoVerticalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EtiquetaLayout map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EtiquetaLayout(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFormatoPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_formato_papel']),
      codigoFabricante: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_fabricante']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantidade']),
      quantidadeHorizontal: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_horizontal']),
      quantidadeVertical: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_vertical']),
      margemSuperior: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}margem_superior']),
      margemInferior: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}margem_inferior']),
      margemEsquerda: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}margem_esquerda']),
      margemDireita: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}margem_direita']),
      espacamentoHorizontal: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}espacamento_horizontal']),
      espacamentoVertical: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}espacamento_vertical']),
    );
  }

  @override
  $EtiquetaLayoutsTable createAlias(String alias) {
    return $EtiquetaLayoutsTable(attachedDatabase, alias);
  }
}

class EtiquetaLayout extends DataClass implements Insertable<EtiquetaLayout> {
  final int? id;
  final int? idFormatoPapel;
  final String? codigoFabricante;
  final int? quantidade;
  final int? quantidadeHorizontal;
  final int? quantidadeVertical;
  final int? margemSuperior;
  final int? margemInferior;
  final int? margemEsquerda;
  final int? margemDireita;
  final int? espacamentoHorizontal;
  final int? espacamentoVertical;
  const EtiquetaLayout(
      {this.id,
      this.idFormatoPapel,
      this.codigoFabricante,
      this.quantidade,
      this.quantidadeHorizontal,
      this.quantidadeVertical,
      this.margemSuperior,
      this.margemInferior,
      this.margemEsquerda,
      this.margemDireita,
      this.espacamentoHorizontal,
      this.espacamentoVertical});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFormatoPapel != null) {
      map['id_formato_papel'] = Variable<int>(idFormatoPapel);
    }
    if (!nullToAbsent || codigoFabricante != null) {
      map['codigo_fabricante'] = Variable<String>(codigoFabricante);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    if (!nullToAbsent || quantidadeHorizontal != null) {
      map['quantidade_horizontal'] = Variable<int>(quantidadeHorizontal);
    }
    if (!nullToAbsent || quantidadeVertical != null) {
      map['quantidade_vertical'] = Variable<int>(quantidadeVertical);
    }
    if (!nullToAbsent || margemSuperior != null) {
      map['margem_superior'] = Variable<int>(margemSuperior);
    }
    if (!nullToAbsent || margemInferior != null) {
      map['margem_inferior'] = Variable<int>(margemInferior);
    }
    if (!nullToAbsent || margemEsquerda != null) {
      map['margem_esquerda'] = Variable<int>(margemEsquerda);
    }
    if (!nullToAbsent || margemDireita != null) {
      map['margem_direita'] = Variable<int>(margemDireita);
    }
    if (!nullToAbsent || espacamentoHorizontal != null) {
      map['espacamento_horizontal'] = Variable<int>(espacamentoHorizontal);
    }
    if (!nullToAbsent || espacamentoVertical != null) {
      map['espacamento_vertical'] = Variable<int>(espacamentoVertical);
    }
    return map;
  }

  factory EtiquetaLayout.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EtiquetaLayout(
      id: serializer.fromJson<int?>(json['id']),
      idFormatoPapel: serializer.fromJson<int?>(json['idFormatoPapel']),
      codigoFabricante: serializer.fromJson<String?>(json['codigoFabricante']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
      quantidadeHorizontal:
          serializer.fromJson<int?>(json['quantidadeHorizontal']),
      quantidadeVertical: serializer.fromJson<int?>(json['quantidadeVertical']),
      margemSuperior: serializer.fromJson<int?>(json['margemSuperior']),
      margemInferior: serializer.fromJson<int?>(json['margemInferior']),
      margemEsquerda: serializer.fromJson<int?>(json['margemEsquerda']),
      margemDireita: serializer.fromJson<int?>(json['margemDireita']),
      espacamentoHorizontal:
          serializer.fromJson<int?>(json['espacamentoHorizontal']),
      espacamentoVertical:
          serializer.fromJson<int?>(json['espacamentoVertical']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFormatoPapel': serializer.toJson<int?>(idFormatoPapel),
      'codigoFabricante': serializer.toJson<String?>(codigoFabricante),
      'quantidade': serializer.toJson<int?>(quantidade),
      'quantidadeHorizontal': serializer.toJson<int?>(quantidadeHorizontal),
      'quantidadeVertical': serializer.toJson<int?>(quantidadeVertical),
      'margemSuperior': serializer.toJson<int?>(margemSuperior),
      'margemInferior': serializer.toJson<int?>(margemInferior),
      'margemEsquerda': serializer.toJson<int?>(margemEsquerda),
      'margemDireita': serializer.toJson<int?>(margemDireita),
      'espacamentoHorizontal': serializer.toJson<int?>(espacamentoHorizontal),
      'espacamentoVertical': serializer.toJson<int?>(espacamentoVertical),
    };
  }

  EtiquetaLayout copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFormatoPapel = const Value.absent(),
          Value<String?> codigoFabricante = const Value.absent(),
          Value<int?> quantidade = const Value.absent(),
          Value<int?> quantidadeHorizontal = const Value.absent(),
          Value<int?> quantidadeVertical = const Value.absent(),
          Value<int?> margemSuperior = const Value.absent(),
          Value<int?> margemInferior = const Value.absent(),
          Value<int?> margemEsquerda = const Value.absent(),
          Value<int?> margemDireita = const Value.absent(),
          Value<int?> espacamentoHorizontal = const Value.absent(),
          Value<int?> espacamentoVertical = const Value.absent()}) =>
      EtiquetaLayout(
        id: id.present ? id.value : this.id,
        idFormatoPapel:
            idFormatoPapel.present ? idFormatoPapel.value : this.idFormatoPapel,
        codigoFabricante: codigoFabricante.present
            ? codigoFabricante.value
            : this.codigoFabricante,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        quantidadeHorizontal: quantidadeHorizontal.present
            ? quantidadeHorizontal.value
            : this.quantidadeHorizontal,
        quantidadeVertical: quantidadeVertical.present
            ? quantidadeVertical.value
            : this.quantidadeVertical,
        margemSuperior:
            margemSuperior.present ? margemSuperior.value : this.margemSuperior,
        margemInferior:
            margemInferior.present ? margemInferior.value : this.margemInferior,
        margemEsquerda:
            margemEsquerda.present ? margemEsquerda.value : this.margemEsquerda,
        margemDireita:
            margemDireita.present ? margemDireita.value : this.margemDireita,
        espacamentoHorizontal: espacamentoHorizontal.present
            ? espacamentoHorizontal.value
            : this.espacamentoHorizontal,
        espacamentoVertical: espacamentoVertical.present
            ? espacamentoVertical.value
            : this.espacamentoVertical,
      );
  @override
  String toString() {
    return (StringBuffer('EtiquetaLayout(')
          ..write('id: $id, ')
          ..write('idFormatoPapel: $idFormatoPapel, ')
          ..write('codigoFabricante: $codigoFabricante, ')
          ..write('quantidade: $quantidade, ')
          ..write('quantidadeHorizontal: $quantidadeHorizontal, ')
          ..write('quantidadeVertical: $quantidadeVertical, ')
          ..write('margemSuperior: $margemSuperior, ')
          ..write('margemInferior: $margemInferior, ')
          ..write('margemEsquerda: $margemEsquerda, ')
          ..write('margemDireita: $margemDireita, ')
          ..write('espacamentoHorizontal: $espacamentoHorizontal, ')
          ..write('espacamentoVertical: $espacamentoVertical')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idFormatoPapel,
      codigoFabricante,
      quantidade,
      quantidadeHorizontal,
      quantidadeVertical,
      margemSuperior,
      margemInferior,
      margemEsquerda,
      margemDireita,
      espacamentoHorizontal,
      espacamentoVertical);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EtiquetaLayout &&
          other.id == this.id &&
          other.idFormatoPapel == this.idFormatoPapel &&
          other.codigoFabricante == this.codigoFabricante &&
          other.quantidade == this.quantidade &&
          other.quantidadeHorizontal == this.quantidadeHorizontal &&
          other.quantidadeVertical == this.quantidadeVertical &&
          other.margemSuperior == this.margemSuperior &&
          other.margemInferior == this.margemInferior &&
          other.margemEsquerda == this.margemEsquerda &&
          other.margemDireita == this.margemDireita &&
          other.espacamentoHorizontal == this.espacamentoHorizontal &&
          other.espacamentoVertical == this.espacamentoVertical);
}

class EtiquetaLayoutsCompanion extends UpdateCompanion<EtiquetaLayout> {
  final Value<int?> id;
  final Value<int?> idFormatoPapel;
  final Value<String?> codigoFabricante;
  final Value<int?> quantidade;
  final Value<int?> quantidadeHorizontal;
  final Value<int?> quantidadeVertical;
  final Value<int?> margemSuperior;
  final Value<int?> margemInferior;
  final Value<int?> margemEsquerda;
  final Value<int?> margemDireita;
  final Value<int?> espacamentoHorizontal;
  final Value<int?> espacamentoVertical;
  const EtiquetaLayoutsCompanion({
    this.id = const Value.absent(),
    this.idFormatoPapel = const Value.absent(),
    this.codigoFabricante = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.quantidadeHorizontal = const Value.absent(),
    this.quantidadeVertical = const Value.absent(),
    this.margemSuperior = const Value.absent(),
    this.margemInferior = const Value.absent(),
    this.margemEsquerda = const Value.absent(),
    this.margemDireita = const Value.absent(),
    this.espacamentoHorizontal = const Value.absent(),
    this.espacamentoVertical = const Value.absent(),
  });
  EtiquetaLayoutsCompanion.insert({
    this.id = const Value.absent(),
    this.idFormatoPapel = const Value.absent(),
    this.codigoFabricante = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.quantidadeHorizontal = const Value.absent(),
    this.quantidadeVertical = const Value.absent(),
    this.margemSuperior = const Value.absent(),
    this.margemInferior = const Value.absent(),
    this.margemEsquerda = const Value.absent(),
    this.margemDireita = const Value.absent(),
    this.espacamentoHorizontal = const Value.absent(),
    this.espacamentoVertical = const Value.absent(),
  });
  static Insertable<EtiquetaLayout> custom({
    Expression<int>? id,
    Expression<int>? idFormatoPapel,
    Expression<String>? codigoFabricante,
    Expression<int>? quantidade,
    Expression<int>? quantidadeHorizontal,
    Expression<int>? quantidadeVertical,
    Expression<int>? margemSuperior,
    Expression<int>? margemInferior,
    Expression<int>? margemEsquerda,
    Expression<int>? margemDireita,
    Expression<int>? espacamentoHorizontal,
    Expression<int>? espacamentoVertical,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFormatoPapel != null) 'id_formato_papel': idFormatoPapel,
      if (codigoFabricante != null) 'codigo_fabricante': codigoFabricante,
      if (quantidade != null) 'quantidade': quantidade,
      if (quantidadeHorizontal != null)
        'quantidade_horizontal': quantidadeHorizontal,
      if (quantidadeVertical != null) 'quantidade_vertical': quantidadeVertical,
      if (margemSuperior != null) 'margem_superior': margemSuperior,
      if (margemInferior != null) 'margem_inferior': margemInferior,
      if (margemEsquerda != null) 'margem_esquerda': margemEsquerda,
      if (margemDireita != null) 'margem_direita': margemDireita,
      if (espacamentoHorizontal != null)
        'espacamento_horizontal': espacamentoHorizontal,
      if (espacamentoVertical != null)
        'espacamento_vertical': espacamentoVertical,
    });
  }

  EtiquetaLayoutsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFormatoPapel,
      Value<String?>? codigoFabricante,
      Value<int?>? quantidade,
      Value<int?>? quantidadeHorizontal,
      Value<int?>? quantidadeVertical,
      Value<int?>? margemSuperior,
      Value<int?>? margemInferior,
      Value<int?>? margemEsquerda,
      Value<int?>? margemDireita,
      Value<int?>? espacamentoHorizontal,
      Value<int?>? espacamentoVertical}) {
    return EtiquetaLayoutsCompanion(
      id: id ?? this.id,
      idFormatoPapel: idFormatoPapel ?? this.idFormatoPapel,
      codigoFabricante: codigoFabricante ?? this.codigoFabricante,
      quantidade: quantidade ?? this.quantidade,
      quantidadeHorizontal: quantidadeHorizontal ?? this.quantidadeHorizontal,
      quantidadeVertical: quantidadeVertical ?? this.quantidadeVertical,
      margemSuperior: margemSuperior ?? this.margemSuperior,
      margemInferior: margemInferior ?? this.margemInferior,
      margemEsquerda: margemEsquerda ?? this.margemEsquerda,
      margemDireita: margemDireita ?? this.margemDireita,
      espacamentoHorizontal:
          espacamentoHorizontal ?? this.espacamentoHorizontal,
      espacamentoVertical: espacamentoVertical ?? this.espacamentoVertical,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFormatoPapel.present) {
      map['id_formato_papel'] = Variable<int>(idFormatoPapel.value);
    }
    if (codigoFabricante.present) {
      map['codigo_fabricante'] = Variable<String>(codigoFabricante.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    if (quantidadeHorizontal.present) {
      map['quantidade_horizontal'] = Variable<int>(quantidadeHorizontal.value);
    }
    if (quantidadeVertical.present) {
      map['quantidade_vertical'] = Variable<int>(quantidadeVertical.value);
    }
    if (margemSuperior.present) {
      map['margem_superior'] = Variable<int>(margemSuperior.value);
    }
    if (margemInferior.present) {
      map['margem_inferior'] = Variable<int>(margemInferior.value);
    }
    if (margemEsquerda.present) {
      map['margem_esquerda'] = Variable<int>(margemEsquerda.value);
    }
    if (margemDireita.present) {
      map['margem_direita'] = Variable<int>(margemDireita.value);
    }
    if (espacamentoHorizontal.present) {
      map['espacamento_horizontal'] =
          Variable<int>(espacamentoHorizontal.value);
    }
    if (espacamentoVertical.present) {
      map['espacamento_vertical'] = Variable<int>(espacamentoVertical.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EtiquetaLayoutsCompanion(')
          ..write('id: $id, ')
          ..write('idFormatoPapel: $idFormatoPapel, ')
          ..write('codigoFabricante: $codigoFabricante, ')
          ..write('quantidade: $quantidade, ')
          ..write('quantidadeHorizontal: $quantidadeHorizontal, ')
          ..write('quantidadeVertical: $quantidadeVertical, ')
          ..write('margemSuperior: $margemSuperior, ')
          ..write('margemInferior: $margemInferior, ')
          ..write('margemEsquerda: $margemEsquerda, ')
          ..write('margemDireita: $margemDireita, ')
          ..write('espacamentoHorizontal: $espacamentoHorizontal, ')
          ..write('espacamentoVertical: $espacamentoVertical')
          ..write(')'))
        .toString();
  }
}

class $EtiquetaFormatoPapelsTable extends EtiquetaFormatoPapels
    with TableInfo<$EtiquetaFormatoPapelsTable, EtiquetaFormatoPapel> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EtiquetaFormatoPapelsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _alturaMeta = const VerificationMeta('altura');
  @override
  late final GeneratedColumn<int> altura = GeneratedColumn<int>(
      'altura', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _larguraMeta =
      const VerificationMeta('largura');
  @override
  late final GeneratedColumn<int> largura = GeneratedColumn<int>(
      'largura', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, altura, largura];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'etiqueta_formato_papel';
  @override
  VerificationContext validateIntegrity(
      Insertable<EtiquetaFormatoPapel> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('altura')) {
      context.handle(_alturaMeta,
          altura.isAcceptableOrUnknown(data['altura']!, _alturaMeta));
    }
    if (data.containsKey('largura')) {
      context.handle(_larguraMeta,
          largura.isAcceptableOrUnknown(data['largura']!, _larguraMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EtiquetaFormatoPapel map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EtiquetaFormatoPapel(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      altura: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}altura']),
      largura: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}largura']),
    );
  }

  @override
  $EtiquetaFormatoPapelsTable createAlias(String alias) {
    return $EtiquetaFormatoPapelsTable(attachedDatabase, alias);
  }
}

class EtiquetaFormatoPapel extends DataClass
    implements Insertable<EtiquetaFormatoPapel> {
  final int? id;
  final String? nome;
  final int? altura;
  final int? largura;
  const EtiquetaFormatoPapel({this.id, this.nome, this.altura, this.largura});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || altura != null) {
      map['altura'] = Variable<int>(altura);
    }
    if (!nullToAbsent || largura != null) {
      map['largura'] = Variable<int>(largura);
    }
    return map;
  }

  factory EtiquetaFormatoPapel.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EtiquetaFormatoPapel(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      altura: serializer.fromJson<int?>(json['altura']),
      largura: serializer.fromJson<int?>(json['largura']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'altura': serializer.toJson<int?>(altura),
      'largura': serializer.toJson<int?>(largura),
    };
  }

  EtiquetaFormatoPapel copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<int?> altura = const Value.absent(),
          Value<int?> largura = const Value.absent()}) =>
      EtiquetaFormatoPapel(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        altura: altura.present ? altura.value : this.altura,
        largura: largura.present ? largura.value : this.largura,
      );
  @override
  String toString() {
    return (StringBuffer('EtiquetaFormatoPapel(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('altura: $altura, ')
          ..write('largura: $largura')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, altura, largura);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EtiquetaFormatoPapel &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.altura == this.altura &&
          other.largura == this.largura);
}

class EtiquetaFormatoPapelsCompanion
    extends UpdateCompanion<EtiquetaFormatoPapel> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<int?> altura;
  final Value<int?> largura;
  const EtiquetaFormatoPapelsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.altura = const Value.absent(),
    this.largura = const Value.absent(),
  });
  EtiquetaFormatoPapelsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.altura = const Value.absent(),
    this.largura = const Value.absent(),
  });
  static Insertable<EtiquetaFormatoPapel> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<int>? altura,
    Expression<int>? largura,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (altura != null) 'altura': altura,
      if (largura != null) 'largura': largura,
    });
  }

  EtiquetaFormatoPapelsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<int?>? altura,
      Value<int?>? largura}) {
    return EtiquetaFormatoPapelsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      altura: altura ?? this.altura,
      largura: largura ?? this.largura,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (altura.present) {
      map['altura'] = Variable<int>(altura.value);
    }
    if (largura.present) {
      map['largura'] = Variable<int>(largura.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EtiquetaFormatoPapelsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('altura: $altura, ')
          ..write('largura: $largura')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $EtiquetaTemplatesTable etiquetaTemplates =
      $EtiquetaTemplatesTable(this);
  late final $EtiquetaLayoutsTable etiquetaLayouts =
      $EtiquetaLayoutsTable(this);
  late final $EtiquetaFormatoPapelsTable etiquetaFormatoPapels =
      $EtiquetaFormatoPapelsTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final EtiquetaLayoutDao etiquetaLayoutDao =
      EtiquetaLayoutDao(this as AppDatabase);
  late final EtiquetaFormatoPapelDao etiquetaFormatoPapelDao =
      EtiquetaFormatoPapelDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        etiquetaTemplates,
        etiquetaLayouts,
        etiquetaFormatoPapels,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
