// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'etiqueta_formato_papel_dao.dart';

// ignore_for_file: type=lint
mixin _$EtiquetaFormatoPapelDaoMixin on DatabaseAccessor<AppDatabase> {
  $EtiquetaFormatoPapelsTable get etiquetaFormatoPapels =>
      attachedDatabase.etiquetaFormatoPapels;
}
