// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'etiqueta_layout_dao.dart';

// ignore_for_file: type=lint
mixin _$EtiquetaLayoutDaoMixin on DatabaseAccessor<AppDatabase> {
  $EtiquetaLayoutsTable get etiquetaLayouts => attachedDatabase.etiquetaLayouts;
  $EtiquetaTemplatesTable get etiquetaTemplates =>
      attachedDatabase.etiquetaTemplates;
  $EtiquetaFormatoPapelsTable get etiquetaFormatoPapels =>
      attachedDatabase.etiquetaFormatoPapels;
}
