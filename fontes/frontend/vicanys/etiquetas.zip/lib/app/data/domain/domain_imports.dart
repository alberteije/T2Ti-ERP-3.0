
export 'etiqueta_template_domain.dart';