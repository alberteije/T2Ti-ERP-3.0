import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:nfe/app/controller/nfe_cabecalho_controller.dart';
import 'package:nfe/app/page/shared_widget/shared_widget_imports.dart';
import 'package:open_file/open_file.dart';

class NfeCabecalhoTabPage extends StatelessWidget {
  NfeCabecalhoTabPage({Key? key}) : super(key: key);
  final nfeCabecalhoController = Get.find<NfeCabecalhoController>();

  @override
  Widget build(BuildContext context) {
    return RawKeyboardListener(
      autofocus: false,
      focusNode: FocusNode(),
      onKey: (event) {
        if (event.isKeyPressed(LogicalKeyboardKey.escape)) {
          nfeCabecalhoController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: nfeCabecalhoController.nfeCabecalhoTabPageScaffoldKey,
        appBar: AppBar(automaticallyImplyLeading: false, title: Text('NF-e - ${'editing'.tr}'), actions: [
          IconButton(onPressed: () async {
            String filePath = 'C:/temp/53160310793118000178550010004570911004570917-nfe.pdf';
            final result = await OpenFile.open(filePath);
            if (result.type == ResultType.done) {
              print('Arquivo aberto com sucesso!');
            } else {
              print('Erro ao abrir o arquivo: ${result.message}');
            }
          }, icon: const Icon(Icons.document_scanner)),
          saveButton(onPressed: nfeCabecalhoController.save),
          cancelAndExitButton(onPressed: nfeCabecalhoController.preventDataLoss),
        ]),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: nfeCabecalhoController.tabController,
                  children: nfeCabecalhoController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: nfeCabecalhoController.tabController,
                onTap: nfeCabecalhoController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: nfeCabecalhoController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
