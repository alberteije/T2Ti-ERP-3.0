// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_transporte_reboque_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeTransporteReboqueDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeTransporteReboquesTable get nfeTransporteReboques =>
      attachedDatabase.nfeTransporteReboques;
  $NfeTransportesTable get nfeTransportes => attachedDatabase.nfeTransportes;
}
