// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeCabecalhosTable get nfeCabecalhos => attachedDatabase.nfeCabecalhos;
  $NfeReferenciadasTable get nfeReferenciadas =>
      attachedDatabase.nfeReferenciadas;
  $NfeEmitentesTable get nfeEmitentes => attachedDatabase.nfeEmitentes;
  $NfeDestinatariosTable get nfeDestinatarios =>
      attachedDatabase.nfeDestinatarios;
  $NfeLocalRetiradasTable get nfeLocalRetiradas =>
      attachedDatabase.nfeLocalRetiradas;
  $NfeLocalEntregasTable get nfeLocalEntregas =>
      attachedDatabase.nfeLocalEntregas;
  $NfeTransportesTable get nfeTransportes => attachedDatabase.nfeTransportes;
  $NfeFaturasTable get nfeFaturas => attachedDatabase.nfeFaturas;
  $NfeCanasTable get nfeCanas => attachedDatabase.nfeCanas;
  $NfeProdRuralReferenciadasTable get nfeProdRuralReferenciadas =>
      attachedDatabase.nfeProdRuralReferenciadas;
  $NfeNfReferenciadasTable get nfeNfReferenciadas =>
      attachedDatabase.nfeNfReferenciadas;
  $NfeProcessoReferenciadosTable get nfeProcessoReferenciados =>
      attachedDatabase.nfeProcessoReferenciados;
  $NfeAcessoXmlsTable get nfeAcessoXmls => attachedDatabase.nfeAcessoXmls;
  $NfeInformacaoPagamentosTable get nfeInformacaoPagamentos =>
      attachedDatabase.nfeInformacaoPagamentos;
  $NfeResponsavelTecnicosTable get nfeResponsavelTecnicos =>
      attachedDatabase.nfeResponsavelTecnicos;
  $TributOperacaoFiscalsTable get tributOperacaoFiscals =>
      attachedDatabase.tributOperacaoFiscals;
  $VendaCabecalhosTable get vendaCabecalhos => attachedDatabase.vendaCabecalhos;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
  $NfeCteReferenciadosTable get nfeCteReferenciados =>
      attachedDatabase.nfeCteReferenciados;
  $NfeCupomFiscalReferenciadosTable get nfeCupomFiscalReferenciados =>
      attachedDatabase.nfeCupomFiscalReferenciados;
}
