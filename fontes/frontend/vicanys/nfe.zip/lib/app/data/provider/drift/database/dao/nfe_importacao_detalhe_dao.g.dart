// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_importacao_detalhe_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeImportacaoDetalheDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeImportacaoDetalhesTable get nfeImportacaoDetalhes =>
      attachedDatabase.nfeImportacaoDetalhes;
  $NfeDeclaracaoImportacaosTable get nfeDeclaracaoImportacaos =>
      attachedDatabase.nfeDeclaracaoImportacaos;
}
