// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_duplicata_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeDuplicataDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeDuplicatasTable get nfeDuplicatas => attachedDatabase.nfeDuplicatas;
  $NfeFaturasTable get nfeFaturas => attachedDatabase.nfeFaturas;
}
