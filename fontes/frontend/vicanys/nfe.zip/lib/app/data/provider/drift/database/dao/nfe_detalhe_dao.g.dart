// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_detalhe_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeDetalheDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeDetalhesTable get nfeDetalhes => attachedDatabase.nfeDetalhes;
  $NfeDetEspecificoVeiculosTable get nfeDetEspecificoVeiculos =>
      attachedDatabase.nfeDetEspecificoVeiculos;
  $NfeDetEspecificoMedicamentosTable get nfeDetEspecificoMedicamentos =>
      attachedDatabase.nfeDetEspecificoMedicamentos;
  $NfeDetEspecificoArmamentosTable get nfeDetEspecificoArmamentos =>
      attachedDatabase.nfeDetEspecificoArmamentos;
  $NfeDetEspecificoCombustivelsTable get nfeDetEspecificoCombustivels =>
      attachedDatabase.nfeDetEspecificoCombustivels;
  $NfeDeclaracaoImportacaosTable get nfeDeclaracaoImportacaos =>
      attachedDatabase.nfeDeclaracaoImportacaos;
  $NfeDetalheImpostoIcmssTable get nfeDetalheImpostoIcmss =>
      attachedDatabase.nfeDetalheImpostoIcmss;
  $NfeDetalheImpostoIpisTable get nfeDetalheImpostoIpis =>
      attachedDatabase.nfeDetalheImpostoIpis;
  $NfeDetalheImpostoIisTable get nfeDetalheImpostoIis =>
      attachedDatabase.nfeDetalheImpostoIis;
  $NfeDetalheImpostoPissTable get nfeDetalheImpostoPiss =>
      attachedDatabase.nfeDetalheImpostoPiss;
  $NfeDetalheImpostoCofinssTable get nfeDetalheImpostoCofinss =>
      attachedDatabase.nfeDetalheImpostoCofinss;
  $NfeDetalheImpostoIssqnsTable get nfeDetalheImpostoIssqns =>
      attachedDatabase.nfeDetalheImpostoIssqns;
  $NfeExportacaosTable get nfeExportacaos => attachedDatabase.nfeExportacaos;
  $NfeItemRastreadosTable get nfeItemRastreados =>
      attachedDatabase.nfeItemRastreados;
  $NfeDetalheImpostoPisStsTable get nfeDetalheImpostoPisSts =>
      attachedDatabase.nfeDetalheImpostoPisSts;
  $NfeDetalheImpostoIcmsUfdestsTable get nfeDetalheImpostoIcmsUfdests =>
      attachedDatabase.nfeDetalheImpostoIcmsUfdests;
  $NfeDetalheImpostoCofinsStsTable get nfeDetalheImpostoCofinsSts =>
      attachedDatabase.nfeDetalheImpostoCofinsSts;
  $NfeCabecalhosTable get nfeCabecalhos => attachedDatabase.nfeCabecalhos;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
