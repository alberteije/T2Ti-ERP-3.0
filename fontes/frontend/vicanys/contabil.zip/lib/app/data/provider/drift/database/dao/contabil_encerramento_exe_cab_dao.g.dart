// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_encerramento_exe_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilEncerramentoExeCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilEncerramentoExeCabsTable get contabilEncerramentoExeCabs =>
      attachedDatabase.contabilEncerramentoExeCabs;
  $ContabilEncerramentoExeDetsTable get contabilEncerramentoExeDets =>
      attachedDatabase.contabilEncerramentoExeDets;
  $ContabilContasTable get contabilContas => attachedDatabase.contabilContas;
}
