// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_lancamento_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilLancamentoCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilLancamentoCabecalhosTable get contabilLancamentoCabecalhos =>
      attachedDatabase.contabilLancamentoCabecalhos;
  $ContabilLancamentoDetalhesTable get contabilLancamentoDetalhes =>
      attachedDatabase.contabilLancamentoDetalhes;
  $ContabilContasTable get contabilContas => attachedDatabase.contabilContas;
  $ContabilHistoricosTable get contabilHistoricos =>
      attachedDatabase.contabilHistoricos;
  $ContabilLotesTable get contabilLotes => attachedDatabase.contabilLotes;
}
