// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fap_dao.dart';

// ignore_for_file: type=lint
mixin _$FapDaoMixin on DatabaseAccessor<AppDatabase> {
  $FapsTable get faps => attachedDatabase.faps;
}
