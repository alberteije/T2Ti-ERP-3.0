// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'centro_resultado_dao.dart';

// ignore_for_file: type=lint
mixin _$CentroResultadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
  $PlanoCentroResultadosTable get planoCentroResultados =>
      attachedDatabase.planoCentroResultados;
  $CtResultadoNtFinanceirasTable get ctResultadoNtFinanceiras =>
      attachedDatabase.ctResultadoNtFinanceiras;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
}
