// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'plano_conta_ref_sped_dao.dart';

// ignore_for_file: type=lint
mixin _$PlanoContaRefSpedDaoMixin on DatabaseAccessor<AppDatabase> {
  $PlanoContaRefSpedsTable get planoContaRefSpeds =>
      attachedDatabase.planoContaRefSpeds;
}
