// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_indice_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilIndiceDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilIndicesTable get contabilIndices => attachedDatabase.contabilIndices;
  $ContabilIndiceValorsTable get contabilIndiceValors =>
      attachedDatabase.contabilIndiceValors;
}
