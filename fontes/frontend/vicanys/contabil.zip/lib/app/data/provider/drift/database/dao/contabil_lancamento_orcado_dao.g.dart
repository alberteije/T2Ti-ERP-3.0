// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_lancamento_orcado_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilLancamentoOrcadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilLancamentoOrcadosTable get contabilLancamentoOrcados =>
      attachedDatabase.contabilLancamentoOrcados;
  $ContabilContasTable get contabilContas => attachedDatabase.contabilContas;
}
