// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_lote_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilLoteDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilLotesTable get contabilLotes => attachedDatabase.contabilLotes;
}
