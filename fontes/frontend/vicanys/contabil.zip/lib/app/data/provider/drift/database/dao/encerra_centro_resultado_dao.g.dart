// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'encerra_centro_resultado_dao.dart';

// ignore_for_file: type=lint
mixin _$EncerraCentroResultadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $EncerraCentroResultadosTable get encerraCentroResultados =>
      attachedDatabase.encerraCentroResultados;
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
}
