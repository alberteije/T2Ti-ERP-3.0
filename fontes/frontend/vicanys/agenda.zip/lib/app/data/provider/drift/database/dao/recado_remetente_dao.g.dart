// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recado_remetente_dao.dart';

// ignore_for_file: type=lint
mixin _$RecadoRemetenteDaoMixin on DatabaseAccessor<AppDatabase> {
  $RecadoRemetentesTable get recadoRemetentes =>
      attachedDatabase.recadoRemetentes;
  $RecadoDestinatariosTable get recadoDestinatarios =>
      attachedDatabase.recadoDestinatarios;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
