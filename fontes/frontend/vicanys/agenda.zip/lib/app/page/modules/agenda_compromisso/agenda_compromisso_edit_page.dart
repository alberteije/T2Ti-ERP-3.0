import 'package:flutter/material.dart';
// import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
// import 'package:agenda/app/page/shared_widget/shared_widget_imports.dart';
import 'package:agenda/app/controller/agenda_compromisso_controller.dart';
// import 'package:agenda/app/infra/infra_imports.dart';
// import 'package:agenda/app/page/shared_widget/input/input_imports.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class AgendaCompromissoEditPage extends StatelessWidget {
	AgendaCompromissoEditPage({Key? key}) : super(key: key);
	final agendaCompromissoController = Get.find<AgendaCompromissoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: agendaCompromissoController.agendaCompromissoEditPageScaffoldKey,				
				body: SfCalendar(
          view: CalendarView.month,
          dataSource: MeetingDataSource(_getDataSource()),
          // by default the month appointment display mode set as Indicator, we can
          // change the display mode as appointment using the appointment display
          // mode property
          monthViewSettings: const MonthViewSettings(
              appointmentDisplayMode: MonthAppointmentDisplayMode.appointment),
        )
        
        // SafeArea(
				// 	top: false,
				// 	bottom: false,
				// 	child: Form(
				// 		key: agendaCompromissoController.agendaCompromissoEditPageFormKey,
				// 		autovalidateMode: AutovalidateMode.always,
				// 		child: Scrollbar(
				// 			controller: agendaCompromissoController.scrollController,
				// 			child: SingleChildScrollView(
				// 				controller: agendaCompromissoController.scrollController,
				// 				child: BootstrapContainer(
				// 					fluid: true,
				// 					padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
				// 					children: <Widget>[
				// 						const Divider(
				// 							color: Colors.transparent,
				// 						),
				// 						BootstrapRow(
				// 							height: 60,
				// 							children: <BootstrapCol>[
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-6',
				// 									child: Row(
				// 										children: <Widget>[
				// 											Expanded(
				// 												flex: 1,
				// 												child: SizedBox(
				// 													child: TextFormField(
				// 														controller: agendaCompromissoController.agendaCategoriaCompromissoModelController,
				// 														validator: ValidateFormField.validateMandatory,
				// 														readOnly: true,
				// 														decoration: inputDecoration(
				// 															hintText: 'Informe os dados para o campo Categoria',
				// 															labelText: 'Categoria *',
				// 															usePadding: true,
				// 														),
				// 														onSaved: (String? value) {},
				// 														onChanged: (text) {},
				// 													),
				// 												),
				// 											),
				// 											Expanded(
				// 												flex: 0,
				// 												child: lookupButton(onPressed: agendaCompromissoController.callAgendaCategoriaCompromissoLookup),
				// 											),
				// 										],
				// 									),
				// 								),
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-6',
				// 									child: Row(
				// 										children: <Widget>[
				// 											Expanded(
				// 												flex: 1,
				// 												child: SizedBox(
				// 													child: TextFormField(
				// 														controller: agendaCompromissoController.viewPessoaColaboradorModelController,
				// 														validator: ValidateFormField.validateMandatory,
				// 														readOnly: true,
				// 														decoration: inputDecoration(
				// 															hintText: 'Informe os dados para o campo Colaborador',
				// 															labelText: 'Colaborador *',
				// 															usePadding: true,
				// 														),
				// 														onSaved: (String? value) {},
				// 														onChanged: (text) {},
				// 													),
				// 												),
				// 											),
				// 											Expanded(
				// 												flex: 0,
				// 												child: lookupButton(onPressed: agendaCompromissoController.callViewPessoaColaboradorLookup),
				// 											),
				// 										],
				// 									),
				// 								),
				// 							],
				// 						),
				// 						const Divider(
				// 							color: Colors.transparent,
				// 						),
				// 						BootstrapRow(
				// 							height: 60,
				// 							children: <BootstrapCol>[
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-3',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: InputDecorator(
				// 											decoration: inputDecoration(
				// 												hintText: 'Informe os dados para o campo Data Compromisso',
				// 												labelText: 'Data Compromisso',
				// 												usePadding: true,
				// 											),
				// 											isEmpty: false,
				// 											child: DatePickerItem(
				// 												dateTime: agendaCompromissoController.agendaCompromissoModel.dataCompromisso,
				// 												firstDate: DateTime.parse('1000-01-01'),
				// 												lastDate: DateTime.parse('5000-01-01'),
				// 												onChanged: (DateTime? value) {
				// 													agendaCompromissoController.agendaCompromissoModel.dataCompromisso = value;
				// 													agendaCompromissoController.formWasChanged = true;
				// 												},
				// 											),
				// 										),
				// 									),
				// 								),
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-3',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: TextFormField(
				// 											autofocus: true,
				// 											maxLength: 8,
				// 											controller: agendaCompromissoController.horaController,
				// 											decoration: inputDecoration(
				// 												hintText: 'Informe os dados para o campo Hora',
				// 												labelText: 'Hora',
				// 												usePadding: true,
				// 											),
				// 											onSaved: (String? value) {},
				// 											onChanged: (text) {
				// 												agendaCompromissoController.agendaCompromissoModel.hora = text;
				// 												agendaCompromissoController.formWasChanged = true;
				// 											},
				// 										),
				// 									),
				// 								),
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-3',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: TextFormField(
				// 											autofocus: true,
				// 											controller: agendaCompromissoController.duracaoController,
				// 											decoration: inputDecoration(
				// 												hintText: 'Informe os dados para o campo Duracao',
				// 												labelText: 'Duracao',
				// 												usePadding: true,
				// 											),
				// 											onSaved: (String? value) {},
				// 											onChanged: (text) {
				// 												agendaCompromissoController.agendaCompromissoModel.duracao = int.tryParse(text);
				// 												agendaCompromissoController.formWasChanged = true;
				// 											},
				// 										),
				// 									),
				// 								),
				// 								BootstrapCol(
				// 									sizes: 'col-12 col-md-3',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: CustomDropdownButtonFormField(
				// 											value: agendaCompromissoController.agendaCompromissoModel.tipo ?? 'Pessoal',
				// 											labelText: 'Tipo',
				// 											hintText: 'Informe os dados para o campo Tipo',
				// 											items: const ['Pessoal','Gerencial'],
				// 											onChanged: (dynamic newValue) {
				// 												agendaCompromissoController.agendaCompromissoModel.tipo = newValue;
				// 												agendaCompromissoController.formWasChanged = true;
				// 											},
				// 										),
				// 									),
				// 								),
				// 							],
				// 						),
				// 						const Divider(
				// 							color: Colors.transparent,
				// 						),
				// 						BootstrapRow(
				// 							height: 60,
				// 							children: <BootstrapCol>[
				// 								BootstrapCol(
				// 									sizes: 'col-12',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: TextFormField(
				// 											autofocus: true,
				// 											maxLength: 100,
				// 											controller: agendaCompromissoController.ondeController,
				// 											decoration: inputDecoration(
				// 												hintText: 'Informe os dados para o campo Onde',
				// 												labelText: 'Onde',
				// 												usePadding: true,
				// 											),
				// 											onSaved: (String? value) {},
				// 											onChanged: (text) {
				// 												agendaCompromissoController.agendaCompromissoModel.onde = text;
				// 												agendaCompromissoController.formWasChanged = true;
				// 											},
				// 										),
				// 									),
				// 								),
				// 							],
				// 						),
				// 						const Divider(
				// 							color: Colors.transparent,
				// 						),
				// 						BootstrapRow(
				// 							height: 60,
				// 							children: <BootstrapCol>[
				// 								BootstrapCol(
				// 									sizes: 'col-12',
				// 									child: Padding(
				// 										padding: Util.distanceBetweenColumnsLineBreak(context)!,
				// 										child: TextFormField(
				// 											autofocus: true,
				// 											maxLength: 100,
				// 											controller: agendaCompromissoController.descricaoController,
				// 											decoration: inputDecoration(
				// 												hintText: 'Informe os dados para o campo Descricao',
				// 												labelText: 'Descricao',
				// 												usePadding: true,
				// 											),
				// 											onSaved: (String? value) {},
				// 											onChanged: (text) {
				// 												agendaCompromissoController.agendaCompromissoModel.descricao = text;
				// 												agendaCompromissoController.formWasChanged = true;
				// 											},
				// 										),
				// 									),
				// 								),
				// 							],
				// 						),
				// 						const Divider(
				// 							indent: 10,
				// 							endIndent: 10,
				// 							thickness: 2,
				// 						),
				// 						BootstrapRow(
				// 							height: 60,
				// 							children: <BootstrapCol>[
				// 								BootstrapCol(
				// 									sizes: 'col-12',
				// 									child: Text(
				// 										'field_is_mandatory'.tr,
				// 										style: Theme.of(context).textTheme.bodySmall,
				// 									),
				// 								),
				// 							],
				// 						),
				// 						const SizedBox(height: 10.0),
				// 					],
				// 				),
				// 			),
				// 		),
				// 	),
				// ),
			);
	}

  List<Meeting> _getDataSource() {
    final List<Meeting> meetings = <Meeting>[];
    final DateTime today = DateTime.now();
    final DateTime startTime = DateTime(today.year, today.month, today.day, 9);
    final DateTime endTime = startTime.add(const Duration(hours: 2));
    meetings.add(Meeting(
        'Conference', startTime, endTime, const Color(0xFF0F8644), false));
    return meetings;
  }  
}

/// An object to set the appointment collection data source to calendar, which
/// used to map the custom appointment data to the calendar appointment, and
/// allows to add, remove or reset the appointment collection.
class MeetingDataSource extends CalendarDataSource {
  /// Creates a meeting data source, which used to set the appointment
  /// collection to the calendar
  MeetingDataSource(List<Meeting> source) {
    appointments = source;
  }

  @override
  DateTime getStartTime(int index) {
    return _getMeetingData(index).from;
  }

  @override
  DateTime getEndTime(int index) {
    return _getMeetingData(index).to;
  }

  @override
  String getSubject(int index) {
    return _getMeetingData(index).eventName;
  }

  @override
  Color getColor(int index) {
    return _getMeetingData(index).background;
  }

  @override
  bool isAllDay(int index) {
    return _getMeetingData(index).isAllDay;
  }

  Meeting _getMeetingData(int index) {
    final dynamic meeting = appointments![index];
    late final Meeting meetingData;
    if (meeting is Meeting) {
      meetingData = meeting;
    }

    return meetingData;
  }
}

/// Custom business object class which contains properties to hold the detailed
/// information about the event data which will be rendered in calendar.
class Meeting {
  /// Creates a meeting class with required details.
  Meeting(this.eventName, this.from, this.to, this.background, this.isAllDay);

  /// Event name which is equivalent to subject property of [Appointment].
  String eventName;

  /// From which is equivalent to start time property of [Appointment].
  DateTime from;

  /// To which is equivalent to end time property of [Appointment].
  DateTime to;

  /// Background which is equivalent to color property of [Appointment].
  Color background;

  /// IsAllDay which is equivalent to isAllDay property of [Appointment].
  bool isAllDay;
}
