// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nota_fiscal_tipo_dao.dart';

// ignore_for_file: type=lint
mixin _$NotaFiscalTipoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NotaFiscalTiposTable get notaFiscalTipos => attachedDatabase.notaFiscalTipos;
  $NotaFiscalModelosTable get notaFiscalModelos =>
      attachedDatabase.notaFiscalModelos;
}
