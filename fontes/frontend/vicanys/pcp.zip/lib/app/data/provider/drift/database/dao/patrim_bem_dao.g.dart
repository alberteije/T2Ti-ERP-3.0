// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_bem_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimBemDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimBemsTable get patrimBems => attachedDatabase.patrimBems;
}
