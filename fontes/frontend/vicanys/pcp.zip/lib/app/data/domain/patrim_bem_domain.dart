class PatrimBemDomain {
	PatrimBemDomain._();

	static getDeprecia(String? deprecia) { 
		switch (deprecia) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setDeprecia(String? deprecia) { 
		switch (deprecia) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getMetodoDepreciacao(String? metodoDepreciacao) { 
		switch (metodoDepreciacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setMetodoDepreciacao(String? metodoDepreciacao) { 
		switch (metodoDepreciacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getTipoDepreciacao(String? tipoDepreciacao) { 
		switch (tipoDepreciacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoDepreciacao(String? tipoDepreciacao) { 
		switch (tipoDepreciacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}