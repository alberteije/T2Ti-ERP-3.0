abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const pcpOpCabecalhoListPage = '/pcpOpCabecalhoListPage'; 
	static const pcpOpCabecalhoTabPage = '/pcpOpCabecalhoTabPage';
	static const pcpServicoListPage = '/pcpServicoListPage'; 
	static const pcpServicoTabPage = '/pcpServicoTabPage';
	static const pcpInstrucaoListPage = '/pcpInstrucaoListPage'; 
	static const pcpInstrucaoEditPage = '/pcpInstrucaoEditPage';
}