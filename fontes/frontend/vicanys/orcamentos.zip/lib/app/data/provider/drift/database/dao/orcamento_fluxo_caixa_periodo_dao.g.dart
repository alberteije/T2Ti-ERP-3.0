// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orcamento_fluxo_caixa_periodo_dao.dart';

// ignore_for_file: type=lint
mixin _$OrcamentoFluxoCaixaPeriodoDaoMixin on DatabaseAccessor<AppDatabase> {
  $OrcamentoFluxoCaixaPeriodosTable get orcamentoFluxoCaixaPeriodos =>
      attachedDatabase.orcamentoFluxoCaixaPeriodos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
