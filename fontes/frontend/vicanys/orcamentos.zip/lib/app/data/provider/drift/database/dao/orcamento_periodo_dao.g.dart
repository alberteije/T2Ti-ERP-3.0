// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orcamento_periodo_dao.dart';

// ignore_for_file: type=lint
mixin _$OrcamentoPeriodoDaoMixin on DatabaseAccessor<AppDatabase> {
  $OrcamentoPeriodosTable get orcamentoPeriodos =>
      attachedDatabase.orcamentoPeriodos;
}
