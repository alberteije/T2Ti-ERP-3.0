// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $OrcamentoFluxoCaixaDetalhesTable extends OrcamentoFluxoCaixaDetalhes
    with
        TableInfo<$OrcamentoFluxoCaixaDetalhesTable,
            OrcamentoFluxoCaixaDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoFluxoCaixaDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOrcamentoFluxoCaixaMeta =
      const VerificationMeta('idOrcamentoFluxoCaixa');
  @override
  late final GeneratedColumn<int> idOrcamentoFluxoCaixa = GeneratedColumn<int>(
      'id_orcamento_fluxo_caixa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFinNaturezaFinanceiraMeta =
      const VerificationMeta('idFinNaturezaFinanceira');
  @override
  late final GeneratedColumn<int> idFinNaturezaFinanceira =
      GeneratedColumn<int>('id_fin_natureza_financeira', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _periodoMeta =
      const VerificationMeta('periodo');
  @override
  late final GeneratedColumn<String> periodo = GeneratedColumn<String>(
      'periodo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorOrcadoMeta =
      const VerificationMeta('valorOrcado');
  @override
  late final GeneratedColumn<double> valorOrcado = GeneratedColumn<double>(
      'valor_orcado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRealizadoMeta =
      const VerificationMeta('valorRealizado');
  @override
  late final GeneratedColumn<double> valorRealizado = GeneratedColumn<double>(
      'valor_realizado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaVariacaoMeta =
      const VerificationMeta('taxaVariacao');
  @override
  late final GeneratedColumn<double> taxaVariacao = GeneratedColumn<double>(
      'taxa_variacao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVariacaoMeta =
      const VerificationMeta('valorVariacao');
  @override
  late final GeneratedColumn<double> valorVariacao = GeneratedColumn<double>(
      'valor_variacao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idOrcamentoFluxoCaixa,
        idFinNaturezaFinanceira,
        periodo,
        valorOrcado,
        valorRealizado,
        taxaVariacao,
        valorVariacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_fluxo_caixa_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<OrcamentoFluxoCaixaDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_orcamento_fluxo_caixa')) {
      context.handle(
          _idOrcamentoFluxoCaixaMeta,
          idOrcamentoFluxoCaixa.isAcceptableOrUnknown(
              data['id_orcamento_fluxo_caixa']!, _idOrcamentoFluxoCaixaMeta));
    }
    if (data.containsKey('id_fin_natureza_financeira')) {
      context.handle(
          _idFinNaturezaFinanceiraMeta,
          idFinNaturezaFinanceira.isAcceptableOrUnknown(
              data['id_fin_natureza_financeira']!,
              _idFinNaturezaFinanceiraMeta));
    }
    if (data.containsKey('periodo')) {
      context.handle(_periodoMeta,
          periodo.isAcceptableOrUnknown(data['periodo']!, _periodoMeta));
    }
    if (data.containsKey('valor_orcado')) {
      context.handle(
          _valorOrcadoMeta,
          valorOrcado.isAcceptableOrUnknown(
              data['valor_orcado']!, _valorOrcadoMeta));
    }
    if (data.containsKey('valor_realizado')) {
      context.handle(
          _valorRealizadoMeta,
          valorRealizado.isAcceptableOrUnknown(
              data['valor_realizado']!, _valorRealizadoMeta));
    }
    if (data.containsKey('taxa_variacao')) {
      context.handle(
          _taxaVariacaoMeta,
          taxaVariacao.isAcceptableOrUnknown(
              data['taxa_variacao']!, _taxaVariacaoMeta));
    }
    if (data.containsKey('valor_variacao')) {
      context.handle(
          _valorVariacaoMeta,
          valorVariacao.isAcceptableOrUnknown(
              data['valor_variacao']!, _valorVariacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoFluxoCaixaDetalhe map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoFluxoCaixaDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOrcamentoFluxoCaixa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_orcamento_fluxo_caixa']),
      idFinNaturezaFinanceira: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_fin_natureza_financeira']),
      periodo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo']),
      valorOrcado: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_orcado']),
      valorRealizado: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_realizado']),
      taxaVariacao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_variacao']),
      valorVariacao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_variacao']),
    );
  }

  @override
  $OrcamentoFluxoCaixaDetalhesTable createAlias(String alias) {
    return $OrcamentoFluxoCaixaDetalhesTable(attachedDatabase, alias);
  }
}

class OrcamentoFluxoCaixaDetalhe extends DataClass
    implements Insertable<OrcamentoFluxoCaixaDetalhe> {
  final int? id;
  final int? idOrcamentoFluxoCaixa;
  final int? idFinNaturezaFinanceira;
  final String? periodo;
  final double? valorOrcado;
  final double? valorRealizado;
  final double? taxaVariacao;
  final double? valorVariacao;
  const OrcamentoFluxoCaixaDetalhe(
      {this.id,
      this.idOrcamentoFluxoCaixa,
      this.idFinNaturezaFinanceira,
      this.periodo,
      this.valorOrcado,
      this.valorRealizado,
      this.taxaVariacao,
      this.valorVariacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOrcamentoFluxoCaixa != null) {
      map['id_orcamento_fluxo_caixa'] = Variable<int>(idOrcamentoFluxoCaixa);
    }
    if (!nullToAbsent || idFinNaturezaFinanceira != null) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira);
    }
    if (!nullToAbsent || periodo != null) {
      map['periodo'] = Variable<String>(periodo);
    }
    if (!nullToAbsent || valorOrcado != null) {
      map['valor_orcado'] = Variable<double>(valorOrcado);
    }
    if (!nullToAbsent || valorRealizado != null) {
      map['valor_realizado'] = Variable<double>(valorRealizado);
    }
    if (!nullToAbsent || taxaVariacao != null) {
      map['taxa_variacao'] = Variable<double>(taxaVariacao);
    }
    if (!nullToAbsent || valorVariacao != null) {
      map['valor_variacao'] = Variable<double>(valorVariacao);
    }
    return map;
  }

  factory OrcamentoFluxoCaixaDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoFluxoCaixaDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idOrcamentoFluxoCaixa:
          serializer.fromJson<int?>(json['idOrcamentoFluxoCaixa']),
      idFinNaturezaFinanceira:
          serializer.fromJson<int?>(json['idFinNaturezaFinanceira']),
      periodo: serializer.fromJson<String?>(json['periodo']),
      valorOrcado: serializer.fromJson<double?>(json['valorOrcado']),
      valorRealizado: serializer.fromJson<double?>(json['valorRealizado']),
      taxaVariacao: serializer.fromJson<double?>(json['taxaVariacao']),
      valorVariacao: serializer.fromJson<double?>(json['valorVariacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOrcamentoFluxoCaixa': serializer.toJson<int?>(idOrcamentoFluxoCaixa),
      'idFinNaturezaFinanceira':
          serializer.toJson<int?>(idFinNaturezaFinanceira),
      'periodo': serializer.toJson<String?>(periodo),
      'valorOrcado': serializer.toJson<double?>(valorOrcado),
      'valorRealizado': serializer.toJson<double?>(valorRealizado),
      'taxaVariacao': serializer.toJson<double?>(taxaVariacao),
      'valorVariacao': serializer.toJson<double?>(valorVariacao),
    };
  }

  OrcamentoFluxoCaixaDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOrcamentoFluxoCaixa = const Value.absent(),
          Value<int?> idFinNaturezaFinanceira = const Value.absent(),
          Value<String?> periodo = const Value.absent(),
          Value<double?> valorOrcado = const Value.absent(),
          Value<double?> valorRealizado = const Value.absent(),
          Value<double?> taxaVariacao = const Value.absent(),
          Value<double?> valorVariacao = const Value.absent()}) =>
      OrcamentoFluxoCaixaDetalhe(
        id: id.present ? id.value : this.id,
        idOrcamentoFluxoCaixa: idOrcamentoFluxoCaixa.present
            ? idOrcamentoFluxoCaixa.value
            : this.idOrcamentoFluxoCaixa,
        idFinNaturezaFinanceira: idFinNaturezaFinanceira.present
            ? idFinNaturezaFinanceira.value
            : this.idFinNaturezaFinanceira,
        periodo: periodo.present ? periodo.value : this.periodo,
        valorOrcado: valorOrcado.present ? valorOrcado.value : this.valorOrcado,
        valorRealizado:
            valorRealizado.present ? valorRealizado.value : this.valorRealizado,
        taxaVariacao:
            taxaVariacao.present ? taxaVariacao.value : this.taxaVariacao,
        valorVariacao:
            valorVariacao.present ? valorVariacao.value : this.valorVariacao,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixaDetalhe(')
          ..write('id: $id, ')
          ..write('idOrcamentoFluxoCaixa: $idOrcamentoFluxoCaixa, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('periodo: $periodo, ')
          ..write('valorOrcado: $valorOrcado, ')
          ..write('valorRealizado: $valorRealizado, ')
          ..write('taxaVariacao: $taxaVariacao, ')
          ..write('valorVariacao: $valorVariacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idOrcamentoFluxoCaixa,
      idFinNaturezaFinanceira,
      periodo,
      valorOrcado,
      valorRealizado,
      taxaVariacao,
      valorVariacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoFluxoCaixaDetalhe &&
          other.id == this.id &&
          other.idOrcamentoFluxoCaixa == this.idOrcamentoFluxoCaixa &&
          other.idFinNaturezaFinanceira == this.idFinNaturezaFinanceira &&
          other.periodo == this.periodo &&
          other.valorOrcado == this.valorOrcado &&
          other.valorRealizado == this.valorRealizado &&
          other.taxaVariacao == this.taxaVariacao &&
          other.valorVariacao == this.valorVariacao);
}

class OrcamentoFluxoCaixaDetalhesCompanion
    extends UpdateCompanion<OrcamentoFluxoCaixaDetalhe> {
  final Value<int?> id;
  final Value<int?> idOrcamentoFluxoCaixa;
  final Value<int?> idFinNaturezaFinanceira;
  final Value<String?> periodo;
  final Value<double?> valorOrcado;
  final Value<double?> valorRealizado;
  final Value<double?> taxaVariacao;
  final Value<double?> valorVariacao;
  const OrcamentoFluxoCaixaDetalhesCompanion({
    this.id = const Value.absent(),
    this.idOrcamentoFluxoCaixa = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.periodo = const Value.absent(),
    this.valorOrcado = const Value.absent(),
    this.valorRealizado = const Value.absent(),
    this.taxaVariacao = const Value.absent(),
    this.valorVariacao = const Value.absent(),
  });
  OrcamentoFluxoCaixaDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idOrcamentoFluxoCaixa = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.periodo = const Value.absent(),
    this.valorOrcado = const Value.absent(),
    this.valorRealizado = const Value.absent(),
    this.taxaVariacao = const Value.absent(),
    this.valorVariacao = const Value.absent(),
  });
  static Insertable<OrcamentoFluxoCaixaDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idOrcamentoFluxoCaixa,
    Expression<int>? idFinNaturezaFinanceira,
    Expression<String>? periodo,
    Expression<double>? valorOrcado,
    Expression<double>? valorRealizado,
    Expression<double>? taxaVariacao,
    Expression<double>? valorVariacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOrcamentoFluxoCaixa != null)
        'id_orcamento_fluxo_caixa': idOrcamentoFluxoCaixa,
      if (idFinNaturezaFinanceira != null)
        'id_fin_natureza_financeira': idFinNaturezaFinanceira,
      if (periodo != null) 'periodo': periodo,
      if (valorOrcado != null) 'valor_orcado': valorOrcado,
      if (valorRealizado != null) 'valor_realizado': valorRealizado,
      if (taxaVariacao != null) 'taxa_variacao': taxaVariacao,
      if (valorVariacao != null) 'valor_variacao': valorVariacao,
    });
  }

  OrcamentoFluxoCaixaDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOrcamentoFluxoCaixa,
      Value<int?>? idFinNaturezaFinanceira,
      Value<String?>? periodo,
      Value<double?>? valorOrcado,
      Value<double?>? valorRealizado,
      Value<double?>? taxaVariacao,
      Value<double?>? valorVariacao}) {
    return OrcamentoFluxoCaixaDetalhesCompanion(
      id: id ?? this.id,
      idOrcamentoFluxoCaixa:
          idOrcamentoFluxoCaixa ?? this.idOrcamentoFluxoCaixa,
      idFinNaturezaFinanceira:
          idFinNaturezaFinanceira ?? this.idFinNaturezaFinanceira,
      periodo: periodo ?? this.periodo,
      valorOrcado: valorOrcado ?? this.valorOrcado,
      valorRealizado: valorRealizado ?? this.valorRealizado,
      taxaVariacao: taxaVariacao ?? this.taxaVariacao,
      valorVariacao: valorVariacao ?? this.valorVariacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOrcamentoFluxoCaixa.present) {
      map['id_orcamento_fluxo_caixa'] =
          Variable<int>(idOrcamentoFluxoCaixa.value);
    }
    if (idFinNaturezaFinanceira.present) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira.value);
    }
    if (periodo.present) {
      map['periodo'] = Variable<String>(periodo.value);
    }
    if (valorOrcado.present) {
      map['valor_orcado'] = Variable<double>(valorOrcado.value);
    }
    if (valorRealizado.present) {
      map['valor_realizado'] = Variable<double>(valorRealizado.value);
    }
    if (taxaVariacao.present) {
      map['taxa_variacao'] = Variable<double>(taxaVariacao.value);
    }
    if (valorVariacao.present) {
      map['valor_variacao'] = Variable<double>(valorVariacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixaDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idOrcamentoFluxoCaixa: $idOrcamentoFluxoCaixa, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('periodo: $periodo, ')
          ..write('valorOrcado: $valorOrcado, ')
          ..write('valorRealizado: $valorRealizado, ')
          ..write('taxaVariacao: $taxaVariacao, ')
          ..write('valorVariacao: $valorVariacao')
          ..write(')'))
        .toString();
  }
}

class $OrcamentoDetalhesTable extends OrcamentoDetalhes
    with TableInfo<$OrcamentoDetalhesTable, OrcamentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOrcamentoEmpresarialMeta =
      const VerificationMeta('idOrcamentoEmpresarial');
  @override
  late final GeneratedColumn<int> idOrcamentoEmpresarial = GeneratedColumn<int>(
      'id_orcamento_empresarial', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFinNaturezaFinanceiraMeta =
      const VerificationMeta('idFinNaturezaFinanceira');
  @override
  late final GeneratedColumn<int> idFinNaturezaFinanceira =
      GeneratedColumn<int>('id_fin_natureza_financeira', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _periodoMeta =
      const VerificationMeta('periodo');
  @override
  late final GeneratedColumn<String> periodo = GeneratedColumn<String>(
      'periodo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorOrcadoMeta =
      const VerificationMeta('valorOrcado');
  @override
  late final GeneratedColumn<double> valorOrcado = GeneratedColumn<double>(
      'valor_orcado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRealizadoMeta =
      const VerificationMeta('valorRealizado');
  @override
  late final GeneratedColumn<double> valorRealizado = GeneratedColumn<double>(
      'valor_realizado', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaVariacaoMeta =
      const VerificationMeta('taxaVariacao');
  @override
  late final GeneratedColumn<double> taxaVariacao = GeneratedColumn<double>(
      'taxa_variacao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVariacaoMeta =
      const VerificationMeta('valorVariacao');
  @override
  late final GeneratedColumn<double> valorVariacao = GeneratedColumn<double>(
      'valor_variacao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idOrcamentoEmpresarial,
        idFinNaturezaFinanceira,
        periodo,
        valorOrcado,
        valorRealizado,
        taxaVariacao,
        valorVariacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_detalhe';
  @override
  VerificationContext validateIntegrity(Insertable<OrcamentoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_orcamento_empresarial')) {
      context.handle(
          _idOrcamentoEmpresarialMeta,
          idOrcamentoEmpresarial.isAcceptableOrUnknown(
              data['id_orcamento_empresarial']!, _idOrcamentoEmpresarialMeta));
    }
    if (data.containsKey('id_fin_natureza_financeira')) {
      context.handle(
          _idFinNaturezaFinanceiraMeta,
          idFinNaturezaFinanceira.isAcceptableOrUnknown(
              data['id_fin_natureza_financeira']!,
              _idFinNaturezaFinanceiraMeta));
    }
    if (data.containsKey('periodo')) {
      context.handle(_periodoMeta,
          periodo.isAcceptableOrUnknown(data['periodo']!, _periodoMeta));
    }
    if (data.containsKey('valor_orcado')) {
      context.handle(
          _valorOrcadoMeta,
          valorOrcado.isAcceptableOrUnknown(
              data['valor_orcado']!, _valorOrcadoMeta));
    }
    if (data.containsKey('valor_realizado')) {
      context.handle(
          _valorRealizadoMeta,
          valorRealizado.isAcceptableOrUnknown(
              data['valor_realizado']!, _valorRealizadoMeta));
    }
    if (data.containsKey('taxa_variacao')) {
      context.handle(
          _taxaVariacaoMeta,
          taxaVariacao.isAcceptableOrUnknown(
              data['taxa_variacao']!, _taxaVariacaoMeta));
    }
    if (data.containsKey('valor_variacao')) {
      context.handle(
          _valorVariacaoMeta,
          valorVariacao.isAcceptableOrUnknown(
              data['valor_variacao']!, _valorVariacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOrcamentoEmpresarial: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_orcamento_empresarial']),
      idFinNaturezaFinanceira: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_fin_natureza_financeira']),
      periodo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo']),
      valorOrcado: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_orcado']),
      valorRealizado: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_realizado']),
      taxaVariacao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_variacao']),
      valorVariacao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_variacao']),
    );
  }

  @override
  $OrcamentoDetalhesTable createAlias(String alias) {
    return $OrcamentoDetalhesTable(attachedDatabase, alias);
  }
}

class OrcamentoDetalhe extends DataClass
    implements Insertable<OrcamentoDetalhe> {
  final int? id;
  final int? idOrcamentoEmpresarial;
  final int? idFinNaturezaFinanceira;
  final String? periodo;
  final double? valorOrcado;
  final double? valorRealizado;
  final double? taxaVariacao;
  final double? valorVariacao;
  const OrcamentoDetalhe(
      {this.id,
      this.idOrcamentoEmpresarial,
      this.idFinNaturezaFinanceira,
      this.periodo,
      this.valorOrcado,
      this.valorRealizado,
      this.taxaVariacao,
      this.valorVariacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOrcamentoEmpresarial != null) {
      map['id_orcamento_empresarial'] = Variable<int>(idOrcamentoEmpresarial);
    }
    if (!nullToAbsent || idFinNaturezaFinanceira != null) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira);
    }
    if (!nullToAbsent || periodo != null) {
      map['periodo'] = Variable<String>(periodo);
    }
    if (!nullToAbsent || valorOrcado != null) {
      map['valor_orcado'] = Variable<double>(valorOrcado);
    }
    if (!nullToAbsent || valorRealizado != null) {
      map['valor_realizado'] = Variable<double>(valorRealizado);
    }
    if (!nullToAbsent || taxaVariacao != null) {
      map['taxa_variacao'] = Variable<double>(taxaVariacao);
    }
    if (!nullToAbsent || valorVariacao != null) {
      map['valor_variacao'] = Variable<double>(valorVariacao);
    }
    return map;
  }

  factory OrcamentoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idOrcamentoEmpresarial:
          serializer.fromJson<int?>(json['idOrcamentoEmpresarial']),
      idFinNaturezaFinanceira:
          serializer.fromJson<int?>(json['idFinNaturezaFinanceira']),
      periodo: serializer.fromJson<String?>(json['periodo']),
      valorOrcado: serializer.fromJson<double?>(json['valorOrcado']),
      valorRealizado: serializer.fromJson<double?>(json['valorRealizado']),
      taxaVariacao: serializer.fromJson<double?>(json['taxaVariacao']),
      valorVariacao: serializer.fromJson<double?>(json['valorVariacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOrcamentoEmpresarial': serializer.toJson<int?>(idOrcamentoEmpresarial),
      'idFinNaturezaFinanceira':
          serializer.toJson<int?>(idFinNaturezaFinanceira),
      'periodo': serializer.toJson<String?>(periodo),
      'valorOrcado': serializer.toJson<double?>(valorOrcado),
      'valorRealizado': serializer.toJson<double?>(valorRealizado),
      'taxaVariacao': serializer.toJson<double?>(taxaVariacao),
      'valorVariacao': serializer.toJson<double?>(valorVariacao),
    };
  }

  OrcamentoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOrcamentoEmpresarial = const Value.absent(),
          Value<int?> idFinNaturezaFinanceira = const Value.absent(),
          Value<String?> periodo = const Value.absent(),
          Value<double?> valorOrcado = const Value.absent(),
          Value<double?> valorRealizado = const Value.absent(),
          Value<double?> taxaVariacao = const Value.absent(),
          Value<double?> valorVariacao = const Value.absent()}) =>
      OrcamentoDetalhe(
        id: id.present ? id.value : this.id,
        idOrcamentoEmpresarial: idOrcamentoEmpresarial.present
            ? idOrcamentoEmpresarial.value
            : this.idOrcamentoEmpresarial,
        idFinNaturezaFinanceira: idFinNaturezaFinanceira.present
            ? idFinNaturezaFinanceira.value
            : this.idFinNaturezaFinanceira,
        periodo: periodo.present ? periodo.value : this.periodo,
        valorOrcado: valorOrcado.present ? valorOrcado.value : this.valorOrcado,
        valorRealizado:
            valorRealizado.present ? valorRealizado.value : this.valorRealizado,
        taxaVariacao:
            taxaVariacao.present ? taxaVariacao.value : this.taxaVariacao,
        valorVariacao:
            valorVariacao.present ? valorVariacao.value : this.valorVariacao,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoDetalhe(')
          ..write('id: $id, ')
          ..write('idOrcamentoEmpresarial: $idOrcamentoEmpresarial, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('periodo: $periodo, ')
          ..write('valorOrcado: $valorOrcado, ')
          ..write('valorRealizado: $valorRealizado, ')
          ..write('taxaVariacao: $taxaVariacao, ')
          ..write('valorVariacao: $valorVariacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idOrcamentoEmpresarial,
      idFinNaturezaFinanceira,
      periodo,
      valorOrcado,
      valorRealizado,
      taxaVariacao,
      valorVariacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoDetalhe &&
          other.id == this.id &&
          other.idOrcamentoEmpresarial == this.idOrcamentoEmpresarial &&
          other.idFinNaturezaFinanceira == this.idFinNaturezaFinanceira &&
          other.periodo == this.periodo &&
          other.valorOrcado == this.valorOrcado &&
          other.valorRealizado == this.valorRealizado &&
          other.taxaVariacao == this.taxaVariacao &&
          other.valorVariacao == this.valorVariacao);
}

class OrcamentoDetalhesCompanion extends UpdateCompanion<OrcamentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idOrcamentoEmpresarial;
  final Value<int?> idFinNaturezaFinanceira;
  final Value<String?> periodo;
  final Value<double?> valorOrcado;
  final Value<double?> valorRealizado;
  final Value<double?> taxaVariacao;
  final Value<double?> valorVariacao;
  const OrcamentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idOrcamentoEmpresarial = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.periodo = const Value.absent(),
    this.valorOrcado = const Value.absent(),
    this.valorRealizado = const Value.absent(),
    this.taxaVariacao = const Value.absent(),
    this.valorVariacao = const Value.absent(),
  });
  OrcamentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idOrcamentoEmpresarial = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.periodo = const Value.absent(),
    this.valorOrcado = const Value.absent(),
    this.valorRealizado = const Value.absent(),
    this.taxaVariacao = const Value.absent(),
    this.valorVariacao = const Value.absent(),
  });
  static Insertable<OrcamentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idOrcamentoEmpresarial,
    Expression<int>? idFinNaturezaFinanceira,
    Expression<String>? periodo,
    Expression<double>? valorOrcado,
    Expression<double>? valorRealizado,
    Expression<double>? taxaVariacao,
    Expression<double>? valorVariacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOrcamentoEmpresarial != null)
        'id_orcamento_empresarial': idOrcamentoEmpresarial,
      if (idFinNaturezaFinanceira != null)
        'id_fin_natureza_financeira': idFinNaturezaFinanceira,
      if (periodo != null) 'periodo': periodo,
      if (valorOrcado != null) 'valor_orcado': valorOrcado,
      if (valorRealizado != null) 'valor_realizado': valorRealizado,
      if (taxaVariacao != null) 'taxa_variacao': taxaVariacao,
      if (valorVariacao != null) 'valor_variacao': valorVariacao,
    });
  }

  OrcamentoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOrcamentoEmpresarial,
      Value<int?>? idFinNaturezaFinanceira,
      Value<String?>? periodo,
      Value<double?>? valorOrcado,
      Value<double?>? valorRealizado,
      Value<double?>? taxaVariacao,
      Value<double?>? valorVariacao}) {
    return OrcamentoDetalhesCompanion(
      id: id ?? this.id,
      idOrcamentoEmpresarial:
          idOrcamentoEmpresarial ?? this.idOrcamentoEmpresarial,
      idFinNaturezaFinanceira:
          idFinNaturezaFinanceira ?? this.idFinNaturezaFinanceira,
      periodo: periodo ?? this.periodo,
      valorOrcado: valorOrcado ?? this.valorOrcado,
      valorRealizado: valorRealizado ?? this.valorRealizado,
      taxaVariacao: taxaVariacao ?? this.taxaVariacao,
      valorVariacao: valorVariacao ?? this.valorVariacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOrcamentoEmpresarial.present) {
      map['id_orcamento_empresarial'] =
          Variable<int>(idOrcamentoEmpresarial.value);
    }
    if (idFinNaturezaFinanceira.present) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira.value);
    }
    if (periodo.present) {
      map['periodo'] = Variable<String>(periodo.value);
    }
    if (valorOrcado.present) {
      map['valor_orcado'] = Variable<double>(valorOrcado.value);
    }
    if (valorRealizado.present) {
      map['valor_realizado'] = Variable<double>(valorRealizado.value);
    }
    if (taxaVariacao.present) {
      map['taxa_variacao'] = Variable<double>(taxaVariacao.value);
    }
    if (valorVariacao.present) {
      map['valor_variacao'] = Variable<double>(valorVariacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idOrcamentoEmpresarial: $idOrcamentoEmpresarial, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('periodo: $periodo, ')
          ..write('valorOrcado: $valorOrcado, ')
          ..write('valorRealizado: $valorRealizado, ')
          ..write('taxaVariacao: $taxaVariacao, ')
          ..write('valorVariacao: $valorVariacao')
          ..write(')'))
        .toString();
  }
}

class $OrcamentoFluxoCaixasTable extends OrcamentoFluxoCaixas
    with TableInfo<$OrcamentoFluxoCaixasTable, OrcamentoFluxoCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoFluxoCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOrcFluxoCaixaPeriodoMeta =
      const VerificationMeta('idOrcFluxoCaixaPeriodo');
  @override
  late final GeneratedColumn<int> idOrcFluxoCaixaPeriodo = GeneratedColumn<int>(
      'id_orc_fluxo_caixa_periodo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInicialMeta =
      const VerificationMeta('dataInicial');
  @override
  late final GeneratedColumn<DateTime> dataInicial = GeneratedColumn<DateTime>(
      'data_inicial', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _numeroPeriodosMeta =
      const VerificationMeta('numeroPeriodos');
  @override
  late final GeneratedColumn<int> numeroPeriodos = GeneratedColumn<int>(
      'numero_periodos', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataBaseMeta =
      const VerificationMeta('dataBase');
  @override
  late final GeneratedColumn<DateTime> dataBase = GeneratedColumn<DateTime>(
      'data_base', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idOrcFluxoCaixaPeriodo,
        nome,
        dataInicial,
        numeroPeriodos,
        dataBase,
        descricao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_fluxo_caixa';
  @override
  VerificationContext validateIntegrity(
      Insertable<OrcamentoFluxoCaixa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_orc_fluxo_caixa_periodo')) {
      context.handle(
          _idOrcFluxoCaixaPeriodoMeta,
          idOrcFluxoCaixaPeriodo.isAcceptableOrUnknown(
              data['id_orc_fluxo_caixa_periodo']!,
              _idOrcFluxoCaixaPeriodoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('data_inicial')) {
      context.handle(
          _dataInicialMeta,
          dataInicial.isAcceptableOrUnknown(
              data['data_inicial']!, _dataInicialMeta));
    }
    if (data.containsKey('numero_periodos')) {
      context.handle(
          _numeroPeriodosMeta,
          numeroPeriodos.isAcceptableOrUnknown(
              data['numero_periodos']!, _numeroPeriodosMeta));
    }
    if (data.containsKey('data_base')) {
      context.handle(_dataBaseMeta,
          dataBase.isAcceptableOrUnknown(data['data_base']!, _dataBaseMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoFluxoCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoFluxoCaixa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOrcFluxoCaixaPeriodo: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_orc_fluxo_caixa_periodo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      dataInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicial']),
      numeroPeriodos: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_periodos']),
      dataBase: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_base']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $OrcamentoFluxoCaixasTable createAlias(String alias) {
    return $OrcamentoFluxoCaixasTable(attachedDatabase, alias);
  }
}

class OrcamentoFluxoCaixa extends DataClass
    implements Insertable<OrcamentoFluxoCaixa> {
  final int? id;
  final int? idOrcFluxoCaixaPeriodo;
  final String? nome;
  final DateTime? dataInicial;
  final int? numeroPeriodos;
  final DateTime? dataBase;
  final String? descricao;
  const OrcamentoFluxoCaixa(
      {this.id,
      this.idOrcFluxoCaixaPeriodo,
      this.nome,
      this.dataInicial,
      this.numeroPeriodos,
      this.dataBase,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOrcFluxoCaixaPeriodo != null) {
      map['id_orc_fluxo_caixa_periodo'] = Variable<int>(idOrcFluxoCaixaPeriodo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataInicial != null) {
      map['data_inicial'] = Variable<DateTime>(dataInicial);
    }
    if (!nullToAbsent || numeroPeriodos != null) {
      map['numero_periodos'] = Variable<int>(numeroPeriodos);
    }
    if (!nullToAbsent || dataBase != null) {
      map['data_base'] = Variable<DateTime>(dataBase);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory OrcamentoFluxoCaixa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoFluxoCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idOrcFluxoCaixaPeriodo:
          serializer.fromJson<int?>(json['idOrcFluxoCaixaPeriodo']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataInicial: serializer.fromJson<DateTime?>(json['dataInicial']),
      numeroPeriodos: serializer.fromJson<int?>(json['numeroPeriodos']),
      dataBase: serializer.fromJson<DateTime?>(json['dataBase']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOrcFluxoCaixaPeriodo': serializer.toJson<int?>(idOrcFluxoCaixaPeriodo),
      'nome': serializer.toJson<String?>(nome),
      'dataInicial': serializer.toJson<DateTime?>(dataInicial),
      'numeroPeriodos': serializer.toJson<int?>(numeroPeriodos),
      'dataBase': serializer.toJson<DateTime?>(dataBase),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  OrcamentoFluxoCaixa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOrcFluxoCaixaPeriodo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<DateTime?> dataInicial = const Value.absent(),
          Value<int?> numeroPeriodos = const Value.absent(),
          Value<DateTime?> dataBase = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      OrcamentoFluxoCaixa(
        id: id.present ? id.value : this.id,
        idOrcFluxoCaixaPeriodo: idOrcFluxoCaixaPeriodo.present
            ? idOrcFluxoCaixaPeriodo.value
            : this.idOrcFluxoCaixaPeriodo,
        nome: nome.present ? nome.value : this.nome,
        dataInicial: dataInicial.present ? dataInicial.value : this.dataInicial,
        numeroPeriodos:
            numeroPeriodos.present ? numeroPeriodos.value : this.numeroPeriodos,
        dataBase: dataBase.present ? dataBase.value : this.dataBase,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixa(')
          ..write('id: $id, ')
          ..write('idOrcFluxoCaixaPeriodo: $idOrcFluxoCaixaPeriodo, ')
          ..write('nome: $nome, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('numeroPeriodos: $numeroPeriodos, ')
          ..write('dataBase: $dataBase, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idOrcFluxoCaixaPeriodo, nome, dataInicial,
      numeroPeriodos, dataBase, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoFluxoCaixa &&
          other.id == this.id &&
          other.idOrcFluxoCaixaPeriodo == this.idOrcFluxoCaixaPeriodo &&
          other.nome == this.nome &&
          other.dataInicial == this.dataInicial &&
          other.numeroPeriodos == this.numeroPeriodos &&
          other.dataBase == this.dataBase &&
          other.descricao == this.descricao);
}

class OrcamentoFluxoCaixasCompanion
    extends UpdateCompanion<OrcamentoFluxoCaixa> {
  final Value<int?> id;
  final Value<int?> idOrcFluxoCaixaPeriodo;
  final Value<String?> nome;
  final Value<DateTime?> dataInicial;
  final Value<int?> numeroPeriodos;
  final Value<DateTime?> dataBase;
  final Value<String?> descricao;
  const OrcamentoFluxoCaixasCompanion({
    this.id = const Value.absent(),
    this.idOrcFluxoCaixaPeriodo = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.numeroPeriodos = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  OrcamentoFluxoCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idOrcFluxoCaixaPeriodo = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.numeroPeriodos = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<OrcamentoFluxoCaixa> custom({
    Expression<int>? id,
    Expression<int>? idOrcFluxoCaixaPeriodo,
    Expression<String>? nome,
    Expression<DateTime>? dataInicial,
    Expression<int>? numeroPeriodos,
    Expression<DateTime>? dataBase,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOrcFluxoCaixaPeriodo != null)
        'id_orc_fluxo_caixa_periodo': idOrcFluxoCaixaPeriodo,
      if (nome != null) 'nome': nome,
      if (dataInicial != null) 'data_inicial': dataInicial,
      if (numeroPeriodos != null) 'numero_periodos': numeroPeriodos,
      if (dataBase != null) 'data_base': dataBase,
      if (descricao != null) 'descricao': descricao,
    });
  }

  OrcamentoFluxoCaixasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOrcFluxoCaixaPeriodo,
      Value<String?>? nome,
      Value<DateTime?>? dataInicial,
      Value<int?>? numeroPeriodos,
      Value<DateTime?>? dataBase,
      Value<String?>? descricao}) {
    return OrcamentoFluxoCaixasCompanion(
      id: id ?? this.id,
      idOrcFluxoCaixaPeriodo:
          idOrcFluxoCaixaPeriodo ?? this.idOrcFluxoCaixaPeriodo,
      nome: nome ?? this.nome,
      dataInicial: dataInicial ?? this.dataInicial,
      numeroPeriodos: numeroPeriodos ?? this.numeroPeriodos,
      dataBase: dataBase ?? this.dataBase,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOrcFluxoCaixaPeriodo.present) {
      map['id_orc_fluxo_caixa_periodo'] =
          Variable<int>(idOrcFluxoCaixaPeriodo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataInicial.present) {
      map['data_inicial'] = Variable<DateTime>(dataInicial.value);
    }
    if (numeroPeriodos.present) {
      map['numero_periodos'] = Variable<int>(numeroPeriodos.value);
    }
    if (dataBase.present) {
      map['data_base'] = Variable<DateTime>(dataBase.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idOrcFluxoCaixaPeriodo: $idOrcFluxoCaixaPeriodo, ')
          ..write('nome: $nome, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('numeroPeriodos: $numeroPeriodos, ')
          ..write('dataBase: $dataBase, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $OrcamentoEmpresarialsTable extends OrcamentoEmpresarials
    with TableInfo<$OrcamentoEmpresarialsTable, OrcamentoEmpresarial> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoEmpresarialsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOrcamentoPeriodoMeta =
      const VerificationMeta('idOrcamentoPeriodo');
  @override
  late final GeneratedColumn<int> idOrcamentoPeriodo = GeneratedColumn<int>(
      'id_orcamento_periodo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInicialMeta =
      const VerificationMeta('dataInicial');
  @override
  late final GeneratedColumn<DateTime> dataInicial = GeneratedColumn<DateTime>(
      'data_inicial', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _numeroPeriodosMeta =
      const VerificationMeta('numeroPeriodos');
  @override
  late final GeneratedColumn<int> numeroPeriodos = GeneratedColumn<int>(
      'numero_periodos', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataBaseMeta =
      const VerificationMeta('dataBase');
  @override
  late final GeneratedColumn<DateTime> dataBase = GeneratedColumn<DateTime>(
      'data_base', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idOrcamentoPeriodo,
        nome,
        dataInicial,
        numeroPeriodos,
        dataBase,
        descricao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_empresarial';
  @override
  VerificationContext validateIntegrity(
      Insertable<OrcamentoEmpresarial> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_orcamento_periodo')) {
      context.handle(
          _idOrcamentoPeriodoMeta,
          idOrcamentoPeriodo.isAcceptableOrUnknown(
              data['id_orcamento_periodo']!, _idOrcamentoPeriodoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('data_inicial')) {
      context.handle(
          _dataInicialMeta,
          dataInicial.isAcceptableOrUnknown(
              data['data_inicial']!, _dataInicialMeta));
    }
    if (data.containsKey('numero_periodos')) {
      context.handle(
          _numeroPeriodosMeta,
          numeroPeriodos.isAcceptableOrUnknown(
              data['numero_periodos']!, _numeroPeriodosMeta));
    }
    if (data.containsKey('data_base')) {
      context.handle(_dataBaseMeta,
          dataBase.isAcceptableOrUnknown(data['data_base']!, _dataBaseMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoEmpresarial map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoEmpresarial(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOrcamentoPeriodo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_orcamento_periodo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      dataInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicial']),
      numeroPeriodos: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_periodos']),
      dataBase: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_base']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $OrcamentoEmpresarialsTable createAlias(String alias) {
    return $OrcamentoEmpresarialsTable(attachedDatabase, alias);
  }
}

class OrcamentoEmpresarial extends DataClass
    implements Insertable<OrcamentoEmpresarial> {
  final int? id;
  final int? idOrcamentoPeriodo;
  final String? nome;
  final DateTime? dataInicial;
  final int? numeroPeriodos;
  final DateTime? dataBase;
  final String? descricao;
  const OrcamentoEmpresarial(
      {this.id,
      this.idOrcamentoPeriodo,
      this.nome,
      this.dataInicial,
      this.numeroPeriodos,
      this.dataBase,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOrcamentoPeriodo != null) {
      map['id_orcamento_periodo'] = Variable<int>(idOrcamentoPeriodo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataInicial != null) {
      map['data_inicial'] = Variable<DateTime>(dataInicial);
    }
    if (!nullToAbsent || numeroPeriodos != null) {
      map['numero_periodos'] = Variable<int>(numeroPeriodos);
    }
    if (!nullToAbsent || dataBase != null) {
      map['data_base'] = Variable<DateTime>(dataBase);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory OrcamentoEmpresarial.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoEmpresarial(
      id: serializer.fromJson<int?>(json['id']),
      idOrcamentoPeriodo: serializer.fromJson<int?>(json['idOrcamentoPeriodo']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataInicial: serializer.fromJson<DateTime?>(json['dataInicial']),
      numeroPeriodos: serializer.fromJson<int?>(json['numeroPeriodos']),
      dataBase: serializer.fromJson<DateTime?>(json['dataBase']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOrcamentoPeriodo': serializer.toJson<int?>(idOrcamentoPeriodo),
      'nome': serializer.toJson<String?>(nome),
      'dataInicial': serializer.toJson<DateTime?>(dataInicial),
      'numeroPeriodos': serializer.toJson<int?>(numeroPeriodos),
      'dataBase': serializer.toJson<DateTime?>(dataBase),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  OrcamentoEmpresarial copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOrcamentoPeriodo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<DateTime?> dataInicial = const Value.absent(),
          Value<int?> numeroPeriodos = const Value.absent(),
          Value<DateTime?> dataBase = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      OrcamentoEmpresarial(
        id: id.present ? id.value : this.id,
        idOrcamentoPeriodo: idOrcamentoPeriodo.present
            ? idOrcamentoPeriodo.value
            : this.idOrcamentoPeriodo,
        nome: nome.present ? nome.value : this.nome,
        dataInicial: dataInicial.present ? dataInicial.value : this.dataInicial,
        numeroPeriodos:
            numeroPeriodos.present ? numeroPeriodos.value : this.numeroPeriodos,
        dataBase: dataBase.present ? dataBase.value : this.dataBase,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoEmpresarial(')
          ..write('id: $id, ')
          ..write('idOrcamentoPeriodo: $idOrcamentoPeriodo, ')
          ..write('nome: $nome, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('numeroPeriodos: $numeroPeriodos, ')
          ..write('dataBase: $dataBase, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idOrcamentoPeriodo, nome, dataInicial,
      numeroPeriodos, dataBase, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoEmpresarial &&
          other.id == this.id &&
          other.idOrcamentoPeriodo == this.idOrcamentoPeriodo &&
          other.nome == this.nome &&
          other.dataInicial == this.dataInicial &&
          other.numeroPeriodos == this.numeroPeriodos &&
          other.dataBase == this.dataBase &&
          other.descricao == this.descricao);
}

class OrcamentoEmpresarialsCompanion
    extends UpdateCompanion<OrcamentoEmpresarial> {
  final Value<int?> id;
  final Value<int?> idOrcamentoPeriodo;
  final Value<String?> nome;
  final Value<DateTime?> dataInicial;
  final Value<int?> numeroPeriodos;
  final Value<DateTime?> dataBase;
  final Value<String?> descricao;
  const OrcamentoEmpresarialsCompanion({
    this.id = const Value.absent(),
    this.idOrcamentoPeriodo = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.numeroPeriodos = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  OrcamentoEmpresarialsCompanion.insert({
    this.id = const Value.absent(),
    this.idOrcamentoPeriodo = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.numeroPeriodos = const Value.absent(),
    this.dataBase = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<OrcamentoEmpresarial> custom({
    Expression<int>? id,
    Expression<int>? idOrcamentoPeriodo,
    Expression<String>? nome,
    Expression<DateTime>? dataInicial,
    Expression<int>? numeroPeriodos,
    Expression<DateTime>? dataBase,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOrcamentoPeriodo != null)
        'id_orcamento_periodo': idOrcamentoPeriodo,
      if (nome != null) 'nome': nome,
      if (dataInicial != null) 'data_inicial': dataInicial,
      if (numeroPeriodos != null) 'numero_periodos': numeroPeriodos,
      if (dataBase != null) 'data_base': dataBase,
      if (descricao != null) 'descricao': descricao,
    });
  }

  OrcamentoEmpresarialsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOrcamentoPeriodo,
      Value<String?>? nome,
      Value<DateTime?>? dataInicial,
      Value<int?>? numeroPeriodos,
      Value<DateTime?>? dataBase,
      Value<String?>? descricao}) {
    return OrcamentoEmpresarialsCompanion(
      id: id ?? this.id,
      idOrcamentoPeriodo: idOrcamentoPeriodo ?? this.idOrcamentoPeriodo,
      nome: nome ?? this.nome,
      dataInicial: dataInicial ?? this.dataInicial,
      numeroPeriodos: numeroPeriodos ?? this.numeroPeriodos,
      dataBase: dataBase ?? this.dataBase,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOrcamentoPeriodo.present) {
      map['id_orcamento_periodo'] = Variable<int>(idOrcamentoPeriodo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataInicial.present) {
      map['data_inicial'] = Variable<DateTime>(dataInicial.value);
    }
    if (numeroPeriodos.present) {
      map['numero_periodos'] = Variable<int>(numeroPeriodos.value);
    }
    if (dataBase.present) {
      map['data_base'] = Variable<DateTime>(dataBase.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoEmpresarialsCompanion(')
          ..write('id: $id, ')
          ..write('idOrcamentoPeriodo: $idOrcamentoPeriodo, ')
          ..write('nome: $nome, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('numeroPeriodos: $numeroPeriodos, ')
          ..write('dataBase: $dataBase, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $BancoContaCaixasTable extends BancoContaCaixas
    with TableInfo<$BancoContaCaixasTable, BancoContaCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BancoContaCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoMeta = const VerificationMeta('digito');
  @override
  late final GeneratedColumn<String> digito = GeneratedColumn<String>(
      'digito', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, numero, digito, nome, tipo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'banco_conta_caixa';
  @override
  VerificationContext validateIntegrity(Insertable<BancoContaCaixa> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('digito')) {
      context.handle(_digitoMeta,
          digito.isAcceptableOrUnknown(data['digito']!, _digitoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BancoContaCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BancoContaCaixa(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      digito: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}digito']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $BancoContaCaixasTable createAlias(String alias) {
    return $BancoContaCaixasTable(attachedDatabase, alias);
  }
}

class BancoContaCaixa extends DataClass implements Insertable<BancoContaCaixa> {
  final int? id;
  final String? numero;
  final String? digito;
  final String? nome;
  final String? tipo;
  final String? descricao;
  const BancoContaCaixa(
      {this.id,
      this.numero,
      this.digito,
      this.nome,
      this.tipo,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || digito != null) {
      map['digito'] = Variable<String>(digito);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory BancoContaCaixa.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BancoContaCaixa(
      id: serializer.fromJson<int?>(json['id']),
      numero: serializer.fromJson<String?>(json['numero']),
      digito: serializer.fromJson<String?>(json['digito']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'numero': serializer.toJson<String?>(numero),
      'digito': serializer.toJson<String?>(digito),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  BancoContaCaixa copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> digito = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      BancoContaCaixa(
        id: id.present ? id.value : this.id,
        numero: numero.present ? numero.value : this.numero,
        digito: digito.present ? digito.value : this.digito,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('BancoContaCaixa(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, numero, digito, nome, tipo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BancoContaCaixa &&
          other.id == this.id &&
          other.numero == this.numero &&
          other.digito == this.digito &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao);
}

class BancoContaCaixasCompanion extends UpdateCompanion<BancoContaCaixa> {
  final Value<int?> id;
  final Value<String?> numero;
  final Value<String?> digito;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> descricao;
  const BancoContaCaixasCompanion({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  BancoContaCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.digito = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<BancoContaCaixa> custom({
    Expression<int>? id,
    Expression<String>? numero,
    Expression<String>? digito,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (numero != null) 'numero': numero,
      if (digito != null) 'digito': digito,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  BancoContaCaixasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? numero,
      Value<String?>? digito,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? descricao}) {
    return BancoContaCaixasCompanion(
      id: id ?? this.id,
      numero: numero ?? this.numero,
      digito: digito ?? this.digito,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (digito.present) {
      map['digito'] = Variable<String>(digito.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BancoContaCaixasCompanion(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('digito: $digito, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $FinNaturezaFinanceirasTable extends FinNaturezaFinanceiras
    with TableInfo<$FinNaturezaFinanceirasTable, FinNaturezaFinanceira> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinNaturezaFinanceirasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aplicacaoMeta =
      const VerificationMeta('aplicacao');
  @override
  late final GeneratedColumn<String> aplicacao = GeneratedColumn<String>(
      'aplicacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, codigo, descricao, tipo, aplicacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_natureza_financeira';
  @override
  VerificationContext validateIntegrity(
      Insertable<FinNaturezaFinanceira> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('aplicacao')) {
      context.handle(_aplicacaoMeta,
          aplicacao.isAcceptableOrUnknown(data['aplicacao']!, _aplicacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinNaturezaFinanceira map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinNaturezaFinanceira(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      aplicacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}aplicacao']),
    );
  }

  @override
  $FinNaturezaFinanceirasTable createAlias(String alias) {
    return $FinNaturezaFinanceirasTable(attachedDatabase, alias);
  }
}

class FinNaturezaFinanceira extends DataClass
    implements Insertable<FinNaturezaFinanceira> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? tipo;
  final String? aplicacao;
  const FinNaturezaFinanceira(
      {this.id, this.codigo, this.descricao, this.tipo, this.aplicacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || aplicacao != null) {
      map['aplicacao'] = Variable<String>(aplicacao);
    }
    return map;
  }

  factory FinNaturezaFinanceira.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinNaturezaFinanceira(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      aplicacao: serializer.fromJson<String?>(json['aplicacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'tipo': serializer.toJson<String?>(tipo),
      'aplicacao': serializer.toJson<String?>(aplicacao),
    };
  }

  FinNaturezaFinanceira copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> aplicacao = const Value.absent()}) =>
      FinNaturezaFinanceira(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        tipo: tipo.present ? tipo.value : this.tipo,
        aplicacao: aplicacao.present ? aplicacao.value : this.aplicacao,
      );
  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceira(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, tipo, aplicacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinNaturezaFinanceira &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.tipo == this.tipo &&
          other.aplicacao == this.aplicacao);
}

class FinNaturezaFinanceirasCompanion
    extends UpdateCompanion<FinNaturezaFinanceira> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> tipo;
  final Value<String?> aplicacao;
  const FinNaturezaFinanceirasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  FinNaturezaFinanceirasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  static Insertable<FinNaturezaFinanceira> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? tipo,
    Expression<String>? aplicacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (tipo != null) 'tipo': tipo,
      if (aplicacao != null) 'aplicacao': aplicacao,
    });
  }

  FinNaturezaFinanceirasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? tipo,
      Value<String?>? aplicacao}) {
    return FinNaturezaFinanceirasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      tipo: tipo ?? this.tipo,
      aplicacao: aplicacao ?? this.aplicacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (aplicacao.present) {
      map['aplicacao'] = Variable<String>(aplicacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceirasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }
}

class $OrcamentoFluxoCaixaPeriodosTable extends OrcamentoFluxoCaixaPeriodos
    with
        TableInfo<$OrcamentoFluxoCaixaPeriodosTable,
            OrcamentoFluxoCaixaPeriodo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoFluxoCaixaPeriodosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idBancoContaCaixaMeta =
      const VerificationMeta('idBancoContaCaixa');
  @override
  late final GeneratedColumn<int> idBancoContaCaixa = GeneratedColumn<int>(
      'id_banco_conta_caixa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _periodoMeta =
      const VerificationMeta('periodo');
  @override
  late final GeneratedColumn<String> periodo = GeneratedColumn<String>(
      'periodo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idBancoContaCaixa, periodo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_fluxo_caixa_periodo';
  @override
  VerificationContext validateIntegrity(
      Insertable<OrcamentoFluxoCaixaPeriodo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_banco_conta_caixa')) {
      context.handle(
          _idBancoContaCaixaMeta,
          idBancoContaCaixa.isAcceptableOrUnknown(
              data['id_banco_conta_caixa']!, _idBancoContaCaixaMeta));
    }
    if (data.containsKey('periodo')) {
      context.handle(_periodoMeta,
          periodo.isAcceptableOrUnknown(data['periodo']!, _periodoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoFluxoCaixaPeriodo map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoFluxoCaixaPeriodo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idBancoContaCaixa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_banco_conta_caixa']),
      periodo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $OrcamentoFluxoCaixaPeriodosTable createAlias(String alias) {
    return $OrcamentoFluxoCaixaPeriodosTable(attachedDatabase, alias);
  }
}

class OrcamentoFluxoCaixaPeriodo extends DataClass
    implements Insertable<OrcamentoFluxoCaixaPeriodo> {
  final int? id;
  final int? idBancoContaCaixa;
  final String? periodo;
  final String? nome;
  const OrcamentoFluxoCaixaPeriodo(
      {this.id, this.idBancoContaCaixa, this.periodo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBancoContaCaixa != null) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa);
    }
    if (!nullToAbsent || periodo != null) {
      map['periodo'] = Variable<String>(periodo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory OrcamentoFluxoCaixaPeriodo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoFluxoCaixaPeriodo(
      id: serializer.fromJson<int?>(json['id']),
      idBancoContaCaixa: serializer.fromJson<int?>(json['idBancoContaCaixa']),
      periodo: serializer.fromJson<String?>(json['periodo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBancoContaCaixa': serializer.toJson<int?>(idBancoContaCaixa),
      'periodo': serializer.toJson<String?>(periodo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  OrcamentoFluxoCaixaPeriodo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idBancoContaCaixa = const Value.absent(),
          Value<String?> periodo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      OrcamentoFluxoCaixaPeriodo(
        id: id.present ? id.value : this.id,
        idBancoContaCaixa: idBancoContaCaixa.present
            ? idBancoContaCaixa.value
            : this.idBancoContaCaixa,
        periodo: periodo.present ? periodo.value : this.periodo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixaPeriodo(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('periodo: $periodo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idBancoContaCaixa, periodo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoFluxoCaixaPeriodo &&
          other.id == this.id &&
          other.idBancoContaCaixa == this.idBancoContaCaixa &&
          other.periodo == this.periodo &&
          other.nome == this.nome);
}

class OrcamentoFluxoCaixaPeriodosCompanion
    extends UpdateCompanion<OrcamentoFluxoCaixaPeriodo> {
  final Value<int?> id;
  final Value<int?> idBancoContaCaixa;
  final Value<String?> periodo;
  final Value<String?> nome;
  const OrcamentoFluxoCaixaPeriodosCompanion({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.periodo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  OrcamentoFluxoCaixaPeriodosCompanion.insert({
    this.id = const Value.absent(),
    this.idBancoContaCaixa = const Value.absent(),
    this.periodo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<OrcamentoFluxoCaixaPeriodo> custom({
    Expression<int>? id,
    Expression<int>? idBancoContaCaixa,
    Expression<String>? periodo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBancoContaCaixa != null) 'id_banco_conta_caixa': idBancoContaCaixa,
      if (periodo != null) 'periodo': periodo,
      if (nome != null) 'nome': nome,
    });
  }

  OrcamentoFluxoCaixaPeriodosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idBancoContaCaixa,
      Value<String?>? periodo,
      Value<String?>? nome}) {
    return OrcamentoFluxoCaixaPeriodosCompanion(
      id: id ?? this.id,
      idBancoContaCaixa: idBancoContaCaixa ?? this.idBancoContaCaixa,
      periodo: periodo ?? this.periodo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBancoContaCaixa.present) {
      map['id_banco_conta_caixa'] = Variable<int>(idBancoContaCaixa.value);
    }
    if (periodo.present) {
      map['periodo'] = Variable<String>(periodo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoFluxoCaixaPeriodosCompanion(')
          ..write('id: $id, ')
          ..write('idBancoContaCaixa: $idBancoContaCaixa, ')
          ..write('periodo: $periodo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $OrcamentoPeriodosTable extends OrcamentoPeriodos
    with TableInfo<$OrcamentoPeriodosTable, OrcamentoPeriodo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OrcamentoPeriodosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _periodoMeta =
      const VerificationMeta('periodo');
  @override
  late final GeneratedColumn<String> periodo = GeneratedColumn<String>(
      'periodo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, periodo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'orcamento_periodo';
  @override
  VerificationContext validateIntegrity(Insertable<OrcamentoPeriodo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('periodo')) {
      context.handle(_periodoMeta,
          periodo.isAcceptableOrUnknown(data['periodo']!, _periodoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OrcamentoPeriodo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OrcamentoPeriodo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      periodo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $OrcamentoPeriodosTable createAlias(String alias) {
    return $OrcamentoPeriodosTable(attachedDatabase, alias);
  }
}

class OrcamentoPeriodo extends DataClass
    implements Insertable<OrcamentoPeriodo> {
  final int? id;
  final String? periodo;
  final String? nome;
  const OrcamentoPeriodo({this.id, this.periodo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || periodo != null) {
      map['periodo'] = Variable<String>(periodo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory OrcamentoPeriodo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OrcamentoPeriodo(
      id: serializer.fromJson<int?>(json['id']),
      periodo: serializer.fromJson<String?>(json['periodo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'periodo': serializer.toJson<String?>(periodo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  OrcamentoPeriodo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> periodo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      OrcamentoPeriodo(
        id: id.present ? id.value : this.id,
        periodo: periodo.present ? periodo.value : this.periodo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('OrcamentoPeriodo(')
          ..write('id: $id, ')
          ..write('periodo: $periodo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, periodo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OrcamentoPeriodo &&
          other.id == this.id &&
          other.periodo == this.periodo &&
          other.nome == this.nome);
}

class OrcamentoPeriodosCompanion extends UpdateCompanion<OrcamentoPeriodo> {
  final Value<int?> id;
  final Value<String?> periodo;
  final Value<String?> nome;
  const OrcamentoPeriodosCompanion({
    this.id = const Value.absent(),
    this.periodo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  OrcamentoPeriodosCompanion.insert({
    this.id = const Value.absent(),
    this.periodo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<OrcamentoPeriodo> custom({
    Expression<int>? id,
    Expression<String>? periodo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (periodo != null) 'periodo': periodo,
      if (nome != null) 'nome': nome,
    });
  }

  OrcamentoPeriodosCompanion copyWith(
      {Value<int?>? id, Value<String?>? periodo, Value<String?>? nome}) {
    return OrcamentoPeriodosCompanion(
      id: id ?? this.id,
      periodo: periodo ?? this.periodo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (periodo.present) {
      map['periodo'] = Variable<String>(periodo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OrcamentoPeriodosCompanion(')
          ..write('id: $id, ')
          ..write('periodo: $periodo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $OrcamentoFluxoCaixaDetalhesTable orcamentoFluxoCaixaDetalhes =
      $OrcamentoFluxoCaixaDetalhesTable(this);
  late final $OrcamentoDetalhesTable orcamentoDetalhes =
      $OrcamentoDetalhesTable(this);
  late final $OrcamentoFluxoCaixasTable orcamentoFluxoCaixas =
      $OrcamentoFluxoCaixasTable(this);
  late final $OrcamentoEmpresarialsTable orcamentoEmpresarials =
      $OrcamentoEmpresarialsTable(this);
  late final $BancoContaCaixasTable bancoContaCaixas =
      $BancoContaCaixasTable(this);
  late final $FinNaturezaFinanceirasTable finNaturezaFinanceiras =
      $FinNaturezaFinanceirasTable(this);
  late final $OrcamentoFluxoCaixaPeriodosTable orcamentoFluxoCaixaPeriodos =
      $OrcamentoFluxoCaixaPeriodosTable(this);
  late final $OrcamentoPeriodosTable orcamentoPeriodos =
      $OrcamentoPeriodosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final OrcamentoFluxoCaixaDao orcamentoFluxoCaixaDao =
      OrcamentoFluxoCaixaDao(this as AppDatabase);
  late final OrcamentoEmpresarialDao orcamentoEmpresarialDao =
      OrcamentoEmpresarialDao(this as AppDatabase);
  late final BancoContaCaixaDao bancoContaCaixaDao =
      BancoContaCaixaDao(this as AppDatabase);
  late final FinNaturezaFinanceiraDao finNaturezaFinanceiraDao =
      FinNaturezaFinanceiraDao(this as AppDatabase);
  late final OrcamentoFluxoCaixaPeriodoDao orcamentoFluxoCaixaPeriodoDao =
      OrcamentoFluxoCaixaPeriodoDao(this as AppDatabase);
  late final OrcamentoPeriodoDao orcamentoPeriodoDao =
      OrcamentoPeriodoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        orcamentoFluxoCaixaDetalhes,
        orcamentoDetalhes,
        orcamentoFluxoCaixas,
        orcamentoEmpresarials,
        bancoContaCaixas,
        finNaturezaFinanceiras,
        orcamentoFluxoCaixaPeriodos,
        orcamentoPeriodos,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
