// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'orcamento_empresarial_dao.dart';

// ignore_for_file: type=lint
mixin _$OrcamentoEmpresarialDaoMixin on DatabaseAccessor<AppDatabase> {
  $OrcamentoEmpresarialsTable get orcamentoEmpresarials =>
      attachedDatabase.orcamentoEmpresarials;
  $OrcamentoDetalhesTable get orcamentoDetalhes =>
      attachedDatabase.orcamentoDetalhes;
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
  $OrcamentoPeriodosTable get orcamentoPeriodos =>
      attachedDatabase.orcamentoPeriodos;
}
