// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_estante_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsEstanteDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsEstantesTable get wmsEstantes => attachedDatabase.wmsEstantes;
  $WmsRuasTable get wmsRuas => attachedDatabase.wmsRuas;
}
