// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_recebimento_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsRecebimentoCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsRecebimentoCabecalhosTable get wmsRecebimentoCabecalhos =>
      attachedDatabase.wmsRecebimentoCabecalhos;
  $WmsRecebimentoDetalhesTable get wmsRecebimentoDetalhes =>
      attachedDatabase.wmsRecebimentoDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $WmsAgendamentosTable get wmsAgendamentos => attachedDatabase.wmsAgendamentos;
}
