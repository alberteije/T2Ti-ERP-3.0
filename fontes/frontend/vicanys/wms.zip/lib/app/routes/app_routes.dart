abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const wmsRecebimentoCabecalhoListPage = '/wmsRecebimentoCabecalhoListPage'; 
	static const wmsRecebimentoCabecalhoTabPage = '/wmsRecebimentoCabecalhoTabPage';
	static const wmsCaixaListPage = '/wmsCaixaListPage'; 
	static const wmsCaixaTabPage = '/wmsCaixaTabPage';
	static const wmsOrdemSeparacaoCabListPage = '/wmsOrdemSeparacaoCabListPage'; 
	static const wmsOrdemSeparacaoCabTabPage = '/wmsOrdemSeparacaoCabTabPage';
	static const wmsAgendamentoListPage = '/wmsAgendamentoListPage'; 
	static const wmsAgendamentoEditPage = '/wmsAgendamentoEditPage';
	static const wmsParametroListPage = '/wmsParametroListPage'; 
	static const wmsParametroEditPage = '/wmsParametroEditPage';
	static const wmsRuaListPage = '/wmsRuaListPage'; 
	static const wmsRuaEditPage = '/wmsRuaEditPage';
	static const wmsEstanteListPage = '/wmsEstanteListPage'; 
	static const wmsEstanteEditPage = '/wmsEstanteEditPage';
	static const wmsExpedicaoListPage = '/wmsExpedicaoListPage'; 
	static const wmsExpedicaoEditPage = '/wmsExpedicaoEditPage';
}