abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const gondolaCaixaListPage = '/gondolaCaixaListPage'; 
	static const gondolaCaixaTabPage = '/gondolaCaixaTabPage';
	static const gondolaRuaListPage = '/gondolaRuaListPage'; 
	static const gondolaRuaEditPage = '/gondolaRuaEditPage';
	static const gondolaEstanteListPage = '/gondolaEstanteListPage'; 
	static const gondolaEstanteEditPage = '/gondolaEstanteEditPage';
}