// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sped_contabil_dao.dart';

// ignore_for_file: type=lint
mixin _$SpedContabilDaoMixin on DatabaseAccessor<AppDatabase> {
  $SpedContabilsTable get spedContabils => attachedDatabase.spedContabils;
}
