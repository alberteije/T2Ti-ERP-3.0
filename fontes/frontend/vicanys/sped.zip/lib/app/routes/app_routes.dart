abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const spedContabilListPage = '/spedContabilListPage'; 
	static const spedContabilEditPage = '/spedContabilEditPage';
	static const spedFiscalListPage = '/spedFiscalListPage'; 
	static const spedFiscalEditPage = '/spedFiscalEditPage';
	static const sintegraListPage = '/sintegraListPage'; 
	static const sintegraEditPage = '/sintegraEditPage';
	static const efdContribuicoesListPage = '/efdContribuicoesListPage'; 
	static const efdContribuicoesEditPage = '/efdContribuicoesEditPage';
	static const efdReinfListPage = '/efdReinfListPage'; 
	static const efdReinfEditPage = '/efdReinfEditPage';
}