// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'esocial_motivo_desligamento_dao.dart';

// ignore_for_file: type=lint
mixin _$EsocialMotivoDesligamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $EsocialMotivoDesligamentosTable get esocialMotivoDesligamentos =>
      attachedDatabase.esocialMotivoDesligamentos;
}
