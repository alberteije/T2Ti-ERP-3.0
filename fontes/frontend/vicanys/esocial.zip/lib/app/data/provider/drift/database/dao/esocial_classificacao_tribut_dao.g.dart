// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'esocial_classificacao_tribut_dao.dart';

// ignore_for_file: type=lint
mixin _$EsocialClassificacaoTributDaoMixin on DatabaseAccessor<AppDatabase> {
  $EsocialClassificacaoTributsTable get esocialClassificacaoTributs =>
      attachedDatabase.esocialClassificacaoTributs;
}
