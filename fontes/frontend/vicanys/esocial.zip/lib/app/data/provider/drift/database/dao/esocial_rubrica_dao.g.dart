// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'esocial_rubrica_dao.dart';

// ignore_for_file: type=lint
mixin _$EsocialRubricaDaoMixin on DatabaseAccessor<AppDatabase> {
  $EsocialRubricasTable get esocialRubricas => attachedDatabase.esocialRubricas;
}
