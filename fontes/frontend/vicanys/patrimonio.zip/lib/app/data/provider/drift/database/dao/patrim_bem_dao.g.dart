// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_bem_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimBemDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimBemsTable get patrimBems => attachedDatabase.patrimBems;
  $PatrimDocumentoBemsTable get patrimDocumentoBems =>
      attachedDatabase.patrimDocumentoBems;
  $PatrimDepreciacaoBemsTable get patrimDepreciacaoBems =>
      attachedDatabase.patrimDepreciacaoBems;
  $PatrimMovimentacaoBemsTable get patrimMovimentacaoBems =>
      attachedDatabase.patrimMovimentacaoBems;
  $PatrimTipoMovimentacaosTable get patrimTipoMovimentacaos =>
      attachedDatabase.patrimTipoMovimentacaos;
  $PatrimApoliceSegurosTable get patrimApoliceSeguros =>
      attachedDatabase.patrimApoliceSeguros;
  $SeguradorasTable get seguradoras => attachedDatabase.seguradoras;
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
  $PatrimEstadoConservacaosTable get patrimEstadoConservacaos =>
      attachedDatabase.patrimEstadoConservacaos;
  $SetorsTable get setors => attachedDatabase.setors;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
  $PatrimTipoAquisicaoBemsTable get patrimTipoAquisicaoBems =>
      attachedDatabase.patrimTipoAquisicaoBems;
  $PatrimGrupoBemsTable get patrimGrupoBems => attachedDatabase.patrimGrupoBems;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
