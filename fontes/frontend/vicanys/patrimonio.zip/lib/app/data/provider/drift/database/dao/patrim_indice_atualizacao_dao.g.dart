// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_indice_atualizacao_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimIndiceAtualizacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimIndiceAtualizacaosTable get patrimIndiceAtualizacaos =>
      attachedDatabase.patrimIndiceAtualizacaos;
}
