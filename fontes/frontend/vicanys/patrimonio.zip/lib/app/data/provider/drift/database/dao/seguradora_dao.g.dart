// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'seguradora_dao.dart';

// ignore_for_file: type=lint
mixin _$SeguradoraDaoMixin on DatabaseAccessor<AppDatabase> {
  $SeguradorasTable get seguradoras => attachedDatabase.seguradoras;
}
