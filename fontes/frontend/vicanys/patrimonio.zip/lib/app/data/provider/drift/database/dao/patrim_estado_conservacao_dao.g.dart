// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'patrim_estado_conservacao_dao.dart';

// ignore_for_file: type=lint
mixin _$PatrimEstadoConservacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PatrimEstadoConservacaosTable get patrimEstadoConservacaos =>
      attachedDatabase.patrimEstadoConservacaos;
}
