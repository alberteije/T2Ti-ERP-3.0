abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const patrimBemListPage = '/patrimBemListPage'; 
	static const patrimBemTabPage = '/patrimBemTabPage';
	static const patrimIndiceAtualizacaoListPage = '/patrimIndiceAtualizacaoListPage'; 
	static const patrimIndiceAtualizacaoEditPage = '/patrimIndiceAtualizacaoEditPage';
	static const patrimTaxaDepreciacaoListPage = '/patrimTaxaDepreciacaoListPage'; 
	static const patrimTaxaDepreciacaoEditPage = '/patrimTaxaDepreciacaoEditPage';
	static const patrimGrupoBemListPage = '/patrimGrupoBemListPage'; 
	static const patrimGrupoBemEditPage = '/patrimGrupoBemEditPage';
	static const patrimTipoAquisicaoBemListPage = '/patrimTipoAquisicaoBemListPage'; 
	static const patrimTipoAquisicaoBemEditPage = '/patrimTipoAquisicaoBemEditPage';
	static const patrimEstadoConservacaoListPage = '/patrimEstadoConservacaoListPage'; 
	static const patrimEstadoConservacaoEditPage = '/patrimEstadoConservacaoEditPage';
	static const seguradoraListPage = '/seguradoraListPage'; 
	static const seguradoraEditPage = '/seguradoraEditPage';
	static const patrimTipoMovimentacaoListPage = '/patrimTipoMovimentacaoListPage'; 
	static const patrimTipoMovimentacaoEditPage = '/patrimTipoMovimentacaoEditPage';
}