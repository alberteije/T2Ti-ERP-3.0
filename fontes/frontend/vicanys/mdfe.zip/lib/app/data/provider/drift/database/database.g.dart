// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $MdfeLacresTable extends MdfeLacres
    with TableInfo<$MdfeLacresTable, MdfeLacre> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeLacresTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroLacreMeta =
      const VerificationMeta('numeroLacre');
  @override
  late final GeneratedColumn<String> numeroLacre = GeneratedColumn<String>(
      'numero_lacre', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idMdfeCabecalho, numeroLacre];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_lacre';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeLacre> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('numero_lacre')) {
      context.handle(
          _numeroLacreMeta,
          numeroLacre.isAcceptableOrUnknown(
              data['numero_lacre']!, _numeroLacreMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeLacre map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeLacre(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      numeroLacre: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_lacre']),
    );
  }

  @override
  $MdfeLacresTable createAlias(String alias) {
    return $MdfeLacresTable(attachedDatabase, alias);
  }
}

class MdfeLacre extends DataClass implements Insertable<MdfeLacre> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? numeroLacre;
  const MdfeLacre({this.id, this.idMdfeCabecalho, this.numeroLacre});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || numeroLacre != null) {
      map['numero_lacre'] = Variable<String>(numeroLacre);
    }
    return map;
  }

  factory MdfeLacre.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeLacre(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      numeroLacre: serializer.fromJson<String?>(json['numeroLacre']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'numeroLacre': serializer.toJson<String?>(numeroLacre),
    };
  }

  MdfeLacre copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> numeroLacre = const Value.absent()}) =>
      MdfeLacre(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        numeroLacre: numeroLacre.present ? numeroLacre.value : this.numeroLacre,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeLacre(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('numeroLacre: $numeroLacre')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeCabecalho, numeroLacre);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeLacre &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.numeroLacre == this.numeroLacre);
}

class MdfeLacresCompanion extends UpdateCompanion<MdfeLacre> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> numeroLacre;
  const MdfeLacresCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.numeroLacre = const Value.absent(),
  });
  MdfeLacresCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.numeroLacre = const Value.absent(),
  });
  static Insertable<MdfeLacre> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? numeroLacre,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (numeroLacre != null) 'numero_lacre': numeroLacre,
    });
  }

  MdfeLacresCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? numeroLacre}) {
    return MdfeLacresCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      numeroLacre: numeroLacre ?? this.numeroLacre,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (numeroLacre.present) {
      map['numero_lacre'] = Variable<String>(numeroLacre.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeLacresCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('numeroLacre: $numeroLacre')
          ..write(')'))
        .toString();
  }
}

class $MdfeMunicipioDescarregasTable extends MdfeMunicipioDescarregas
    with TableInfo<$MdfeMunicipioDescarregasTable, MdfeMunicipioDescarrega> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeMunicipioDescarregasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<String> codigoMunicipio = GeneratedColumn<String>(
      'codigo_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idMdfeCabecalho, codigoMunicipio, nomeMunicipio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_municipio_descarrega';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeMunicipioDescarrega> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeMunicipioDescarrega map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeMunicipioDescarrega(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      codigoMunicipio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
    );
  }

  @override
  $MdfeMunicipioDescarregasTable createAlias(String alias) {
    return $MdfeMunicipioDescarregasTable(attachedDatabase, alias);
  }
}

class MdfeMunicipioDescarrega extends DataClass
    implements Insertable<MdfeMunicipioDescarrega> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? codigoMunicipio;
  final String? nomeMunicipio;
  const MdfeMunicipioDescarrega(
      {this.id,
      this.idMdfeCabecalho,
      this.codigoMunicipio,
      this.nomeMunicipio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    return map;
  }

  factory MdfeMunicipioDescarrega.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeMunicipioDescarrega(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      codigoMunicipio: serializer.fromJson<String?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'codigoMunicipio': serializer.toJson<String?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
    };
  }

  MdfeMunicipioDescarrega copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent()}) =>
      MdfeMunicipioDescarrega(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeMunicipioDescarrega(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idMdfeCabecalho, codigoMunicipio, nomeMunicipio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeMunicipioDescarrega &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio);
}

class MdfeMunicipioDescarregasCompanion
    extends UpdateCompanion<MdfeMunicipioDescarrega> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  const MdfeMunicipioDescarregasCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
  });
  MdfeMunicipioDescarregasCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
  });
  static Insertable<MdfeMunicipioDescarrega> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
    });
  }

  MdfeMunicipioDescarregasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? codigoMunicipio,
      Value<String?>? nomeMunicipio}) {
    return MdfeMunicipioDescarregasCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeMunicipioDescarregasCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio')
          ..write(')'))
        .toString();
  }
}

class $MdfeEmitentesTable extends MdfeEmitentes
    with TableInfo<$MdfeEmitentesTable, MdfeEmitente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeEmitentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _fantasiaMeta =
      const VerificationMeta('fantasia');
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
      'fantasia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<int> ie = GeneratedColumn<int>(
      'ie', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<String> codigoMunicipio = GeneratedColumn<String>(
      'codigo_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _telefoneMeta =
      const VerificationMeta('telefone');
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
      'telefone', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 12),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeCabecalho,
        nome,
        fantasia,
        cnpj,
        ie,
        logradouro,
        numero,
        complemento,
        bairro,
        codigoMunicipio,
        nomeMunicipio,
        cep,
        uf,
        telefone,
        email
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_emitente';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeEmitente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('fantasia')) {
      context.handle(_fantasiaMeta,
          fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('telefone')) {
      context.handle(_telefoneMeta,
          telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeEmitente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeEmitente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      fantasia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fantasia']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      ie: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ie']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      codigoMunicipio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      telefone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}telefone']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
    );
  }

  @override
  $MdfeEmitentesTable createAlias(String alias) {
    return $MdfeEmitentesTable(attachedDatabase, alias);
  }
}

class MdfeEmitente extends DataClass implements Insertable<MdfeEmitente> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? nome;
  final String? fantasia;
  final String? cnpj;
  final int? ie;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? codigoMunicipio;
  final String? nomeMunicipio;
  final String? cep;
  final String? uf;
  final String? telefone;
  final String? email;
  const MdfeEmitente(
      {this.id,
      this.idMdfeCabecalho,
      this.nome,
      this.fantasia,
      this.cnpj,
      this.ie,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.codigoMunicipio,
      this.nomeMunicipio,
      this.cep,
      this.uf,
      this.telefone,
      this.email});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<int>(ie);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory MdfeEmitente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeEmitente(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      ie: serializer.fromJson<int?>(json['ie']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<String?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      cep: serializer.fromJson<String?>(json['cep']),
      uf: serializer.fromJson<String?>(json['uf']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'cnpj': serializer.toJson<String?>(cnpj),
      'ie': serializer.toJson<int?>(ie),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<String?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'cep': serializer.toJson<String?>(cep),
      'uf': serializer.toJson<String?>(uf),
      'telefone': serializer.toJson<String?>(telefone),
      'email': serializer.toJson<String?>(email),
    };
  }

  MdfeEmitente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> fantasia = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<int?> ie = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> telefone = const Value.absent(),
          Value<String?> email = const Value.absent()}) =>
      MdfeEmitente(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        nome: nome.present ? nome.value : this.nome,
        fantasia: fantasia.present ? fantasia.value : this.fantasia,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        ie: ie.present ? ie.value : this.ie,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
        cep: cep.present ? cep.value : this.cep,
        uf: uf.present ? uf.value : this.uf,
        telefone: telefone.present ? telefone.value : this.telefone,
        email: email.present ? email.value : this.email,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeEmitente(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('cep: $cep, ')
          ..write('uf: $uf, ')
          ..write('telefone: $telefone, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idMdfeCabecalho,
      nome,
      fantasia,
      cnpj,
      ie,
      logradouro,
      numero,
      complemento,
      bairro,
      codigoMunicipio,
      nomeMunicipio,
      cep,
      uf,
      telefone,
      email);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeEmitente &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.cnpj == this.cnpj &&
          other.ie == this.ie &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.cep == this.cep &&
          other.uf == this.uf &&
          other.telefone == this.telefone &&
          other.email == this.email);
}

class MdfeEmitentesCompanion extends UpdateCompanion<MdfeEmitente> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> cnpj;
  final Value<int?> ie;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> cep;
  final Value<String?> uf;
  final Value<String?> telefone;
  final Value<String?> email;
  const MdfeEmitentesCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.cep = const Value.absent(),
    this.uf = const Value.absent(),
    this.telefone = const Value.absent(),
    this.email = const Value.absent(),
  });
  MdfeEmitentesCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.cep = const Value.absent(),
    this.uf = const Value.absent(),
    this.telefone = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<MdfeEmitente> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? cnpj,
    Expression<int>? ie,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? cep,
    Expression<String>? uf,
    Expression<String>? telefone,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (cnpj != null) 'cnpj': cnpj,
      if (ie != null) 'ie': ie,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (cep != null) 'cep': cep,
      if (uf != null) 'uf': uf,
      if (telefone != null) 'telefone': telefone,
      if (email != null) 'email': email,
    });
  }

  MdfeEmitentesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? nome,
      Value<String?>? fantasia,
      Value<String?>? cnpj,
      Value<int?>? ie,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? codigoMunicipio,
      Value<String?>? nomeMunicipio,
      Value<String?>? cep,
      Value<String?>? uf,
      Value<String?>? telefone,
      Value<String?>? email}) {
    return MdfeEmitentesCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      cnpj: cnpj ?? this.cnpj,
      ie: ie ?? this.ie,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      cep: cep ?? this.cep,
      uf: uf ?? this.uf,
      telefone: telefone ?? this.telefone,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (ie.present) {
      map['ie'] = Variable<int>(ie.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeEmitentesCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('cep: $cep, ')
          ..write('uf: $uf, ')
          ..write('telefone: $telefone, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $MdfePercursosTable extends MdfePercursos
    with TableInfo<$MdfePercursosTable, MdfePercurso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfePercursosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufPercursoMeta =
      const VerificationMeta('ufPercurso');
  @override
  late final GeneratedColumn<String> ufPercurso = GeneratedColumn<String>(
      'uf_percurso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInicioViagemMeta =
      const VerificationMeta('dataInicioViagem');
  @override
  late final GeneratedColumn<DateTime> dataInicioViagem =
      GeneratedColumn<DateTime>('data_inicio_viagem', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idMdfeCabecalho, ufPercurso, dataInicioViagem];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_percurso';
  @override
  VerificationContext validateIntegrity(Insertable<MdfePercurso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('uf_percurso')) {
      context.handle(
          _ufPercursoMeta,
          ufPercurso.isAcceptableOrUnknown(
              data['uf_percurso']!, _ufPercursoMeta));
    }
    if (data.containsKey('data_inicio_viagem')) {
      context.handle(
          _dataInicioViagemMeta,
          dataInicioViagem.isAcceptableOrUnknown(
              data['data_inicio_viagem']!, _dataInicioViagemMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfePercurso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfePercurso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      ufPercurso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_percurso']),
      dataInicioViagem: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_inicio_viagem']),
    );
  }

  @override
  $MdfePercursosTable createAlias(String alias) {
    return $MdfePercursosTable(attachedDatabase, alias);
  }
}

class MdfePercurso extends DataClass implements Insertable<MdfePercurso> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? ufPercurso;
  final DateTime? dataInicioViagem;
  const MdfePercurso(
      {this.id, this.idMdfeCabecalho, this.ufPercurso, this.dataInicioViagem});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || ufPercurso != null) {
      map['uf_percurso'] = Variable<String>(ufPercurso);
    }
    if (!nullToAbsent || dataInicioViagem != null) {
      map['data_inicio_viagem'] = Variable<DateTime>(dataInicioViagem);
    }
    return map;
  }

  factory MdfePercurso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfePercurso(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      ufPercurso: serializer.fromJson<String?>(json['ufPercurso']),
      dataInicioViagem:
          serializer.fromJson<DateTime?>(json['dataInicioViagem']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'ufPercurso': serializer.toJson<String?>(ufPercurso),
      'dataInicioViagem': serializer.toJson<DateTime?>(dataInicioViagem),
    };
  }

  MdfePercurso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> ufPercurso = const Value.absent(),
          Value<DateTime?> dataInicioViagem = const Value.absent()}) =>
      MdfePercurso(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        ufPercurso: ufPercurso.present ? ufPercurso.value : this.ufPercurso,
        dataInicioViagem: dataInicioViagem.present
            ? dataInicioViagem.value
            : this.dataInicioViagem,
      );
  @override
  String toString() {
    return (StringBuffer('MdfePercurso(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('ufPercurso: $ufPercurso, ')
          ..write('dataInicioViagem: $dataInicioViagem')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idMdfeCabecalho, ufPercurso, dataInicioViagem);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfePercurso &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.ufPercurso == this.ufPercurso &&
          other.dataInicioViagem == this.dataInicioViagem);
}

class MdfePercursosCompanion extends UpdateCompanion<MdfePercurso> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> ufPercurso;
  final Value<DateTime?> dataInicioViagem;
  const MdfePercursosCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.ufPercurso = const Value.absent(),
    this.dataInicioViagem = const Value.absent(),
  });
  MdfePercursosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.ufPercurso = const Value.absent(),
    this.dataInicioViagem = const Value.absent(),
  });
  static Insertable<MdfePercurso> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? ufPercurso,
    Expression<DateTime>? dataInicioViagem,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (ufPercurso != null) 'uf_percurso': ufPercurso,
      if (dataInicioViagem != null) 'data_inicio_viagem': dataInicioViagem,
    });
  }

  MdfePercursosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? ufPercurso,
      Value<DateTime?>? dataInicioViagem}) {
    return MdfePercursosCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      ufPercurso: ufPercurso ?? this.ufPercurso,
      dataInicioViagem: dataInicioViagem ?? this.dataInicioViagem,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (ufPercurso.present) {
      map['uf_percurso'] = Variable<String>(ufPercurso.value);
    }
    if (dataInicioViagem.present) {
      map['data_inicio_viagem'] = Variable<DateTime>(dataInicioViagem.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfePercursosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('ufPercurso: $ufPercurso, ')
          ..write('dataInicioViagem: $dataInicioViagem')
          ..write(')'))
        .toString();
  }
}

class $MdfeMunicipioCarregamentosTable extends MdfeMunicipioCarregamentos
    with
        TableInfo<$MdfeMunicipioCarregamentosTable, MdfeMunicipioCarregamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeMunicipioCarregamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<String> codigoMunicipio = GeneratedColumn<String>(
      'codigo_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMunicipioMeta =
      const VerificationMeta('nomeMunicipio');
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
      'nome_municipio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idMdfeCabecalho, codigoMunicipio, nomeMunicipio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_municipio_carregamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeMunicipioCarregamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
          _nomeMunicipioMeta,
          nomeMunicipio.isAcceptableOrUnknown(
              data['nome_municipio']!, _nomeMunicipioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeMunicipioCarregamento map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeMunicipioCarregamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      codigoMunicipio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_municipio']),
      nomeMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_municipio']),
    );
  }

  @override
  $MdfeMunicipioCarregamentosTable createAlias(String alias) {
    return $MdfeMunicipioCarregamentosTable(attachedDatabase, alias);
  }
}

class MdfeMunicipioCarregamento extends DataClass
    implements Insertable<MdfeMunicipioCarregamento> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? codigoMunicipio;
  final String? nomeMunicipio;
  const MdfeMunicipioCarregamento(
      {this.id,
      this.idMdfeCabecalho,
      this.codigoMunicipio,
      this.nomeMunicipio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    return map;
  }

  factory MdfeMunicipioCarregamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeMunicipioCarregamento(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      codigoMunicipio: serializer.fromJson<String?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'codigoMunicipio': serializer.toJson<String?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
    };
  }

  MdfeMunicipioCarregamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> codigoMunicipio = const Value.absent(),
          Value<String?> nomeMunicipio = const Value.absent()}) =>
      MdfeMunicipioCarregamento(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        nomeMunicipio:
            nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeMunicipioCarregamento(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idMdfeCabecalho, codigoMunicipio, nomeMunicipio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeMunicipioCarregamento &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio);
}

class MdfeMunicipioCarregamentosCompanion
    extends UpdateCompanion<MdfeMunicipioCarregamento> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  const MdfeMunicipioCarregamentosCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
  });
  MdfeMunicipioCarregamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
  });
  static Insertable<MdfeMunicipioCarregamento> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
    });
  }

  MdfeMunicipioCarregamentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? codigoMunicipio,
      Value<String?>? nomeMunicipio}) {
    return MdfeMunicipioCarregamentosCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<String>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeMunicipioCarregamentosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio')
          ..write(')'))
        .toString();
  }
}

class $MdfeRodoviariosTable extends MdfeRodoviarios
    with TableInfo<$MdfeRodoviariosTable, MdfeRodoviario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeRodoviariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _rntrcMeta = const VerificationMeta('rntrc');
  @override
  late final GeneratedColumn<String> rntrc = GeneratedColumn<String>(
      'rntrc', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoAgendamentoMeta =
      const VerificationMeta('codigoAgendamento');
  @override
  late final GeneratedColumn<String> codigoAgendamento =
      GeneratedColumn<String>('codigo_agendamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 16),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idMdfeCabecalho, rntrc, codigoAgendamento];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_rodoviario';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeRodoviario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('rntrc')) {
      context.handle(
          _rntrcMeta, rntrc.isAcceptableOrUnknown(data['rntrc']!, _rntrcMeta));
    }
    if (data.containsKey('codigo_agendamento')) {
      context.handle(
          _codigoAgendamentoMeta,
          codigoAgendamento.isAcceptableOrUnknown(
              data['codigo_agendamento']!, _codigoAgendamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeRodoviario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeRodoviario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      rntrc: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rntrc']),
      codigoAgendamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_agendamento']),
    );
  }

  @override
  $MdfeRodoviariosTable createAlias(String alias) {
    return $MdfeRodoviariosTable(attachedDatabase, alias);
  }
}

class MdfeRodoviario extends DataClass implements Insertable<MdfeRodoviario> {
  final int? id;
  final int? idMdfeCabecalho;
  final String? rntrc;
  final String? codigoAgendamento;
  const MdfeRodoviario(
      {this.id, this.idMdfeCabecalho, this.rntrc, this.codigoAgendamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || rntrc != null) {
      map['rntrc'] = Variable<String>(rntrc);
    }
    if (!nullToAbsent || codigoAgendamento != null) {
      map['codigo_agendamento'] = Variable<String>(codigoAgendamento);
    }
    return map;
  }

  factory MdfeRodoviario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeRodoviario(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      rntrc: serializer.fromJson<String?>(json['rntrc']),
      codigoAgendamento:
          serializer.fromJson<String?>(json['codigoAgendamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'rntrc': serializer.toJson<String?>(rntrc),
      'codigoAgendamento': serializer.toJson<String?>(codigoAgendamento),
    };
  }

  MdfeRodoviario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<String?> rntrc = const Value.absent(),
          Value<String?> codigoAgendamento = const Value.absent()}) =>
      MdfeRodoviario(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        rntrc: rntrc.present ? rntrc.value : this.rntrc,
        codigoAgendamento: codigoAgendamento.present
            ? codigoAgendamento.value
            : this.codigoAgendamento,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeRodoviario(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('rntrc: $rntrc, ')
          ..write('codigoAgendamento: $codigoAgendamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idMdfeCabecalho, rntrc, codigoAgendamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeRodoviario &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.rntrc == this.rntrc &&
          other.codigoAgendamento == this.codigoAgendamento);
}

class MdfeRodoviariosCompanion extends UpdateCompanion<MdfeRodoviario> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<String?> rntrc;
  final Value<String?> codigoAgendamento;
  const MdfeRodoviariosCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.rntrc = const Value.absent(),
    this.codigoAgendamento = const Value.absent(),
  });
  MdfeRodoviariosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.rntrc = const Value.absent(),
    this.codigoAgendamento = const Value.absent(),
  });
  static Insertable<MdfeRodoviario> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<String>? rntrc,
    Expression<String>? codigoAgendamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (rntrc != null) 'rntrc': rntrc,
      if (codigoAgendamento != null) 'codigo_agendamento': codigoAgendamento,
    });
  }

  MdfeRodoviariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<String?>? rntrc,
      Value<String?>? codigoAgendamento}) {
    return MdfeRodoviariosCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      rntrc: rntrc ?? this.rntrc,
      codigoAgendamento: codigoAgendamento ?? this.codigoAgendamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (rntrc.present) {
      map['rntrc'] = Variable<String>(rntrc.value);
    }
    if (codigoAgendamento.present) {
      map['codigo_agendamento'] = Variable<String>(codigoAgendamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeRodoviariosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('rntrc: $rntrc, ')
          ..write('codigoAgendamento: $codigoAgendamento')
          ..write(')'))
        .toString();
  }
}

class $MdfeInformacaoSegurosTable extends MdfeInformacaoSeguros
    with TableInfo<$MdfeInformacaoSegurosTable, MdfeInformacaoSeguro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeInformacaoSegurosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeCabecalhoMeta =
      const VerificationMeta('idMdfeCabecalho');
  @override
  late final GeneratedColumn<int> idMdfeCabecalho = GeneratedColumn<int>(
      'id_mdfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _responsavelMeta =
      const VerificationMeta('responsavel');
  @override
  late final GeneratedColumn<int> responsavel = GeneratedColumn<int>(
      'responsavel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjCpfMeta =
      const VerificationMeta('cnpjCpf');
  @override
  late final GeneratedColumn<String> cnpjCpf = GeneratedColumn<String>(
      'cnpj_cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _seguradoraMeta =
      const VerificationMeta('seguradora');
  @override
  late final GeneratedColumn<String> seguradora = GeneratedColumn<String>(
      'seguradora', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjSeguradoraMeta =
      const VerificationMeta('cnpjSeguradora');
  @override
  late final GeneratedColumn<String> cnpjSeguradora = GeneratedColumn<String>(
      'cnpj_seguradora', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _apoliceMeta =
      const VerificationMeta('apolice');
  @override
  late final GeneratedColumn<String> apolice = GeneratedColumn<String>(
      'apolice', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _averbacaoMeta =
      const VerificationMeta('averbacao');
  @override
  late final GeneratedColumn<String> averbacao = GeneratedColumn<String>(
      'averbacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 40),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeCabecalho,
        responsavel,
        cnpjCpf,
        seguradora,
        cnpjSeguradora,
        apolice,
        averbacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_informacao_seguro';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeInformacaoSeguro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_cabecalho')) {
      context.handle(
          _idMdfeCabecalhoMeta,
          idMdfeCabecalho.isAcceptableOrUnknown(
              data['id_mdfe_cabecalho']!, _idMdfeCabecalhoMeta));
    }
    if (data.containsKey('responsavel')) {
      context.handle(
          _responsavelMeta,
          responsavel.isAcceptableOrUnknown(
              data['responsavel']!, _responsavelMeta));
    }
    if (data.containsKey('cnpj_cpf')) {
      context.handle(_cnpjCpfMeta,
          cnpjCpf.isAcceptableOrUnknown(data['cnpj_cpf']!, _cnpjCpfMeta));
    }
    if (data.containsKey('seguradora')) {
      context.handle(
          _seguradoraMeta,
          seguradora.isAcceptableOrUnknown(
              data['seguradora']!, _seguradoraMeta));
    }
    if (data.containsKey('cnpj_seguradora')) {
      context.handle(
          _cnpjSeguradoraMeta,
          cnpjSeguradora.isAcceptableOrUnknown(
              data['cnpj_seguradora']!, _cnpjSeguradoraMeta));
    }
    if (data.containsKey('apolice')) {
      context.handle(_apoliceMeta,
          apolice.isAcceptableOrUnknown(data['apolice']!, _apoliceMeta));
    }
    if (data.containsKey('averbacao')) {
      context.handle(_averbacaoMeta,
          averbacao.isAcceptableOrUnknown(data['averbacao']!, _averbacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeInformacaoSeguro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeInformacaoSeguro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_cabecalho']),
      responsavel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}responsavel']),
      cnpjCpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj_cpf']),
      seguradora: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}seguradora']),
      cnpjSeguradora: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj_seguradora']),
      apolice: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}apolice']),
      averbacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}averbacao']),
    );
  }

  @override
  $MdfeInformacaoSegurosTable createAlias(String alias) {
    return $MdfeInformacaoSegurosTable(attachedDatabase, alias);
  }
}

class MdfeInformacaoSeguro extends DataClass
    implements Insertable<MdfeInformacaoSeguro> {
  final int? id;
  final int? idMdfeCabecalho;
  final int? responsavel;
  final String? cnpjCpf;
  final String? seguradora;
  final String? cnpjSeguradora;
  final String? apolice;
  final String? averbacao;
  const MdfeInformacaoSeguro(
      {this.id,
      this.idMdfeCabecalho,
      this.responsavel,
      this.cnpjCpf,
      this.seguradora,
      this.cnpjSeguradora,
      this.apolice,
      this.averbacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeCabecalho != null) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho);
    }
    if (!nullToAbsent || responsavel != null) {
      map['responsavel'] = Variable<int>(responsavel);
    }
    if (!nullToAbsent || cnpjCpf != null) {
      map['cnpj_cpf'] = Variable<String>(cnpjCpf);
    }
    if (!nullToAbsent || seguradora != null) {
      map['seguradora'] = Variable<String>(seguradora);
    }
    if (!nullToAbsent || cnpjSeguradora != null) {
      map['cnpj_seguradora'] = Variable<String>(cnpjSeguradora);
    }
    if (!nullToAbsent || apolice != null) {
      map['apolice'] = Variable<String>(apolice);
    }
    if (!nullToAbsent || averbacao != null) {
      map['averbacao'] = Variable<String>(averbacao);
    }
    return map;
  }

  factory MdfeInformacaoSeguro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeInformacaoSeguro(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeCabecalho: serializer.fromJson<int?>(json['idMdfeCabecalho']),
      responsavel: serializer.fromJson<int?>(json['responsavel']),
      cnpjCpf: serializer.fromJson<String?>(json['cnpjCpf']),
      seguradora: serializer.fromJson<String?>(json['seguradora']),
      cnpjSeguradora: serializer.fromJson<String?>(json['cnpjSeguradora']),
      apolice: serializer.fromJson<String?>(json['apolice']),
      averbacao: serializer.fromJson<String?>(json['averbacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeCabecalho': serializer.toJson<int?>(idMdfeCabecalho),
      'responsavel': serializer.toJson<int?>(responsavel),
      'cnpjCpf': serializer.toJson<String?>(cnpjCpf),
      'seguradora': serializer.toJson<String?>(seguradora),
      'cnpjSeguradora': serializer.toJson<String?>(cnpjSeguradora),
      'apolice': serializer.toJson<String?>(apolice),
      'averbacao': serializer.toJson<String?>(averbacao),
    };
  }

  MdfeInformacaoSeguro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeCabecalho = const Value.absent(),
          Value<int?> responsavel = const Value.absent(),
          Value<String?> cnpjCpf = const Value.absent(),
          Value<String?> seguradora = const Value.absent(),
          Value<String?> cnpjSeguradora = const Value.absent(),
          Value<String?> apolice = const Value.absent(),
          Value<String?> averbacao = const Value.absent()}) =>
      MdfeInformacaoSeguro(
        id: id.present ? id.value : this.id,
        idMdfeCabecalho: idMdfeCabecalho.present
            ? idMdfeCabecalho.value
            : this.idMdfeCabecalho,
        responsavel: responsavel.present ? responsavel.value : this.responsavel,
        cnpjCpf: cnpjCpf.present ? cnpjCpf.value : this.cnpjCpf,
        seguradora: seguradora.present ? seguradora.value : this.seguradora,
        cnpjSeguradora:
            cnpjSeguradora.present ? cnpjSeguradora.value : this.cnpjSeguradora,
        apolice: apolice.present ? apolice.value : this.apolice,
        averbacao: averbacao.present ? averbacao.value : this.averbacao,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoSeguro(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('responsavel: $responsavel, ')
          ..write('cnpjCpf: $cnpjCpf, ')
          ..write('seguradora: $seguradora, ')
          ..write('cnpjSeguradora: $cnpjSeguradora, ')
          ..write('apolice: $apolice, ')
          ..write('averbacao: $averbacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeCabecalho, responsavel, cnpjCpf,
      seguradora, cnpjSeguradora, apolice, averbacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeInformacaoSeguro &&
          other.id == this.id &&
          other.idMdfeCabecalho == this.idMdfeCabecalho &&
          other.responsavel == this.responsavel &&
          other.cnpjCpf == this.cnpjCpf &&
          other.seguradora == this.seguradora &&
          other.cnpjSeguradora == this.cnpjSeguradora &&
          other.apolice == this.apolice &&
          other.averbacao == this.averbacao);
}

class MdfeInformacaoSegurosCompanion
    extends UpdateCompanion<MdfeInformacaoSeguro> {
  final Value<int?> id;
  final Value<int?> idMdfeCabecalho;
  final Value<int?> responsavel;
  final Value<String?> cnpjCpf;
  final Value<String?> seguradora;
  final Value<String?> cnpjSeguradora;
  final Value<String?> apolice;
  final Value<String?> averbacao;
  const MdfeInformacaoSegurosCompanion({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.cnpjCpf = const Value.absent(),
    this.seguradora = const Value.absent(),
    this.cnpjSeguradora = const Value.absent(),
    this.apolice = const Value.absent(),
    this.averbacao = const Value.absent(),
  });
  MdfeInformacaoSegurosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeCabecalho = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.cnpjCpf = const Value.absent(),
    this.seguradora = const Value.absent(),
    this.cnpjSeguradora = const Value.absent(),
    this.apolice = const Value.absent(),
    this.averbacao = const Value.absent(),
  });
  static Insertable<MdfeInformacaoSeguro> custom({
    Expression<int>? id,
    Expression<int>? idMdfeCabecalho,
    Expression<int>? responsavel,
    Expression<String>? cnpjCpf,
    Expression<String>? seguradora,
    Expression<String>? cnpjSeguradora,
    Expression<String>? apolice,
    Expression<String>? averbacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeCabecalho != null) 'id_mdfe_cabecalho': idMdfeCabecalho,
      if (responsavel != null) 'responsavel': responsavel,
      if (cnpjCpf != null) 'cnpj_cpf': cnpjCpf,
      if (seguradora != null) 'seguradora': seguradora,
      if (cnpjSeguradora != null) 'cnpj_seguradora': cnpjSeguradora,
      if (apolice != null) 'apolice': apolice,
      if (averbacao != null) 'averbacao': averbacao,
    });
  }

  MdfeInformacaoSegurosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeCabecalho,
      Value<int?>? responsavel,
      Value<String?>? cnpjCpf,
      Value<String?>? seguradora,
      Value<String?>? cnpjSeguradora,
      Value<String?>? apolice,
      Value<String?>? averbacao}) {
    return MdfeInformacaoSegurosCompanion(
      id: id ?? this.id,
      idMdfeCabecalho: idMdfeCabecalho ?? this.idMdfeCabecalho,
      responsavel: responsavel ?? this.responsavel,
      cnpjCpf: cnpjCpf ?? this.cnpjCpf,
      seguradora: seguradora ?? this.seguradora,
      cnpjSeguradora: cnpjSeguradora ?? this.cnpjSeguradora,
      apolice: apolice ?? this.apolice,
      averbacao: averbacao ?? this.averbacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeCabecalho.present) {
      map['id_mdfe_cabecalho'] = Variable<int>(idMdfeCabecalho.value);
    }
    if (responsavel.present) {
      map['responsavel'] = Variable<int>(responsavel.value);
    }
    if (cnpjCpf.present) {
      map['cnpj_cpf'] = Variable<String>(cnpjCpf.value);
    }
    if (seguradora.present) {
      map['seguradora'] = Variable<String>(seguradora.value);
    }
    if (cnpjSeguradora.present) {
      map['cnpj_seguradora'] = Variable<String>(cnpjSeguradora.value);
    }
    if (apolice.present) {
      map['apolice'] = Variable<String>(apolice.value);
    }
    if (averbacao.present) {
      map['averbacao'] = Variable<String>(averbacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoSegurosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeCabecalho: $idMdfeCabecalho, ')
          ..write('responsavel: $responsavel, ')
          ..write('cnpjCpf: $cnpjCpf, ')
          ..write('seguradora: $seguradora, ')
          ..write('cnpjSeguradora: $cnpjSeguradora, ')
          ..write('apolice: $apolice, ')
          ..write('averbacao: $averbacao')
          ..write(')'))
        .toString();
  }
}

class $MdfeCabecalhosTable extends MdfeCabecalhos
    with TableInfo<$MdfeCabecalhosTable, MdfeCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoAmbienteMeta =
      const VerificationMeta('tipoAmbiente');
  @override
  late final GeneratedColumn<String> tipoAmbiente = GeneratedColumn<String>(
      'tipo_ambiente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoEmitenteMeta =
      const VerificationMeta('tipoEmitente');
  @override
  late final GeneratedColumn<String> tipoEmitente = GeneratedColumn<String>(
      'tipo_emitente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoTransportadoraMeta =
      const VerificationMeta('tipoTransportadora');
  @override
  late final GeneratedColumn<String> tipoTransportadora =
      GeneratedColumn<String>('tipo_transportadora', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 3),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _modeloMeta = const VerificationMeta('modelo');
  @override
  late final GeneratedColumn<String> modelo = GeneratedColumn<String>(
      'modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMdfeMeta =
      const VerificationMeta('numeroMdfe');
  @override
  late final GeneratedColumn<String> numeroMdfe = GeneratedColumn<String>(
      'numero_mdfe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 9),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoNumericoMeta =
      const VerificationMeta('codigoNumerico');
  @override
  late final GeneratedColumn<String> codigoNumerico = GeneratedColumn<String>(
      'codigo_numerico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _chaveAcessoMeta =
      const VerificationMeta('chaveAcesso');
  @override
  late final GeneratedColumn<String> chaveAcesso = GeneratedColumn<String>(
      'chave_acesso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoVerificadorMeta =
      const VerificationMeta('digitoVerificador');
  @override
  late final GeneratedColumn<int> digitoVerificador = GeneratedColumn<int>(
      'digito_verificador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _modalMeta = const VerificationMeta('modal');
  @override
  late final GeneratedColumn<String> modal = GeneratedColumn<String>(
      'modal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataHoraEmissaoMeta =
      const VerificationMeta('dataHoraEmissao');
  @override
  late final GeneratedColumn<DateTime> dataHoraEmissao =
      GeneratedColumn<DateTime>('data_hora_emissao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoEmissaoMeta =
      const VerificationMeta('tipoEmissao');
  @override
  late final GeneratedColumn<String> tipoEmissao = GeneratedColumn<String>(
      'tipo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _processoEmissaoMeta =
      const VerificationMeta('processoEmissao');
  @override
  late final GeneratedColumn<String> processoEmissao = GeneratedColumn<String>(
      'processo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _versaoProcessoEmissaoMeta =
      const VerificationMeta('versaoProcessoEmissao');
  @override
  late final GeneratedColumn<String> versaoProcessoEmissao =
      GeneratedColumn<String>('versao_processo_emissao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ufInicioMeta =
      const VerificationMeta('ufInicio');
  @override
  late final GeneratedColumn<String> ufInicio = GeneratedColumn<String>(
      'uf_inicio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufFimMeta = const VerificationMeta('ufFim');
  @override
  late final GeneratedColumn<String> ufFim = GeneratedColumn<String>(
      'uf_fim', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataHoraPrevisaoViagemMeta =
      const VerificationMeta('dataHoraPrevisaoViagem');
  @override
  late final GeneratedColumn<DateTime> dataHoraPrevisaoViagem =
      GeneratedColumn<DateTime>('data_hora_previsao_viagem', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeTotalCteMeta =
      const VerificationMeta('quantidadeTotalCte');
  @override
  late final GeneratedColumn<int> quantidadeTotalCte = GeneratedColumn<int>(
      'quantidade_total_cte', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeTotalNfeMeta =
      const VerificationMeta('quantidadeTotalNfe');
  @override
  late final GeneratedColumn<int> quantidadeTotalNfe = GeneratedColumn<int>(
      'quantidade_total_nfe', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeTotalMdfeMeta =
      const VerificationMeta('quantidadeTotalMdfe');
  @override
  late final GeneratedColumn<int> quantidadeTotalMdfe = GeneratedColumn<int>(
      'quantidade_total_mdfe', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoUnidadeMedidaMeta =
      const VerificationMeta('codigoUnidadeMedida');
  @override
  late final GeneratedColumn<String> codigoUnidadeMedida =
      GeneratedColumn<String>('codigo_unidade_medida', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pesoBrutoCargaMeta =
      const VerificationMeta('pesoBrutoCarga');
  @override
  late final GeneratedColumn<double> pesoBrutoCarga = GeneratedColumn<double>(
      'peso_bruto_carga', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCargaMeta =
      const VerificationMeta('valorCarga');
  @override
  late final GeneratedColumn<double> valorCarga = GeneratedColumn<double>(
      'valor_carga', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _numeroProtocoloMeta =
      const VerificationMeta('numeroProtocolo');
  @override
  late final GeneratedColumn<String> numeroProtocolo = GeneratedColumn<String>(
      'numero_protocolo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        uf,
        tipoAmbiente,
        tipoEmitente,
        tipoTransportadora,
        modelo,
        serie,
        numeroMdfe,
        codigoNumerico,
        chaveAcesso,
        digitoVerificador,
        modal,
        dataHoraEmissao,
        tipoEmissao,
        processoEmissao,
        versaoProcessoEmissao,
        ufInicio,
        ufFim,
        dataHoraPrevisaoViagem,
        quantidadeTotalCte,
        quantidadeTotalNfe,
        quantidadeTotalMdfe,
        codigoUnidadeMedida,
        pesoBrutoCarga,
        valorCarga,
        numeroProtocolo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('tipo_ambiente')) {
      context.handle(
          _tipoAmbienteMeta,
          tipoAmbiente.isAcceptableOrUnknown(
              data['tipo_ambiente']!, _tipoAmbienteMeta));
    }
    if (data.containsKey('tipo_emitente')) {
      context.handle(
          _tipoEmitenteMeta,
          tipoEmitente.isAcceptableOrUnknown(
              data['tipo_emitente']!, _tipoEmitenteMeta));
    }
    if (data.containsKey('tipo_transportadora')) {
      context.handle(
          _tipoTransportadoraMeta,
          tipoTransportadora.isAcceptableOrUnknown(
              data['tipo_transportadora']!, _tipoTransportadoraMeta));
    }
    if (data.containsKey('modelo')) {
      context.handle(_modeloMeta,
          modelo.isAcceptableOrUnknown(data['modelo']!, _modeloMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('numero_mdfe')) {
      context.handle(
          _numeroMdfeMeta,
          numeroMdfe.isAcceptableOrUnknown(
              data['numero_mdfe']!, _numeroMdfeMeta));
    }
    if (data.containsKey('codigo_numerico')) {
      context.handle(
          _codigoNumericoMeta,
          codigoNumerico.isAcceptableOrUnknown(
              data['codigo_numerico']!, _codigoNumericoMeta));
    }
    if (data.containsKey('chave_acesso')) {
      context.handle(
          _chaveAcessoMeta,
          chaveAcesso.isAcceptableOrUnknown(
              data['chave_acesso']!, _chaveAcessoMeta));
    }
    if (data.containsKey('digito_verificador')) {
      context.handle(
          _digitoVerificadorMeta,
          digitoVerificador.isAcceptableOrUnknown(
              data['digito_verificador']!, _digitoVerificadorMeta));
    }
    if (data.containsKey('modal')) {
      context.handle(
          _modalMeta, modal.isAcceptableOrUnknown(data['modal']!, _modalMeta));
    }
    if (data.containsKey('data_hora_emissao')) {
      context.handle(
          _dataHoraEmissaoMeta,
          dataHoraEmissao.isAcceptableOrUnknown(
              data['data_hora_emissao']!, _dataHoraEmissaoMeta));
    }
    if (data.containsKey('tipo_emissao')) {
      context.handle(
          _tipoEmissaoMeta,
          tipoEmissao.isAcceptableOrUnknown(
              data['tipo_emissao']!, _tipoEmissaoMeta));
    }
    if (data.containsKey('processo_emissao')) {
      context.handle(
          _processoEmissaoMeta,
          processoEmissao.isAcceptableOrUnknown(
              data['processo_emissao']!, _processoEmissaoMeta));
    }
    if (data.containsKey('versao_processo_emissao')) {
      context.handle(
          _versaoProcessoEmissaoMeta,
          versaoProcessoEmissao.isAcceptableOrUnknown(
              data['versao_processo_emissao']!, _versaoProcessoEmissaoMeta));
    }
    if (data.containsKey('uf_inicio')) {
      context.handle(_ufInicioMeta,
          ufInicio.isAcceptableOrUnknown(data['uf_inicio']!, _ufInicioMeta));
    }
    if (data.containsKey('uf_fim')) {
      context.handle(
          _ufFimMeta, ufFim.isAcceptableOrUnknown(data['uf_fim']!, _ufFimMeta));
    }
    if (data.containsKey('data_hora_previsao_viagem')) {
      context.handle(
          _dataHoraPrevisaoViagemMeta,
          dataHoraPrevisaoViagem.isAcceptableOrUnknown(
              data['data_hora_previsao_viagem']!, _dataHoraPrevisaoViagemMeta));
    }
    if (data.containsKey('quantidade_total_cte')) {
      context.handle(
          _quantidadeTotalCteMeta,
          quantidadeTotalCte.isAcceptableOrUnknown(
              data['quantidade_total_cte']!, _quantidadeTotalCteMeta));
    }
    if (data.containsKey('quantidade_total_nfe')) {
      context.handle(
          _quantidadeTotalNfeMeta,
          quantidadeTotalNfe.isAcceptableOrUnknown(
              data['quantidade_total_nfe']!, _quantidadeTotalNfeMeta));
    }
    if (data.containsKey('quantidade_total_mdfe')) {
      context.handle(
          _quantidadeTotalMdfeMeta,
          quantidadeTotalMdfe.isAcceptableOrUnknown(
              data['quantidade_total_mdfe']!, _quantidadeTotalMdfeMeta));
    }
    if (data.containsKey('codigo_unidade_medida')) {
      context.handle(
          _codigoUnidadeMedidaMeta,
          codigoUnidadeMedida.isAcceptableOrUnknown(
              data['codigo_unidade_medida']!, _codigoUnidadeMedidaMeta));
    }
    if (data.containsKey('peso_bruto_carga')) {
      context.handle(
          _pesoBrutoCargaMeta,
          pesoBrutoCarga.isAcceptableOrUnknown(
              data['peso_bruto_carga']!, _pesoBrutoCargaMeta));
    }
    if (data.containsKey('valor_carga')) {
      context.handle(
          _valorCargaMeta,
          valorCarga.isAcceptableOrUnknown(
              data['valor_carga']!, _valorCargaMeta));
    }
    if (data.containsKey('numero_protocolo')) {
      context.handle(
          _numeroProtocoloMeta,
          numeroProtocolo.isAcceptableOrUnknown(
              data['numero_protocolo']!, _numeroProtocoloMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      tipoAmbiente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_ambiente']),
      tipoEmitente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_emitente']),
      tipoTransportadora: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}tipo_transportadora']),
      modelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modelo']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      numeroMdfe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_mdfe']),
      codigoNumerico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_numerico']),
      chaveAcesso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_acesso']),
      digitoVerificador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}digito_verificador']),
      modal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modal']),
      dataHoraEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_hora_emissao']),
      tipoEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_emissao']),
      processoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}processo_emissao']),
      versaoProcessoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}versao_processo_emissao']),
      ufInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_inicio']),
      ufFim: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_fim']),
      dataHoraPrevisaoViagem: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_hora_previsao_viagem']),
      quantidadeTotalCte: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_total_cte']),
      quantidadeTotalNfe: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_total_nfe']),
      quantidadeTotalMdfe: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_total_mdfe']),
      codigoUnidadeMedida: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_unidade_medida']),
      pesoBrutoCarga: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}peso_bruto_carga']),
      valorCarga: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_carga']),
      numeroProtocolo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numero_protocolo']),
    );
  }

  @override
  $MdfeCabecalhosTable createAlias(String alias) {
    return $MdfeCabecalhosTable(attachedDatabase, alias);
  }
}

class MdfeCabecalho extends DataClass implements Insertable<MdfeCabecalho> {
  final int? id;
  final String? uf;
  final String? tipoAmbiente;
  final String? tipoEmitente;
  final String? tipoTransportadora;
  final String? modelo;
  final String? serie;
  final String? numeroMdfe;
  final String? codigoNumerico;
  final String? chaveAcesso;
  final int? digitoVerificador;
  final String? modal;
  final DateTime? dataHoraEmissao;
  final String? tipoEmissao;
  final String? processoEmissao;
  final String? versaoProcessoEmissao;
  final String? ufInicio;
  final String? ufFim;
  final DateTime? dataHoraPrevisaoViagem;
  final int? quantidadeTotalCte;
  final int? quantidadeTotalNfe;
  final int? quantidadeTotalMdfe;
  final String? codigoUnidadeMedida;
  final double? pesoBrutoCarga;
  final double? valorCarga;
  final String? numeroProtocolo;
  const MdfeCabecalho(
      {this.id,
      this.uf,
      this.tipoAmbiente,
      this.tipoEmitente,
      this.tipoTransportadora,
      this.modelo,
      this.serie,
      this.numeroMdfe,
      this.codigoNumerico,
      this.chaveAcesso,
      this.digitoVerificador,
      this.modal,
      this.dataHoraEmissao,
      this.tipoEmissao,
      this.processoEmissao,
      this.versaoProcessoEmissao,
      this.ufInicio,
      this.ufFim,
      this.dataHoraPrevisaoViagem,
      this.quantidadeTotalCte,
      this.quantidadeTotalNfe,
      this.quantidadeTotalMdfe,
      this.codigoUnidadeMedida,
      this.pesoBrutoCarga,
      this.valorCarga,
      this.numeroProtocolo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || tipoAmbiente != null) {
      map['tipo_ambiente'] = Variable<String>(tipoAmbiente);
    }
    if (!nullToAbsent || tipoEmitente != null) {
      map['tipo_emitente'] = Variable<String>(tipoEmitente);
    }
    if (!nullToAbsent || tipoTransportadora != null) {
      map['tipo_transportadora'] = Variable<String>(tipoTransportadora);
    }
    if (!nullToAbsent || modelo != null) {
      map['modelo'] = Variable<String>(modelo);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numeroMdfe != null) {
      map['numero_mdfe'] = Variable<String>(numeroMdfe);
    }
    if (!nullToAbsent || codigoNumerico != null) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico);
    }
    if (!nullToAbsent || chaveAcesso != null) {
      map['chave_acesso'] = Variable<String>(chaveAcesso);
    }
    if (!nullToAbsent || digitoVerificador != null) {
      map['digito_verificador'] = Variable<int>(digitoVerificador);
    }
    if (!nullToAbsent || modal != null) {
      map['modal'] = Variable<String>(modal);
    }
    if (!nullToAbsent || dataHoraEmissao != null) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao);
    }
    if (!nullToAbsent || tipoEmissao != null) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao);
    }
    if (!nullToAbsent || processoEmissao != null) {
      map['processo_emissao'] = Variable<String>(processoEmissao);
    }
    if (!nullToAbsent || versaoProcessoEmissao != null) {
      map['versao_processo_emissao'] = Variable<String>(versaoProcessoEmissao);
    }
    if (!nullToAbsent || ufInicio != null) {
      map['uf_inicio'] = Variable<String>(ufInicio);
    }
    if (!nullToAbsent || ufFim != null) {
      map['uf_fim'] = Variable<String>(ufFim);
    }
    if (!nullToAbsent || dataHoraPrevisaoViagem != null) {
      map['data_hora_previsao_viagem'] =
          Variable<DateTime>(dataHoraPrevisaoViagem);
    }
    if (!nullToAbsent || quantidadeTotalCte != null) {
      map['quantidade_total_cte'] = Variable<int>(quantidadeTotalCte);
    }
    if (!nullToAbsent || quantidadeTotalNfe != null) {
      map['quantidade_total_nfe'] = Variable<int>(quantidadeTotalNfe);
    }
    if (!nullToAbsent || quantidadeTotalMdfe != null) {
      map['quantidade_total_mdfe'] = Variable<int>(quantidadeTotalMdfe);
    }
    if (!nullToAbsent || codigoUnidadeMedida != null) {
      map['codigo_unidade_medida'] = Variable<String>(codigoUnidadeMedida);
    }
    if (!nullToAbsent || pesoBrutoCarga != null) {
      map['peso_bruto_carga'] = Variable<double>(pesoBrutoCarga);
    }
    if (!nullToAbsent || valorCarga != null) {
      map['valor_carga'] = Variable<double>(valorCarga);
    }
    if (!nullToAbsent || numeroProtocolo != null) {
      map['numero_protocolo'] = Variable<String>(numeroProtocolo);
    }
    return map;
  }

  factory MdfeCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      uf: serializer.fromJson<String?>(json['uf']),
      tipoAmbiente: serializer.fromJson<String?>(json['tipoAmbiente']),
      tipoEmitente: serializer.fromJson<String?>(json['tipoEmitente']),
      tipoTransportadora:
          serializer.fromJson<String?>(json['tipoTransportadora']),
      modelo: serializer.fromJson<String?>(json['modelo']),
      serie: serializer.fromJson<String?>(json['serie']),
      numeroMdfe: serializer.fromJson<String?>(json['numeroMdfe']),
      codigoNumerico: serializer.fromJson<String?>(json['codigoNumerico']),
      chaveAcesso: serializer.fromJson<String?>(json['chaveAcesso']),
      digitoVerificador: serializer.fromJson<int?>(json['digitoVerificador']),
      modal: serializer.fromJson<String?>(json['modal']),
      dataHoraEmissao: serializer.fromJson<DateTime?>(json['dataHoraEmissao']),
      tipoEmissao: serializer.fromJson<String?>(json['tipoEmissao']),
      processoEmissao: serializer.fromJson<String?>(json['processoEmissao']),
      versaoProcessoEmissao:
          serializer.fromJson<String?>(json['versaoProcessoEmissao']),
      ufInicio: serializer.fromJson<String?>(json['ufInicio']),
      ufFim: serializer.fromJson<String?>(json['ufFim']),
      dataHoraPrevisaoViagem:
          serializer.fromJson<DateTime?>(json['dataHoraPrevisaoViagem']),
      quantidadeTotalCte: serializer.fromJson<int?>(json['quantidadeTotalCte']),
      quantidadeTotalNfe: serializer.fromJson<int?>(json['quantidadeTotalNfe']),
      quantidadeTotalMdfe:
          serializer.fromJson<int?>(json['quantidadeTotalMdfe']),
      codigoUnidadeMedida:
          serializer.fromJson<String?>(json['codigoUnidadeMedida']),
      pesoBrutoCarga: serializer.fromJson<double?>(json['pesoBrutoCarga']),
      valorCarga: serializer.fromJson<double?>(json['valorCarga']),
      numeroProtocolo: serializer.fromJson<String?>(json['numeroProtocolo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'uf': serializer.toJson<String?>(uf),
      'tipoAmbiente': serializer.toJson<String?>(tipoAmbiente),
      'tipoEmitente': serializer.toJson<String?>(tipoEmitente),
      'tipoTransportadora': serializer.toJson<String?>(tipoTransportadora),
      'modelo': serializer.toJson<String?>(modelo),
      'serie': serializer.toJson<String?>(serie),
      'numeroMdfe': serializer.toJson<String?>(numeroMdfe),
      'codigoNumerico': serializer.toJson<String?>(codigoNumerico),
      'chaveAcesso': serializer.toJson<String?>(chaveAcesso),
      'digitoVerificador': serializer.toJson<int?>(digitoVerificador),
      'modal': serializer.toJson<String?>(modal),
      'dataHoraEmissao': serializer.toJson<DateTime?>(dataHoraEmissao),
      'tipoEmissao': serializer.toJson<String?>(tipoEmissao),
      'processoEmissao': serializer.toJson<String?>(processoEmissao),
      'versaoProcessoEmissao':
          serializer.toJson<String?>(versaoProcessoEmissao),
      'ufInicio': serializer.toJson<String?>(ufInicio),
      'ufFim': serializer.toJson<String?>(ufFim),
      'dataHoraPrevisaoViagem':
          serializer.toJson<DateTime?>(dataHoraPrevisaoViagem),
      'quantidadeTotalCte': serializer.toJson<int?>(quantidadeTotalCte),
      'quantidadeTotalNfe': serializer.toJson<int?>(quantidadeTotalNfe),
      'quantidadeTotalMdfe': serializer.toJson<int?>(quantidadeTotalMdfe),
      'codigoUnidadeMedida': serializer.toJson<String?>(codigoUnidadeMedida),
      'pesoBrutoCarga': serializer.toJson<double?>(pesoBrutoCarga),
      'valorCarga': serializer.toJson<double?>(valorCarga),
      'numeroProtocolo': serializer.toJson<String?>(numeroProtocolo),
    };
  }

  MdfeCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> tipoAmbiente = const Value.absent(),
          Value<String?> tipoEmitente = const Value.absent(),
          Value<String?> tipoTransportadora = const Value.absent(),
          Value<String?> modelo = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> numeroMdfe = const Value.absent(),
          Value<String?> codigoNumerico = const Value.absent(),
          Value<String?> chaveAcesso = const Value.absent(),
          Value<int?> digitoVerificador = const Value.absent(),
          Value<String?> modal = const Value.absent(),
          Value<DateTime?> dataHoraEmissao = const Value.absent(),
          Value<String?> tipoEmissao = const Value.absent(),
          Value<String?> processoEmissao = const Value.absent(),
          Value<String?> versaoProcessoEmissao = const Value.absent(),
          Value<String?> ufInicio = const Value.absent(),
          Value<String?> ufFim = const Value.absent(),
          Value<DateTime?> dataHoraPrevisaoViagem = const Value.absent(),
          Value<int?> quantidadeTotalCte = const Value.absent(),
          Value<int?> quantidadeTotalNfe = const Value.absent(),
          Value<int?> quantidadeTotalMdfe = const Value.absent(),
          Value<String?> codigoUnidadeMedida = const Value.absent(),
          Value<double?> pesoBrutoCarga = const Value.absent(),
          Value<double?> valorCarga = const Value.absent(),
          Value<String?> numeroProtocolo = const Value.absent()}) =>
      MdfeCabecalho(
        id: id.present ? id.value : this.id,
        uf: uf.present ? uf.value : this.uf,
        tipoAmbiente:
            tipoAmbiente.present ? tipoAmbiente.value : this.tipoAmbiente,
        tipoEmitente:
            tipoEmitente.present ? tipoEmitente.value : this.tipoEmitente,
        tipoTransportadora: tipoTransportadora.present
            ? tipoTransportadora.value
            : this.tipoTransportadora,
        modelo: modelo.present ? modelo.value : this.modelo,
        serie: serie.present ? serie.value : this.serie,
        numeroMdfe: numeroMdfe.present ? numeroMdfe.value : this.numeroMdfe,
        codigoNumerico:
            codigoNumerico.present ? codigoNumerico.value : this.codigoNumerico,
        chaveAcesso: chaveAcesso.present ? chaveAcesso.value : this.chaveAcesso,
        digitoVerificador: digitoVerificador.present
            ? digitoVerificador.value
            : this.digitoVerificador,
        modal: modal.present ? modal.value : this.modal,
        dataHoraEmissao: dataHoraEmissao.present
            ? dataHoraEmissao.value
            : this.dataHoraEmissao,
        tipoEmissao: tipoEmissao.present ? tipoEmissao.value : this.tipoEmissao,
        processoEmissao: processoEmissao.present
            ? processoEmissao.value
            : this.processoEmissao,
        versaoProcessoEmissao: versaoProcessoEmissao.present
            ? versaoProcessoEmissao.value
            : this.versaoProcessoEmissao,
        ufInicio: ufInicio.present ? ufInicio.value : this.ufInicio,
        ufFim: ufFim.present ? ufFim.value : this.ufFim,
        dataHoraPrevisaoViagem: dataHoraPrevisaoViagem.present
            ? dataHoraPrevisaoViagem.value
            : this.dataHoraPrevisaoViagem,
        quantidadeTotalCte: quantidadeTotalCte.present
            ? quantidadeTotalCte.value
            : this.quantidadeTotalCte,
        quantidadeTotalNfe: quantidadeTotalNfe.present
            ? quantidadeTotalNfe.value
            : this.quantidadeTotalNfe,
        quantidadeTotalMdfe: quantidadeTotalMdfe.present
            ? quantidadeTotalMdfe.value
            : this.quantidadeTotalMdfe,
        codigoUnidadeMedida: codigoUnidadeMedida.present
            ? codigoUnidadeMedida.value
            : this.codigoUnidadeMedida,
        pesoBrutoCarga:
            pesoBrutoCarga.present ? pesoBrutoCarga.value : this.pesoBrutoCarga,
        valorCarga: valorCarga.present ? valorCarga.value : this.valorCarga,
        numeroProtocolo: numeroProtocolo.present
            ? numeroProtocolo.value
            : this.numeroProtocolo,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeCabecalho(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('tipoAmbiente: $tipoAmbiente, ')
          ..write('tipoEmitente: $tipoEmitente, ')
          ..write('tipoTransportadora: $tipoTransportadora, ')
          ..write('modelo: $modelo, ')
          ..write('serie: $serie, ')
          ..write('numeroMdfe: $numeroMdfe, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoVerificador: $digitoVerificador, ')
          ..write('modal: $modal, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('ufInicio: $ufInicio, ')
          ..write('ufFim: $ufFim, ')
          ..write('dataHoraPrevisaoViagem: $dataHoraPrevisaoViagem, ')
          ..write('quantidadeTotalCte: $quantidadeTotalCte, ')
          ..write('quantidadeTotalNfe: $quantidadeTotalNfe, ')
          ..write('quantidadeTotalMdfe: $quantidadeTotalMdfe, ')
          ..write('codigoUnidadeMedida: $codigoUnidadeMedida, ')
          ..write('pesoBrutoCarga: $pesoBrutoCarga, ')
          ..write('valorCarga: $valorCarga, ')
          ..write('numeroProtocolo: $numeroProtocolo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        uf,
        tipoAmbiente,
        tipoEmitente,
        tipoTransportadora,
        modelo,
        serie,
        numeroMdfe,
        codigoNumerico,
        chaveAcesso,
        digitoVerificador,
        modal,
        dataHoraEmissao,
        tipoEmissao,
        processoEmissao,
        versaoProcessoEmissao,
        ufInicio,
        ufFim,
        dataHoraPrevisaoViagem,
        quantidadeTotalCte,
        quantidadeTotalNfe,
        quantidadeTotalMdfe,
        codigoUnidadeMedida,
        pesoBrutoCarga,
        valorCarga,
        numeroProtocolo
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeCabecalho &&
          other.id == this.id &&
          other.uf == this.uf &&
          other.tipoAmbiente == this.tipoAmbiente &&
          other.tipoEmitente == this.tipoEmitente &&
          other.tipoTransportadora == this.tipoTransportadora &&
          other.modelo == this.modelo &&
          other.serie == this.serie &&
          other.numeroMdfe == this.numeroMdfe &&
          other.codigoNumerico == this.codigoNumerico &&
          other.chaveAcesso == this.chaveAcesso &&
          other.digitoVerificador == this.digitoVerificador &&
          other.modal == this.modal &&
          other.dataHoraEmissao == this.dataHoraEmissao &&
          other.tipoEmissao == this.tipoEmissao &&
          other.processoEmissao == this.processoEmissao &&
          other.versaoProcessoEmissao == this.versaoProcessoEmissao &&
          other.ufInicio == this.ufInicio &&
          other.ufFim == this.ufFim &&
          other.dataHoraPrevisaoViagem == this.dataHoraPrevisaoViagem &&
          other.quantidadeTotalCte == this.quantidadeTotalCte &&
          other.quantidadeTotalNfe == this.quantidadeTotalNfe &&
          other.quantidadeTotalMdfe == this.quantidadeTotalMdfe &&
          other.codigoUnidadeMedida == this.codigoUnidadeMedida &&
          other.pesoBrutoCarga == this.pesoBrutoCarga &&
          other.valorCarga == this.valorCarga &&
          other.numeroProtocolo == this.numeroProtocolo);
}

class MdfeCabecalhosCompanion extends UpdateCompanion<MdfeCabecalho> {
  final Value<int?> id;
  final Value<String?> uf;
  final Value<String?> tipoAmbiente;
  final Value<String?> tipoEmitente;
  final Value<String?> tipoTransportadora;
  final Value<String?> modelo;
  final Value<String?> serie;
  final Value<String?> numeroMdfe;
  final Value<String?> codigoNumerico;
  final Value<String?> chaveAcesso;
  final Value<int?> digitoVerificador;
  final Value<String?> modal;
  final Value<DateTime?> dataHoraEmissao;
  final Value<String?> tipoEmissao;
  final Value<String?> processoEmissao;
  final Value<String?> versaoProcessoEmissao;
  final Value<String?> ufInicio;
  final Value<String?> ufFim;
  final Value<DateTime?> dataHoraPrevisaoViagem;
  final Value<int?> quantidadeTotalCte;
  final Value<int?> quantidadeTotalNfe;
  final Value<int?> quantidadeTotalMdfe;
  final Value<String?> codigoUnidadeMedida;
  final Value<double?> pesoBrutoCarga;
  final Value<double?> valorCarga;
  final Value<String?> numeroProtocolo;
  const MdfeCabecalhosCompanion({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.tipoAmbiente = const Value.absent(),
    this.tipoEmitente = const Value.absent(),
    this.tipoTransportadora = const Value.absent(),
    this.modelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numeroMdfe = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoVerificador = const Value.absent(),
    this.modal = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.ufInicio = const Value.absent(),
    this.ufFim = const Value.absent(),
    this.dataHoraPrevisaoViagem = const Value.absent(),
    this.quantidadeTotalCte = const Value.absent(),
    this.quantidadeTotalNfe = const Value.absent(),
    this.quantidadeTotalMdfe = const Value.absent(),
    this.codigoUnidadeMedida = const Value.absent(),
    this.pesoBrutoCarga = const Value.absent(),
    this.valorCarga = const Value.absent(),
    this.numeroProtocolo = const Value.absent(),
  });
  MdfeCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.tipoAmbiente = const Value.absent(),
    this.tipoEmitente = const Value.absent(),
    this.tipoTransportadora = const Value.absent(),
    this.modelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numeroMdfe = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoVerificador = const Value.absent(),
    this.modal = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.ufInicio = const Value.absent(),
    this.ufFim = const Value.absent(),
    this.dataHoraPrevisaoViagem = const Value.absent(),
    this.quantidadeTotalCte = const Value.absent(),
    this.quantidadeTotalNfe = const Value.absent(),
    this.quantidadeTotalMdfe = const Value.absent(),
    this.codigoUnidadeMedida = const Value.absent(),
    this.pesoBrutoCarga = const Value.absent(),
    this.valorCarga = const Value.absent(),
    this.numeroProtocolo = const Value.absent(),
  });
  static Insertable<MdfeCabecalho> custom({
    Expression<int>? id,
    Expression<String>? uf,
    Expression<String>? tipoAmbiente,
    Expression<String>? tipoEmitente,
    Expression<String>? tipoTransportadora,
    Expression<String>? modelo,
    Expression<String>? serie,
    Expression<String>? numeroMdfe,
    Expression<String>? codigoNumerico,
    Expression<String>? chaveAcesso,
    Expression<int>? digitoVerificador,
    Expression<String>? modal,
    Expression<DateTime>? dataHoraEmissao,
    Expression<String>? tipoEmissao,
    Expression<String>? processoEmissao,
    Expression<String>? versaoProcessoEmissao,
    Expression<String>? ufInicio,
    Expression<String>? ufFim,
    Expression<DateTime>? dataHoraPrevisaoViagem,
    Expression<int>? quantidadeTotalCte,
    Expression<int>? quantidadeTotalNfe,
    Expression<int>? quantidadeTotalMdfe,
    Expression<String>? codigoUnidadeMedida,
    Expression<double>? pesoBrutoCarga,
    Expression<double>? valorCarga,
    Expression<String>? numeroProtocolo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (uf != null) 'uf': uf,
      if (tipoAmbiente != null) 'tipo_ambiente': tipoAmbiente,
      if (tipoEmitente != null) 'tipo_emitente': tipoEmitente,
      if (tipoTransportadora != null) 'tipo_transportadora': tipoTransportadora,
      if (modelo != null) 'modelo': modelo,
      if (serie != null) 'serie': serie,
      if (numeroMdfe != null) 'numero_mdfe': numeroMdfe,
      if (codigoNumerico != null) 'codigo_numerico': codigoNumerico,
      if (chaveAcesso != null) 'chave_acesso': chaveAcesso,
      if (digitoVerificador != null) 'digito_verificador': digitoVerificador,
      if (modal != null) 'modal': modal,
      if (dataHoraEmissao != null) 'data_hora_emissao': dataHoraEmissao,
      if (tipoEmissao != null) 'tipo_emissao': tipoEmissao,
      if (processoEmissao != null) 'processo_emissao': processoEmissao,
      if (versaoProcessoEmissao != null)
        'versao_processo_emissao': versaoProcessoEmissao,
      if (ufInicio != null) 'uf_inicio': ufInicio,
      if (ufFim != null) 'uf_fim': ufFim,
      if (dataHoraPrevisaoViagem != null)
        'data_hora_previsao_viagem': dataHoraPrevisaoViagem,
      if (quantidadeTotalCte != null)
        'quantidade_total_cte': quantidadeTotalCte,
      if (quantidadeTotalNfe != null)
        'quantidade_total_nfe': quantidadeTotalNfe,
      if (quantidadeTotalMdfe != null)
        'quantidade_total_mdfe': quantidadeTotalMdfe,
      if (codigoUnidadeMedida != null)
        'codigo_unidade_medida': codigoUnidadeMedida,
      if (pesoBrutoCarga != null) 'peso_bruto_carga': pesoBrutoCarga,
      if (valorCarga != null) 'valor_carga': valorCarga,
      if (numeroProtocolo != null) 'numero_protocolo': numeroProtocolo,
    });
  }

  MdfeCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? uf,
      Value<String?>? tipoAmbiente,
      Value<String?>? tipoEmitente,
      Value<String?>? tipoTransportadora,
      Value<String?>? modelo,
      Value<String?>? serie,
      Value<String?>? numeroMdfe,
      Value<String?>? codigoNumerico,
      Value<String?>? chaveAcesso,
      Value<int?>? digitoVerificador,
      Value<String?>? modal,
      Value<DateTime?>? dataHoraEmissao,
      Value<String?>? tipoEmissao,
      Value<String?>? processoEmissao,
      Value<String?>? versaoProcessoEmissao,
      Value<String?>? ufInicio,
      Value<String?>? ufFim,
      Value<DateTime?>? dataHoraPrevisaoViagem,
      Value<int?>? quantidadeTotalCte,
      Value<int?>? quantidadeTotalNfe,
      Value<int?>? quantidadeTotalMdfe,
      Value<String?>? codigoUnidadeMedida,
      Value<double?>? pesoBrutoCarga,
      Value<double?>? valorCarga,
      Value<String?>? numeroProtocolo}) {
    return MdfeCabecalhosCompanion(
      id: id ?? this.id,
      uf: uf ?? this.uf,
      tipoAmbiente: tipoAmbiente ?? this.tipoAmbiente,
      tipoEmitente: tipoEmitente ?? this.tipoEmitente,
      tipoTransportadora: tipoTransportadora ?? this.tipoTransportadora,
      modelo: modelo ?? this.modelo,
      serie: serie ?? this.serie,
      numeroMdfe: numeroMdfe ?? this.numeroMdfe,
      codigoNumerico: codigoNumerico ?? this.codigoNumerico,
      chaveAcesso: chaveAcesso ?? this.chaveAcesso,
      digitoVerificador: digitoVerificador ?? this.digitoVerificador,
      modal: modal ?? this.modal,
      dataHoraEmissao: dataHoraEmissao ?? this.dataHoraEmissao,
      tipoEmissao: tipoEmissao ?? this.tipoEmissao,
      processoEmissao: processoEmissao ?? this.processoEmissao,
      versaoProcessoEmissao:
          versaoProcessoEmissao ?? this.versaoProcessoEmissao,
      ufInicio: ufInicio ?? this.ufInicio,
      ufFim: ufFim ?? this.ufFim,
      dataHoraPrevisaoViagem:
          dataHoraPrevisaoViagem ?? this.dataHoraPrevisaoViagem,
      quantidadeTotalCte: quantidadeTotalCte ?? this.quantidadeTotalCte,
      quantidadeTotalNfe: quantidadeTotalNfe ?? this.quantidadeTotalNfe,
      quantidadeTotalMdfe: quantidadeTotalMdfe ?? this.quantidadeTotalMdfe,
      codigoUnidadeMedida: codigoUnidadeMedida ?? this.codigoUnidadeMedida,
      pesoBrutoCarga: pesoBrutoCarga ?? this.pesoBrutoCarga,
      valorCarga: valorCarga ?? this.valorCarga,
      numeroProtocolo: numeroProtocolo ?? this.numeroProtocolo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (tipoAmbiente.present) {
      map['tipo_ambiente'] = Variable<String>(tipoAmbiente.value);
    }
    if (tipoEmitente.present) {
      map['tipo_emitente'] = Variable<String>(tipoEmitente.value);
    }
    if (tipoTransportadora.present) {
      map['tipo_transportadora'] = Variable<String>(tipoTransportadora.value);
    }
    if (modelo.present) {
      map['modelo'] = Variable<String>(modelo.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numeroMdfe.present) {
      map['numero_mdfe'] = Variable<String>(numeroMdfe.value);
    }
    if (codigoNumerico.present) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico.value);
    }
    if (chaveAcesso.present) {
      map['chave_acesso'] = Variable<String>(chaveAcesso.value);
    }
    if (digitoVerificador.present) {
      map['digito_verificador'] = Variable<int>(digitoVerificador.value);
    }
    if (modal.present) {
      map['modal'] = Variable<String>(modal.value);
    }
    if (dataHoraEmissao.present) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao.value);
    }
    if (tipoEmissao.present) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao.value);
    }
    if (processoEmissao.present) {
      map['processo_emissao'] = Variable<String>(processoEmissao.value);
    }
    if (versaoProcessoEmissao.present) {
      map['versao_processo_emissao'] =
          Variable<String>(versaoProcessoEmissao.value);
    }
    if (ufInicio.present) {
      map['uf_inicio'] = Variable<String>(ufInicio.value);
    }
    if (ufFim.present) {
      map['uf_fim'] = Variable<String>(ufFim.value);
    }
    if (dataHoraPrevisaoViagem.present) {
      map['data_hora_previsao_viagem'] =
          Variable<DateTime>(dataHoraPrevisaoViagem.value);
    }
    if (quantidadeTotalCte.present) {
      map['quantidade_total_cte'] = Variable<int>(quantidadeTotalCte.value);
    }
    if (quantidadeTotalNfe.present) {
      map['quantidade_total_nfe'] = Variable<int>(quantidadeTotalNfe.value);
    }
    if (quantidadeTotalMdfe.present) {
      map['quantidade_total_mdfe'] = Variable<int>(quantidadeTotalMdfe.value);
    }
    if (codigoUnidadeMedida.present) {
      map['codigo_unidade_medida'] =
          Variable<String>(codigoUnidadeMedida.value);
    }
    if (pesoBrutoCarga.present) {
      map['peso_bruto_carga'] = Variable<double>(pesoBrutoCarga.value);
    }
    if (valorCarga.present) {
      map['valor_carga'] = Variable<double>(valorCarga.value);
    }
    if (numeroProtocolo.present) {
      map['numero_protocolo'] = Variable<String>(numeroProtocolo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('tipoAmbiente: $tipoAmbiente, ')
          ..write('tipoEmitente: $tipoEmitente, ')
          ..write('tipoTransportadora: $tipoTransportadora, ')
          ..write('modelo: $modelo, ')
          ..write('serie: $serie, ')
          ..write('numeroMdfe: $numeroMdfe, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoVerificador: $digitoVerificador, ')
          ..write('modal: $modal, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('ufInicio: $ufInicio, ')
          ..write('ufFim: $ufFim, ')
          ..write('dataHoraPrevisaoViagem: $dataHoraPrevisaoViagem, ')
          ..write('quantidadeTotalCte: $quantidadeTotalCte, ')
          ..write('quantidadeTotalNfe: $quantidadeTotalNfe, ')
          ..write('quantidadeTotalMdfe: $quantidadeTotalMdfe, ')
          ..write('codigoUnidadeMedida: $codigoUnidadeMedida, ')
          ..write('pesoBrutoCarga: $pesoBrutoCarga, ')
          ..write('valorCarga: $valorCarga, ')
          ..write('numeroProtocolo: $numeroProtocolo')
          ..write(')'))
        .toString();
  }
}

class $MdfeInformacaoCtesTable extends MdfeInformacaoCtes
    with TableInfo<$MdfeInformacaoCtesTable, MdfeInformacaoCte> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeInformacaoCtesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeMunicipioDescarregaMeta =
      const VerificationMeta('idMdfeMunicipioDescarrega');
  @override
  late final GeneratedColumn<int> idMdfeMunicipioDescarrega =
      GeneratedColumn<int>('id_mdfe_municipio_descarrega', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _chaveCteMeta =
      const VerificationMeta('chaveCte');
  @override
  late final GeneratedColumn<String> chaveCte = GeneratedColumn<String>(
      'chave_cte', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _segundoCodigoBarraMeta =
      const VerificationMeta('segundoCodigoBarra');
  @override
  late final GeneratedColumn<String> segundoCodigoBarra =
      GeneratedColumn<String>('segundo_codigo_barra', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 36),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _indicadorReentregaMeta =
      const VerificationMeta('indicadorReentrega');
  @override
  late final GeneratedColumn<int> indicadorReentrega = GeneratedColumn<int>(
      'indicador_reentrega', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeMunicipioDescarrega,
        chaveCte,
        segundoCodigoBarra,
        indicadorReentrega
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_informacao_cte';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeInformacaoCte> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_municipio_descarrega')) {
      context.handle(
          _idMdfeMunicipioDescarregaMeta,
          idMdfeMunicipioDescarrega.isAcceptableOrUnknown(
              data['id_mdfe_municipio_descarrega']!,
              _idMdfeMunicipioDescarregaMeta));
    }
    if (data.containsKey('chave_cte')) {
      context.handle(_chaveCteMeta,
          chaveCte.isAcceptableOrUnknown(data['chave_cte']!, _chaveCteMeta));
    }
    if (data.containsKey('segundo_codigo_barra')) {
      context.handle(
          _segundoCodigoBarraMeta,
          segundoCodigoBarra.isAcceptableOrUnknown(
              data['segundo_codigo_barra']!, _segundoCodigoBarraMeta));
    }
    if (data.containsKey('indicador_reentrega')) {
      context.handle(
          _indicadorReentregaMeta,
          indicadorReentrega.isAcceptableOrUnknown(
              data['indicador_reentrega']!, _indicadorReentregaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeInformacaoCte map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeInformacaoCte(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeMunicipioDescarrega: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_mdfe_municipio_descarrega']),
      chaveCte: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_cte']),
      segundoCodigoBarra: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}segundo_codigo_barra']),
      indicadorReentrega: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}indicador_reentrega']),
    );
  }

  @override
  $MdfeInformacaoCtesTable createAlias(String alias) {
    return $MdfeInformacaoCtesTable(attachedDatabase, alias);
  }
}

class MdfeInformacaoCte extends DataClass
    implements Insertable<MdfeInformacaoCte> {
  final int? id;
  final int? idMdfeMunicipioDescarrega;
  final String? chaveCte;
  final String? segundoCodigoBarra;
  final int? indicadorReentrega;
  const MdfeInformacaoCte(
      {this.id,
      this.idMdfeMunicipioDescarrega,
      this.chaveCte,
      this.segundoCodigoBarra,
      this.indicadorReentrega});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeMunicipioDescarrega != null) {
      map['id_mdfe_municipio_descarrega'] =
          Variable<int>(idMdfeMunicipioDescarrega);
    }
    if (!nullToAbsent || chaveCte != null) {
      map['chave_cte'] = Variable<String>(chaveCte);
    }
    if (!nullToAbsent || segundoCodigoBarra != null) {
      map['segundo_codigo_barra'] = Variable<String>(segundoCodigoBarra);
    }
    if (!nullToAbsent || indicadorReentrega != null) {
      map['indicador_reentrega'] = Variable<int>(indicadorReentrega);
    }
    return map;
  }

  factory MdfeInformacaoCte.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeInformacaoCte(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeMunicipioDescarrega:
          serializer.fromJson<int?>(json['idMdfeMunicipioDescarrega']),
      chaveCte: serializer.fromJson<String?>(json['chaveCte']),
      segundoCodigoBarra:
          serializer.fromJson<String?>(json['segundoCodigoBarra']),
      indicadorReentrega: serializer.fromJson<int?>(json['indicadorReentrega']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeMunicipioDescarrega':
          serializer.toJson<int?>(idMdfeMunicipioDescarrega),
      'chaveCte': serializer.toJson<String?>(chaveCte),
      'segundoCodigoBarra': serializer.toJson<String?>(segundoCodigoBarra),
      'indicadorReentrega': serializer.toJson<int?>(indicadorReentrega),
    };
  }

  MdfeInformacaoCte copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeMunicipioDescarrega = const Value.absent(),
          Value<String?> chaveCte = const Value.absent(),
          Value<String?> segundoCodigoBarra = const Value.absent(),
          Value<int?> indicadorReentrega = const Value.absent()}) =>
      MdfeInformacaoCte(
        id: id.present ? id.value : this.id,
        idMdfeMunicipioDescarrega: idMdfeMunicipioDescarrega.present
            ? idMdfeMunicipioDescarrega.value
            : this.idMdfeMunicipioDescarrega,
        chaveCte: chaveCte.present ? chaveCte.value : this.chaveCte,
        segundoCodigoBarra: segundoCodigoBarra.present
            ? segundoCodigoBarra.value
            : this.segundoCodigoBarra,
        indicadorReentrega: indicadorReentrega.present
            ? indicadorReentrega.value
            : this.indicadorReentrega,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoCte(')
          ..write('id: $id, ')
          ..write('idMdfeMunicipioDescarrega: $idMdfeMunicipioDescarrega, ')
          ..write('chaveCte: $chaveCte, ')
          ..write('segundoCodigoBarra: $segundoCodigoBarra, ')
          ..write('indicadorReentrega: $indicadorReentrega')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeMunicipioDescarrega, chaveCte,
      segundoCodigoBarra, indicadorReentrega);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeInformacaoCte &&
          other.id == this.id &&
          other.idMdfeMunicipioDescarrega == this.idMdfeMunicipioDescarrega &&
          other.chaveCte == this.chaveCte &&
          other.segundoCodigoBarra == this.segundoCodigoBarra &&
          other.indicadorReentrega == this.indicadorReentrega);
}

class MdfeInformacaoCtesCompanion extends UpdateCompanion<MdfeInformacaoCte> {
  final Value<int?> id;
  final Value<int?> idMdfeMunicipioDescarrega;
  final Value<String?> chaveCte;
  final Value<String?> segundoCodigoBarra;
  final Value<int?> indicadorReentrega;
  const MdfeInformacaoCtesCompanion({
    this.id = const Value.absent(),
    this.idMdfeMunicipioDescarrega = const Value.absent(),
    this.chaveCte = const Value.absent(),
    this.segundoCodigoBarra = const Value.absent(),
    this.indicadorReentrega = const Value.absent(),
  });
  MdfeInformacaoCtesCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeMunicipioDescarrega = const Value.absent(),
    this.chaveCte = const Value.absent(),
    this.segundoCodigoBarra = const Value.absent(),
    this.indicadorReentrega = const Value.absent(),
  });
  static Insertable<MdfeInformacaoCte> custom({
    Expression<int>? id,
    Expression<int>? idMdfeMunicipioDescarrega,
    Expression<String>? chaveCte,
    Expression<String>? segundoCodigoBarra,
    Expression<int>? indicadorReentrega,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeMunicipioDescarrega != null)
        'id_mdfe_municipio_descarrega': idMdfeMunicipioDescarrega,
      if (chaveCte != null) 'chave_cte': chaveCte,
      if (segundoCodigoBarra != null)
        'segundo_codigo_barra': segundoCodigoBarra,
      if (indicadorReentrega != null) 'indicador_reentrega': indicadorReentrega,
    });
  }

  MdfeInformacaoCtesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeMunicipioDescarrega,
      Value<String?>? chaveCte,
      Value<String?>? segundoCodigoBarra,
      Value<int?>? indicadorReentrega}) {
    return MdfeInformacaoCtesCompanion(
      id: id ?? this.id,
      idMdfeMunicipioDescarrega:
          idMdfeMunicipioDescarrega ?? this.idMdfeMunicipioDescarrega,
      chaveCte: chaveCte ?? this.chaveCte,
      segundoCodigoBarra: segundoCodigoBarra ?? this.segundoCodigoBarra,
      indicadorReentrega: indicadorReentrega ?? this.indicadorReentrega,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeMunicipioDescarrega.present) {
      map['id_mdfe_municipio_descarrega'] =
          Variable<int>(idMdfeMunicipioDescarrega.value);
    }
    if (chaveCte.present) {
      map['chave_cte'] = Variable<String>(chaveCte.value);
    }
    if (segundoCodigoBarra.present) {
      map['segundo_codigo_barra'] = Variable<String>(segundoCodigoBarra.value);
    }
    if (indicadorReentrega.present) {
      map['indicador_reentrega'] = Variable<int>(indicadorReentrega.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoCtesCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeMunicipioDescarrega: $idMdfeMunicipioDescarrega, ')
          ..write('chaveCte: $chaveCte, ')
          ..write('segundoCodigoBarra: $segundoCodigoBarra, ')
          ..write('indicadorReentrega: $indicadorReentrega')
          ..write(')'))
        .toString();
  }
}

class $MdfeInformacaoNfesTable extends MdfeInformacaoNfes
    with TableInfo<$MdfeInformacaoNfesTable, MdfeInformacaoNfe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeInformacaoNfesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeMunicipioDescarregaMeta =
      const VerificationMeta('idMdfeMunicipioDescarrega');
  @override
  late final GeneratedColumn<int> idMdfeMunicipioDescarrega =
      GeneratedColumn<int>('id_mdfe_municipio_descarrega', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _chaveNfeMeta =
      const VerificationMeta('chaveNfe');
  @override
  late final GeneratedColumn<String> chaveNfe = GeneratedColumn<String>(
      'chave_nfe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _segundoCodigoBarraMeta =
      const VerificationMeta('segundoCodigoBarra');
  @override
  late final GeneratedColumn<String> segundoCodigoBarra =
      GeneratedColumn<String>('segundo_codigo_barra', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 36),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _indicadorReentregaMeta =
      const VerificationMeta('indicadorReentrega');
  @override
  late final GeneratedColumn<int> indicadorReentrega = GeneratedColumn<int>(
      'indicador_reentrega', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeMunicipioDescarrega,
        chaveNfe,
        segundoCodigoBarra,
        indicadorReentrega
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_informacao_nfe';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeInformacaoNfe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_municipio_descarrega')) {
      context.handle(
          _idMdfeMunicipioDescarregaMeta,
          idMdfeMunicipioDescarrega.isAcceptableOrUnknown(
              data['id_mdfe_municipio_descarrega']!,
              _idMdfeMunicipioDescarregaMeta));
    }
    if (data.containsKey('chave_nfe')) {
      context.handle(_chaveNfeMeta,
          chaveNfe.isAcceptableOrUnknown(data['chave_nfe']!, _chaveNfeMeta));
    }
    if (data.containsKey('segundo_codigo_barra')) {
      context.handle(
          _segundoCodigoBarraMeta,
          segundoCodigoBarra.isAcceptableOrUnknown(
              data['segundo_codigo_barra']!, _segundoCodigoBarraMeta));
    }
    if (data.containsKey('indicador_reentrega')) {
      context.handle(
          _indicadorReentregaMeta,
          indicadorReentrega.isAcceptableOrUnknown(
              data['indicador_reentrega']!, _indicadorReentregaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeInformacaoNfe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeInformacaoNfe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeMunicipioDescarrega: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_mdfe_municipio_descarrega']),
      chaveNfe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_nfe']),
      segundoCodigoBarra: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}segundo_codigo_barra']),
      indicadorReentrega: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}indicador_reentrega']),
    );
  }

  @override
  $MdfeInformacaoNfesTable createAlias(String alias) {
    return $MdfeInformacaoNfesTable(attachedDatabase, alias);
  }
}

class MdfeInformacaoNfe extends DataClass
    implements Insertable<MdfeInformacaoNfe> {
  final int? id;
  final int? idMdfeMunicipioDescarrega;
  final String? chaveNfe;
  final String? segundoCodigoBarra;
  final int? indicadorReentrega;
  const MdfeInformacaoNfe(
      {this.id,
      this.idMdfeMunicipioDescarrega,
      this.chaveNfe,
      this.segundoCodigoBarra,
      this.indicadorReentrega});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeMunicipioDescarrega != null) {
      map['id_mdfe_municipio_descarrega'] =
          Variable<int>(idMdfeMunicipioDescarrega);
    }
    if (!nullToAbsent || chaveNfe != null) {
      map['chave_nfe'] = Variable<String>(chaveNfe);
    }
    if (!nullToAbsent || segundoCodigoBarra != null) {
      map['segundo_codigo_barra'] = Variable<String>(segundoCodigoBarra);
    }
    if (!nullToAbsent || indicadorReentrega != null) {
      map['indicador_reentrega'] = Variable<int>(indicadorReentrega);
    }
    return map;
  }

  factory MdfeInformacaoNfe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeInformacaoNfe(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeMunicipioDescarrega:
          serializer.fromJson<int?>(json['idMdfeMunicipioDescarrega']),
      chaveNfe: serializer.fromJson<String?>(json['chaveNfe']),
      segundoCodigoBarra:
          serializer.fromJson<String?>(json['segundoCodigoBarra']),
      indicadorReentrega: serializer.fromJson<int?>(json['indicadorReentrega']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeMunicipioDescarrega':
          serializer.toJson<int?>(idMdfeMunicipioDescarrega),
      'chaveNfe': serializer.toJson<String?>(chaveNfe),
      'segundoCodigoBarra': serializer.toJson<String?>(segundoCodigoBarra),
      'indicadorReentrega': serializer.toJson<int?>(indicadorReentrega),
    };
  }

  MdfeInformacaoNfe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeMunicipioDescarrega = const Value.absent(),
          Value<String?> chaveNfe = const Value.absent(),
          Value<String?> segundoCodigoBarra = const Value.absent(),
          Value<int?> indicadorReentrega = const Value.absent()}) =>
      MdfeInformacaoNfe(
        id: id.present ? id.value : this.id,
        idMdfeMunicipioDescarrega: idMdfeMunicipioDescarrega.present
            ? idMdfeMunicipioDescarrega.value
            : this.idMdfeMunicipioDescarrega,
        chaveNfe: chaveNfe.present ? chaveNfe.value : this.chaveNfe,
        segundoCodigoBarra: segundoCodigoBarra.present
            ? segundoCodigoBarra.value
            : this.segundoCodigoBarra,
        indicadorReentrega: indicadorReentrega.present
            ? indicadorReentrega.value
            : this.indicadorReentrega,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoNfe(')
          ..write('id: $id, ')
          ..write('idMdfeMunicipioDescarrega: $idMdfeMunicipioDescarrega, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('segundoCodigoBarra: $segundoCodigoBarra, ')
          ..write('indicadorReentrega: $indicadorReentrega')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeMunicipioDescarrega, chaveNfe,
      segundoCodigoBarra, indicadorReentrega);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeInformacaoNfe &&
          other.id == this.id &&
          other.idMdfeMunicipioDescarrega == this.idMdfeMunicipioDescarrega &&
          other.chaveNfe == this.chaveNfe &&
          other.segundoCodigoBarra == this.segundoCodigoBarra &&
          other.indicadorReentrega == this.indicadorReentrega);
}

class MdfeInformacaoNfesCompanion extends UpdateCompanion<MdfeInformacaoNfe> {
  final Value<int?> id;
  final Value<int?> idMdfeMunicipioDescarrega;
  final Value<String?> chaveNfe;
  final Value<String?> segundoCodigoBarra;
  final Value<int?> indicadorReentrega;
  const MdfeInformacaoNfesCompanion({
    this.id = const Value.absent(),
    this.idMdfeMunicipioDescarrega = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.segundoCodigoBarra = const Value.absent(),
    this.indicadorReentrega = const Value.absent(),
  });
  MdfeInformacaoNfesCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeMunicipioDescarrega = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.segundoCodigoBarra = const Value.absent(),
    this.indicadorReentrega = const Value.absent(),
  });
  static Insertable<MdfeInformacaoNfe> custom({
    Expression<int>? id,
    Expression<int>? idMdfeMunicipioDescarrega,
    Expression<String>? chaveNfe,
    Expression<String>? segundoCodigoBarra,
    Expression<int>? indicadorReentrega,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeMunicipioDescarrega != null)
        'id_mdfe_municipio_descarrega': idMdfeMunicipioDescarrega,
      if (chaveNfe != null) 'chave_nfe': chaveNfe,
      if (segundoCodigoBarra != null)
        'segundo_codigo_barra': segundoCodigoBarra,
      if (indicadorReentrega != null) 'indicador_reentrega': indicadorReentrega,
    });
  }

  MdfeInformacaoNfesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeMunicipioDescarrega,
      Value<String?>? chaveNfe,
      Value<String?>? segundoCodigoBarra,
      Value<int?>? indicadorReentrega}) {
    return MdfeInformacaoNfesCompanion(
      id: id ?? this.id,
      idMdfeMunicipioDescarrega:
          idMdfeMunicipioDescarrega ?? this.idMdfeMunicipioDescarrega,
      chaveNfe: chaveNfe ?? this.chaveNfe,
      segundoCodigoBarra: segundoCodigoBarra ?? this.segundoCodigoBarra,
      indicadorReentrega: indicadorReentrega ?? this.indicadorReentrega,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeMunicipioDescarrega.present) {
      map['id_mdfe_municipio_descarrega'] =
          Variable<int>(idMdfeMunicipioDescarrega.value);
    }
    if (chaveNfe.present) {
      map['chave_nfe'] = Variable<String>(chaveNfe.value);
    }
    if (segundoCodigoBarra.present) {
      map['segundo_codigo_barra'] = Variable<String>(segundoCodigoBarra.value);
    }
    if (indicadorReentrega.present) {
      map['indicador_reentrega'] = Variable<int>(indicadorReentrega.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeInformacaoNfesCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeMunicipioDescarrega: $idMdfeMunicipioDescarrega, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('segundoCodigoBarra: $segundoCodigoBarra, ')
          ..write('indicadorReentrega: $indicadorReentrega')
          ..write(')'))
        .toString();
  }
}

class $MdfeRodoviarioMotoristasTable extends MdfeRodoviarioMotoristas
    with TableInfo<$MdfeRodoviarioMotoristasTable, MdfeRodoviarioMotorista> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeRodoviarioMotoristasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeRodoviarioMeta =
      const VerificationMeta('idMdfeRodoviario');
  @override
  late final GeneratedColumn<int> idMdfeRodoviario = GeneratedColumn<int>(
      'id_mdfe_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idMdfeRodoviario, nome, cpf];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_rodoviario_motorista';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeRodoviarioMotorista> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_rodoviario')) {
      context.handle(
          _idMdfeRodoviarioMeta,
          idMdfeRodoviario.isAcceptableOrUnknown(
              data['id_mdfe_rodoviario']!, _idMdfeRodoviarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeRodoviarioMotorista map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeRodoviarioMotorista(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_rodoviario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
    );
  }

  @override
  $MdfeRodoviarioMotoristasTable createAlias(String alias) {
    return $MdfeRodoviarioMotoristasTable(attachedDatabase, alias);
  }
}

class MdfeRodoviarioMotorista extends DataClass
    implements Insertable<MdfeRodoviarioMotorista> {
  final int? id;
  final int? idMdfeRodoviario;
  final String? nome;
  final String? cpf;
  const MdfeRodoviarioMotorista(
      {this.id, this.idMdfeRodoviario, this.nome, this.cpf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeRodoviario != null) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    return map;
  }

  factory MdfeRodoviarioMotorista.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeRodoviarioMotorista(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeRodoviario: serializer.fromJson<int?>(json['idMdfeRodoviario']),
      nome: serializer.fromJson<String?>(json['nome']),
      cpf: serializer.fromJson<String?>(json['cpf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeRodoviario': serializer.toJson<int?>(idMdfeRodoviario),
      'nome': serializer.toJson<String?>(nome),
      'cpf': serializer.toJson<String?>(cpf),
    };
  }

  MdfeRodoviarioMotorista copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeRodoviario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> cpf = const Value.absent()}) =>
      MdfeRodoviarioMotorista(
        id: id.present ? id.value : this.id,
        idMdfeRodoviario: idMdfeRodoviario.present
            ? idMdfeRodoviario.value
            : this.idMdfeRodoviario,
        nome: nome.present ? nome.value : this.nome,
        cpf: cpf.present ? cpf.value : this.cpf,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioMotorista(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeRodoviario, nome, cpf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeRodoviarioMotorista &&
          other.id == this.id &&
          other.idMdfeRodoviario == this.idMdfeRodoviario &&
          other.nome == this.nome &&
          other.cpf == this.cpf);
}

class MdfeRodoviarioMotoristasCompanion
    extends UpdateCompanion<MdfeRodoviarioMotorista> {
  final Value<int?> id;
  final Value<int?> idMdfeRodoviario;
  final Value<String?> nome;
  final Value<String?> cpf;
  const MdfeRodoviarioMotoristasCompanion({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
  });
  MdfeRodoviarioMotoristasCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
  });
  static Insertable<MdfeRodoviarioMotorista> custom({
    Expression<int>? id,
    Expression<int>? idMdfeRodoviario,
    Expression<String>? nome,
    Expression<String>? cpf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeRodoviario != null) 'id_mdfe_rodoviario': idMdfeRodoviario,
      if (nome != null) 'nome': nome,
      if (cpf != null) 'cpf': cpf,
    });
  }

  MdfeRodoviarioMotoristasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeRodoviario,
      Value<String?>? nome,
      Value<String?>? cpf}) {
    return MdfeRodoviarioMotoristasCompanion(
      id: id ?? this.id,
      idMdfeRodoviario: idMdfeRodoviario ?? this.idMdfeRodoviario,
      nome: nome ?? this.nome,
      cpf: cpf ?? this.cpf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeRodoviario.present) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioMotoristasCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf')
          ..write(')'))
        .toString();
  }
}

class $MdfeRodoviarioVeiculosTable extends MdfeRodoviarioVeiculos
    with TableInfo<$MdfeRodoviarioVeiculosTable, MdfeRodoviarioVeiculo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeRodoviarioVeiculosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeRodoviarioMeta =
      const VerificationMeta('idMdfeRodoviario');
  @override
  late final GeneratedColumn<int> idMdfeRodoviario = GeneratedColumn<int>(
      'id_mdfe_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _placaMeta = const VerificationMeta('placa');
  @override
  late final GeneratedColumn<String> placa = GeneratedColumn<String>(
      'placa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _renavamMeta =
      const VerificationMeta('renavam');
  @override
  late final GeneratedColumn<String> renavam = GeneratedColumn<String>(
      'renavam', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _taraMeta = const VerificationMeta('tara');
  @override
  late final GeneratedColumn<int> tara = GeneratedColumn<int>(
      'tara', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _capacidadeKgMeta =
      const VerificationMeta('capacidadeKg');
  @override
  late final GeneratedColumn<int> capacidadeKg = GeneratedColumn<int>(
      'capacidade_kg', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _capacidadeM3Meta =
      const VerificationMeta('capacidadeM3');
  @override
  late final GeneratedColumn<int> capacidadeM3 = GeneratedColumn<int>(
      'capacidade_m3', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoRodadoMeta =
      const VerificationMeta('tipoRodado');
  @override
  late final GeneratedColumn<String> tipoRodado = GeneratedColumn<String>(
      'tipo_rodado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoCarroceriaMeta =
      const VerificationMeta('tipoCarroceria');
  @override
  late final GeneratedColumn<String> tipoCarroceria = GeneratedColumn<String>(
      'tipo_carroceria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufLicenciamentoMeta =
      const VerificationMeta('ufLicenciamento');
  @override
  late final GeneratedColumn<String> ufLicenciamento = GeneratedColumn<String>(
      'uf_licenciamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioCpfMeta =
      const VerificationMeta('proprietarioCpf');
  @override
  late final GeneratedColumn<String> proprietarioCpf = GeneratedColumn<String>(
      'proprietario_cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioCnpjMeta =
      const VerificationMeta('proprietarioCnpj');
  @override
  late final GeneratedColumn<String> proprietarioCnpj = GeneratedColumn<String>(
      'proprietario_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioRntrcMeta =
      const VerificationMeta('proprietarioRntrc');
  @override
  late final GeneratedColumn<String> proprietarioRntrc =
      GeneratedColumn<String>('proprietario_rntrc', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _proprietarioNomeMeta =
      const VerificationMeta('proprietarioNome');
  @override
  late final GeneratedColumn<String> proprietarioNome = GeneratedColumn<String>(
      'proprietario_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioIeMeta =
      const VerificationMeta('proprietarioIe');
  @override
  late final GeneratedColumn<String> proprietarioIe = GeneratedColumn<String>(
      'proprietario_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _proprietarioTipoMeta =
      const VerificationMeta('proprietarioTipo');
  @override
  late final GeneratedColumn<int> proprietarioTipo = GeneratedColumn<int>(
      'proprietario_tipo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeRodoviario,
        codigoInterno,
        placa,
        renavam,
        tara,
        capacidadeKg,
        capacidadeM3,
        tipoRodado,
        tipoCarroceria,
        ufLicenciamento,
        proprietarioCpf,
        proprietarioCnpj,
        proprietarioRntrc,
        proprietarioNome,
        proprietarioIe,
        proprietarioTipo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_rodoviario_veiculo';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeRodoviarioVeiculo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_rodoviario')) {
      context.handle(
          _idMdfeRodoviarioMeta,
          idMdfeRodoviario.isAcceptableOrUnknown(
              data['id_mdfe_rodoviario']!, _idMdfeRodoviarioMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('placa')) {
      context.handle(
          _placaMeta, placa.isAcceptableOrUnknown(data['placa']!, _placaMeta));
    }
    if (data.containsKey('renavam')) {
      context.handle(_renavamMeta,
          renavam.isAcceptableOrUnknown(data['renavam']!, _renavamMeta));
    }
    if (data.containsKey('tara')) {
      context.handle(
          _taraMeta, tara.isAcceptableOrUnknown(data['tara']!, _taraMeta));
    }
    if (data.containsKey('capacidade_kg')) {
      context.handle(
          _capacidadeKgMeta,
          capacidadeKg.isAcceptableOrUnknown(
              data['capacidade_kg']!, _capacidadeKgMeta));
    }
    if (data.containsKey('capacidade_m3')) {
      context.handle(
          _capacidadeM3Meta,
          capacidadeM3.isAcceptableOrUnknown(
              data['capacidade_m3']!, _capacidadeM3Meta));
    }
    if (data.containsKey('tipo_rodado')) {
      context.handle(
          _tipoRodadoMeta,
          tipoRodado.isAcceptableOrUnknown(
              data['tipo_rodado']!, _tipoRodadoMeta));
    }
    if (data.containsKey('tipo_carroceria')) {
      context.handle(
          _tipoCarroceriaMeta,
          tipoCarroceria.isAcceptableOrUnknown(
              data['tipo_carroceria']!, _tipoCarroceriaMeta));
    }
    if (data.containsKey('uf_licenciamento')) {
      context.handle(
          _ufLicenciamentoMeta,
          ufLicenciamento.isAcceptableOrUnknown(
              data['uf_licenciamento']!, _ufLicenciamentoMeta));
    }
    if (data.containsKey('proprietario_cpf')) {
      context.handle(
          _proprietarioCpfMeta,
          proprietarioCpf.isAcceptableOrUnknown(
              data['proprietario_cpf']!, _proprietarioCpfMeta));
    }
    if (data.containsKey('proprietario_cnpj')) {
      context.handle(
          _proprietarioCnpjMeta,
          proprietarioCnpj.isAcceptableOrUnknown(
              data['proprietario_cnpj']!, _proprietarioCnpjMeta));
    }
    if (data.containsKey('proprietario_rntrc')) {
      context.handle(
          _proprietarioRntrcMeta,
          proprietarioRntrc.isAcceptableOrUnknown(
              data['proprietario_rntrc']!, _proprietarioRntrcMeta));
    }
    if (data.containsKey('proprietario_nome')) {
      context.handle(
          _proprietarioNomeMeta,
          proprietarioNome.isAcceptableOrUnknown(
              data['proprietario_nome']!, _proprietarioNomeMeta));
    }
    if (data.containsKey('proprietario_ie')) {
      context.handle(
          _proprietarioIeMeta,
          proprietarioIe.isAcceptableOrUnknown(
              data['proprietario_ie']!, _proprietarioIeMeta));
    }
    if (data.containsKey('proprietario_tipo')) {
      context.handle(
          _proprietarioTipoMeta,
          proprietarioTipo.isAcceptableOrUnknown(
              data['proprietario_tipo']!, _proprietarioTipoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeRodoviarioVeiculo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeRodoviarioVeiculo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_rodoviario']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      placa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}placa']),
      renavam: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}renavam']),
      tara: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}tara']),
      capacidadeKg: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}capacidade_kg']),
      capacidadeM3: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}capacidade_m3']),
      tipoRodado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_rodado']),
      tipoCarroceria: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_carroceria']),
      ufLicenciamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}uf_licenciamento']),
      proprietarioCpf: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_cpf']),
      proprietarioCnpj: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_cnpj']),
      proprietarioRntrc: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_rntrc']),
      proprietarioNome: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}proprietario_nome']),
      proprietarioIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}proprietario_ie']),
      proprietarioTipo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}proprietario_tipo']),
    );
  }

  @override
  $MdfeRodoviarioVeiculosTable createAlias(String alias) {
    return $MdfeRodoviarioVeiculosTable(attachedDatabase, alias);
  }
}

class MdfeRodoviarioVeiculo extends DataClass
    implements Insertable<MdfeRodoviarioVeiculo> {
  final int? id;
  final int? idMdfeRodoviario;
  final String? codigoInterno;
  final String? placa;
  final String? renavam;
  final int? tara;
  final int? capacidadeKg;
  final int? capacidadeM3;
  final String? tipoRodado;
  final String? tipoCarroceria;
  final String? ufLicenciamento;
  final String? proprietarioCpf;
  final String? proprietarioCnpj;
  final String? proprietarioRntrc;
  final String? proprietarioNome;
  final String? proprietarioIe;
  final int? proprietarioTipo;
  const MdfeRodoviarioVeiculo(
      {this.id,
      this.idMdfeRodoviario,
      this.codigoInterno,
      this.placa,
      this.renavam,
      this.tara,
      this.capacidadeKg,
      this.capacidadeM3,
      this.tipoRodado,
      this.tipoCarroceria,
      this.ufLicenciamento,
      this.proprietarioCpf,
      this.proprietarioCnpj,
      this.proprietarioRntrc,
      this.proprietarioNome,
      this.proprietarioIe,
      this.proprietarioTipo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeRodoviario != null) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || placa != null) {
      map['placa'] = Variable<String>(placa);
    }
    if (!nullToAbsent || renavam != null) {
      map['renavam'] = Variable<String>(renavam);
    }
    if (!nullToAbsent || tara != null) {
      map['tara'] = Variable<int>(tara);
    }
    if (!nullToAbsent || capacidadeKg != null) {
      map['capacidade_kg'] = Variable<int>(capacidadeKg);
    }
    if (!nullToAbsent || capacidadeM3 != null) {
      map['capacidade_m3'] = Variable<int>(capacidadeM3);
    }
    if (!nullToAbsent || tipoRodado != null) {
      map['tipo_rodado'] = Variable<String>(tipoRodado);
    }
    if (!nullToAbsent || tipoCarroceria != null) {
      map['tipo_carroceria'] = Variable<String>(tipoCarroceria);
    }
    if (!nullToAbsent || ufLicenciamento != null) {
      map['uf_licenciamento'] = Variable<String>(ufLicenciamento);
    }
    if (!nullToAbsent || proprietarioCpf != null) {
      map['proprietario_cpf'] = Variable<String>(proprietarioCpf);
    }
    if (!nullToAbsent || proprietarioCnpj != null) {
      map['proprietario_cnpj'] = Variable<String>(proprietarioCnpj);
    }
    if (!nullToAbsent || proprietarioRntrc != null) {
      map['proprietario_rntrc'] = Variable<String>(proprietarioRntrc);
    }
    if (!nullToAbsent || proprietarioNome != null) {
      map['proprietario_nome'] = Variable<String>(proprietarioNome);
    }
    if (!nullToAbsent || proprietarioIe != null) {
      map['proprietario_ie'] = Variable<String>(proprietarioIe);
    }
    if (!nullToAbsent || proprietarioTipo != null) {
      map['proprietario_tipo'] = Variable<int>(proprietarioTipo);
    }
    return map;
  }

  factory MdfeRodoviarioVeiculo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeRodoviarioVeiculo(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeRodoviario: serializer.fromJson<int?>(json['idMdfeRodoviario']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      placa: serializer.fromJson<String?>(json['placa']),
      renavam: serializer.fromJson<String?>(json['renavam']),
      tara: serializer.fromJson<int?>(json['tara']),
      capacidadeKg: serializer.fromJson<int?>(json['capacidadeKg']),
      capacidadeM3: serializer.fromJson<int?>(json['capacidadeM3']),
      tipoRodado: serializer.fromJson<String?>(json['tipoRodado']),
      tipoCarroceria: serializer.fromJson<String?>(json['tipoCarroceria']),
      ufLicenciamento: serializer.fromJson<String?>(json['ufLicenciamento']),
      proprietarioCpf: serializer.fromJson<String?>(json['proprietarioCpf']),
      proprietarioCnpj: serializer.fromJson<String?>(json['proprietarioCnpj']),
      proprietarioRntrc:
          serializer.fromJson<String?>(json['proprietarioRntrc']),
      proprietarioNome: serializer.fromJson<String?>(json['proprietarioNome']),
      proprietarioIe: serializer.fromJson<String?>(json['proprietarioIe']),
      proprietarioTipo: serializer.fromJson<int?>(json['proprietarioTipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeRodoviario': serializer.toJson<int?>(idMdfeRodoviario),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'placa': serializer.toJson<String?>(placa),
      'renavam': serializer.toJson<String?>(renavam),
      'tara': serializer.toJson<int?>(tara),
      'capacidadeKg': serializer.toJson<int?>(capacidadeKg),
      'capacidadeM3': serializer.toJson<int?>(capacidadeM3),
      'tipoRodado': serializer.toJson<String?>(tipoRodado),
      'tipoCarroceria': serializer.toJson<String?>(tipoCarroceria),
      'ufLicenciamento': serializer.toJson<String?>(ufLicenciamento),
      'proprietarioCpf': serializer.toJson<String?>(proprietarioCpf),
      'proprietarioCnpj': serializer.toJson<String?>(proprietarioCnpj),
      'proprietarioRntrc': serializer.toJson<String?>(proprietarioRntrc),
      'proprietarioNome': serializer.toJson<String?>(proprietarioNome),
      'proprietarioIe': serializer.toJson<String?>(proprietarioIe),
      'proprietarioTipo': serializer.toJson<int?>(proprietarioTipo),
    };
  }

  MdfeRodoviarioVeiculo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeRodoviario = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<String?> placa = const Value.absent(),
          Value<String?> renavam = const Value.absent(),
          Value<int?> tara = const Value.absent(),
          Value<int?> capacidadeKg = const Value.absent(),
          Value<int?> capacidadeM3 = const Value.absent(),
          Value<String?> tipoRodado = const Value.absent(),
          Value<String?> tipoCarroceria = const Value.absent(),
          Value<String?> ufLicenciamento = const Value.absent(),
          Value<String?> proprietarioCpf = const Value.absent(),
          Value<String?> proprietarioCnpj = const Value.absent(),
          Value<String?> proprietarioRntrc = const Value.absent(),
          Value<String?> proprietarioNome = const Value.absent(),
          Value<String?> proprietarioIe = const Value.absent(),
          Value<int?> proprietarioTipo = const Value.absent()}) =>
      MdfeRodoviarioVeiculo(
        id: id.present ? id.value : this.id,
        idMdfeRodoviario: idMdfeRodoviario.present
            ? idMdfeRodoviario.value
            : this.idMdfeRodoviario,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        placa: placa.present ? placa.value : this.placa,
        renavam: renavam.present ? renavam.value : this.renavam,
        tara: tara.present ? tara.value : this.tara,
        capacidadeKg:
            capacidadeKg.present ? capacidadeKg.value : this.capacidadeKg,
        capacidadeM3:
            capacidadeM3.present ? capacidadeM3.value : this.capacidadeM3,
        tipoRodado: tipoRodado.present ? tipoRodado.value : this.tipoRodado,
        tipoCarroceria:
            tipoCarroceria.present ? tipoCarroceria.value : this.tipoCarroceria,
        ufLicenciamento: ufLicenciamento.present
            ? ufLicenciamento.value
            : this.ufLicenciamento,
        proprietarioCpf: proprietarioCpf.present
            ? proprietarioCpf.value
            : this.proprietarioCpf,
        proprietarioCnpj: proprietarioCnpj.present
            ? proprietarioCnpj.value
            : this.proprietarioCnpj,
        proprietarioRntrc: proprietarioRntrc.present
            ? proprietarioRntrc.value
            : this.proprietarioRntrc,
        proprietarioNome: proprietarioNome.present
            ? proprietarioNome.value
            : this.proprietarioNome,
        proprietarioIe:
            proprietarioIe.present ? proprietarioIe.value : this.proprietarioIe,
        proprietarioTipo: proprietarioTipo.present
            ? proprietarioTipo.value
            : this.proprietarioTipo,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioVeiculo(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('placa: $placa, ')
          ..write('renavam: $renavam, ')
          ..write('tara: $tara, ')
          ..write('capacidadeKg: $capacidadeKg, ')
          ..write('capacidadeM3: $capacidadeM3, ')
          ..write('tipoRodado: $tipoRodado, ')
          ..write('tipoCarroceria: $tipoCarroceria, ')
          ..write('ufLicenciamento: $ufLicenciamento, ')
          ..write('proprietarioCpf: $proprietarioCpf, ')
          ..write('proprietarioCnpj: $proprietarioCnpj, ')
          ..write('proprietarioRntrc: $proprietarioRntrc, ')
          ..write('proprietarioNome: $proprietarioNome, ')
          ..write('proprietarioIe: $proprietarioIe, ')
          ..write('proprietarioTipo: $proprietarioTipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idMdfeRodoviario,
      codigoInterno,
      placa,
      renavam,
      tara,
      capacidadeKg,
      capacidadeM3,
      tipoRodado,
      tipoCarroceria,
      ufLicenciamento,
      proprietarioCpf,
      proprietarioCnpj,
      proprietarioRntrc,
      proprietarioNome,
      proprietarioIe,
      proprietarioTipo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeRodoviarioVeiculo &&
          other.id == this.id &&
          other.idMdfeRodoviario == this.idMdfeRodoviario &&
          other.codigoInterno == this.codigoInterno &&
          other.placa == this.placa &&
          other.renavam == this.renavam &&
          other.tara == this.tara &&
          other.capacidadeKg == this.capacidadeKg &&
          other.capacidadeM3 == this.capacidadeM3 &&
          other.tipoRodado == this.tipoRodado &&
          other.tipoCarroceria == this.tipoCarroceria &&
          other.ufLicenciamento == this.ufLicenciamento &&
          other.proprietarioCpf == this.proprietarioCpf &&
          other.proprietarioCnpj == this.proprietarioCnpj &&
          other.proprietarioRntrc == this.proprietarioRntrc &&
          other.proprietarioNome == this.proprietarioNome &&
          other.proprietarioIe == this.proprietarioIe &&
          other.proprietarioTipo == this.proprietarioTipo);
}

class MdfeRodoviarioVeiculosCompanion
    extends UpdateCompanion<MdfeRodoviarioVeiculo> {
  final Value<int?> id;
  final Value<int?> idMdfeRodoviario;
  final Value<String?> codigoInterno;
  final Value<String?> placa;
  final Value<String?> renavam;
  final Value<int?> tara;
  final Value<int?> capacidadeKg;
  final Value<int?> capacidadeM3;
  final Value<String?> tipoRodado;
  final Value<String?> tipoCarroceria;
  final Value<String?> ufLicenciamento;
  final Value<String?> proprietarioCpf;
  final Value<String?> proprietarioCnpj;
  final Value<String?> proprietarioRntrc;
  final Value<String?> proprietarioNome;
  final Value<String?> proprietarioIe;
  final Value<int?> proprietarioTipo;
  const MdfeRodoviarioVeiculosCompanion({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.placa = const Value.absent(),
    this.renavam = const Value.absent(),
    this.tara = const Value.absent(),
    this.capacidadeKg = const Value.absent(),
    this.capacidadeM3 = const Value.absent(),
    this.tipoRodado = const Value.absent(),
    this.tipoCarroceria = const Value.absent(),
    this.ufLicenciamento = const Value.absent(),
    this.proprietarioCpf = const Value.absent(),
    this.proprietarioCnpj = const Value.absent(),
    this.proprietarioRntrc = const Value.absent(),
    this.proprietarioNome = const Value.absent(),
    this.proprietarioIe = const Value.absent(),
    this.proprietarioTipo = const Value.absent(),
  });
  MdfeRodoviarioVeiculosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.placa = const Value.absent(),
    this.renavam = const Value.absent(),
    this.tara = const Value.absent(),
    this.capacidadeKg = const Value.absent(),
    this.capacidadeM3 = const Value.absent(),
    this.tipoRodado = const Value.absent(),
    this.tipoCarroceria = const Value.absent(),
    this.ufLicenciamento = const Value.absent(),
    this.proprietarioCpf = const Value.absent(),
    this.proprietarioCnpj = const Value.absent(),
    this.proprietarioRntrc = const Value.absent(),
    this.proprietarioNome = const Value.absent(),
    this.proprietarioIe = const Value.absent(),
    this.proprietarioTipo = const Value.absent(),
  });
  static Insertable<MdfeRodoviarioVeiculo> custom({
    Expression<int>? id,
    Expression<int>? idMdfeRodoviario,
    Expression<String>? codigoInterno,
    Expression<String>? placa,
    Expression<String>? renavam,
    Expression<int>? tara,
    Expression<int>? capacidadeKg,
    Expression<int>? capacidadeM3,
    Expression<String>? tipoRodado,
    Expression<String>? tipoCarroceria,
    Expression<String>? ufLicenciamento,
    Expression<String>? proprietarioCpf,
    Expression<String>? proprietarioCnpj,
    Expression<String>? proprietarioRntrc,
    Expression<String>? proprietarioNome,
    Expression<String>? proprietarioIe,
    Expression<int>? proprietarioTipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeRodoviario != null) 'id_mdfe_rodoviario': idMdfeRodoviario,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (placa != null) 'placa': placa,
      if (renavam != null) 'renavam': renavam,
      if (tara != null) 'tara': tara,
      if (capacidadeKg != null) 'capacidade_kg': capacidadeKg,
      if (capacidadeM3 != null) 'capacidade_m3': capacidadeM3,
      if (tipoRodado != null) 'tipo_rodado': tipoRodado,
      if (tipoCarroceria != null) 'tipo_carroceria': tipoCarroceria,
      if (ufLicenciamento != null) 'uf_licenciamento': ufLicenciamento,
      if (proprietarioCpf != null) 'proprietario_cpf': proprietarioCpf,
      if (proprietarioCnpj != null) 'proprietario_cnpj': proprietarioCnpj,
      if (proprietarioRntrc != null) 'proprietario_rntrc': proprietarioRntrc,
      if (proprietarioNome != null) 'proprietario_nome': proprietarioNome,
      if (proprietarioIe != null) 'proprietario_ie': proprietarioIe,
      if (proprietarioTipo != null) 'proprietario_tipo': proprietarioTipo,
    });
  }

  MdfeRodoviarioVeiculosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeRodoviario,
      Value<String?>? codigoInterno,
      Value<String?>? placa,
      Value<String?>? renavam,
      Value<int?>? tara,
      Value<int?>? capacidadeKg,
      Value<int?>? capacidadeM3,
      Value<String?>? tipoRodado,
      Value<String?>? tipoCarroceria,
      Value<String?>? ufLicenciamento,
      Value<String?>? proprietarioCpf,
      Value<String?>? proprietarioCnpj,
      Value<String?>? proprietarioRntrc,
      Value<String?>? proprietarioNome,
      Value<String?>? proprietarioIe,
      Value<int?>? proprietarioTipo}) {
    return MdfeRodoviarioVeiculosCompanion(
      id: id ?? this.id,
      idMdfeRodoviario: idMdfeRodoviario ?? this.idMdfeRodoviario,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      placa: placa ?? this.placa,
      renavam: renavam ?? this.renavam,
      tara: tara ?? this.tara,
      capacidadeKg: capacidadeKg ?? this.capacidadeKg,
      capacidadeM3: capacidadeM3 ?? this.capacidadeM3,
      tipoRodado: tipoRodado ?? this.tipoRodado,
      tipoCarroceria: tipoCarroceria ?? this.tipoCarroceria,
      ufLicenciamento: ufLicenciamento ?? this.ufLicenciamento,
      proprietarioCpf: proprietarioCpf ?? this.proprietarioCpf,
      proprietarioCnpj: proprietarioCnpj ?? this.proprietarioCnpj,
      proprietarioRntrc: proprietarioRntrc ?? this.proprietarioRntrc,
      proprietarioNome: proprietarioNome ?? this.proprietarioNome,
      proprietarioIe: proprietarioIe ?? this.proprietarioIe,
      proprietarioTipo: proprietarioTipo ?? this.proprietarioTipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeRodoviario.present) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (placa.present) {
      map['placa'] = Variable<String>(placa.value);
    }
    if (renavam.present) {
      map['renavam'] = Variable<String>(renavam.value);
    }
    if (tara.present) {
      map['tara'] = Variable<int>(tara.value);
    }
    if (capacidadeKg.present) {
      map['capacidade_kg'] = Variable<int>(capacidadeKg.value);
    }
    if (capacidadeM3.present) {
      map['capacidade_m3'] = Variable<int>(capacidadeM3.value);
    }
    if (tipoRodado.present) {
      map['tipo_rodado'] = Variable<String>(tipoRodado.value);
    }
    if (tipoCarroceria.present) {
      map['tipo_carroceria'] = Variable<String>(tipoCarroceria.value);
    }
    if (ufLicenciamento.present) {
      map['uf_licenciamento'] = Variable<String>(ufLicenciamento.value);
    }
    if (proprietarioCpf.present) {
      map['proprietario_cpf'] = Variable<String>(proprietarioCpf.value);
    }
    if (proprietarioCnpj.present) {
      map['proprietario_cnpj'] = Variable<String>(proprietarioCnpj.value);
    }
    if (proprietarioRntrc.present) {
      map['proprietario_rntrc'] = Variable<String>(proprietarioRntrc.value);
    }
    if (proprietarioNome.present) {
      map['proprietario_nome'] = Variable<String>(proprietarioNome.value);
    }
    if (proprietarioIe.present) {
      map['proprietario_ie'] = Variable<String>(proprietarioIe.value);
    }
    if (proprietarioTipo.present) {
      map['proprietario_tipo'] = Variable<int>(proprietarioTipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioVeiculosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('placa: $placa, ')
          ..write('renavam: $renavam, ')
          ..write('tara: $tara, ')
          ..write('capacidadeKg: $capacidadeKg, ')
          ..write('capacidadeM3: $capacidadeM3, ')
          ..write('tipoRodado: $tipoRodado, ')
          ..write('tipoCarroceria: $tipoCarroceria, ')
          ..write('ufLicenciamento: $ufLicenciamento, ')
          ..write('proprietarioCpf: $proprietarioCpf, ')
          ..write('proprietarioCnpj: $proprietarioCnpj, ')
          ..write('proprietarioRntrc: $proprietarioRntrc, ')
          ..write('proprietarioNome: $proprietarioNome, ')
          ..write('proprietarioIe: $proprietarioIe, ')
          ..write('proprietarioTipo: $proprietarioTipo')
          ..write(')'))
        .toString();
  }
}

class $MdfeRodoviarioPedagiosTable extends MdfeRodoviarioPedagios
    with TableInfo<$MdfeRodoviarioPedagiosTable, MdfeRodoviarioPedagio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeRodoviarioPedagiosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeRodoviarioMeta =
      const VerificationMeta('idMdfeRodoviario');
  @override
  late final GeneratedColumn<int> idMdfeRodoviario = GeneratedColumn<int>(
      'id_mdfe_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjFornecedorMeta =
      const VerificationMeta('cnpjFornecedor');
  @override
  late final GeneratedColumn<String> cnpjFornecedor = GeneratedColumn<String>(
      'cnpj_fornecedor', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjResponsavelMeta =
      const VerificationMeta('cnpjResponsavel');
  @override
  late final GeneratedColumn<String> cnpjResponsavel = GeneratedColumn<String>(
      'cnpj_responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfResponsavelMeta =
      const VerificationMeta('cpfResponsavel');
  @override
  late final GeneratedColumn<String> cpfResponsavel = GeneratedColumn<String>(
      'cpf_responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroComprovanteMeta =
      const VerificationMeta('numeroComprovante');
  @override
  late final GeneratedColumn<String> numeroComprovante =
      GeneratedColumn<String>('numero_comprovante', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idMdfeRodoviario,
        cnpjFornecedor,
        cnpjResponsavel,
        cpfResponsavel,
        numeroComprovante,
        valor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_rodoviario_pedagio';
  @override
  VerificationContext validateIntegrity(
      Insertable<MdfeRodoviarioPedagio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_rodoviario')) {
      context.handle(
          _idMdfeRodoviarioMeta,
          idMdfeRodoviario.isAcceptableOrUnknown(
              data['id_mdfe_rodoviario']!, _idMdfeRodoviarioMeta));
    }
    if (data.containsKey('cnpj_fornecedor')) {
      context.handle(
          _cnpjFornecedorMeta,
          cnpjFornecedor.isAcceptableOrUnknown(
              data['cnpj_fornecedor']!, _cnpjFornecedorMeta));
    }
    if (data.containsKey('cnpj_responsavel')) {
      context.handle(
          _cnpjResponsavelMeta,
          cnpjResponsavel.isAcceptableOrUnknown(
              data['cnpj_responsavel']!, _cnpjResponsavelMeta));
    }
    if (data.containsKey('cpf_responsavel')) {
      context.handle(
          _cpfResponsavelMeta,
          cpfResponsavel.isAcceptableOrUnknown(
              data['cpf_responsavel']!, _cpfResponsavelMeta));
    }
    if (data.containsKey('numero_comprovante')) {
      context.handle(
          _numeroComprovanteMeta,
          numeroComprovante.isAcceptableOrUnknown(
              data['numero_comprovante']!, _numeroComprovanteMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeRodoviarioPedagio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeRodoviarioPedagio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_rodoviario']),
      cnpjFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj_fornecedor']),
      cnpjResponsavel: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cnpj_responsavel']),
      cpfResponsavel: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_responsavel']),
      numeroComprovante: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numero_comprovante']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $MdfeRodoviarioPedagiosTable createAlias(String alias) {
    return $MdfeRodoviarioPedagiosTable(attachedDatabase, alias);
  }
}

class MdfeRodoviarioPedagio extends DataClass
    implements Insertable<MdfeRodoviarioPedagio> {
  final int? id;
  final int? idMdfeRodoviario;
  final String? cnpjFornecedor;
  final String? cnpjResponsavel;
  final String? cpfResponsavel;
  final String? numeroComprovante;
  final double? valor;
  const MdfeRodoviarioPedagio(
      {this.id,
      this.idMdfeRodoviario,
      this.cnpjFornecedor,
      this.cnpjResponsavel,
      this.cpfResponsavel,
      this.numeroComprovante,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeRodoviario != null) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario);
    }
    if (!nullToAbsent || cnpjFornecedor != null) {
      map['cnpj_fornecedor'] = Variable<String>(cnpjFornecedor);
    }
    if (!nullToAbsent || cnpjResponsavel != null) {
      map['cnpj_responsavel'] = Variable<String>(cnpjResponsavel);
    }
    if (!nullToAbsent || cpfResponsavel != null) {
      map['cpf_responsavel'] = Variable<String>(cpfResponsavel);
    }
    if (!nullToAbsent || numeroComprovante != null) {
      map['numero_comprovante'] = Variable<String>(numeroComprovante);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory MdfeRodoviarioPedagio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeRodoviarioPedagio(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeRodoviario: serializer.fromJson<int?>(json['idMdfeRodoviario']),
      cnpjFornecedor: serializer.fromJson<String?>(json['cnpjFornecedor']),
      cnpjResponsavel: serializer.fromJson<String?>(json['cnpjResponsavel']),
      cpfResponsavel: serializer.fromJson<String?>(json['cpfResponsavel']),
      numeroComprovante:
          serializer.fromJson<String?>(json['numeroComprovante']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeRodoviario': serializer.toJson<int?>(idMdfeRodoviario),
      'cnpjFornecedor': serializer.toJson<String?>(cnpjFornecedor),
      'cnpjResponsavel': serializer.toJson<String?>(cnpjResponsavel),
      'cpfResponsavel': serializer.toJson<String?>(cpfResponsavel),
      'numeroComprovante': serializer.toJson<String?>(numeroComprovante),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  MdfeRodoviarioPedagio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeRodoviario = const Value.absent(),
          Value<String?> cnpjFornecedor = const Value.absent(),
          Value<String?> cnpjResponsavel = const Value.absent(),
          Value<String?> cpfResponsavel = const Value.absent(),
          Value<String?> numeroComprovante = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      MdfeRodoviarioPedagio(
        id: id.present ? id.value : this.id,
        idMdfeRodoviario: idMdfeRodoviario.present
            ? idMdfeRodoviario.value
            : this.idMdfeRodoviario,
        cnpjFornecedor:
            cnpjFornecedor.present ? cnpjFornecedor.value : this.cnpjFornecedor,
        cnpjResponsavel: cnpjResponsavel.present
            ? cnpjResponsavel.value
            : this.cnpjResponsavel,
        cpfResponsavel:
            cpfResponsavel.present ? cpfResponsavel.value : this.cpfResponsavel,
        numeroComprovante: numeroComprovante.present
            ? numeroComprovante.value
            : this.numeroComprovante,
        valor: valor.present ? valor.value : this.valor,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioPedagio(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('cnpjFornecedor: $cnpjFornecedor, ')
          ..write('cnpjResponsavel: $cnpjResponsavel, ')
          ..write('cpfResponsavel: $cpfResponsavel, ')
          ..write('numeroComprovante: $numeroComprovante, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeRodoviario, cnpjFornecedor,
      cnpjResponsavel, cpfResponsavel, numeroComprovante, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeRodoviarioPedagio &&
          other.id == this.id &&
          other.idMdfeRodoviario == this.idMdfeRodoviario &&
          other.cnpjFornecedor == this.cnpjFornecedor &&
          other.cnpjResponsavel == this.cnpjResponsavel &&
          other.cpfResponsavel == this.cpfResponsavel &&
          other.numeroComprovante == this.numeroComprovante &&
          other.valor == this.valor);
}

class MdfeRodoviarioPedagiosCompanion
    extends UpdateCompanion<MdfeRodoviarioPedagio> {
  final Value<int?> id;
  final Value<int?> idMdfeRodoviario;
  final Value<String?> cnpjFornecedor;
  final Value<String?> cnpjResponsavel;
  final Value<String?> cpfResponsavel;
  final Value<String?> numeroComprovante;
  final Value<double?> valor;
  const MdfeRodoviarioPedagiosCompanion({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.cnpjFornecedor = const Value.absent(),
    this.cnpjResponsavel = const Value.absent(),
    this.cpfResponsavel = const Value.absent(),
    this.numeroComprovante = const Value.absent(),
    this.valor = const Value.absent(),
  });
  MdfeRodoviarioPedagiosCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.cnpjFornecedor = const Value.absent(),
    this.cnpjResponsavel = const Value.absent(),
    this.cpfResponsavel = const Value.absent(),
    this.numeroComprovante = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<MdfeRodoviarioPedagio> custom({
    Expression<int>? id,
    Expression<int>? idMdfeRodoviario,
    Expression<String>? cnpjFornecedor,
    Expression<String>? cnpjResponsavel,
    Expression<String>? cpfResponsavel,
    Expression<String>? numeroComprovante,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeRodoviario != null) 'id_mdfe_rodoviario': idMdfeRodoviario,
      if (cnpjFornecedor != null) 'cnpj_fornecedor': cnpjFornecedor,
      if (cnpjResponsavel != null) 'cnpj_responsavel': cnpjResponsavel,
      if (cpfResponsavel != null) 'cpf_responsavel': cpfResponsavel,
      if (numeroComprovante != null) 'numero_comprovante': numeroComprovante,
      if (valor != null) 'valor': valor,
    });
  }

  MdfeRodoviarioPedagiosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeRodoviario,
      Value<String?>? cnpjFornecedor,
      Value<String?>? cnpjResponsavel,
      Value<String?>? cpfResponsavel,
      Value<String?>? numeroComprovante,
      Value<double?>? valor}) {
    return MdfeRodoviarioPedagiosCompanion(
      id: id ?? this.id,
      idMdfeRodoviario: idMdfeRodoviario ?? this.idMdfeRodoviario,
      cnpjFornecedor: cnpjFornecedor ?? this.cnpjFornecedor,
      cnpjResponsavel: cnpjResponsavel ?? this.cnpjResponsavel,
      cpfResponsavel: cpfResponsavel ?? this.cpfResponsavel,
      numeroComprovante: numeroComprovante ?? this.numeroComprovante,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeRodoviario.present) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario.value);
    }
    if (cnpjFornecedor.present) {
      map['cnpj_fornecedor'] = Variable<String>(cnpjFornecedor.value);
    }
    if (cnpjResponsavel.present) {
      map['cnpj_responsavel'] = Variable<String>(cnpjResponsavel.value);
    }
    if (cpfResponsavel.present) {
      map['cpf_responsavel'] = Variable<String>(cpfResponsavel.value);
    }
    if (numeroComprovante.present) {
      map['numero_comprovante'] = Variable<String>(numeroComprovante.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioPedagiosCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('cnpjFornecedor: $cnpjFornecedor, ')
          ..write('cnpjResponsavel: $cnpjResponsavel, ')
          ..write('cpfResponsavel: $cpfResponsavel, ')
          ..write('numeroComprovante: $numeroComprovante, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $MdfeRodoviarioCiotsTable extends MdfeRodoviarioCiots
    with TableInfo<$MdfeRodoviarioCiotsTable, MdfeRodoviarioCiot> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MdfeRodoviarioCiotsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idMdfeRodoviarioMeta =
      const VerificationMeta('idMdfeRodoviario');
  @override
  late final GeneratedColumn<int> idMdfeRodoviario = GeneratedColumn<int>(
      'id_mdfe_rodoviario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ciotMeta = const VerificationMeta('ciot');
  @override
  late final GeneratedColumn<String> ciot = GeneratedColumn<String>(
      'ciot', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 12),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
      'cpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idMdfeRodoviario, ciot, cpf, cnpj];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mdfe_rodoviario_ciot';
  @override
  VerificationContext validateIntegrity(Insertable<MdfeRodoviarioCiot> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_mdfe_rodoviario')) {
      context.handle(
          _idMdfeRodoviarioMeta,
          idMdfeRodoviario.isAcceptableOrUnknown(
              data['id_mdfe_rodoviario']!, _idMdfeRodoviarioMeta));
    }
    if (data.containsKey('ciot')) {
      context.handle(
          _ciotMeta, ciot.isAcceptableOrUnknown(data['ciot']!, _ciotMeta));
    }
    if (data.containsKey('cpf')) {
      context.handle(
          _cpfMeta, cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MdfeRodoviarioCiot map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MdfeRodoviarioCiot(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idMdfeRodoviario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_mdfe_rodoviario']),
      ciot: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ciot']),
      cpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
    );
  }

  @override
  $MdfeRodoviarioCiotsTable createAlias(String alias) {
    return $MdfeRodoviarioCiotsTable(attachedDatabase, alias);
  }
}

class MdfeRodoviarioCiot extends DataClass
    implements Insertable<MdfeRodoviarioCiot> {
  final int? id;
  final int? idMdfeRodoviario;
  final String? ciot;
  final String? cpf;
  final String? cnpj;
  const MdfeRodoviarioCiot(
      {this.id, this.idMdfeRodoviario, this.ciot, this.cpf, this.cnpj});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idMdfeRodoviario != null) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario);
    }
    if (!nullToAbsent || ciot != null) {
      map['ciot'] = Variable<String>(ciot);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    return map;
  }

  factory MdfeRodoviarioCiot.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MdfeRodoviarioCiot(
      id: serializer.fromJson<int?>(json['id']),
      idMdfeRodoviario: serializer.fromJson<int?>(json['idMdfeRodoviario']),
      ciot: serializer.fromJson<String?>(json['ciot']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idMdfeRodoviario': serializer.toJson<int?>(idMdfeRodoviario),
      'ciot': serializer.toJson<String?>(ciot),
      'cpf': serializer.toJson<String?>(cpf),
      'cnpj': serializer.toJson<String?>(cnpj),
    };
  }

  MdfeRodoviarioCiot copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idMdfeRodoviario = const Value.absent(),
          Value<String?> ciot = const Value.absent(),
          Value<String?> cpf = const Value.absent(),
          Value<String?> cnpj = const Value.absent()}) =>
      MdfeRodoviarioCiot(
        id: id.present ? id.value : this.id,
        idMdfeRodoviario: idMdfeRodoviario.present
            ? idMdfeRodoviario.value
            : this.idMdfeRodoviario,
        ciot: ciot.present ? ciot.value : this.ciot,
        cpf: cpf.present ? cpf.value : this.cpf,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
      );
  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioCiot(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('ciot: $ciot, ')
          ..write('cpf: $cpf, ')
          ..write('cnpj: $cnpj')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idMdfeRodoviario, ciot, cpf, cnpj);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MdfeRodoviarioCiot &&
          other.id == this.id &&
          other.idMdfeRodoviario == this.idMdfeRodoviario &&
          other.ciot == this.ciot &&
          other.cpf == this.cpf &&
          other.cnpj == this.cnpj);
}

class MdfeRodoviarioCiotsCompanion extends UpdateCompanion<MdfeRodoviarioCiot> {
  final Value<int?> id;
  final Value<int?> idMdfeRodoviario;
  final Value<String?> ciot;
  final Value<String?> cpf;
  final Value<String?> cnpj;
  const MdfeRodoviarioCiotsCompanion({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.ciot = const Value.absent(),
    this.cpf = const Value.absent(),
    this.cnpj = const Value.absent(),
  });
  MdfeRodoviarioCiotsCompanion.insert({
    this.id = const Value.absent(),
    this.idMdfeRodoviario = const Value.absent(),
    this.ciot = const Value.absent(),
    this.cpf = const Value.absent(),
    this.cnpj = const Value.absent(),
  });
  static Insertable<MdfeRodoviarioCiot> custom({
    Expression<int>? id,
    Expression<int>? idMdfeRodoviario,
    Expression<String>? ciot,
    Expression<String>? cpf,
    Expression<String>? cnpj,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idMdfeRodoviario != null) 'id_mdfe_rodoviario': idMdfeRodoviario,
      if (ciot != null) 'ciot': ciot,
      if (cpf != null) 'cpf': cpf,
      if (cnpj != null) 'cnpj': cnpj,
    });
  }

  MdfeRodoviarioCiotsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idMdfeRodoviario,
      Value<String?>? ciot,
      Value<String?>? cpf,
      Value<String?>? cnpj}) {
    return MdfeRodoviarioCiotsCompanion(
      id: id ?? this.id,
      idMdfeRodoviario: idMdfeRodoviario ?? this.idMdfeRodoviario,
      ciot: ciot ?? this.ciot,
      cpf: cpf ?? this.cpf,
      cnpj: cnpj ?? this.cnpj,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idMdfeRodoviario.present) {
      map['id_mdfe_rodoviario'] = Variable<int>(idMdfeRodoviario.value);
    }
    if (ciot.present) {
      map['ciot'] = Variable<String>(ciot.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MdfeRodoviarioCiotsCompanion(')
          ..write('id: $id, ')
          ..write('idMdfeRodoviario: $idMdfeRodoviario, ')
          ..write('ciot: $ciot, ')
          ..write('cpf: $cpf, ')
          ..write('cnpj: $cnpj')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $MdfeLacresTable mdfeLacres = $MdfeLacresTable(this);
  late final $MdfeMunicipioDescarregasTable mdfeMunicipioDescarregas =
      $MdfeMunicipioDescarregasTable(this);
  late final $MdfeEmitentesTable mdfeEmitentes = $MdfeEmitentesTable(this);
  late final $MdfePercursosTable mdfePercursos = $MdfePercursosTable(this);
  late final $MdfeMunicipioCarregamentosTable mdfeMunicipioCarregamentos =
      $MdfeMunicipioCarregamentosTable(this);
  late final $MdfeRodoviariosTable mdfeRodoviarios =
      $MdfeRodoviariosTable(this);
  late final $MdfeInformacaoSegurosTable mdfeInformacaoSeguros =
      $MdfeInformacaoSegurosTable(this);
  late final $MdfeCabecalhosTable mdfeCabecalhos = $MdfeCabecalhosTable(this);
  late final $MdfeInformacaoCtesTable mdfeInformacaoCtes =
      $MdfeInformacaoCtesTable(this);
  late final $MdfeInformacaoNfesTable mdfeInformacaoNfes =
      $MdfeInformacaoNfesTable(this);
  late final $MdfeRodoviarioMotoristasTable mdfeRodoviarioMotoristas =
      $MdfeRodoviarioMotoristasTable(this);
  late final $MdfeRodoviarioVeiculosTable mdfeRodoviarioVeiculos =
      $MdfeRodoviarioVeiculosTable(this);
  late final $MdfeRodoviarioPedagiosTable mdfeRodoviarioPedagios =
      $MdfeRodoviarioPedagiosTable(this);
  late final $MdfeRodoviarioCiotsTable mdfeRodoviarioCiots =
      $MdfeRodoviarioCiotsTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final MdfeCabecalhoDao mdfeCabecalhoDao =
      MdfeCabecalhoDao(this as AppDatabase);
  late final MdfeInformacaoCteDao mdfeInformacaoCteDao =
      MdfeInformacaoCteDao(this as AppDatabase);
  late final MdfeInformacaoNfeDao mdfeInformacaoNfeDao =
      MdfeInformacaoNfeDao(this as AppDatabase);
  late final MdfeRodoviarioMotoristaDao mdfeRodoviarioMotoristaDao =
      MdfeRodoviarioMotoristaDao(this as AppDatabase);
  late final MdfeRodoviarioVeiculoDao mdfeRodoviarioVeiculoDao =
      MdfeRodoviarioVeiculoDao(this as AppDatabase);
  late final MdfeRodoviarioPedagioDao mdfeRodoviarioPedagioDao =
      MdfeRodoviarioPedagioDao(this as AppDatabase);
  late final MdfeRodoviarioCiotDao mdfeRodoviarioCiotDao =
      MdfeRodoviarioCiotDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        mdfeLacres,
        mdfeMunicipioDescarregas,
        mdfeEmitentes,
        mdfePercursos,
        mdfeMunicipioCarregamentos,
        mdfeRodoviarios,
        mdfeInformacaoSeguros,
        mdfeCabecalhos,
        mdfeInformacaoCtes,
        mdfeInformacaoNfes,
        mdfeRodoviarioMotoristas,
        mdfeRodoviarioVeiculos,
        mdfeRodoviarioPedagios,
        mdfeRodoviarioCiots,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
