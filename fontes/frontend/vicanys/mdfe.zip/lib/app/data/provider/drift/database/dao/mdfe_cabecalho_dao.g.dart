// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeCabecalhosTable get mdfeCabecalhos => attachedDatabase.mdfeCabecalhos;
  $MdfeLacresTable get mdfeLacres => attachedDatabase.mdfeLacres;
  $MdfeMunicipioDescarregasTable get mdfeMunicipioDescarregas =>
      attachedDatabase.mdfeMunicipioDescarregas;
  $MdfeEmitentesTable get mdfeEmitentes => attachedDatabase.mdfeEmitentes;
  $MdfePercursosTable get mdfePercursos => attachedDatabase.mdfePercursos;
  $MdfeMunicipioCarregamentosTable get mdfeMunicipioCarregamentos =>
      attachedDatabase.mdfeMunicipioCarregamentos;
  $MdfeRodoviariosTable get mdfeRodoviarios => attachedDatabase.mdfeRodoviarios;
  $MdfeInformacaoSegurosTable get mdfeInformacaoSeguros =>
      attachedDatabase.mdfeInformacaoSeguros;
}
