// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_rodoviario_motorista_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeRodoviarioMotoristaDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeRodoviarioMotoristasTable get mdfeRodoviarioMotoristas =>
      attachedDatabase.mdfeRodoviarioMotoristas;
  $MdfeRodoviariosTable get mdfeRodoviarios => attachedDatabase.mdfeRodoviarios;
}
