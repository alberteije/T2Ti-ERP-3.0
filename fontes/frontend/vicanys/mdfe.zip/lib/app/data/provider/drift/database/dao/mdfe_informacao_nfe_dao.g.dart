// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_informacao_nfe_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeInformacaoNfeDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeInformacaoNfesTable get mdfeInformacaoNfes =>
      attachedDatabase.mdfeInformacaoNfes;
  $MdfeMunicipioDescarregasTable get mdfeMunicipioDescarregas =>
      attachedDatabase.mdfeMunicipioDescarregas;
}
