// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_estadual_porte_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalEstadualPorteDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalEstadualPortesTable get fiscalEstadualPortes =>
      attachedDatabase.fiscalEstadualPortes;
}
