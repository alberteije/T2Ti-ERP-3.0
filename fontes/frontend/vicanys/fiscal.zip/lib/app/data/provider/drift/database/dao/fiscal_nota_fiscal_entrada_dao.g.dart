// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_nota_fiscal_entrada_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalNotaFiscalEntradaDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalNotaFiscalEntradasTable get fiscalNotaFiscalEntradas =>
      attachedDatabase.fiscalNotaFiscalEntradas;
  $NfeCabecalhosTable get nfeCabecalhos => attachedDatabase.nfeCabecalhos;
}
