// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fiscal_parametro_dao.dart';

// ignore_for_file: type=lint
mixin _$FiscalParametroDaoMixin on DatabaseAccessor<AppDatabase> {
  $FiscalParametrosTable get fiscalParametros =>
      attachedDatabase.fiscalParametros;
  $FiscalInscricoesSubstitutassTable get fiscalInscricoesSubstitutass =>
      attachedDatabase.fiscalInscricoesSubstitutass;
  $FiscalEstadualRegimesTable get fiscalEstadualRegimes =>
      attachedDatabase.fiscalEstadualRegimes;
  $FiscalEstadualPortesTable get fiscalEstadualPortes =>
      attachedDatabase.fiscalEstadualPortes;
  $FiscalMunicipalRegimesTable get fiscalMunicipalRegimes =>
      attachedDatabase.fiscalMunicipalRegimes;
}
