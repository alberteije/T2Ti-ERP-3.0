// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $FiscalTermosTable extends FiscalTermos
    with TableInfo<$FiscalTermosTable, FiscalTermo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalTermosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFiscalLivroMeta =
      const VerificationMeta('idFiscalLivro');
  @override
  late final GeneratedColumn<int> idFiscalLivro = GeneratedColumn<int>(
      'id_fiscal_livro', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _aberturaEncerramentoMeta =
      const VerificationMeta('aberturaEncerramento');
  @override
  late final GeneratedColumn<String> aberturaEncerramento =
      GeneratedColumn<String>(
          'abertura_encerramento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
      'numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _paginaInicialMeta =
      const VerificationMeta('paginaInicial');
  @override
  late final GeneratedColumn<int> paginaInicial = GeneratedColumn<int>(
      'pagina_inicial', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _paginaFinalMeta =
      const VerificationMeta('paginaFinal');
  @override
  late final GeneratedColumn<int> paginaFinal = GeneratedColumn<int>(
      'pagina_final', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroRegistroMeta =
      const VerificationMeta('numeroRegistro');
  @override
  late final GeneratedColumn<String> numeroRegistro = GeneratedColumn<String>(
      'numero_registro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _registradoMeta =
      const VerificationMeta('registrado');
  @override
  late final GeneratedColumn<String> registrado = GeneratedColumn<String>(
      'registrado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataDespachoMeta =
      const VerificationMeta('dataDespacho');
  @override
  late final GeneratedColumn<DateTime> dataDespacho = GeneratedColumn<DateTime>(
      'data_despacho', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAberturaMeta =
      const VerificationMeta('dataAbertura');
  @override
  late final GeneratedColumn<DateTime> dataAbertura = GeneratedColumn<DateTime>(
      'data_abertura', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataEncerramentoMeta =
      const VerificationMeta('dataEncerramento');
  @override
  late final GeneratedColumn<DateTime> dataEncerramento =
      GeneratedColumn<DateTime>('data_encerramento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _escrituracaoInicioMeta =
      const VerificationMeta('escrituracaoInicio');
  @override
  late final GeneratedColumn<DateTime> escrituracaoInicio =
      GeneratedColumn<DateTime>('escrituracao_inicio', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _escrituracaoFimMeta =
      const VerificationMeta('escrituracaoFim');
  @override
  late final GeneratedColumn<DateTime> escrituracaoFim =
      GeneratedColumn<DateTime>('escrituracao_fim', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _textoMeta = const VerificationMeta('texto');
  @override
  late final GeneratedColumn<String> texto = GeneratedColumn<String>(
      'texto', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFiscalLivro,
        aberturaEncerramento,
        numero,
        paginaInicial,
        paginaFinal,
        numeroRegistro,
        registrado,
        dataDespacho,
        dataAbertura,
        dataEncerramento,
        escrituracaoInicio,
        escrituracaoFim,
        texto
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_termo';
  @override
  VerificationContext validateIntegrity(Insertable<FiscalTermo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_fiscal_livro')) {
      context.handle(
          _idFiscalLivroMeta,
          idFiscalLivro.isAcceptableOrUnknown(
              data['id_fiscal_livro']!, _idFiscalLivroMeta));
    }
    if (data.containsKey('abertura_encerramento')) {
      context.handle(
          _aberturaEncerramentoMeta,
          aberturaEncerramento.isAcceptableOrUnknown(
              data['abertura_encerramento']!, _aberturaEncerramentoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('pagina_inicial')) {
      context.handle(
          _paginaInicialMeta,
          paginaInicial.isAcceptableOrUnknown(
              data['pagina_inicial']!, _paginaInicialMeta));
    }
    if (data.containsKey('pagina_final')) {
      context.handle(
          _paginaFinalMeta,
          paginaFinal.isAcceptableOrUnknown(
              data['pagina_final']!, _paginaFinalMeta));
    }
    if (data.containsKey('numero_registro')) {
      context.handle(
          _numeroRegistroMeta,
          numeroRegistro.isAcceptableOrUnknown(
              data['numero_registro']!, _numeroRegistroMeta));
    }
    if (data.containsKey('registrado')) {
      context.handle(
          _registradoMeta,
          registrado.isAcceptableOrUnknown(
              data['registrado']!, _registradoMeta));
    }
    if (data.containsKey('data_despacho')) {
      context.handle(
          _dataDespachoMeta,
          dataDespacho.isAcceptableOrUnknown(
              data['data_despacho']!, _dataDespachoMeta));
    }
    if (data.containsKey('data_abertura')) {
      context.handle(
          _dataAberturaMeta,
          dataAbertura.isAcceptableOrUnknown(
              data['data_abertura']!, _dataAberturaMeta));
    }
    if (data.containsKey('data_encerramento')) {
      context.handle(
          _dataEncerramentoMeta,
          dataEncerramento.isAcceptableOrUnknown(
              data['data_encerramento']!, _dataEncerramentoMeta));
    }
    if (data.containsKey('escrituracao_inicio')) {
      context.handle(
          _escrituracaoInicioMeta,
          escrituracaoInicio.isAcceptableOrUnknown(
              data['escrituracao_inicio']!, _escrituracaoInicioMeta));
    }
    if (data.containsKey('escrituracao_fim')) {
      context.handle(
          _escrituracaoFimMeta,
          escrituracaoFim.isAcceptableOrUnknown(
              data['escrituracao_fim']!, _escrituracaoFimMeta));
    }
    if (data.containsKey('texto')) {
      context.handle(
          _textoMeta, texto.isAcceptableOrUnknown(data['texto']!, _textoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalTermo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalTermo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFiscalLivro: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fiscal_livro']),
      aberturaEncerramento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}abertura_encerramento']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero']),
      paginaInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pagina_inicial']),
      paginaFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pagina_final']),
      numeroRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_registro']),
      registrado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}registrado']),
      dataDespacho: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_despacho']),
      dataAbertura: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_abertura']),
      dataEncerramento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_encerramento']),
      escrituracaoInicio: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}escrituracao_inicio']),
      escrituracaoFim: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}escrituracao_fim']),
      texto: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}texto']),
    );
  }

  @override
  $FiscalTermosTable createAlias(String alias) {
    return $FiscalTermosTable(attachedDatabase, alias);
  }
}

class FiscalTermo extends DataClass implements Insertable<FiscalTermo> {
  final int? id;
  final int? idFiscalLivro;
  final String? aberturaEncerramento;
  final int? numero;
  final int? paginaInicial;
  final int? paginaFinal;
  final String? numeroRegistro;
  final String? registrado;
  final DateTime? dataDespacho;
  final DateTime? dataAbertura;
  final DateTime? dataEncerramento;
  final DateTime? escrituracaoInicio;
  final DateTime? escrituracaoFim;
  final String? texto;
  const FiscalTermo(
      {this.id,
      this.idFiscalLivro,
      this.aberturaEncerramento,
      this.numero,
      this.paginaInicial,
      this.paginaFinal,
      this.numeroRegistro,
      this.registrado,
      this.dataDespacho,
      this.dataAbertura,
      this.dataEncerramento,
      this.escrituracaoInicio,
      this.escrituracaoFim,
      this.texto});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFiscalLivro != null) {
      map['id_fiscal_livro'] = Variable<int>(idFiscalLivro);
    }
    if (!nullToAbsent || aberturaEncerramento != null) {
      map['abertura_encerramento'] = Variable<String>(aberturaEncerramento);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || paginaInicial != null) {
      map['pagina_inicial'] = Variable<int>(paginaInicial);
    }
    if (!nullToAbsent || paginaFinal != null) {
      map['pagina_final'] = Variable<int>(paginaFinal);
    }
    if (!nullToAbsent || numeroRegistro != null) {
      map['numero_registro'] = Variable<String>(numeroRegistro);
    }
    if (!nullToAbsent || registrado != null) {
      map['registrado'] = Variable<String>(registrado);
    }
    if (!nullToAbsent || dataDespacho != null) {
      map['data_despacho'] = Variable<DateTime>(dataDespacho);
    }
    if (!nullToAbsent || dataAbertura != null) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura);
    }
    if (!nullToAbsent || dataEncerramento != null) {
      map['data_encerramento'] = Variable<DateTime>(dataEncerramento);
    }
    if (!nullToAbsent || escrituracaoInicio != null) {
      map['escrituracao_inicio'] = Variable<DateTime>(escrituracaoInicio);
    }
    if (!nullToAbsent || escrituracaoFim != null) {
      map['escrituracao_fim'] = Variable<DateTime>(escrituracaoFim);
    }
    if (!nullToAbsent || texto != null) {
      map['texto'] = Variable<String>(texto);
    }
    return map;
  }

  factory FiscalTermo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalTermo(
      id: serializer.fromJson<int?>(json['id']),
      idFiscalLivro: serializer.fromJson<int?>(json['idFiscalLivro']),
      aberturaEncerramento:
          serializer.fromJson<String?>(json['aberturaEncerramento']),
      numero: serializer.fromJson<int?>(json['numero']),
      paginaInicial: serializer.fromJson<int?>(json['paginaInicial']),
      paginaFinal: serializer.fromJson<int?>(json['paginaFinal']),
      numeroRegistro: serializer.fromJson<String?>(json['numeroRegistro']),
      registrado: serializer.fromJson<String?>(json['registrado']),
      dataDespacho: serializer.fromJson<DateTime?>(json['dataDespacho']),
      dataAbertura: serializer.fromJson<DateTime?>(json['dataAbertura']),
      dataEncerramento:
          serializer.fromJson<DateTime?>(json['dataEncerramento']),
      escrituracaoInicio:
          serializer.fromJson<DateTime?>(json['escrituracaoInicio']),
      escrituracaoFim: serializer.fromJson<DateTime?>(json['escrituracaoFim']),
      texto: serializer.fromJson<String?>(json['texto']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFiscalLivro': serializer.toJson<int?>(idFiscalLivro),
      'aberturaEncerramento': serializer.toJson<String?>(aberturaEncerramento),
      'numero': serializer.toJson<int?>(numero),
      'paginaInicial': serializer.toJson<int?>(paginaInicial),
      'paginaFinal': serializer.toJson<int?>(paginaFinal),
      'numeroRegistro': serializer.toJson<String?>(numeroRegistro),
      'registrado': serializer.toJson<String?>(registrado),
      'dataDespacho': serializer.toJson<DateTime?>(dataDespacho),
      'dataAbertura': serializer.toJson<DateTime?>(dataAbertura),
      'dataEncerramento': serializer.toJson<DateTime?>(dataEncerramento),
      'escrituracaoInicio': serializer.toJson<DateTime?>(escrituracaoInicio),
      'escrituracaoFim': serializer.toJson<DateTime?>(escrituracaoFim),
      'texto': serializer.toJson<String?>(texto),
    };
  }

  FiscalTermo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFiscalLivro = const Value.absent(),
          Value<String?> aberturaEncerramento = const Value.absent(),
          Value<int?> numero = const Value.absent(),
          Value<int?> paginaInicial = const Value.absent(),
          Value<int?> paginaFinal = const Value.absent(),
          Value<String?> numeroRegistro = const Value.absent(),
          Value<String?> registrado = const Value.absent(),
          Value<DateTime?> dataDespacho = const Value.absent(),
          Value<DateTime?> dataAbertura = const Value.absent(),
          Value<DateTime?> dataEncerramento = const Value.absent(),
          Value<DateTime?> escrituracaoInicio = const Value.absent(),
          Value<DateTime?> escrituracaoFim = const Value.absent(),
          Value<String?> texto = const Value.absent()}) =>
      FiscalTermo(
        id: id.present ? id.value : this.id,
        idFiscalLivro:
            idFiscalLivro.present ? idFiscalLivro.value : this.idFiscalLivro,
        aberturaEncerramento: aberturaEncerramento.present
            ? aberturaEncerramento.value
            : this.aberturaEncerramento,
        numero: numero.present ? numero.value : this.numero,
        paginaInicial:
            paginaInicial.present ? paginaInicial.value : this.paginaInicial,
        paginaFinal: paginaFinal.present ? paginaFinal.value : this.paginaFinal,
        numeroRegistro:
            numeroRegistro.present ? numeroRegistro.value : this.numeroRegistro,
        registrado: registrado.present ? registrado.value : this.registrado,
        dataDespacho:
            dataDespacho.present ? dataDespacho.value : this.dataDespacho,
        dataAbertura:
            dataAbertura.present ? dataAbertura.value : this.dataAbertura,
        dataEncerramento: dataEncerramento.present
            ? dataEncerramento.value
            : this.dataEncerramento,
        escrituracaoInicio: escrituracaoInicio.present
            ? escrituracaoInicio.value
            : this.escrituracaoInicio,
        escrituracaoFim: escrituracaoFim.present
            ? escrituracaoFim.value
            : this.escrituracaoFim,
        texto: texto.present ? texto.value : this.texto,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalTermo(')
          ..write('id: $id, ')
          ..write('idFiscalLivro: $idFiscalLivro, ')
          ..write('aberturaEncerramento: $aberturaEncerramento, ')
          ..write('numero: $numero, ')
          ..write('paginaInicial: $paginaInicial, ')
          ..write('paginaFinal: $paginaFinal, ')
          ..write('numeroRegistro: $numeroRegistro, ')
          ..write('registrado: $registrado, ')
          ..write('dataDespacho: $dataDespacho, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataEncerramento: $dataEncerramento, ')
          ..write('escrituracaoInicio: $escrituracaoInicio, ')
          ..write('escrituracaoFim: $escrituracaoFim, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idFiscalLivro,
      aberturaEncerramento,
      numero,
      paginaInicial,
      paginaFinal,
      numeroRegistro,
      registrado,
      dataDespacho,
      dataAbertura,
      dataEncerramento,
      escrituracaoInicio,
      escrituracaoFim,
      texto);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalTermo &&
          other.id == this.id &&
          other.idFiscalLivro == this.idFiscalLivro &&
          other.aberturaEncerramento == this.aberturaEncerramento &&
          other.numero == this.numero &&
          other.paginaInicial == this.paginaInicial &&
          other.paginaFinal == this.paginaFinal &&
          other.numeroRegistro == this.numeroRegistro &&
          other.registrado == this.registrado &&
          other.dataDespacho == this.dataDespacho &&
          other.dataAbertura == this.dataAbertura &&
          other.dataEncerramento == this.dataEncerramento &&
          other.escrituracaoInicio == this.escrituracaoInicio &&
          other.escrituracaoFim == this.escrituracaoFim &&
          other.texto == this.texto);
}

class FiscalTermosCompanion extends UpdateCompanion<FiscalTermo> {
  final Value<int?> id;
  final Value<int?> idFiscalLivro;
  final Value<String?> aberturaEncerramento;
  final Value<int?> numero;
  final Value<int?> paginaInicial;
  final Value<int?> paginaFinal;
  final Value<String?> numeroRegistro;
  final Value<String?> registrado;
  final Value<DateTime?> dataDespacho;
  final Value<DateTime?> dataAbertura;
  final Value<DateTime?> dataEncerramento;
  final Value<DateTime?> escrituracaoInicio;
  final Value<DateTime?> escrituracaoFim;
  final Value<String?> texto;
  const FiscalTermosCompanion({
    this.id = const Value.absent(),
    this.idFiscalLivro = const Value.absent(),
    this.aberturaEncerramento = const Value.absent(),
    this.numero = const Value.absent(),
    this.paginaInicial = const Value.absent(),
    this.paginaFinal = const Value.absent(),
    this.numeroRegistro = const Value.absent(),
    this.registrado = const Value.absent(),
    this.dataDespacho = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataEncerramento = const Value.absent(),
    this.escrituracaoInicio = const Value.absent(),
    this.escrituracaoFim = const Value.absent(),
    this.texto = const Value.absent(),
  });
  FiscalTermosCompanion.insert({
    this.id = const Value.absent(),
    this.idFiscalLivro = const Value.absent(),
    this.aberturaEncerramento = const Value.absent(),
    this.numero = const Value.absent(),
    this.paginaInicial = const Value.absent(),
    this.paginaFinal = const Value.absent(),
    this.numeroRegistro = const Value.absent(),
    this.registrado = const Value.absent(),
    this.dataDespacho = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataEncerramento = const Value.absent(),
    this.escrituracaoInicio = const Value.absent(),
    this.escrituracaoFim = const Value.absent(),
    this.texto = const Value.absent(),
  });
  static Insertable<FiscalTermo> custom({
    Expression<int>? id,
    Expression<int>? idFiscalLivro,
    Expression<String>? aberturaEncerramento,
    Expression<int>? numero,
    Expression<int>? paginaInicial,
    Expression<int>? paginaFinal,
    Expression<String>? numeroRegistro,
    Expression<String>? registrado,
    Expression<DateTime>? dataDespacho,
    Expression<DateTime>? dataAbertura,
    Expression<DateTime>? dataEncerramento,
    Expression<DateTime>? escrituracaoInicio,
    Expression<DateTime>? escrituracaoFim,
    Expression<String>? texto,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFiscalLivro != null) 'id_fiscal_livro': idFiscalLivro,
      if (aberturaEncerramento != null)
        'abertura_encerramento': aberturaEncerramento,
      if (numero != null) 'numero': numero,
      if (paginaInicial != null) 'pagina_inicial': paginaInicial,
      if (paginaFinal != null) 'pagina_final': paginaFinal,
      if (numeroRegistro != null) 'numero_registro': numeroRegistro,
      if (registrado != null) 'registrado': registrado,
      if (dataDespacho != null) 'data_despacho': dataDespacho,
      if (dataAbertura != null) 'data_abertura': dataAbertura,
      if (dataEncerramento != null) 'data_encerramento': dataEncerramento,
      if (escrituracaoInicio != null) 'escrituracao_inicio': escrituracaoInicio,
      if (escrituracaoFim != null) 'escrituracao_fim': escrituracaoFim,
      if (texto != null) 'texto': texto,
    });
  }

  FiscalTermosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFiscalLivro,
      Value<String?>? aberturaEncerramento,
      Value<int?>? numero,
      Value<int?>? paginaInicial,
      Value<int?>? paginaFinal,
      Value<String?>? numeroRegistro,
      Value<String?>? registrado,
      Value<DateTime?>? dataDespacho,
      Value<DateTime?>? dataAbertura,
      Value<DateTime?>? dataEncerramento,
      Value<DateTime?>? escrituracaoInicio,
      Value<DateTime?>? escrituracaoFim,
      Value<String?>? texto}) {
    return FiscalTermosCompanion(
      id: id ?? this.id,
      idFiscalLivro: idFiscalLivro ?? this.idFiscalLivro,
      aberturaEncerramento: aberturaEncerramento ?? this.aberturaEncerramento,
      numero: numero ?? this.numero,
      paginaInicial: paginaInicial ?? this.paginaInicial,
      paginaFinal: paginaFinal ?? this.paginaFinal,
      numeroRegistro: numeroRegistro ?? this.numeroRegistro,
      registrado: registrado ?? this.registrado,
      dataDespacho: dataDespacho ?? this.dataDespacho,
      dataAbertura: dataAbertura ?? this.dataAbertura,
      dataEncerramento: dataEncerramento ?? this.dataEncerramento,
      escrituracaoInicio: escrituracaoInicio ?? this.escrituracaoInicio,
      escrituracaoFim: escrituracaoFim ?? this.escrituracaoFim,
      texto: texto ?? this.texto,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFiscalLivro.present) {
      map['id_fiscal_livro'] = Variable<int>(idFiscalLivro.value);
    }
    if (aberturaEncerramento.present) {
      map['abertura_encerramento'] =
          Variable<String>(aberturaEncerramento.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (paginaInicial.present) {
      map['pagina_inicial'] = Variable<int>(paginaInicial.value);
    }
    if (paginaFinal.present) {
      map['pagina_final'] = Variable<int>(paginaFinal.value);
    }
    if (numeroRegistro.present) {
      map['numero_registro'] = Variable<String>(numeroRegistro.value);
    }
    if (registrado.present) {
      map['registrado'] = Variable<String>(registrado.value);
    }
    if (dataDespacho.present) {
      map['data_despacho'] = Variable<DateTime>(dataDespacho.value);
    }
    if (dataAbertura.present) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura.value);
    }
    if (dataEncerramento.present) {
      map['data_encerramento'] = Variable<DateTime>(dataEncerramento.value);
    }
    if (escrituracaoInicio.present) {
      map['escrituracao_inicio'] = Variable<DateTime>(escrituracaoInicio.value);
    }
    if (escrituracaoFim.present) {
      map['escrituracao_fim'] = Variable<DateTime>(escrituracaoFim.value);
    }
    if (texto.present) {
      map['texto'] = Variable<String>(texto.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalTermosCompanion(')
          ..write('id: $id, ')
          ..write('idFiscalLivro: $idFiscalLivro, ')
          ..write('aberturaEncerramento: $aberturaEncerramento, ')
          ..write('numero: $numero, ')
          ..write('paginaInicial: $paginaInicial, ')
          ..write('paginaFinal: $paginaFinal, ')
          ..write('numeroRegistro: $numeroRegistro, ')
          ..write('registrado: $registrado, ')
          ..write('dataDespacho: $dataDespacho, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataEncerramento: $dataEncerramento, ')
          ..write('escrituracaoInicio: $escrituracaoInicio, ')
          ..write('escrituracaoFim: $escrituracaoFim, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }
}

class $FiscalInscricoesSubstitutassTable extends FiscalInscricoesSubstitutass
    with
        TableInfo<$FiscalInscricoesSubstitutassTable,
            FiscalInscricoesSubstitutas> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalInscricoesSubstitutassTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFiscalParametrosMeta =
      const VerificationMeta('idFiscalParametros');
  @override
  late final GeneratedColumn<int> idFiscalParametros = GeneratedColumn<int>(
      'id_fiscal_parametros', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoEstadualMeta =
      const VerificationMeta('inscricaoEstadual');
  @override
  late final GeneratedColumn<String> inscricaoEstadual =
      GeneratedColumn<String>('inscricao_estadual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _pmpfMeta = const VerificationMeta('pmpf');
  @override
  late final GeneratedColumn<String> pmpf = GeneratedColumn<String>(
      'pmpf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFiscalParametros, uf, inscricaoEstadual, pmpf];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_inscricoes_substitutas';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalInscricoesSubstitutas> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_fiscal_parametros')) {
      context.handle(
          _idFiscalParametrosMeta,
          idFiscalParametros.isAcceptableOrUnknown(
              data['id_fiscal_parametros']!, _idFiscalParametrosMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('inscricao_estadual')) {
      context.handle(
          _inscricaoEstadualMeta,
          inscricaoEstadual.isAcceptableOrUnknown(
              data['inscricao_estadual']!, _inscricaoEstadualMeta));
    }
    if (data.containsKey('pmpf')) {
      context.handle(
          _pmpfMeta, pmpf.isAcceptableOrUnknown(data['pmpf']!, _pmpfMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalInscricoesSubstitutas map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalInscricoesSubstitutas(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFiscalParametros: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_fiscal_parametros']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      inscricaoEstadual: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_estadual']),
      pmpf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pmpf']),
    );
  }

  @override
  $FiscalInscricoesSubstitutassTable createAlias(String alias) {
    return $FiscalInscricoesSubstitutassTable(attachedDatabase, alias);
  }
}

class FiscalInscricoesSubstitutas extends DataClass
    implements Insertable<FiscalInscricoesSubstitutas> {
  final int? id;
  final int? idFiscalParametros;
  final String? uf;
  final String? inscricaoEstadual;
  final String? pmpf;
  const FiscalInscricoesSubstitutas(
      {this.id,
      this.idFiscalParametros,
      this.uf,
      this.inscricaoEstadual,
      this.pmpf});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFiscalParametros != null) {
      map['id_fiscal_parametros'] = Variable<int>(idFiscalParametros);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || inscricaoEstadual != null) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual);
    }
    if (!nullToAbsent || pmpf != null) {
      map['pmpf'] = Variable<String>(pmpf);
    }
    return map;
  }

  factory FiscalInscricoesSubstitutas.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalInscricoesSubstitutas(
      id: serializer.fromJson<int?>(json['id']),
      idFiscalParametros: serializer.fromJson<int?>(json['idFiscalParametros']),
      uf: serializer.fromJson<String?>(json['uf']),
      inscricaoEstadual:
          serializer.fromJson<String?>(json['inscricaoEstadual']),
      pmpf: serializer.fromJson<String?>(json['pmpf']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFiscalParametros': serializer.toJson<int?>(idFiscalParametros),
      'uf': serializer.toJson<String?>(uf),
      'inscricaoEstadual': serializer.toJson<String?>(inscricaoEstadual),
      'pmpf': serializer.toJson<String?>(pmpf),
    };
  }

  FiscalInscricoesSubstitutas copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFiscalParametros = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> inscricaoEstadual = const Value.absent(),
          Value<String?> pmpf = const Value.absent()}) =>
      FiscalInscricoesSubstitutas(
        id: id.present ? id.value : this.id,
        idFiscalParametros: idFiscalParametros.present
            ? idFiscalParametros.value
            : this.idFiscalParametros,
        uf: uf.present ? uf.value : this.uf,
        inscricaoEstadual: inscricaoEstadual.present
            ? inscricaoEstadual.value
            : this.inscricaoEstadual,
        pmpf: pmpf.present ? pmpf.value : this.pmpf,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalInscricoesSubstitutas(')
          ..write('id: $id, ')
          ..write('idFiscalParametros: $idFiscalParametros, ')
          ..write('uf: $uf, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('pmpf: $pmpf')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idFiscalParametros, uf, inscricaoEstadual, pmpf);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalInscricoesSubstitutas &&
          other.id == this.id &&
          other.idFiscalParametros == this.idFiscalParametros &&
          other.uf == this.uf &&
          other.inscricaoEstadual == this.inscricaoEstadual &&
          other.pmpf == this.pmpf);
}

class FiscalInscricoesSubstitutassCompanion
    extends UpdateCompanion<FiscalInscricoesSubstitutas> {
  final Value<int?> id;
  final Value<int?> idFiscalParametros;
  final Value<String?> uf;
  final Value<String?> inscricaoEstadual;
  final Value<String?> pmpf;
  const FiscalInscricoesSubstitutassCompanion({
    this.id = const Value.absent(),
    this.idFiscalParametros = const Value.absent(),
    this.uf = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.pmpf = const Value.absent(),
  });
  FiscalInscricoesSubstitutassCompanion.insert({
    this.id = const Value.absent(),
    this.idFiscalParametros = const Value.absent(),
    this.uf = const Value.absent(),
    this.inscricaoEstadual = const Value.absent(),
    this.pmpf = const Value.absent(),
  });
  static Insertable<FiscalInscricoesSubstitutas> custom({
    Expression<int>? id,
    Expression<int>? idFiscalParametros,
    Expression<String>? uf,
    Expression<String>? inscricaoEstadual,
    Expression<String>? pmpf,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFiscalParametros != null)
        'id_fiscal_parametros': idFiscalParametros,
      if (uf != null) 'uf': uf,
      if (inscricaoEstadual != null) 'inscricao_estadual': inscricaoEstadual,
      if (pmpf != null) 'pmpf': pmpf,
    });
  }

  FiscalInscricoesSubstitutassCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFiscalParametros,
      Value<String?>? uf,
      Value<String?>? inscricaoEstadual,
      Value<String?>? pmpf}) {
    return FiscalInscricoesSubstitutassCompanion(
      id: id ?? this.id,
      idFiscalParametros: idFiscalParametros ?? this.idFiscalParametros,
      uf: uf ?? this.uf,
      inscricaoEstadual: inscricaoEstadual ?? this.inscricaoEstadual,
      pmpf: pmpf ?? this.pmpf,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFiscalParametros.present) {
      map['id_fiscal_parametros'] = Variable<int>(idFiscalParametros.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (inscricaoEstadual.present) {
      map['inscricao_estadual'] = Variable<String>(inscricaoEstadual.value);
    }
    if (pmpf.present) {
      map['pmpf'] = Variable<String>(pmpf.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalInscricoesSubstitutassCompanion(')
          ..write('id: $id, ')
          ..write('idFiscalParametros: $idFiscalParametros, ')
          ..write('uf: $uf, ')
          ..write('inscricaoEstadual: $inscricaoEstadual, ')
          ..write('pmpf: $pmpf')
          ..write(')'))
        .toString();
  }
}

class $SimplesNacionalDetalhesTable extends SimplesNacionalDetalhes
    with TableInfo<$SimplesNacionalDetalhesTable, SimplesNacionalDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SimplesNacionalDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSimplesNacionalCabecalhoMeta =
      const VerificationMeta('idSimplesNacionalCabecalho');
  @override
  late final GeneratedColumn<int> idSimplesNacionalCabecalho =
      GeneratedColumn<int>('id_simples_nacional_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _faixaMeta = const VerificationMeta('faixa');
  @override
  late final GeneratedColumn<int> faixa = GeneratedColumn<int>(
      'faixa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorInicialMeta =
      const VerificationMeta('valorInicial');
  @override
  late final GeneratedColumn<double> valorInicial = GeneratedColumn<double>(
      'valor_inicial', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorFinalMeta =
      const VerificationMeta('valorFinal');
  @override
  late final GeneratedColumn<double> valorFinal = GeneratedColumn<double>(
      'valor_final', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaMeta =
      const VerificationMeta('aliquota');
  @override
  late final GeneratedColumn<double> aliquota = GeneratedColumn<double>(
      'aliquota', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _irpjMeta = const VerificationMeta('irpj');
  @override
  late final GeneratedColumn<double> irpj = GeneratedColumn<double>(
      'irpj', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _csllMeta = const VerificationMeta('csll');
  @override
  late final GeneratedColumn<double> csll = GeneratedColumn<double>(
      'csll', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cofinsMeta = const VerificationMeta('cofins');
  @override
  late final GeneratedColumn<double> cofins = GeneratedColumn<double>(
      'cofins', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pisPasepMeta =
      const VerificationMeta('pisPasep');
  @override
  late final GeneratedColumn<double> pisPasep = GeneratedColumn<double>(
      'pis_pasep', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cppMeta = const VerificationMeta('cpp');
  @override
  late final GeneratedColumn<double> cpp = GeneratedColumn<double>(
      'cpp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _icmsMeta = const VerificationMeta('icms');
  @override
  late final GeneratedColumn<double> icms = GeneratedColumn<double>(
      'icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _ipiMeta = const VerificationMeta('ipi');
  @override
  late final GeneratedColumn<double> ipi = GeneratedColumn<double>(
      'ipi', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _issMeta = const VerificationMeta('iss');
  @override
  late final GeneratedColumn<double> iss = GeneratedColumn<double>(
      'iss', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idSimplesNacionalCabecalho,
        faixa,
        valorInicial,
        valorFinal,
        aliquota,
        irpj,
        csll,
        cofins,
        pisPasep,
        cpp,
        icms,
        ipi,
        iss
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'simples_nacional_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<SimplesNacionalDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_simples_nacional_cabecalho')) {
      context.handle(
          _idSimplesNacionalCabecalhoMeta,
          idSimplesNacionalCabecalho.isAcceptableOrUnknown(
              data['id_simples_nacional_cabecalho']!,
              _idSimplesNacionalCabecalhoMeta));
    }
    if (data.containsKey('faixa')) {
      context.handle(
          _faixaMeta, faixa.isAcceptableOrUnknown(data['faixa']!, _faixaMeta));
    }
    if (data.containsKey('valor_inicial')) {
      context.handle(
          _valorInicialMeta,
          valorInicial.isAcceptableOrUnknown(
              data['valor_inicial']!, _valorInicialMeta));
    }
    if (data.containsKey('valor_final')) {
      context.handle(
          _valorFinalMeta,
          valorFinal.isAcceptableOrUnknown(
              data['valor_final']!, _valorFinalMeta));
    }
    if (data.containsKey('aliquota')) {
      context.handle(_aliquotaMeta,
          aliquota.isAcceptableOrUnknown(data['aliquota']!, _aliquotaMeta));
    }
    if (data.containsKey('irpj')) {
      context.handle(
          _irpjMeta, irpj.isAcceptableOrUnknown(data['irpj']!, _irpjMeta));
    }
    if (data.containsKey('csll')) {
      context.handle(
          _csllMeta, csll.isAcceptableOrUnknown(data['csll']!, _csllMeta));
    }
    if (data.containsKey('cofins')) {
      context.handle(_cofinsMeta,
          cofins.isAcceptableOrUnknown(data['cofins']!, _cofinsMeta));
    }
    if (data.containsKey('pis_pasep')) {
      context.handle(_pisPasepMeta,
          pisPasep.isAcceptableOrUnknown(data['pis_pasep']!, _pisPasepMeta));
    }
    if (data.containsKey('cpp')) {
      context.handle(
          _cppMeta, cpp.isAcceptableOrUnknown(data['cpp']!, _cppMeta));
    }
    if (data.containsKey('icms')) {
      context.handle(
          _icmsMeta, icms.isAcceptableOrUnknown(data['icms']!, _icmsMeta));
    }
    if (data.containsKey('ipi')) {
      context.handle(
          _ipiMeta, ipi.isAcceptableOrUnknown(data['ipi']!, _ipiMeta));
    }
    if (data.containsKey('iss')) {
      context.handle(
          _issMeta, iss.isAcceptableOrUnknown(data['iss']!, _issMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SimplesNacionalDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SimplesNacionalDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idSimplesNacionalCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_simples_nacional_cabecalho']),
      faixa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}faixa']),
      valorInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_inicial']),
      valorFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_final']),
      aliquota: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota']),
      irpj: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}irpj']),
      csll: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}csll']),
      cofins: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}cofins']),
      pisPasep: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}pis_pasep']),
      cpp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}cpp']),
      icms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}icms']),
      ipi: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}ipi']),
      iss: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}iss']),
    );
  }

  @override
  $SimplesNacionalDetalhesTable createAlias(String alias) {
    return $SimplesNacionalDetalhesTable(attachedDatabase, alias);
  }
}

class SimplesNacionalDetalhe extends DataClass
    implements Insertable<SimplesNacionalDetalhe> {
  final int? id;
  final int? idSimplesNacionalCabecalho;
  final int? faixa;
  final double? valorInicial;
  final double? valorFinal;
  final double? aliquota;
  final double? irpj;
  final double? csll;
  final double? cofins;
  final double? pisPasep;
  final double? cpp;
  final double? icms;
  final double? ipi;
  final double? iss;
  const SimplesNacionalDetalhe(
      {this.id,
      this.idSimplesNacionalCabecalho,
      this.faixa,
      this.valorInicial,
      this.valorFinal,
      this.aliquota,
      this.irpj,
      this.csll,
      this.cofins,
      this.pisPasep,
      this.cpp,
      this.icms,
      this.ipi,
      this.iss});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idSimplesNacionalCabecalho != null) {
      map['id_simples_nacional_cabecalho'] =
          Variable<int>(idSimplesNacionalCabecalho);
    }
    if (!nullToAbsent || faixa != null) {
      map['faixa'] = Variable<int>(faixa);
    }
    if (!nullToAbsent || valorInicial != null) {
      map['valor_inicial'] = Variable<double>(valorInicial);
    }
    if (!nullToAbsent || valorFinal != null) {
      map['valor_final'] = Variable<double>(valorFinal);
    }
    if (!nullToAbsent || aliquota != null) {
      map['aliquota'] = Variable<double>(aliquota);
    }
    if (!nullToAbsent || irpj != null) {
      map['irpj'] = Variable<double>(irpj);
    }
    if (!nullToAbsent || csll != null) {
      map['csll'] = Variable<double>(csll);
    }
    if (!nullToAbsent || cofins != null) {
      map['cofins'] = Variable<double>(cofins);
    }
    if (!nullToAbsent || pisPasep != null) {
      map['pis_pasep'] = Variable<double>(pisPasep);
    }
    if (!nullToAbsent || cpp != null) {
      map['cpp'] = Variable<double>(cpp);
    }
    if (!nullToAbsent || icms != null) {
      map['icms'] = Variable<double>(icms);
    }
    if (!nullToAbsent || ipi != null) {
      map['ipi'] = Variable<double>(ipi);
    }
    if (!nullToAbsent || iss != null) {
      map['iss'] = Variable<double>(iss);
    }
    return map;
  }

  factory SimplesNacionalDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SimplesNacionalDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idSimplesNacionalCabecalho:
          serializer.fromJson<int?>(json['idSimplesNacionalCabecalho']),
      faixa: serializer.fromJson<int?>(json['faixa']),
      valorInicial: serializer.fromJson<double?>(json['valorInicial']),
      valorFinal: serializer.fromJson<double?>(json['valorFinal']),
      aliquota: serializer.fromJson<double?>(json['aliquota']),
      irpj: serializer.fromJson<double?>(json['irpj']),
      csll: serializer.fromJson<double?>(json['csll']),
      cofins: serializer.fromJson<double?>(json['cofins']),
      pisPasep: serializer.fromJson<double?>(json['pisPasep']),
      cpp: serializer.fromJson<double?>(json['cpp']),
      icms: serializer.fromJson<double?>(json['icms']),
      ipi: serializer.fromJson<double?>(json['ipi']),
      iss: serializer.fromJson<double?>(json['iss']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idSimplesNacionalCabecalho':
          serializer.toJson<int?>(idSimplesNacionalCabecalho),
      'faixa': serializer.toJson<int?>(faixa),
      'valorInicial': serializer.toJson<double?>(valorInicial),
      'valorFinal': serializer.toJson<double?>(valorFinal),
      'aliquota': serializer.toJson<double?>(aliquota),
      'irpj': serializer.toJson<double?>(irpj),
      'csll': serializer.toJson<double?>(csll),
      'cofins': serializer.toJson<double?>(cofins),
      'pisPasep': serializer.toJson<double?>(pisPasep),
      'cpp': serializer.toJson<double?>(cpp),
      'icms': serializer.toJson<double?>(icms),
      'ipi': serializer.toJson<double?>(ipi),
      'iss': serializer.toJson<double?>(iss),
    };
  }

  SimplesNacionalDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idSimplesNacionalCabecalho = const Value.absent(),
          Value<int?> faixa = const Value.absent(),
          Value<double?> valorInicial = const Value.absent(),
          Value<double?> valorFinal = const Value.absent(),
          Value<double?> aliquota = const Value.absent(),
          Value<double?> irpj = const Value.absent(),
          Value<double?> csll = const Value.absent(),
          Value<double?> cofins = const Value.absent(),
          Value<double?> pisPasep = const Value.absent(),
          Value<double?> cpp = const Value.absent(),
          Value<double?> icms = const Value.absent(),
          Value<double?> ipi = const Value.absent(),
          Value<double?> iss = const Value.absent()}) =>
      SimplesNacionalDetalhe(
        id: id.present ? id.value : this.id,
        idSimplesNacionalCabecalho: idSimplesNacionalCabecalho.present
            ? idSimplesNacionalCabecalho.value
            : this.idSimplesNacionalCabecalho,
        faixa: faixa.present ? faixa.value : this.faixa,
        valorInicial:
            valorInicial.present ? valorInicial.value : this.valorInicial,
        valorFinal: valorFinal.present ? valorFinal.value : this.valorFinal,
        aliquota: aliquota.present ? aliquota.value : this.aliquota,
        irpj: irpj.present ? irpj.value : this.irpj,
        csll: csll.present ? csll.value : this.csll,
        cofins: cofins.present ? cofins.value : this.cofins,
        pisPasep: pisPasep.present ? pisPasep.value : this.pisPasep,
        cpp: cpp.present ? cpp.value : this.cpp,
        icms: icms.present ? icms.value : this.icms,
        ipi: ipi.present ? ipi.value : this.ipi,
        iss: iss.present ? iss.value : this.iss,
      );
  @override
  String toString() {
    return (StringBuffer('SimplesNacionalDetalhe(')
          ..write('id: $id, ')
          ..write('idSimplesNacionalCabecalho: $idSimplesNacionalCabecalho, ')
          ..write('faixa: $faixa, ')
          ..write('valorInicial: $valorInicial, ')
          ..write('valorFinal: $valorFinal, ')
          ..write('aliquota: $aliquota, ')
          ..write('irpj: $irpj, ')
          ..write('csll: $csll, ')
          ..write('cofins: $cofins, ')
          ..write('pisPasep: $pisPasep, ')
          ..write('cpp: $cpp, ')
          ..write('icms: $icms, ')
          ..write('ipi: $ipi, ')
          ..write('iss: $iss')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idSimplesNacionalCabecalho,
      faixa,
      valorInicial,
      valorFinal,
      aliquota,
      irpj,
      csll,
      cofins,
      pisPasep,
      cpp,
      icms,
      ipi,
      iss);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SimplesNacionalDetalhe &&
          other.id == this.id &&
          other.idSimplesNacionalCabecalho == this.idSimplesNacionalCabecalho &&
          other.faixa == this.faixa &&
          other.valorInicial == this.valorInicial &&
          other.valorFinal == this.valorFinal &&
          other.aliquota == this.aliquota &&
          other.irpj == this.irpj &&
          other.csll == this.csll &&
          other.cofins == this.cofins &&
          other.pisPasep == this.pisPasep &&
          other.cpp == this.cpp &&
          other.icms == this.icms &&
          other.ipi == this.ipi &&
          other.iss == this.iss);
}

class SimplesNacionalDetalhesCompanion
    extends UpdateCompanion<SimplesNacionalDetalhe> {
  final Value<int?> id;
  final Value<int?> idSimplesNacionalCabecalho;
  final Value<int?> faixa;
  final Value<double?> valorInicial;
  final Value<double?> valorFinal;
  final Value<double?> aliquota;
  final Value<double?> irpj;
  final Value<double?> csll;
  final Value<double?> cofins;
  final Value<double?> pisPasep;
  final Value<double?> cpp;
  final Value<double?> icms;
  final Value<double?> ipi;
  final Value<double?> iss;
  const SimplesNacionalDetalhesCompanion({
    this.id = const Value.absent(),
    this.idSimplesNacionalCabecalho = const Value.absent(),
    this.faixa = const Value.absent(),
    this.valorInicial = const Value.absent(),
    this.valorFinal = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.irpj = const Value.absent(),
    this.csll = const Value.absent(),
    this.cofins = const Value.absent(),
    this.pisPasep = const Value.absent(),
    this.cpp = const Value.absent(),
    this.icms = const Value.absent(),
    this.ipi = const Value.absent(),
    this.iss = const Value.absent(),
  });
  SimplesNacionalDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idSimplesNacionalCabecalho = const Value.absent(),
    this.faixa = const Value.absent(),
    this.valorInicial = const Value.absent(),
    this.valorFinal = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.irpj = const Value.absent(),
    this.csll = const Value.absent(),
    this.cofins = const Value.absent(),
    this.pisPasep = const Value.absent(),
    this.cpp = const Value.absent(),
    this.icms = const Value.absent(),
    this.ipi = const Value.absent(),
    this.iss = const Value.absent(),
  });
  static Insertable<SimplesNacionalDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idSimplesNacionalCabecalho,
    Expression<int>? faixa,
    Expression<double>? valorInicial,
    Expression<double>? valorFinal,
    Expression<double>? aliquota,
    Expression<double>? irpj,
    Expression<double>? csll,
    Expression<double>? cofins,
    Expression<double>? pisPasep,
    Expression<double>? cpp,
    Expression<double>? icms,
    Expression<double>? ipi,
    Expression<double>? iss,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idSimplesNacionalCabecalho != null)
        'id_simples_nacional_cabecalho': idSimplesNacionalCabecalho,
      if (faixa != null) 'faixa': faixa,
      if (valorInicial != null) 'valor_inicial': valorInicial,
      if (valorFinal != null) 'valor_final': valorFinal,
      if (aliquota != null) 'aliquota': aliquota,
      if (irpj != null) 'irpj': irpj,
      if (csll != null) 'csll': csll,
      if (cofins != null) 'cofins': cofins,
      if (pisPasep != null) 'pis_pasep': pisPasep,
      if (cpp != null) 'cpp': cpp,
      if (icms != null) 'icms': icms,
      if (ipi != null) 'ipi': ipi,
      if (iss != null) 'iss': iss,
    });
  }

  SimplesNacionalDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idSimplesNacionalCabecalho,
      Value<int?>? faixa,
      Value<double?>? valorInicial,
      Value<double?>? valorFinal,
      Value<double?>? aliquota,
      Value<double?>? irpj,
      Value<double?>? csll,
      Value<double?>? cofins,
      Value<double?>? pisPasep,
      Value<double?>? cpp,
      Value<double?>? icms,
      Value<double?>? ipi,
      Value<double?>? iss}) {
    return SimplesNacionalDetalhesCompanion(
      id: id ?? this.id,
      idSimplesNacionalCabecalho:
          idSimplesNacionalCabecalho ?? this.idSimplesNacionalCabecalho,
      faixa: faixa ?? this.faixa,
      valorInicial: valorInicial ?? this.valorInicial,
      valorFinal: valorFinal ?? this.valorFinal,
      aliquota: aliquota ?? this.aliquota,
      irpj: irpj ?? this.irpj,
      csll: csll ?? this.csll,
      cofins: cofins ?? this.cofins,
      pisPasep: pisPasep ?? this.pisPasep,
      cpp: cpp ?? this.cpp,
      icms: icms ?? this.icms,
      ipi: ipi ?? this.ipi,
      iss: iss ?? this.iss,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idSimplesNacionalCabecalho.present) {
      map['id_simples_nacional_cabecalho'] =
          Variable<int>(idSimplesNacionalCabecalho.value);
    }
    if (faixa.present) {
      map['faixa'] = Variable<int>(faixa.value);
    }
    if (valorInicial.present) {
      map['valor_inicial'] = Variable<double>(valorInicial.value);
    }
    if (valorFinal.present) {
      map['valor_final'] = Variable<double>(valorFinal.value);
    }
    if (aliquota.present) {
      map['aliquota'] = Variable<double>(aliquota.value);
    }
    if (irpj.present) {
      map['irpj'] = Variable<double>(irpj.value);
    }
    if (csll.present) {
      map['csll'] = Variable<double>(csll.value);
    }
    if (cofins.present) {
      map['cofins'] = Variable<double>(cofins.value);
    }
    if (pisPasep.present) {
      map['pis_pasep'] = Variable<double>(pisPasep.value);
    }
    if (cpp.present) {
      map['cpp'] = Variable<double>(cpp.value);
    }
    if (icms.present) {
      map['icms'] = Variable<double>(icms.value);
    }
    if (ipi.present) {
      map['ipi'] = Variable<double>(ipi.value);
    }
    if (iss.present) {
      map['iss'] = Variable<double>(iss.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SimplesNacionalDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idSimplesNacionalCabecalho: $idSimplesNacionalCabecalho, ')
          ..write('faixa: $faixa, ')
          ..write('valorInicial: $valorInicial, ')
          ..write('valorFinal: $valorFinal, ')
          ..write('aliquota: $aliquota, ')
          ..write('irpj: $irpj, ')
          ..write('csll: $csll, ')
          ..write('cofins: $cofins, ')
          ..write('pisPasep: $pisPasep, ')
          ..write('cpp: $cpp, ')
          ..write('icms: $icms, ')
          ..write('ipi: $ipi, ')
          ..write('iss: $iss')
          ..write(')'))
        .toString();
  }
}

class $FiscalParametrosTable extends FiscalParametros
    with TableInfo<$FiscalParametrosTable, FiscalParametro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalParametrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFiscalEstadualPorteMeta =
      const VerificationMeta('idFiscalEstadualPorte');
  @override
  late final GeneratedColumn<int> idFiscalEstadualPorte = GeneratedColumn<int>(
      'id_fiscal_estadual_porte', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFiscalEstadualRegimeMeta =
      const VerificationMeta('idFiscalEstadualRegime');
  @override
  late final GeneratedColumn<int> idFiscalEstadualRegime = GeneratedColumn<int>(
      'id_fiscal_estadual_regime', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFiscalMunicipalRegimeMeta =
      const VerificationMeta('idFiscalMunicipalRegime');
  @override
  late final GeneratedColumn<int> idFiscalMunicipalRegime =
      GeneratedColumn<int>('id_fiscal_municipal_regime', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _vigenciaMeta =
      const VerificationMeta('vigencia');
  @override
  late final GeneratedColumn<String> vigencia = GeneratedColumn<String>(
      'vigencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoVigenciaMeta =
      const VerificationMeta('descricaoVigencia');
  @override
  late final GeneratedColumn<String> descricaoVigencia =
      GeneratedColumn<String>('descricao_vigencia', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _criterioLancamentoMeta =
      const VerificationMeta('criterioLancamento');
  @override
  late final GeneratedColumn<String> criterioLancamento =
      GeneratedColumn<String>('criterio_lancamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _apuracaoMeta =
      const VerificationMeta('apuracao');
  @override
  late final GeneratedColumn<String> apuracao = GeneratedColumn<String>(
      'apuracao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _microempreeIndividualMeta =
      const VerificationMeta('microempreeIndividual');
  @override
  late final GeneratedColumn<String> microempreeIndividual =
      GeneratedColumn<String>('microempree_individual', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _calcPisCofinsEfdMeta =
      const VerificationMeta('calcPisCofinsEfd');
  @override
  late final GeneratedColumn<String> calcPisCofinsEfd = GeneratedColumn<String>(
      'calc_pis_cofins_efd', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _simplesCodigoAcessoMeta =
      const VerificationMeta('simplesCodigoAcesso');
  @override
  late final GeneratedColumn<String> simplesCodigoAcesso =
      GeneratedColumn<String>('simples_codigo_acesso', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 50),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _simplesTabelaMeta =
      const VerificationMeta('simplesTabela');
  @override
  late final GeneratedColumn<String> simplesTabela = GeneratedColumn<String>(
      'simples_tabela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _simplesAtividadeMeta =
      const VerificationMeta('simplesAtividade');
  @override
  late final GeneratedColumn<String> simplesAtividade = GeneratedColumn<String>(
      'simples_atividade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _perfilSpedMeta =
      const VerificationMeta('perfilSped');
  @override
  late final GeneratedColumn<String> perfilSped = GeneratedColumn<String>(
      'perfil_sped', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _apuracaoConsolidadaMeta =
      const VerificationMeta('apuracaoConsolidada');
  @override
  late final GeneratedColumn<String> apuracaoConsolidada =
      GeneratedColumn<String>('apuracao_consolidada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _substituicaoTributariaMeta =
      const VerificationMeta('substituicaoTributaria');
  @override
  late final GeneratedColumn<String> substituicaoTributaria =
      GeneratedColumn<String>('substituicao_tributaria', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _formaCalculoIssMeta =
      const VerificationMeta('formaCalculoIss');
  @override
  late final GeneratedColumn<String> formaCalculoIss = GeneratedColumn<String>(
      'forma_calculo_iss', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFiscalEstadualPorte,
        idFiscalEstadualRegime,
        idFiscalMunicipalRegime,
        vigencia,
        descricaoVigencia,
        criterioLancamento,
        apuracao,
        microempreeIndividual,
        calcPisCofinsEfd,
        simplesCodigoAcesso,
        simplesTabela,
        simplesAtividade,
        perfilSped,
        apuracaoConsolidada,
        substituicaoTributaria,
        formaCalculoIss
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_parametro';
  @override
  VerificationContext validateIntegrity(Insertable<FiscalParametro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_fiscal_estadual_porte')) {
      context.handle(
          _idFiscalEstadualPorteMeta,
          idFiscalEstadualPorte.isAcceptableOrUnknown(
              data['id_fiscal_estadual_porte']!, _idFiscalEstadualPorteMeta));
    }
    if (data.containsKey('id_fiscal_estadual_regime')) {
      context.handle(
          _idFiscalEstadualRegimeMeta,
          idFiscalEstadualRegime.isAcceptableOrUnknown(
              data['id_fiscal_estadual_regime']!, _idFiscalEstadualRegimeMeta));
    }
    if (data.containsKey('id_fiscal_municipal_regime')) {
      context.handle(
          _idFiscalMunicipalRegimeMeta,
          idFiscalMunicipalRegime.isAcceptableOrUnknown(
              data['id_fiscal_municipal_regime']!,
              _idFiscalMunicipalRegimeMeta));
    }
    if (data.containsKey('vigencia')) {
      context.handle(_vigenciaMeta,
          vigencia.isAcceptableOrUnknown(data['vigencia']!, _vigenciaMeta));
    }
    if (data.containsKey('descricao_vigencia')) {
      context.handle(
          _descricaoVigenciaMeta,
          descricaoVigencia.isAcceptableOrUnknown(
              data['descricao_vigencia']!, _descricaoVigenciaMeta));
    }
    if (data.containsKey('criterio_lancamento')) {
      context.handle(
          _criterioLancamentoMeta,
          criterioLancamento.isAcceptableOrUnknown(
              data['criterio_lancamento']!, _criterioLancamentoMeta));
    }
    if (data.containsKey('apuracao')) {
      context.handle(_apuracaoMeta,
          apuracao.isAcceptableOrUnknown(data['apuracao']!, _apuracaoMeta));
    }
    if (data.containsKey('microempree_individual')) {
      context.handle(
          _microempreeIndividualMeta,
          microempreeIndividual.isAcceptableOrUnknown(
              data['microempree_individual']!, _microempreeIndividualMeta));
    }
    if (data.containsKey('calc_pis_cofins_efd')) {
      context.handle(
          _calcPisCofinsEfdMeta,
          calcPisCofinsEfd.isAcceptableOrUnknown(
              data['calc_pis_cofins_efd']!, _calcPisCofinsEfdMeta));
    }
    if (data.containsKey('simples_codigo_acesso')) {
      context.handle(
          _simplesCodigoAcessoMeta,
          simplesCodigoAcesso.isAcceptableOrUnknown(
              data['simples_codigo_acesso']!, _simplesCodigoAcessoMeta));
    }
    if (data.containsKey('simples_tabela')) {
      context.handle(
          _simplesTabelaMeta,
          simplesTabela.isAcceptableOrUnknown(
              data['simples_tabela']!, _simplesTabelaMeta));
    }
    if (data.containsKey('simples_atividade')) {
      context.handle(
          _simplesAtividadeMeta,
          simplesAtividade.isAcceptableOrUnknown(
              data['simples_atividade']!, _simplesAtividadeMeta));
    }
    if (data.containsKey('perfil_sped')) {
      context.handle(
          _perfilSpedMeta,
          perfilSped.isAcceptableOrUnknown(
              data['perfil_sped']!, _perfilSpedMeta));
    }
    if (data.containsKey('apuracao_consolidada')) {
      context.handle(
          _apuracaoConsolidadaMeta,
          apuracaoConsolidada.isAcceptableOrUnknown(
              data['apuracao_consolidada']!, _apuracaoConsolidadaMeta));
    }
    if (data.containsKey('substituicao_tributaria')) {
      context.handle(
          _substituicaoTributariaMeta,
          substituicaoTributaria.isAcceptableOrUnknown(
              data['substituicao_tributaria']!, _substituicaoTributariaMeta));
    }
    if (data.containsKey('forma_calculo_iss')) {
      context.handle(
          _formaCalculoIssMeta,
          formaCalculoIss.isAcceptableOrUnknown(
              data['forma_calculo_iss']!, _formaCalculoIssMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalParametro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalParametro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFiscalEstadualPorte: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_fiscal_estadual_porte']),
      idFiscalEstadualRegime: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_fiscal_estadual_regime']),
      idFiscalMunicipalRegime: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_fiscal_municipal_regime']),
      vigencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}vigencia']),
      descricaoVigencia: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}descricao_vigencia']),
      criterioLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}criterio_lancamento']),
      apuracao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}apuracao']),
      microempreeIndividual: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}microempree_individual']),
      calcPisCofinsEfd: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}calc_pis_cofins_efd']),
      simplesCodigoAcesso: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}simples_codigo_acesso']),
      simplesTabela: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}simples_tabela']),
      simplesAtividade: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}simples_atividade']),
      perfilSped: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}perfil_sped']),
      apuracaoConsolidada: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}apuracao_consolidada']),
      substituicaoTributaria: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}substituicao_tributaria']),
      formaCalculoIss: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}forma_calculo_iss']),
    );
  }

  @override
  $FiscalParametrosTable createAlias(String alias) {
    return $FiscalParametrosTable(attachedDatabase, alias);
  }
}

class FiscalParametro extends DataClass implements Insertable<FiscalParametro> {
  final int? id;
  final int? idFiscalEstadualPorte;
  final int? idFiscalEstadualRegime;
  final int? idFiscalMunicipalRegime;
  final String? vigencia;
  final String? descricaoVigencia;
  final String? criterioLancamento;
  final String? apuracao;
  final String? microempreeIndividual;
  final String? calcPisCofinsEfd;
  final String? simplesCodigoAcesso;
  final String? simplesTabela;
  final String? simplesAtividade;
  final String? perfilSped;
  final String? apuracaoConsolidada;
  final String? substituicaoTributaria;
  final String? formaCalculoIss;
  const FiscalParametro(
      {this.id,
      this.idFiscalEstadualPorte,
      this.idFiscalEstadualRegime,
      this.idFiscalMunicipalRegime,
      this.vigencia,
      this.descricaoVigencia,
      this.criterioLancamento,
      this.apuracao,
      this.microempreeIndividual,
      this.calcPisCofinsEfd,
      this.simplesCodigoAcesso,
      this.simplesTabela,
      this.simplesAtividade,
      this.perfilSped,
      this.apuracaoConsolidada,
      this.substituicaoTributaria,
      this.formaCalculoIss});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFiscalEstadualPorte != null) {
      map['id_fiscal_estadual_porte'] = Variable<int>(idFiscalEstadualPorte);
    }
    if (!nullToAbsent || idFiscalEstadualRegime != null) {
      map['id_fiscal_estadual_regime'] = Variable<int>(idFiscalEstadualRegime);
    }
    if (!nullToAbsent || idFiscalMunicipalRegime != null) {
      map['id_fiscal_municipal_regime'] =
          Variable<int>(idFiscalMunicipalRegime);
    }
    if (!nullToAbsent || vigencia != null) {
      map['vigencia'] = Variable<String>(vigencia);
    }
    if (!nullToAbsent || descricaoVigencia != null) {
      map['descricao_vigencia'] = Variable<String>(descricaoVigencia);
    }
    if (!nullToAbsent || criterioLancamento != null) {
      map['criterio_lancamento'] = Variable<String>(criterioLancamento);
    }
    if (!nullToAbsent || apuracao != null) {
      map['apuracao'] = Variable<String>(apuracao);
    }
    if (!nullToAbsent || microempreeIndividual != null) {
      map['microempree_individual'] = Variable<String>(microempreeIndividual);
    }
    if (!nullToAbsent || calcPisCofinsEfd != null) {
      map['calc_pis_cofins_efd'] = Variable<String>(calcPisCofinsEfd);
    }
    if (!nullToAbsent || simplesCodigoAcesso != null) {
      map['simples_codigo_acesso'] = Variable<String>(simplesCodigoAcesso);
    }
    if (!nullToAbsent || simplesTabela != null) {
      map['simples_tabela'] = Variable<String>(simplesTabela);
    }
    if (!nullToAbsent || simplesAtividade != null) {
      map['simples_atividade'] = Variable<String>(simplesAtividade);
    }
    if (!nullToAbsent || perfilSped != null) {
      map['perfil_sped'] = Variable<String>(perfilSped);
    }
    if (!nullToAbsent || apuracaoConsolidada != null) {
      map['apuracao_consolidada'] = Variable<String>(apuracaoConsolidada);
    }
    if (!nullToAbsent || substituicaoTributaria != null) {
      map['substituicao_tributaria'] = Variable<String>(substituicaoTributaria);
    }
    if (!nullToAbsent || formaCalculoIss != null) {
      map['forma_calculo_iss'] = Variable<String>(formaCalculoIss);
    }
    return map;
  }

  factory FiscalParametro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalParametro(
      id: serializer.fromJson<int?>(json['id']),
      idFiscalEstadualPorte:
          serializer.fromJson<int?>(json['idFiscalEstadualPorte']),
      idFiscalEstadualRegime:
          serializer.fromJson<int?>(json['idFiscalEstadualRegime']),
      idFiscalMunicipalRegime:
          serializer.fromJson<int?>(json['idFiscalMunicipalRegime']),
      vigencia: serializer.fromJson<String?>(json['vigencia']),
      descricaoVigencia:
          serializer.fromJson<String?>(json['descricaoVigencia']),
      criterioLancamento:
          serializer.fromJson<String?>(json['criterioLancamento']),
      apuracao: serializer.fromJson<String?>(json['apuracao']),
      microempreeIndividual:
          serializer.fromJson<String?>(json['microempreeIndividual']),
      calcPisCofinsEfd: serializer.fromJson<String?>(json['calcPisCofinsEfd']),
      simplesCodigoAcesso:
          serializer.fromJson<String?>(json['simplesCodigoAcesso']),
      simplesTabela: serializer.fromJson<String?>(json['simplesTabela']),
      simplesAtividade: serializer.fromJson<String?>(json['simplesAtividade']),
      perfilSped: serializer.fromJson<String?>(json['perfilSped']),
      apuracaoConsolidada:
          serializer.fromJson<String?>(json['apuracaoConsolidada']),
      substituicaoTributaria:
          serializer.fromJson<String?>(json['substituicaoTributaria']),
      formaCalculoIss: serializer.fromJson<String?>(json['formaCalculoIss']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFiscalEstadualPorte': serializer.toJson<int?>(idFiscalEstadualPorte),
      'idFiscalEstadualRegime': serializer.toJson<int?>(idFiscalEstadualRegime),
      'idFiscalMunicipalRegime':
          serializer.toJson<int?>(idFiscalMunicipalRegime),
      'vigencia': serializer.toJson<String?>(vigencia),
      'descricaoVigencia': serializer.toJson<String?>(descricaoVigencia),
      'criterioLancamento': serializer.toJson<String?>(criterioLancamento),
      'apuracao': serializer.toJson<String?>(apuracao),
      'microempreeIndividual':
          serializer.toJson<String?>(microempreeIndividual),
      'calcPisCofinsEfd': serializer.toJson<String?>(calcPisCofinsEfd),
      'simplesCodigoAcesso': serializer.toJson<String?>(simplesCodigoAcesso),
      'simplesTabela': serializer.toJson<String?>(simplesTabela),
      'simplesAtividade': serializer.toJson<String?>(simplesAtividade),
      'perfilSped': serializer.toJson<String?>(perfilSped),
      'apuracaoConsolidada': serializer.toJson<String?>(apuracaoConsolidada),
      'substituicaoTributaria':
          serializer.toJson<String?>(substituicaoTributaria),
      'formaCalculoIss': serializer.toJson<String?>(formaCalculoIss),
    };
  }

  FiscalParametro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFiscalEstadualPorte = const Value.absent(),
          Value<int?> idFiscalEstadualRegime = const Value.absent(),
          Value<int?> idFiscalMunicipalRegime = const Value.absent(),
          Value<String?> vigencia = const Value.absent(),
          Value<String?> descricaoVigencia = const Value.absent(),
          Value<String?> criterioLancamento = const Value.absent(),
          Value<String?> apuracao = const Value.absent(),
          Value<String?> microempreeIndividual = const Value.absent(),
          Value<String?> calcPisCofinsEfd = const Value.absent(),
          Value<String?> simplesCodigoAcesso = const Value.absent(),
          Value<String?> simplesTabela = const Value.absent(),
          Value<String?> simplesAtividade = const Value.absent(),
          Value<String?> perfilSped = const Value.absent(),
          Value<String?> apuracaoConsolidada = const Value.absent(),
          Value<String?> substituicaoTributaria = const Value.absent(),
          Value<String?> formaCalculoIss = const Value.absent()}) =>
      FiscalParametro(
        id: id.present ? id.value : this.id,
        idFiscalEstadualPorte: idFiscalEstadualPorte.present
            ? idFiscalEstadualPorte.value
            : this.idFiscalEstadualPorte,
        idFiscalEstadualRegime: idFiscalEstadualRegime.present
            ? idFiscalEstadualRegime.value
            : this.idFiscalEstadualRegime,
        idFiscalMunicipalRegime: idFiscalMunicipalRegime.present
            ? idFiscalMunicipalRegime.value
            : this.idFiscalMunicipalRegime,
        vigencia: vigencia.present ? vigencia.value : this.vigencia,
        descricaoVigencia: descricaoVigencia.present
            ? descricaoVigencia.value
            : this.descricaoVigencia,
        criterioLancamento: criterioLancamento.present
            ? criterioLancamento.value
            : this.criterioLancamento,
        apuracao: apuracao.present ? apuracao.value : this.apuracao,
        microempreeIndividual: microempreeIndividual.present
            ? microempreeIndividual.value
            : this.microempreeIndividual,
        calcPisCofinsEfd: calcPisCofinsEfd.present
            ? calcPisCofinsEfd.value
            : this.calcPisCofinsEfd,
        simplesCodigoAcesso: simplesCodigoAcesso.present
            ? simplesCodigoAcesso.value
            : this.simplesCodigoAcesso,
        simplesTabela:
            simplesTabela.present ? simplesTabela.value : this.simplesTabela,
        simplesAtividade: simplesAtividade.present
            ? simplesAtividade.value
            : this.simplesAtividade,
        perfilSped: perfilSped.present ? perfilSped.value : this.perfilSped,
        apuracaoConsolidada: apuracaoConsolidada.present
            ? apuracaoConsolidada.value
            : this.apuracaoConsolidada,
        substituicaoTributaria: substituicaoTributaria.present
            ? substituicaoTributaria.value
            : this.substituicaoTributaria,
        formaCalculoIss: formaCalculoIss.present
            ? formaCalculoIss.value
            : this.formaCalculoIss,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalParametro(')
          ..write('id: $id, ')
          ..write('idFiscalEstadualPorte: $idFiscalEstadualPorte, ')
          ..write('idFiscalEstadualRegime: $idFiscalEstadualRegime, ')
          ..write('idFiscalMunicipalRegime: $idFiscalMunicipalRegime, ')
          ..write('vigencia: $vigencia, ')
          ..write('descricaoVigencia: $descricaoVigencia, ')
          ..write('criterioLancamento: $criterioLancamento, ')
          ..write('apuracao: $apuracao, ')
          ..write('microempreeIndividual: $microempreeIndividual, ')
          ..write('calcPisCofinsEfd: $calcPisCofinsEfd, ')
          ..write('simplesCodigoAcesso: $simplesCodigoAcesso, ')
          ..write('simplesTabela: $simplesTabela, ')
          ..write('simplesAtividade: $simplesAtividade, ')
          ..write('perfilSped: $perfilSped, ')
          ..write('apuracaoConsolidada: $apuracaoConsolidada, ')
          ..write('substituicaoTributaria: $substituicaoTributaria, ')
          ..write('formaCalculoIss: $formaCalculoIss')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idFiscalEstadualPorte,
      idFiscalEstadualRegime,
      idFiscalMunicipalRegime,
      vigencia,
      descricaoVigencia,
      criterioLancamento,
      apuracao,
      microempreeIndividual,
      calcPisCofinsEfd,
      simplesCodigoAcesso,
      simplesTabela,
      simplesAtividade,
      perfilSped,
      apuracaoConsolidada,
      substituicaoTributaria,
      formaCalculoIss);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalParametro &&
          other.id == this.id &&
          other.idFiscalEstadualPorte == this.idFiscalEstadualPorte &&
          other.idFiscalEstadualRegime == this.idFiscalEstadualRegime &&
          other.idFiscalMunicipalRegime == this.idFiscalMunicipalRegime &&
          other.vigencia == this.vigencia &&
          other.descricaoVigencia == this.descricaoVigencia &&
          other.criterioLancamento == this.criterioLancamento &&
          other.apuracao == this.apuracao &&
          other.microempreeIndividual == this.microempreeIndividual &&
          other.calcPisCofinsEfd == this.calcPisCofinsEfd &&
          other.simplesCodigoAcesso == this.simplesCodigoAcesso &&
          other.simplesTabela == this.simplesTabela &&
          other.simplesAtividade == this.simplesAtividade &&
          other.perfilSped == this.perfilSped &&
          other.apuracaoConsolidada == this.apuracaoConsolidada &&
          other.substituicaoTributaria == this.substituicaoTributaria &&
          other.formaCalculoIss == this.formaCalculoIss);
}

class FiscalParametrosCompanion extends UpdateCompanion<FiscalParametro> {
  final Value<int?> id;
  final Value<int?> idFiscalEstadualPorte;
  final Value<int?> idFiscalEstadualRegime;
  final Value<int?> idFiscalMunicipalRegime;
  final Value<String?> vigencia;
  final Value<String?> descricaoVigencia;
  final Value<String?> criterioLancamento;
  final Value<String?> apuracao;
  final Value<String?> microempreeIndividual;
  final Value<String?> calcPisCofinsEfd;
  final Value<String?> simplesCodigoAcesso;
  final Value<String?> simplesTabela;
  final Value<String?> simplesAtividade;
  final Value<String?> perfilSped;
  final Value<String?> apuracaoConsolidada;
  final Value<String?> substituicaoTributaria;
  final Value<String?> formaCalculoIss;
  const FiscalParametrosCompanion({
    this.id = const Value.absent(),
    this.idFiscalEstadualPorte = const Value.absent(),
    this.idFiscalEstadualRegime = const Value.absent(),
    this.idFiscalMunicipalRegime = const Value.absent(),
    this.vigencia = const Value.absent(),
    this.descricaoVigencia = const Value.absent(),
    this.criterioLancamento = const Value.absent(),
    this.apuracao = const Value.absent(),
    this.microempreeIndividual = const Value.absent(),
    this.calcPisCofinsEfd = const Value.absent(),
    this.simplesCodigoAcesso = const Value.absent(),
    this.simplesTabela = const Value.absent(),
    this.simplesAtividade = const Value.absent(),
    this.perfilSped = const Value.absent(),
    this.apuracaoConsolidada = const Value.absent(),
    this.substituicaoTributaria = const Value.absent(),
    this.formaCalculoIss = const Value.absent(),
  });
  FiscalParametrosCompanion.insert({
    this.id = const Value.absent(),
    this.idFiscalEstadualPorte = const Value.absent(),
    this.idFiscalEstadualRegime = const Value.absent(),
    this.idFiscalMunicipalRegime = const Value.absent(),
    this.vigencia = const Value.absent(),
    this.descricaoVigencia = const Value.absent(),
    this.criterioLancamento = const Value.absent(),
    this.apuracao = const Value.absent(),
    this.microempreeIndividual = const Value.absent(),
    this.calcPisCofinsEfd = const Value.absent(),
    this.simplesCodigoAcesso = const Value.absent(),
    this.simplesTabela = const Value.absent(),
    this.simplesAtividade = const Value.absent(),
    this.perfilSped = const Value.absent(),
    this.apuracaoConsolidada = const Value.absent(),
    this.substituicaoTributaria = const Value.absent(),
    this.formaCalculoIss = const Value.absent(),
  });
  static Insertable<FiscalParametro> custom({
    Expression<int>? id,
    Expression<int>? idFiscalEstadualPorte,
    Expression<int>? idFiscalEstadualRegime,
    Expression<int>? idFiscalMunicipalRegime,
    Expression<String>? vigencia,
    Expression<String>? descricaoVigencia,
    Expression<String>? criterioLancamento,
    Expression<String>? apuracao,
    Expression<String>? microempreeIndividual,
    Expression<String>? calcPisCofinsEfd,
    Expression<String>? simplesCodigoAcesso,
    Expression<String>? simplesTabela,
    Expression<String>? simplesAtividade,
    Expression<String>? perfilSped,
    Expression<String>? apuracaoConsolidada,
    Expression<String>? substituicaoTributaria,
    Expression<String>? formaCalculoIss,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFiscalEstadualPorte != null)
        'id_fiscal_estadual_porte': idFiscalEstadualPorte,
      if (idFiscalEstadualRegime != null)
        'id_fiscal_estadual_regime': idFiscalEstadualRegime,
      if (idFiscalMunicipalRegime != null)
        'id_fiscal_municipal_regime': idFiscalMunicipalRegime,
      if (vigencia != null) 'vigencia': vigencia,
      if (descricaoVigencia != null) 'descricao_vigencia': descricaoVigencia,
      if (criterioLancamento != null) 'criterio_lancamento': criterioLancamento,
      if (apuracao != null) 'apuracao': apuracao,
      if (microempreeIndividual != null)
        'microempree_individual': microempreeIndividual,
      if (calcPisCofinsEfd != null) 'calc_pis_cofins_efd': calcPisCofinsEfd,
      if (simplesCodigoAcesso != null)
        'simples_codigo_acesso': simplesCodigoAcesso,
      if (simplesTabela != null) 'simples_tabela': simplesTabela,
      if (simplesAtividade != null) 'simples_atividade': simplesAtividade,
      if (perfilSped != null) 'perfil_sped': perfilSped,
      if (apuracaoConsolidada != null)
        'apuracao_consolidada': apuracaoConsolidada,
      if (substituicaoTributaria != null)
        'substituicao_tributaria': substituicaoTributaria,
      if (formaCalculoIss != null) 'forma_calculo_iss': formaCalculoIss,
    });
  }

  FiscalParametrosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFiscalEstadualPorte,
      Value<int?>? idFiscalEstadualRegime,
      Value<int?>? idFiscalMunicipalRegime,
      Value<String?>? vigencia,
      Value<String?>? descricaoVigencia,
      Value<String?>? criterioLancamento,
      Value<String?>? apuracao,
      Value<String?>? microempreeIndividual,
      Value<String?>? calcPisCofinsEfd,
      Value<String?>? simplesCodigoAcesso,
      Value<String?>? simplesTabela,
      Value<String?>? simplesAtividade,
      Value<String?>? perfilSped,
      Value<String?>? apuracaoConsolidada,
      Value<String?>? substituicaoTributaria,
      Value<String?>? formaCalculoIss}) {
    return FiscalParametrosCompanion(
      id: id ?? this.id,
      idFiscalEstadualPorte:
          idFiscalEstadualPorte ?? this.idFiscalEstadualPorte,
      idFiscalEstadualRegime:
          idFiscalEstadualRegime ?? this.idFiscalEstadualRegime,
      idFiscalMunicipalRegime:
          idFiscalMunicipalRegime ?? this.idFiscalMunicipalRegime,
      vigencia: vigencia ?? this.vigencia,
      descricaoVigencia: descricaoVigencia ?? this.descricaoVigencia,
      criterioLancamento: criterioLancamento ?? this.criterioLancamento,
      apuracao: apuracao ?? this.apuracao,
      microempreeIndividual:
          microempreeIndividual ?? this.microempreeIndividual,
      calcPisCofinsEfd: calcPisCofinsEfd ?? this.calcPisCofinsEfd,
      simplesCodigoAcesso: simplesCodigoAcesso ?? this.simplesCodigoAcesso,
      simplesTabela: simplesTabela ?? this.simplesTabela,
      simplesAtividade: simplesAtividade ?? this.simplesAtividade,
      perfilSped: perfilSped ?? this.perfilSped,
      apuracaoConsolidada: apuracaoConsolidada ?? this.apuracaoConsolidada,
      substituicaoTributaria:
          substituicaoTributaria ?? this.substituicaoTributaria,
      formaCalculoIss: formaCalculoIss ?? this.formaCalculoIss,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFiscalEstadualPorte.present) {
      map['id_fiscal_estadual_porte'] =
          Variable<int>(idFiscalEstadualPorte.value);
    }
    if (idFiscalEstadualRegime.present) {
      map['id_fiscal_estadual_regime'] =
          Variable<int>(idFiscalEstadualRegime.value);
    }
    if (idFiscalMunicipalRegime.present) {
      map['id_fiscal_municipal_regime'] =
          Variable<int>(idFiscalMunicipalRegime.value);
    }
    if (vigencia.present) {
      map['vigencia'] = Variable<String>(vigencia.value);
    }
    if (descricaoVigencia.present) {
      map['descricao_vigencia'] = Variable<String>(descricaoVigencia.value);
    }
    if (criterioLancamento.present) {
      map['criterio_lancamento'] = Variable<String>(criterioLancamento.value);
    }
    if (apuracao.present) {
      map['apuracao'] = Variable<String>(apuracao.value);
    }
    if (microempreeIndividual.present) {
      map['microempree_individual'] =
          Variable<String>(microempreeIndividual.value);
    }
    if (calcPisCofinsEfd.present) {
      map['calc_pis_cofins_efd'] = Variable<String>(calcPisCofinsEfd.value);
    }
    if (simplesCodigoAcesso.present) {
      map['simples_codigo_acesso'] =
          Variable<String>(simplesCodigoAcesso.value);
    }
    if (simplesTabela.present) {
      map['simples_tabela'] = Variable<String>(simplesTabela.value);
    }
    if (simplesAtividade.present) {
      map['simples_atividade'] = Variable<String>(simplesAtividade.value);
    }
    if (perfilSped.present) {
      map['perfil_sped'] = Variable<String>(perfilSped.value);
    }
    if (apuracaoConsolidada.present) {
      map['apuracao_consolidada'] = Variable<String>(apuracaoConsolidada.value);
    }
    if (substituicaoTributaria.present) {
      map['substituicao_tributaria'] =
          Variable<String>(substituicaoTributaria.value);
    }
    if (formaCalculoIss.present) {
      map['forma_calculo_iss'] = Variable<String>(formaCalculoIss.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalParametrosCompanion(')
          ..write('id: $id, ')
          ..write('idFiscalEstadualPorte: $idFiscalEstadualPorte, ')
          ..write('idFiscalEstadualRegime: $idFiscalEstadualRegime, ')
          ..write('idFiscalMunicipalRegime: $idFiscalMunicipalRegime, ')
          ..write('vigencia: $vigencia, ')
          ..write('descricaoVigencia: $descricaoVigencia, ')
          ..write('criterioLancamento: $criterioLancamento, ')
          ..write('apuracao: $apuracao, ')
          ..write('microempreeIndividual: $microempreeIndividual, ')
          ..write('calcPisCofinsEfd: $calcPisCofinsEfd, ')
          ..write('simplesCodigoAcesso: $simplesCodigoAcesso, ')
          ..write('simplesTabela: $simplesTabela, ')
          ..write('simplesAtividade: $simplesAtividade, ')
          ..write('perfilSped: $perfilSped, ')
          ..write('apuracaoConsolidada: $apuracaoConsolidada, ')
          ..write('substituicaoTributaria: $substituicaoTributaria, ')
          ..write('formaCalculoIss: $formaCalculoIss')
          ..write(')'))
        .toString();
  }
}

class $FiscalLivrosTable extends FiscalLivros
    with TableInfo<$FiscalLivrosTable, FiscalLivro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalLivrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_livro';
  @override
  VerificationContext validateIntegrity(Insertable<FiscalLivro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalLivro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalLivro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $FiscalLivrosTable createAlias(String alias) {
    return $FiscalLivrosTable(attachedDatabase, alias);
  }
}

class FiscalLivro extends DataClass implements Insertable<FiscalLivro> {
  final int? id;
  final String? descricao;
  const FiscalLivro({this.id, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory FiscalLivro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalLivro(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  FiscalLivro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      FiscalLivro(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalLivro(')
          ..write('id: $id, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalLivro &&
          other.id == this.id &&
          other.descricao == this.descricao);
}

class FiscalLivrosCompanion extends UpdateCompanion<FiscalLivro> {
  final Value<int?> id;
  final Value<String?> descricao;
  const FiscalLivrosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  FiscalLivrosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<FiscalLivro> custom({
    Expression<int>? id,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
    });
  }

  FiscalLivrosCompanion copyWith({Value<int?>? id, Value<String?>? descricao}) {
    return FiscalLivrosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalLivrosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $SimplesNacionalCabecalhosTable extends SimplesNacionalCabecalhos
    with TableInfo<$SimplesNacionalCabecalhosTable, SimplesNacionalCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SimplesNacionalCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _vigenciaInicialMeta =
      const VerificationMeta('vigenciaInicial');
  @override
  late final GeneratedColumn<DateTime> vigenciaInicial =
      GeneratedColumn<DateTime>('vigencia_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _vigenciaFinalMeta =
      const VerificationMeta('vigenciaFinal');
  @override
  late final GeneratedColumn<DateTime> vigenciaFinal =
      GeneratedColumn<DateTime>('vigencia_final', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _anexoMeta = const VerificationMeta('anexo');
  @override
  late final GeneratedColumn<String> anexo = GeneratedColumn<String>(
      'anexo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tabelaMeta = const VerificationMeta('tabela');
  @override
  late final GeneratedColumn<String> tabela = GeneratedColumn<String>(
      'tabela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, vigenciaInicial, vigenciaFinal, anexo, tabela];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'simples_nacional_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<SimplesNacionalCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('vigencia_inicial')) {
      context.handle(
          _vigenciaInicialMeta,
          vigenciaInicial.isAcceptableOrUnknown(
              data['vigencia_inicial']!, _vigenciaInicialMeta));
    }
    if (data.containsKey('vigencia_final')) {
      context.handle(
          _vigenciaFinalMeta,
          vigenciaFinal.isAcceptableOrUnknown(
              data['vigencia_final']!, _vigenciaFinalMeta));
    }
    if (data.containsKey('anexo')) {
      context.handle(
          _anexoMeta, anexo.isAcceptableOrUnknown(data['anexo']!, _anexoMeta));
    }
    if (data.containsKey('tabela')) {
      context.handle(_tabelaMeta,
          tabela.isAcceptableOrUnknown(data['tabela']!, _tabelaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SimplesNacionalCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SimplesNacionalCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      vigenciaInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}vigencia_inicial']),
      vigenciaFinal: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}vigencia_final']),
      anexo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}anexo']),
      tabela: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tabela']),
    );
  }

  @override
  $SimplesNacionalCabecalhosTable createAlias(String alias) {
    return $SimplesNacionalCabecalhosTable(attachedDatabase, alias);
  }
}

class SimplesNacionalCabecalho extends DataClass
    implements Insertable<SimplesNacionalCabecalho> {
  final int? id;
  final DateTime? vigenciaInicial;
  final DateTime? vigenciaFinal;
  final String? anexo;
  final String? tabela;
  const SimplesNacionalCabecalho(
      {this.id,
      this.vigenciaInicial,
      this.vigenciaFinal,
      this.anexo,
      this.tabela});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || vigenciaInicial != null) {
      map['vigencia_inicial'] = Variable<DateTime>(vigenciaInicial);
    }
    if (!nullToAbsent || vigenciaFinal != null) {
      map['vigencia_final'] = Variable<DateTime>(vigenciaFinal);
    }
    if (!nullToAbsent || anexo != null) {
      map['anexo'] = Variable<String>(anexo);
    }
    if (!nullToAbsent || tabela != null) {
      map['tabela'] = Variable<String>(tabela);
    }
    return map;
  }

  factory SimplesNacionalCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SimplesNacionalCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      vigenciaInicial: serializer.fromJson<DateTime?>(json['vigenciaInicial']),
      vigenciaFinal: serializer.fromJson<DateTime?>(json['vigenciaFinal']),
      anexo: serializer.fromJson<String?>(json['anexo']),
      tabela: serializer.fromJson<String?>(json['tabela']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'vigenciaInicial': serializer.toJson<DateTime?>(vigenciaInicial),
      'vigenciaFinal': serializer.toJson<DateTime?>(vigenciaFinal),
      'anexo': serializer.toJson<String?>(anexo),
      'tabela': serializer.toJson<String?>(tabela),
    };
  }

  SimplesNacionalCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> vigenciaInicial = const Value.absent(),
          Value<DateTime?> vigenciaFinal = const Value.absent(),
          Value<String?> anexo = const Value.absent(),
          Value<String?> tabela = const Value.absent()}) =>
      SimplesNacionalCabecalho(
        id: id.present ? id.value : this.id,
        vigenciaInicial: vigenciaInicial.present
            ? vigenciaInicial.value
            : this.vigenciaInicial,
        vigenciaFinal:
            vigenciaFinal.present ? vigenciaFinal.value : this.vigenciaFinal,
        anexo: anexo.present ? anexo.value : this.anexo,
        tabela: tabela.present ? tabela.value : this.tabela,
      );
  @override
  String toString() {
    return (StringBuffer('SimplesNacionalCabecalho(')
          ..write('id: $id, ')
          ..write('vigenciaInicial: $vigenciaInicial, ')
          ..write('vigenciaFinal: $vigenciaFinal, ')
          ..write('anexo: $anexo, ')
          ..write('tabela: $tabela')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, vigenciaInicial, vigenciaFinal, anexo, tabela);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SimplesNacionalCabecalho &&
          other.id == this.id &&
          other.vigenciaInicial == this.vigenciaInicial &&
          other.vigenciaFinal == this.vigenciaFinal &&
          other.anexo == this.anexo &&
          other.tabela == this.tabela);
}

class SimplesNacionalCabecalhosCompanion
    extends UpdateCompanion<SimplesNacionalCabecalho> {
  final Value<int?> id;
  final Value<DateTime?> vigenciaInicial;
  final Value<DateTime?> vigenciaFinal;
  final Value<String?> anexo;
  final Value<String?> tabela;
  const SimplesNacionalCabecalhosCompanion({
    this.id = const Value.absent(),
    this.vigenciaInicial = const Value.absent(),
    this.vigenciaFinal = const Value.absent(),
    this.anexo = const Value.absent(),
    this.tabela = const Value.absent(),
  });
  SimplesNacionalCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.vigenciaInicial = const Value.absent(),
    this.vigenciaFinal = const Value.absent(),
    this.anexo = const Value.absent(),
    this.tabela = const Value.absent(),
  });
  static Insertable<SimplesNacionalCabecalho> custom({
    Expression<int>? id,
    Expression<DateTime>? vigenciaInicial,
    Expression<DateTime>? vigenciaFinal,
    Expression<String>? anexo,
    Expression<String>? tabela,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (vigenciaInicial != null) 'vigencia_inicial': vigenciaInicial,
      if (vigenciaFinal != null) 'vigencia_final': vigenciaFinal,
      if (anexo != null) 'anexo': anexo,
      if (tabela != null) 'tabela': tabela,
    });
  }

  SimplesNacionalCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? vigenciaInicial,
      Value<DateTime?>? vigenciaFinal,
      Value<String?>? anexo,
      Value<String?>? tabela}) {
    return SimplesNacionalCabecalhosCompanion(
      id: id ?? this.id,
      vigenciaInicial: vigenciaInicial ?? this.vigenciaInicial,
      vigenciaFinal: vigenciaFinal ?? this.vigenciaFinal,
      anexo: anexo ?? this.anexo,
      tabela: tabela ?? this.tabela,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (vigenciaInicial.present) {
      map['vigencia_inicial'] = Variable<DateTime>(vigenciaInicial.value);
    }
    if (vigenciaFinal.present) {
      map['vigencia_final'] = Variable<DateTime>(vigenciaFinal.value);
    }
    if (anexo.present) {
      map['anexo'] = Variable<String>(anexo.value);
    }
    if (tabela.present) {
      map['tabela'] = Variable<String>(tabela.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SimplesNacionalCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('vigenciaInicial: $vigenciaInicial, ')
          ..write('vigenciaFinal: $vigenciaFinal, ')
          ..write('anexo: $anexo, ')
          ..write('tabela: $tabela')
          ..write(')'))
        .toString();
  }
}

class $NfeCabecalhosTable extends NfeCabecalhos
    with TableInfo<$NfeCabecalhosTable, NfeCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NfeCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendedorMeta =
      const VerificationMeta('idVendedor');
  @override
  late final GeneratedColumn<int> idVendedor = GeneratedColumn<int>(
      'id_vendedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufEmitenteMeta =
      const VerificationMeta('ufEmitente');
  @override
  late final GeneratedColumn<int> ufEmitente = GeneratedColumn<int>(
      'uf_emitente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoNumericoMeta =
      const VerificationMeta('codigoNumerico');
  @override
  late final GeneratedColumn<String> codigoNumerico = GeneratedColumn<String>(
      'codigo_numerico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturezaOperacaoMeta =
      const VerificationMeta('naturezaOperacao');
  @override
  late final GeneratedColumn<String> naturezaOperacao = GeneratedColumn<String>(
      'natureza_operacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoModeloMeta =
      const VerificationMeta('codigoModelo');
  @override
  late final GeneratedColumn<String> codigoModelo = GeneratedColumn<String>(
      'codigo_modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 9),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataHoraEmissaoMeta =
      const VerificationMeta('dataHoraEmissao');
  @override
  late final GeneratedColumn<DateTime> dataHoraEmissao =
      GeneratedColumn<DateTime>('data_hora_emissao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataHoraEntradaSaidaMeta =
      const VerificationMeta('dataHoraEntradaSaida');
  @override
  late final GeneratedColumn<DateTime> dataHoraEntradaSaida =
      GeneratedColumn<DateTime>('data_hora_entrada_saida', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoOperacaoMeta =
      const VerificationMeta('tipoOperacao');
  @override
  late final GeneratedColumn<String> tipoOperacao = GeneratedColumn<String>(
      'tipo_operacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _localDestinoMeta =
      const VerificationMeta('localDestino');
  @override
  late final GeneratedColumn<String> localDestino = GeneratedColumn<String>(
      'local_destino', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMunicipioMeta =
      const VerificationMeta('codigoMunicipio');
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
      'codigo_municipio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _formatoImpressaoDanfeMeta =
      const VerificationMeta('formatoImpressaoDanfe');
  @override
  late final GeneratedColumn<String> formatoImpressaoDanfe =
      GeneratedColumn<String>('formato_impressao_danfe', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _tipoEmissaoMeta =
      const VerificationMeta('tipoEmissao');
  @override
  late final GeneratedColumn<String> tipoEmissao = GeneratedColumn<String>(
      'tipo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _chaveAcessoMeta =
      const VerificationMeta('chaveAcesso');
  @override
  late final GeneratedColumn<String> chaveAcesso = GeneratedColumn<String>(
      'chave_acesso', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 44),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _digitoChaveAcessoMeta =
      const VerificationMeta('digitoChaveAcesso');
  @override
  late final GeneratedColumn<String> digitoChaveAcesso =
      GeneratedColumn<String>('digito_chave_acesso', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _ambienteMeta =
      const VerificationMeta('ambiente');
  @override
  late final GeneratedColumn<String> ambiente = GeneratedColumn<String>(
      'ambiente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _finalidadeEmissaoMeta =
      const VerificationMeta('finalidadeEmissao');
  @override
  late final GeneratedColumn<String> finalidadeEmissao =
      GeneratedColumn<String>('finalidade_emissao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _consumidorOperacaoMeta =
      const VerificationMeta('consumidorOperacao');
  @override
  late final GeneratedColumn<String> consumidorOperacao =
      GeneratedColumn<String>('consumidor_operacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _consumidorPresencaMeta =
      const VerificationMeta('consumidorPresenca');
  @override
  late final GeneratedColumn<String> consumidorPresenca =
      GeneratedColumn<String>('consumidor_presenca', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _processoEmissaoMeta =
      const VerificationMeta('processoEmissao');
  @override
  late final GeneratedColumn<String> processoEmissao = GeneratedColumn<String>(
      'processo_emissao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _versaoProcessoEmissaoMeta =
      const VerificationMeta('versaoProcessoEmissao');
  @override
  late final GeneratedColumn<String> versaoProcessoEmissao =
      GeneratedColumn<String>('versao_processo_emissao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataEntradaContingenciaMeta =
      const VerificationMeta('dataEntradaContingencia');
  @override
  late final GeneratedColumn<DateTime> dataEntradaContingencia =
      GeneratedColumn<DateTime>('data_entrada_contingencia', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _justificativaContingenciaMeta =
      const VerificationMeta('justificativaContingencia');
  @override
  late final GeneratedColumn<String> justificativaContingencia =
      GeneratedColumn<String>('justificativa_contingencia', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 255),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsMeta =
      const VerificationMeta('baseCalculoIcms');
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
      'base_calculo_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsMeta =
      const VerificationMeta('valorIcms');
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
      'valor_icms', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsDesoneradoMeta =
      const VerificationMeta('valorIcmsDesonerado');
  @override
  late final GeneratedColumn<double> valorIcmsDesonerado =
      GeneratedColumn<double>('valor_icms_desonerado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalIcmsFcpUfDestinoMeta =
      const VerificationMeta('totalIcmsFcpUfDestino');
  @override
  late final GeneratedColumn<double> totalIcmsFcpUfDestino =
      GeneratedColumn<double>('total_icms_fcp_uf_destino', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalIcmsInterestadualUfDestinoMeta =
      const VerificationMeta('totalIcmsInterestadualUfDestino');
  @override
  late final GeneratedColumn<double> totalIcmsInterestadualUfDestino =
      GeneratedColumn<double>(
          'total_icms_interestadual_uf_destino', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalIcmsInterestadualUfRemetenteMeta =
      const VerificationMeta('totalIcmsInterestadualUfRemetente');
  @override
  late final GeneratedColumn<double> totalIcmsInterestadualUfRemetente =
      GeneratedColumn<double>(
          'total_icms_interestadual_uf_remetente', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalFcpMeta =
      const VerificationMeta('valorTotalFcp');
  @override
  late final GeneratedColumn<double> valorTotalFcp = GeneratedColumn<double>(
      'valor_total_fcp', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIcmsStMeta =
      const VerificationMeta('baseCalculoIcmsSt');
  @override
  late final GeneratedColumn<double> baseCalculoIcmsSt =
      GeneratedColumn<double>('base_calculo_icms_st', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsStMeta =
      const VerificationMeta('valorIcmsSt');
  @override
  late final GeneratedColumn<double> valorIcmsSt = GeneratedColumn<double>(
      'valor_icms_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalFcpStMeta =
      const VerificationMeta('valorTotalFcpSt');
  @override
  late final GeneratedColumn<double> valorTotalFcpSt = GeneratedColumn<double>(
      'valor_total_fcp_st', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalFcpStRetidoMeta =
      const VerificationMeta('valorTotalFcpStRetido');
  @override
  late final GeneratedColumn<double> valorTotalFcpStRetido =
      GeneratedColumn<double>('valor_total_fcp_st_retido', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalProdutosMeta =
      const VerificationMeta('valorTotalProdutos');
  @override
  late final GeneratedColumn<double> valorTotalProdutos =
      GeneratedColumn<double>('valor_total_produtos', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSeguroMeta =
      const VerificationMeta('valorSeguro');
  @override
  late final GeneratedColumn<double> valorSeguro = GeneratedColumn<double>(
      'valor_seguro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorImpostoImportacaoMeta =
      const VerificationMeta('valorImpostoImportacao');
  @override
  late final GeneratedColumn<double> valorImpostoImportacao =
      GeneratedColumn<double>('valor_imposto_importacao', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIpiMeta =
      const VerificationMeta('valorIpi');
  @override
  late final GeneratedColumn<double> valorIpi = GeneratedColumn<double>(
      'valor_ipi', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIpiDevolvidoMeta =
      const VerificationMeta('valorIpiDevolvido');
  @override
  late final GeneratedColumn<double> valorIpiDevolvido =
      GeneratedColumn<double>('valor_ipi_devolvido', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPisMeta =
      const VerificationMeta('valorPis');
  @override
  late final GeneratedColumn<double> valorPis = GeneratedColumn<double>(
      'valor_pis', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCofinsMeta =
      const VerificationMeta('valorCofins');
  @override
  late final GeneratedColumn<double> valorCofins = GeneratedColumn<double>(
      'valor_cofins', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDespesasAcessoriasMeta =
      const VerificationMeta('valorDespesasAcessorias');
  @override
  late final GeneratedColumn<double> valorDespesasAcessorias =
      GeneratedColumn<double>('valor_despesas_acessorias', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalTributosMeta =
      const VerificationMeta('valorTotalTributos');
  @override
  late final GeneratedColumn<double> valorTotalTributos =
      GeneratedColumn<double>('valor_total_tributos', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorServicosMeta =
      const VerificationMeta('valorServicos');
  @override
  late final GeneratedColumn<double> valorServicos = GeneratedColumn<double>(
      'valor_servicos', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIssqnMeta =
      const VerificationMeta('baseCalculoIssqn');
  @override
  late final GeneratedColumn<double> baseCalculoIssqn = GeneratedColumn<double>(
      'base_calculo_issqn', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIssqnMeta =
      const VerificationMeta('valorIssqn');
  @override
  late final GeneratedColumn<double> valorIssqn = GeneratedColumn<double>(
      'valor_issqn', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPisIssqnMeta =
      const VerificationMeta('valorPisIssqn');
  @override
  late final GeneratedColumn<double> valorPisIssqn = GeneratedColumn<double>(
      'valor_pis_issqn', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCofinsIssqnMeta =
      const VerificationMeta('valorCofinsIssqn');
  @override
  late final GeneratedColumn<double> valorCofinsIssqn = GeneratedColumn<double>(
      'valor_cofins_issqn', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataPrestacaoServicoMeta =
      const VerificationMeta('dataPrestacaoServico');
  @override
  late final GeneratedColumn<DateTime> dataPrestacaoServico =
      GeneratedColumn<DateTime>('data_prestacao_servico', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorDeducaoIssqnMeta =
      const VerificationMeta('valorDeducaoIssqn');
  @override
  late final GeneratedColumn<double> valorDeducaoIssqn =
      GeneratedColumn<double>('valor_deducao_issqn', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _outrasRetencoesIssqnMeta =
      const VerificationMeta('outrasRetencoesIssqn');
  @override
  late final GeneratedColumn<double> outrasRetencoesIssqn =
      GeneratedColumn<double>('outras_retencoes_issqn', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _descontoIncondicionadoIssqnMeta =
      const VerificationMeta('descontoIncondicionadoIssqn');
  @override
  late final GeneratedColumn<double> descontoIncondicionadoIssqn =
      GeneratedColumn<double>(
          'desconto_incondicionado_issqn', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _descontoCondicionadoIssqnMeta =
      const VerificationMeta('descontoCondicionadoIssqn');
  @override
  late final GeneratedColumn<double> descontoCondicionadoIssqn =
      GeneratedColumn<double>('desconto_condicionado_issqn', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _totalRetencaoIssqnMeta =
      const VerificationMeta('totalRetencaoIssqn');
  @override
  late final GeneratedColumn<double> totalRetencaoIssqn =
      GeneratedColumn<double>('total_retencao_issqn', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _regimeEspecialTributacaoMeta =
      const VerificationMeta('regimeEspecialTributacao');
  @override
  late final GeneratedColumn<String> regimeEspecialTributacao =
      GeneratedColumn<String>('regime_especial_tributacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorRetidoPisMeta =
      const VerificationMeta('valorRetidoPis');
  @override
  late final GeneratedColumn<double> valorRetidoPis = GeneratedColumn<double>(
      'valor_retido_pis', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRetidoCofinsMeta =
      const VerificationMeta('valorRetidoCofins');
  @override
  late final GeneratedColumn<double> valorRetidoCofins =
      GeneratedColumn<double>('valor_retido_cofins', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRetidoCsllMeta =
      const VerificationMeta('valorRetidoCsll');
  @override
  late final GeneratedColumn<double> valorRetidoCsll = GeneratedColumn<double>(
      'valor_retido_csll', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoIrrfMeta =
      const VerificationMeta('baseCalculoIrrf');
  @override
  late final GeneratedColumn<double> baseCalculoIrrf = GeneratedColumn<double>(
      'base_calculo_irrf', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRetidoIrrfMeta =
      const VerificationMeta('valorRetidoIrrf');
  @override
  late final GeneratedColumn<double> valorRetidoIrrf = GeneratedColumn<double>(
      'valor_retido_irrf', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _baseCalculoPrevidenciaMeta =
      const VerificationMeta('baseCalculoPrevidencia');
  @override
  late final GeneratedColumn<double> baseCalculoPrevidencia =
      GeneratedColumn<double>('base_calculo_previdencia', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorRetidoPrevidenciaMeta =
      const VerificationMeta('valorRetidoPrevidencia');
  @override
  late final GeneratedColumn<double> valorRetidoPrevidencia =
      GeneratedColumn<double>('valor_retido_previdencia', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _informacoesAddFiscoMeta =
      const VerificationMeta('informacoesAddFisco');
  @override
  late final GeneratedColumn<String> informacoesAddFisco =
      GeneratedColumn<String>('informacoes_add_fisco', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _informacoesAddContribuinteMeta =
      const VerificationMeta('informacoesAddContribuinte');
  @override
  late final GeneratedColumn<String> informacoesAddContribuinte =
      GeneratedColumn<String>('informacoes_add_contribuinte', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _comexUfEmbarqueMeta =
      const VerificationMeta('comexUfEmbarque');
  @override
  late final GeneratedColumn<String> comexUfEmbarque = GeneratedColumn<String>(
      'comex_uf_embarque', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _comexLocalEmbarqueMeta =
      const VerificationMeta('comexLocalEmbarque');
  @override
  late final GeneratedColumn<String> comexLocalEmbarque =
      GeneratedColumn<String>('comex_local_embarque', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _comexLocalDespachoMeta =
      const VerificationMeta('comexLocalDespacho');
  @override
  late final GeneratedColumn<String> comexLocalDespacho =
      GeneratedColumn<String>('comex_local_despacho', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 60),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _compraNotaEmpenhoMeta =
      const VerificationMeta('compraNotaEmpenho');
  @override
  late final GeneratedColumn<String> compraNotaEmpenho =
      GeneratedColumn<String>('compra_nota_empenho', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 22),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _compraPedidoMeta =
      const VerificationMeta('compraPedido');
  @override
  late final GeneratedColumn<String> compraPedido = GeneratedColumn<String>(
      'compra_pedido', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _compraContratoMeta =
      const VerificationMeta('compraContrato');
  @override
  late final GeneratedColumn<String> compraContrato = GeneratedColumn<String>(
      'compra_contrato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 60),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _qrcodeMeta = const VerificationMeta('qrcode');
  @override
  late final GeneratedColumn<String> qrcode = GeneratedColumn<String>(
      'qrcode', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _urlChaveMeta =
      const VerificationMeta('urlChave');
  @override
  late final GeneratedColumn<String> urlChave = GeneratedColumn<String>(
      'url_chave', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 85),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _statusNotaMeta =
      const VerificationMeta('statusNota');
  @override
  late final GeneratedColumn<String> statusNota = GeneratedColumn<String>(
      'status_nota', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFornecedorMeta =
      const VerificationMeta('idFornecedor');
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
      'id_fornecedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfceMovimentoMeta =
      const VerificationMeta('idNfceMovimento');
  @override
  late final GeneratedColumn<int> idNfceMovimento = GeneratedColumn<int>(
      'id_nfce_movimento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributOperacaoFiscalMeta =
      const VerificationMeta('idTributOperacaoFiscal');
  @override
  late final GeneratedColumn<int> idTributOperacaoFiscal = GeneratedColumn<int>(
      'id_tribut_operacao_fiscal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendedor,
        ufEmitente,
        codigoNumerico,
        naturezaOperacao,
        codigoModelo,
        serie,
        numero,
        dataHoraEmissao,
        dataHoraEntradaSaida,
        tipoOperacao,
        localDestino,
        codigoMunicipio,
        formatoImpressaoDanfe,
        tipoEmissao,
        chaveAcesso,
        digitoChaveAcesso,
        ambiente,
        finalidadeEmissao,
        consumidorOperacao,
        consumidorPresenca,
        processoEmissao,
        versaoProcessoEmissao,
        dataEntradaContingencia,
        justificativaContingencia,
        baseCalculoIcms,
        valorIcms,
        valorIcmsDesonerado,
        totalIcmsFcpUfDestino,
        totalIcmsInterestadualUfDestino,
        totalIcmsInterestadualUfRemetente,
        valorTotalFcp,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalFcpSt,
        valorTotalFcpStRetido,
        valorTotalProdutos,
        valorFrete,
        valorSeguro,
        valorDesconto,
        valorImpostoImportacao,
        valorIpi,
        valorIpiDevolvido,
        valorPis,
        valorCofins,
        valorDespesasAcessorias,
        valorTotal,
        valorTotalTributos,
        valorServicos,
        baseCalculoIssqn,
        valorIssqn,
        valorPisIssqn,
        valorCofinsIssqn,
        dataPrestacaoServico,
        valorDeducaoIssqn,
        outrasRetencoesIssqn,
        descontoIncondicionadoIssqn,
        descontoCondicionadoIssqn,
        totalRetencaoIssqn,
        regimeEspecialTributacao,
        valorRetidoPis,
        valorRetidoCofins,
        valorRetidoCsll,
        baseCalculoIrrf,
        valorRetidoIrrf,
        baseCalculoPrevidencia,
        valorRetidoPrevidencia,
        informacoesAddFisco,
        informacoesAddContribuinte,
        comexUfEmbarque,
        comexLocalEmbarque,
        comexLocalDespacho,
        compraNotaEmpenho,
        compraPedido,
        compraContrato,
        qrcode,
        urlChave,
        statusNota,
        idFornecedor,
        idNfceMovimento,
        idVendaCabecalho,
        idTributOperacaoFiscal,
        idCliente
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nfe_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<NfeCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_vendedor')) {
      context.handle(
          _idVendedorMeta,
          idVendedor.isAcceptableOrUnknown(
              data['id_vendedor']!, _idVendedorMeta));
    }
    if (data.containsKey('uf_emitente')) {
      context.handle(
          _ufEmitenteMeta,
          ufEmitente.isAcceptableOrUnknown(
              data['uf_emitente']!, _ufEmitenteMeta));
    }
    if (data.containsKey('codigo_numerico')) {
      context.handle(
          _codigoNumericoMeta,
          codigoNumerico.isAcceptableOrUnknown(
              data['codigo_numerico']!, _codigoNumericoMeta));
    }
    if (data.containsKey('natureza_operacao')) {
      context.handle(
          _naturezaOperacaoMeta,
          naturezaOperacao.isAcceptableOrUnknown(
              data['natureza_operacao']!, _naturezaOperacaoMeta));
    }
    if (data.containsKey('codigo_modelo')) {
      context.handle(
          _codigoModeloMeta,
          codigoModelo.isAcceptableOrUnknown(
              data['codigo_modelo']!, _codigoModeloMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_hora_emissao')) {
      context.handle(
          _dataHoraEmissaoMeta,
          dataHoraEmissao.isAcceptableOrUnknown(
              data['data_hora_emissao']!, _dataHoraEmissaoMeta));
    }
    if (data.containsKey('data_hora_entrada_saida')) {
      context.handle(
          _dataHoraEntradaSaidaMeta,
          dataHoraEntradaSaida.isAcceptableOrUnknown(
              data['data_hora_entrada_saida']!, _dataHoraEntradaSaidaMeta));
    }
    if (data.containsKey('tipo_operacao')) {
      context.handle(
          _tipoOperacaoMeta,
          tipoOperacao.isAcceptableOrUnknown(
              data['tipo_operacao']!, _tipoOperacaoMeta));
    }
    if (data.containsKey('local_destino')) {
      context.handle(
          _localDestinoMeta,
          localDestino.isAcceptableOrUnknown(
              data['local_destino']!, _localDestinoMeta));
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
          _codigoMunicipioMeta,
          codigoMunicipio.isAcceptableOrUnknown(
              data['codigo_municipio']!, _codigoMunicipioMeta));
    }
    if (data.containsKey('formato_impressao_danfe')) {
      context.handle(
          _formatoImpressaoDanfeMeta,
          formatoImpressaoDanfe.isAcceptableOrUnknown(
              data['formato_impressao_danfe']!, _formatoImpressaoDanfeMeta));
    }
    if (data.containsKey('tipo_emissao')) {
      context.handle(
          _tipoEmissaoMeta,
          tipoEmissao.isAcceptableOrUnknown(
              data['tipo_emissao']!, _tipoEmissaoMeta));
    }
    if (data.containsKey('chave_acesso')) {
      context.handle(
          _chaveAcessoMeta,
          chaveAcesso.isAcceptableOrUnknown(
              data['chave_acesso']!, _chaveAcessoMeta));
    }
    if (data.containsKey('digito_chave_acesso')) {
      context.handle(
          _digitoChaveAcessoMeta,
          digitoChaveAcesso.isAcceptableOrUnknown(
              data['digito_chave_acesso']!, _digitoChaveAcessoMeta));
    }
    if (data.containsKey('ambiente')) {
      context.handle(_ambienteMeta,
          ambiente.isAcceptableOrUnknown(data['ambiente']!, _ambienteMeta));
    }
    if (data.containsKey('finalidade_emissao')) {
      context.handle(
          _finalidadeEmissaoMeta,
          finalidadeEmissao.isAcceptableOrUnknown(
              data['finalidade_emissao']!, _finalidadeEmissaoMeta));
    }
    if (data.containsKey('consumidor_operacao')) {
      context.handle(
          _consumidorOperacaoMeta,
          consumidorOperacao.isAcceptableOrUnknown(
              data['consumidor_operacao']!, _consumidorOperacaoMeta));
    }
    if (data.containsKey('consumidor_presenca')) {
      context.handle(
          _consumidorPresencaMeta,
          consumidorPresenca.isAcceptableOrUnknown(
              data['consumidor_presenca']!, _consumidorPresencaMeta));
    }
    if (data.containsKey('processo_emissao')) {
      context.handle(
          _processoEmissaoMeta,
          processoEmissao.isAcceptableOrUnknown(
              data['processo_emissao']!, _processoEmissaoMeta));
    }
    if (data.containsKey('versao_processo_emissao')) {
      context.handle(
          _versaoProcessoEmissaoMeta,
          versaoProcessoEmissao.isAcceptableOrUnknown(
              data['versao_processo_emissao']!, _versaoProcessoEmissaoMeta));
    }
    if (data.containsKey('data_entrada_contingencia')) {
      context.handle(
          _dataEntradaContingenciaMeta,
          dataEntradaContingencia.isAcceptableOrUnknown(
              data['data_entrada_contingencia']!,
              _dataEntradaContingenciaMeta));
    }
    if (data.containsKey('justificativa_contingencia')) {
      context.handle(
          _justificativaContingenciaMeta,
          justificativaContingencia.isAcceptableOrUnknown(
              data['justificativa_contingencia']!,
              _justificativaContingenciaMeta));
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
          _baseCalculoIcmsMeta,
          baseCalculoIcms.isAcceptableOrUnknown(
              data['base_calculo_icms']!, _baseCalculoIcmsMeta));
    }
    if (data.containsKey('valor_icms')) {
      context.handle(_valorIcmsMeta,
          valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta));
    }
    if (data.containsKey('valor_icms_desonerado')) {
      context.handle(
          _valorIcmsDesoneradoMeta,
          valorIcmsDesonerado.isAcceptableOrUnknown(
              data['valor_icms_desonerado']!, _valorIcmsDesoneradoMeta));
    }
    if (data.containsKey('total_icms_fcp_uf_destino')) {
      context.handle(
          _totalIcmsFcpUfDestinoMeta,
          totalIcmsFcpUfDestino.isAcceptableOrUnknown(
              data['total_icms_fcp_uf_destino']!, _totalIcmsFcpUfDestinoMeta));
    }
    if (data.containsKey('total_icms_interestadual_uf_destino')) {
      context.handle(
          _totalIcmsInterestadualUfDestinoMeta,
          totalIcmsInterestadualUfDestino.isAcceptableOrUnknown(
              data['total_icms_interestadual_uf_destino']!,
              _totalIcmsInterestadualUfDestinoMeta));
    }
    if (data.containsKey('total_icms_interestadual_uf_remetente')) {
      context.handle(
          _totalIcmsInterestadualUfRemetenteMeta,
          totalIcmsInterestadualUfRemetente.isAcceptableOrUnknown(
              data['total_icms_interestadual_uf_remetente']!,
              _totalIcmsInterestadualUfRemetenteMeta));
    }
    if (data.containsKey('valor_total_fcp')) {
      context.handle(
          _valorTotalFcpMeta,
          valorTotalFcp.isAcceptableOrUnknown(
              data['valor_total_fcp']!, _valorTotalFcpMeta));
    }
    if (data.containsKey('base_calculo_icms_st')) {
      context.handle(
          _baseCalculoIcmsStMeta,
          baseCalculoIcmsSt.isAcceptableOrUnknown(
              data['base_calculo_icms_st']!, _baseCalculoIcmsStMeta));
    }
    if (data.containsKey('valor_icms_st')) {
      context.handle(
          _valorIcmsStMeta,
          valorIcmsSt.isAcceptableOrUnknown(
              data['valor_icms_st']!, _valorIcmsStMeta));
    }
    if (data.containsKey('valor_total_fcp_st')) {
      context.handle(
          _valorTotalFcpStMeta,
          valorTotalFcpSt.isAcceptableOrUnknown(
              data['valor_total_fcp_st']!, _valorTotalFcpStMeta));
    }
    if (data.containsKey('valor_total_fcp_st_retido')) {
      context.handle(
          _valorTotalFcpStRetidoMeta,
          valorTotalFcpStRetido.isAcceptableOrUnknown(
              data['valor_total_fcp_st_retido']!, _valorTotalFcpStRetidoMeta));
    }
    if (data.containsKey('valor_total_produtos')) {
      context.handle(
          _valorTotalProdutosMeta,
          valorTotalProdutos.isAcceptableOrUnknown(
              data['valor_total_produtos']!, _valorTotalProdutosMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    if (data.containsKey('valor_seguro')) {
      context.handle(
          _valorSeguroMeta,
          valorSeguro.isAcceptableOrUnknown(
              data['valor_seguro']!, _valorSeguroMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_imposto_importacao')) {
      context.handle(
          _valorImpostoImportacaoMeta,
          valorImpostoImportacao.isAcceptableOrUnknown(
              data['valor_imposto_importacao']!, _valorImpostoImportacaoMeta));
    }
    if (data.containsKey('valor_ipi')) {
      context.handle(_valorIpiMeta,
          valorIpi.isAcceptableOrUnknown(data['valor_ipi']!, _valorIpiMeta));
    }
    if (data.containsKey('valor_ipi_devolvido')) {
      context.handle(
          _valorIpiDevolvidoMeta,
          valorIpiDevolvido.isAcceptableOrUnknown(
              data['valor_ipi_devolvido']!, _valorIpiDevolvidoMeta));
    }
    if (data.containsKey('valor_pis')) {
      context.handle(_valorPisMeta,
          valorPis.isAcceptableOrUnknown(data['valor_pis']!, _valorPisMeta));
    }
    if (data.containsKey('valor_cofins')) {
      context.handle(
          _valorCofinsMeta,
          valorCofins.isAcceptableOrUnknown(
              data['valor_cofins']!, _valorCofinsMeta));
    }
    if (data.containsKey('valor_despesas_acessorias')) {
      context.handle(
          _valorDespesasAcessoriasMeta,
          valorDespesasAcessorias.isAcceptableOrUnknown(
              data['valor_despesas_acessorias']!,
              _valorDespesasAcessoriasMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('valor_total_tributos')) {
      context.handle(
          _valorTotalTributosMeta,
          valorTotalTributos.isAcceptableOrUnknown(
              data['valor_total_tributos']!, _valorTotalTributosMeta));
    }
    if (data.containsKey('valor_servicos')) {
      context.handle(
          _valorServicosMeta,
          valorServicos.isAcceptableOrUnknown(
              data['valor_servicos']!, _valorServicosMeta));
    }
    if (data.containsKey('base_calculo_issqn')) {
      context.handle(
          _baseCalculoIssqnMeta,
          baseCalculoIssqn.isAcceptableOrUnknown(
              data['base_calculo_issqn']!, _baseCalculoIssqnMeta));
    }
    if (data.containsKey('valor_issqn')) {
      context.handle(
          _valorIssqnMeta,
          valorIssqn.isAcceptableOrUnknown(
              data['valor_issqn']!, _valorIssqnMeta));
    }
    if (data.containsKey('valor_pis_issqn')) {
      context.handle(
          _valorPisIssqnMeta,
          valorPisIssqn.isAcceptableOrUnknown(
              data['valor_pis_issqn']!, _valorPisIssqnMeta));
    }
    if (data.containsKey('valor_cofins_issqn')) {
      context.handle(
          _valorCofinsIssqnMeta,
          valorCofinsIssqn.isAcceptableOrUnknown(
              data['valor_cofins_issqn']!, _valorCofinsIssqnMeta));
    }
    if (data.containsKey('data_prestacao_servico')) {
      context.handle(
          _dataPrestacaoServicoMeta,
          dataPrestacaoServico.isAcceptableOrUnknown(
              data['data_prestacao_servico']!, _dataPrestacaoServicoMeta));
    }
    if (data.containsKey('valor_deducao_issqn')) {
      context.handle(
          _valorDeducaoIssqnMeta,
          valorDeducaoIssqn.isAcceptableOrUnknown(
              data['valor_deducao_issqn']!, _valorDeducaoIssqnMeta));
    }
    if (data.containsKey('outras_retencoes_issqn')) {
      context.handle(
          _outrasRetencoesIssqnMeta,
          outrasRetencoesIssqn.isAcceptableOrUnknown(
              data['outras_retencoes_issqn']!, _outrasRetencoesIssqnMeta));
    }
    if (data.containsKey('desconto_incondicionado_issqn')) {
      context.handle(
          _descontoIncondicionadoIssqnMeta,
          descontoIncondicionadoIssqn.isAcceptableOrUnknown(
              data['desconto_incondicionado_issqn']!,
              _descontoIncondicionadoIssqnMeta));
    }
    if (data.containsKey('desconto_condicionado_issqn')) {
      context.handle(
          _descontoCondicionadoIssqnMeta,
          descontoCondicionadoIssqn.isAcceptableOrUnknown(
              data['desconto_condicionado_issqn']!,
              _descontoCondicionadoIssqnMeta));
    }
    if (data.containsKey('total_retencao_issqn')) {
      context.handle(
          _totalRetencaoIssqnMeta,
          totalRetencaoIssqn.isAcceptableOrUnknown(
              data['total_retencao_issqn']!, _totalRetencaoIssqnMeta));
    }
    if (data.containsKey('regime_especial_tributacao')) {
      context.handle(
          _regimeEspecialTributacaoMeta,
          regimeEspecialTributacao.isAcceptableOrUnknown(
              data['regime_especial_tributacao']!,
              _regimeEspecialTributacaoMeta));
    }
    if (data.containsKey('valor_retido_pis')) {
      context.handle(
          _valorRetidoPisMeta,
          valorRetidoPis.isAcceptableOrUnknown(
              data['valor_retido_pis']!, _valorRetidoPisMeta));
    }
    if (data.containsKey('valor_retido_cofins')) {
      context.handle(
          _valorRetidoCofinsMeta,
          valorRetidoCofins.isAcceptableOrUnknown(
              data['valor_retido_cofins']!, _valorRetidoCofinsMeta));
    }
    if (data.containsKey('valor_retido_csll')) {
      context.handle(
          _valorRetidoCsllMeta,
          valorRetidoCsll.isAcceptableOrUnknown(
              data['valor_retido_csll']!, _valorRetidoCsllMeta));
    }
    if (data.containsKey('base_calculo_irrf')) {
      context.handle(
          _baseCalculoIrrfMeta,
          baseCalculoIrrf.isAcceptableOrUnknown(
              data['base_calculo_irrf']!, _baseCalculoIrrfMeta));
    }
    if (data.containsKey('valor_retido_irrf')) {
      context.handle(
          _valorRetidoIrrfMeta,
          valorRetidoIrrf.isAcceptableOrUnknown(
              data['valor_retido_irrf']!, _valorRetidoIrrfMeta));
    }
    if (data.containsKey('base_calculo_previdencia')) {
      context.handle(
          _baseCalculoPrevidenciaMeta,
          baseCalculoPrevidencia.isAcceptableOrUnknown(
              data['base_calculo_previdencia']!, _baseCalculoPrevidenciaMeta));
    }
    if (data.containsKey('valor_retido_previdencia')) {
      context.handle(
          _valorRetidoPrevidenciaMeta,
          valorRetidoPrevidencia.isAcceptableOrUnknown(
              data['valor_retido_previdencia']!, _valorRetidoPrevidenciaMeta));
    }
    if (data.containsKey('informacoes_add_fisco')) {
      context.handle(
          _informacoesAddFiscoMeta,
          informacoesAddFisco.isAcceptableOrUnknown(
              data['informacoes_add_fisco']!, _informacoesAddFiscoMeta));
    }
    if (data.containsKey('informacoes_add_contribuinte')) {
      context.handle(
          _informacoesAddContribuinteMeta,
          informacoesAddContribuinte.isAcceptableOrUnknown(
              data['informacoes_add_contribuinte']!,
              _informacoesAddContribuinteMeta));
    }
    if (data.containsKey('comex_uf_embarque')) {
      context.handle(
          _comexUfEmbarqueMeta,
          comexUfEmbarque.isAcceptableOrUnknown(
              data['comex_uf_embarque']!, _comexUfEmbarqueMeta));
    }
    if (data.containsKey('comex_local_embarque')) {
      context.handle(
          _comexLocalEmbarqueMeta,
          comexLocalEmbarque.isAcceptableOrUnknown(
              data['comex_local_embarque']!, _comexLocalEmbarqueMeta));
    }
    if (data.containsKey('comex_local_despacho')) {
      context.handle(
          _comexLocalDespachoMeta,
          comexLocalDespacho.isAcceptableOrUnknown(
              data['comex_local_despacho']!, _comexLocalDespachoMeta));
    }
    if (data.containsKey('compra_nota_empenho')) {
      context.handle(
          _compraNotaEmpenhoMeta,
          compraNotaEmpenho.isAcceptableOrUnknown(
              data['compra_nota_empenho']!, _compraNotaEmpenhoMeta));
    }
    if (data.containsKey('compra_pedido')) {
      context.handle(
          _compraPedidoMeta,
          compraPedido.isAcceptableOrUnknown(
              data['compra_pedido']!, _compraPedidoMeta));
    }
    if (data.containsKey('compra_contrato')) {
      context.handle(
          _compraContratoMeta,
          compraContrato.isAcceptableOrUnknown(
              data['compra_contrato']!, _compraContratoMeta));
    }
    if (data.containsKey('qrcode')) {
      context.handle(_qrcodeMeta,
          qrcode.isAcceptableOrUnknown(data['qrcode']!, _qrcodeMeta));
    }
    if (data.containsKey('url_chave')) {
      context.handle(_urlChaveMeta,
          urlChave.isAcceptableOrUnknown(data['url_chave']!, _urlChaveMeta));
    }
    if (data.containsKey('status_nota')) {
      context.handle(
          _statusNotaMeta,
          statusNota.isAcceptableOrUnknown(
              data['status_nota']!, _statusNotaMeta));
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
          _idFornecedorMeta,
          idFornecedor.isAcceptableOrUnknown(
              data['id_fornecedor']!, _idFornecedorMeta));
    }
    if (data.containsKey('id_nfce_movimento')) {
      context.handle(
          _idNfceMovimentoMeta,
          idNfceMovimento.isAcceptableOrUnknown(
              data['id_nfce_movimento']!, _idNfceMovimentoMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_tribut_operacao_fiscal')) {
      context.handle(
          _idTributOperacaoFiscalMeta,
          idTributOperacaoFiscal.isAcceptableOrUnknown(
              data['id_tribut_operacao_fiscal']!, _idTributOperacaoFiscalMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NfeCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NfeCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_vendedor']),
      ufEmitente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}uf_emitente']),
      codigoNumerico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_numerico']),
      naturezaOperacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}natureza_operacao']),
      codigoModelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_modelo']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataHoraEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_hora_emissao']),
      dataHoraEntradaSaida: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_hora_entrada_saida']),
      tipoOperacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_operacao']),
      localDestino: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_destino']),
      codigoMunicipio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}codigo_municipio']),
      formatoImpressaoDanfe: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}formato_impressao_danfe']),
      tipoEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_emissao']),
      chaveAcesso: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}chave_acesso']),
      digitoChaveAcesso: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}digito_chave_acesso']),
      ambiente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ambiente']),
      finalidadeEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}finalidade_emissao']),
      consumidorOperacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}consumidor_operacao']),
      consumidorPresenca: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}consumidor_presenca']),
      processoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}processo_emissao']),
      versaoProcessoEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}versao_processo_emissao']),
      dataEntradaContingencia: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_entrada_contingencia']),
      justificativaContingencia: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}justificativa_contingencia']),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms']),
      valorIcms: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms']),
      valorIcmsDesonerado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_desonerado']),
      totalIcmsFcpUfDestino: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}total_icms_fcp_uf_destino']),
      totalIcmsInterestadualUfDestino: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}total_icms_interestadual_uf_destino']),
      totalIcmsInterestadualUfRemetente: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}total_icms_interestadual_uf_remetente']),
      valorTotalFcp: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total_fcp']),
      baseCalculoIcmsSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_icms_st']),
      valorIcmsSt: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_icms_st']),
      valorTotalFcpSt: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_fcp_st']),
      valorTotalFcpStRetido: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_total_fcp_st_retido']),
      valorTotalProdutos: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_produtos']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
      valorSeguro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_seguro']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorImpostoImportacao: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_imposto_importacao']),
      valorIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_ipi']),
      valorIpiDevolvido: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_ipi_devolvido']),
      valorPis: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pis']),
      valorCofins: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_cofins']),
      valorDespesasAcessorias: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_despesas_acessorias']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      valorTotalTributos: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_tributos']),
      valorServicos: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_servicos']),
      baseCalculoIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_issqn']),
      valorIssqn: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_issqn']),
      valorPisIssqn: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pis_issqn']),
      valorCofinsIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_cofins_issqn']),
      dataPrestacaoServico: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_prestacao_servico']),
      valorDeducaoIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_deducao_issqn']),
      outrasRetencoesIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}outras_retencoes_issqn']),
      descontoIncondicionadoIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}desconto_incondicionado_issqn']),
      descontoCondicionadoIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}desconto_condicionado_issqn']),
      totalRetencaoIssqn: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}total_retencao_issqn']),
      regimeEspecialTributacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}regime_especial_tributacao']),
      valorRetidoPis: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_retido_pis']),
      valorRetidoCofins: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_retido_cofins']),
      valorRetidoCsll: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_retido_csll']),
      baseCalculoIrrf: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}base_calculo_irrf']),
      valorRetidoIrrf: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_retido_irrf']),
      baseCalculoPrevidencia: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}base_calculo_previdencia']),
      valorRetidoPrevidencia: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_retido_previdencia']),
      informacoesAddFisco: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}informacoes_add_fisco']),
      informacoesAddContribuinte: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}informacoes_add_contribuinte']),
      comexUfEmbarque: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}comex_uf_embarque']),
      comexLocalEmbarque: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}comex_local_embarque']),
      comexLocalDespacho: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}comex_local_despacho']),
      compraNotaEmpenho: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}compra_nota_empenho']),
      compraPedido: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}compra_pedido']),
      compraContrato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}compra_contrato']),
      qrcode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}qrcode']),
      urlChave: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url_chave']),
      statusNota: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status_nota']),
      idFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fornecedor']),
      idNfceMovimento: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nfce_movimento']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idTributOperacaoFiscal: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_operacao_fiscal']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
    );
  }

  @override
  $NfeCabecalhosTable createAlias(String alias) {
    return $NfeCabecalhosTable(attachedDatabase, alias);
  }
}

class NfeCabecalho extends DataClass implements Insertable<NfeCabecalho> {
  final int? id;
  final int? idVendedor;
  final int? ufEmitente;
  final String? codigoNumerico;
  final String? naturezaOperacao;
  final String? codigoModelo;
  final String? serie;
  final String? numero;
  final DateTime? dataHoraEmissao;
  final DateTime? dataHoraEntradaSaida;
  final String? tipoOperacao;
  final String? localDestino;
  final int? codigoMunicipio;
  final String? formatoImpressaoDanfe;
  final String? tipoEmissao;
  final String? chaveAcesso;
  final String? digitoChaveAcesso;
  final String? ambiente;
  final String? finalidadeEmissao;
  final String? consumidorOperacao;
  final String? consumidorPresenca;
  final String? processoEmissao;
  final String? versaoProcessoEmissao;
  final DateTime? dataEntradaContingencia;
  final String? justificativaContingencia;
  final double? baseCalculoIcms;
  final double? valorIcms;
  final double? valorIcmsDesonerado;
  final double? totalIcmsFcpUfDestino;
  final double? totalIcmsInterestadualUfDestino;
  final double? totalIcmsInterestadualUfRemetente;
  final double? valorTotalFcp;
  final double? baseCalculoIcmsSt;
  final double? valorIcmsSt;
  final double? valorTotalFcpSt;
  final double? valorTotalFcpStRetido;
  final double? valorTotalProdutos;
  final double? valorFrete;
  final double? valorSeguro;
  final double? valorDesconto;
  final double? valorImpostoImportacao;
  final double? valorIpi;
  final double? valorIpiDevolvido;
  final double? valorPis;
  final double? valorCofins;
  final double? valorDespesasAcessorias;
  final double? valorTotal;
  final double? valorTotalTributos;
  final double? valorServicos;
  final double? baseCalculoIssqn;
  final double? valorIssqn;
  final double? valorPisIssqn;
  final double? valorCofinsIssqn;
  final DateTime? dataPrestacaoServico;
  final double? valorDeducaoIssqn;
  final double? outrasRetencoesIssqn;
  final double? descontoIncondicionadoIssqn;
  final double? descontoCondicionadoIssqn;
  final double? totalRetencaoIssqn;
  final String? regimeEspecialTributacao;
  final double? valorRetidoPis;
  final double? valorRetidoCofins;
  final double? valorRetidoCsll;
  final double? baseCalculoIrrf;
  final double? valorRetidoIrrf;
  final double? baseCalculoPrevidencia;
  final double? valorRetidoPrevidencia;
  final String? informacoesAddFisco;
  final String? informacoesAddContribuinte;
  final String? comexUfEmbarque;
  final String? comexLocalEmbarque;
  final String? comexLocalDespacho;
  final String? compraNotaEmpenho;
  final String? compraPedido;
  final String? compraContrato;
  final String? qrcode;
  final String? urlChave;
  final String? statusNota;
  final int? idFornecedor;
  final int? idNfceMovimento;
  final int? idVendaCabecalho;
  final int? idTributOperacaoFiscal;
  final int? idCliente;
  const NfeCabecalho(
      {this.id,
      this.idVendedor,
      this.ufEmitente,
      this.codigoNumerico,
      this.naturezaOperacao,
      this.codigoModelo,
      this.serie,
      this.numero,
      this.dataHoraEmissao,
      this.dataHoraEntradaSaida,
      this.tipoOperacao,
      this.localDestino,
      this.codigoMunicipio,
      this.formatoImpressaoDanfe,
      this.tipoEmissao,
      this.chaveAcesso,
      this.digitoChaveAcesso,
      this.ambiente,
      this.finalidadeEmissao,
      this.consumidorOperacao,
      this.consumidorPresenca,
      this.processoEmissao,
      this.versaoProcessoEmissao,
      this.dataEntradaContingencia,
      this.justificativaContingencia,
      this.baseCalculoIcms,
      this.valorIcms,
      this.valorIcmsDesonerado,
      this.totalIcmsFcpUfDestino,
      this.totalIcmsInterestadualUfDestino,
      this.totalIcmsInterestadualUfRemetente,
      this.valorTotalFcp,
      this.baseCalculoIcmsSt,
      this.valorIcmsSt,
      this.valorTotalFcpSt,
      this.valorTotalFcpStRetido,
      this.valorTotalProdutos,
      this.valorFrete,
      this.valorSeguro,
      this.valorDesconto,
      this.valorImpostoImportacao,
      this.valorIpi,
      this.valorIpiDevolvido,
      this.valorPis,
      this.valorCofins,
      this.valorDespesasAcessorias,
      this.valorTotal,
      this.valorTotalTributos,
      this.valorServicos,
      this.baseCalculoIssqn,
      this.valorIssqn,
      this.valorPisIssqn,
      this.valorCofinsIssqn,
      this.dataPrestacaoServico,
      this.valorDeducaoIssqn,
      this.outrasRetencoesIssqn,
      this.descontoIncondicionadoIssqn,
      this.descontoCondicionadoIssqn,
      this.totalRetencaoIssqn,
      this.regimeEspecialTributacao,
      this.valorRetidoPis,
      this.valorRetidoCofins,
      this.valorRetidoCsll,
      this.baseCalculoIrrf,
      this.valorRetidoIrrf,
      this.baseCalculoPrevidencia,
      this.valorRetidoPrevidencia,
      this.informacoesAddFisco,
      this.informacoesAddContribuinte,
      this.comexUfEmbarque,
      this.comexLocalEmbarque,
      this.comexLocalDespacho,
      this.compraNotaEmpenho,
      this.compraPedido,
      this.compraContrato,
      this.qrcode,
      this.urlChave,
      this.statusNota,
      this.idFornecedor,
      this.idNfceMovimento,
      this.idVendaCabecalho,
      this.idTributOperacaoFiscal,
      this.idCliente});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendedor != null) {
      map['id_vendedor'] = Variable<int>(idVendedor);
    }
    if (!nullToAbsent || ufEmitente != null) {
      map['uf_emitente'] = Variable<int>(ufEmitente);
    }
    if (!nullToAbsent || codigoNumerico != null) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico);
    }
    if (!nullToAbsent || naturezaOperacao != null) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao);
    }
    if (!nullToAbsent || codigoModelo != null) {
      map['codigo_modelo'] = Variable<String>(codigoModelo);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataHoraEmissao != null) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao);
    }
    if (!nullToAbsent || dataHoraEntradaSaida != null) {
      map['data_hora_entrada_saida'] = Variable<DateTime>(dataHoraEntradaSaida);
    }
    if (!nullToAbsent || tipoOperacao != null) {
      map['tipo_operacao'] = Variable<String>(tipoOperacao);
    }
    if (!nullToAbsent || localDestino != null) {
      map['local_destino'] = Variable<String>(localDestino);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || formatoImpressaoDanfe != null) {
      map['formato_impressao_danfe'] = Variable<String>(formatoImpressaoDanfe);
    }
    if (!nullToAbsent || tipoEmissao != null) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao);
    }
    if (!nullToAbsent || chaveAcesso != null) {
      map['chave_acesso'] = Variable<String>(chaveAcesso);
    }
    if (!nullToAbsent || digitoChaveAcesso != null) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso);
    }
    if (!nullToAbsent || ambiente != null) {
      map['ambiente'] = Variable<String>(ambiente);
    }
    if (!nullToAbsent || finalidadeEmissao != null) {
      map['finalidade_emissao'] = Variable<String>(finalidadeEmissao);
    }
    if (!nullToAbsent || consumidorOperacao != null) {
      map['consumidor_operacao'] = Variable<String>(consumidorOperacao);
    }
    if (!nullToAbsent || consumidorPresenca != null) {
      map['consumidor_presenca'] = Variable<String>(consumidorPresenca);
    }
    if (!nullToAbsent || processoEmissao != null) {
      map['processo_emissao'] = Variable<String>(processoEmissao);
    }
    if (!nullToAbsent || versaoProcessoEmissao != null) {
      map['versao_processo_emissao'] = Variable<String>(versaoProcessoEmissao);
    }
    if (!nullToAbsent || dataEntradaContingencia != null) {
      map['data_entrada_contingencia'] =
          Variable<DateTime>(dataEntradaContingencia);
    }
    if (!nullToAbsent || justificativaContingencia != null) {
      map['justificativa_contingencia'] =
          Variable<String>(justificativaContingencia);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || valorIcmsDesonerado != null) {
      map['valor_icms_desonerado'] = Variable<double>(valorIcmsDesonerado);
    }
    if (!nullToAbsent || totalIcmsFcpUfDestino != null) {
      map['total_icms_fcp_uf_destino'] =
          Variable<double>(totalIcmsFcpUfDestino);
    }
    if (!nullToAbsent || totalIcmsInterestadualUfDestino != null) {
      map['total_icms_interestadual_uf_destino'] =
          Variable<double>(totalIcmsInterestadualUfDestino);
    }
    if (!nullToAbsent || totalIcmsInterestadualUfRemetente != null) {
      map['total_icms_interestadual_uf_remetente'] =
          Variable<double>(totalIcmsInterestadualUfRemetente);
    }
    if (!nullToAbsent || valorTotalFcp != null) {
      map['valor_total_fcp'] = Variable<double>(valorTotalFcp);
    }
    if (!nullToAbsent || baseCalculoIcmsSt != null) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt);
    }
    if (!nullToAbsent || valorIcmsSt != null) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt);
    }
    if (!nullToAbsent || valorTotalFcpSt != null) {
      map['valor_total_fcp_st'] = Variable<double>(valorTotalFcpSt);
    }
    if (!nullToAbsent || valorTotalFcpStRetido != null) {
      map['valor_total_fcp_st_retido'] =
          Variable<double>(valorTotalFcpStRetido);
    }
    if (!nullToAbsent || valorTotalProdutos != null) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    if (!nullToAbsent || valorSeguro != null) {
      map['valor_seguro'] = Variable<double>(valorSeguro);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorImpostoImportacao != null) {
      map['valor_imposto_importacao'] =
          Variable<double>(valorImpostoImportacao);
    }
    if (!nullToAbsent || valorIpi != null) {
      map['valor_ipi'] = Variable<double>(valorIpi);
    }
    if (!nullToAbsent || valorIpiDevolvido != null) {
      map['valor_ipi_devolvido'] = Variable<double>(valorIpiDevolvido);
    }
    if (!nullToAbsent || valorPis != null) {
      map['valor_pis'] = Variable<double>(valorPis);
    }
    if (!nullToAbsent || valorCofins != null) {
      map['valor_cofins'] = Variable<double>(valorCofins);
    }
    if (!nullToAbsent || valorDespesasAcessorias != null) {
      map['valor_despesas_acessorias'] =
          Variable<double>(valorDespesasAcessorias);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || valorTotalTributos != null) {
      map['valor_total_tributos'] = Variable<double>(valorTotalTributos);
    }
    if (!nullToAbsent || valorServicos != null) {
      map['valor_servicos'] = Variable<double>(valorServicos);
    }
    if (!nullToAbsent || baseCalculoIssqn != null) {
      map['base_calculo_issqn'] = Variable<double>(baseCalculoIssqn);
    }
    if (!nullToAbsent || valorIssqn != null) {
      map['valor_issqn'] = Variable<double>(valorIssqn);
    }
    if (!nullToAbsent || valorPisIssqn != null) {
      map['valor_pis_issqn'] = Variable<double>(valorPisIssqn);
    }
    if (!nullToAbsent || valorCofinsIssqn != null) {
      map['valor_cofins_issqn'] = Variable<double>(valorCofinsIssqn);
    }
    if (!nullToAbsent || dataPrestacaoServico != null) {
      map['data_prestacao_servico'] = Variable<DateTime>(dataPrestacaoServico);
    }
    if (!nullToAbsent || valorDeducaoIssqn != null) {
      map['valor_deducao_issqn'] = Variable<double>(valorDeducaoIssqn);
    }
    if (!nullToAbsent || outrasRetencoesIssqn != null) {
      map['outras_retencoes_issqn'] = Variable<double>(outrasRetencoesIssqn);
    }
    if (!nullToAbsent || descontoIncondicionadoIssqn != null) {
      map['desconto_incondicionado_issqn'] =
          Variable<double>(descontoIncondicionadoIssqn);
    }
    if (!nullToAbsent || descontoCondicionadoIssqn != null) {
      map['desconto_condicionado_issqn'] =
          Variable<double>(descontoCondicionadoIssqn);
    }
    if (!nullToAbsent || totalRetencaoIssqn != null) {
      map['total_retencao_issqn'] = Variable<double>(totalRetencaoIssqn);
    }
    if (!nullToAbsent || regimeEspecialTributacao != null) {
      map['regime_especial_tributacao'] =
          Variable<String>(regimeEspecialTributacao);
    }
    if (!nullToAbsent || valorRetidoPis != null) {
      map['valor_retido_pis'] = Variable<double>(valorRetidoPis);
    }
    if (!nullToAbsent || valorRetidoCofins != null) {
      map['valor_retido_cofins'] = Variable<double>(valorRetidoCofins);
    }
    if (!nullToAbsent || valorRetidoCsll != null) {
      map['valor_retido_csll'] = Variable<double>(valorRetidoCsll);
    }
    if (!nullToAbsent || baseCalculoIrrf != null) {
      map['base_calculo_irrf'] = Variable<double>(baseCalculoIrrf);
    }
    if (!nullToAbsent || valorRetidoIrrf != null) {
      map['valor_retido_irrf'] = Variable<double>(valorRetidoIrrf);
    }
    if (!nullToAbsent || baseCalculoPrevidencia != null) {
      map['base_calculo_previdencia'] =
          Variable<double>(baseCalculoPrevidencia);
    }
    if (!nullToAbsent || valorRetidoPrevidencia != null) {
      map['valor_retido_previdencia'] =
          Variable<double>(valorRetidoPrevidencia);
    }
    if (!nullToAbsent || informacoesAddFisco != null) {
      map['informacoes_add_fisco'] = Variable<String>(informacoesAddFisco);
    }
    if (!nullToAbsent || informacoesAddContribuinte != null) {
      map['informacoes_add_contribuinte'] =
          Variable<String>(informacoesAddContribuinte);
    }
    if (!nullToAbsent || comexUfEmbarque != null) {
      map['comex_uf_embarque'] = Variable<String>(comexUfEmbarque);
    }
    if (!nullToAbsent || comexLocalEmbarque != null) {
      map['comex_local_embarque'] = Variable<String>(comexLocalEmbarque);
    }
    if (!nullToAbsent || comexLocalDespacho != null) {
      map['comex_local_despacho'] = Variable<String>(comexLocalDespacho);
    }
    if (!nullToAbsent || compraNotaEmpenho != null) {
      map['compra_nota_empenho'] = Variable<String>(compraNotaEmpenho);
    }
    if (!nullToAbsent || compraPedido != null) {
      map['compra_pedido'] = Variable<String>(compraPedido);
    }
    if (!nullToAbsent || compraContrato != null) {
      map['compra_contrato'] = Variable<String>(compraContrato);
    }
    if (!nullToAbsent || qrcode != null) {
      map['qrcode'] = Variable<String>(qrcode);
    }
    if (!nullToAbsent || urlChave != null) {
      map['url_chave'] = Variable<String>(urlChave);
    }
    if (!nullToAbsent || statusNota != null) {
      map['status_nota'] = Variable<String>(statusNota);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || idNfceMovimento != null) {
      map['id_nfce_movimento'] = Variable<int>(idNfceMovimento);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idTributOperacaoFiscal != null) {
      map['id_tribut_operacao_fiscal'] = Variable<int>(idTributOperacaoFiscal);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    return map;
  }

  factory NfeCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NfeCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idVendedor: serializer.fromJson<int?>(json['idVendedor']),
      ufEmitente: serializer.fromJson<int?>(json['ufEmitente']),
      codigoNumerico: serializer.fromJson<String?>(json['codigoNumerico']),
      naturezaOperacao: serializer.fromJson<String?>(json['naturezaOperacao']),
      codigoModelo: serializer.fromJson<String?>(json['codigoModelo']),
      serie: serializer.fromJson<String?>(json['serie']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataHoraEmissao: serializer.fromJson<DateTime?>(json['dataHoraEmissao']),
      dataHoraEntradaSaida:
          serializer.fromJson<DateTime?>(json['dataHoraEntradaSaida']),
      tipoOperacao: serializer.fromJson<String?>(json['tipoOperacao']),
      localDestino: serializer.fromJson<String?>(json['localDestino']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      formatoImpressaoDanfe:
          serializer.fromJson<String?>(json['formatoImpressaoDanfe']),
      tipoEmissao: serializer.fromJson<String?>(json['tipoEmissao']),
      chaveAcesso: serializer.fromJson<String?>(json['chaveAcesso']),
      digitoChaveAcesso:
          serializer.fromJson<String?>(json['digitoChaveAcesso']),
      ambiente: serializer.fromJson<String?>(json['ambiente']),
      finalidadeEmissao:
          serializer.fromJson<String?>(json['finalidadeEmissao']),
      consumidorOperacao:
          serializer.fromJson<String?>(json['consumidorOperacao']),
      consumidorPresenca:
          serializer.fromJson<String?>(json['consumidorPresenca']),
      processoEmissao: serializer.fromJson<String?>(json['processoEmissao']),
      versaoProcessoEmissao:
          serializer.fromJson<String?>(json['versaoProcessoEmissao']),
      dataEntradaContingencia:
          serializer.fromJson<DateTime?>(json['dataEntradaContingencia']),
      justificativaContingencia:
          serializer.fromJson<String?>(json['justificativaContingencia']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      valorIcmsDesonerado:
          serializer.fromJson<double?>(json['valorIcmsDesonerado']),
      totalIcmsFcpUfDestino:
          serializer.fromJson<double?>(json['totalIcmsFcpUfDestino']),
      totalIcmsInterestadualUfDestino:
          serializer.fromJson<double?>(json['totalIcmsInterestadualUfDestino']),
      totalIcmsInterestadualUfRemetente: serializer
          .fromJson<double?>(json['totalIcmsInterestadualUfRemetente']),
      valorTotalFcp: serializer.fromJson<double?>(json['valorTotalFcp']),
      baseCalculoIcmsSt:
          serializer.fromJson<double?>(json['baseCalculoIcmsSt']),
      valorIcmsSt: serializer.fromJson<double?>(json['valorIcmsSt']),
      valorTotalFcpSt: serializer.fromJson<double?>(json['valorTotalFcpSt']),
      valorTotalFcpStRetido:
          serializer.fromJson<double?>(json['valorTotalFcpStRetido']),
      valorTotalProdutos:
          serializer.fromJson<double?>(json['valorTotalProdutos']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
      valorSeguro: serializer.fromJson<double?>(json['valorSeguro']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorImpostoImportacao:
          serializer.fromJson<double?>(json['valorImpostoImportacao']),
      valorIpi: serializer.fromJson<double?>(json['valorIpi']),
      valorIpiDevolvido:
          serializer.fromJson<double?>(json['valorIpiDevolvido']),
      valorPis: serializer.fromJson<double?>(json['valorPis']),
      valorCofins: serializer.fromJson<double?>(json['valorCofins']),
      valorDespesasAcessorias:
          serializer.fromJson<double?>(json['valorDespesasAcessorias']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      valorTotalTributos:
          serializer.fromJson<double?>(json['valorTotalTributos']),
      valorServicos: serializer.fromJson<double?>(json['valorServicos']),
      baseCalculoIssqn: serializer.fromJson<double?>(json['baseCalculoIssqn']),
      valorIssqn: serializer.fromJson<double?>(json['valorIssqn']),
      valorPisIssqn: serializer.fromJson<double?>(json['valorPisIssqn']),
      valorCofinsIssqn: serializer.fromJson<double?>(json['valorCofinsIssqn']),
      dataPrestacaoServico:
          serializer.fromJson<DateTime?>(json['dataPrestacaoServico']),
      valorDeducaoIssqn:
          serializer.fromJson<double?>(json['valorDeducaoIssqn']),
      outrasRetencoesIssqn:
          serializer.fromJson<double?>(json['outrasRetencoesIssqn']),
      descontoIncondicionadoIssqn:
          serializer.fromJson<double?>(json['descontoIncondicionadoIssqn']),
      descontoCondicionadoIssqn:
          serializer.fromJson<double?>(json['descontoCondicionadoIssqn']),
      totalRetencaoIssqn:
          serializer.fromJson<double?>(json['totalRetencaoIssqn']),
      regimeEspecialTributacao:
          serializer.fromJson<String?>(json['regimeEspecialTributacao']),
      valorRetidoPis: serializer.fromJson<double?>(json['valorRetidoPis']),
      valorRetidoCofins:
          serializer.fromJson<double?>(json['valorRetidoCofins']),
      valorRetidoCsll: serializer.fromJson<double?>(json['valorRetidoCsll']),
      baseCalculoIrrf: serializer.fromJson<double?>(json['baseCalculoIrrf']),
      valorRetidoIrrf: serializer.fromJson<double?>(json['valorRetidoIrrf']),
      baseCalculoPrevidencia:
          serializer.fromJson<double?>(json['baseCalculoPrevidencia']),
      valorRetidoPrevidencia:
          serializer.fromJson<double?>(json['valorRetidoPrevidencia']),
      informacoesAddFisco:
          serializer.fromJson<String?>(json['informacoesAddFisco']),
      informacoesAddContribuinte:
          serializer.fromJson<String?>(json['informacoesAddContribuinte']),
      comexUfEmbarque: serializer.fromJson<String?>(json['comexUfEmbarque']),
      comexLocalEmbarque:
          serializer.fromJson<String?>(json['comexLocalEmbarque']),
      comexLocalDespacho:
          serializer.fromJson<String?>(json['comexLocalDespacho']),
      compraNotaEmpenho:
          serializer.fromJson<String?>(json['compraNotaEmpenho']),
      compraPedido: serializer.fromJson<String?>(json['compraPedido']),
      compraContrato: serializer.fromJson<String?>(json['compraContrato']),
      qrcode: serializer.fromJson<String?>(json['qrcode']),
      urlChave: serializer.fromJson<String?>(json['urlChave']),
      statusNota: serializer.fromJson<String?>(json['statusNota']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      idNfceMovimento: serializer.fromJson<int?>(json['idNfceMovimento']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idTributOperacaoFiscal:
          serializer.fromJson<int?>(json['idTributOperacaoFiscal']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendedor': serializer.toJson<int?>(idVendedor),
      'ufEmitente': serializer.toJson<int?>(ufEmitente),
      'codigoNumerico': serializer.toJson<String?>(codigoNumerico),
      'naturezaOperacao': serializer.toJson<String?>(naturezaOperacao),
      'codigoModelo': serializer.toJson<String?>(codigoModelo),
      'serie': serializer.toJson<String?>(serie),
      'numero': serializer.toJson<String?>(numero),
      'dataHoraEmissao': serializer.toJson<DateTime?>(dataHoraEmissao),
      'dataHoraEntradaSaida':
          serializer.toJson<DateTime?>(dataHoraEntradaSaida),
      'tipoOperacao': serializer.toJson<String?>(tipoOperacao),
      'localDestino': serializer.toJson<String?>(localDestino),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'formatoImpressaoDanfe':
          serializer.toJson<String?>(formatoImpressaoDanfe),
      'tipoEmissao': serializer.toJson<String?>(tipoEmissao),
      'chaveAcesso': serializer.toJson<String?>(chaveAcesso),
      'digitoChaveAcesso': serializer.toJson<String?>(digitoChaveAcesso),
      'ambiente': serializer.toJson<String?>(ambiente),
      'finalidadeEmissao': serializer.toJson<String?>(finalidadeEmissao),
      'consumidorOperacao': serializer.toJson<String?>(consumidorOperacao),
      'consumidorPresenca': serializer.toJson<String?>(consumidorPresenca),
      'processoEmissao': serializer.toJson<String?>(processoEmissao),
      'versaoProcessoEmissao':
          serializer.toJson<String?>(versaoProcessoEmissao),
      'dataEntradaContingencia':
          serializer.toJson<DateTime?>(dataEntradaContingencia),
      'justificativaContingencia':
          serializer.toJson<String?>(justificativaContingencia),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'valorIcmsDesonerado': serializer.toJson<double?>(valorIcmsDesonerado),
      'totalIcmsFcpUfDestino':
          serializer.toJson<double?>(totalIcmsFcpUfDestino),
      'totalIcmsInterestadualUfDestino':
          serializer.toJson<double?>(totalIcmsInterestadualUfDestino),
      'totalIcmsInterestadualUfRemetente':
          serializer.toJson<double?>(totalIcmsInterestadualUfRemetente),
      'valorTotalFcp': serializer.toJson<double?>(valorTotalFcp),
      'baseCalculoIcmsSt': serializer.toJson<double?>(baseCalculoIcmsSt),
      'valorIcmsSt': serializer.toJson<double?>(valorIcmsSt),
      'valorTotalFcpSt': serializer.toJson<double?>(valorTotalFcpSt),
      'valorTotalFcpStRetido':
          serializer.toJson<double?>(valorTotalFcpStRetido),
      'valorTotalProdutos': serializer.toJson<double?>(valorTotalProdutos),
      'valorFrete': serializer.toJson<double?>(valorFrete),
      'valorSeguro': serializer.toJson<double?>(valorSeguro),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorImpostoImportacao':
          serializer.toJson<double?>(valorImpostoImportacao),
      'valorIpi': serializer.toJson<double?>(valorIpi),
      'valorIpiDevolvido': serializer.toJson<double?>(valorIpiDevolvido),
      'valorPis': serializer.toJson<double?>(valorPis),
      'valorCofins': serializer.toJson<double?>(valorCofins),
      'valorDespesasAcessorias':
          serializer.toJson<double?>(valorDespesasAcessorias),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'valorTotalTributos': serializer.toJson<double?>(valorTotalTributos),
      'valorServicos': serializer.toJson<double?>(valorServicos),
      'baseCalculoIssqn': serializer.toJson<double?>(baseCalculoIssqn),
      'valorIssqn': serializer.toJson<double?>(valorIssqn),
      'valorPisIssqn': serializer.toJson<double?>(valorPisIssqn),
      'valorCofinsIssqn': serializer.toJson<double?>(valorCofinsIssqn),
      'dataPrestacaoServico':
          serializer.toJson<DateTime?>(dataPrestacaoServico),
      'valorDeducaoIssqn': serializer.toJson<double?>(valorDeducaoIssqn),
      'outrasRetencoesIssqn': serializer.toJson<double?>(outrasRetencoesIssqn),
      'descontoIncondicionadoIssqn':
          serializer.toJson<double?>(descontoIncondicionadoIssqn),
      'descontoCondicionadoIssqn':
          serializer.toJson<double?>(descontoCondicionadoIssqn),
      'totalRetencaoIssqn': serializer.toJson<double?>(totalRetencaoIssqn),
      'regimeEspecialTributacao':
          serializer.toJson<String?>(regimeEspecialTributacao),
      'valorRetidoPis': serializer.toJson<double?>(valorRetidoPis),
      'valorRetidoCofins': serializer.toJson<double?>(valorRetidoCofins),
      'valorRetidoCsll': serializer.toJson<double?>(valorRetidoCsll),
      'baseCalculoIrrf': serializer.toJson<double?>(baseCalculoIrrf),
      'valorRetidoIrrf': serializer.toJson<double?>(valorRetidoIrrf),
      'baseCalculoPrevidencia':
          serializer.toJson<double?>(baseCalculoPrevidencia),
      'valorRetidoPrevidencia':
          serializer.toJson<double?>(valorRetidoPrevidencia),
      'informacoesAddFisco': serializer.toJson<String?>(informacoesAddFisco),
      'informacoesAddContribuinte':
          serializer.toJson<String?>(informacoesAddContribuinte),
      'comexUfEmbarque': serializer.toJson<String?>(comexUfEmbarque),
      'comexLocalEmbarque': serializer.toJson<String?>(comexLocalEmbarque),
      'comexLocalDespacho': serializer.toJson<String?>(comexLocalDespacho),
      'compraNotaEmpenho': serializer.toJson<String?>(compraNotaEmpenho),
      'compraPedido': serializer.toJson<String?>(compraPedido),
      'compraContrato': serializer.toJson<String?>(compraContrato),
      'qrcode': serializer.toJson<String?>(qrcode),
      'urlChave': serializer.toJson<String?>(urlChave),
      'statusNota': serializer.toJson<String?>(statusNota),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'idNfceMovimento': serializer.toJson<int?>(idNfceMovimento),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idTributOperacaoFiscal': serializer.toJson<int?>(idTributOperacaoFiscal),
      'idCliente': serializer.toJson<int?>(idCliente),
    };
  }

  NfeCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendedor = const Value.absent(),
          Value<int?> ufEmitente = const Value.absent(),
          Value<String?> codigoNumerico = const Value.absent(),
          Value<String?> naturezaOperacao = const Value.absent(),
          Value<String?> codigoModelo = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataHoraEmissao = const Value.absent(),
          Value<DateTime?> dataHoraEntradaSaida = const Value.absent(),
          Value<String?> tipoOperacao = const Value.absent(),
          Value<String?> localDestino = const Value.absent(),
          Value<int?> codigoMunicipio = const Value.absent(),
          Value<String?> formatoImpressaoDanfe = const Value.absent(),
          Value<String?> tipoEmissao = const Value.absent(),
          Value<String?> chaveAcesso = const Value.absent(),
          Value<String?> digitoChaveAcesso = const Value.absent(),
          Value<String?> ambiente = const Value.absent(),
          Value<String?> finalidadeEmissao = const Value.absent(),
          Value<String?> consumidorOperacao = const Value.absent(),
          Value<String?> consumidorPresenca = const Value.absent(),
          Value<String?> processoEmissao = const Value.absent(),
          Value<String?> versaoProcessoEmissao = const Value.absent(),
          Value<DateTime?> dataEntradaContingencia = const Value.absent(),
          Value<String?> justificativaContingencia = const Value.absent(),
          Value<double?> baseCalculoIcms = const Value.absent(),
          Value<double?> valorIcms = const Value.absent(),
          Value<double?> valorIcmsDesonerado = const Value.absent(),
          Value<double?> totalIcmsFcpUfDestino = const Value.absent(),
          Value<double?> totalIcmsInterestadualUfDestino = const Value.absent(),
          Value<double?> totalIcmsInterestadualUfRemetente =
              const Value.absent(),
          Value<double?> valorTotalFcp = const Value.absent(),
          Value<double?> baseCalculoIcmsSt = const Value.absent(),
          Value<double?> valorIcmsSt = const Value.absent(),
          Value<double?> valorTotalFcpSt = const Value.absent(),
          Value<double?> valorTotalFcpStRetido = const Value.absent(),
          Value<double?> valorTotalProdutos = const Value.absent(),
          Value<double?> valorFrete = const Value.absent(),
          Value<double?> valorSeguro = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorImpostoImportacao = const Value.absent(),
          Value<double?> valorIpi = const Value.absent(),
          Value<double?> valorIpiDevolvido = const Value.absent(),
          Value<double?> valorPis = const Value.absent(),
          Value<double?> valorCofins = const Value.absent(),
          Value<double?> valorDespesasAcessorias = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<double?> valorTotalTributos = const Value.absent(),
          Value<double?> valorServicos = const Value.absent(),
          Value<double?> baseCalculoIssqn = const Value.absent(),
          Value<double?> valorIssqn = const Value.absent(),
          Value<double?> valorPisIssqn = const Value.absent(),
          Value<double?> valorCofinsIssqn = const Value.absent(),
          Value<DateTime?> dataPrestacaoServico = const Value.absent(),
          Value<double?> valorDeducaoIssqn = const Value.absent(),
          Value<double?> outrasRetencoesIssqn = const Value.absent(),
          Value<double?> descontoIncondicionadoIssqn = const Value.absent(),
          Value<double?> descontoCondicionadoIssqn = const Value.absent(),
          Value<double?> totalRetencaoIssqn = const Value.absent(),
          Value<String?> regimeEspecialTributacao = const Value.absent(),
          Value<double?> valorRetidoPis = const Value.absent(),
          Value<double?> valorRetidoCofins = const Value.absent(),
          Value<double?> valorRetidoCsll = const Value.absent(),
          Value<double?> baseCalculoIrrf = const Value.absent(),
          Value<double?> valorRetidoIrrf = const Value.absent(),
          Value<double?> baseCalculoPrevidencia = const Value.absent(),
          Value<double?> valorRetidoPrevidencia = const Value.absent(),
          Value<String?> informacoesAddFisco = const Value.absent(),
          Value<String?> informacoesAddContribuinte = const Value.absent(),
          Value<String?> comexUfEmbarque = const Value.absent(),
          Value<String?> comexLocalEmbarque = const Value.absent(),
          Value<String?> comexLocalDespacho = const Value.absent(),
          Value<String?> compraNotaEmpenho = const Value.absent(),
          Value<String?> compraPedido = const Value.absent(),
          Value<String?> compraContrato = const Value.absent(),
          Value<String?> qrcode = const Value.absent(),
          Value<String?> urlChave = const Value.absent(),
          Value<String?> statusNota = const Value.absent(),
          Value<int?> idFornecedor = const Value.absent(),
          Value<int?> idNfceMovimento = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idTributOperacaoFiscal = const Value.absent(),
          Value<int?> idCliente = const Value.absent()}) =>
      NfeCabecalho(
        id: id.present ? id.value : this.id,
        idVendedor: idVendedor.present ? idVendedor.value : this.idVendedor,
        ufEmitente: ufEmitente.present ? ufEmitente.value : this.ufEmitente,
        codigoNumerico:
            codigoNumerico.present ? codigoNumerico.value : this.codigoNumerico,
        naturezaOperacao: naturezaOperacao.present
            ? naturezaOperacao.value
            : this.naturezaOperacao,
        codigoModelo:
            codigoModelo.present ? codigoModelo.value : this.codigoModelo,
        serie: serie.present ? serie.value : this.serie,
        numero: numero.present ? numero.value : this.numero,
        dataHoraEmissao: dataHoraEmissao.present
            ? dataHoraEmissao.value
            : this.dataHoraEmissao,
        dataHoraEntradaSaida: dataHoraEntradaSaida.present
            ? dataHoraEntradaSaida.value
            : this.dataHoraEntradaSaida,
        tipoOperacao:
            tipoOperacao.present ? tipoOperacao.value : this.tipoOperacao,
        localDestino:
            localDestino.present ? localDestino.value : this.localDestino,
        codigoMunicipio: codigoMunicipio.present
            ? codigoMunicipio.value
            : this.codigoMunicipio,
        formatoImpressaoDanfe: formatoImpressaoDanfe.present
            ? formatoImpressaoDanfe.value
            : this.formatoImpressaoDanfe,
        tipoEmissao: tipoEmissao.present ? tipoEmissao.value : this.tipoEmissao,
        chaveAcesso: chaveAcesso.present ? chaveAcesso.value : this.chaveAcesso,
        digitoChaveAcesso: digitoChaveAcesso.present
            ? digitoChaveAcesso.value
            : this.digitoChaveAcesso,
        ambiente: ambiente.present ? ambiente.value : this.ambiente,
        finalidadeEmissao: finalidadeEmissao.present
            ? finalidadeEmissao.value
            : this.finalidadeEmissao,
        consumidorOperacao: consumidorOperacao.present
            ? consumidorOperacao.value
            : this.consumidorOperacao,
        consumidorPresenca: consumidorPresenca.present
            ? consumidorPresenca.value
            : this.consumidorPresenca,
        processoEmissao: processoEmissao.present
            ? processoEmissao.value
            : this.processoEmissao,
        versaoProcessoEmissao: versaoProcessoEmissao.present
            ? versaoProcessoEmissao.value
            : this.versaoProcessoEmissao,
        dataEntradaContingencia: dataEntradaContingencia.present
            ? dataEntradaContingencia.value
            : this.dataEntradaContingencia,
        justificativaContingencia: justificativaContingencia.present
            ? justificativaContingencia.value
            : this.justificativaContingencia,
        baseCalculoIcms: baseCalculoIcms.present
            ? baseCalculoIcms.value
            : this.baseCalculoIcms,
        valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
        valorIcmsDesonerado: valorIcmsDesonerado.present
            ? valorIcmsDesonerado.value
            : this.valorIcmsDesonerado,
        totalIcmsFcpUfDestino: totalIcmsFcpUfDestino.present
            ? totalIcmsFcpUfDestino.value
            : this.totalIcmsFcpUfDestino,
        totalIcmsInterestadualUfDestino: totalIcmsInterestadualUfDestino.present
            ? totalIcmsInterestadualUfDestino.value
            : this.totalIcmsInterestadualUfDestino,
        totalIcmsInterestadualUfRemetente:
            totalIcmsInterestadualUfRemetente.present
                ? totalIcmsInterestadualUfRemetente.value
                : this.totalIcmsInterestadualUfRemetente,
        valorTotalFcp:
            valorTotalFcp.present ? valorTotalFcp.value : this.valorTotalFcp,
        baseCalculoIcmsSt: baseCalculoIcmsSt.present
            ? baseCalculoIcmsSt.value
            : this.baseCalculoIcmsSt,
        valorIcmsSt: valorIcmsSt.present ? valorIcmsSt.value : this.valorIcmsSt,
        valorTotalFcpSt: valorTotalFcpSt.present
            ? valorTotalFcpSt.value
            : this.valorTotalFcpSt,
        valorTotalFcpStRetido: valorTotalFcpStRetido.present
            ? valorTotalFcpStRetido.value
            : this.valorTotalFcpStRetido,
        valorTotalProdutos: valorTotalProdutos.present
            ? valorTotalProdutos.value
            : this.valorTotalProdutos,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
        valorSeguro: valorSeguro.present ? valorSeguro.value : this.valorSeguro,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorImpostoImportacao: valorImpostoImportacao.present
            ? valorImpostoImportacao.value
            : this.valorImpostoImportacao,
        valorIpi: valorIpi.present ? valorIpi.value : this.valorIpi,
        valorIpiDevolvido: valorIpiDevolvido.present
            ? valorIpiDevolvido.value
            : this.valorIpiDevolvido,
        valorPis: valorPis.present ? valorPis.value : this.valorPis,
        valorCofins: valorCofins.present ? valorCofins.value : this.valorCofins,
        valorDespesasAcessorias: valorDespesasAcessorias.present
            ? valorDespesasAcessorias.value
            : this.valorDespesasAcessorias,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        valorTotalTributos: valorTotalTributos.present
            ? valorTotalTributos.value
            : this.valorTotalTributos,
        valorServicos:
            valorServicos.present ? valorServicos.value : this.valorServicos,
        baseCalculoIssqn: baseCalculoIssqn.present
            ? baseCalculoIssqn.value
            : this.baseCalculoIssqn,
        valorIssqn: valorIssqn.present ? valorIssqn.value : this.valorIssqn,
        valorPisIssqn:
            valorPisIssqn.present ? valorPisIssqn.value : this.valorPisIssqn,
        valorCofinsIssqn: valorCofinsIssqn.present
            ? valorCofinsIssqn.value
            : this.valorCofinsIssqn,
        dataPrestacaoServico: dataPrestacaoServico.present
            ? dataPrestacaoServico.value
            : this.dataPrestacaoServico,
        valorDeducaoIssqn: valorDeducaoIssqn.present
            ? valorDeducaoIssqn.value
            : this.valorDeducaoIssqn,
        outrasRetencoesIssqn: outrasRetencoesIssqn.present
            ? outrasRetencoesIssqn.value
            : this.outrasRetencoesIssqn,
        descontoIncondicionadoIssqn: descontoIncondicionadoIssqn.present
            ? descontoIncondicionadoIssqn.value
            : this.descontoIncondicionadoIssqn,
        descontoCondicionadoIssqn: descontoCondicionadoIssqn.present
            ? descontoCondicionadoIssqn.value
            : this.descontoCondicionadoIssqn,
        totalRetencaoIssqn: totalRetencaoIssqn.present
            ? totalRetencaoIssqn.value
            : this.totalRetencaoIssqn,
        regimeEspecialTributacao: regimeEspecialTributacao.present
            ? regimeEspecialTributacao.value
            : this.regimeEspecialTributacao,
        valorRetidoPis:
            valorRetidoPis.present ? valorRetidoPis.value : this.valorRetidoPis,
        valorRetidoCofins: valorRetidoCofins.present
            ? valorRetidoCofins.value
            : this.valorRetidoCofins,
        valorRetidoCsll: valorRetidoCsll.present
            ? valorRetidoCsll.value
            : this.valorRetidoCsll,
        baseCalculoIrrf: baseCalculoIrrf.present
            ? baseCalculoIrrf.value
            : this.baseCalculoIrrf,
        valorRetidoIrrf: valorRetidoIrrf.present
            ? valorRetidoIrrf.value
            : this.valorRetidoIrrf,
        baseCalculoPrevidencia: baseCalculoPrevidencia.present
            ? baseCalculoPrevidencia.value
            : this.baseCalculoPrevidencia,
        valorRetidoPrevidencia: valorRetidoPrevidencia.present
            ? valorRetidoPrevidencia.value
            : this.valorRetidoPrevidencia,
        informacoesAddFisco: informacoesAddFisco.present
            ? informacoesAddFisco.value
            : this.informacoesAddFisco,
        informacoesAddContribuinte: informacoesAddContribuinte.present
            ? informacoesAddContribuinte.value
            : this.informacoesAddContribuinte,
        comexUfEmbarque: comexUfEmbarque.present
            ? comexUfEmbarque.value
            : this.comexUfEmbarque,
        comexLocalEmbarque: comexLocalEmbarque.present
            ? comexLocalEmbarque.value
            : this.comexLocalEmbarque,
        comexLocalDespacho: comexLocalDespacho.present
            ? comexLocalDespacho.value
            : this.comexLocalDespacho,
        compraNotaEmpenho: compraNotaEmpenho.present
            ? compraNotaEmpenho.value
            : this.compraNotaEmpenho,
        compraPedido:
            compraPedido.present ? compraPedido.value : this.compraPedido,
        compraContrato:
            compraContrato.present ? compraContrato.value : this.compraContrato,
        qrcode: qrcode.present ? qrcode.value : this.qrcode,
        urlChave: urlChave.present ? urlChave.value : this.urlChave,
        statusNota: statusNota.present ? statusNota.value : this.statusNota,
        idFornecedor:
            idFornecedor.present ? idFornecedor.value : this.idFornecedor,
        idNfceMovimento: idNfceMovimento.present
            ? idNfceMovimento.value
            : this.idNfceMovimento,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idTributOperacaoFiscal: idTributOperacaoFiscal.present
            ? idTributOperacaoFiscal.value
            : this.idTributOperacaoFiscal,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
      );
  @override
  String toString() {
    return (StringBuffer('NfeCabecalho(')
          ..write('id: $id, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('codigoModelo: $codigoModelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('dataHoraEntradaSaida: $dataHoraEntradaSaida, ')
          ..write('tipoOperacao: $tipoOperacao, ')
          ..write('localDestino: $localDestino, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('formatoImpressaoDanfe: $formatoImpressaoDanfe, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('ambiente: $ambiente, ')
          ..write('finalidadeEmissao: $finalidadeEmissao, ')
          ..write('consumidorOperacao: $consumidorOperacao, ')
          ..write('consumidorPresenca: $consumidorPresenca, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('dataEntradaContingencia: $dataEntradaContingencia, ')
          ..write('justificativaContingencia: $justificativaContingencia, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('valorIcmsDesonerado: $valorIcmsDesonerado, ')
          ..write('totalIcmsFcpUfDestino: $totalIcmsFcpUfDestino, ')
          ..write(
              'totalIcmsInterestadualUfDestino: $totalIcmsInterestadualUfDestino, ')
          ..write(
              'totalIcmsInterestadualUfRemetente: $totalIcmsInterestadualUfRemetente, ')
          ..write('valorTotalFcp: $valorTotalFcp, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalFcpSt: $valorTotalFcpSt, ')
          ..write('valorTotalFcpStRetido: $valorTotalFcpStRetido, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorImpostoImportacao: $valorImpostoImportacao, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('valorIpiDevolvido: $valorIpiDevolvido, ')
          ..write('valorPis: $valorPis, ')
          ..write('valorCofins: $valorCofins, ')
          ..write('valorDespesasAcessorias: $valorDespesasAcessorias, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('valorTotalTributos: $valorTotalTributos, ')
          ..write('valorServicos: $valorServicos, ')
          ..write('baseCalculoIssqn: $baseCalculoIssqn, ')
          ..write('valorIssqn: $valorIssqn, ')
          ..write('valorPisIssqn: $valorPisIssqn, ')
          ..write('valorCofinsIssqn: $valorCofinsIssqn, ')
          ..write('dataPrestacaoServico: $dataPrestacaoServico, ')
          ..write('valorDeducaoIssqn: $valorDeducaoIssqn, ')
          ..write('outrasRetencoesIssqn: $outrasRetencoesIssqn, ')
          ..write('descontoIncondicionadoIssqn: $descontoIncondicionadoIssqn, ')
          ..write('descontoCondicionadoIssqn: $descontoCondicionadoIssqn, ')
          ..write('totalRetencaoIssqn: $totalRetencaoIssqn, ')
          ..write('regimeEspecialTributacao: $regimeEspecialTributacao, ')
          ..write('valorRetidoPis: $valorRetidoPis, ')
          ..write('valorRetidoCofins: $valorRetidoCofins, ')
          ..write('valorRetidoCsll: $valorRetidoCsll, ')
          ..write('baseCalculoIrrf: $baseCalculoIrrf, ')
          ..write('valorRetidoIrrf: $valorRetidoIrrf, ')
          ..write('baseCalculoPrevidencia: $baseCalculoPrevidencia, ')
          ..write('valorRetidoPrevidencia: $valorRetidoPrevidencia, ')
          ..write('informacoesAddFisco: $informacoesAddFisco, ')
          ..write('informacoesAddContribuinte: $informacoesAddContribuinte, ')
          ..write('comexUfEmbarque: $comexUfEmbarque, ')
          ..write('comexLocalEmbarque: $comexLocalEmbarque, ')
          ..write('comexLocalDespacho: $comexLocalDespacho, ')
          ..write('compraNotaEmpenho: $compraNotaEmpenho, ')
          ..write('compraPedido: $compraPedido, ')
          ..write('compraContrato: $compraContrato, ')
          ..write('qrcode: $qrcode, ')
          ..write('urlChave: $urlChave, ')
          ..write('statusNota: $statusNota, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idNfceMovimento: $idNfceMovimento, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal, ')
          ..write('idCliente: $idCliente')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idVendedor,
        ufEmitente,
        codigoNumerico,
        naturezaOperacao,
        codigoModelo,
        serie,
        numero,
        dataHoraEmissao,
        dataHoraEntradaSaida,
        tipoOperacao,
        localDestino,
        codigoMunicipio,
        formatoImpressaoDanfe,
        tipoEmissao,
        chaveAcesso,
        digitoChaveAcesso,
        ambiente,
        finalidadeEmissao,
        consumidorOperacao,
        consumidorPresenca,
        processoEmissao,
        versaoProcessoEmissao,
        dataEntradaContingencia,
        justificativaContingencia,
        baseCalculoIcms,
        valorIcms,
        valorIcmsDesonerado,
        totalIcmsFcpUfDestino,
        totalIcmsInterestadualUfDestino,
        totalIcmsInterestadualUfRemetente,
        valorTotalFcp,
        baseCalculoIcmsSt,
        valorIcmsSt,
        valorTotalFcpSt,
        valorTotalFcpStRetido,
        valorTotalProdutos,
        valorFrete,
        valorSeguro,
        valorDesconto,
        valorImpostoImportacao,
        valorIpi,
        valorIpiDevolvido,
        valorPis,
        valorCofins,
        valorDespesasAcessorias,
        valorTotal,
        valorTotalTributos,
        valorServicos,
        baseCalculoIssqn,
        valorIssqn,
        valorPisIssqn,
        valorCofinsIssqn,
        dataPrestacaoServico,
        valorDeducaoIssqn,
        outrasRetencoesIssqn,
        descontoIncondicionadoIssqn,
        descontoCondicionadoIssqn,
        totalRetencaoIssqn,
        regimeEspecialTributacao,
        valorRetidoPis,
        valorRetidoCofins,
        valorRetidoCsll,
        baseCalculoIrrf,
        valorRetidoIrrf,
        baseCalculoPrevidencia,
        valorRetidoPrevidencia,
        informacoesAddFisco,
        informacoesAddContribuinte,
        comexUfEmbarque,
        comexLocalEmbarque,
        comexLocalDespacho,
        compraNotaEmpenho,
        compraPedido,
        compraContrato,
        qrcode,
        urlChave,
        statusNota,
        idFornecedor,
        idNfceMovimento,
        idVendaCabecalho,
        idTributOperacaoFiscal,
        idCliente
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NfeCabecalho &&
          other.id == this.id &&
          other.idVendedor == this.idVendedor &&
          other.ufEmitente == this.ufEmitente &&
          other.codigoNumerico == this.codigoNumerico &&
          other.naturezaOperacao == this.naturezaOperacao &&
          other.codigoModelo == this.codigoModelo &&
          other.serie == this.serie &&
          other.numero == this.numero &&
          other.dataHoraEmissao == this.dataHoraEmissao &&
          other.dataHoraEntradaSaida == this.dataHoraEntradaSaida &&
          other.tipoOperacao == this.tipoOperacao &&
          other.localDestino == this.localDestino &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.formatoImpressaoDanfe == this.formatoImpressaoDanfe &&
          other.tipoEmissao == this.tipoEmissao &&
          other.chaveAcesso == this.chaveAcesso &&
          other.digitoChaveAcesso == this.digitoChaveAcesso &&
          other.ambiente == this.ambiente &&
          other.finalidadeEmissao == this.finalidadeEmissao &&
          other.consumidorOperacao == this.consumidorOperacao &&
          other.consumidorPresenca == this.consumidorPresenca &&
          other.processoEmissao == this.processoEmissao &&
          other.versaoProcessoEmissao == this.versaoProcessoEmissao &&
          other.dataEntradaContingencia == this.dataEntradaContingencia &&
          other.justificativaContingencia == this.justificativaContingencia &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.valorIcms == this.valorIcms &&
          other.valorIcmsDesonerado == this.valorIcmsDesonerado &&
          other.totalIcmsFcpUfDestino == this.totalIcmsFcpUfDestino &&
          other.totalIcmsInterestadualUfDestino ==
              this.totalIcmsInterestadualUfDestino &&
          other.totalIcmsInterestadualUfRemetente ==
              this.totalIcmsInterestadualUfRemetente &&
          other.valorTotalFcp == this.valorTotalFcp &&
          other.baseCalculoIcmsSt == this.baseCalculoIcmsSt &&
          other.valorIcmsSt == this.valorIcmsSt &&
          other.valorTotalFcpSt == this.valorTotalFcpSt &&
          other.valorTotalFcpStRetido == this.valorTotalFcpStRetido &&
          other.valorTotalProdutos == this.valorTotalProdutos &&
          other.valorFrete == this.valorFrete &&
          other.valorSeguro == this.valorSeguro &&
          other.valorDesconto == this.valorDesconto &&
          other.valorImpostoImportacao == this.valorImpostoImportacao &&
          other.valorIpi == this.valorIpi &&
          other.valorIpiDevolvido == this.valorIpiDevolvido &&
          other.valorPis == this.valorPis &&
          other.valorCofins == this.valorCofins &&
          other.valorDespesasAcessorias == this.valorDespesasAcessorias &&
          other.valorTotal == this.valorTotal &&
          other.valorTotalTributos == this.valorTotalTributos &&
          other.valorServicos == this.valorServicos &&
          other.baseCalculoIssqn == this.baseCalculoIssqn &&
          other.valorIssqn == this.valorIssqn &&
          other.valorPisIssqn == this.valorPisIssqn &&
          other.valorCofinsIssqn == this.valorCofinsIssqn &&
          other.dataPrestacaoServico == this.dataPrestacaoServico &&
          other.valorDeducaoIssqn == this.valorDeducaoIssqn &&
          other.outrasRetencoesIssqn == this.outrasRetencoesIssqn &&
          other.descontoIncondicionadoIssqn ==
              this.descontoIncondicionadoIssqn &&
          other.descontoCondicionadoIssqn == this.descontoCondicionadoIssqn &&
          other.totalRetencaoIssqn == this.totalRetencaoIssqn &&
          other.regimeEspecialTributacao == this.regimeEspecialTributacao &&
          other.valorRetidoPis == this.valorRetidoPis &&
          other.valorRetidoCofins == this.valorRetidoCofins &&
          other.valorRetidoCsll == this.valorRetidoCsll &&
          other.baseCalculoIrrf == this.baseCalculoIrrf &&
          other.valorRetidoIrrf == this.valorRetidoIrrf &&
          other.baseCalculoPrevidencia == this.baseCalculoPrevidencia &&
          other.valorRetidoPrevidencia == this.valorRetidoPrevidencia &&
          other.informacoesAddFisco == this.informacoesAddFisco &&
          other.informacoesAddContribuinte == this.informacoesAddContribuinte &&
          other.comexUfEmbarque == this.comexUfEmbarque &&
          other.comexLocalEmbarque == this.comexLocalEmbarque &&
          other.comexLocalDespacho == this.comexLocalDespacho &&
          other.compraNotaEmpenho == this.compraNotaEmpenho &&
          other.compraPedido == this.compraPedido &&
          other.compraContrato == this.compraContrato &&
          other.qrcode == this.qrcode &&
          other.urlChave == this.urlChave &&
          other.statusNota == this.statusNota &&
          other.idFornecedor == this.idFornecedor &&
          other.idNfceMovimento == this.idNfceMovimento &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idTributOperacaoFiscal == this.idTributOperacaoFiscal &&
          other.idCliente == this.idCliente);
}

class NfeCabecalhosCompanion extends UpdateCompanion<NfeCabecalho> {
  final Value<int?> id;
  final Value<int?> idVendedor;
  final Value<int?> ufEmitente;
  final Value<String?> codigoNumerico;
  final Value<String?> naturezaOperacao;
  final Value<String?> codigoModelo;
  final Value<String?> serie;
  final Value<String?> numero;
  final Value<DateTime?> dataHoraEmissao;
  final Value<DateTime?> dataHoraEntradaSaida;
  final Value<String?> tipoOperacao;
  final Value<String?> localDestino;
  final Value<int?> codigoMunicipio;
  final Value<String?> formatoImpressaoDanfe;
  final Value<String?> tipoEmissao;
  final Value<String?> chaveAcesso;
  final Value<String?> digitoChaveAcesso;
  final Value<String?> ambiente;
  final Value<String?> finalidadeEmissao;
  final Value<String?> consumidorOperacao;
  final Value<String?> consumidorPresenca;
  final Value<String?> processoEmissao;
  final Value<String?> versaoProcessoEmissao;
  final Value<DateTime?> dataEntradaContingencia;
  final Value<String?> justificativaContingencia;
  final Value<double?> baseCalculoIcms;
  final Value<double?> valorIcms;
  final Value<double?> valorIcmsDesonerado;
  final Value<double?> totalIcmsFcpUfDestino;
  final Value<double?> totalIcmsInterestadualUfDestino;
  final Value<double?> totalIcmsInterestadualUfRemetente;
  final Value<double?> valorTotalFcp;
  final Value<double?> baseCalculoIcmsSt;
  final Value<double?> valorIcmsSt;
  final Value<double?> valorTotalFcpSt;
  final Value<double?> valorTotalFcpStRetido;
  final Value<double?> valorTotalProdutos;
  final Value<double?> valorFrete;
  final Value<double?> valorSeguro;
  final Value<double?> valorDesconto;
  final Value<double?> valorImpostoImportacao;
  final Value<double?> valorIpi;
  final Value<double?> valorIpiDevolvido;
  final Value<double?> valorPis;
  final Value<double?> valorCofins;
  final Value<double?> valorDespesasAcessorias;
  final Value<double?> valorTotal;
  final Value<double?> valorTotalTributos;
  final Value<double?> valorServicos;
  final Value<double?> baseCalculoIssqn;
  final Value<double?> valorIssqn;
  final Value<double?> valorPisIssqn;
  final Value<double?> valorCofinsIssqn;
  final Value<DateTime?> dataPrestacaoServico;
  final Value<double?> valorDeducaoIssqn;
  final Value<double?> outrasRetencoesIssqn;
  final Value<double?> descontoIncondicionadoIssqn;
  final Value<double?> descontoCondicionadoIssqn;
  final Value<double?> totalRetencaoIssqn;
  final Value<String?> regimeEspecialTributacao;
  final Value<double?> valorRetidoPis;
  final Value<double?> valorRetidoCofins;
  final Value<double?> valorRetidoCsll;
  final Value<double?> baseCalculoIrrf;
  final Value<double?> valorRetidoIrrf;
  final Value<double?> baseCalculoPrevidencia;
  final Value<double?> valorRetidoPrevidencia;
  final Value<String?> informacoesAddFisco;
  final Value<String?> informacoesAddContribuinte;
  final Value<String?> comexUfEmbarque;
  final Value<String?> comexLocalEmbarque;
  final Value<String?> comexLocalDespacho;
  final Value<String?> compraNotaEmpenho;
  final Value<String?> compraPedido;
  final Value<String?> compraContrato;
  final Value<String?> qrcode;
  final Value<String?> urlChave;
  final Value<String?> statusNota;
  final Value<int?> idFornecedor;
  final Value<int?> idNfceMovimento;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idTributOperacaoFiscal;
  final Value<int?> idCliente;
  const NfeCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.codigoModelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.dataHoraEntradaSaida = const Value.absent(),
    this.tipoOperacao = const Value.absent(),
    this.localDestino = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.formatoImpressaoDanfe = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.finalidadeEmissao = const Value.absent(),
    this.consumidorOperacao = const Value.absent(),
    this.consumidorPresenca = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.dataEntradaContingencia = const Value.absent(),
    this.justificativaContingencia = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.valorIcmsDesonerado = const Value.absent(),
    this.totalIcmsFcpUfDestino = const Value.absent(),
    this.totalIcmsInterestadualUfDestino = const Value.absent(),
    this.totalIcmsInterestadualUfRemetente = const Value.absent(),
    this.valorTotalFcp = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalFcpSt = const Value.absent(),
    this.valorTotalFcpStRetido = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorImpostoImportacao = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.valorIpiDevolvido = const Value.absent(),
    this.valorPis = const Value.absent(),
    this.valorCofins = const Value.absent(),
    this.valorDespesasAcessorias = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.valorTotalTributos = const Value.absent(),
    this.valorServicos = const Value.absent(),
    this.baseCalculoIssqn = const Value.absent(),
    this.valorIssqn = const Value.absent(),
    this.valorPisIssqn = const Value.absent(),
    this.valorCofinsIssqn = const Value.absent(),
    this.dataPrestacaoServico = const Value.absent(),
    this.valorDeducaoIssqn = const Value.absent(),
    this.outrasRetencoesIssqn = const Value.absent(),
    this.descontoIncondicionadoIssqn = const Value.absent(),
    this.descontoCondicionadoIssqn = const Value.absent(),
    this.totalRetencaoIssqn = const Value.absent(),
    this.regimeEspecialTributacao = const Value.absent(),
    this.valorRetidoPis = const Value.absent(),
    this.valorRetidoCofins = const Value.absent(),
    this.valorRetidoCsll = const Value.absent(),
    this.baseCalculoIrrf = const Value.absent(),
    this.valorRetidoIrrf = const Value.absent(),
    this.baseCalculoPrevidencia = const Value.absent(),
    this.valorRetidoPrevidencia = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
    this.informacoesAddContribuinte = const Value.absent(),
    this.comexUfEmbarque = const Value.absent(),
    this.comexLocalEmbarque = const Value.absent(),
    this.comexLocalDespacho = const Value.absent(),
    this.compraNotaEmpenho = const Value.absent(),
    this.compraPedido = const Value.absent(),
    this.compraContrato = const Value.absent(),
    this.qrcode = const Value.absent(),
    this.urlChave = const Value.absent(),
    this.statusNota = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idNfceMovimento = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
    this.idCliente = const Value.absent(),
  });
  NfeCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.codigoModelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.dataHoraEntradaSaida = const Value.absent(),
    this.tipoOperacao = const Value.absent(),
    this.localDestino = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.formatoImpressaoDanfe = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.finalidadeEmissao = const Value.absent(),
    this.consumidorOperacao = const Value.absent(),
    this.consumidorPresenca = const Value.absent(),
    this.processoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.dataEntradaContingencia = const Value.absent(),
    this.justificativaContingencia = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.valorIcmsDesonerado = const Value.absent(),
    this.totalIcmsFcpUfDestino = const Value.absent(),
    this.totalIcmsInterestadualUfDestino = const Value.absent(),
    this.totalIcmsInterestadualUfRemetente = const Value.absent(),
    this.valorTotalFcp = const Value.absent(),
    this.baseCalculoIcmsSt = const Value.absent(),
    this.valorIcmsSt = const Value.absent(),
    this.valorTotalFcpSt = const Value.absent(),
    this.valorTotalFcpStRetido = const Value.absent(),
    this.valorTotalProdutos = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorImpostoImportacao = const Value.absent(),
    this.valorIpi = const Value.absent(),
    this.valorIpiDevolvido = const Value.absent(),
    this.valorPis = const Value.absent(),
    this.valorCofins = const Value.absent(),
    this.valorDespesasAcessorias = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.valorTotalTributos = const Value.absent(),
    this.valorServicos = const Value.absent(),
    this.baseCalculoIssqn = const Value.absent(),
    this.valorIssqn = const Value.absent(),
    this.valorPisIssqn = const Value.absent(),
    this.valorCofinsIssqn = const Value.absent(),
    this.dataPrestacaoServico = const Value.absent(),
    this.valorDeducaoIssqn = const Value.absent(),
    this.outrasRetencoesIssqn = const Value.absent(),
    this.descontoIncondicionadoIssqn = const Value.absent(),
    this.descontoCondicionadoIssqn = const Value.absent(),
    this.totalRetencaoIssqn = const Value.absent(),
    this.regimeEspecialTributacao = const Value.absent(),
    this.valorRetidoPis = const Value.absent(),
    this.valorRetidoCofins = const Value.absent(),
    this.valorRetidoCsll = const Value.absent(),
    this.baseCalculoIrrf = const Value.absent(),
    this.valorRetidoIrrf = const Value.absent(),
    this.baseCalculoPrevidencia = const Value.absent(),
    this.valorRetidoPrevidencia = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
    this.informacoesAddContribuinte = const Value.absent(),
    this.comexUfEmbarque = const Value.absent(),
    this.comexLocalEmbarque = const Value.absent(),
    this.comexLocalDespacho = const Value.absent(),
    this.compraNotaEmpenho = const Value.absent(),
    this.compraPedido = const Value.absent(),
    this.compraContrato = const Value.absent(),
    this.qrcode = const Value.absent(),
    this.urlChave = const Value.absent(),
    this.statusNota = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idNfceMovimento = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idTributOperacaoFiscal = const Value.absent(),
    this.idCliente = const Value.absent(),
  });
  static Insertable<NfeCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idVendedor,
    Expression<int>? ufEmitente,
    Expression<String>? codigoNumerico,
    Expression<String>? naturezaOperacao,
    Expression<String>? codigoModelo,
    Expression<String>? serie,
    Expression<String>? numero,
    Expression<DateTime>? dataHoraEmissao,
    Expression<DateTime>? dataHoraEntradaSaida,
    Expression<String>? tipoOperacao,
    Expression<String>? localDestino,
    Expression<int>? codigoMunicipio,
    Expression<String>? formatoImpressaoDanfe,
    Expression<String>? tipoEmissao,
    Expression<String>? chaveAcesso,
    Expression<String>? digitoChaveAcesso,
    Expression<String>? ambiente,
    Expression<String>? finalidadeEmissao,
    Expression<String>? consumidorOperacao,
    Expression<String>? consumidorPresenca,
    Expression<String>? processoEmissao,
    Expression<String>? versaoProcessoEmissao,
    Expression<DateTime>? dataEntradaContingencia,
    Expression<String>? justificativaContingencia,
    Expression<double>? baseCalculoIcms,
    Expression<double>? valorIcms,
    Expression<double>? valorIcmsDesonerado,
    Expression<double>? totalIcmsFcpUfDestino,
    Expression<double>? totalIcmsInterestadualUfDestino,
    Expression<double>? totalIcmsInterestadualUfRemetente,
    Expression<double>? valorTotalFcp,
    Expression<double>? baseCalculoIcmsSt,
    Expression<double>? valorIcmsSt,
    Expression<double>? valorTotalFcpSt,
    Expression<double>? valorTotalFcpStRetido,
    Expression<double>? valorTotalProdutos,
    Expression<double>? valorFrete,
    Expression<double>? valorSeguro,
    Expression<double>? valorDesconto,
    Expression<double>? valorImpostoImportacao,
    Expression<double>? valorIpi,
    Expression<double>? valorIpiDevolvido,
    Expression<double>? valorPis,
    Expression<double>? valorCofins,
    Expression<double>? valorDespesasAcessorias,
    Expression<double>? valorTotal,
    Expression<double>? valorTotalTributos,
    Expression<double>? valorServicos,
    Expression<double>? baseCalculoIssqn,
    Expression<double>? valorIssqn,
    Expression<double>? valorPisIssqn,
    Expression<double>? valorCofinsIssqn,
    Expression<DateTime>? dataPrestacaoServico,
    Expression<double>? valorDeducaoIssqn,
    Expression<double>? outrasRetencoesIssqn,
    Expression<double>? descontoIncondicionadoIssqn,
    Expression<double>? descontoCondicionadoIssqn,
    Expression<double>? totalRetencaoIssqn,
    Expression<String>? regimeEspecialTributacao,
    Expression<double>? valorRetidoPis,
    Expression<double>? valorRetidoCofins,
    Expression<double>? valorRetidoCsll,
    Expression<double>? baseCalculoIrrf,
    Expression<double>? valorRetidoIrrf,
    Expression<double>? baseCalculoPrevidencia,
    Expression<double>? valorRetidoPrevidencia,
    Expression<String>? informacoesAddFisco,
    Expression<String>? informacoesAddContribuinte,
    Expression<String>? comexUfEmbarque,
    Expression<String>? comexLocalEmbarque,
    Expression<String>? comexLocalDespacho,
    Expression<String>? compraNotaEmpenho,
    Expression<String>? compraPedido,
    Expression<String>? compraContrato,
    Expression<String>? qrcode,
    Expression<String>? urlChave,
    Expression<String>? statusNota,
    Expression<int>? idFornecedor,
    Expression<int>? idNfceMovimento,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idTributOperacaoFiscal,
    Expression<int>? idCliente,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendedor != null) 'id_vendedor': idVendedor,
      if (ufEmitente != null) 'uf_emitente': ufEmitente,
      if (codigoNumerico != null) 'codigo_numerico': codigoNumerico,
      if (naturezaOperacao != null) 'natureza_operacao': naturezaOperacao,
      if (codigoModelo != null) 'codigo_modelo': codigoModelo,
      if (serie != null) 'serie': serie,
      if (numero != null) 'numero': numero,
      if (dataHoraEmissao != null) 'data_hora_emissao': dataHoraEmissao,
      if (dataHoraEntradaSaida != null)
        'data_hora_entrada_saida': dataHoraEntradaSaida,
      if (tipoOperacao != null) 'tipo_operacao': tipoOperacao,
      if (localDestino != null) 'local_destino': localDestino,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (formatoImpressaoDanfe != null)
        'formato_impressao_danfe': formatoImpressaoDanfe,
      if (tipoEmissao != null) 'tipo_emissao': tipoEmissao,
      if (chaveAcesso != null) 'chave_acesso': chaveAcesso,
      if (digitoChaveAcesso != null) 'digito_chave_acesso': digitoChaveAcesso,
      if (ambiente != null) 'ambiente': ambiente,
      if (finalidadeEmissao != null) 'finalidade_emissao': finalidadeEmissao,
      if (consumidorOperacao != null) 'consumidor_operacao': consumidorOperacao,
      if (consumidorPresenca != null) 'consumidor_presenca': consumidorPresenca,
      if (processoEmissao != null) 'processo_emissao': processoEmissao,
      if (versaoProcessoEmissao != null)
        'versao_processo_emissao': versaoProcessoEmissao,
      if (dataEntradaContingencia != null)
        'data_entrada_contingencia': dataEntradaContingencia,
      if (justificativaContingencia != null)
        'justificativa_contingencia': justificativaContingencia,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (valorIcmsDesonerado != null)
        'valor_icms_desonerado': valorIcmsDesonerado,
      if (totalIcmsFcpUfDestino != null)
        'total_icms_fcp_uf_destino': totalIcmsFcpUfDestino,
      if (totalIcmsInterestadualUfDestino != null)
        'total_icms_interestadual_uf_destino': totalIcmsInterestadualUfDestino,
      if (totalIcmsInterestadualUfRemetente != null)
        'total_icms_interestadual_uf_remetente':
            totalIcmsInterestadualUfRemetente,
      if (valorTotalFcp != null) 'valor_total_fcp': valorTotalFcp,
      if (baseCalculoIcmsSt != null) 'base_calculo_icms_st': baseCalculoIcmsSt,
      if (valorIcmsSt != null) 'valor_icms_st': valorIcmsSt,
      if (valorTotalFcpSt != null) 'valor_total_fcp_st': valorTotalFcpSt,
      if (valorTotalFcpStRetido != null)
        'valor_total_fcp_st_retido': valorTotalFcpStRetido,
      if (valorTotalProdutos != null)
        'valor_total_produtos': valorTotalProdutos,
      if (valorFrete != null) 'valor_frete': valorFrete,
      if (valorSeguro != null) 'valor_seguro': valorSeguro,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorImpostoImportacao != null)
        'valor_imposto_importacao': valorImpostoImportacao,
      if (valorIpi != null) 'valor_ipi': valorIpi,
      if (valorIpiDevolvido != null) 'valor_ipi_devolvido': valorIpiDevolvido,
      if (valorPis != null) 'valor_pis': valorPis,
      if (valorCofins != null) 'valor_cofins': valorCofins,
      if (valorDespesasAcessorias != null)
        'valor_despesas_acessorias': valorDespesasAcessorias,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (valorTotalTributos != null)
        'valor_total_tributos': valorTotalTributos,
      if (valorServicos != null) 'valor_servicos': valorServicos,
      if (baseCalculoIssqn != null) 'base_calculo_issqn': baseCalculoIssqn,
      if (valorIssqn != null) 'valor_issqn': valorIssqn,
      if (valorPisIssqn != null) 'valor_pis_issqn': valorPisIssqn,
      if (valorCofinsIssqn != null) 'valor_cofins_issqn': valorCofinsIssqn,
      if (dataPrestacaoServico != null)
        'data_prestacao_servico': dataPrestacaoServico,
      if (valorDeducaoIssqn != null) 'valor_deducao_issqn': valorDeducaoIssqn,
      if (outrasRetencoesIssqn != null)
        'outras_retencoes_issqn': outrasRetencoesIssqn,
      if (descontoIncondicionadoIssqn != null)
        'desconto_incondicionado_issqn': descontoIncondicionadoIssqn,
      if (descontoCondicionadoIssqn != null)
        'desconto_condicionado_issqn': descontoCondicionadoIssqn,
      if (totalRetencaoIssqn != null)
        'total_retencao_issqn': totalRetencaoIssqn,
      if (regimeEspecialTributacao != null)
        'regime_especial_tributacao': regimeEspecialTributacao,
      if (valorRetidoPis != null) 'valor_retido_pis': valorRetidoPis,
      if (valorRetidoCofins != null) 'valor_retido_cofins': valorRetidoCofins,
      if (valorRetidoCsll != null) 'valor_retido_csll': valorRetidoCsll,
      if (baseCalculoIrrf != null) 'base_calculo_irrf': baseCalculoIrrf,
      if (valorRetidoIrrf != null) 'valor_retido_irrf': valorRetidoIrrf,
      if (baseCalculoPrevidencia != null)
        'base_calculo_previdencia': baseCalculoPrevidencia,
      if (valorRetidoPrevidencia != null)
        'valor_retido_previdencia': valorRetidoPrevidencia,
      if (informacoesAddFisco != null)
        'informacoes_add_fisco': informacoesAddFisco,
      if (informacoesAddContribuinte != null)
        'informacoes_add_contribuinte': informacoesAddContribuinte,
      if (comexUfEmbarque != null) 'comex_uf_embarque': comexUfEmbarque,
      if (comexLocalEmbarque != null)
        'comex_local_embarque': comexLocalEmbarque,
      if (comexLocalDespacho != null)
        'comex_local_despacho': comexLocalDespacho,
      if (compraNotaEmpenho != null) 'compra_nota_empenho': compraNotaEmpenho,
      if (compraPedido != null) 'compra_pedido': compraPedido,
      if (compraContrato != null) 'compra_contrato': compraContrato,
      if (qrcode != null) 'qrcode': qrcode,
      if (urlChave != null) 'url_chave': urlChave,
      if (statusNota != null) 'status_nota': statusNota,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (idNfceMovimento != null) 'id_nfce_movimento': idNfceMovimento,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idTributOperacaoFiscal != null)
        'id_tribut_operacao_fiscal': idTributOperacaoFiscal,
      if (idCliente != null) 'id_cliente': idCliente,
    });
  }

  NfeCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendedor,
      Value<int?>? ufEmitente,
      Value<String?>? codigoNumerico,
      Value<String?>? naturezaOperacao,
      Value<String?>? codigoModelo,
      Value<String?>? serie,
      Value<String?>? numero,
      Value<DateTime?>? dataHoraEmissao,
      Value<DateTime?>? dataHoraEntradaSaida,
      Value<String?>? tipoOperacao,
      Value<String?>? localDestino,
      Value<int?>? codigoMunicipio,
      Value<String?>? formatoImpressaoDanfe,
      Value<String?>? tipoEmissao,
      Value<String?>? chaveAcesso,
      Value<String?>? digitoChaveAcesso,
      Value<String?>? ambiente,
      Value<String?>? finalidadeEmissao,
      Value<String?>? consumidorOperacao,
      Value<String?>? consumidorPresenca,
      Value<String?>? processoEmissao,
      Value<String?>? versaoProcessoEmissao,
      Value<DateTime?>? dataEntradaContingencia,
      Value<String?>? justificativaContingencia,
      Value<double?>? baseCalculoIcms,
      Value<double?>? valorIcms,
      Value<double?>? valorIcmsDesonerado,
      Value<double?>? totalIcmsFcpUfDestino,
      Value<double?>? totalIcmsInterestadualUfDestino,
      Value<double?>? totalIcmsInterestadualUfRemetente,
      Value<double?>? valorTotalFcp,
      Value<double?>? baseCalculoIcmsSt,
      Value<double?>? valorIcmsSt,
      Value<double?>? valorTotalFcpSt,
      Value<double?>? valorTotalFcpStRetido,
      Value<double?>? valorTotalProdutos,
      Value<double?>? valorFrete,
      Value<double?>? valorSeguro,
      Value<double?>? valorDesconto,
      Value<double?>? valorImpostoImportacao,
      Value<double?>? valorIpi,
      Value<double?>? valorIpiDevolvido,
      Value<double?>? valorPis,
      Value<double?>? valorCofins,
      Value<double?>? valorDespesasAcessorias,
      Value<double?>? valorTotal,
      Value<double?>? valorTotalTributos,
      Value<double?>? valorServicos,
      Value<double?>? baseCalculoIssqn,
      Value<double?>? valorIssqn,
      Value<double?>? valorPisIssqn,
      Value<double?>? valorCofinsIssqn,
      Value<DateTime?>? dataPrestacaoServico,
      Value<double?>? valorDeducaoIssqn,
      Value<double?>? outrasRetencoesIssqn,
      Value<double?>? descontoIncondicionadoIssqn,
      Value<double?>? descontoCondicionadoIssqn,
      Value<double?>? totalRetencaoIssqn,
      Value<String?>? regimeEspecialTributacao,
      Value<double?>? valorRetidoPis,
      Value<double?>? valorRetidoCofins,
      Value<double?>? valorRetidoCsll,
      Value<double?>? baseCalculoIrrf,
      Value<double?>? valorRetidoIrrf,
      Value<double?>? baseCalculoPrevidencia,
      Value<double?>? valorRetidoPrevidencia,
      Value<String?>? informacoesAddFisco,
      Value<String?>? informacoesAddContribuinte,
      Value<String?>? comexUfEmbarque,
      Value<String?>? comexLocalEmbarque,
      Value<String?>? comexLocalDespacho,
      Value<String?>? compraNotaEmpenho,
      Value<String?>? compraPedido,
      Value<String?>? compraContrato,
      Value<String?>? qrcode,
      Value<String?>? urlChave,
      Value<String?>? statusNota,
      Value<int?>? idFornecedor,
      Value<int?>? idNfceMovimento,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idTributOperacaoFiscal,
      Value<int?>? idCliente}) {
    return NfeCabecalhosCompanion(
      id: id ?? this.id,
      idVendedor: idVendedor ?? this.idVendedor,
      ufEmitente: ufEmitente ?? this.ufEmitente,
      codigoNumerico: codigoNumerico ?? this.codigoNumerico,
      naturezaOperacao: naturezaOperacao ?? this.naturezaOperacao,
      codigoModelo: codigoModelo ?? this.codigoModelo,
      serie: serie ?? this.serie,
      numero: numero ?? this.numero,
      dataHoraEmissao: dataHoraEmissao ?? this.dataHoraEmissao,
      dataHoraEntradaSaida: dataHoraEntradaSaida ?? this.dataHoraEntradaSaida,
      tipoOperacao: tipoOperacao ?? this.tipoOperacao,
      localDestino: localDestino ?? this.localDestino,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      formatoImpressaoDanfe:
          formatoImpressaoDanfe ?? this.formatoImpressaoDanfe,
      tipoEmissao: tipoEmissao ?? this.tipoEmissao,
      chaveAcesso: chaveAcesso ?? this.chaveAcesso,
      digitoChaveAcesso: digitoChaveAcesso ?? this.digitoChaveAcesso,
      ambiente: ambiente ?? this.ambiente,
      finalidadeEmissao: finalidadeEmissao ?? this.finalidadeEmissao,
      consumidorOperacao: consumidorOperacao ?? this.consumidorOperacao,
      consumidorPresenca: consumidorPresenca ?? this.consumidorPresenca,
      processoEmissao: processoEmissao ?? this.processoEmissao,
      versaoProcessoEmissao:
          versaoProcessoEmissao ?? this.versaoProcessoEmissao,
      dataEntradaContingencia:
          dataEntradaContingencia ?? this.dataEntradaContingencia,
      justificativaContingencia:
          justificativaContingencia ?? this.justificativaContingencia,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      valorIcmsDesonerado: valorIcmsDesonerado ?? this.valorIcmsDesonerado,
      totalIcmsFcpUfDestino:
          totalIcmsFcpUfDestino ?? this.totalIcmsFcpUfDestino,
      totalIcmsInterestadualUfDestino: totalIcmsInterestadualUfDestino ??
          this.totalIcmsInterestadualUfDestino,
      totalIcmsInterestadualUfRemetente: totalIcmsInterestadualUfRemetente ??
          this.totalIcmsInterestadualUfRemetente,
      valorTotalFcp: valorTotalFcp ?? this.valorTotalFcp,
      baseCalculoIcmsSt: baseCalculoIcmsSt ?? this.baseCalculoIcmsSt,
      valorIcmsSt: valorIcmsSt ?? this.valorIcmsSt,
      valorTotalFcpSt: valorTotalFcpSt ?? this.valorTotalFcpSt,
      valorTotalFcpStRetido:
          valorTotalFcpStRetido ?? this.valorTotalFcpStRetido,
      valorTotalProdutos: valorTotalProdutos ?? this.valorTotalProdutos,
      valorFrete: valorFrete ?? this.valorFrete,
      valorSeguro: valorSeguro ?? this.valorSeguro,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorImpostoImportacao:
          valorImpostoImportacao ?? this.valorImpostoImportacao,
      valorIpi: valorIpi ?? this.valorIpi,
      valorIpiDevolvido: valorIpiDevolvido ?? this.valorIpiDevolvido,
      valorPis: valorPis ?? this.valorPis,
      valorCofins: valorCofins ?? this.valorCofins,
      valorDespesasAcessorias:
          valorDespesasAcessorias ?? this.valorDespesasAcessorias,
      valorTotal: valorTotal ?? this.valorTotal,
      valorTotalTributos: valorTotalTributos ?? this.valorTotalTributos,
      valorServicos: valorServicos ?? this.valorServicos,
      baseCalculoIssqn: baseCalculoIssqn ?? this.baseCalculoIssqn,
      valorIssqn: valorIssqn ?? this.valorIssqn,
      valorPisIssqn: valorPisIssqn ?? this.valorPisIssqn,
      valorCofinsIssqn: valorCofinsIssqn ?? this.valorCofinsIssqn,
      dataPrestacaoServico: dataPrestacaoServico ?? this.dataPrestacaoServico,
      valorDeducaoIssqn: valorDeducaoIssqn ?? this.valorDeducaoIssqn,
      outrasRetencoesIssqn: outrasRetencoesIssqn ?? this.outrasRetencoesIssqn,
      descontoIncondicionadoIssqn:
          descontoIncondicionadoIssqn ?? this.descontoIncondicionadoIssqn,
      descontoCondicionadoIssqn:
          descontoCondicionadoIssqn ?? this.descontoCondicionadoIssqn,
      totalRetencaoIssqn: totalRetencaoIssqn ?? this.totalRetencaoIssqn,
      regimeEspecialTributacao:
          regimeEspecialTributacao ?? this.regimeEspecialTributacao,
      valorRetidoPis: valorRetidoPis ?? this.valorRetidoPis,
      valorRetidoCofins: valorRetidoCofins ?? this.valorRetidoCofins,
      valorRetidoCsll: valorRetidoCsll ?? this.valorRetidoCsll,
      baseCalculoIrrf: baseCalculoIrrf ?? this.baseCalculoIrrf,
      valorRetidoIrrf: valorRetidoIrrf ?? this.valorRetidoIrrf,
      baseCalculoPrevidencia:
          baseCalculoPrevidencia ?? this.baseCalculoPrevidencia,
      valorRetidoPrevidencia:
          valorRetidoPrevidencia ?? this.valorRetidoPrevidencia,
      informacoesAddFisco: informacoesAddFisco ?? this.informacoesAddFisco,
      informacoesAddContribuinte:
          informacoesAddContribuinte ?? this.informacoesAddContribuinte,
      comexUfEmbarque: comexUfEmbarque ?? this.comexUfEmbarque,
      comexLocalEmbarque: comexLocalEmbarque ?? this.comexLocalEmbarque,
      comexLocalDespacho: comexLocalDespacho ?? this.comexLocalDespacho,
      compraNotaEmpenho: compraNotaEmpenho ?? this.compraNotaEmpenho,
      compraPedido: compraPedido ?? this.compraPedido,
      compraContrato: compraContrato ?? this.compraContrato,
      qrcode: qrcode ?? this.qrcode,
      urlChave: urlChave ?? this.urlChave,
      statusNota: statusNota ?? this.statusNota,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      idNfceMovimento: idNfceMovimento ?? this.idNfceMovimento,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idTributOperacaoFiscal:
          idTributOperacaoFiscal ?? this.idTributOperacaoFiscal,
      idCliente: idCliente ?? this.idCliente,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendedor.present) {
      map['id_vendedor'] = Variable<int>(idVendedor.value);
    }
    if (ufEmitente.present) {
      map['uf_emitente'] = Variable<int>(ufEmitente.value);
    }
    if (codigoNumerico.present) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico.value);
    }
    if (naturezaOperacao.present) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao.value);
    }
    if (codigoModelo.present) {
      map['codigo_modelo'] = Variable<String>(codigoModelo.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataHoraEmissao.present) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao.value);
    }
    if (dataHoraEntradaSaida.present) {
      map['data_hora_entrada_saida'] =
          Variable<DateTime>(dataHoraEntradaSaida.value);
    }
    if (tipoOperacao.present) {
      map['tipo_operacao'] = Variable<String>(tipoOperacao.value);
    }
    if (localDestino.present) {
      map['local_destino'] = Variable<String>(localDestino.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (formatoImpressaoDanfe.present) {
      map['formato_impressao_danfe'] =
          Variable<String>(formatoImpressaoDanfe.value);
    }
    if (tipoEmissao.present) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao.value);
    }
    if (chaveAcesso.present) {
      map['chave_acesso'] = Variable<String>(chaveAcesso.value);
    }
    if (digitoChaveAcesso.present) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso.value);
    }
    if (ambiente.present) {
      map['ambiente'] = Variable<String>(ambiente.value);
    }
    if (finalidadeEmissao.present) {
      map['finalidade_emissao'] = Variable<String>(finalidadeEmissao.value);
    }
    if (consumidorOperacao.present) {
      map['consumidor_operacao'] = Variable<String>(consumidorOperacao.value);
    }
    if (consumidorPresenca.present) {
      map['consumidor_presenca'] = Variable<String>(consumidorPresenca.value);
    }
    if (processoEmissao.present) {
      map['processo_emissao'] = Variable<String>(processoEmissao.value);
    }
    if (versaoProcessoEmissao.present) {
      map['versao_processo_emissao'] =
          Variable<String>(versaoProcessoEmissao.value);
    }
    if (dataEntradaContingencia.present) {
      map['data_entrada_contingencia'] =
          Variable<DateTime>(dataEntradaContingencia.value);
    }
    if (justificativaContingencia.present) {
      map['justificativa_contingencia'] =
          Variable<String>(justificativaContingencia.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (valorIcmsDesonerado.present) {
      map['valor_icms_desonerado'] =
          Variable<double>(valorIcmsDesonerado.value);
    }
    if (totalIcmsFcpUfDestino.present) {
      map['total_icms_fcp_uf_destino'] =
          Variable<double>(totalIcmsFcpUfDestino.value);
    }
    if (totalIcmsInterestadualUfDestino.present) {
      map['total_icms_interestadual_uf_destino'] =
          Variable<double>(totalIcmsInterestadualUfDestino.value);
    }
    if (totalIcmsInterestadualUfRemetente.present) {
      map['total_icms_interestadual_uf_remetente'] =
          Variable<double>(totalIcmsInterestadualUfRemetente.value);
    }
    if (valorTotalFcp.present) {
      map['valor_total_fcp'] = Variable<double>(valorTotalFcp.value);
    }
    if (baseCalculoIcmsSt.present) {
      map['base_calculo_icms_st'] = Variable<double>(baseCalculoIcmsSt.value);
    }
    if (valorIcmsSt.present) {
      map['valor_icms_st'] = Variable<double>(valorIcmsSt.value);
    }
    if (valorTotalFcpSt.present) {
      map['valor_total_fcp_st'] = Variable<double>(valorTotalFcpSt.value);
    }
    if (valorTotalFcpStRetido.present) {
      map['valor_total_fcp_st_retido'] =
          Variable<double>(valorTotalFcpStRetido.value);
    }
    if (valorTotalProdutos.present) {
      map['valor_total_produtos'] = Variable<double>(valorTotalProdutos.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    if (valorSeguro.present) {
      map['valor_seguro'] = Variable<double>(valorSeguro.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorImpostoImportacao.present) {
      map['valor_imposto_importacao'] =
          Variable<double>(valorImpostoImportacao.value);
    }
    if (valorIpi.present) {
      map['valor_ipi'] = Variable<double>(valorIpi.value);
    }
    if (valorIpiDevolvido.present) {
      map['valor_ipi_devolvido'] = Variable<double>(valorIpiDevolvido.value);
    }
    if (valorPis.present) {
      map['valor_pis'] = Variable<double>(valorPis.value);
    }
    if (valorCofins.present) {
      map['valor_cofins'] = Variable<double>(valorCofins.value);
    }
    if (valorDespesasAcessorias.present) {
      map['valor_despesas_acessorias'] =
          Variable<double>(valorDespesasAcessorias.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (valorTotalTributos.present) {
      map['valor_total_tributos'] = Variable<double>(valorTotalTributos.value);
    }
    if (valorServicos.present) {
      map['valor_servicos'] = Variable<double>(valorServicos.value);
    }
    if (baseCalculoIssqn.present) {
      map['base_calculo_issqn'] = Variable<double>(baseCalculoIssqn.value);
    }
    if (valorIssqn.present) {
      map['valor_issqn'] = Variable<double>(valorIssqn.value);
    }
    if (valorPisIssqn.present) {
      map['valor_pis_issqn'] = Variable<double>(valorPisIssqn.value);
    }
    if (valorCofinsIssqn.present) {
      map['valor_cofins_issqn'] = Variable<double>(valorCofinsIssqn.value);
    }
    if (dataPrestacaoServico.present) {
      map['data_prestacao_servico'] =
          Variable<DateTime>(dataPrestacaoServico.value);
    }
    if (valorDeducaoIssqn.present) {
      map['valor_deducao_issqn'] = Variable<double>(valorDeducaoIssqn.value);
    }
    if (outrasRetencoesIssqn.present) {
      map['outras_retencoes_issqn'] =
          Variable<double>(outrasRetencoesIssqn.value);
    }
    if (descontoIncondicionadoIssqn.present) {
      map['desconto_incondicionado_issqn'] =
          Variable<double>(descontoIncondicionadoIssqn.value);
    }
    if (descontoCondicionadoIssqn.present) {
      map['desconto_condicionado_issqn'] =
          Variable<double>(descontoCondicionadoIssqn.value);
    }
    if (totalRetencaoIssqn.present) {
      map['total_retencao_issqn'] = Variable<double>(totalRetencaoIssqn.value);
    }
    if (regimeEspecialTributacao.present) {
      map['regime_especial_tributacao'] =
          Variable<String>(regimeEspecialTributacao.value);
    }
    if (valorRetidoPis.present) {
      map['valor_retido_pis'] = Variable<double>(valorRetidoPis.value);
    }
    if (valorRetidoCofins.present) {
      map['valor_retido_cofins'] = Variable<double>(valorRetidoCofins.value);
    }
    if (valorRetidoCsll.present) {
      map['valor_retido_csll'] = Variable<double>(valorRetidoCsll.value);
    }
    if (baseCalculoIrrf.present) {
      map['base_calculo_irrf'] = Variable<double>(baseCalculoIrrf.value);
    }
    if (valorRetidoIrrf.present) {
      map['valor_retido_irrf'] = Variable<double>(valorRetidoIrrf.value);
    }
    if (baseCalculoPrevidencia.present) {
      map['base_calculo_previdencia'] =
          Variable<double>(baseCalculoPrevidencia.value);
    }
    if (valorRetidoPrevidencia.present) {
      map['valor_retido_previdencia'] =
          Variable<double>(valorRetidoPrevidencia.value);
    }
    if (informacoesAddFisco.present) {
      map['informacoes_add_fisco'] =
          Variable<String>(informacoesAddFisco.value);
    }
    if (informacoesAddContribuinte.present) {
      map['informacoes_add_contribuinte'] =
          Variable<String>(informacoesAddContribuinte.value);
    }
    if (comexUfEmbarque.present) {
      map['comex_uf_embarque'] = Variable<String>(comexUfEmbarque.value);
    }
    if (comexLocalEmbarque.present) {
      map['comex_local_embarque'] = Variable<String>(comexLocalEmbarque.value);
    }
    if (comexLocalDespacho.present) {
      map['comex_local_despacho'] = Variable<String>(comexLocalDespacho.value);
    }
    if (compraNotaEmpenho.present) {
      map['compra_nota_empenho'] = Variable<String>(compraNotaEmpenho.value);
    }
    if (compraPedido.present) {
      map['compra_pedido'] = Variable<String>(compraPedido.value);
    }
    if (compraContrato.present) {
      map['compra_contrato'] = Variable<String>(compraContrato.value);
    }
    if (qrcode.present) {
      map['qrcode'] = Variable<String>(qrcode.value);
    }
    if (urlChave.present) {
      map['url_chave'] = Variable<String>(urlChave.value);
    }
    if (statusNota.present) {
      map['status_nota'] = Variable<String>(statusNota.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (idNfceMovimento.present) {
      map['id_nfce_movimento'] = Variable<int>(idNfceMovimento.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idTributOperacaoFiscal.present) {
      map['id_tribut_operacao_fiscal'] =
          Variable<int>(idTributOperacaoFiscal.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NfeCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('codigoModelo: $codigoModelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('dataHoraEntradaSaida: $dataHoraEntradaSaida, ')
          ..write('tipoOperacao: $tipoOperacao, ')
          ..write('localDestino: $localDestino, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('formatoImpressaoDanfe: $formatoImpressaoDanfe, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('ambiente: $ambiente, ')
          ..write('finalidadeEmissao: $finalidadeEmissao, ')
          ..write('consumidorOperacao: $consumidorOperacao, ')
          ..write('consumidorPresenca: $consumidorPresenca, ')
          ..write('processoEmissao: $processoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('dataEntradaContingencia: $dataEntradaContingencia, ')
          ..write('justificativaContingencia: $justificativaContingencia, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('valorIcmsDesonerado: $valorIcmsDesonerado, ')
          ..write('totalIcmsFcpUfDestino: $totalIcmsFcpUfDestino, ')
          ..write(
              'totalIcmsInterestadualUfDestino: $totalIcmsInterestadualUfDestino, ')
          ..write(
              'totalIcmsInterestadualUfRemetente: $totalIcmsInterestadualUfRemetente, ')
          ..write('valorTotalFcp: $valorTotalFcp, ')
          ..write('baseCalculoIcmsSt: $baseCalculoIcmsSt, ')
          ..write('valorIcmsSt: $valorIcmsSt, ')
          ..write('valorTotalFcpSt: $valorTotalFcpSt, ')
          ..write('valorTotalFcpStRetido: $valorTotalFcpStRetido, ')
          ..write('valorTotalProdutos: $valorTotalProdutos, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorImpostoImportacao: $valorImpostoImportacao, ')
          ..write('valorIpi: $valorIpi, ')
          ..write('valorIpiDevolvido: $valorIpiDevolvido, ')
          ..write('valorPis: $valorPis, ')
          ..write('valorCofins: $valorCofins, ')
          ..write('valorDespesasAcessorias: $valorDespesasAcessorias, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('valorTotalTributos: $valorTotalTributos, ')
          ..write('valorServicos: $valorServicos, ')
          ..write('baseCalculoIssqn: $baseCalculoIssqn, ')
          ..write('valorIssqn: $valorIssqn, ')
          ..write('valorPisIssqn: $valorPisIssqn, ')
          ..write('valorCofinsIssqn: $valorCofinsIssqn, ')
          ..write('dataPrestacaoServico: $dataPrestacaoServico, ')
          ..write('valorDeducaoIssqn: $valorDeducaoIssqn, ')
          ..write('outrasRetencoesIssqn: $outrasRetencoesIssqn, ')
          ..write('descontoIncondicionadoIssqn: $descontoIncondicionadoIssqn, ')
          ..write('descontoCondicionadoIssqn: $descontoCondicionadoIssqn, ')
          ..write('totalRetencaoIssqn: $totalRetencaoIssqn, ')
          ..write('regimeEspecialTributacao: $regimeEspecialTributacao, ')
          ..write('valorRetidoPis: $valorRetidoPis, ')
          ..write('valorRetidoCofins: $valorRetidoCofins, ')
          ..write('valorRetidoCsll: $valorRetidoCsll, ')
          ..write('baseCalculoIrrf: $baseCalculoIrrf, ')
          ..write('valorRetidoIrrf: $valorRetidoIrrf, ')
          ..write('baseCalculoPrevidencia: $baseCalculoPrevidencia, ')
          ..write('valorRetidoPrevidencia: $valorRetidoPrevidencia, ')
          ..write('informacoesAddFisco: $informacoesAddFisco, ')
          ..write('informacoesAddContribuinte: $informacoesAddContribuinte, ')
          ..write('comexUfEmbarque: $comexUfEmbarque, ')
          ..write('comexLocalEmbarque: $comexLocalEmbarque, ')
          ..write('comexLocalDespacho: $comexLocalDespacho, ')
          ..write('compraNotaEmpenho: $compraNotaEmpenho, ')
          ..write('compraPedido: $compraPedido, ')
          ..write('compraContrato: $compraContrato, ')
          ..write('qrcode: $qrcode, ')
          ..write('urlChave: $urlChave, ')
          ..write('statusNota: $statusNota, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idNfceMovimento: $idNfceMovimento, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idTributOperacaoFiscal: $idTributOperacaoFiscal, ')
          ..write('idCliente: $idCliente')
          ..write(')'))
        .toString();
  }
}

class $FiscalMunicipalRegimesTable extends FiscalMunicipalRegimes
    with TableInfo<$FiscalMunicipalRegimesTable, FiscalMunicipalRegime> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalMunicipalRegimesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, uf, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_municipal_regime';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalMunicipalRegime> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalMunicipalRegime map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalMunicipalRegime(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FiscalMunicipalRegimesTable createAlias(String alias) {
    return $FiscalMunicipalRegimesTable(attachedDatabase, alias);
  }
}

class FiscalMunicipalRegime extends DataClass
    implements Insertable<FiscalMunicipalRegime> {
  final int? id;
  final String? uf;
  final String? codigo;
  final String? nome;
  const FiscalMunicipalRegime({this.id, this.uf, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FiscalMunicipalRegime.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalMunicipalRegime(
      id: serializer.fromJson<int?>(json['id']),
      uf: serializer.fromJson<String?>(json['uf']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'uf': serializer.toJson<String?>(uf),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FiscalMunicipalRegime copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FiscalMunicipalRegime(
        id: id.present ? id.value : this.id,
        uf: uf.present ? uf.value : this.uf,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalMunicipalRegime(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, uf, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalMunicipalRegime &&
          other.id == this.id &&
          other.uf == this.uf &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FiscalMunicipalRegimesCompanion
    extends UpdateCompanion<FiscalMunicipalRegime> {
  final Value<int?> id;
  final Value<String?> uf;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FiscalMunicipalRegimesCompanion({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FiscalMunicipalRegimesCompanion.insert({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FiscalMunicipalRegime> custom({
    Expression<int>? id,
    Expression<String>? uf,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (uf != null) 'uf': uf,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FiscalMunicipalRegimesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? uf,
      Value<String?>? codigo,
      Value<String?>? nome}) {
    return FiscalMunicipalRegimesCompanion(
      id: id ?? this.id,
      uf: uf ?? this.uf,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalMunicipalRegimesCompanion(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FiscalEstadualRegimesTable extends FiscalEstadualRegimes
    with TableInfo<$FiscalEstadualRegimesTable, FiscalEstadualRegime> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalEstadualRegimesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, uf, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_estadual_regime';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalEstadualRegime> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalEstadualRegime map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalEstadualRegime(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FiscalEstadualRegimesTable createAlias(String alias) {
    return $FiscalEstadualRegimesTable(attachedDatabase, alias);
  }
}

class FiscalEstadualRegime extends DataClass
    implements Insertable<FiscalEstadualRegime> {
  final int? id;
  final String? uf;
  final String? codigo;
  final String? nome;
  const FiscalEstadualRegime({this.id, this.uf, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FiscalEstadualRegime.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalEstadualRegime(
      id: serializer.fromJson<int?>(json['id']),
      uf: serializer.fromJson<String?>(json['uf']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'uf': serializer.toJson<String?>(uf),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FiscalEstadualRegime copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FiscalEstadualRegime(
        id: id.present ? id.value : this.id,
        uf: uf.present ? uf.value : this.uf,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalEstadualRegime(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, uf, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalEstadualRegime &&
          other.id == this.id &&
          other.uf == this.uf &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FiscalEstadualRegimesCompanion
    extends UpdateCompanion<FiscalEstadualRegime> {
  final Value<int?> id;
  final Value<String?> uf;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FiscalEstadualRegimesCompanion({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FiscalEstadualRegimesCompanion.insert({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FiscalEstadualRegime> custom({
    Expression<int>? id,
    Expression<String>? uf,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (uf != null) 'uf': uf,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FiscalEstadualRegimesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? uf,
      Value<String?>? codigo,
      Value<String?>? nome}) {
    return FiscalEstadualRegimesCompanion(
      id: id ?? this.id,
      uf: uf ?? this.uf,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalEstadualRegimesCompanion(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FiscalEstadualPortesTable extends FiscalEstadualPortes
    with TableInfo<$FiscalEstadualPortesTable, FiscalEstadualPorte> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalEstadualPortesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, uf, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_estadual_porte';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalEstadualPorte> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalEstadualPorte map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalEstadualPorte(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FiscalEstadualPortesTable createAlias(String alias) {
    return $FiscalEstadualPortesTable(attachedDatabase, alias);
  }
}

class FiscalEstadualPorte extends DataClass
    implements Insertable<FiscalEstadualPorte> {
  final int? id;
  final String? uf;
  final String? codigo;
  final String? nome;
  const FiscalEstadualPorte({this.id, this.uf, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FiscalEstadualPorte.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalEstadualPorte(
      id: serializer.fromJson<int?>(json['id']),
      uf: serializer.fromJson<String?>(json['uf']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'uf': serializer.toJson<String?>(uf),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FiscalEstadualPorte copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FiscalEstadualPorte(
        id: id.present ? id.value : this.id,
        uf: uf.present ? uf.value : this.uf,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalEstadualPorte(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, uf, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalEstadualPorte &&
          other.id == this.id &&
          other.uf == this.uf &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FiscalEstadualPortesCompanion
    extends UpdateCompanion<FiscalEstadualPorte> {
  final Value<int?> id;
  final Value<String?> uf;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FiscalEstadualPortesCompanion({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FiscalEstadualPortesCompanion.insert({
    this.id = const Value.absent(),
    this.uf = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FiscalEstadualPorte> custom({
    Expression<int>? id,
    Expression<String>? uf,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (uf != null) 'uf': uf,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FiscalEstadualPortesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? uf,
      Value<String?>? codigo,
      Value<String?>? nome}) {
    return FiscalEstadualPortesCompanion(
      id: id ?? this.id,
      uf: uf ?? this.uf,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalEstadualPortesCompanion(')
          ..write('id: $id, ')
          ..write('uf: $uf, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FiscalNotaFiscalEntradasTable extends FiscalNotaFiscalEntradas
    with TableInfo<$FiscalNotaFiscalEntradasTable, FiscalNotaFiscalEntrada> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalNotaFiscalEntradasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfeCabecalhoMeta =
      const VerificationMeta('idNfeCabecalho');
  @override
  late final GeneratedColumn<int> idNfeCabecalho = GeneratedColumn<int>(
      'id_nfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cfopEntradaMeta =
      const VerificationMeta('cfopEntrada');
  @override
  late final GeneratedColumn<int> cfopEntrada = GeneratedColumn<int>(
      'cfop_entrada', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorRateioFreteMeta =
      const VerificationMeta('valorRateioFrete');
  @override
  late final GeneratedColumn<double> valorRateioFrete = GeneratedColumn<double>(
      'valor_rateio_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCustoMedioMeta =
      const VerificationMeta('valorCustoMedio');
  @override
  late final GeneratedColumn<double> valorCustoMedio = GeneratedColumn<double>(
      'valor_custo_medio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsAntecipadoMeta =
      const VerificationMeta('valorIcmsAntecipado');
  @override
  late final GeneratedColumn<double> valorIcmsAntecipado =
      GeneratedColumn<double>('valor_icms_antecipado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcIcmsAntecipadoMeta =
      const VerificationMeta('valorBcIcmsAntecipado');
  @override
  late final GeneratedColumn<double> valorBcIcmsAntecipado =
      GeneratedColumn<double>('valor_bc_icms_antecipado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcIcmsCreditadoMeta =
      const VerificationMeta('valorBcIcmsCreditado');
  @override
  late final GeneratedColumn<double> valorBcIcmsCreditado =
      GeneratedColumn<double>('valor_bc_icms_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcPisCreditadoMeta =
      const VerificationMeta('valorBcPisCreditado');
  @override
  late final GeneratedColumn<double> valorBcPisCreditado =
      GeneratedColumn<double>('valor_bc_pis_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcCofinsCreditadoMeta =
      const VerificationMeta('valorBcCofinsCreditado');
  @override
  late final GeneratedColumn<double> valorBcCofinsCreditado =
      GeneratedColumn<double>('valor_bc_cofins_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBcIpiCreditadoMeta =
      const VerificationMeta('valorBcIpiCreditado');
  @override
  late final GeneratedColumn<double> valorBcIpiCreditado =
      GeneratedColumn<double>('valor_bc_ipi_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _cstCreditoIcmsMeta =
      const VerificationMeta('cstCreditoIcms');
  @override
  late final GeneratedColumn<String> cstCreditoIcms = GeneratedColumn<String>(
      'cst_credito_icms', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cstCreditoPisMeta =
      const VerificationMeta('cstCreditoPis');
  @override
  late final GeneratedColumn<String> cstCreditoPis = GeneratedColumn<String>(
      'cst_credito_pis', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cstCreditoCofinsMeta =
      const VerificationMeta('cstCreditoCofins');
  @override
  late final GeneratedColumn<String> cstCreditoCofins = GeneratedColumn<String>(
      'cst_credito_cofins', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cstCreditoIpiMeta =
      const VerificationMeta('cstCreditoIpi');
  @override
  late final GeneratedColumn<String> cstCreditoIpi = GeneratedColumn<String>(
      'cst_credito_ipi', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsCreditadoMeta =
      const VerificationMeta('valorIcmsCreditado');
  @override
  late final GeneratedColumn<double> valorIcmsCreditado =
      GeneratedColumn<double>('valor_icms_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPisCreditadoMeta =
      const VerificationMeta('valorPisCreditado');
  @override
  late final GeneratedColumn<double> valorPisCreditado =
      GeneratedColumn<double>('valor_pis_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCofinsCreditadoMeta =
      const VerificationMeta('valorCofinsCreditado');
  @override
  late final GeneratedColumn<double> valorCofinsCreditado =
      GeneratedColumn<double>('valor_cofins_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIpiCreditadoMeta =
      const VerificationMeta('valorIpiCreditado');
  @override
  late final GeneratedColumn<double> valorIpiCreditado =
      GeneratedColumn<double>('valor_ipi_creditado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _qtdeParcelaCreditoPisMeta =
      const VerificationMeta('qtdeParcelaCreditoPis');
  @override
  late final GeneratedColumn<int> qtdeParcelaCreditoPis = GeneratedColumn<int>(
      'qtde_parcela_credito_pis', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _qtdeParcelaCreditoCofinsMeta =
      const VerificationMeta('qtdeParcelaCreditoCofins');
  @override
  late final GeneratedColumn<int> qtdeParcelaCreditoCofins =
      GeneratedColumn<int>('qtde_parcela_credito_cofins', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _qtdeParcelaCreditoIcmsMeta =
      const VerificationMeta('qtdeParcelaCreditoIcms');
  @override
  late final GeneratedColumn<int> qtdeParcelaCreditoIcms = GeneratedColumn<int>(
      'qtde_parcela_credito_icms', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _qtdeParcelaCreditoIpiMeta =
      const VerificationMeta('qtdeParcelaCreditoIpi');
  @override
  late final GeneratedColumn<int> qtdeParcelaCreditoIpi = GeneratedColumn<int>(
      'qtde_parcela_credito_ipi', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaCreditoIcmsMeta =
      const VerificationMeta('aliquotaCreditoIcms');
  @override
  late final GeneratedColumn<double> aliquotaCreditoIcms =
      GeneratedColumn<double>('aliquota_credito_icms', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaCreditoPisMeta =
      const VerificationMeta('aliquotaCreditoPis');
  @override
  late final GeneratedColumn<double> aliquotaCreditoPis =
      GeneratedColumn<double>('aliquota_credito_pis', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaCreditoCofinsMeta =
      const VerificationMeta('aliquotaCreditoCofins');
  @override
  late final GeneratedColumn<double> aliquotaCreditoCofins =
      GeneratedColumn<double>('aliquota_credito_cofins', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaCreditoIpiMeta =
      const VerificationMeta('aliquotaCreditoIpi');
  @override
  late final GeneratedColumn<double> aliquotaCreditoIpi =
      GeneratedColumn<double>('aliquota_credito_ipi', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idNfeCabecalho,
        competencia,
        cfopEntrada,
        valorRateioFrete,
        valorCustoMedio,
        valorIcmsAntecipado,
        valorBcIcmsAntecipado,
        valorBcIcmsCreditado,
        valorBcPisCreditado,
        valorBcCofinsCreditado,
        valorBcIpiCreditado,
        cstCreditoIcms,
        cstCreditoPis,
        cstCreditoCofins,
        cstCreditoIpi,
        valorIcmsCreditado,
        valorPisCreditado,
        valorCofinsCreditado,
        valorIpiCreditado,
        qtdeParcelaCreditoPis,
        qtdeParcelaCreditoCofins,
        qtdeParcelaCreditoIcms,
        qtdeParcelaCreditoIpi,
        aliquotaCreditoIcms,
        aliquotaCreditoPis,
        aliquotaCreditoCofins,
        aliquotaCreditoIpi
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_nota_fiscal_entrada';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalNotaFiscalEntrada> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_nfe_cabecalho')) {
      context.handle(
          _idNfeCabecalhoMeta,
          idNfeCabecalho.isAcceptableOrUnknown(
              data['id_nfe_cabecalho']!, _idNfeCabecalhoMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('cfop_entrada')) {
      context.handle(
          _cfopEntradaMeta,
          cfopEntrada.isAcceptableOrUnknown(
              data['cfop_entrada']!, _cfopEntradaMeta));
    }
    if (data.containsKey('valor_rateio_frete')) {
      context.handle(
          _valorRateioFreteMeta,
          valorRateioFrete.isAcceptableOrUnknown(
              data['valor_rateio_frete']!, _valorRateioFreteMeta));
    }
    if (data.containsKey('valor_custo_medio')) {
      context.handle(
          _valorCustoMedioMeta,
          valorCustoMedio.isAcceptableOrUnknown(
              data['valor_custo_medio']!, _valorCustoMedioMeta));
    }
    if (data.containsKey('valor_icms_antecipado')) {
      context.handle(
          _valorIcmsAntecipadoMeta,
          valorIcmsAntecipado.isAcceptableOrUnknown(
              data['valor_icms_antecipado']!, _valorIcmsAntecipadoMeta));
    }
    if (data.containsKey('valor_bc_icms_antecipado')) {
      context.handle(
          _valorBcIcmsAntecipadoMeta,
          valorBcIcmsAntecipado.isAcceptableOrUnknown(
              data['valor_bc_icms_antecipado']!, _valorBcIcmsAntecipadoMeta));
    }
    if (data.containsKey('valor_bc_icms_creditado')) {
      context.handle(
          _valorBcIcmsCreditadoMeta,
          valorBcIcmsCreditado.isAcceptableOrUnknown(
              data['valor_bc_icms_creditado']!, _valorBcIcmsCreditadoMeta));
    }
    if (data.containsKey('valor_bc_pis_creditado')) {
      context.handle(
          _valorBcPisCreditadoMeta,
          valorBcPisCreditado.isAcceptableOrUnknown(
              data['valor_bc_pis_creditado']!, _valorBcPisCreditadoMeta));
    }
    if (data.containsKey('valor_bc_cofins_creditado')) {
      context.handle(
          _valorBcCofinsCreditadoMeta,
          valorBcCofinsCreditado.isAcceptableOrUnknown(
              data['valor_bc_cofins_creditado']!, _valorBcCofinsCreditadoMeta));
    }
    if (data.containsKey('valor_bc_ipi_creditado')) {
      context.handle(
          _valorBcIpiCreditadoMeta,
          valorBcIpiCreditado.isAcceptableOrUnknown(
              data['valor_bc_ipi_creditado']!, _valorBcIpiCreditadoMeta));
    }
    if (data.containsKey('cst_credito_icms')) {
      context.handle(
          _cstCreditoIcmsMeta,
          cstCreditoIcms.isAcceptableOrUnknown(
              data['cst_credito_icms']!, _cstCreditoIcmsMeta));
    }
    if (data.containsKey('cst_credito_pis')) {
      context.handle(
          _cstCreditoPisMeta,
          cstCreditoPis.isAcceptableOrUnknown(
              data['cst_credito_pis']!, _cstCreditoPisMeta));
    }
    if (data.containsKey('cst_credito_cofins')) {
      context.handle(
          _cstCreditoCofinsMeta,
          cstCreditoCofins.isAcceptableOrUnknown(
              data['cst_credito_cofins']!, _cstCreditoCofinsMeta));
    }
    if (data.containsKey('cst_credito_ipi')) {
      context.handle(
          _cstCreditoIpiMeta,
          cstCreditoIpi.isAcceptableOrUnknown(
              data['cst_credito_ipi']!, _cstCreditoIpiMeta));
    }
    if (data.containsKey('valor_icms_creditado')) {
      context.handle(
          _valorIcmsCreditadoMeta,
          valorIcmsCreditado.isAcceptableOrUnknown(
              data['valor_icms_creditado']!, _valorIcmsCreditadoMeta));
    }
    if (data.containsKey('valor_pis_creditado')) {
      context.handle(
          _valorPisCreditadoMeta,
          valorPisCreditado.isAcceptableOrUnknown(
              data['valor_pis_creditado']!, _valorPisCreditadoMeta));
    }
    if (data.containsKey('valor_cofins_creditado')) {
      context.handle(
          _valorCofinsCreditadoMeta,
          valorCofinsCreditado.isAcceptableOrUnknown(
              data['valor_cofins_creditado']!, _valorCofinsCreditadoMeta));
    }
    if (data.containsKey('valor_ipi_creditado')) {
      context.handle(
          _valorIpiCreditadoMeta,
          valorIpiCreditado.isAcceptableOrUnknown(
              data['valor_ipi_creditado']!, _valorIpiCreditadoMeta));
    }
    if (data.containsKey('qtde_parcela_credito_pis')) {
      context.handle(
          _qtdeParcelaCreditoPisMeta,
          qtdeParcelaCreditoPis.isAcceptableOrUnknown(
              data['qtde_parcela_credito_pis']!, _qtdeParcelaCreditoPisMeta));
    }
    if (data.containsKey('qtde_parcela_credito_cofins')) {
      context.handle(
          _qtdeParcelaCreditoCofinsMeta,
          qtdeParcelaCreditoCofins.isAcceptableOrUnknown(
              data['qtde_parcela_credito_cofins']!,
              _qtdeParcelaCreditoCofinsMeta));
    }
    if (data.containsKey('qtde_parcela_credito_icms')) {
      context.handle(
          _qtdeParcelaCreditoIcmsMeta,
          qtdeParcelaCreditoIcms.isAcceptableOrUnknown(
              data['qtde_parcela_credito_icms']!, _qtdeParcelaCreditoIcmsMeta));
    }
    if (data.containsKey('qtde_parcela_credito_ipi')) {
      context.handle(
          _qtdeParcelaCreditoIpiMeta,
          qtdeParcelaCreditoIpi.isAcceptableOrUnknown(
              data['qtde_parcela_credito_ipi']!, _qtdeParcelaCreditoIpiMeta));
    }
    if (data.containsKey('aliquota_credito_icms')) {
      context.handle(
          _aliquotaCreditoIcmsMeta,
          aliquotaCreditoIcms.isAcceptableOrUnknown(
              data['aliquota_credito_icms']!, _aliquotaCreditoIcmsMeta));
    }
    if (data.containsKey('aliquota_credito_pis')) {
      context.handle(
          _aliquotaCreditoPisMeta,
          aliquotaCreditoPis.isAcceptableOrUnknown(
              data['aliquota_credito_pis']!, _aliquotaCreditoPisMeta));
    }
    if (data.containsKey('aliquota_credito_cofins')) {
      context.handle(
          _aliquotaCreditoCofinsMeta,
          aliquotaCreditoCofins.isAcceptableOrUnknown(
              data['aliquota_credito_cofins']!, _aliquotaCreditoCofinsMeta));
    }
    if (data.containsKey('aliquota_credito_ipi')) {
      context.handle(
          _aliquotaCreditoIpiMeta,
          aliquotaCreditoIpi.isAcceptableOrUnknown(
              data['aliquota_credito_ipi']!, _aliquotaCreditoIpiMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalNotaFiscalEntrada map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalNotaFiscalEntrada(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idNfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nfe_cabecalho']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      cfopEntrada: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cfop_entrada']),
      valorRateioFrete: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_rateio_frete']),
      valorCustoMedio: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_custo_medio']),
      valorIcmsAntecipado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_antecipado']),
      valorBcIcmsAntecipado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_icms_antecipado']),
      valorBcIcmsCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_icms_creditado']),
      valorBcPisCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_pis_creditado']),
      valorBcCofinsCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_cofins_creditado']),
      valorBcIpiCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_bc_ipi_creditado']),
      cstCreditoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cst_credito_icms']),
      cstCreditoPis: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst_credito_pis']),
      cstCreditoCofins: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}cst_credito_cofins']),
      cstCreditoIpi: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cst_credito_ipi']),
      valorIcmsCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_creditado']),
      valorPisCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_pis_creditado']),
      valorCofinsCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_cofins_creditado']),
      valorIpiCreditado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_ipi_creditado']),
      qtdeParcelaCreditoPis: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}qtde_parcela_credito_pis']),
      qtdeParcelaCreditoCofins: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}qtde_parcela_credito_cofins']),
      qtdeParcelaCreditoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}qtde_parcela_credito_icms']),
      qtdeParcelaCreditoIpi: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}qtde_parcela_credito_ipi']),
      aliquotaCreditoIcms: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_credito_icms']),
      aliquotaCreditoPis: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_credito_pis']),
      aliquotaCreditoCofins: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}aliquota_credito_cofins']),
      aliquotaCreditoIpi: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}aliquota_credito_ipi']),
    );
  }

  @override
  $FiscalNotaFiscalEntradasTable createAlias(String alias) {
    return $FiscalNotaFiscalEntradasTable(attachedDatabase, alias);
  }
}

class FiscalNotaFiscalEntrada extends DataClass
    implements Insertable<FiscalNotaFiscalEntrada> {
  final int? id;
  final int? idNfeCabecalho;
  final String? competencia;
  final int? cfopEntrada;
  final double? valorRateioFrete;
  final double? valorCustoMedio;
  final double? valorIcmsAntecipado;
  final double? valorBcIcmsAntecipado;
  final double? valorBcIcmsCreditado;
  final double? valorBcPisCreditado;
  final double? valorBcCofinsCreditado;
  final double? valorBcIpiCreditado;
  final String? cstCreditoIcms;
  final String? cstCreditoPis;
  final String? cstCreditoCofins;
  final String? cstCreditoIpi;
  final double? valorIcmsCreditado;
  final double? valorPisCreditado;
  final double? valorCofinsCreditado;
  final double? valorIpiCreditado;
  final int? qtdeParcelaCreditoPis;
  final int? qtdeParcelaCreditoCofins;
  final int? qtdeParcelaCreditoIcms;
  final int? qtdeParcelaCreditoIpi;
  final double? aliquotaCreditoIcms;
  final double? aliquotaCreditoPis;
  final double? aliquotaCreditoCofins;
  final double? aliquotaCreditoIpi;
  const FiscalNotaFiscalEntrada(
      {this.id,
      this.idNfeCabecalho,
      this.competencia,
      this.cfopEntrada,
      this.valorRateioFrete,
      this.valorCustoMedio,
      this.valorIcmsAntecipado,
      this.valorBcIcmsAntecipado,
      this.valorBcIcmsCreditado,
      this.valorBcPisCreditado,
      this.valorBcCofinsCreditado,
      this.valorBcIpiCreditado,
      this.cstCreditoIcms,
      this.cstCreditoPis,
      this.cstCreditoCofins,
      this.cstCreditoIpi,
      this.valorIcmsCreditado,
      this.valorPisCreditado,
      this.valorCofinsCreditado,
      this.valorIpiCreditado,
      this.qtdeParcelaCreditoPis,
      this.qtdeParcelaCreditoCofins,
      this.qtdeParcelaCreditoIcms,
      this.qtdeParcelaCreditoIpi,
      this.aliquotaCreditoIcms,
      this.aliquotaCreditoPis,
      this.aliquotaCreditoCofins,
      this.aliquotaCreditoIpi});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idNfeCabecalho != null) {
      map['id_nfe_cabecalho'] = Variable<int>(idNfeCabecalho);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || cfopEntrada != null) {
      map['cfop_entrada'] = Variable<int>(cfopEntrada);
    }
    if (!nullToAbsent || valorRateioFrete != null) {
      map['valor_rateio_frete'] = Variable<double>(valorRateioFrete);
    }
    if (!nullToAbsent || valorCustoMedio != null) {
      map['valor_custo_medio'] = Variable<double>(valorCustoMedio);
    }
    if (!nullToAbsent || valorIcmsAntecipado != null) {
      map['valor_icms_antecipado'] = Variable<double>(valorIcmsAntecipado);
    }
    if (!nullToAbsent || valorBcIcmsAntecipado != null) {
      map['valor_bc_icms_antecipado'] = Variable<double>(valorBcIcmsAntecipado);
    }
    if (!nullToAbsent || valorBcIcmsCreditado != null) {
      map['valor_bc_icms_creditado'] = Variable<double>(valorBcIcmsCreditado);
    }
    if (!nullToAbsent || valorBcPisCreditado != null) {
      map['valor_bc_pis_creditado'] = Variable<double>(valorBcPisCreditado);
    }
    if (!nullToAbsent || valorBcCofinsCreditado != null) {
      map['valor_bc_cofins_creditado'] =
          Variable<double>(valorBcCofinsCreditado);
    }
    if (!nullToAbsent || valorBcIpiCreditado != null) {
      map['valor_bc_ipi_creditado'] = Variable<double>(valorBcIpiCreditado);
    }
    if (!nullToAbsent || cstCreditoIcms != null) {
      map['cst_credito_icms'] = Variable<String>(cstCreditoIcms);
    }
    if (!nullToAbsent || cstCreditoPis != null) {
      map['cst_credito_pis'] = Variable<String>(cstCreditoPis);
    }
    if (!nullToAbsent || cstCreditoCofins != null) {
      map['cst_credito_cofins'] = Variable<String>(cstCreditoCofins);
    }
    if (!nullToAbsent || cstCreditoIpi != null) {
      map['cst_credito_ipi'] = Variable<String>(cstCreditoIpi);
    }
    if (!nullToAbsent || valorIcmsCreditado != null) {
      map['valor_icms_creditado'] = Variable<double>(valorIcmsCreditado);
    }
    if (!nullToAbsent || valorPisCreditado != null) {
      map['valor_pis_creditado'] = Variable<double>(valorPisCreditado);
    }
    if (!nullToAbsent || valorCofinsCreditado != null) {
      map['valor_cofins_creditado'] = Variable<double>(valorCofinsCreditado);
    }
    if (!nullToAbsent || valorIpiCreditado != null) {
      map['valor_ipi_creditado'] = Variable<double>(valorIpiCreditado);
    }
    if (!nullToAbsent || qtdeParcelaCreditoPis != null) {
      map['qtde_parcela_credito_pis'] = Variable<int>(qtdeParcelaCreditoPis);
    }
    if (!nullToAbsent || qtdeParcelaCreditoCofins != null) {
      map['qtde_parcela_credito_cofins'] =
          Variable<int>(qtdeParcelaCreditoCofins);
    }
    if (!nullToAbsent || qtdeParcelaCreditoIcms != null) {
      map['qtde_parcela_credito_icms'] = Variable<int>(qtdeParcelaCreditoIcms);
    }
    if (!nullToAbsent || qtdeParcelaCreditoIpi != null) {
      map['qtde_parcela_credito_ipi'] = Variable<int>(qtdeParcelaCreditoIpi);
    }
    if (!nullToAbsent || aliquotaCreditoIcms != null) {
      map['aliquota_credito_icms'] = Variable<double>(aliquotaCreditoIcms);
    }
    if (!nullToAbsent || aliquotaCreditoPis != null) {
      map['aliquota_credito_pis'] = Variable<double>(aliquotaCreditoPis);
    }
    if (!nullToAbsent || aliquotaCreditoCofins != null) {
      map['aliquota_credito_cofins'] = Variable<double>(aliquotaCreditoCofins);
    }
    if (!nullToAbsent || aliquotaCreditoIpi != null) {
      map['aliquota_credito_ipi'] = Variable<double>(aliquotaCreditoIpi);
    }
    return map;
  }

  factory FiscalNotaFiscalEntrada.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalNotaFiscalEntrada(
      id: serializer.fromJson<int?>(json['id']),
      idNfeCabecalho: serializer.fromJson<int?>(json['idNfeCabecalho']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      cfopEntrada: serializer.fromJson<int?>(json['cfopEntrada']),
      valorRateioFrete: serializer.fromJson<double?>(json['valorRateioFrete']),
      valorCustoMedio: serializer.fromJson<double?>(json['valorCustoMedio']),
      valorIcmsAntecipado:
          serializer.fromJson<double?>(json['valorIcmsAntecipado']),
      valorBcIcmsAntecipado:
          serializer.fromJson<double?>(json['valorBcIcmsAntecipado']),
      valorBcIcmsCreditado:
          serializer.fromJson<double?>(json['valorBcIcmsCreditado']),
      valorBcPisCreditado:
          serializer.fromJson<double?>(json['valorBcPisCreditado']),
      valorBcCofinsCreditado:
          serializer.fromJson<double?>(json['valorBcCofinsCreditado']),
      valorBcIpiCreditado:
          serializer.fromJson<double?>(json['valorBcIpiCreditado']),
      cstCreditoIcms: serializer.fromJson<String?>(json['cstCreditoIcms']),
      cstCreditoPis: serializer.fromJson<String?>(json['cstCreditoPis']),
      cstCreditoCofins: serializer.fromJson<String?>(json['cstCreditoCofins']),
      cstCreditoIpi: serializer.fromJson<String?>(json['cstCreditoIpi']),
      valorIcmsCreditado:
          serializer.fromJson<double?>(json['valorIcmsCreditado']),
      valorPisCreditado:
          serializer.fromJson<double?>(json['valorPisCreditado']),
      valorCofinsCreditado:
          serializer.fromJson<double?>(json['valorCofinsCreditado']),
      valorIpiCreditado:
          serializer.fromJson<double?>(json['valorIpiCreditado']),
      qtdeParcelaCreditoPis:
          serializer.fromJson<int?>(json['qtdeParcelaCreditoPis']),
      qtdeParcelaCreditoCofins:
          serializer.fromJson<int?>(json['qtdeParcelaCreditoCofins']),
      qtdeParcelaCreditoIcms:
          serializer.fromJson<int?>(json['qtdeParcelaCreditoIcms']),
      qtdeParcelaCreditoIpi:
          serializer.fromJson<int?>(json['qtdeParcelaCreditoIpi']),
      aliquotaCreditoIcms:
          serializer.fromJson<double?>(json['aliquotaCreditoIcms']),
      aliquotaCreditoPis:
          serializer.fromJson<double?>(json['aliquotaCreditoPis']),
      aliquotaCreditoCofins:
          serializer.fromJson<double?>(json['aliquotaCreditoCofins']),
      aliquotaCreditoIpi:
          serializer.fromJson<double?>(json['aliquotaCreditoIpi']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idNfeCabecalho': serializer.toJson<int?>(idNfeCabecalho),
      'competencia': serializer.toJson<String?>(competencia),
      'cfopEntrada': serializer.toJson<int?>(cfopEntrada),
      'valorRateioFrete': serializer.toJson<double?>(valorRateioFrete),
      'valorCustoMedio': serializer.toJson<double?>(valorCustoMedio),
      'valorIcmsAntecipado': serializer.toJson<double?>(valorIcmsAntecipado),
      'valorBcIcmsAntecipado':
          serializer.toJson<double?>(valorBcIcmsAntecipado),
      'valorBcIcmsCreditado': serializer.toJson<double?>(valorBcIcmsCreditado),
      'valorBcPisCreditado': serializer.toJson<double?>(valorBcPisCreditado),
      'valorBcCofinsCreditado':
          serializer.toJson<double?>(valorBcCofinsCreditado),
      'valorBcIpiCreditado': serializer.toJson<double?>(valorBcIpiCreditado),
      'cstCreditoIcms': serializer.toJson<String?>(cstCreditoIcms),
      'cstCreditoPis': serializer.toJson<String?>(cstCreditoPis),
      'cstCreditoCofins': serializer.toJson<String?>(cstCreditoCofins),
      'cstCreditoIpi': serializer.toJson<String?>(cstCreditoIpi),
      'valorIcmsCreditado': serializer.toJson<double?>(valorIcmsCreditado),
      'valorPisCreditado': serializer.toJson<double?>(valorPisCreditado),
      'valorCofinsCreditado': serializer.toJson<double?>(valorCofinsCreditado),
      'valorIpiCreditado': serializer.toJson<double?>(valorIpiCreditado),
      'qtdeParcelaCreditoPis': serializer.toJson<int?>(qtdeParcelaCreditoPis),
      'qtdeParcelaCreditoCofins':
          serializer.toJson<int?>(qtdeParcelaCreditoCofins),
      'qtdeParcelaCreditoIcms': serializer.toJson<int?>(qtdeParcelaCreditoIcms),
      'qtdeParcelaCreditoIpi': serializer.toJson<int?>(qtdeParcelaCreditoIpi),
      'aliquotaCreditoIcms': serializer.toJson<double?>(aliquotaCreditoIcms),
      'aliquotaCreditoPis': serializer.toJson<double?>(aliquotaCreditoPis),
      'aliquotaCreditoCofins':
          serializer.toJson<double?>(aliquotaCreditoCofins),
      'aliquotaCreditoIpi': serializer.toJson<double?>(aliquotaCreditoIpi),
    };
  }

  FiscalNotaFiscalEntrada copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idNfeCabecalho = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<int?> cfopEntrada = const Value.absent(),
          Value<double?> valorRateioFrete = const Value.absent(),
          Value<double?> valorCustoMedio = const Value.absent(),
          Value<double?> valorIcmsAntecipado = const Value.absent(),
          Value<double?> valorBcIcmsAntecipado = const Value.absent(),
          Value<double?> valorBcIcmsCreditado = const Value.absent(),
          Value<double?> valorBcPisCreditado = const Value.absent(),
          Value<double?> valorBcCofinsCreditado = const Value.absent(),
          Value<double?> valorBcIpiCreditado = const Value.absent(),
          Value<String?> cstCreditoIcms = const Value.absent(),
          Value<String?> cstCreditoPis = const Value.absent(),
          Value<String?> cstCreditoCofins = const Value.absent(),
          Value<String?> cstCreditoIpi = const Value.absent(),
          Value<double?> valorIcmsCreditado = const Value.absent(),
          Value<double?> valorPisCreditado = const Value.absent(),
          Value<double?> valorCofinsCreditado = const Value.absent(),
          Value<double?> valorIpiCreditado = const Value.absent(),
          Value<int?> qtdeParcelaCreditoPis = const Value.absent(),
          Value<int?> qtdeParcelaCreditoCofins = const Value.absent(),
          Value<int?> qtdeParcelaCreditoIcms = const Value.absent(),
          Value<int?> qtdeParcelaCreditoIpi = const Value.absent(),
          Value<double?> aliquotaCreditoIcms = const Value.absent(),
          Value<double?> aliquotaCreditoPis = const Value.absent(),
          Value<double?> aliquotaCreditoCofins = const Value.absent(),
          Value<double?> aliquotaCreditoIpi = const Value.absent()}) =>
      FiscalNotaFiscalEntrada(
        id: id.present ? id.value : this.id,
        idNfeCabecalho:
            idNfeCabecalho.present ? idNfeCabecalho.value : this.idNfeCabecalho,
        competencia: competencia.present ? competencia.value : this.competencia,
        cfopEntrada: cfopEntrada.present ? cfopEntrada.value : this.cfopEntrada,
        valorRateioFrete: valorRateioFrete.present
            ? valorRateioFrete.value
            : this.valorRateioFrete,
        valorCustoMedio: valorCustoMedio.present
            ? valorCustoMedio.value
            : this.valorCustoMedio,
        valorIcmsAntecipado: valorIcmsAntecipado.present
            ? valorIcmsAntecipado.value
            : this.valorIcmsAntecipado,
        valorBcIcmsAntecipado: valorBcIcmsAntecipado.present
            ? valorBcIcmsAntecipado.value
            : this.valorBcIcmsAntecipado,
        valorBcIcmsCreditado: valorBcIcmsCreditado.present
            ? valorBcIcmsCreditado.value
            : this.valorBcIcmsCreditado,
        valorBcPisCreditado: valorBcPisCreditado.present
            ? valorBcPisCreditado.value
            : this.valorBcPisCreditado,
        valorBcCofinsCreditado: valorBcCofinsCreditado.present
            ? valorBcCofinsCreditado.value
            : this.valorBcCofinsCreditado,
        valorBcIpiCreditado: valorBcIpiCreditado.present
            ? valorBcIpiCreditado.value
            : this.valorBcIpiCreditado,
        cstCreditoIcms:
            cstCreditoIcms.present ? cstCreditoIcms.value : this.cstCreditoIcms,
        cstCreditoPis:
            cstCreditoPis.present ? cstCreditoPis.value : this.cstCreditoPis,
        cstCreditoCofins: cstCreditoCofins.present
            ? cstCreditoCofins.value
            : this.cstCreditoCofins,
        cstCreditoIpi:
            cstCreditoIpi.present ? cstCreditoIpi.value : this.cstCreditoIpi,
        valorIcmsCreditado: valorIcmsCreditado.present
            ? valorIcmsCreditado.value
            : this.valorIcmsCreditado,
        valorPisCreditado: valorPisCreditado.present
            ? valorPisCreditado.value
            : this.valorPisCreditado,
        valorCofinsCreditado: valorCofinsCreditado.present
            ? valorCofinsCreditado.value
            : this.valorCofinsCreditado,
        valorIpiCreditado: valorIpiCreditado.present
            ? valorIpiCreditado.value
            : this.valorIpiCreditado,
        qtdeParcelaCreditoPis: qtdeParcelaCreditoPis.present
            ? qtdeParcelaCreditoPis.value
            : this.qtdeParcelaCreditoPis,
        qtdeParcelaCreditoCofins: qtdeParcelaCreditoCofins.present
            ? qtdeParcelaCreditoCofins.value
            : this.qtdeParcelaCreditoCofins,
        qtdeParcelaCreditoIcms: qtdeParcelaCreditoIcms.present
            ? qtdeParcelaCreditoIcms.value
            : this.qtdeParcelaCreditoIcms,
        qtdeParcelaCreditoIpi: qtdeParcelaCreditoIpi.present
            ? qtdeParcelaCreditoIpi.value
            : this.qtdeParcelaCreditoIpi,
        aliquotaCreditoIcms: aliquotaCreditoIcms.present
            ? aliquotaCreditoIcms.value
            : this.aliquotaCreditoIcms,
        aliquotaCreditoPis: aliquotaCreditoPis.present
            ? aliquotaCreditoPis.value
            : this.aliquotaCreditoPis,
        aliquotaCreditoCofins: aliquotaCreditoCofins.present
            ? aliquotaCreditoCofins.value
            : this.aliquotaCreditoCofins,
        aliquotaCreditoIpi: aliquotaCreditoIpi.present
            ? aliquotaCreditoIpi.value
            : this.aliquotaCreditoIpi,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalNotaFiscalEntrada(')
          ..write('id: $id, ')
          ..write('idNfeCabecalho: $idNfeCabecalho, ')
          ..write('competencia: $competencia, ')
          ..write('cfopEntrada: $cfopEntrada, ')
          ..write('valorRateioFrete: $valorRateioFrete, ')
          ..write('valorCustoMedio: $valorCustoMedio, ')
          ..write('valorIcmsAntecipado: $valorIcmsAntecipado, ')
          ..write('valorBcIcmsAntecipado: $valorBcIcmsAntecipado, ')
          ..write('valorBcIcmsCreditado: $valorBcIcmsCreditado, ')
          ..write('valorBcPisCreditado: $valorBcPisCreditado, ')
          ..write('valorBcCofinsCreditado: $valorBcCofinsCreditado, ')
          ..write('valorBcIpiCreditado: $valorBcIpiCreditado, ')
          ..write('cstCreditoIcms: $cstCreditoIcms, ')
          ..write('cstCreditoPis: $cstCreditoPis, ')
          ..write('cstCreditoCofins: $cstCreditoCofins, ')
          ..write('cstCreditoIpi: $cstCreditoIpi, ')
          ..write('valorIcmsCreditado: $valorIcmsCreditado, ')
          ..write('valorPisCreditado: $valorPisCreditado, ')
          ..write('valorCofinsCreditado: $valorCofinsCreditado, ')
          ..write('valorIpiCreditado: $valorIpiCreditado, ')
          ..write('qtdeParcelaCreditoPis: $qtdeParcelaCreditoPis, ')
          ..write('qtdeParcelaCreditoCofins: $qtdeParcelaCreditoCofins, ')
          ..write('qtdeParcelaCreditoIcms: $qtdeParcelaCreditoIcms, ')
          ..write('qtdeParcelaCreditoIpi: $qtdeParcelaCreditoIpi, ')
          ..write('aliquotaCreditoIcms: $aliquotaCreditoIcms, ')
          ..write('aliquotaCreditoPis: $aliquotaCreditoPis, ')
          ..write('aliquotaCreditoCofins: $aliquotaCreditoCofins, ')
          ..write('aliquotaCreditoIpi: $aliquotaCreditoIpi')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idNfeCabecalho,
        competencia,
        cfopEntrada,
        valorRateioFrete,
        valorCustoMedio,
        valorIcmsAntecipado,
        valorBcIcmsAntecipado,
        valorBcIcmsCreditado,
        valorBcPisCreditado,
        valorBcCofinsCreditado,
        valorBcIpiCreditado,
        cstCreditoIcms,
        cstCreditoPis,
        cstCreditoCofins,
        cstCreditoIpi,
        valorIcmsCreditado,
        valorPisCreditado,
        valorCofinsCreditado,
        valorIpiCreditado,
        qtdeParcelaCreditoPis,
        qtdeParcelaCreditoCofins,
        qtdeParcelaCreditoIcms,
        qtdeParcelaCreditoIpi,
        aliquotaCreditoIcms,
        aliquotaCreditoPis,
        aliquotaCreditoCofins,
        aliquotaCreditoIpi
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalNotaFiscalEntrada &&
          other.id == this.id &&
          other.idNfeCabecalho == this.idNfeCabecalho &&
          other.competencia == this.competencia &&
          other.cfopEntrada == this.cfopEntrada &&
          other.valorRateioFrete == this.valorRateioFrete &&
          other.valorCustoMedio == this.valorCustoMedio &&
          other.valorIcmsAntecipado == this.valorIcmsAntecipado &&
          other.valorBcIcmsAntecipado == this.valorBcIcmsAntecipado &&
          other.valorBcIcmsCreditado == this.valorBcIcmsCreditado &&
          other.valorBcPisCreditado == this.valorBcPisCreditado &&
          other.valorBcCofinsCreditado == this.valorBcCofinsCreditado &&
          other.valorBcIpiCreditado == this.valorBcIpiCreditado &&
          other.cstCreditoIcms == this.cstCreditoIcms &&
          other.cstCreditoPis == this.cstCreditoPis &&
          other.cstCreditoCofins == this.cstCreditoCofins &&
          other.cstCreditoIpi == this.cstCreditoIpi &&
          other.valorIcmsCreditado == this.valorIcmsCreditado &&
          other.valorPisCreditado == this.valorPisCreditado &&
          other.valorCofinsCreditado == this.valorCofinsCreditado &&
          other.valorIpiCreditado == this.valorIpiCreditado &&
          other.qtdeParcelaCreditoPis == this.qtdeParcelaCreditoPis &&
          other.qtdeParcelaCreditoCofins == this.qtdeParcelaCreditoCofins &&
          other.qtdeParcelaCreditoIcms == this.qtdeParcelaCreditoIcms &&
          other.qtdeParcelaCreditoIpi == this.qtdeParcelaCreditoIpi &&
          other.aliquotaCreditoIcms == this.aliquotaCreditoIcms &&
          other.aliquotaCreditoPis == this.aliquotaCreditoPis &&
          other.aliquotaCreditoCofins == this.aliquotaCreditoCofins &&
          other.aliquotaCreditoIpi == this.aliquotaCreditoIpi);
}

class FiscalNotaFiscalEntradasCompanion
    extends UpdateCompanion<FiscalNotaFiscalEntrada> {
  final Value<int?> id;
  final Value<int?> idNfeCabecalho;
  final Value<String?> competencia;
  final Value<int?> cfopEntrada;
  final Value<double?> valorRateioFrete;
  final Value<double?> valorCustoMedio;
  final Value<double?> valorIcmsAntecipado;
  final Value<double?> valorBcIcmsAntecipado;
  final Value<double?> valorBcIcmsCreditado;
  final Value<double?> valorBcPisCreditado;
  final Value<double?> valorBcCofinsCreditado;
  final Value<double?> valorBcIpiCreditado;
  final Value<String?> cstCreditoIcms;
  final Value<String?> cstCreditoPis;
  final Value<String?> cstCreditoCofins;
  final Value<String?> cstCreditoIpi;
  final Value<double?> valorIcmsCreditado;
  final Value<double?> valorPisCreditado;
  final Value<double?> valorCofinsCreditado;
  final Value<double?> valorIpiCreditado;
  final Value<int?> qtdeParcelaCreditoPis;
  final Value<int?> qtdeParcelaCreditoCofins;
  final Value<int?> qtdeParcelaCreditoIcms;
  final Value<int?> qtdeParcelaCreditoIpi;
  final Value<double?> aliquotaCreditoIcms;
  final Value<double?> aliquotaCreditoPis;
  final Value<double?> aliquotaCreditoCofins;
  final Value<double?> aliquotaCreditoIpi;
  const FiscalNotaFiscalEntradasCompanion({
    this.id = const Value.absent(),
    this.idNfeCabecalho = const Value.absent(),
    this.competencia = const Value.absent(),
    this.cfopEntrada = const Value.absent(),
    this.valorRateioFrete = const Value.absent(),
    this.valorCustoMedio = const Value.absent(),
    this.valorIcmsAntecipado = const Value.absent(),
    this.valorBcIcmsAntecipado = const Value.absent(),
    this.valorBcIcmsCreditado = const Value.absent(),
    this.valorBcPisCreditado = const Value.absent(),
    this.valorBcCofinsCreditado = const Value.absent(),
    this.valorBcIpiCreditado = const Value.absent(),
    this.cstCreditoIcms = const Value.absent(),
    this.cstCreditoPis = const Value.absent(),
    this.cstCreditoCofins = const Value.absent(),
    this.cstCreditoIpi = const Value.absent(),
    this.valorIcmsCreditado = const Value.absent(),
    this.valorPisCreditado = const Value.absent(),
    this.valorCofinsCreditado = const Value.absent(),
    this.valorIpiCreditado = const Value.absent(),
    this.qtdeParcelaCreditoPis = const Value.absent(),
    this.qtdeParcelaCreditoCofins = const Value.absent(),
    this.qtdeParcelaCreditoIcms = const Value.absent(),
    this.qtdeParcelaCreditoIpi = const Value.absent(),
    this.aliquotaCreditoIcms = const Value.absent(),
    this.aliquotaCreditoPis = const Value.absent(),
    this.aliquotaCreditoCofins = const Value.absent(),
    this.aliquotaCreditoIpi = const Value.absent(),
  });
  FiscalNotaFiscalEntradasCompanion.insert({
    this.id = const Value.absent(),
    this.idNfeCabecalho = const Value.absent(),
    this.competencia = const Value.absent(),
    this.cfopEntrada = const Value.absent(),
    this.valorRateioFrete = const Value.absent(),
    this.valorCustoMedio = const Value.absent(),
    this.valorIcmsAntecipado = const Value.absent(),
    this.valorBcIcmsAntecipado = const Value.absent(),
    this.valorBcIcmsCreditado = const Value.absent(),
    this.valorBcPisCreditado = const Value.absent(),
    this.valorBcCofinsCreditado = const Value.absent(),
    this.valorBcIpiCreditado = const Value.absent(),
    this.cstCreditoIcms = const Value.absent(),
    this.cstCreditoPis = const Value.absent(),
    this.cstCreditoCofins = const Value.absent(),
    this.cstCreditoIpi = const Value.absent(),
    this.valorIcmsCreditado = const Value.absent(),
    this.valorPisCreditado = const Value.absent(),
    this.valorCofinsCreditado = const Value.absent(),
    this.valorIpiCreditado = const Value.absent(),
    this.qtdeParcelaCreditoPis = const Value.absent(),
    this.qtdeParcelaCreditoCofins = const Value.absent(),
    this.qtdeParcelaCreditoIcms = const Value.absent(),
    this.qtdeParcelaCreditoIpi = const Value.absent(),
    this.aliquotaCreditoIcms = const Value.absent(),
    this.aliquotaCreditoPis = const Value.absent(),
    this.aliquotaCreditoCofins = const Value.absent(),
    this.aliquotaCreditoIpi = const Value.absent(),
  });
  static Insertable<FiscalNotaFiscalEntrada> custom({
    Expression<int>? id,
    Expression<int>? idNfeCabecalho,
    Expression<String>? competencia,
    Expression<int>? cfopEntrada,
    Expression<double>? valorRateioFrete,
    Expression<double>? valorCustoMedio,
    Expression<double>? valorIcmsAntecipado,
    Expression<double>? valorBcIcmsAntecipado,
    Expression<double>? valorBcIcmsCreditado,
    Expression<double>? valorBcPisCreditado,
    Expression<double>? valorBcCofinsCreditado,
    Expression<double>? valorBcIpiCreditado,
    Expression<String>? cstCreditoIcms,
    Expression<String>? cstCreditoPis,
    Expression<String>? cstCreditoCofins,
    Expression<String>? cstCreditoIpi,
    Expression<double>? valorIcmsCreditado,
    Expression<double>? valorPisCreditado,
    Expression<double>? valorCofinsCreditado,
    Expression<double>? valorIpiCreditado,
    Expression<int>? qtdeParcelaCreditoPis,
    Expression<int>? qtdeParcelaCreditoCofins,
    Expression<int>? qtdeParcelaCreditoIcms,
    Expression<int>? qtdeParcelaCreditoIpi,
    Expression<double>? aliquotaCreditoIcms,
    Expression<double>? aliquotaCreditoPis,
    Expression<double>? aliquotaCreditoCofins,
    Expression<double>? aliquotaCreditoIpi,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idNfeCabecalho != null) 'id_nfe_cabecalho': idNfeCabecalho,
      if (competencia != null) 'competencia': competencia,
      if (cfopEntrada != null) 'cfop_entrada': cfopEntrada,
      if (valorRateioFrete != null) 'valor_rateio_frete': valorRateioFrete,
      if (valorCustoMedio != null) 'valor_custo_medio': valorCustoMedio,
      if (valorIcmsAntecipado != null)
        'valor_icms_antecipado': valorIcmsAntecipado,
      if (valorBcIcmsAntecipado != null)
        'valor_bc_icms_antecipado': valorBcIcmsAntecipado,
      if (valorBcIcmsCreditado != null)
        'valor_bc_icms_creditado': valorBcIcmsCreditado,
      if (valorBcPisCreditado != null)
        'valor_bc_pis_creditado': valorBcPisCreditado,
      if (valorBcCofinsCreditado != null)
        'valor_bc_cofins_creditado': valorBcCofinsCreditado,
      if (valorBcIpiCreditado != null)
        'valor_bc_ipi_creditado': valorBcIpiCreditado,
      if (cstCreditoIcms != null) 'cst_credito_icms': cstCreditoIcms,
      if (cstCreditoPis != null) 'cst_credito_pis': cstCreditoPis,
      if (cstCreditoCofins != null) 'cst_credito_cofins': cstCreditoCofins,
      if (cstCreditoIpi != null) 'cst_credito_ipi': cstCreditoIpi,
      if (valorIcmsCreditado != null)
        'valor_icms_creditado': valorIcmsCreditado,
      if (valorPisCreditado != null) 'valor_pis_creditado': valorPisCreditado,
      if (valorCofinsCreditado != null)
        'valor_cofins_creditado': valorCofinsCreditado,
      if (valorIpiCreditado != null) 'valor_ipi_creditado': valorIpiCreditado,
      if (qtdeParcelaCreditoPis != null)
        'qtde_parcela_credito_pis': qtdeParcelaCreditoPis,
      if (qtdeParcelaCreditoCofins != null)
        'qtde_parcela_credito_cofins': qtdeParcelaCreditoCofins,
      if (qtdeParcelaCreditoIcms != null)
        'qtde_parcela_credito_icms': qtdeParcelaCreditoIcms,
      if (qtdeParcelaCreditoIpi != null)
        'qtde_parcela_credito_ipi': qtdeParcelaCreditoIpi,
      if (aliquotaCreditoIcms != null)
        'aliquota_credito_icms': aliquotaCreditoIcms,
      if (aliquotaCreditoPis != null)
        'aliquota_credito_pis': aliquotaCreditoPis,
      if (aliquotaCreditoCofins != null)
        'aliquota_credito_cofins': aliquotaCreditoCofins,
      if (aliquotaCreditoIpi != null)
        'aliquota_credito_ipi': aliquotaCreditoIpi,
    });
  }

  FiscalNotaFiscalEntradasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idNfeCabecalho,
      Value<String?>? competencia,
      Value<int?>? cfopEntrada,
      Value<double?>? valorRateioFrete,
      Value<double?>? valorCustoMedio,
      Value<double?>? valorIcmsAntecipado,
      Value<double?>? valorBcIcmsAntecipado,
      Value<double?>? valorBcIcmsCreditado,
      Value<double?>? valorBcPisCreditado,
      Value<double?>? valorBcCofinsCreditado,
      Value<double?>? valorBcIpiCreditado,
      Value<String?>? cstCreditoIcms,
      Value<String?>? cstCreditoPis,
      Value<String?>? cstCreditoCofins,
      Value<String?>? cstCreditoIpi,
      Value<double?>? valorIcmsCreditado,
      Value<double?>? valorPisCreditado,
      Value<double?>? valorCofinsCreditado,
      Value<double?>? valorIpiCreditado,
      Value<int?>? qtdeParcelaCreditoPis,
      Value<int?>? qtdeParcelaCreditoCofins,
      Value<int?>? qtdeParcelaCreditoIcms,
      Value<int?>? qtdeParcelaCreditoIpi,
      Value<double?>? aliquotaCreditoIcms,
      Value<double?>? aliquotaCreditoPis,
      Value<double?>? aliquotaCreditoCofins,
      Value<double?>? aliquotaCreditoIpi}) {
    return FiscalNotaFiscalEntradasCompanion(
      id: id ?? this.id,
      idNfeCabecalho: idNfeCabecalho ?? this.idNfeCabecalho,
      competencia: competencia ?? this.competencia,
      cfopEntrada: cfopEntrada ?? this.cfopEntrada,
      valorRateioFrete: valorRateioFrete ?? this.valorRateioFrete,
      valorCustoMedio: valorCustoMedio ?? this.valorCustoMedio,
      valorIcmsAntecipado: valorIcmsAntecipado ?? this.valorIcmsAntecipado,
      valorBcIcmsAntecipado:
          valorBcIcmsAntecipado ?? this.valorBcIcmsAntecipado,
      valorBcIcmsCreditado: valorBcIcmsCreditado ?? this.valorBcIcmsCreditado,
      valorBcPisCreditado: valorBcPisCreditado ?? this.valorBcPisCreditado,
      valorBcCofinsCreditado:
          valorBcCofinsCreditado ?? this.valorBcCofinsCreditado,
      valorBcIpiCreditado: valorBcIpiCreditado ?? this.valorBcIpiCreditado,
      cstCreditoIcms: cstCreditoIcms ?? this.cstCreditoIcms,
      cstCreditoPis: cstCreditoPis ?? this.cstCreditoPis,
      cstCreditoCofins: cstCreditoCofins ?? this.cstCreditoCofins,
      cstCreditoIpi: cstCreditoIpi ?? this.cstCreditoIpi,
      valorIcmsCreditado: valorIcmsCreditado ?? this.valorIcmsCreditado,
      valorPisCreditado: valorPisCreditado ?? this.valorPisCreditado,
      valorCofinsCreditado: valorCofinsCreditado ?? this.valorCofinsCreditado,
      valorIpiCreditado: valorIpiCreditado ?? this.valorIpiCreditado,
      qtdeParcelaCreditoPis:
          qtdeParcelaCreditoPis ?? this.qtdeParcelaCreditoPis,
      qtdeParcelaCreditoCofins:
          qtdeParcelaCreditoCofins ?? this.qtdeParcelaCreditoCofins,
      qtdeParcelaCreditoIcms:
          qtdeParcelaCreditoIcms ?? this.qtdeParcelaCreditoIcms,
      qtdeParcelaCreditoIpi:
          qtdeParcelaCreditoIpi ?? this.qtdeParcelaCreditoIpi,
      aliquotaCreditoIcms: aliquotaCreditoIcms ?? this.aliquotaCreditoIcms,
      aliquotaCreditoPis: aliquotaCreditoPis ?? this.aliquotaCreditoPis,
      aliquotaCreditoCofins:
          aliquotaCreditoCofins ?? this.aliquotaCreditoCofins,
      aliquotaCreditoIpi: aliquotaCreditoIpi ?? this.aliquotaCreditoIpi,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idNfeCabecalho.present) {
      map['id_nfe_cabecalho'] = Variable<int>(idNfeCabecalho.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (cfopEntrada.present) {
      map['cfop_entrada'] = Variable<int>(cfopEntrada.value);
    }
    if (valorRateioFrete.present) {
      map['valor_rateio_frete'] = Variable<double>(valorRateioFrete.value);
    }
    if (valorCustoMedio.present) {
      map['valor_custo_medio'] = Variable<double>(valorCustoMedio.value);
    }
    if (valorIcmsAntecipado.present) {
      map['valor_icms_antecipado'] =
          Variable<double>(valorIcmsAntecipado.value);
    }
    if (valorBcIcmsAntecipado.present) {
      map['valor_bc_icms_antecipado'] =
          Variable<double>(valorBcIcmsAntecipado.value);
    }
    if (valorBcIcmsCreditado.present) {
      map['valor_bc_icms_creditado'] =
          Variable<double>(valorBcIcmsCreditado.value);
    }
    if (valorBcPisCreditado.present) {
      map['valor_bc_pis_creditado'] =
          Variable<double>(valorBcPisCreditado.value);
    }
    if (valorBcCofinsCreditado.present) {
      map['valor_bc_cofins_creditado'] =
          Variable<double>(valorBcCofinsCreditado.value);
    }
    if (valorBcIpiCreditado.present) {
      map['valor_bc_ipi_creditado'] =
          Variable<double>(valorBcIpiCreditado.value);
    }
    if (cstCreditoIcms.present) {
      map['cst_credito_icms'] = Variable<String>(cstCreditoIcms.value);
    }
    if (cstCreditoPis.present) {
      map['cst_credito_pis'] = Variable<String>(cstCreditoPis.value);
    }
    if (cstCreditoCofins.present) {
      map['cst_credito_cofins'] = Variable<String>(cstCreditoCofins.value);
    }
    if (cstCreditoIpi.present) {
      map['cst_credito_ipi'] = Variable<String>(cstCreditoIpi.value);
    }
    if (valorIcmsCreditado.present) {
      map['valor_icms_creditado'] = Variable<double>(valorIcmsCreditado.value);
    }
    if (valorPisCreditado.present) {
      map['valor_pis_creditado'] = Variable<double>(valorPisCreditado.value);
    }
    if (valorCofinsCreditado.present) {
      map['valor_cofins_creditado'] =
          Variable<double>(valorCofinsCreditado.value);
    }
    if (valorIpiCreditado.present) {
      map['valor_ipi_creditado'] = Variable<double>(valorIpiCreditado.value);
    }
    if (qtdeParcelaCreditoPis.present) {
      map['qtde_parcela_credito_pis'] =
          Variable<int>(qtdeParcelaCreditoPis.value);
    }
    if (qtdeParcelaCreditoCofins.present) {
      map['qtde_parcela_credito_cofins'] =
          Variable<int>(qtdeParcelaCreditoCofins.value);
    }
    if (qtdeParcelaCreditoIcms.present) {
      map['qtde_parcela_credito_icms'] =
          Variable<int>(qtdeParcelaCreditoIcms.value);
    }
    if (qtdeParcelaCreditoIpi.present) {
      map['qtde_parcela_credito_ipi'] =
          Variable<int>(qtdeParcelaCreditoIpi.value);
    }
    if (aliquotaCreditoIcms.present) {
      map['aliquota_credito_icms'] =
          Variable<double>(aliquotaCreditoIcms.value);
    }
    if (aliquotaCreditoPis.present) {
      map['aliquota_credito_pis'] = Variable<double>(aliquotaCreditoPis.value);
    }
    if (aliquotaCreditoCofins.present) {
      map['aliquota_credito_cofins'] =
          Variable<double>(aliquotaCreditoCofins.value);
    }
    if (aliquotaCreditoIpi.present) {
      map['aliquota_credito_ipi'] = Variable<double>(aliquotaCreditoIpi.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalNotaFiscalEntradasCompanion(')
          ..write('id: $id, ')
          ..write('idNfeCabecalho: $idNfeCabecalho, ')
          ..write('competencia: $competencia, ')
          ..write('cfopEntrada: $cfopEntrada, ')
          ..write('valorRateioFrete: $valorRateioFrete, ')
          ..write('valorCustoMedio: $valorCustoMedio, ')
          ..write('valorIcmsAntecipado: $valorIcmsAntecipado, ')
          ..write('valorBcIcmsAntecipado: $valorBcIcmsAntecipado, ')
          ..write('valorBcIcmsCreditado: $valorBcIcmsCreditado, ')
          ..write('valorBcPisCreditado: $valorBcPisCreditado, ')
          ..write('valorBcCofinsCreditado: $valorBcCofinsCreditado, ')
          ..write('valorBcIpiCreditado: $valorBcIpiCreditado, ')
          ..write('cstCreditoIcms: $cstCreditoIcms, ')
          ..write('cstCreditoPis: $cstCreditoPis, ')
          ..write('cstCreditoCofins: $cstCreditoCofins, ')
          ..write('cstCreditoIpi: $cstCreditoIpi, ')
          ..write('valorIcmsCreditado: $valorIcmsCreditado, ')
          ..write('valorPisCreditado: $valorPisCreditado, ')
          ..write('valorCofinsCreditado: $valorCofinsCreditado, ')
          ..write('valorIpiCreditado: $valorIpiCreditado, ')
          ..write('qtdeParcelaCreditoPis: $qtdeParcelaCreditoPis, ')
          ..write('qtdeParcelaCreditoCofins: $qtdeParcelaCreditoCofins, ')
          ..write('qtdeParcelaCreditoIcms: $qtdeParcelaCreditoIcms, ')
          ..write('qtdeParcelaCreditoIpi: $qtdeParcelaCreditoIpi, ')
          ..write('aliquotaCreditoIcms: $aliquotaCreditoIcms, ')
          ..write('aliquotaCreditoPis: $aliquotaCreditoPis, ')
          ..write('aliquotaCreditoCofins: $aliquotaCreditoCofins, ')
          ..write('aliquotaCreditoIpi: $aliquotaCreditoIpi')
          ..write(')'))
        .toString();
  }
}

class $FiscalApuracaoIcmssTable extends FiscalApuracaoIcmss
    with TableInfo<$FiscalApuracaoIcmssTable, FiscalApuracaoIcms> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalApuracaoIcmssTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorTotalDebitoMeta =
      const VerificationMeta('valorTotalDebito');
  @override
  late final GeneratedColumn<double> valorTotalDebito = GeneratedColumn<double>(
      'valor_total_debito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAjusteDebitoMeta =
      const VerificationMeta('valorAjusteDebito');
  @override
  late final GeneratedColumn<double> valorAjusteDebito =
      GeneratedColumn<double>('valor_ajuste_debito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalAjusteDebitoMeta =
      const VerificationMeta('valorTotalAjusteDebito');
  @override
  late final GeneratedColumn<double> valorTotalAjusteDebito =
      GeneratedColumn<double>('valor_total_ajuste_debito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorEstornoCreditoMeta =
      const VerificationMeta('valorEstornoCredito');
  @override
  late final GeneratedColumn<double> valorEstornoCredito =
      GeneratedColumn<double>('valor_estorno_credito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalCreditoMeta =
      const VerificationMeta('valorTotalCredito');
  @override
  late final GeneratedColumn<double> valorTotalCredito =
      GeneratedColumn<double>('valor_total_credito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAjusteCreditoMeta =
      const VerificationMeta('valorAjusteCredito');
  @override
  late final GeneratedColumn<double> valorAjusteCredito =
      GeneratedColumn<double>('valor_ajuste_credito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalAjusteCreditoMeta =
      const VerificationMeta('valorTotalAjusteCredito');
  @override
  late final GeneratedColumn<double> valorTotalAjusteCredito =
      GeneratedColumn<double>('valor_total_ajuste_credito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorEstornoDebitoMeta =
      const VerificationMeta('valorEstornoDebito');
  @override
  late final GeneratedColumn<double> valorEstornoDebito =
      GeneratedColumn<double>('valor_estorno_debito', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSaldoCredorAnteriorMeta =
      const VerificationMeta('valorSaldoCredorAnterior');
  @override
  late final GeneratedColumn<double> valorSaldoCredorAnterior =
      GeneratedColumn<double>('valor_saldo_credor_anterior', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSaldoApuradoMeta =
      const VerificationMeta('valorSaldoApurado');
  @override
  late final GeneratedColumn<double> valorSaldoApurado =
      GeneratedColumn<double>('valor_saldo_apurado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalDeducaoMeta =
      const VerificationMeta('valorTotalDeducao');
  @override
  late final GeneratedColumn<double> valorTotalDeducao =
      GeneratedColumn<double>('valor_total_deducao', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIcmsRecolherMeta =
      const VerificationMeta('valorIcmsRecolher');
  @override
  late final GeneratedColumn<double> valorIcmsRecolher =
      GeneratedColumn<double>('valor_icms_recolher', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSaldoCredorTranspMeta =
      const VerificationMeta('valorSaldoCredorTransp');
  @override
  late final GeneratedColumn<double> valorSaldoCredorTransp =
      GeneratedColumn<double>('valor_saldo_credor_transp', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDebitoEspecialMeta =
      const VerificationMeta('valorDebitoEspecial');
  @override
  late final GeneratedColumn<double> valorDebitoEspecial =
      GeneratedColumn<double>('valor_debito_especial', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        competencia,
        valorTotalDebito,
        valorAjusteDebito,
        valorTotalAjusteDebito,
        valorEstornoCredito,
        valorTotalCredito,
        valorAjusteCredito,
        valorTotalAjusteCredito,
        valorEstornoDebito,
        valorSaldoCredorAnterior,
        valorSaldoApurado,
        valorTotalDeducao,
        valorIcmsRecolher,
        valorSaldoCredorTransp,
        valorDebitoEspecial
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_apuracao_icms';
  @override
  VerificationContext validateIntegrity(Insertable<FiscalApuracaoIcms> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('valor_total_debito')) {
      context.handle(
          _valorTotalDebitoMeta,
          valorTotalDebito.isAcceptableOrUnknown(
              data['valor_total_debito']!, _valorTotalDebitoMeta));
    }
    if (data.containsKey('valor_ajuste_debito')) {
      context.handle(
          _valorAjusteDebitoMeta,
          valorAjusteDebito.isAcceptableOrUnknown(
              data['valor_ajuste_debito']!, _valorAjusteDebitoMeta));
    }
    if (data.containsKey('valor_total_ajuste_debito')) {
      context.handle(
          _valorTotalAjusteDebitoMeta,
          valorTotalAjusteDebito.isAcceptableOrUnknown(
              data['valor_total_ajuste_debito']!, _valorTotalAjusteDebitoMeta));
    }
    if (data.containsKey('valor_estorno_credito')) {
      context.handle(
          _valorEstornoCreditoMeta,
          valorEstornoCredito.isAcceptableOrUnknown(
              data['valor_estorno_credito']!, _valorEstornoCreditoMeta));
    }
    if (data.containsKey('valor_total_credito')) {
      context.handle(
          _valorTotalCreditoMeta,
          valorTotalCredito.isAcceptableOrUnknown(
              data['valor_total_credito']!, _valorTotalCreditoMeta));
    }
    if (data.containsKey('valor_ajuste_credito')) {
      context.handle(
          _valorAjusteCreditoMeta,
          valorAjusteCredito.isAcceptableOrUnknown(
              data['valor_ajuste_credito']!, _valorAjusteCreditoMeta));
    }
    if (data.containsKey('valor_total_ajuste_credito')) {
      context.handle(
          _valorTotalAjusteCreditoMeta,
          valorTotalAjusteCredito.isAcceptableOrUnknown(
              data['valor_total_ajuste_credito']!,
              _valorTotalAjusteCreditoMeta));
    }
    if (data.containsKey('valor_estorno_debito')) {
      context.handle(
          _valorEstornoDebitoMeta,
          valorEstornoDebito.isAcceptableOrUnknown(
              data['valor_estorno_debito']!, _valorEstornoDebitoMeta));
    }
    if (data.containsKey('valor_saldo_credor_anterior')) {
      context.handle(
          _valorSaldoCredorAnteriorMeta,
          valorSaldoCredorAnterior.isAcceptableOrUnknown(
              data['valor_saldo_credor_anterior']!,
              _valorSaldoCredorAnteriorMeta));
    }
    if (data.containsKey('valor_saldo_apurado')) {
      context.handle(
          _valorSaldoApuradoMeta,
          valorSaldoApurado.isAcceptableOrUnknown(
              data['valor_saldo_apurado']!, _valorSaldoApuradoMeta));
    }
    if (data.containsKey('valor_total_deducao')) {
      context.handle(
          _valorTotalDeducaoMeta,
          valorTotalDeducao.isAcceptableOrUnknown(
              data['valor_total_deducao']!, _valorTotalDeducaoMeta));
    }
    if (data.containsKey('valor_icms_recolher')) {
      context.handle(
          _valorIcmsRecolherMeta,
          valorIcmsRecolher.isAcceptableOrUnknown(
              data['valor_icms_recolher']!, _valorIcmsRecolherMeta));
    }
    if (data.containsKey('valor_saldo_credor_transp')) {
      context.handle(
          _valorSaldoCredorTranspMeta,
          valorSaldoCredorTransp.isAcceptableOrUnknown(
              data['valor_saldo_credor_transp']!, _valorSaldoCredorTranspMeta));
    }
    if (data.containsKey('valor_debito_especial')) {
      context.handle(
          _valorDebitoEspecialMeta,
          valorDebitoEspecial.isAcceptableOrUnknown(
              data['valor_debito_especial']!, _valorDebitoEspecialMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalApuracaoIcms map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalApuracaoIcms(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      valorTotalDebito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_debito']),
      valorAjusteDebito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_ajuste_debito']),
      valorTotalAjusteDebito: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_total_ajuste_debito']),
      valorEstornoCredito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_estorno_credito']),
      valorTotalCredito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_credito']),
      valorAjusteCredito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_ajuste_credito']),
      valorTotalAjusteCredito: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_total_ajuste_credito']),
      valorEstornoDebito: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_estorno_debito']),
      valorSaldoCredorAnterior: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_saldo_credor_anterior']),
      valorSaldoApurado: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_saldo_apurado']),
      valorTotalDeducao: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_total_deducao']),
      valorIcmsRecolher: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_icms_recolher']),
      valorSaldoCredorTransp: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_saldo_credor_transp']),
      valorDebitoEspecial: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_debito_especial']),
    );
  }

  @override
  $FiscalApuracaoIcmssTable createAlias(String alias) {
    return $FiscalApuracaoIcmssTable(attachedDatabase, alias);
  }
}

class FiscalApuracaoIcms extends DataClass
    implements Insertable<FiscalApuracaoIcms> {
  final int? id;
  final String? competencia;
  final double? valorTotalDebito;
  final double? valorAjusteDebito;
  final double? valorTotalAjusteDebito;
  final double? valorEstornoCredito;
  final double? valorTotalCredito;
  final double? valorAjusteCredito;
  final double? valorTotalAjusteCredito;
  final double? valorEstornoDebito;
  final double? valorSaldoCredorAnterior;
  final double? valorSaldoApurado;
  final double? valorTotalDeducao;
  final double? valorIcmsRecolher;
  final double? valorSaldoCredorTransp;
  final double? valorDebitoEspecial;
  const FiscalApuracaoIcms(
      {this.id,
      this.competencia,
      this.valorTotalDebito,
      this.valorAjusteDebito,
      this.valorTotalAjusteDebito,
      this.valorEstornoCredito,
      this.valorTotalCredito,
      this.valorAjusteCredito,
      this.valorTotalAjusteCredito,
      this.valorEstornoDebito,
      this.valorSaldoCredorAnterior,
      this.valorSaldoApurado,
      this.valorTotalDeducao,
      this.valorIcmsRecolher,
      this.valorSaldoCredorTransp,
      this.valorDebitoEspecial});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || valorTotalDebito != null) {
      map['valor_total_debito'] = Variable<double>(valorTotalDebito);
    }
    if (!nullToAbsent || valorAjusteDebito != null) {
      map['valor_ajuste_debito'] = Variable<double>(valorAjusteDebito);
    }
    if (!nullToAbsent || valorTotalAjusteDebito != null) {
      map['valor_total_ajuste_debito'] =
          Variable<double>(valorTotalAjusteDebito);
    }
    if (!nullToAbsent || valorEstornoCredito != null) {
      map['valor_estorno_credito'] = Variable<double>(valorEstornoCredito);
    }
    if (!nullToAbsent || valorTotalCredito != null) {
      map['valor_total_credito'] = Variable<double>(valorTotalCredito);
    }
    if (!nullToAbsent || valorAjusteCredito != null) {
      map['valor_ajuste_credito'] = Variable<double>(valorAjusteCredito);
    }
    if (!nullToAbsent || valorTotalAjusteCredito != null) {
      map['valor_total_ajuste_credito'] =
          Variable<double>(valorTotalAjusteCredito);
    }
    if (!nullToAbsent || valorEstornoDebito != null) {
      map['valor_estorno_debito'] = Variable<double>(valorEstornoDebito);
    }
    if (!nullToAbsent || valorSaldoCredorAnterior != null) {
      map['valor_saldo_credor_anterior'] =
          Variable<double>(valorSaldoCredorAnterior);
    }
    if (!nullToAbsent || valorSaldoApurado != null) {
      map['valor_saldo_apurado'] = Variable<double>(valorSaldoApurado);
    }
    if (!nullToAbsent || valorTotalDeducao != null) {
      map['valor_total_deducao'] = Variable<double>(valorTotalDeducao);
    }
    if (!nullToAbsent || valorIcmsRecolher != null) {
      map['valor_icms_recolher'] = Variable<double>(valorIcmsRecolher);
    }
    if (!nullToAbsent || valorSaldoCredorTransp != null) {
      map['valor_saldo_credor_transp'] =
          Variable<double>(valorSaldoCredorTransp);
    }
    if (!nullToAbsent || valorDebitoEspecial != null) {
      map['valor_debito_especial'] = Variable<double>(valorDebitoEspecial);
    }
    return map;
  }

  factory FiscalApuracaoIcms.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalApuracaoIcms(
      id: serializer.fromJson<int?>(json['id']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      valorTotalDebito: serializer.fromJson<double?>(json['valorTotalDebito']),
      valorAjusteDebito:
          serializer.fromJson<double?>(json['valorAjusteDebito']),
      valorTotalAjusteDebito:
          serializer.fromJson<double?>(json['valorTotalAjusteDebito']),
      valorEstornoCredito:
          serializer.fromJson<double?>(json['valorEstornoCredito']),
      valorTotalCredito:
          serializer.fromJson<double?>(json['valorTotalCredito']),
      valorAjusteCredito:
          serializer.fromJson<double?>(json['valorAjusteCredito']),
      valorTotalAjusteCredito:
          serializer.fromJson<double?>(json['valorTotalAjusteCredito']),
      valorEstornoDebito:
          serializer.fromJson<double?>(json['valorEstornoDebito']),
      valorSaldoCredorAnterior:
          serializer.fromJson<double?>(json['valorSaldoCredorAnterior']),
      valorSaldoApurado:
          serializer.fromJson<double?>(json['valorSaldoApurado']),
      valorTotalDeducao:
          serializer.fromJson<double?>(json['valorTotalDeducao']),
      valorIcmsRecolher:
          serializer.fromJson<double?>(json['valorIcmsRecolher']),
      valorSaldoCredorTransp:
          serializer.fromJson<double?>(json['valorSaldoCredorTransp']),
      valorDebitoEspecial:
          serializer.fromJson<double?>(json['valorDebitoEspecial']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'competencia': serializer.toJson<String?>(competencia),
      'valorTotalDebito': serializer.toJson<double?>(valorTotalDebito),
      'valorAjusteDebito': serializer.toJson<double?>(valorAjusteDebito),
      'valorTotalAjusteDebito':
          serializer.toJson<double?>(valorTotalAjusteDebito),
      'valorEstornoCredito': serializer.toJson<double?>(valorEstornoCredito),
      'valorTotalCredito': serializer.toJson<double?>(valorTotalCredito),
      'valorAjusteCredito': serializer.toJson<double?>(valorAjusteCredito),
      'valorTotalAjusteCredito':
          serializer.toJson<double?>(valorTotalAjusteCredito),
      'valorEstornoDebito': serializer.toJson<double?>(valorEstornoDebito),
      'valorSaldoCredorAnterior':
          serializer.toJson<double?>(valorSaldoCredorAnterior),
      'valorSaldoApurado': serializer.toJson<double?>(valorSaldoApurado),
      'valorTotalDeducao': serializer.toJson<double?>(valorTotalDeducao),
      'valorIcmsRecolher': serializer.toJson<double?>(valorIcmsRecolher),
      'valorSaldoCredorTransp':
          serializer.toJson<double?>(valorSaldoCredorTransp),
      'valorDebitoEspecial': serializer.toJson<double?>(valorDebitoEspecial),
    };
  }

  FiscalApuracaoIcms copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<double?> valorTotalDebito = const Value.absent(),
          Value<double?> valorAjusteDebito = const Value.absent(),
          Value<double?> valorTotalAjusteDebito = const Value.absent(),
          Value<double?> valorEstornoCredito = const Value.absent(),
          Value<double?> valorTotalCredito = const Value.absent(),
          Value<double?> valorAjusteCredito = const Value.absent(),
          Value<double?> valorTotalAjusteCredito = const Value.absent(),
          Value<double?> valorEstornoDebito = const Value.absent(),
          Value<double?> valorSaldoCredorAnterior = const Value.absent(),
          Value<double?> valorSaldoApurado = const Value.absent(),
          Value<double?> valorTotalDeducao = const Value.absent(),
          Value<double?> valorIcmsRecolher = const Value.absent(),
          Value<double?> valorSaldoCredorTransp = const Value.absent(),
          Value<double?> valorDebitoEspecial = const Value.absent()}) =>
      FiscalApuracaoIcms(
        id: id.present ? id.value : this.id,
        competencia: competencia.present ? competencia.value : this.competencia,
        valorTotalDebito: valorTotalDebito.present
            ? valorTotalDebito.value
            : this.valorTotalDebito,
        valorAjusteDebito: valorAjusteDebito.present
            ? valorAjusteDebito.value
            : this.valorAjusteDebito,
        valorTotalAjusteDebito: valorTotalAjusteDebito.present
            ? valorTotalAjusteDebito.value
            : this.valorTotalAjusteDebito,
        valorEstornoCredito: valorEstornoCredito.present
            ? valorEstornoCredito.value
            : this.valorEstornoCredito,
        valorTotalCredito: valorTotalCredito.present
            ? valorTotalCredito.value
            : this.valorTotalCredito,
        valorAjusteCredito: valorAjusteCredito.present
            ? valorAjusteCredito.value
            : this.valorAjusteCredito,
        valorTotalAjusteCredito: valorTotalAjusteCredito.present
            ? valorTotalAjusteCredito.value
            : this.valorTotalAjusteCredito,
        valorEstornoDebito: valorEstornoDebito.present
            ? valorEstornoDebito.value
            : this.valorEstornoDebito,
        valorSaldoCredorAnterior: valorSaldoCredorAnterior.present
            ? valorSaldoCredorAnterior.value
            : this.valorSaldoCredorAnterior,
        valorSaldoApurado: valorSaldoApurado.present
            ? valorSaldoApurado.value
            : this.valorSaldoApurado,
        valorTotalDeducao: valorTotalDeducao.present
            ? valorTotalDeducao.value
            : this.valorTotalDeducao,
        valorIcmsRecolher: valorIcmsRecolher.present
            ? valorIcmsRecolher.value
            : this.valorIcmsRecolher,
        valorSaldoCredorTransp: valorSaldoCredorTransp.present
            ? valorSaldoCredorTransp.value
            : this.valorSaldoCredorTransp,
        valorDebitoEspecial: valorDebitoEspecial.present
            ? valorDebitoEspecial.value
            : this.valorDebitoEspecial,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalApuracaoIcms(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('valorTotalDebito: $valorTotalDebito, ')
          ..write('valorAjusteDebito: $valorAjusteDebito, ')
          ..write('valorTotalAjusteDebito: $valorTotalAjusteDebito, ')
          ..write('valorEstornoCredito: $valorEstornoCredito, ')
          ..write('valorTotalCredito: $valorTotalCredito, ')
          ..write('valorAjusteCredito: $valorAjusteCredito, ')
          ..write('valorTotalAjusteCredito: $valorTotalAjusteCredito, ')
          ..write('valorEstornoDebito: $valorEstornoDebito, ')
          ..write('valorSaldoCredorAnterior: $valorSaldoCredorAnterior, ')
          ..write('valorSaldoApurado: $valorSaldoApurado, ')
          ..write('valorTotalDeducao: $valorTotalDeducao, ')
          ..write('valorIcmsRecolher: $valorIcmsRecolher, ')
          ..write('valorSaldoCredorTransp: $valorSaldoCredorTransp, ')
          ..write('valorDebitoEspecial: $valorDebitoEspecial')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      competencia,
      valorTotalDebito,
      valorAjusteDebito,
      valorTotalAjusteDebito,
      valorEstornoCredito,
      valorTotalCredito,
      valorAjusteCredito,
      valorTotalAjusteCredito,
      valorEstornoDebito,
      valorSaldoCredorAnterior,
      valorSaldoApurado,
      valorTotalDeducao,
      valorIcmsRecolher,
      valorSaldoCredorTransp,
      valorDebitoEspecial);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalApuracaoIcms &&
          other.id == this.id &&
          other.competencia == this.competencia &&
          other.valorTotalDebito == this.valorTotalDebito &&
          other.valorAjusteDebito == this.valorAjusteDebito &&
          other.valorTotalAjusteDebito == this.valorTotalAjusteDebito &&
          other.valorEstornoCredito == this.valorEstornoCredito &&
          other.valorTotalCredito == this.valorTotalCredito &&
          other.valorAjusteCredito == this.valorAjusteCredito &&
          other.valorTotalAjusteCredito == this.valorTotalAjusteCredito &&
          other.valorEstornoDebito == this.valorEstornoDebito &&
          other.valorSaldoCredorAnterior == this.valorSaldoCredorAnterior &&
          other.valorSaldoApurado == this.valorSaldoApurado &&
          other.valorTotalDeducao == this.valorTotalDeducao &&
          other.valorIcmsRecolher == this.valorIcmsRecolher &&
          other.valorSaldoCredorTransp == this.valorSaldoCredorTransp &&
          other.valorDebitoEspecial == this.valorDebitoEspecial);
}

class FiscalApuracaoIcmssCompanion extends UpdateCompanion<FiscalApuracaoIcms> {
  final Value<int?> id;
  final Value<String?> competencia;
  final Value<double?> valorTotalDebito;
  final Value<double?> valorAjusteDebito;
  final Value<double?> valorTotalAjusteDebito;
  final Value<double?> valorEstornoCredito;
  final Value<double?> valorTotalCredito;
  final Value<double?> valorAjusteCredito;
  final Value<double?> valorTotalAjusteCredito;
  final Value<double?> valorEstornoDebito;
  final Value<double?> valorSaldoCredorAnterior;
  final Value<double?> valorSaldoApurado;
  final Value<double?> valorTotalDeducao;
  final Value<double?> valorIcmsRecolher;
  final Value<double?> valorSaldoCredorTransp;
  final Value<double?> valorDebitoEspecial;
  const FiscalApuracaoIcmssCompanion({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.valorTotalDebito = const Value.absent(),
    this.valorAjusteDebito = const Value.absent(),
    this.valorTotalAjusteDebito = const Value.absent(),
    this.valorEstornoCredito = const Value.absent(),
    this.valorTotalCredito = const Value.absent(),
    this.valorAjusteCredito = const Value.absent(),
    this.valorTotalAjusteCredito = const Value.absent(),
    this.valorEstornoDebito = const Value.absent(),
    this.valorSaldoCredorAnterior = const Value.absent(),
    this.valorSaldoApurado = const Value.absent(),
    this.valorTotalDeducao = const Value.absent(),
    this.valorIcmsRecolher = const Value.absent(),
    this.valorSaldoCredorTransp = const Value.absent(),
    this.valorDebitoEspecial = const Value.absent(),
  });
  FiscalApuracaoIcmssCompanion.insert({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.valorTotalDebito = const Value.absent(),
    this.valorAjusteDebito = const Value.absent(),
    this.valorTotalAjusteDebito = const Value.absent(),
    this.valorEstornoCredito = const Value.absent(),
    this.valorTotalCredito = const Value.absent(),
    this.valorAjusteCredito = const Value.absent(),
    this.valorTotalAjusteCredito = const Value.absent(),
    this.valorEstornoDebito = const Value.absent(),
    this.valorSaldoCredorAnterior = const Value.absent(),
    this.valorSaldoApurado = const Value.absent(),
    this.valorTotalDeducao = const Value.absent(),
    this.valorIcmsRecolher = const Value.absent(),
    this.valorSaldoCredorTransp = const Value.absent(),
    this.valorDebitoEspecial = const Value.absent(),
  });
  static Insertable<FiscalApuracaoIcms> custom({
    Expression<int>? id,
    Expression<String>? competencia,
    Expression<double>? valorTotalDebito,
    Expression<double>? valorAjusteDebito,
    Expression<double>? valorTotalAjusteDebito,
    Expression<double>? valorEstornoCredito,
    Expression<double>? valorTotalCredito,
    Expression<double>? valorAjusteCredito,
    Expression<double>? valorTotalAjusteCredito,
    Expression<double>? valorEstornoDebito,
    Expression<double>? valorSaldoCredorAnterior,
    Expression<double>? valorSaldoApurado,
    Expression<double>? valorTotalDeducao,
    Expression<double>? valorIcmsRecolher,
    Expression<double>? valorSaldoCredorTransp,
    Expression<double>? valorDebitoEspecial,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (competencia != null) 'competencia': competencia,
      if (valorTotalDebito != null) 'valor_total_debito': valorTotalDebito,
      if (valorAjusteDebito != null) 'valor_ajuste_debito': valorAjusteDebito,
      if (valorTotalAjusteDebito != null)
        'valor_total_ajuste_debito': valorTotalAjusteDebito,
      if (valorEstornoCredito != null)
        'valor_estorno_credito': valorEstornoCredito,
      if (valorTotalCredito != null) 'valor_total_credito': valorTotalCredito,
      if (valorAjusteCredito != null)
        'valor_ajuste_credito': valorAjusteCredito,
      if (valorTotalAjusteCredito != null)
        'valor_total_ajuste_credito': valorTotalAjusteCredito,
      if (valorEstornoDebito != null)
        'valor_estorno_debito': valorEstornoDebito,
      if (valorSaldoCredorAnterior != null)
        'valor_saldo_credor_anterior': valorSaldoCredorAnterior,
      if (valorSaldoApurado != null) 'valor_saldo_apurado': valorSaldoApurado,
      if (valorTotalDeducao != null) 'valor_total_deducao': valorTotalDeducao,
      if (valorIcmsRecolher != null) 'valor_icms_recolher': valorIcmsRecolher,
      if (valorSaldoCredorTransp != null)
        'valor_saldo_credor_transp': valorSaldoCredorTransp,
      if (valorDebitoEspecial != null)
        'valor_debito_especial': valorDebitoEspecial,
    });
  }

  FiscalApuracaoIcmssCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? competencia,
      Value<double?>? valorTotalDebito,
      Value<double?>? valorAjusteDebito,
      Value<double?>? valorTotalAjusteDebito,
      Value<double?>? valorEstornoCredito,
      Value<double?>? valorTotalCredito,
      Value<double?>? valorAjusteCredito,
      Value<double?>? valorTotalAjusteCredito,
      Value<double?>? valorEstornoDebito,
      Value<double?>? valorSaldoCredorAnterior,
      Value<double?>? valorSaldoApurado,
      Value<double?>? valorTotalDeducao,
      Value<double?>? valorIcmsRecolher,
      Value<double?>? valorSaldoCredorTransp,
      Value<double?>? valorDebitoEspecial}) {
    return FiscalApuracaoIcmssCompanion(
      id: id ?? this.id,
      competencia: competencia ?? this.competencia,
      valorTotalDebito: valorTotalDebito ?? this.valorTotalDebito,
      valorAjusteDebito: valorAjusteDebito ?? this.valorAjusteDebito,
      valorTotalAjusteDebito:
          valorTotalAjusteDebito ?? this.valorTotalAjusteDebito,
      valorEstornoCredito: valorEstornoCredito ?? this.valorEstornoCredito,
      valorTotalCredito: valorTotalCredito ?? this.valorTotalCredito,
      valorAjusteCredito: valorAjusteCredito ?? this.valorAjusteCredito,
      valorTotalAjusteCredito:
          valorTotalAjusteCredito ?? this.valorTotalAjusteCredito,
      valorEstornoDebito: valorEstornoDebito ?? this.valorEstornoDebito,
      valorSaldoCredorAnterior:
          valorSaldoCredorAnterior ?? this.valorSaldoCredorAnterior,
      valorSaldoApurado: valorSaldoApurado ?? this.valorSaldoApurado,
      valorTotalDeducao: valorTotalDeducao ?? this.valorTotalDeducao,
      valorIcmsRecolher: valorIcmsRecolher ?? this.valorIcmsRecolher,
      valorSaldoCredorTransp:
          valorSaldoCredorTransp ?? this.valorSaldoCredorTransp,
      valorDebitoEspecial: valorDebitoEspecial ?? this.valorDebitoEspecial,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (valorTotalDebito.present) {
      map['valor_total_debito'] = Variable<double>(valorTotalDebito.value);
    }
    if (valorAjusteDebito.present) {
      map['valor_ajuste_debito'] = Variable<double>(valorAjusteDebito.value);
    }
    if (valorTotalAjusteDebito.present) {
      map['valor_total_ajuste_debito'] =
          Variable<double>(valorTotalAjusteDebito.value);
    }
    if (valorEstornoCredito.present) {
      map['valor_estorno_credito'] =
          Variable<double>(valorEstornoCredito.value);
    }
    if (valorTotalCredito.present) {
      map['valor_total_credito'] = Variable<double>(valorTotalCredito.value);
    }
    if (valorAjusteCredito.present) {
      map['valor_ajuste_credito'] = Variable<double>(valorAjusteCredito.value);
    }
    if (valorTotalAjusteCredito.present) {
      map['valor_total_ajuste_credito'] =
          Variable<double>(valorTotalAjusteCredito.value);
    }
    if (valorEstornoDebito.present) {
      map['valor_estorno_debito'] = Variable<double>(valorEstornoDebito.value);
    }
    if (valorSaldoCredorAnterior.present) {
      map['valor_saldo_credor_anterior'] =
          Variable<double>(valorSaldoCredorAnterior.value);
    }
    if (valorSaldoApurado.present) {
      map['valor_saldo_apurado'] = Variable<double>(valorSaldoApurado.value);
    }
    if (valorTotalDeducao.present) {
      map['valor_total_deducao'] = Variable<double>(valorTotalDeducao.value);
    }
    if (valorIcmsRecolher.present) {
      map['valor_icms_recolher'] = Variable<double>(valorIcmsRecolher.value);
    }
    if (valorSaldoCredorTransp.present) {
      map['valor_saldo_credor_transp'] =
          Variable<double>(valorSaldoCredorTransp.value);
    }
    if (valorDebitoEspecial.present) {
      map['valor_debito_especial'] =
          Variable<double>(valorDebitoEspecial.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalApuracaoIcmssCompanion(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('valorTotalDebito: $valorTotalDebito, ')
          ..write('valorAjusteDebito: $valorAjusteDebito, ')
          ..write('valorTotalAjusteDebito: $valorTotalAjusteDebito, ')
          ..write('valorEstornoCredito: $valorEstornoCredito, ')
          ..write('valorTotalCredito: $valorTotalCredito, ')
          ..write('valorAjusteCredito: $valorAjusteCredito, ')
          ..write('valorTotalAjusteCredito: $valorTotalAjusteCredito, ')
          ..write('valorEstornoDebito: $valorEstornoDebito, ')
          ..write('valorSaldoCredorAnterior: $valorSaldoCredorAnterior, ')
          ..write('valorSaldoApurado: $valorSaldoApurado, ')
          ..write('valorTotalDeducao: $valorTotalDeducao, ')
          ..write('valorIcmsRecolher: $valorIcmsRecolher, ')
          ..write('valorSaldoCredorTransp: $valorSaldoCredorTransp, ')
          ..write('valorDebitoEspecial: $valorDebitoEspecial')
          ..write(')'))
        .toString();
  }
}

class $FiscalNotaFiscalSaidasTable extends FiscalNotaFiscalSaidas
    with TableInfo<$FiscalNotaFiscalSaidasTable, FiscalNotaFiscalSaida> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FiscalNotaFiscalSaidasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfeCabecalhoMeta =
      const VerificationMeta('idNfeCabecalho');
  @override
  late final GeneratedColumn<int> idNfeCabecalho = GeneratedColumn<int>(
      'id_nfe_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idNfeCabecalho, competencia];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fiscal_nota_fiscal_saida';
  @override
  VerificationContext validateIntegrity(
      Insertable<FiscalNotaFiscalSaida> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_nfe_cabecalho')) {
      context.handle(
          _idNfeCabecalhoMeta,
          idNfeCabecalho.isAcceptableOrUnknown(
              data['id_nfe_cabecalho']!, _idNfeCabecalhoMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FiscalNotaFiscalSaida map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FiscalNotaFiscalSaida(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idNfeCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nfe_cabecalho']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
    );
  }

  @override
  $FiscalNotaFiscalSaidasTable createAlias(String alias) {
    return $FiscalNotaFiscalSaidasTable(attachedDatabase, alias);
  }
}

class FiscalNotaFiscalSaida extends DataClass
    implements Insertable<FiscalNotaFiscalSaida> {
  final int? id;
  final int? idNfeCabecalho;
  final String? competencia;
  const FiscalNotaFiscalSaida({this.id, this.idNfeCabecalho, this.competencia});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idNfeCabecalho != null) {
      map['id_nfe_cabecalho'] = Variable<int>(idNfeCabecalho);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    return map;
  }

  factory FiscalNotaFiscalSaida.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FiscalNotaFiscalSaida(
      id: serializer.fromJson<int?>(json['id']),
      idNfeCabecalho: serializer.fromJson<int?>(json['idNfeCabecalho']),
      competencia: serializer.fromJson<String?>(json['competencia']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idNfeCabecalho': serializer.toJson<int?>(idNfeCabecalho),
      'competencia': serializer.toJson<String?>(competencia),
    };
  }

  FiscalNotaFiscalSaida copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idNfeCabecalho = const Value.absent(),
          Value<String?> competencia = const Value.absent()}) =>
      FiscalNotaFiscalSaida(
        id: id.present ? id.value : this.id,
        idNfeCabecalho:
            idNfeCabecalho.present ? idNfeCabecalho.value : this.idNfeCabecalho,
        competencia: competencia.present ? competencia.value : this.competencia,
      );
  @override
  String toString() {
    return (StringBuffer('FiscalNotaFiscalSaida(')
          ..write('id: $id, ')
          ..write('idNfeCabecalho: $idNfeCabecalho, ')
          ..write('competencia: $competencia')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idNfeCabecalho, competencia);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FiscalNotaFiscalSaida &&
          other.id == this.id &&
          other.idNfeCabecalho == this.idNfeCabecalho &&
          other.competencia == this.competencia);
}

class FiscalNotaFiscalSaidasCompanion
    extends UpdateCompanion<FiscalNotaFiscalSaida> {
  final Value<int?> id;
  final Value<int?> idNfeCabecalho;
  final Value<String?> competencia;
  const FiscalNotaFiscalSaidasCompanion({
    this.id = const Value.absent(),
    this.idNfeCabecalho = const Value.absent(),
    this.competencia = const Value.absent(),
  });
  FiscalNotaFiscalSaidasCompanion.insert({
    this.id = const Value.absent(),
    this.idNfeCabecalho = const Value.absent(),
    this.competencia = const Value.absent(),
  });
  static Insertable<FiscalNotaFiscalSaida> custom({
    Expression<int>? id,
    Expression<int>? idNfeCabecalho,
    Expression<String>? competencia,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idNfeCabecalho != null) 'id_nfe_cabecalho': idNfeCabecalho,
      if (competencia != null) 'competencia': competencia,
    });
  }

  FiscalNotaFiscalSaidasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idNfeCabecalho,
      Value<String?>? competencia}) {
    return FiscalNotaFiscalSaidasCompanion(
      id: id ?? this.id,
      idNfeCabecalho: idNfeCabecalho ?? this.idNfeCabecalho,
      competencia: competencia ?? this.competencia,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idNfeCabecalho.present) {
      map['id_nfe_cabecalho'] = Variable<int>(idNfeCabecalho.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FiscalNotaFiscalSaidasCompanion(')
          ..write('id: $id, ')
          ..write('idNfeCabecalho: $idNfeCabecalho, ')
          ..write('competencia: $competencia')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  late final $FiscalTermosTable fiscalTermos = $FiscalTermosTable(this);
  late final $FiscalInscricoesSubstitutassTable fiscalInscricoesSubstitutass =
      $FiscalInscricoesSubstitutassTable(this);
  late final $SimplesNacionalDetalhesTable simplesNacionalDetalhes =
      $SimplesNacionalDetalhesTable(this);
  late final $FiscalParametrosTable fiscalParametros =
      $FiscalParametrosTable(this);
  late final $FiscalLivrosTable fiscalLivros = $FiscalLivrosTable(this);
  late final $SimplesNacionalCabecalhosTable simplesNacionalCabecalhos =
      $SimplesNacionalCabecalhosTable(this);
  late final $NfeCabecalhosTable nfeCabecalhos = $NfeCabecalhosTable(this);
  late final $FiscalMunicipalRegimesTable fiscalMunicipalRegimes =
      $FiscalMunicipalRegimesTable(this);
  late final $FiscalEstadualRegimesTable fiscalEstadualRegimes =
      $FiscalEstadualRegimesTable(this);
  late final $FiscalEstadualPortesTable fiscalEstadualPortes =
      $FiscalEstadualPortesTable(this);
  late final $FiscalNotaFiscalEntradasTable fiscalNotaFiscalEntradas =
      $FiscalNotaFiscalEntradasTable(this);
  late final $FiscalApuracaoIcmssTable fiscalApuracaoIcmss =
      $FiscalApuracaoIcmssTable(this);
  late final $FiscalNotaFiscalSaidasTable fiscalNotaFiscalSaidas =
      $FiscalNotaFiscalSaidasTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final FiscalParametroDao fiscalParametroDao =
      FiscalParametroDao(this as AppDatabase);
  late final FiscalLivroDao fiscalLivroDao =
      FiscalLivroDao(this as AppDatabase);
  late final SimplesNacionalCabecalhoDao simplesNacionalCabecalhoDao =
      SimplesNacionalCabecalhoDao(this as AppDatabase);
  late final NfeCabecalhoDao nfeCabecalhoDao =
      NfeCabecalhoDao(this as AppDatabase);
  late final FiscalMunicipalRegimeDao fiscalMunicipalRegimeDao =
      FiscalMunicipalRegimeDao(this as AppDatabase);
  late final FiscalEstadualRegimeDao fiscalEstadualRegimeDao =
      FiscalEstadualRegimeDao(this as AppDatabase);
  late final FiscalEstadualPorteDao fiscalEstadualPorteDao =
      FiscalEstadualPorteDao(this as AppDatabase);
  late final FiscalNotaFiscalEntradaDao fiscalNotaFiscalEntradaDao =
      FiscalNotaFiscalEntradaDao(this as AppDatabase);
  late final FiscalApuracaoIcmsDao fiscalApuracaoIcmsDao =
      FiscalApuracaoIcmsDao(this as AppDatabase);
  late final FiscalNotaFiscalSaidaDao fiscalNotaFiscalSaidaDao =
      FiscalNotaFiscalSaidaDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        fiscalTermos,
        fiscalInscricoesSubstitutass,
        simplesNacionalDetalhes,
        fiscalParametros,
        fiscalLivros,
        simplesNacionalCabecalhos,
        nfeCabecalhos,
        fiscalMunicipalRegimes,
        fiscalEstadualRegimes,
        fiscalEstadualPortes,
        fiscalNotaFiscalEntradas,
        fiscalApuracaoIcmss,
        fiscalNotaFiscalSaidas,
        viewControleAcessos,
        viewPessoaUsuarios
      ];
}
