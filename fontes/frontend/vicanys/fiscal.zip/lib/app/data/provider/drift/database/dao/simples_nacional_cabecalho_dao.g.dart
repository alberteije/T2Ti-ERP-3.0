// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'simples_nacional_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$SimplesNacionalCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SimplesNacionalCabecalhosTable get simplesNacionalCabecalhos =>
      attachedDatabase.simplesNacionalCabecalhos;
  $SimplesNacionalDetalhesTable get simplesNacionalDetalhes =>
      attachedDatabase.simplesNacionalDetalhes;
}
