// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_pessoa_transportadora_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewPessoaTransportadoraDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewPessoaTransportadorasTable get viewPessoaTransportadoras =>
      attachedDatabase.viewPessoaTransportadoras;
}
