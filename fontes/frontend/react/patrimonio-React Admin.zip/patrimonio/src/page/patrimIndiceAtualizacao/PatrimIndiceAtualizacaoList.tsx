/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PatrimIndiceAtualizacaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataIndice","nome","valor"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimIndiceAtualizacaoSmallScreenList : PatrimIndiceAtualizacaoBigScreenList;

	return (
		<List
			title="Índices de Atualização"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimIndiceAtualizacaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataIndice }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.valor }
		/>
	);
}

const PatrimIndiceAtualizacaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataIndice" label="Data Indice" />
			<TextField source="nome" label="Nome" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorAlternativo" label="Valor Alternativo" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimIndiceAtualizacaoList;
