import PatrimIndiceAtualizacaoIcon from "@mui/icons-material/Apps";
import PatrimIndiceAtualizacaoList from "./PatrimIndiceAtualizacaoList";
import PatrimIndiceAtualizacaoCreate from "./PatrimIndiceAtualizacaoCreate";
import PatrimIndiceAtualizacaoEdit from "./PatrimIndiceAtualizacaoEdit";

export default {
	list: PatrimIndiceAtualizacaoList,
	create: PatrimIndiceAtualizacaoCreate,
	edit: PatrimIndiceAtualizacaoEdit,
	icon: PatrimIndiceAtualizacaoIcon,
};
