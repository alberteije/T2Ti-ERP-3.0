import {
	Edit,
} from "react-admin";
import { PatrimIndiceAtualizacaoForm } from "./PatrimIndiceAtualizacaoForm";

const PatrimIndiceAtualizacaoEdit = () => {
	return (
		<Edit>
			<PatrimIndiceAtualizacaoForm />
		</Edit>
	);
};

export default PatrimIndiceAtualizacaoEdit;