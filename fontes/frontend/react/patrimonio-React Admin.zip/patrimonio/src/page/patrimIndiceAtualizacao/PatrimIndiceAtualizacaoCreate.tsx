import {
	Create,
} from "react-admin";
import { PatrimIndiceAtualizacaoForm } from "./PatrimIndiceAtualizacaoForm";

const PatrimIndiceAtualizacaoCreate = () => {
	return (
		<Create>
			<PatrimIndiceAtualizacaoForm />
		</Create>
	);
};

export default PatrimIndiceAtualizacaoCreate;