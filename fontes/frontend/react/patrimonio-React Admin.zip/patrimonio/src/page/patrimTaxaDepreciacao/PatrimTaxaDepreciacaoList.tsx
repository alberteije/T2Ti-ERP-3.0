/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PatrimTaxaDepreciacaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["ncm","bem","vida"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimTaxaDepreciacaoSmallScreenList : PatrimTaxaDepreciacaoBigScreenList;

	return (
		<List
			title="Taxas de Depreciação"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimTaxaDepreciacaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.ncm }
			secondaryText={ (record) => record.bem }
			tertiaryText={ (record) => record.vida }
		/>
	);
}

const PatrimTaxaDepreciacaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="ncm" label="Ncm" />
			<TextField source="bem" label="Bem" />
			<NumberField source="vida" label="Vida" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxa" label="Taxa" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimTaxaDepreciacaoList;
