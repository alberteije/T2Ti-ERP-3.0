import {
	Edit,
} from "react-admin";
import { PatrimTaxaDepreciacaoForm } from "./PatrimTaxaDepreciacaoForm";

const PatrimTaxaDepreciacaoEdit = () => {
	return (
		<Edit>
			<PatrimTaxaDepreciacaoForm />
		</Edit>
	);
};

export default PatrimTaxaDepreciacaoEdit;