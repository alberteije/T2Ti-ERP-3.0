import {
	Create,
} from "react-admin";
import { PatrimTaxaDepreciacaoForm } from "./PatrimTaxaDepreciacaoForm";

const PatrimTaxaDepreciacaoCreate = () => {
	return (
		<Create>
			<PatrimTaxaDepreciacaoForm />
		</Create>
	);
};

export default PatrimTaxaDepreciacaoCreate;