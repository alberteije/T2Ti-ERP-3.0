import PatrimTaxaDepreciacaoIcon from "@mui/icons-material/Apps";
import PatrimTaxaDepreciacaoList from "./PatrimTaxaDepreciacaoList";
import PatrimTaxaDepreciacaoCreate from "./PatrimTaxaDepreciacaoCreate";
import PatrimTaxaDepreciacaoEdit from "./PatrimTaxaDepreciacaoEdit";

export default {
	list: PatrimTaxaDepreciacaoList,
	create: PatrimTaxaDepreciacaoCreate,
	edit: PatrimTaxaDepreciacaoEdit,
	icon: PatrimTaxaDepreciacaoIcon,
};
