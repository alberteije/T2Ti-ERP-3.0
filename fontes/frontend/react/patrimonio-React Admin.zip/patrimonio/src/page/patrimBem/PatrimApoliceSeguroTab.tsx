/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PatrimApoliceSeguro {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PatrimApoliceSeguro {
		const patrimApoliceSeguro = new PatrimApoliceSeguro();
		patrimApoliceSeguro.id = Date.now();
		patrimApoliceSeguro.statusCrud = "C";
		return patrimApoliceSeguro;
	}
}

export const PatrimApoliceSeguroTab: React.FC = () => {

	const renderForm = (
		currentRecord: PatrimApoliceSeguro,
		setCurrentRecord: (record: PatrimApoliceSeguro) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'seguradoraModel.id', label: 'Seguradora', reference: 'seguradora', fieldName: 'nome' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'dataContratacao', label: 'Data Contratacao' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'valorPremio', label: 'Valor Premio' },
		{ source: 'valorSegurado', label: 'Valor Segurado' },
		{ source: 'observacao', label: 'Observacao' },
		{ source: 'imagem', label: 'Imagem' },
	];

	return (
		<CrudChildTab
			title="Apólices"
			recordContext="patrimBem"
			fieldSource="patrimApoliceSeguroModelList"
			newObject={ PatrimApoliceSeguro.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};