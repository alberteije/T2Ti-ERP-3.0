/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PatrimDocumentoBemTab } from './PatrimDocumentoBemTab';
import { PatrimDepreciacaoBemTab } from './PatrimDepreciacaoBemTab';
import { PatrimMovimentacaoBemTab } from './PatrimMovimentacaoBemTab';
import { PatrimApoliceSeguroTab } from './PatrimApoliceSeguroTab';

export const PatrimBemForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Bem">
				<PatrimBemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Documentos">
				<PatrimDocumentoBemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Depreciação">
				<PatrimDepreciacaoBemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Movimentação">
				<PatrimMovimentacaoBemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Apólices">
				<PatrimApoliceSeguroTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PatrimBemTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};