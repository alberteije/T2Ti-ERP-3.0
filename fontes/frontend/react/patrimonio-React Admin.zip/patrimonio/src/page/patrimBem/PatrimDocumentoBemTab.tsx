/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PatrimDocumentoBem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PatrimDocumentoBem {
		const patrimDocumentoBem = new PatrimDocumentoBem();
		patrimDocumentoBem.id = Date.now();
		patrimDocumentoBem.statusCrud = "C";
		return patrimDocumentoBem;
	}
}

export const PatrimDocumentoBemTab: React.FC = () => {

	const renderForm = (
		currentRecord: PatrimDocumentoBem,
		setCurrentRecord: (record: PatrimDocumentoBem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'descricao', label: 'Descricao' },
		{ source: 'imagem', label: 'Imagem' },
	];

	return (
		<CrudChildTab
			title="Documentos"
			recordContext="patrimBem"
			fieldSource="patrimDocumentoBemModelList"
			newObject={ PatrimDocumentoBem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};