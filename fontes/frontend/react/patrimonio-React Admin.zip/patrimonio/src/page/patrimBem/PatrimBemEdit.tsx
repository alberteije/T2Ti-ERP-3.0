/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PatrimBemForm } from "./PatrimBemForm";
import { transformNestedData } from "../../infra/utils";

const PatrimBemEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PatrimBemForm />
		</Edit>
	);
};

export default PatrimBemEdit;