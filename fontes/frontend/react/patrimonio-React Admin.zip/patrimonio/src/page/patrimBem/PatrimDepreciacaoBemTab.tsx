/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PatrimDepreciacaoBem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PatrimDepreciacaoBem {
		const patrimDepreciacaoBem = new PatrimDepreciacaoBem();
		patrimDepreciacaoBem.id = Date.now();
		patrimDepreciacaoBem.statusCrud = "C";
		return patrimDepreciacaoBem;
	}
}

export const PatrimDepreciacaoBemTab: React.FC = () => {

	const renderForm = (
		currentRecord: PatrimDepreciacaoBem,
		setCurrentRecord: (record: PatrimDepreciacaoBem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataDepreciacao', label: 'Data Depreciacao' },
		{ source: 'dias', label: 'Dias' },
		{ source: 'taxa', label: 'Taxa' },
		{ source: 'indice', label: 'Indice' },
		{ source: 'valor', label: 'Valor' },
		{ source: 'depreciacaoAcumulada', label: 'Depreciacao Acumulada' },
	];

	return (
		<CrudChildTab
			title="Depreciação"
			recordContext="patrimBem"
			fieldSource="patrimDepreciacaoBemModelList"
			newObject={ PatrimDepreciacaoBem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};