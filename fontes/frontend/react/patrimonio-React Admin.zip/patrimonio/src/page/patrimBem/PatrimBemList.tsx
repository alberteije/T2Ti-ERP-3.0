/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PatrimBemDomain from '../../data/domain/PatrimBemDomain';

const PatrimBemList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["centroResultadoModel.descricao","viewPessoaFornecedorModel.nome","viewPessoaColaboradorModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimBemSmallScreenList : PatrimBemBigScreenList;

	return (
		<List
			title="Bem"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimBemSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.centroResultadoModel.descricao }
			secondaryText={ (record) => record.viewPessoaFornecedorModel.nome }
			tertiaryText={ (record) => record.viewPessoaColaboradorModel.nome }
		/>
	);
}

const PatrimBemBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Centro Resultado" source="centroResultadoModel.id" reference="centro-resultado" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Fornecedor" source="viewPessoaFornecedorModel.id" reference="view-pessoa-fornecedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Patrim Tipo Aquisicao Bem" source="patrimTipoAquisicaoBemModel.id" reference="patrim-tipo-aquisicao-bem" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Patrim Estado Conservacao" source="patrimEstadoConservacaoModel.id" reference="patrim-estado-conservacao" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Patrim Grupo Bem" source="patrimGrupoBemModel.id" reference="patrim-grupo-bem" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Setor" source="setorModel.id" reference="setor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="numeroNb" label="Numero Nb" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="dataAquisicao" label="Data Aquisicao" />
			<TextField source="dataAceite" label="Data Aceite" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<TextField source="dataContabilizado" label="Data Contabilizado" />
			<TextField source="dataVistoria" label="Data Vistoria" />
			<TextField source="dataMarcacao" label="Data Marcacao" />
			<TextField source="dataBaixa" label="Data Baixa" />
			<TextField source="vencimentoGarantia" label="Vencimento Garantia" />
			<TextField source="numeroNotaFiscal" label="Numero Nota Fiscal" />
			<TextField source="numeroSerie" label="Numero Serie" />
			<TextField source="chaveNfe" label="Chave Nfe" />
			<NumberField source="valorOriginal" label="Valor Original" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCompra" label="Valor Compra" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorAtualizado" label="Valor Atualizado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBaixa" label="Valor Baixa" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Deprecia"
				render={record => PatrimBemDomain.getDeprecia(record.deprecia)}
			/>
			<FunctionField
				label="Metodo Depreciacao"
				render={record => PatrimBemDomain.getMetodoDepreciacao(record.metodoDepreciacao)}
			/>
			<TextField source="inicioDepreciacao" label="Inicio Depreciacao" />
			<TextField source="ultimaDepreciacao" label="Ultima Depreciacao" />
			<FunctionField
				label="Tipo Depreciacao"
				render={record => PatrimBemDomain.getTipoDepreciacao(record.tipoDepreciacao)}
			/>
			<NumberField source="taxaAnualDepreciacao" label="Taxa Anual Depreciacao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaMensalDepreciacao" label="Taxa Mensal Depreciacao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaDepreciacaoAcelerada" label="Taxa Depreciacao Acelerada" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaDepreciacaoIncentivada" label="Taxa Depreciacao Incentivada" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="funcao" label="Funcao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimBemList;
