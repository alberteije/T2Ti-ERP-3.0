/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PatrimBemForm } from "./PatrimBemForm";
import { transformNestedData } from "../../infra/utils";

const PatrimBemCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PatrimBemForm />
		</Create>
	);
};

export default PatrimBemCreate;