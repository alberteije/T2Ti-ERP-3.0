/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PatrimMovimentacaoBem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PatrimMovimentacaoBem {
		const patrimMovimentacaoBem = new PatrimMovimentacaoBem();
		patrimMovimentacaoBem.id = Date.now();
		patrimMovimentacaoBem.statusCrud = "C";
		return patrimMovimentacaoBem;
	}
}

export const PatrimMovimentacaoBemTab: React.FC = () => {

	const renderForm = (
		currentRecord: PatrimMovimentacaoBem,
		setCurrentRecord: (record: PatrimMovimentacaoBem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'patrimTipoMovimentacaoModel.id', label: 'Tipo Movimentacao', reference: 'patrim-tipo-movimentacao', fieldName: 'nome' },
		{ source: 'dataMovimentacao', label: 'Data Movimentacao' },
		{ source: 'responsavel', label: 'Responsavel' },
	];

	return (
		<CrudChildTab
			title="Movimentação"
			recordContext="patrimBem"
			fieldSource="patrimMovimentacaoBemModelList"
			newObject={ PatrimMovimentacaoBem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};