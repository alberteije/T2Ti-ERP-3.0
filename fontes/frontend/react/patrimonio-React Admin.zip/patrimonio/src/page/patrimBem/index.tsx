import PatrimBemIcon from "@mui/icons-material/Apps";
import PatrimBemList from "./PatrimBemList";
import PatrimBemCreate from "./PatrimBemCreate";
import PatrimBemEdit from "./PatrimBemEdit";

export default {
	list: PatrimBemList,
	create: PatrimBemCreate,
	edit: PatrimBemEdit,
	icon: PatrimBemIcon,
};
