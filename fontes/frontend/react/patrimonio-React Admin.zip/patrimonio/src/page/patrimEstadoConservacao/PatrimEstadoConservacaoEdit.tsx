import {
	Edit,
} from "react-admin";
import { PatrimEstadoConservacaoForm } from "./PatrimEstadoConservacaoForm";

const PatrimEstadoConservacaoEdit = () => {
	return (
		<Edit>
			<PatrimEstadoConservacaoForm />
		</Edit>
	);
};

export default PatrimEstadoConservacaoEdit;