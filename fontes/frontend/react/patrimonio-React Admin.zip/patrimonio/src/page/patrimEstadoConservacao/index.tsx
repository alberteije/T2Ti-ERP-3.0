import PatrimEstadoConservacaoIcon from "@mui/icons-material/Apps";
import PatrimEstadoConservacaoList from "./PatrimEstadoConservacaoList";
import PatrimEstadoConservacaoCreate from "./PatrimEstadoConservacaoCreate";
import PatrimEstadoConservacaoEdit from "./PatrimEstadoConservacaoEdit";

export default {
	list: PatrimEstadoConservacaoList,
	create: PatrimEstadoConservacaoCreate,
	edit: PatrimEstadoConservacaoEdit,
	icon: PatrimEstadoConservacaoIcon,
};
