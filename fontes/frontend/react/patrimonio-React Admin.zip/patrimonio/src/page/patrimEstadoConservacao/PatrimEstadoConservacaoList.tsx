/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PatrimEstadoConservacaoDomain from '../../data/domain/PatrimEstadoConservacaoDomain';

const PatrimEstadoConservacaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimEstadoConservacaoSmallScreenList : PatrimEstadoConservacaoBigScreenList;

	return (
		<List
			title="Estado de Conservação"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimEstadoConservacaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const PatrimEstadoConservacaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Codigo"
				render={record => PatrimEstadoConservacaoDomain.getCodigo(record.codigo)}
			/>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimEstadoConservacaoList;
