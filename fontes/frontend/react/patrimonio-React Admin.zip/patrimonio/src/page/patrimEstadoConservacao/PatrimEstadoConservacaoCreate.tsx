import {
	Create,
} from "react-admin";
import { PatrimEstadoConservacaoForm } from "./PatrimEstadoConservacaoForm";

const PatrimEstadoConservacaoCreate = () => {
	return (
		<Create>
			<PatrimEstadoConservacaoForm />
		</Create>
	);
};

export default PatrimEstadoConservacaoCreate;