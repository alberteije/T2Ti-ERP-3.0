import {
	Edit,
} from "react-admin";
import { PatrimTipoMovimentacaoForm } from "./PatrimTipoMovimentacaoForm";

const PatrimTipoMovimentacaoEdit = () => {
	return (
		<Edit>
			<PatrimTipoMovimentacaoForm />
		</Edit>
	);
};

export default PatrimTipoMovimentacaoEdit;