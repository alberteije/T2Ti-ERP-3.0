/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PatrimTipoMovimentacaoDomain from '../../data/domain/PatrimTipoMovimentacaoDomain';

const PatrimTipoMovimentacaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["tipo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimTipoMovimentacaoSmallScreenList : PatrimTipoMovimentacaoBigScreenList;

	return (
		<List
			title="Tipo Movimentação Bem"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimTipoMovimentacaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.tipo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const PatrimTipoMovimentacaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Tipo"
				render={record => PatrimTipoMovimentacaoDomain.getTipo(record.tipo)}
			/>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimTipoMovimentacaoList;
