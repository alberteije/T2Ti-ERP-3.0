import {
	Create,
} from "react-admin";
import { PatrimTipoMovimentacaoForm } from "./PatrimTipoMovimentacaoForm";

const PatrimTipoMovimentacaoCreate = () => {
	return (
		<Create>
			<PatrimTipoMovimentacaoForm />
		</Create>
	);
};

export default PatrimTipoMovimentacaoCreate;