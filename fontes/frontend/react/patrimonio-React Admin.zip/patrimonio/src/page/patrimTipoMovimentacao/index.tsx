import PatrimTipoMovimentacaoIcon from "@mui/icons-material/Apps";
import PatrimTipoMovimentacaoList from "./PatrimTipoMovimentacaoList";
import PatrimTipoMovimentacaoCreate from "./PatrimTipoMovimentacaoCreate";
import PatrimTipoMovimentacaoEdit from "./PatrimTipoMovimentacaoEdit";

export default {
	list: PatrimTipoMovimentacaoList,
	create: PatrimTipoMovimentacaoCreate,
	edit: PatrimTipoMovimentacaoEdit,
	icon: PatrimTipoMovimentacaoIcon,
};
