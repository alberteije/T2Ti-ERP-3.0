import {
	Edit,
} from "react-admin";
import { SeguradoraForm } from "./SeguradoraForm";

const SeguradoraEdit = () => {
	return (
		<Edit>
			<SeguradoraForm />
		</Edit>
	);
};

export default SeguradoraEdit;