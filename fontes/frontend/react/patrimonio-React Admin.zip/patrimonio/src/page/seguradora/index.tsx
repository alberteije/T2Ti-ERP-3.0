import SeguradoraIcon from "@mui/icons-material/Apps";
import SeguradoraList from "./SeguradoraList";
import SeguradoraCreate from "./SeguradoraCreate";
import SeguradoraEdit from "./SeguradoraEdit";

export default {
	list: SeguradoraList,
	create: SeguradoraCreate,
	edit: SeguradoraEdit,
	icon: SeguradoraIcon,
};
