/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const SeguradoraList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","contato","telefone"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SeguradoraSmallScreenList : SeguradoraBigScreenList;

	return (
		<List
			title="Seguradora"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SeguradoraSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.contato }
			tertiaryText={ (record) => record.telefone }
		/>
	);
}

const SeguradoraBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="contato" label="Contato" />
			<FunctionField
				source="telefone"
				label="Telefone"
				render={record => formatWithMask(record.telefone, '(##)#####-####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SeguradoraList;
