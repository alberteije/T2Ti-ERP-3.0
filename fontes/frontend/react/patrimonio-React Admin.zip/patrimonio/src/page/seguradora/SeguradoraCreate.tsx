import {
	Create,
} from "react-admin";
import { SeguradoraForm } from "./SeguradoraForm";

const SeguradoraCreate = () => {
	return (
		<Create>
			<SeguradoraForm />
		</Create>
	);
};

export default SeguradoraCreate;