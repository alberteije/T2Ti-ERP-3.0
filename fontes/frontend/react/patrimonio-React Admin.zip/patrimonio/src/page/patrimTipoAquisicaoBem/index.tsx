import PatrimTipoAquisicaoBemIcon from "@mui/icons-material/Apps";
import PatrimTipoAquisicaoBemList from "./PatrimTipoAquisicaoBemList";
import PatrimTipoAquisicaoBemCreate from "./PatrimTipoAquisicaoBemCreate";
import PatrimTipoAquisicaoBemEdit from "./PatrimTipoAquisicaoBemEdit";

export default {
	list: PatrimTipoAquisicaoBemList,
	create: PatrimTipoAquisicaoBemCreate,
	edit: PatrimTipoAquisicaoBemEdit,
	icon: PatrimTipoAquisicaoBemIcon,
};
