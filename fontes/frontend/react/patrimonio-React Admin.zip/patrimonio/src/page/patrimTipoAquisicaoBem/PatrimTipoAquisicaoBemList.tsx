/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PatrimTipoAquisicaoBemDomain from '../../data/domain/PatrimTipoAquisicaoBemDomain';

const PatrimTipoAquisicaoBemList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["tipo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimTipoAquisicaoBemSmallScreenList : PatrimTipoAquisicaoBemBigScreenList;

	return (
		<List
			title="Tipo Aquisição Bem"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimTipoAquisicaoBemSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.tipo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const PatrimTipoAquisicaoBemBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Tipo"
				render={record => PatrimTipoAquisicaoBemDomain.getTipo(record.tipo)}
			/>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimTipoAquisicaoBemList;
