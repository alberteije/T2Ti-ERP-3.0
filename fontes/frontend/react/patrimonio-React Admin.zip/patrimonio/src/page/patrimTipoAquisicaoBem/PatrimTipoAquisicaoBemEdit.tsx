import {
	Edit,
} from "react-admin";
import { PatrimTipoAquisicaoBemForm } from "./PatrimTipoAquisicaoBemForm";

const PatrimTipoAquisicaoBemEdit = () => {
	return (
		<Edit>
			<PatrimTipoAquisicaoBemForm />
		</Edit>
	);
};

export default PatrimTipoAquisicaoBemEdit;