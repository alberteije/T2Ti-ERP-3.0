import {
	Create,
} from "react-admin";
import { PatrimTipoAquisicaoBemForm } from "./PatrimTipoAquisicaoBemForm";

const PatrimTipoAquisicaoBemCreate = () => {
	return (
		<Create>
			<PatrimTipoAquisicaoBemForm />
		</Create>
	);
};

export default PatrimTipoAquisicaoBemCreate;