import {
	Edit,
} from "react-admin";
import { PatrimGrupoBemForm } from "./PatrimGrupoBemForm";

const PatrimGrupoBemEdit = () => {
	return (
		<Edit>
			<PatrimGrupoBemForm />
		</Edit>
	);
};

export default PatrimGrupoBemEdit;