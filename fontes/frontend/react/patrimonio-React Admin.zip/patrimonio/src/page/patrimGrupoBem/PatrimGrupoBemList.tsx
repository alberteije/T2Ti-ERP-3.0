/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PatrimGrupoBemList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PatrimGrupoBemSmallScreenList : PatrimGrupoBemBigScreenList;

	return (
		<List
			title="Grupo"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PatrimGrupoBemSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const PatrimGrupoBemBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="contaAtivoImobilizado" label="Conta Ativo Imobilizado" />
			<TextField source="contaDepreciacaoAcumulada" label="Conta Depreciacao Acumulada" />
			<TextField source="contaDespesaDepreciacao" label="Conta Despesa Depreciacao" />
			<TextField source="codigoHistorico" label="Codigo Historico" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PatrimGrupoBemList;
