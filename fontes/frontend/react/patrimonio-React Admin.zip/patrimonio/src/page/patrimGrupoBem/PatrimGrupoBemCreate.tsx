import {
	Create,
} from "react-admin";
import { PatrimGrupoBemForm } from "./PatrimGrupoBemForm";

const PatrimGrupoBemCreate = () => {
	return (
		<Create>
			<PatrimGrupoBemForm />
		</Create>
	);
};

export default PatrimGrupoBemCreate;