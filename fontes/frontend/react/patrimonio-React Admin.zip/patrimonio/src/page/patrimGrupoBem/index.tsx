import PatrimGrupoBemIcon from "@mui/icons-material/Apps";
import PatrimGrupoBemList from "./PatrimGrupoBemList";
import PatrimGrupoBemCreate from "./PatrimGrupoBemCreate";
import PatrimGrupoBemEdit from "./PatrimGrupoBemEdit";

export default {
	list: PatrimGrupoBemList,
	create: PatrimGrupoBemCreate,
	edit: PatrimGrupoBemEdit,
	icon: PatrimGrupoBemIcon,
};
