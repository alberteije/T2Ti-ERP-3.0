import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import patrimBem from './page/patrimBem';
import patrimIndiceAtualizacao from './page/patrimIndiceAtualizacao';
import patrimTaxaDepreciacao from './page/patrimTaxaDepreciacao';
import patrimGrupoBem from './page/patrimGrupoBem';
import patrimTipoAquisicaoBem from './page/patrimTipoAquisicaoBem';
import patrimEstadoConservacao from './page/patrimEstadoConservacao';
import seguradora from './page/seguradora';
import patrimTipoMovimentacao from './page/patrimTipoMovimentacao';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'patrimonio');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Controle Patrimonial (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='patrim-bem' {...patrimBem} options={{ label: 'Bem' }} />
			<Resource name='patrim-indice-atualizacao' {...patrimIndiceAtualizacao} options={{ label: 'Índices de Atualização' }} />
			<Resource name='patrim-taxa-depreciacao' {...patrimTaxaDepreciacao} options={{ label: 'Taxas de Depreciação' }} />
			<Resource name='patrim-grupo-bem' {...patrimGrupoBem} options={{ label: 'Grupo' }} />
			<Resource name='patrim-tipo-aquisicao-bem' {...patrimTipoAquisicaoBem} options={{ label: 'Tipo Aquisição Bem' }} />
			<Resource name='patrim-estado-conservacao' {...patrimEstadoConservacao} options={{ label: 'Estado de Conservação' }} />
			<Resource name='seguradora' {...seguradora} options={{ label: 'Seguradora' }} />
			<Resource name='patrim-tipo-movimentacao' {...patrimTipoMovimentacao} options={{ label: 'Tipo Movimentação Bem' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;