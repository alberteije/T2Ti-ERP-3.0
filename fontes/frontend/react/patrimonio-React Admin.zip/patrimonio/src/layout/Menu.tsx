import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import patrimBem from '../page/patrimBem';
import patrimIndiceAtualizacao from '../page/patrimIndiceAtualizacao';
import patrimTaxaDepreciacao from '../page/patrimTaxaDepreciacao';
import patrimGrupoBem from '../page/patrimGrupoBem';
import patrimTipoAquisicaoBem from '../page/patrimTipoAquisicaoBem';
import patrimEstadoConservacao from '../page/patrimEstadoConservacao';
import seguradora from '../page/seguradora';
import patrimTipoMovimentacao from '../page/patrimTipoMovimentacao';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/patrim-indice-atualizacao'
					state={{ _scrollToTop: true }}
					primaryText='Índices de Atualização'
					leftIcon={<patrimIndiceAtualizacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/patrim-taxa-depreciacao'
					state={{ _scrollToTop: true }}
					primaryText='Taxas de Depreciação'
					leftIcon={<patrimTaxaDepreciacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/patrim-grupo-bem'
					state={{ _scrollToTop: true }}
					primaryText='Grupo'
					leftIcon={<patrimGrupoBem.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/patrim-tipo-aquisicao-bem'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Aquisição Bem'
					leftIcon={<patrimTipoAquisicaoBem.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/patrim-estado-conservacao'
					state={{ _scrollToTop: true }}
					primaryText='Estado de Conservação'
					leftIcon={<patrimEstadoConservacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/seguradora'
					state={{ _scrollToTop: true }}
					primaryText='Seguradora'
					leftIcon={<seguradora.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/patrim-tipo-movimentacao'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Movimentação Bem'
					leftIcon={<patrimTipoMovimentacao.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/patrim-bem'
					state={{ _scrollToTop: true }}
					primaryText='Bem'
					leftIcon={<patrimBem.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
