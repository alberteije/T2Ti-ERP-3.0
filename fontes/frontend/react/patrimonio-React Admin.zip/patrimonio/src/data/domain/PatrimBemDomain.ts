class PatrimBemDomain {
	static getDeprecia(deprecia: string) { 
		switch (deprecia) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setDeprecia(deprecia: string) { 
		switch (deprecia) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getMetodoDepreciacao(metodoDepreciacao: string) { 
		switch (metodoDepreciacao) { 
			case '': 
			case '1': 
				return '1=Linear'; 
			case '2': 
				return '2=Soma dos Algarismos dos Anos'; 
			case '3': 
				return '3=Horas de Trabalho'; 
			case '4': 
				return '4=Unidades Produzidas'; 
			default: 
				return null; 
		} 
	} 

	static setMetodoDepreciacao(metodoDepreciacao: string) { 
		switch (metodoDepreciacao) { 
			case '1=Linear': 
				return '1'; 
			case '2=Soma dos Algarismos dos Anos': 
				return '2'; 
			case '3=Horas de Trabalho': 
				return '3'; 
			case '4=Unidades Produzidas': 
				return '4'; 
			default: 
				return null; 
		} 
	}

	static getTipoDepreciacao(tipoDepreciacao: string) { 
		switch (tipoDepreciacao) { 
			case '': 
			case 'N': 
				return 'Normal'; 
			case 'A': 
				return 'Acelerada'; 
			case 'I': 
				return 'Incentivada'; 
			default: 
				return null; 
		} 
	} 

	static setTipoDepreciacao(tipoDepreciacao: string) { 
		switch (tipoDepreciacao) { 
			case 'Normal': 
				return 'N'; 
			case 'Acelerada': 
				return 'A'; 
			case 'Incentivada': 
				return 'I'; 
			default: 
				return null; 
		} 
	}

}

export default PatrimBemDomain;