/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { GondolaCaixaForm } from "./GondolaCaixaForm";
import { transformNestedData } from "../../infra/utils";

const GondolaCaixaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<GondolaCaixaForm />
		</Create>
	);
};

export default GondolaCaixaCreate;