/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const GondolaCaixaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["gondolaEstanteModel.codigo","codigo","altura"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? GondolaCaixaSmallScreenList : GondolaCaixaBigScreenList;

	return (
		<List
			title="Caixa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const GondolaCaixaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.gondolaEstanteModel.codigo }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.altura }
		/>
	);
}

const GondolaCaixaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Gondola Estante" source="gondolaEstanteModel.id" reference="gondola-estante" sortable={false}>
				<TextField source="codigo" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<TextField source="altura" label="Altura" />
			<TextField source="largura" label="Largura" />
			<TextField source="profundidade" label="Profundidade" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default GondolaCaixaList;
