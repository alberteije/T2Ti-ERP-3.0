import GondolaCaixaIcon from "@mui/icons-material/Apps";
import GondolaCaixaList from "./GondolaCaixaList";
import GondolaCaixaCreate from "./GondolaCaixaCreate";
import GondolaCaixaEdit from "./GondolaCaixaEdit";

export default {
	list: GondolaCaixaList,
	create: GondolaCaixaCreate,
	edit: GondolaCaixaEdit,
	icon: GondolaCaixaIcon,
};
