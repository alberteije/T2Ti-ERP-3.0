/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { GondolaCaixaForm } from "./GondolaCaixaForm";
import { transformNestedData } from "../../infra/utils";

const GondolaCaixaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<GondolaCaixaForm />
		</Edit>
	);
};

export default GondolaCaixaEdit;