/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class GondolaArmazenamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): GondolaArmazenamento {
		const gondolaArmazenamento = new GondolaArmazenamento();
		gondolaArmazenamento.id = Date.now();
		gondolaArmazenamento.statusCrud = "C";
		return gondolaArmazenamento;
	}
}

export const GondolaArmazenamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: GondolaArmazenamento,
		setCurrentRecord: (record: GondolaArmazenamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Armazenamento"
			recordContext="gondolaCaixa"
			fieldSource="gondolaArmazenamentoModelList"
			newObject={ GondolaArmazenamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};