import {
	Create,
} from "react-admin";
import { GondolaRuaForm } from "./GondolaRuaForm";

const GondolaRuaCreate = () => {
	return (
		<Create>
			<GondolaRuaForm />
		</Create>
	);
};

export default GondolaRuaCreate;