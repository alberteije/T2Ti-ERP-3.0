import {
	Edit,
} from "react-admin";
import { GondolaRuaForm } from "./GondolaRuaForm";

const GondolaRuaEdit = () => {
	return (
		<Edit>
			<GondolaRuaForm />
		</Edit>
	);
};

export default GondolaRuaEdit;