import GondolaRuaIcon from "@mui/icons-material/Apps";
import GondolaRuaList from "./GondolaRuaList";
import GondolaRuaCreate from "./GondolaRuaCreate";
import GondolaRuaEdit from "./GondolaRuaEdit";

export default {
	list: GondolaRuaList,
	create: GondolaRuaCreate,
	edit: GondolaRuaEdit,
	icon: GondolaRuaIcon,
};
