import GondolaEstanteIcon from "@mui/icons-material/Apps";
import GondolaEstanteList from "./GondolaEstanteList";
import GondolaEstanteCreate from "./GondolaEstanteCreate";
import GondolaEstanteEdit from "./GondolaEstanteEdit";

export default {
	list: GondolaEstanteList,
	create: GondolaEstanteCreate,
	edit: GondolaEstanteEdit,
	icon: GondolaEstanteIcon,
};
