import {
	Edit,
} from "react-admin";
import { GondolaEstanteForm } from "./GondolaEstanteForm";

const GondolaEstanteEdit = () => {
	return (
		<Edit>
			<GondolaEstanteForm />
		</Edit>
	);
};

export default GondolaEstanteEdit;