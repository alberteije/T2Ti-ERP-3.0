/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const GondolaEstanteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["gondolaRuaModel.nome","codigo","quantidadeCaixa"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? GondolaEstanteSmallScreenList : GondolaEstanteBigScreenList;

	return (
		<List
			title="Estante"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const GondolaEstanteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.gondolaRuaModel.nome }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.quantidadeCaixa }
		/>
	);
}

const GondolaEstanteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Gondola Rua" source="gondolaRuaModel.id" reference="gondola-rua" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<TextField source="quantidadeCaixa" label="Quantidade Caixa" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default GondolaEstanteList;
