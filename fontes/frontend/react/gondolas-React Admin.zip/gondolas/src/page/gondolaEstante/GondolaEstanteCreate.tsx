import {
	Create,
} from "react-admin";
import { GondolaEstanteForm } from "./GondolaEstanteForm";

const GondolaEstanteCreate = () => {
	return (
		<Create>
			<GondolaEstanteForm />
		</Create>
	);
};

export default GondolaEstanteCreate;