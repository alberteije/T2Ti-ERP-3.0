/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class OrcamentoFluxoCaixaDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): OrcamentoFluxoCaixaDetalhe {
		const orcamentoFluxoCaixaDetalhe = new OrcamentoFluxoCaixaDetalhe();
		orcamentoFluxoCaixaDetalhe.id = Date.now();
		orcamentoFluxoCaixaDetalhe.statusCrud = "C";
		return orcamentoFluxoCaixaDetalhe;
	}
}

export const OrcamentoFluxoCaixaDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: OrcamentoFluxoCaixaDetalhe,
		setCurrentRecord: (record: OrcamentoFluxoCaixaDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finNaturezaFinanceiraModel.id', label: 'Natureza Financeira', reference: 'fin-natureza-financeira', fieldName: 'descricao' },
		{ source: 'periodo', label: 'Periodo' },
		{ source: 'valorOrcado', label: 'Valor Orcado' },
		{ source: 'valorRealizado', label: 'Valor Realizado' },
		{ source: 'taxaVariacao', label: 'Taxa Variacao' },
		{ source: 'valorVariacao', label: 'Valor Variacao' },
	];

	return (
		<CrudChildTab
			title="Itens"
			recordContext="orcamentoFluxoCaixa"
			fieldSource="orcamentoFluxoCaixaDetalheModelList"
			newObject={ OrcamentoFluxoCaixaDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};