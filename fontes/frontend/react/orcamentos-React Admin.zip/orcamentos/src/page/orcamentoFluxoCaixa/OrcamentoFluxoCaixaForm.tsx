/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { OrcamentoFluxoCaixaDetalheTab } from './OrcamentoFluxoCaixaDetalheTab';

export const OrcamentoFluxoCaixaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Orçamento - Fluxo de Caixa">
				<OrcamentoFluxoCaixaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens">
				<OrcamentoFluxoCaixaDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const OrcamentoFluxoCaixaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};