/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { OrcamentoFluxoCaixaForm } from "./OrcamentoFluxoCaixaForm";
import { transformNestedData } from "../../infra/utils";

const OrcamentoFluxoCaixaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<OrcamentoFluxoCaixaForm />
		</Edit>
	);
};

export default OrcamentoFluxoCaixaEdit;