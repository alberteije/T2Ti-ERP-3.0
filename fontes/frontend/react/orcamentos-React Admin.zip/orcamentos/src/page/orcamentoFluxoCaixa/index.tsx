import OrcamentoFluxoCaixaIcon from "@mui/icons-material/Apps";
import OrcamentoFluxoCaixaList from "./OrcamentoFluxoCaixaList";
import OrcamentoFluxoCaixaCreate from "./OrcamentoFluxoCaixaCreate";
import OrcamentoFluxoCaixaEdit from "./OrcamentoFluxoCaixaEdit";

export default {
	list: OrcamentoFluxoCaixaList,
	create: OrcamentoFluxoCaixaCreate,
	edit: OrcamentoFluxoCaixaEdit,
	icon: OrcamentoFluxoCaixaIcon,
};
