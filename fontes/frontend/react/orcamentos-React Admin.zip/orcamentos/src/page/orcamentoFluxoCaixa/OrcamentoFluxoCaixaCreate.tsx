/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { OrcamentoFluxoCaixaForm } from "./OrcamentoFluxoCaixaForm";
import { transformNestedData } from "../../infra/utils";

const OrcamentoFluxoCaixaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<OrcamentoFluxoCaixaForm />
		</Create>
	);
};

export default OrcamentoFluxoCaixaCreate;