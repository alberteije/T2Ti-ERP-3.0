/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const OrcamentoFluxoCaixaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["orcamentoFluxoCaixaPeriodoModel.nome","nome","dataInicial"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OrcamentoFluxoCaixaSmallScreenList : OrcamentoFluxoCaixaBigScreenList;

	return (
		<List
			title="Orçamento - Fluxo de Caixa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OrcamentoFluxoCaixaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.orcamentoFluxoCaixaPeriodoModel.nome }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.dataInicial }
		/>
	);
}

const OrcamentoFluxoCaixaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Orc Fluxo Caixa Periodo" source="orcamentoFluxoCaixaPeriodoModel.id" reference="orcamento-fluxo-caixa-periodo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="dataInicial" label="Data Inicial" />
			<TextField source="numeroPeriodos" label="Numero Periodos" />
			<TextField source="dataBase" label="Data Base" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OrcamentoFluxoCaixaList;
