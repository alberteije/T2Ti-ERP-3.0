import OrcamentoEmpresarialIcon from "@mui/icons-material/Apps";
import OrcamentoEmpresarialList from "./OrcamentoEmpresarialList";
import OrcamentoEmpresarialCreate from "./OrcamentoEmpresarialCreate";
import OrcamentoEmpresarialEdit from "./OrcamentoEmpresarialEdit";

export default {
	list: OrcamentoEmpresarialList,
	create: OrcamentoEmpresarialCreate,
	edit: OrcamentoEmpresarialEdit,
	icon: OrcamentoEmpresarialIcon,
};
