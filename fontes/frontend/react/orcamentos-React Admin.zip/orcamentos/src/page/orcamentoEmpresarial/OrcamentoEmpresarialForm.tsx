/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { OrcamentoDetalheTab } from './OrcamentoDetalheTab';

export const OrcamentoEmpresarialForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Orçamento">
				<OrcamentoEmpresarialTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens">
				<OrcamentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const OrcamentoEmpresarialTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};