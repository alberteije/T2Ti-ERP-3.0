/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class OrcamentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): OrcamentoDetalhe {
		const orcamentoDetalhe = new OrcamentoDetalhe();
		orcamentoDetalhe.id = Date.now();
		orcamentoDetalhe.statusCrud = "C";
		return orcamentoDetalhe;
	}
}

export const OrcamentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: OrcamentoDetalhe,
		setCurrentRecord: (record: OrcamentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finNaturezaFinanceiraModel.id', label: 'Natureza Financeira', reference: 'fin-natureza-financeira', fieldName: 'descricao' },
		{ source: 'periodo', label: 'Periodo' },
		{ source: 'valorOrcado', label: 'Valor Orcado' },
		{ source: 'valorRealizado', label: 'Valor Realizado' },
		{ source: 'taxaVariacao', label: 'Taxa Variacao' },
		{ source: 'valorVariacao', label: 'Valor Variacao' },
	];

	return (
		<CrudChildTab
			title="Itens"
			recordContext="orcamentoEmpresarial"
			fieldSource="orcamentoDetalheModelList"
			newObject={ OrcamentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};