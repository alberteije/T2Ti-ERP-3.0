/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { OrcamentoEmpresarialForm } from "./OrcamentoEmpresarialForm";
import { transformNestedData } from "../../infra/utils";

const OrcamentoEmpresarialCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<OrcamentoEmpresarialForm />
		</Create>
	);
};

export default OrcamentoEmpresarialCreate;