import OrcamentoPeriodoIcon from "@mui/icons-material/Apps";
import OrcamentoPeriodoList from "./OrcamentoPeriodoList";
import OrcamentoPeriodoCreate from "./OrcamentoPeriodoCreate";
import OrcamentoPeriodoEdit from "./OrcamentoPeriodoEdit";

export default {
	list: OrcamentoPeriodoList,
	create: OrcamentoPeriodoCreate,
	edit: OrcamentoPeriodoEdit,
	icon: OrcamentoPeriodoIcon,
};
