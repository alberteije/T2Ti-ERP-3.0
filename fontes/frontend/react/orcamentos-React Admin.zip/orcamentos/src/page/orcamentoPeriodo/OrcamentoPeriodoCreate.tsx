import {
	Create,
} from "react-admin";
import { OrcamentoPeriodoForm } from "./OrcamentoPeriodoForm";

const OrcamentoPeriodoCreate = () => {
	return (
		<Create>
			<OrcamentoPeriodoForm />
		</Create>
	);
};

export default OrcamentoPeriodoCreate;