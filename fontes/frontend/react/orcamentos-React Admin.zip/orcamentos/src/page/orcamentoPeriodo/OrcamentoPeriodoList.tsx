/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import OrcamentoPeriodoDomain from '../../data/domain/OrcamentoPeriodoDomain';

const OrcamentoPeriodoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["periodo","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OrcamentoPeriodoSmallScreenList : OrcamentoPeriodoBigScreenList;

	return (
		<List
			title="Períodos do Orçamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OrcamentoPeriodoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.periodo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const OrcamentoPeriodoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Periodo"
				render={record => OrcamentoPeriodoDomain.getPeriodo(record.periodo)}
			/>
			<TextField source="nome" label="Nome" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OrcamentoPeriodoList;
