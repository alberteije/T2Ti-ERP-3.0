import {
	Edit,
} from "react-admin";
import { OrcamentoPeriodoForm } from "./OrcamentoPeriodoForm";

const OrcamentoPeriodoEdit = () => {
	return (
		<Edit>
			<OrcamentoPeriodoForm />
		</Edit>
	);
};

export default OrcamentoPeriodoEdit;