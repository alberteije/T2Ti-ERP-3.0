import OrcamentoFluxoCaixaPeriodoIcon from "@mui/icons-material/Apps";
import OrcamentoFluxoCaixaPeriodoList from "./OrcamentoFluxoCaixaPeriodoList";
import OrcamentoFluxoCaixaPeriodoCreate from "./OrcamentoFluxoCaixaPeriodoCreate";
import OrcamentoFluxoCaixaPeriodoEdit from "./OrcamentoFluxoCaixaPeriodoEdit";

export default {
	list: OrcamentoFluxoCaixaPeriodoList,
	create: OrcamentoFluxoCaixaPeriodoCreate,
	edit: OrcamentoFluxoCaixaPeriodoEdit,
	icon: OrcamentoFluxoCaixaPeriodoIcon,
};
