import {
	Create,
} from "react-admin";
import { OrcamentoFluxoCaixaPeriodoForm } from "./OrcamentoFluxoCaixaPeriodoForm";

const OrcamentoFluxoCaixaPeriodoCreate = () => {
	return (
		<Create>
			<OrcamentoFluxoCaixaPeriodoForm />
		</Create>
	);
};

export default OrcamentoFluxoCaixaPeriodoCreate;