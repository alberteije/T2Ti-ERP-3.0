import {
	Edit,
} from "react-admin";
import { OrcamentoFluxoCaixaPeriodoForm } from "./OrcamentoFluxoCaixaPeriodoForm";

const OrcamentoFluxoCaixaPeriodoEdit = () => {
	return (
		<Edit>
			<OrcamentoFluxoCaixaPeriodoForm />
		</Edit>
	);
};

export default OrcamentoFluxoCaixaPeriodoEdit;