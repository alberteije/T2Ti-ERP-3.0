/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import OrcamentoFluxoCaixaPeriodoDomain from '../../data/domain/OrcamentoFluxoCaixaPeriodoDomain';

const OrcamentoFluxoCaixaPeriodoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["bancoContaCaixaModel.nome","periodo","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OrcamentoFluxoCaixaPeriodoSmallScreenList : OrcamentoFluxoCaixaPeriodoBigScreenList;

	return (
		<List
			title="Períodos - Fluxo de Caixa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OrcamentoFluxoCaixaPeriodoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.bancoContaCaixaModel.nome }
			secondaryText={ (record) => record.periodo }
			tertiaryText={ (record) => record.nome }
		/>
	);
}

const OrcamentoFluxoCaixaPeriodoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Banco Conta Caixa" source="bancoContaCaixaModel.id" reference="banco-conta-caixa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				label="Periodo"
				render={record => OrcamentoFluxoCaixaPeriodoDomain.getPeriodo(record.periodo)}
			/>
			<TextField source="nome" label="Nome" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OrcamentoFluxoCaixaPeriodoList;
