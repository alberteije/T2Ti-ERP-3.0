import FinTipoRecebimentoIcon from "@mui/icons-material/Apps";
import FinTipoRecebimentoList from "./FinTipoRecebimentoList";
import FinTipoRecebimentoCreate from "./FinTipoRecebimentoCreate";
import FinTipoRecebimentoEdit from "./FinTipoRecebimentoEdit";

export default {
	list: FinTipoRecebimentoList,
	create: FinTipoRecebimentoCreate,
	edit: FinTipoRecebimentoEdit,
	icon: FinTipoRecebimentoIcon,
};
