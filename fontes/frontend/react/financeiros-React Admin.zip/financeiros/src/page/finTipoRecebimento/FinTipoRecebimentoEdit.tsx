import {
	Edit,
} from "react-admin";
import { FinTipoRecebimentoForm } from "./FinTipoRecebimentoForm";

const FinTipoRecebimentoEdit = () => {
	return (
		<Edit>
			<FinTipoRecebimentoForm />
		</Edit>
	);
};

export default FinTipoRecebimentoEdit;