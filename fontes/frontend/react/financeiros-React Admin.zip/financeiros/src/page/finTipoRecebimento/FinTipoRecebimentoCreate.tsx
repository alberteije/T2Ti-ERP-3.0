import {
	Create,
} from "react-admin";
import { FinTipoRecebimentoForm } from "./FinTipoRecebimentoForm";

const FinTipoRecebimentoCreate = () => {
	return (
		<Create>
			<FinTipoRecebimentoForm />
		</Create>
	);
};

export default FinTipoRecebimentoCreate;