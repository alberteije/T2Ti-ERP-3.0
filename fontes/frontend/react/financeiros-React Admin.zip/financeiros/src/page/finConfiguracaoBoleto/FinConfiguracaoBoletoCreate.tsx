import {
	Create,
} from "react-admin";
import { FinConfiguracaoBoletoForm } from "./FinConfiguracaoBoletoForm";

const FinConfiguracaoBoletoCreate = () => {
	return (
		<Create>
			<FinConfiguracaoBoletoForm />
		</Create>
	);
};

export default FinConfiguracaoBoletoCreate;