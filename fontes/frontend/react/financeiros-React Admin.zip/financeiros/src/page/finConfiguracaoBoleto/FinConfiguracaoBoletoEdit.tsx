import {
	Edit,
} from "react-admin";
import { FinConfiguracaoBoletoForm } from "./FinConfiguracaoBoletoForm";

const FinConfiguracaoBoletoEdit = () => {
	return (
		<Edit>
			<FinConfiguracaoBoletoForm />
		</Edit>
	);
};

export default FinConfiguracaoBoletoEdit;