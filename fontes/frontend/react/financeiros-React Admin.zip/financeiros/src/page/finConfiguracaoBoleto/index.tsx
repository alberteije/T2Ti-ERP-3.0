import FinConfiguracaoBoletoIcon from "@mui/icons-material/Apps";
import FinConfiguracaoBoletoList from "./FinConfiguracaoBoletoList";
import FinConfiguracaoBoletoCreate from "./FinConfiguracaoBoletoCreate";
import FinConfiguracaoBoletoEdit from "./FinConfiguracaoBoletoEdit";

export default {
	list: FinConfiguracaoBoletoList,
	create: FinConfiguracaoBoletoCreate,
	edit: FinConfiguracaoBoletoEdit,
	icon: FinConfiguracaoBoletoIcon,
};
