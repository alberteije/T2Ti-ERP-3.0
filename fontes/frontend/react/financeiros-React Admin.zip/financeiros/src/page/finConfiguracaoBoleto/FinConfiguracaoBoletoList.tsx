/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FinConfiguracaoBoletoDomain from '../../data/domain/FinConfiguracaoBoletoDomain';

const FinConfiguracaoBoletoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["bancoContaCaixaModel.nome","instrucao01","instrucao02"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinConfiguracaoBoletoSmallScreenList : FinConfiguracaoBoletoBigScreenList;

	return (
		<List
			title="Configuracões Boleto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinConfiguracaoBoletoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.bancoContaCaixaModel.nome }
			secondaryText={ (record) => record.instrucao01 }
			tertiaryText={ (record) => record.instrucao02 }
		/>
	);
}

const FinConfiguracaoBoletoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Banco Conta Caixa" source="bancoContaCaixaModel.id" reference="banco-conta-caixa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="instrucao01" label="Instrucao01" />
			<TextField source="instrucao02" label="Instrucao02" />
			<TextField source="caminhoArquivoRemessa" label="Caminho Arquivo Remessa" />
			<TextField source="caminhoArquivoRetorno" label="Caminho Arquivo Retorno" />
			<TextField source="caminhoArquivoLogotipo" label="Caminho Arquivo Logotipo" />
			<TextField source="caminhoArquivoPdf" label="Caminho Arquivo Pdf" />
			<TextField source="mensagem" label="Mensagem" />
			<TextField source="localPagamento" label="Local Pagamento" />
			<FunctionField
				label="Layout Remessa"
				render={record => FinConfiguracaoBoletoDomain.getLayoutRemessa(record.layoutRemessa)}
			/>
			<FunctionField
				label="Aceite"
				render={record => FinConfiguracaoBoletoDomain.getAceite(record.aceite)}
			/>
			<FunctionField
				label="Especie"
				render={record => FinConfiguracaoBoletoDomain.getEspecie(record.especie)}
			/>
			<TextField source="carteira" label="Carteira" />
			<TextField source="codigoConvenio" label="Codigo Convenio" />
			<TextField source="codigoCedente" label="Codigo Cedente" />
			<NumberField source="taxaMulta" label="Taxa Multa" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaJuro" label="Taxa Juro" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="diasProtesto" label="Dias Protesto" />
			<TextField source="nossoNumeroAnterior" label="Nosso Numero Anterior" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinConfiguracaoBoletoList;
