import {
	Create,
} from "react-admin";
import { FinChequeEmitidoForm } from "./FinChequeEmitidoForm";

const FinChequeEmitidoCreate = () => {
	return (
		<Create>
			<FinChequeEmitidoForm />
		</Create>
	);
};

export default FinChequeEmitidoCreate;