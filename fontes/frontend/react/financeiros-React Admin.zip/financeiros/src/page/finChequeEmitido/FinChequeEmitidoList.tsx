/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FinChequeEmitidoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["chequeModel.numero","dataEmissao","bomPara"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinChequeEmitidoSmallScreenList : FinChequeEmitidoBigScreenList;

	return (
		<List
			title="Cheque Emitido"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinChequeEmitidoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.chequeModel.numero }
			secondaryText={ (record) => record.dataEmissao }
			tertiaryText={ (record) => record.bomPara }
		/>
	);
}

const FinChequeEmitidoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cheque" source="chequeModel.id" reference="cheque" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="bomPara" label="Bom Para" />
			<TextField source="dataCompensacao" label="Data Compensacao" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="nominalA" label="Nominal A" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinChequeEmitidoList;
