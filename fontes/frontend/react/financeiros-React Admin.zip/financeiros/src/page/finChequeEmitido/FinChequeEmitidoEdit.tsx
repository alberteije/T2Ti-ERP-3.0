import {
	Edit,
} from "react-admin";
import { FinChequeEmitidoForm } from "./FinChequeEmitidoForm";

const FinChequeEmitidoEdit = () => {
	return (
		<Edit>
			<FinChequeEmitidoForm />
		</Edit>
	);
};

export default FinChequeEmitidoEdit;