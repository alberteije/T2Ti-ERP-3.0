import FinChequeEmitidoIcon from "@mui/icons-material/Apps";
import FinChequeEmitidoList from "./FinChequeEmitidoList";
import FinChequeEmitidoCreate from "./FinChequeEmitidoCreate";
import FinChequeEmitidoEdit from "./FinChequeEmitidoEdit";

export default {
	list: FinChequeEmitidoList,
	create: FinChequeEmitidoCreate,
	edit: FinChequeEmitidoEdit,
	icon: FinChequeEmitidoIcon,
};
