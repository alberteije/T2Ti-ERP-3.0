/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { TalonarioChequeForm } from "./TalonarioChequeForm";
import { transformNestedData } from "../../infra/utils";

const TalonarioChequeEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<TalonarioChequeForm />
		</Edit>
	);
};

export default TalonarioChequeEdit;