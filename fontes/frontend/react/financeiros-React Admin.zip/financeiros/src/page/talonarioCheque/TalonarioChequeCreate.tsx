/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { TalonarioChequeForm } from "./TalonarioChequeForm";
import { transformNestedData } from "../../infra/utils";

const TalonarioChequeCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<TalonarioChequeForm />
		</Create>
	);
};

export default TalonarioChequeCreate;