/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import TalonarioChequeDomain from '../../data/domain/TalonarioChequeDomain';

const TalonarioChequeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["bancoContaCaixaModel.nome","talao","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TalonarioChequeSmallScreenList : TalonarioChequeBigScreenList;

	return (
		<List
			title="Talonário Cheque"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TalonarioChequeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.bancoContaCaixaModel.nome }
			secondaryText={ (record) => record.talao }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const TalonarioChequeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Banco Conta Caixa" source="bancoContaCaixaModel.id" reference="banco-conta-caixa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="talao" label="Talao" />
			<TextField source="numero" label="Numero" />
			<FunctionField
				label="Status Talao"
				render={record => TalonarioChequeDomain.getStatusTalao(record.statusTalao)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TalonarioChequeList;
