/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ChequeTab } from './ChequeTab';

export const TalonarioChequeForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Talonário Cheque">
				<TalonarioChequeTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Cheque">
				<ChequeTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const TalonarioChequeTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};