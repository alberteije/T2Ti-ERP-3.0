import TalonarioChequeIcon from "@mui/icons-material/Apps";
import TalonarioChequeList from "./TalonarioChequeList";
import TalonarioChequeCreate from "./TalonarioChequeCreate";
import TalonarioChequeEdit from "./TalonarioChequeEdit";

export default {
	list: TalonarioChequeList,
	create: TalonarioChequeCreate,
	edit: TalonarioChequeEdit,
	icon: TalonarioChequeIcon,
};
