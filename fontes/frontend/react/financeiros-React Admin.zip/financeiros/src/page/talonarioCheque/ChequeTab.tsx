/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import ChequeDomain from '../../data/domain/ChequeDomain';

class Cheque {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): Cheque {
		const cheque = new Cheque();
		cheque.id = Date.now();
		cheque.statusCrud = "C";
		return cheque;
	}
}

export const ChequeTab: React.FC = () => {

	const renderForm = (
		currentRecord: Cheque,
		setCurrentRecord: (record: Cheque) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numero', label: 'Numero' },
		{ source: 'statusCheque', label: 'Status', formatDomain: ChequeDomain.getStatusCheque },
		{ source: 'dataStatus', label: 'Data Status' },
	];

	return (
		<CrudChildTab
			title="Cheque"
			recordContext="talonarioCheque"
			fieldSource="chequeModelList"
			newObject={ Cheque.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};