import FinTipoPagamentoIcon from "@mui/icons-material/Apps";
import FinTipoPagamentoList from "./FinTipoPagamentoList";
import FinTipoPagamentoCreate from "./FinTipoPagamentoCreate";
import FinTipoPagamentoEdit from "./FinTipoPagamentoEdit";

export default {
	list: FinTipoPagamentoList,
	create: FinTipoPagamentoCreate,
	edit: FinTipoPagamentoEdit,
	icon: FinTipoPagamentoIcon,
};
