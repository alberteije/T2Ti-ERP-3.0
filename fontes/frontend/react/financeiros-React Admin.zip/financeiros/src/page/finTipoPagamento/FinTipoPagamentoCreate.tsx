import {
	Create,
} from "react-admin";
import { FinTipoPagamentoForm } from "./FinTipoPagamentoForm";

const FinTipoPagamentoCreate = () => {
	return (
		<Create>
			<FinTipoPagamentoForm />
		</Create>
	);
};

export default FinTipoPagamentoCreate;