import {
	Edit,
} from "react-admin";
import { FinTipoPagamentoForm } from "./FinTipoPagamentoForm";

const FinTipoPagamentoEdit = () => {
	return (
		<Edit>
			<FinTipoPagamentoForm />
		</Edit>
	);
};

export default FinTipoPagamentoEdit;