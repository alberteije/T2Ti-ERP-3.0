import {
	Create,
} from "react-admin";
import { FinStatusParcelaForm } from "./FinStatusParcelaForm";

const FinStatusParcelaCreate = () => {
	return (
		<Create>
			<FinStatusParcelaForm />
		</Create>
	);
};

export default FinStatusParcelaCreate;