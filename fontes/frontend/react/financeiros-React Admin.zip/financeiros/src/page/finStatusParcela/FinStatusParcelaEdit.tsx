import {
	Edit,
} from "react-admin";
import { FinStatusParcelaForm } from "./FinStatusParcelaForm";

const FinStatusParcelaEdit = () => {
	return (
		<Edit>
			<FinStatusParcelaForm />
		</Edit>
	);
};

export default FinStatusParcelaEdit;