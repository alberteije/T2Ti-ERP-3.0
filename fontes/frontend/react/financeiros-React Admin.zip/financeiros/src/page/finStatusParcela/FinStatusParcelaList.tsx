/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FinStatusParcelaDomain from '../../data/domain/FinStatusParcelaDomain';

const FinStatusParcelaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["situacao","descricao","procedimento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinStatusParcelaSmallScreenList : FinStatusParcelaBigScreenList;

	return (
		<List
			title="Status Parcela"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinStatusParcelaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.situacao }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.procedimento }
		/>
	);
}

const FinStatusParcelaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Situacao"
				render={record => FinStatusParcelaDomain.getSituacao(record.situacao)}
			/>
			<TextField source="descricao" label="Descricao" />
			<TextField source="procedimento" label="Procedimento" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinStatusParcelaList;
