import FinStatusParcelaIcon from "@mui/icons-material/Apps";
import FinStatusParcelaList from "./FinStatusParcelaList";
import FinStatusParcelaCreate from "./FinStatusParcelaCreate";
import FinStatusParcelaEdit from "./FinStatusParcelaEdit";

export default {
	list: FinStatusParcelaList,
	create: FinStatusParcelaCreate,
	edit: FinStatusParcelaEdit,
	icon: FinStatusParcelaIcon,
};
