import FinChequeRecebidoIcon from "@mui/icons-material/Apps";
import FinChequeRecebidoList from "./FinChequeRecebidoList";
import FinChequeRecebidoCreate from "./FinChequeRecebidoCreate";
import FinChequeRecebidoEdit from "./FinChequeRecebidoEdit";

export default {
	list: FinChequeRecebidoList,
	create: FinChequeRecebidoCreate,
	edit: FinChequeRecebidoEdit,
	icon: FinChequeRecebidoIcon,
};
