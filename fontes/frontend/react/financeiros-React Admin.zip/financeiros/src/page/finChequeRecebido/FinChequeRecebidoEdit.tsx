import {
	Edit,
} from "react-admin";
import { FinChequeRecebidoForm } from "./FinChequeRecebidoForm";

const FinChequeRecebidoEdit = () => {
	return (
		<Edit>
			<FinChequeRecebidoForm />
		</Edit>
	);
};

export default FinChequeRecebidoEdit;