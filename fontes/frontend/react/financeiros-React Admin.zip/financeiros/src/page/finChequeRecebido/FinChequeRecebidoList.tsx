/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FinChequeRecebidoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaClienteModel.nome","cpf","cnpj"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinChequeRecebidoSmallScreenList : FinChequeRecebidoBigScreenList;

	return (
		<List
			title="Cheque Recebido"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinChequeRecebidoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaClienteModel.nome }
			secondaryText={ (record) => record.cpf }
			tertiaryText={ (record) => record.cnpj }
		/>
	);
}

const FinChequeRecebidoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				source="cpf"
				label="Cpf"
				render={record => formatWithMask(record.cpf, '###.###.###-##')}
			/>
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<TextField source="nome" label="Nome" />
			<TextField source="codigoBanco" label="Codigo Banco" />
			<TextField source="codigoAgencia" label="Codigo Agencia" />
			<TextField source="conta" label="Conta" />
			<TextField source="numero" label="Numero" />
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="bomPara" label="Bom Para" />
			<TextField source="dataCompensacao" label="Data Compensacao" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="custodiaData" label="Custodia Data" />
			<NumberField source="custodiaTarifa" label="Custodia Tarifa" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="custodiaComissao" label="Custodia Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="descontoData" label="Desconto Data" />
			<NumberField source="descontoTarifa" label="Desconto Tarifa" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="descontoComissao" label="Desconto Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorRecebido" label="Valor Recebido" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinChequeRecebidoList;
