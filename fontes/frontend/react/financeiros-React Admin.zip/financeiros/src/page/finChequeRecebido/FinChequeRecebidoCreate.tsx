import {
	Create,
} from "react-admin";
import { FinChequeRecebidoForm } from "./FinChequeRecebidoForm";

const FinChequeRecebidoCreate = () => {
	return (
		<Create>
			<FinChequeRecebidoForm />
		</Create>
	);
};

export default FinChequeRecebidoCreate;