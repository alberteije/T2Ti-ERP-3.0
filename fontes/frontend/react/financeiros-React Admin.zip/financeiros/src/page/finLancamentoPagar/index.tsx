import FinLancamentoPagarIcon from "@mui/icons-material/Apps";
import FinLancamentoPagarList from "./FinLancamentoPagarList";
import FinLancamentoPagarCreate from "./FinLancamentoPagarCreate";
import FinLancamentoPagarEdit from "./FinLancamentoPagarEdit";

export default {
	list: FinLancamentoPagarList,
	create: FinLancamentoPagarCreate,
	edit: FinLancamentoPagarEdit,
	icon: FinLancamentoPagarIcon,
};
