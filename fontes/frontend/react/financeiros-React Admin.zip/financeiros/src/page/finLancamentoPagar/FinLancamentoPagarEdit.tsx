/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FinLancamentoPagarForm } from "./FinLancamentoPagarForm";
import { transformNestedData } from "../../infra/utils";

const FinLancamentoPagarEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FinLancamentoPagarForm />
		</Edit>
	);
};

export default FinLancamentoPagarEdit;