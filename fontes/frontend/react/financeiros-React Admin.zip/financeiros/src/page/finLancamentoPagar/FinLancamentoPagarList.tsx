/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FinLancamentoPagarList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaFornecedorModel.nome","bancoContaCaixaModel.nome","finDocumentoOrigemModel.sigla"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinLancamentoPagarSmallScreenList : FinLancamentoPagarBigScreenList;

	return (
		<List
			title="Lançamento a Pagar"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinLancamentoPagarSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaFornecedorModel.nome }
			secondaryText={ (record) => record.bancoContaCaixaModel.nome }
			tertiaryText={ (record) => record.finDocumentoOrigemModel.sigla }
		/>
	);
}

const FinLancamentoPagarBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Fornecedor" source="viewPessoaFornecedorModel.id" reference="view-pessoa-fornecedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Banco Conta Caixa" source="bancoContaCaixaModel.id" reference="banco-conta-caixa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fin Documento Origem" source="finDocumentoOrigemModel.id" reference="fin-documento-origem" sortable={false}>
				<TextField source="sigla" />
			</ReferenceField>
			<ReferenceField label="Id Fin Natureza Financeira" source="finNaturezaFinanceiraModel.id" reference="fin-natureza-financeira" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="quantidadeParcela" label="Quantidade Parcela" />
			<NumberField source="valorAPagar" label="Valor A Pagar" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataLancamento" label="Data Lancamento" />
			<TextField source="numeroDocumento" label="Numero Documento" />
			<TextField source="primeiroVencimento" label="Primeiro Vencimento" />
			<TextField source="intervaloEntreParcelas" label="Intervalo Entre Parcelas" />
			<TextField source="diaFixo" label="Dia Fixo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinLancamentoPagarList;
