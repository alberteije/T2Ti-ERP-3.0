/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FinParcelaPagar {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FinParcelaPagar {
		const finParcelaPagar = new FinParcelaPagar();
		finParcelaPagar.id = Date.now();
		finParcelaPagar.statusCrud = "C";
		return finParcelaPagar;
	}
}

export const FinParcelaPagarTab: React.FC = () => {

	const renderForm = (
		currentRecord: FinParcelaPagar,
		setCurrentRecord: (record: FinParcelaPagar) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finStatusParcelaModel.id', label: 'Status Parcela', reference: 'fin-status-parcela', fieldName: 'descricao' },
		{ source: 'finTipoPagamentoModel.id', label: 'Tipo Pagamento', reference: 'fin-tipo-pagamento', fieldName: 'descricao' },
		{ source: 'numeroParcela', label: 'Numero Parcela' },
		{ source: 'dataEmissao', label: 'Data Emissao' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'dataPagamento', label: 'Data Pagamento' },
		{ source: 'descontoAte', label: 'Desconto Ate' },
		{ source: 'valor', label: 'Valor' },
		{ source: 'taxaJuro', label: 'Taxa Juro' },
		{ source: 'taxaMulta', label: 'Taxa Multa' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorJuro', label: 'Valor Juro' },
		{ source: 'valorMulta', label: 'Valor Multa' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorPago', label: 'Valor Pago' },
		{ source: 'historico', label: 'Historico' },
	];

	return (
		<CrudChildTab
			title="Parcelas"
			recordContext="finLancamentoPagar"
			fieldSource="finParcelaPagarModelList"
			newObject={ FinParcelaPagar.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};