/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FinLancamentoPagarForm } from "./FinLancamentoPagarForm";
import { transformNestedData } from "../../infra/utils";

const FinLancamentoPagarCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FinLancamentoPagarForm />
		</Create>
	);
};

export default FinLancamentoPagarCreate;