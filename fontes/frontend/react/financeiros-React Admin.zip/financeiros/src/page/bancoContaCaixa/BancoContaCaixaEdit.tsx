import {
	Edit,
} from "react-admin";
import { BancoContaCaixaForm } from "./BancoContaCaixaForm";

const BancoContaCaixaEdit = () => {
	return (
		<Edit>
			<BancoContaCaixaForm />
		</Edit>
	);
};

export default BancoContaCaixaEdit;