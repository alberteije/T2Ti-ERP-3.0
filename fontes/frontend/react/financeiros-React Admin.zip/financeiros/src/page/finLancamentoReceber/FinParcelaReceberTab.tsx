/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FinParcelaReceberDomain from '../../data/domain/FinParcelaReceberDomain';

class FinParcelaReceber {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FinParcelaReceber {
		const finParcelaReceber = new FinParcelaReceber();
		finParcelaReceber.id = Date.now();
		finParcelaReceber.statusCrud = "C";
		return finParcelaReceber;
	}
}

export const FinParcelaReceberTab: React.FC = () => {

	const renderForm = (
		currentRecord: FinParcelaReceber,
		setCurrentRecord: (record: FinParcelaReceber) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finStatusParcelaModel.id', label: 'Status Parcela', reference: 'fin-status-parcela', fieldName: 'descricao' },
		{ source: 'finTipoRecebimentoModel.id', label: 'Tipo Recebimento', reference: 'fin-tipo-recebimento', fieldName: 'descricao' },
		{ source: 'numeroParcela', label: 'Numero Parcela' },
		{ source: 'dataEmissao', label: 'Data Emissao' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'dataRecebimento', label: 'Data Recebimento' },
		{ source: 'descontoAte', label: 'Desconto Ate' },
		{ source: 'valor', label: 'Valor' },
		{ source: 'taxaJuro', label: 'Taxa Juro' },
		{ source: 'taxaMulta', label: 'Taxa Multa' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorJuro', label: 'Valor Juro' },
		{ source: 'valorMulta', label: 'Valor Multa' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'emitiuBoleto', label: 'Emitiu Boleto', formatDomain: FinParcelaReceberDomain.getEmitiuBoleto },
		{ source: 'boletoNossoNumero', label: 'Boleto Nosso Numero' },
		{ source: 'valorRecebido', label: 'Valor Recebido' },
		{ source: 'historico', label: 'Historico' },
	];

	return (
		<CrudChildTab
			title="Parcelas"
			recordContext="finLancamentoReceber"
			fieldSource="finParcelaReceberModelList"
			newObject={ FinParcelaReceber.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};