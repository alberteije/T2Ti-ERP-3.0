/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FinLancamentoReceberList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaClienteModel.nome","bancoContaCaixaModel.nome","finDocumentoOrigemModel.sigla"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinLancamentoReceberSmallScreenList : FinLancamentoReceberBigScreenList;

	return (
		<List
			title="Lançamento a Receber"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinLancamentoReceberSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaClienteModel.nome }
			secondaryText={ (record) => record.bancoContaCaixaModel.nome }
			tertiaryText={ (record) => record.finDocumentoOrigemModel.sigla }
		/>
	);
}

const FinLancamentoReceberBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Banco Conta Caixa" source="bancoContaCaixaModel.id" reference="banco-conta-caixa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fin Documento Origem" source="finDocumentoOrigemModel.id" reference="fin-documento-origem" sortable={false}>
				<TextField source="sigla" />
			</ReferenceField>
			<ReferenceField label="Id Fin Natureza Financeira" source="finNaturezaFinanceiraModel.id" reference="fin-natureza-financeira" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="quantidadeParcela" label="Quantidade Parcela" />
			<NumberField source="valorAReceber" label="Valor A Receber" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataLancamento" label="Data Lancamento" />
			<TextField source="numeroDocumento" label="Numero Documento" />
			<TextField source="primeiroVencimento" label="Primeiro Vencimento" />
			<NumberField source="taxaComissao" label="Taxa Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorComissao" label="Valor Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="intervaloEntreParcelas" label="Intervalo Entre Parcelas" />
			<TextField source="diaFixo" label="Dia Fixo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinLancamentoReceberList;
