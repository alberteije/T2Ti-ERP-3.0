import FinLancamentoReceberIcon from "@mui/icons-material/Apps";
import FinLancamentoReceberList from "./FinLancamentoReceberList";
import FinLancamentoReceberCreate from "./FinLancamentoReceberCreate";
import FinLancamentoReceberEdit from "./FinLancamentoReceberEdit";

export default {
	list: FinLancamentoReceberList,
	create: FinLancamentoReceberCreate,
	edit: FinLancamentoReceberEdit,
	icon: FinLancamentoReceberIcon,
};
