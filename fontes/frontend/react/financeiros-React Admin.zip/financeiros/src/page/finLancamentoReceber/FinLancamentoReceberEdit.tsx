/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FinLancamentoReceberForm } from "./FinLancamentoReceberForm";
import { transformNestedData } from "../../infra/utils";

const FinLancamentoReceberEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FinLancamentoReceberForm />
		</Edit>
	);
};

export default FinLancamentoReceberEdit;