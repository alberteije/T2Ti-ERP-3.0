/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FinLancamentoReceberForm } from "./FinLancamentoReceberForm";
import { transformNestedData } from "../../infra/utils";

const FinLancamentoReceberCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FinLancamentoReceberForm />
		</Create>
	);
};

export default FinLancamentoReceberCreate;