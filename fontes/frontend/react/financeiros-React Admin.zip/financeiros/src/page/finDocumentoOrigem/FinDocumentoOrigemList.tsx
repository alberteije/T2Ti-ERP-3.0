/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FinDocumentoOrigemList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","sigla","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinDocumentoOrigemSmallScreenList : FinDocumentoOrigemBigScreenList;

	return (
		<List
			title="Documento Origem"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinDocumentoOrigemSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.sigla }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const FinDocumentoOrigemBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<TextField source="sigla" label="Sigla" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinDocumentoOrigemList;
