import {
	Edit,
} from "react-admin";
import { FinDocumentoOrigemForm } from "./FinDocumentoOrigemForm";

const FinDocumentoOrigemEdit = () => {
	return (
		<Edit>
			<FinDocumentoOrigemForm />
		</Edit>
	);
};

export default FinDocumentoOrigemEdit;