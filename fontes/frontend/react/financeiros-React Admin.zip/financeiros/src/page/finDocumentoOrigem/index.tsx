import FinDocumentoOrigemIcon from "@mui/icons-material/Apps";
import FinDocumentoOrigemList from "./FinDocumentoOrigemList";
import FinDocumentoOrigemCreate from "./FinDocumentoOrigemCreate";
import FinDocumentoOrigemEdit from "./FinDocumentoOrigemEdit";

export default {
	list: FinDocumentoOrigemList,
	create: FinDocumentoOrigemCreate,
	edit: FinDocumentoOrigemEdit,
	icon: FinDocumentoOrigemIcon,
};
