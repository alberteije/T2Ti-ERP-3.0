import {
	Create,
} from "react-admin";
import { FinDocumentoOrigemForm } from "./FinDocumentoOrigemForm";

const FinDocumentoOrigemCreate = () => {
	return (
		<Create>
			<FinDocumentoOrigemForm />
		</Create>
	);
};

export default FinDocumentoOrigemCreate;