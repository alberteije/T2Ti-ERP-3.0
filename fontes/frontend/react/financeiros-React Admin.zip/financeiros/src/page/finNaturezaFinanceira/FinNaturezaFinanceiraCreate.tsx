import {
	Create,
} from "react-admin";
import { FinNaturezaFinanceiraForm } from "./FinNaturezaFinanceiraForm";

const FinNaturezaFinanceiraCreate = () => {
	return (
		<Create>
			<FinNaturezaFinanceiraForm />
		</Create>
	);
};

export default FinNaturezaFinanceiraCreate;