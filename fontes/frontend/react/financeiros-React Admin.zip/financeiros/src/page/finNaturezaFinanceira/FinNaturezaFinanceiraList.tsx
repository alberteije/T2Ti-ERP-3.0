/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FinNaturezaFinanceiraDomain from '../../data/domain/FinNaturezaFinanceiraDomain';

const FinNaturezaFinanceiraList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","tipo","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FinNaturezaFinanceiraSmallScreenList : FinNaturezaFinanceiraBigScreenList;

	return (
		<List
			title="Natureza Financeira"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FinNaturezaFinanceiraSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.tipo }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const FinNaturezaFinanceiraBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<FunctionField
				label="Tipo"
				render={record => FinNaturezaFinanceiraDomain.getTipo(record.tipo)}
			/>
			<TextField source="descricao" label="Descricao" />
			<TextField source="aplicacao" label="Aplicacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FinNaturezaFinanceiraList;
