import FinNaturezaFinanceiraIcon from "@mui/icons-material/Apps";
import FinNaturezaFinanceiraList from "./FinNaturezaFinanceiraList";
import FinNaturezaFinanceiraCreate from "./FinNaturezaFinanceiraCreate";
import FinNaturezaFinanceiraEdit from "./FinNaturezaFinanceiraEdit";

export default {
	list: FinNaturezaFinanceiraList,
	create: FinNaturezaFinanceiraCreate,
	edit: FinNaturezaFinanceiraEdit,
	icon: FinNaturezaFinanceiraIcon,
};
