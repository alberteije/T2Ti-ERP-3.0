import {
	Edit,
} from "react-admin";
import { FinNaturezaFinanceiraForm } from "./FinNaturezaFinanceiraForm";

const FinNaturezaFinanceiraEdit = () => {
	return (
		<Edit>
			<FinNaturezaFinanceiraForm />
		</Edit>
	);
};

export default FinNaturezaFinanceiraEdit;