import { TranslationMessages } from 'react-admin';
import ptBrMessages from 'ra-language-pt-br';

const customPtBrMessages: TranslationMessages = {
	...ptBrMessages,
	ra: {
		...ptBrMessages.ra,
		configurable: {
			...ptBrMessages.ra.configurable,
			customize: 'Personalizar',
		},
	},
	dialogs: {
		confirm_delete_title: 'Confirmar Exclusão',
		confirm_delete_body: 'Tem certeza de que deseja excluir este endereço?',
		snackbar_delete_message: 'A exclusão será confirmada após o salvamento do registro.',
	},
	general: {
		adding: 'Adicionando...',
		editing: 'Editando...',
	},
	dashboard: {
		welcome: {
			title: 'Bem-vindo ao MVP gerado pelo Vycanis usando o react-admin',
			subtitle: 'Gere um dos servidores disponíveis no Vycanis para ver seu sistema funcionando. Acesse o site do Vycanis Modeler para mais ajuda e o site do react-admin para aprender a trabalhar com ele.',
			ra_button: 'Site do react-admin',
			vycanis_button: 'Site do Vycanis',
		},
		orders: {
			monthly_revenue: 'Receita Mensal',
			new_orders: 'Novas Ordens',
			month_history: 'Receitas - Histórico de 30 dias',
			pending_orders: 'Ordens Pendentes',
			items: 'cliente: nonono, one item |||| cliente: nonono, %{nb_items} items',
			last_reviews: 'Últimas Avaliações',
			all_reviews: 'Ver todas as avaliações',
			new_customers: 'Novos clientes',
			all_customers: 'Ver todos os clientes',
		}
	},
	menu: {
		single_page: 'Telas Simples',
		master_page: 'Telas Agrupadas',
	},
	login_screen: {
		hint: 'Dica'
	}
};

export default customPtBrMessages;