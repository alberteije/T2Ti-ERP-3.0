import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import talonarioCheque from '../page/talonarioCheque';
import finLancamentoPagar from '../page/finLancamentoPagar';
import finLancamentoReceber from '../page/finLancamentoReceber';
import bancoContaCaixa from '../page/bancoContaCaixa';
import finDocumentoOrigem from '../page/finDocumentoOrigem';
import finNaturezaFinanceira from '../page/finNaturezaFinanceira';
import finStatusParcela from '../page/finStatusParcela';
import finTipoPagamento from '../page/finTipoPagamento';
import finChequeEmitido from '../page/finChequeEmitido';
import finTipoRecebimento from '../page/finTipoRecebimento';
import finChequeRecebido from '../page/finChequeRecebido';
import finConfiguracaoBoleto from '../page/finConfiguracaoBoleto';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/banco-conta-caixa'
					state={{ _scrollToTop: true }}
					primaryText='Conta/Caixa'
					leftIcon={<bancoContaCaixa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-documento-origem'
					state={{ _scrollToTop: true }}
					primaryText='Documento Origem'
					leftIcon={<finDocumentoOrigem.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-natureza-financeira'
					state={{ _scrollToTop: true }}
					primaryText='Natureza Financeira'
					leftIcon={<finNaturezaFinanceira.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-status-parcela'
					state={{ _scrollToTop: true }}
					primaryText='Status Parcela'
					leftIcon={<finStatusParcela.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-tipo-pagamento'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Pagamento'
					leftIcon={<finTipoPagamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-cheque-emitido'
					state={{ _scrollToTop: true }}
					primaryText='Cheque Emitido'
					leftIcon={<finChequeEmitido.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-tipo-recebimento'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Recebimento'
					leftIcon={<finTipoRecebimento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-cheque-recebido'
					state={{ _scrollToTop: true }}
					primaryText='Cheque Recebido'
					leftIcon={<finChequeRecebido.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-configuracao-boleto'
					state={{ _scrollToTop: true }}
					primaryText='Configuracões Boleto'
					leftIcon={<finConfiguracaoBoleto.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/talonario-cheque'
					state={{ _scrollToTop: true }}
					primaryText='Talonário Cheque'
					leftIcon={<talonarioCheque.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-lancamento-pagar'
					state={{ _scrollToTop: true }}
					primaryText='Lançamento a Pagar'
					leftIcon={<finLancamentoPagar.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fin-lancamento-receber'
					state={{ _scrollToTop: true }}
					primaryText='Lançamento a Receber'
					leftIcon={<finLancamentoReceber.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
