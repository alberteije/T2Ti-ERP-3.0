class BancoContaCaixaDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'C': 
				return 'Corrente'; 
			case 'P': 
				return 'Poupança'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Corrente': 
				return 'C'; 
			case 'Poupança': 
				return 'P'; 
			default: 
				return null; 
		} 
	}

}

export default BancoContaCaixaDomain;