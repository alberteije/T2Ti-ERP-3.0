class FinParcelaReceberDomain {
	static getEmitiuBoleto(emitiuBoleto: string) { 
		switch (emitiuBoleto) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setEmitiuBoleto(emitiuBoleto: string) { 
		switch (emitiuBoleto) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FinParcelaReceberDomain;