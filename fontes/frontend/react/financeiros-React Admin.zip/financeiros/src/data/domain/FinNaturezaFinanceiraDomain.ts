class FinNaturezaFinanceiraDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'R': 
				return 'Receita'; 
			case 'D': 
				return 'Despesa'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Receita': 
				return 'R'; 
			case 'Despesa': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

}

export default FinNaturezaFinanceiraDomain;