class FinExtratoContaBancoDomain {
	static getConciliado(conciliado: string) { 
		switch (conciliado) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setConciliado(conciliado: string) { 
		switch (conciliado) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FinExtratoContaBancoDomain;