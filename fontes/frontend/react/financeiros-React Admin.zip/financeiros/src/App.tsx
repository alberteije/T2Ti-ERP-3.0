import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import talonarioCheque from './page/talonarioCheque';
import finLancamentoPagar from './page/finLancamentoPagar';
import finLancamentoReceber from './page/finLancamentoReceber';
import bancoContaCaixa from './page/bancoContaCaixa';
import finDocumentoOrigem from './page/finDocumentoOrigem';
import finNaturezaFinanceira from './page/finNaturezaFinanceira';
import finStatusParcela from './page/finStatusParcela';
import finTipoPagamento from './page/finTipoPagamento';
import finChequeEmitido from './page/finChequeEmitido';
import finTipoRecebimento from './page/finTipoRecebimento';
import finChequeRecebido from './page/finChequeRecebido';
import finConfiguracaoBoleto from './page/finConfiguracaoBoleto';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'financeiros');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Financeiro (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='talonario-cheque' {...talonarioCheque} options={{ label: 'Talonário Cheque' }} />
			<Resource name='fin-lancamento-pagar' {...finLancamentoPagar} options={{ label: 'Lançamento a Pagar' }} />
			<Resource name='fin-lancamento-receber' {...finLancamentoReceber} options={{ label: 'Lançamento a Receber' }} />
			<Resource name='banco-conta-caixa' {...bancoContaCaixa} options={{ label: 'Conta/Caixa' }} />
			<Resource name='fin-documento-origem' {...finDocumentoOrigem} options={{ label: 'Documento Origem' }} />
			<Resource name='fin-natureza-financeira' {...finNaturezaFinanceira} options={{ label: 'Natureza Financeira' }} />
			<Resource name='fin-status-parcela' {...finStatusParcela} options={{ label: 'Status Parcela' }} />
			<Resource name='fin-tipo-pagamento' {...finTipoPagamento} options={{ label: 'Tipo Pagamento' }} />
			<Resource name='fin-cheque-emitido' {...finChequeEmitido} options={{ label: 'Cheque Emitido' }} />
			<Resource name='fin-tipo-recebimento' {...finTipoRecebimento} options={{ label: 'Tipo Recebimento' }} />
			<Resource name='fin-cheque-recebido' {...finChequeRecebido} options={{ label: 'Cheque Recebido' }} />
			<Resource name='fin-configuracao-boleto' {...finConfiguracaoBoleto} options={{ label: 'Configuracões Boleto' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;