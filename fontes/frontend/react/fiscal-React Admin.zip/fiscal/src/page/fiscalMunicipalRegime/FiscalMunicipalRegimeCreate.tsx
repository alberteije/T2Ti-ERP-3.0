import {
	Create,
} from "react-admin";
import { FiscalMunicipalRegimeForm } from "./FiscalMunicipalRegimeForm";

const FiscalMunicipalRegimeCreate = () => {
	return (
		<Create>
			<FiscalMunicipalRegimeForm />
		</Create>
	);
};

export default FiscalMunicipalRegimeCreate;