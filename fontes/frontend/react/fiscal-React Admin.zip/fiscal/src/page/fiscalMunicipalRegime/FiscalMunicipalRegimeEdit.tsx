import {
	Edit,
} from "react-admin";
import { FiscalMunicipalRegimeForm } from "./FiscalMunicipalRegimeForm";

const FiscalMunicipalRegimeEdit = () => {
	return (
		<Edit>
			<FiscalMunicipalRegimeForm />
		</Edit>
	);
};

export default FiscalMunicipalRegimeEdit;