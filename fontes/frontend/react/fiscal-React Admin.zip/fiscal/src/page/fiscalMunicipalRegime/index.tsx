import FiscalMunicipalRegimeIcon from "@mui/icons-material/Apps";
import FiscalMunicipalRegimeList from "./FiscalMunicipalRegimeList";
import FiscalMunicipalRegimeCreate from "./FiscalMunicipalRegimeCreate";
import FiscalMunicipalRegimeEdit from "./FiscalMunicipalRegimeEdit";

export default {
	list: FiscalMunicipalRegimeList,
	create: FiscalMunicipalRegimeCreate,
	edit: FiscalMunicipalRegimeEdit,
	icon: FiscalMunicipalRegimeIcon,
};
