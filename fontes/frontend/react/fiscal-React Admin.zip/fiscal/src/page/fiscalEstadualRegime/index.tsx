import FiscalEstadualRegimeIcon from "@mui/icons-material/Apps";
import FiscalEstadualRegimeList from "./FiscalEstadualRegimeList";
import FiscalEstadualRegimeCreate from "./FiscalEstadualRegimeCreate";
import FiscalEstadualRegimeEdit from "./FiscalEstadualRegimeEdit";

export default {
	list: FiscalEstadualRegimeList,
	create: FiscalEstadualRegimeCreate,
	edit: FiscalEstadualRegimeEdit,
	icon: FiscalEstadualRegimeIcon,
};
