import {
	Create,
} from "react-admin";
import { FiscalEstadualRegimeForm } from "./FiscalEstadualRegimeForm";

const FiscalEstadualRegimeCreate = () => {
	return (
		<Create>
			<FiscalEstadualRegimeForm />
		</Create>
	);
};

export default FiscalEstadualRegimeCreate;