import {
	Edit,
} from "react-admin";
import { FiscalEstadualRegimeForm } from "./FiscalEstadualRegimeForm";

const FiscalEstadualRegimeEdit = () => {
	return (
		<Edit>
			<FiscalEstadualRegimeForm />
		</Edit>
	);
};

export default FiscalEstadualRegimeEdit;