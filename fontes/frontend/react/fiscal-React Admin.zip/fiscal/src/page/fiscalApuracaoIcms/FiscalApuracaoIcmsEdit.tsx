import {
	Edit,
} from "react-admin";
import { FiscalApuracaoIcmsForm } from "./FiscalApuracaoIcmsForm";

const FiscalApuracaoIcmsEdit = () => {
	return (
		<Edit>
			<FiscalApuracaoIcmsForm />
		</Edit>
	);
};

export default FiscalApuracaoIcmsEdit;