/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FiscalApuracaoIcmsList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["competencia","valorTotalDebito","valorAjusteDebito"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalApuracaoIcmsSmallScreenList : FiscalApuracaoIcmsBigScreenList;

	return (
		<List
			title="Apuração do ICMS"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalApuracaoIcmsSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.competencia }
			secondaryText={ (record) => record.valorTotalDebito }
			tertiaryText={ (record) => record.valorAjusteDebito }
		/>
	);
}

const FiscalApuracaoIcmsBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<NumberField source="valorTotalDebito" label="Valor Total Debito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorAjusteDebito" label="Valor Ajuste Debito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalAjusteDebito" label="Valor Total Ajuste Debito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorEstornoCredito" label="Valor Estorno Credito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalCredito" label="Valor Total Credito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorAjusteCredito" label="Valor Ajuste Credito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalAjusteCredito" label="Valor Total Ajuste Credito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorEstornoDebito" label="Valor Estorno Debito" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSaldoCredorAnterior" label="Valor Saldo Credor Anterior" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSaldoApurado" label="Valor Saldo Apurado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalDeducao" label="Valor Total Deducao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsRecolher" label="Valor Icms Recolher" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSaldoCredorTransp" label="Valor Saldo Credor Transp" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDebitoEspecial" label="Valor Debito Especial" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalApuracaoIcmsList;
