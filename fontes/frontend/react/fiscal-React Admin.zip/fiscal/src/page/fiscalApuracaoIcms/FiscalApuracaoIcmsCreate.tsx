import {
	Create,
} from "react-admin";
import { FiscalApuracaoIcmsForm } from "./FiscalApuracaoIcmsForm";

const FiscalApuracaoIcmsCreate = () => {
	return (
		<Create>
			<FiscalApuracaoIcmsForm />
		</Create>
	);
};

export default FiscalApuracaoIcmsCreate;