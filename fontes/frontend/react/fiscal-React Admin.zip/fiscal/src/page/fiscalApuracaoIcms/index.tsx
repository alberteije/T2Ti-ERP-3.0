import FiscalApuracaoIcmsIcon from "@mui/icons-material/Apps";
import FiscalApuracaoIcmsList from "./FiscalApuracaoIcmsList";
import FiscalApuracaoIcmsCreate from "./FiscalApuracaoIcmsCreate";
import FiscalApuracaoIcmsEdit from "./FiscalApuracaoIcmsEdit";

export default {
	list: FiscalApuracaoIcmsList,
	create: FiscalApuracaoIcmsCreate,
	edit: FiscalApuracaoIcmsEdit,
	icon: FiscalApuracaoIcmsIcon,
};
