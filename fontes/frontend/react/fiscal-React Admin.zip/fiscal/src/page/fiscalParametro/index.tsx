import FiscalParametroIcon from "@mui/icons-material/Apps";
import FiscalParametroList from "./FiscalParametroList";
import FiscalParametroCreate from "./FiscalParametroCreate";
import FiscalParametroEdit from "./FiscalParametroEdit";

export default {
	list: FiscalParametroList,
	create: FiscalParametroCreate,
	edit: FiscalParametroEdit,
	icon: FiscalParametroIcon,
};
