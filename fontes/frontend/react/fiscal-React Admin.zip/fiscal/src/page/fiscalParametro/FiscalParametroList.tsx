/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import FiscalParametroDomain from '../../data/domain/FiscalParametroDomain';

const FiscalParametroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["fiscalEstadualPorteModel.nome","fiscalEstadualRegimeModel.nome","fiscalMunicipalRegimeModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalParametroSmallScreenList : FiscalParametroBigScreenList;

	return (
		<List
			title="Parâmetros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalParametroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.fiscalEstadualPorteModel.nome }
			secondaryText={ (record) => record.fiscalEstadualRegimeModel.nome }
			tertiaryText={ (record) => record.fiscalMunicipalRegimeModel.nome }
		/>
	);
}

const FiscalParametroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Fiscal Estadual Porte" source="fiscalEstadualPorteModel.id" reference="fiscal-estadual-porte" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fiscal Estadual Regime" source="fiscalEstadualRegimeModel.id" reference="fiscal-estadual-regime" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fiscal Municipal Regime" source="fiscalMunicipalRegimeModel.id" reference="fiscal-municipal-regime" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				source="vigencia"
				label="Vigencia"
				render={record => formatWithMask(record.vigencia, '##/####')}
			/>
			<TextField source="descricaoVigencia" label="Descricao Vigencia" />
			<FunctionField
				label="Criterio Lancamento"
				render={record => FiscalParametroDomain.getCriterioLancamento(record.criterioLancamento)}
			/>
			<FunctionField
				label="Apuracao"
				render={record => FiscalParametroDomain.getApuracao(record.apuracao)}
			/>
			<FunctionField
				label="Microempree Individual"
				render={record => FiscalParametroDomain.getMicroempreeIndividual(record.microempreeIndividual)}
			/>
			<FunctionField
				label="Calc Pis Cofins Efd"
				render={record => FiscalParametroDomain.getCalcPisCofinsEfd(record.calcPisCofinsEfd)}
			/>
			<TextField source="simplesCodigoAcesso" label="Simples Codigo Acesso" />
			<FunctionField
				label="Simples Tabela"
				render={record => FiscalParametroDomain.getSimplesTabela(record.simplesTabela)}
			/>
			<FunctionField
				label="Simples Atividade"
				render={record => FiscalParametroDomain.getSimplesAtividade(record.simplesAtividade)}
			/>
			<FunctionField
				label="Perfil Sped"
				render={record => FiscalParametroDomain.getPerfilSped(record.perfilSped)}
			/>
			<FunctionField
				label="Apuracao Consolidada"
				render={record => FiscalParametroDomain.getApuracaoConsolidada(record.apuracaoConsolidada)}
			/>
			<FunctionField
				label="Substituicao Tributaria"
				render={record => FiscalParametroDomain.getSubstituicaoTributaria(record.substituicaoTributaria)}
			/>
			<FunctionField
				label="Forma Calculo Iss"
				render={record => FiscalParametroDomain.getFormaCalculoIss(record.formaCalculoIss)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalParametroList;
