/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FiscalParametroForm } from "./FiscalParametroForm";
import { transformNestedData } from "../../infra/utils";

const FiscalParametroCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FiscalParametroForm />
		</Create>
	);
};

export default FiscalParametroCreate;