/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FiscalInscricoesSubstitutasDomain from '../../data/domain/FiscalInscricoesSubstitutasDomain';

class FiscalInscricoesSubstitutas {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FiscalInscricoesSubstitutas {
		const fiscalInscricoesSubstitutas = new FiscalInscricoesSubstitutas();
		fiscalInscricoesSubstitutas.id = Date.now();
		fiscalInscricoesSubstitutas.statusCrud = "C";
		return fiscalInscricoesSubstitutas;
	}
}

export const FiscalInscricoesSubstitutasTab: React.FC = () => {

	const renderForm = (
		currentRecord: FiscalInscricoesSubstitutas,
		setCurrentRecord: (record: FiscalInscricoesSubstitutas) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'uf', label: 'Uf', formatDomain: FiscalInscricoesSubstitutasDomain.getUf },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
		{ source: 'pmpf', label: 'PMPF', formatDomain: FiscalInscricoesSubstitutasDomain.getPmpf },
	];

	return (
		<CrudChildTab
			title="Inscrições Substitutas"
			recordContext="fiscalParametro"
			fieldSource="fiscalInscricoesSubstitutasModelList"
			newObject={ FiscalInscricoesSubstitutas.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};