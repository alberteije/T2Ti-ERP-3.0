/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FiscalParametroForm } from "./FiscalParametroForm";
import { transformNestedData } from "../../infra/utils";

const FiscalParametroEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FiscalParametroForm />
		</Edit>
	);
};

export default FiscalParametroEdit;