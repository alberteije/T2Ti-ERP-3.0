import {
	Edit,
} from "react-admin";
import { FiscalEstadualPorteForm } from "./FiscalEstadualPorteForm";

const FiscalEstadualPorteEdit = () => {
	return (
		<Edit>
			<FiscalEstadualPorteForm />
		</Edit>
	);
};

export default FiscalEstadualPorteEdit;