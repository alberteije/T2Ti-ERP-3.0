import {
	Create,
} from "react-admin";
import { FiscalEstadualPorteForm } from "./FiscalEstadualPorteForm";

const FiscalEstadualPorteCreate = () => {
	return (
		<Create>
			<FiscalEstadualPorteForm />
		</Create>
	);
};

export default FiscalEstadualPorteCreate;