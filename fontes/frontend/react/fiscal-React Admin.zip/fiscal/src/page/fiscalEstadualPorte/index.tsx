import FiscalEstadualPorteIcon from "@mui/icons-material/Apps";
import FiscalEstadualPorteList from "./FiscalEstadualPorteList";
import FiscalEstadualPorteCreate from "./FiscalEstadualPorteCreate";
import FiscalEstadualPorteEdit from "./FiscalEstadualPorteEdit";

export default {
	list: FiscalEstadualPorteList,
	create: FiscalEstadualPorteCreate,
	edit: FiscalEstadualPorteEdit,
	icon: FiscalEstadualPorteIcon,
};
