import FiscalLivroIcon from "@mui/icons-material/Apps";
import FiscalLivroList from "./FiscalLivroList";
import FiscalLivroCreate from "./FiscalLivroCreate";
import FiscalLivroEdit from "./FiscalLivroEdit";

export default {
	list: FiscalLivroList,
	create: FiscalLivroCreate,
	edit: FiscalLivroEdit,
	icon: FiscalLivroIcon,
};
