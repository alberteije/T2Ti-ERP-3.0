/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FiscalLivroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalLivroSmallScreenList : FiscalLivroBigScreenList;

	return (
		<List
			title="Livros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalLivroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record._ }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const FiscalLivroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalLivroList;
