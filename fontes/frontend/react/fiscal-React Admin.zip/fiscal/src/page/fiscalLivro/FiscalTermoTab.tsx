/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FiscalTermoDomain from '../../data/domain/FiscalTermoDomain';

class FiscalTermo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FiscalTermo {
		const fiscalTermo = new FiscalTermo();
		fiscalTermo.id = Date.now();
		fiscalTermo.statusCrud = "C";
		return fiscalTermo;
	}
}

export const FiscalTermoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FiscalTermo,
		setCurrentRecord: (record: FiscalTermo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'aberturaEncerramento', label: 'Abertura/Encerramento', formatDomain: FiscalTermoDomain.getAberturaEncerramento },
		{ source: 'numero', label: 'Numero' },
		{ source: 'paginaInicial', label: 'Pagina Inicial' },
		{ source: 'paginaFinal', label: 'Pagina Final' },
		{ source: 'numeroRegistro', label: 'Numero Registro' },
		{ source: 'registrado', label: 'Registrado' },
		{ source: 'dataDespacho', label: 'Data Despacho' },
		{ source: 'dataAbertura', label: 'Data Abertura' },
		{ source: 'dataEncerramento', label: 'Data Encerramento' },
		{ source: 'escrituracaoInicio', label: 'Escrituracao Inicio' },
		{ source: 'escrituracaoFim', label: 'Escrituracao Fim' },
		{ source: 'texto', label: 'Texto' },
	];

	return (
		<CrudChildTab
			title="Termos"
			recordContext="fiscalLivro"
			fieldSource="fiscalTermoModelList"
			newObject={ FiscalTermo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};