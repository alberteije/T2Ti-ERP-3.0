/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FiscalLivroForm } from "./FiscalLivroForm";
import { transformNestedData } from "../../infra/utils";

const FiscalLivroCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FiscalLivroForm />
		</Create>
	);
};

export default FiscalLivroCreate;