/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FiscalNotaFiscalEntradaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeCabecalhoModel.chave_acesso","competencia","cfopEntrada"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalNotaFiscalEntradaSmallScreenList : FiscalNotaFiscalEntradaBigScreenList;

	return (
		<List
			title="Registro de Entradas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalNotaFiscalEntradaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeCabecalhoModel.chave_acesso }
			secondaryText={ (record) => record.competencia }
			tertiaryText={ (record) => record.cfopEntrada }
		/>
	);
}

const FiscalNotaFiscalEntradaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Cabecalho" source="nfeCabecalhoModel.id" reference="nfe-cabecalho" sortable={false}>
				<TextField source="chave_acesso" />
			</ReferenceField>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<TextField source="cfopEntrada" label="Cfop Entrada" />
			<NumberField source="valorRateioFrete" label="Valor Rateio Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCustoMedio" label="Valor Custo Medio" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsAntecipado" label="Valor Icms Antecipado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcIcmsAntecipado" label="Valor Bc Icms Antecipado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcIcmsCreditado" label="Valor Bc Icms Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcPisCreditado" label="Valor Bc Pis Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcCofinsCreditado" label="Valor Bc Cofins Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcIpiCreditado" label="Valor Bc Ipi Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="cstCreditoIcms" label="Cst Credito Icms" />
			<TextField source="cstCreditoPis" label="Cst Credito Pis" />
			<TextField source="cstCreditoCofins" label="Cst Credito Cofins" />
			<TextField source="cstCreditoIpi" label="Cst Credito Ipi" />
			<NumberField source="valorIcmsCreditado" label="Valor Icms Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPisCreditado" label="Valor Pis Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCofinsCreditado" label="Valor Cofins Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIpiCreditado" label="Valor Ipi Creditado" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="qtdeParcelaCreditoPis" label="Qtde Parcela Credito Pis" />
			<TextField source="qtdeParcelaCreditoCofins" label="Qtde Parcela Credito Cofins" />
			<TextField source="qtdeParcelaCreditoIcms" label="Qtde Parcela Credito Icms" />
			<TextField source="qtdeParcelaCreditoIpi" label="Qtde Parcela Credito Ipi" />
			<NumberField source="aliquotaCreditoIcms" label="Aliquota Credito Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaCreditoPis" label="Aliquota Credito Pis" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaCreditoCofins" label="Aliquota Credito Cofins" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaCreditoIpi" label="Aliquota Credito Ipi" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalNotaFiscalEntradaList;
