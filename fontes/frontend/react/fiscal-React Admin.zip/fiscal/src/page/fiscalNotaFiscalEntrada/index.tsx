import FiscalNotaFiscalEntradaIcon from "@mui/icons-material/Apps";
import FiscalNotaFiscalEntradaList from "./FiscalNotaFiscalEntradaList";
import FiscalNotaFiscalEntradaCreate from "./FiscalNotaFiscalEntradaCreate";
import FiscalNotaFiscalEntradaEdit from "./FiscalNotaFiscalEntradaEdit";

export default {
	list: FiscalNotaFiscalEntradaList,
	create: FiscalNotaFiscalEntradaCreate,
	edit: FiscalNotaFiscalEntradaEdit,
	icon: FiscalNotaFiscalEntradaIcon,
};
