import {
	Edit,
} from "react-admin";
import { FiscalNotaFiscalEntradaForm } from "./FiscalNotaFiscalEntradaForm";

const FiscalNotaFiscalEntradaEdit = () => {
	return (
		<Edit>
			<FiscalNotaFiscalEntradaForm />
		</Edit>
	);
};

export default FiscalNotaFiscalEntradaEdit;