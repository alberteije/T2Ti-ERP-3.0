import {
	Create,
} from "react-admin";
import { FiscalNotaFiscalEntradaForm } from "./FiscalNotaFiscalEntradaForm";

const FiscalNotaFiscalEntradaCreate = () => {
	return (
		<Create>
			<FiscalNotaFiscalEntradaForm />
		</Create>
	);
};

export default FiscalNotaFiscalEntradaCreate;