/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class SimplesNacionalDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): SimplesNacionalDetalhe {
		const simplesNacionalDetalhe = new SimplesNacionalDetalhe();
		simplesNacionalDetalhe.id = Date.now();
		simplesNacionalDetalhe.statusCrud = "C";
		return simplesNacionalDetalhe;
	}
}

export const SimplesNacionalDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: SimplesNacionalDetalhe,
		setCurrentRecord: (record: SimplesNacionalDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'faixa', label: 'Faixa' },
		{ source: 'valorInicial', label: 'Valor Inicial' },
		{ source: 'valorFinal', label: 'Valor Final' },
		{ source: 'aliquota', label: 'Aliquota' },
		{ source: 'irpj', label: 'Irpj' },
		{ source: 'csll', label: 'Csll' },
		{ source: 'cofins', label: 'Cofins' },
		{ source: 'pisPasep', label: 'Pis Pasep' },
		{ source: 'cpp', label: 'Cpp' },
		{ source: 'icms', label: 'Icms' },
		{ source: 'ipi', label: 'Ipi' },
		{ source: 'iss', label: 'Iss' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="simplesNacionalCabecalho"
			fieldSource="simplesNacionalDetalheModelList"
			newObject={ SimplesNacionalDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};