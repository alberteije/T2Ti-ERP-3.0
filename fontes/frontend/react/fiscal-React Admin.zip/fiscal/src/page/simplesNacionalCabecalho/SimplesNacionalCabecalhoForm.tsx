/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { SimplesNacionalDetalheTab } from './SimplesNacionalDetalheTab';

export const SimplesNacionalCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Simples Nacional">
				<SimplesNacionalCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<SimplesNacionalDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const SimplesNacionalCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};