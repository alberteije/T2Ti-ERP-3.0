/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { SimplesNacionalCabecalhoForm } from "./SimplesNacionalCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const SimplesNacionalCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<SimplesNacionalCabecalhoForm />
		</Create>
	);
};

export default SimplesNacionalCabecalhoCreate;