/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const SimplesNacionalCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["vigenciaInicial","vigenciaFinal","anexo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SimplesNacionalCabecalhoSmallScreenList : SimplesNacionalCabecalhoBigScreenList;

	return (
		<List
			title="Simples Nacional"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SimplesNacionalCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.vigenciaInicial }
			secondaryText={ (record) => record.vigenciaFinal }
			tertiaryText={ (record) => record.anexo }
		/>
	);
}

const SimplesNacionalCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="vigenciaInicial" label="Vigencia Inicial" />
			<TextField source="vigenciaFinal" label="Vigencia Final" />
			<TextField source="anexo" label="Anexo" />
			<TextField source="tabela" label="Tabela" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SimplesNacionalCabecalhoList;
