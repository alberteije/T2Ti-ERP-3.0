import SimplesNacionalCabecalhoIcon from "@mui/icons-material/Apps";
import SimplesNacionalCabecalhoList from "./SimplesNacionalCabecalhoList";
import SimplesNacionalCabecalhoCreate from "./SimplesNacionalCabecalhoCreate";
import SimplesNacionalCabecalhoEdit from "./SimplesNacionalCabecalhoEdit";

export default {
	list: SimplesNacionalCabecalhoList,
	create: SimplesNacionalCabecalhoCreate,
	edit: SimplesNacionalCabecalhoEdit,
	icon: SimplesNacionalCabecalhoIcon,
};
