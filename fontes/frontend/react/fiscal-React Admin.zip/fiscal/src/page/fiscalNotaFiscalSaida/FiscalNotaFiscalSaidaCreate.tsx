import {
	Create,
} from "react-admin";
import { FiscalNotaFiscalSaidaForm } from "./FiscalNotaFiscalSaidaForm";

const FiscalNotaFiscalSaidaCreate = () => {
	return (
		<Create>
			<FiscalNotaFiscalSaidaForm />
		</Create>
	);
};

export default FiscalNotaFiscalSaidaCreate;