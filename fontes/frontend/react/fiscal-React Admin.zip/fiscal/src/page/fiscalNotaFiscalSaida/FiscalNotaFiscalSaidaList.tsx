/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FiscalNotaFiscalSaidaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeCabecalhoModel.chave_acesso","competencia"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FiscalNotaFiscalSaidaSmallScreenList : FiscalNotaFiscalSaidaBigScreenList;

	return (
		<List
			title="Registro de Saídas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FiscalNotaFiscalSaidaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeCabecalhoModel.chave_acesso }
			secondaryText={ (record) => record.competencia }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const FiscalNotaFiscalSaidaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Cabecalho" source="nfeCabecalhoModel.id" reference="nfe-cabecalho" sortable={false}>
				<TextField source="chave_acesso" />
			</ReferenceField>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FiscalNotaFiscalSaidaList;
