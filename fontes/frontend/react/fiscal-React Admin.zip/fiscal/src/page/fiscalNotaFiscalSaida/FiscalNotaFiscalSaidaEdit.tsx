import {
	Edit,
} from "react-admin";
import { FiscalNotaFiscalSaidaForm } from "./FiscalNotaFiscalSaidaForm";

const FiscalNotaFiscalSaidaEdit = () => {
	return (
		<Edit>
			<FiscalNotaFiscalSaidaForm />
		</Edit>
	);
};

export default FiscalNotaFiscalSaidaEdit;