import FiscalNotaFiscalSaidaIcon from "@mui/icons-material/Apps";
import FiscalNotaFiscalSaidaList from "./FiscalNotaFiscalSaidaList";
import FiscalNotaFiscalSaidaCreate from "./FiscalNotaFiscalSaidaCreate";
import FiscalNotaFiscalSaidaEdit from "./FiscalNotaFiscalSaidaEdit";

export default {
	list: FiscalNotaFiscalSaidaList,
	create: FiscalNotaFiscalSaidaCreate,
	edit: FiscalNotaFiscalSaidaEdit,
	icon: FiscalNotaFiscalSaidaIcon,
};
