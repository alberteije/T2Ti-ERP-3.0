import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import fiscalParametro from './page/fiscalParametro';
import fiscalLivro from './page/fiscalLivro';
import simplesNacionalCabecalho from './page/simplesNacionalCabecalho';
import fiscalMunicipalRegime from './page/fiscalMunicipalRegime';
import fiscalEstadualRegime from './page/fiscalEstadualRegime';
import fiscalEstadualPorte from './page/fiscalEstadualPorte';
import fiscalNotaFiscalEntrada from './page/fiscalNotaFiscalEntrada';
import fiscalApuracaoIcms from './page/fiscalApuracaoIcms';
import fiscalNotaFiscalSaida from './page/fiscalNotaFiscalSaida';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'fiscal');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Escrita Fiscal (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='fiscal-parametro' {...fiscalParametro} options={{ label: 'Parâmetros' }} />
			<Resource name='fiscal-livro' {...fiscalLivro} options={{ label: 'Livros' }} />
			<Resource name='simples-nacional-cabecalho' {...simplesNacionalCabecalho} options={{ label: 'Simples Nacional' }} />
			<Resource name='fiscal-municipal-regime' {...fiscalMunicipalRegime} options={{ label: 'Regime Municipal' }} />
			<Resource name='fiscal-estadual-regime' {...fiscalEstadualRegime} options={{ label: 'Regime Estadual' }} />
			<Resource name='fiscal-estadual-porte' {...fiscalEstadualPorte} options={{ label: 'Porte Estadual' }} />
			<Resource name='fiscal-nota-fiscal-entrada' {...fiscalNotaFiscalEntrada} options={{ label: 'Registro de Entradas' }} />
			<Resource name='fiscal-apuracao-icms' {...fiscalApuracaoIcms} options={{ label: 'Apuração do ICMS' }} />
			<Resource name='fiscal-nota-fiscal-saida' {...fiscalNotaFiscalSaida} options={{ label: 'Registro de Saídas' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;