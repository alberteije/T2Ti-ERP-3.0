class FiscalParametroDomain {
	static getCriterioLancamento(criterioLancamento: string) { 
		switch (criterioLancamento) { 
			case '': 
			case 'L': 
				return 'Livre'; 
			case 'A': 
				return 'Avisar'; 
			case 'N': 
				return 'Não Permitir'; 
			default: 
				return null; 
		} 
	} 

	static setCriterioLancamento(criterioLancamento: string) { 
		switch (criterioLancamento) { 
			case 'Livre': 
				return 'L'; 
			case 'Avisar': 
				return 'A'; 
			case 'Não Permitir': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getApuracao(apuracao: string) { 
		switch (apuracao) { 
			case '': 
			case '1': 
				return '1-Regime Competencia'; 
			case '2': 
				return '2-Regime de Caixa'; 
			default: 
				return null; 
		} 
	} 

	static setApuracao(apuracao: string) { 
		switch (apuracao) { 
			case '1-Regime Competencia': 
				return '1'; 
			case '2-Regime de Caixa': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getMicroempreeIndividual(microempreeIndividual: string) { 
		switch (microempreeIndividual) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setMicroempreeIndividual(microempreeIndividual: string) { 
		switch (microempreeIndividual) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getCalcPisCofinsEfd(calcPisCofinsEfd: string) { 
		switch (calcPisCofinsEfd) { 
			case '': 
			case '0': 
				return 'AB=Alíquota Básica'; 
			case '1': 
				return 'AD=Alíquota Diferenciada'; 
			case '2': 
				return 'UP=Unidade de Medida de Produto'; 
			default: 
				return null; 
		} 
	} 

	static setCalcPisCofinsEfd(calcPisCofinsEfd: string) { 
		switch (calcPisCofinsEfd) { 
			case 'AB=Alíquota Básica': 
				return '0'; 
			case 'AD=Alíquota Diferenciada': 
				return '1'; 
			case 'UP=Unidade de Medida de Produto': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getSimplesTabela(simplesTabela: string) { 
		switch (simplesTabela) { 
			case '': 
			case '1': 
				return '1=Federal'; 
			case '2': 
				return '2=Estadual'; 
			default: 
				return null; 
		} 
	} 

	static setSimplesTabela(simplesTabela: string) { 
		switch (simplesTabela) { 
			case '1=Federal': 
				return '1'; 
			case '2=Estadual': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getSimplesAtividade(simplesAtividade: string) { 
		switch (simplesAtividade) { 
			case '': 
			case '0': 
				return 'Comercio'; 
			case '1': 
				return 'Indústria'; 
			case '2': 
				return 'Serviços Anexo III'; 
			case '3': 
				return 'Serviços Anexo IV'; 
			case '4': 
				return '"Serviços Anexo V'; 
			default: 
				return null; 
		} 
	} 

	static setSimplesAtividade(simplesAtividade: string) { 
		switch (simplesAtividade) { 
			case 'Comercio': 
				return '0'; 
			case 'Indústria': 
				return '1'; 
			case 'Serviços Anexo III': 
				return '2'; 
			case 'Serviços Anexo IV': 
				return '3'; 
			case '"Serviços Anexo V': 
				return '4'; 
			default: 
				return null; 
		} 
	}

	static getPerfilSped(perfilSped: string) { 
		switch (perfilSped) { 
			case '': 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	} 

	static setPerfilSped(perfilSped: string) { 
		switch (perfilSped) { 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

	static getApuracaoConsolidada(apuracaoConsolidada: string) { 
		switch (apuracaoConsolidada) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setApuracaoConsolidada(apuracaoConsolidada: string) { 
		switch (apuracaoConsolidada) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getSubstituicaoTributaria(substituicaoTributaria: string) { 
		switch (substituicaoTributaria) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setSubstituicaoTributaria(substituicaoTributaria: string) { 
		switch (substituicaoTributaria) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFormaCalculoIss(formaCalculoIss: string) { 
		switch (formaCalculoIss) { 
			case '': 
			case '0': 
				return 'Normal'; 
			case '1': 
				return 'Profissional Habilitado'; 
			case '2': 
				return 'Valor Fixo'; 
			default: 
				return null; 
		} 
	} 

	static setFormaCalculoIss(formaCalculoIss: string) { 
		switch (formaCalculoIss) { 
			case 'Normal': 
				return '0'; 
			case 'Profissional Habilitado': 
				return '1'; 
			case 'Valor Fixo': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default FiscalParametroDomain;