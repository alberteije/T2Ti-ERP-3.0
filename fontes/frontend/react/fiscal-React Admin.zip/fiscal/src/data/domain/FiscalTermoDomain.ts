class FiscalTermoDomain {
	static getAberturaEncerramento(aberturaEncerramento: string) { 
		switch (aberturaEncerramento) { 
			case '': 
			case '0': 
				return 'Abertura'; 
			case '1': 
				return 'Encerramento'; 
			default: 
				return null; 
		} 
	} 

	static setAberturaEncerramento(aberturaEncerramento: string) { 
		switch (aberturaEncerramento) { 
			case 'Abertura': 
				return '0'; 
			case 'Encerramento': 
				return '1'; 
			default: 
				return null; 
		} 
	}

}

export default FiscalTermoDomain;