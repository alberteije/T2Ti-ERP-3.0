import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import fiscalParametro from '../page/fiscalParametro';
import fiscalLivro from '../page/fiscalLivro';
import simplesNacionalCabecalho from '../page/simplesNacionalCabecalho';
import fiscalMunicipalRegime from '../page/fiscalMunicipalRegime';
import fiscalEstadualRegime from '../page/fiscalEstadualRegime';
import fiscalEstadualPorte from '../page/fiscalEstadualPorte';
import fiscalNotaFiscalEntrada from '../page/fiscalNotaFiscalEntrada';
import fiscalApuracaoIcms from '../page/fiscalApuracaoIcms';
import fiscalNotaFiscalSaida from '../page/fiscalNotaFiscalSaida';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/fiscal-municipal-regime'
					state={{ _scrollToTop: true }}
					primaryText='Regime Municipal'
					leftIcon={<fiscalMunicipalRegime.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-estadual-regime'
					state={{ _scrollToTop: true }}
					primaryText='Regime Estadual'
					leftIcon={<fiscalEstadualRegime.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-estadual-porte'
					state={{ _scrollToTop: true }}
					primaryText='Porte Estadual'
					leftIcon={<fiscalEstadualPorte.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-nota-fiscal-entrada'
					state={{ _scrollToTop: true }}
					primaryText='Registro de Entradas'
					leftIcon={<fiscalNotaFiscalEntrada.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-apuracao-icms'
					state={{ _scrollToTop: true }}
					primaryText='Apuração do ICMS'
					leftIcon={<fiscalApuracaoIcms.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-nota-fiscal-saida'
					state={{ _scrollToTop: true }}
					primaryText='Registro de Saídas'
					leftIcon={<fiscalNotaFiscalSaida.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/fiscal-parametro'
					state={{ _scrollToTop: true }}
					primaryText='Parâmetros'
					leftIcon={<fiscalParametro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fiscal-livro'
					state={{ _scrollToTop: true }}
					primaryText='Livros'
					leftIcon={<fiscalLivro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/simples-nacional-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Simples Nacional'
					leftIcon={<simplesNacionalCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
