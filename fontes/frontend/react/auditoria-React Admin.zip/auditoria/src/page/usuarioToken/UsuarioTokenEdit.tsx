import {
	Edit,
} from "react-admin";
import { UsuarioTokenForm } from "./UsuarioTokenForm";

const UsuarioTokenEdit = () => {
	return (
		<Edit>
			<UsuarioTokenForm />
		</Edit>
	);
};

export default UsuarioTokenEdit;