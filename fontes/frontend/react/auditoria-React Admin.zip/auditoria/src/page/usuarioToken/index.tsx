import UsuarioTokenIcon from "@mui/icons-material/Apps";
import UsuarioTokenList from "./UsuarioTokenList";
import UsuarioTokenCreate from "./UsuarioTokenCreate";
import UsuarioTokenEdit from "./UsuarioTokenEdit";

export default {
	list: UsuarioTokenList,
	create: UsuarioTokenCreate,
	edit: UsuarioTokenEdit,
	icon: UsuarioTokenIcon,
};
