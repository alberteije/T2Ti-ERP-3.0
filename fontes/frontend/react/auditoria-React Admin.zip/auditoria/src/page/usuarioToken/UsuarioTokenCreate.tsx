import {
	Create,
} from "react-admin";
import { UsuarioTokenForm } from "./UsuarioTokenForm";

const UsuarioTokenCreate = () => {
	return (
		<Create>
			<UsuarioTokenForm />
		</Create>
	);
};

export default UsuarioTokenCreate;