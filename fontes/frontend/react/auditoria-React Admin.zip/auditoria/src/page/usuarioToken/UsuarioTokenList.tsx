/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const UsuarioTokenList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["login","token","dataCriacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? UsuarioTokenSmallScreenList : UsuarioTokenBigScreenList;

	return (
		<List
			title="Usuario Token"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const UsuarioTokenSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.login }
			secondaryText={ (record) => record.token }
			tertiaryText={ (record) => record.dataCriacao }
		/>
	);
}

const UsuarioTokenBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="login" label="Login" />
			<TextField source="token" label="Token" />
			<TextField source="dataCriacao" label="Data Criacao" />
			<TextField source="horaCriacao" label="Hora Criacao" />
			<TextField source="dataExpiracao" label="Data Expiracao" />
			<TextField source="horaExpiracao" label="Hora Expiracao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default UsuarioTokenList;
