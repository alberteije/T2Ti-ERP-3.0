import {
	Edit,
} from "react-admin";
import { AuditoriaForm } from "./AuditoriaForm";

const AuditoriaEdit = () => {
	return (
		<Edit>
			<AuditoriaForm />
		</Edit>
	);
};

export default AuditoriaEdit;