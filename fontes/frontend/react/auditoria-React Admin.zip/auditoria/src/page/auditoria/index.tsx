import AuditoriaIcon from "@mui/icons-material/Apps";
import AuditoriaList from "./AuditoriaList";
import AuditoriaCreate from "./AuditoriaCreate";
import AuditoriaEdit from "./AuditoriaEdit";

export default {
	list: AuditoriaList,
	create: AuditoriaCreate,
	edit: AuditoriaEdit,
	icon: AuditoriaIcon,
};
