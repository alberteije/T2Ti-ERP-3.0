/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const AuditoriaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataRegistro","horaRegistro","janelaController"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? AuditoriaSmallScreenList : AuditoriaBigScreenList;

	return (
		<List
			title="Auditoria"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const AuditoriaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataRegistro }
			secondaryText={ (record) => record.horaRegistro }
			tertiaryText={ (record) => record.janelaController }
		/>
	);
}

const AuditoriaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataRegistro" label="Data Registro" />
			<TextField source="horaRegistro" label="Hora Registro" />
			<TextField source="janelaController" label="Janela Controller" />
			<TextField source="acao" label="Acao" />
			<TextField source="conteudo" label="Conteudo" />
			<TextField source="tokenJwt" label="Token Jwt" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default AuditoriaList;
