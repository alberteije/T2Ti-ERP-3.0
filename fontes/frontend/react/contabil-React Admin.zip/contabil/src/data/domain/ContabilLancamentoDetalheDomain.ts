class ContabilLancamentoDetalheDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'D': 
				return 'Débito'; 
			case 'C': 
				return 'Crédito'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Débito': 
				return 'D'; 
			case 'Crédito': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilLancamentoDetalheDomain;