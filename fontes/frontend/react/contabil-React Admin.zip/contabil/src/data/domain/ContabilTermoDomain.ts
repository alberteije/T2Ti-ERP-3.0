class ContabilTermoDomain {
	static getAberturaEncerramento(aberturaEncerramento: string) { 
		switch (aberturaEncerramento) { 
			case '': 
			case 'A': 
				return 'Abertura'; 
			case 'E': 
				return 'Encerramento'; 
			default: 
				return null; 
		} 
	} 

	static setAberturaEncerramento(aberturaEncerramento: string) { 
		switch (aberturaEncerramento) { 
			case 'Abertura': 
				return 'A'; 
			case 'Encerramento': 
				return 'E'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilTermoDomain;