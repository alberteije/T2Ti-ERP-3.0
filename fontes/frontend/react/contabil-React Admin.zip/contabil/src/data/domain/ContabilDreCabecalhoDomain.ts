class ContabilDreCabecalhoDomain {
	static getPadrao(padrao: string) { 
		switch (padrao) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPadrao(padrao: string) { 
		switch (padrao) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilDreCabecalhoDomain;