class CentroResultadoDomain {
	static getSofreRateiro(sofreRateiro: string) { 
		switch (sofreRateiro) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setSofreRateiro(sofreRateiro: string) { 
		switch (sofreRateiro) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default CentroResultadoDomain;