class ContabilParametroDomain {
	static getInformarContaPor(informarContaPor: string) { 
		switch (informarContaPor) { 
			case '': 
			case 'C': 
				return 'Código'; 
			case 'M': 
				return 'Máscara'; 
			default: 
				return null; 
		} 
	} 

	static setInformarContaPor(informarContaPor: string) { 
		switch (informarContaPor) { 
			case 'Código': 
				return 'C'; 
			case 'Máscara': 
				return 'M'; 
			default: 
				return null; 
		} 
	}

	static getCompartilhaPlanoConta(compartilhaPlanoConta: string) { 
		switch (compartilhaPlanoConta) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setCompartilhaPlanoConta(compartilhaPlanoConta: string) { 
		switch (compartilhaPlanoConta) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getCompartilhaHistoricos(compartilhaHistoricos: string) { 
		switch (compartilhaHistoricos) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setCompartilhaHistoricos(compartilhaHistoricos: string) { 
		switch (compartilhaHistoricos) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAlteraLancamentoOutro(alteraLancamentoOutro: string) { 
		switch (alteraLancamentoOutro) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAlteraLancamentoOutro(alteraLancamentoOutro: string) { 
		switch (alteraLancamentoOutro) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getHistoricoObrigatorio(historicoObrigatorio: string) { 
		switch (historicoObrigatorio) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setHistoricoObrigatorio(historicoObrigatorio: string) { 
		switch (historicoObrigatorio) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPermiteLancamentoZerado(permiteLancamentoZerado: string) { 
		switch (permiteLancamentoZerado) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPermiteLancamentoZerado(permiteLancamentoZerado: string) { 
		switch (permiteLancamentoZerado) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getGeraInformativoSped(geraInformativoSped: string) { 
		switch (geraInformativoSped) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setGeraInformativoSped(geraInformativoSped: string) { 
		switch (geraInformativoSped) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getSpedFormaEscritDiario(spedFormaEscritDiario: string) { 
		switch (spedFormaEscritDiario) { 
			case '': 
			case '0': 
				return 'Livro Diário Completo'; 
			case '1': 
				return 'Livro Diário com Escrituração Resumida'; 
			case '2': 
				return 'Livro Balancete Diário e Balanços'; 
			default: 
				return null; 
		} 
	} 

	static setSpedFormaEscritDiario(spedFormaEscritDiario: string) { 
		switch (spedFormaEscritDiario) { 
			case 'Livro Diário Completo': 
				return '0'; 
			case 'Livro Diário com Escrituração Resumida': 
				return '1'; 
			case 'Livro Balancete Diário e Balanços': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilParametroDomain;