class AidfAimdfDomain {
	static getFormularioDisponivel(formularioDisponivel: string) { 
		switch (formularioDisponivel) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFormularioDisponivel(formularioDisponivel: string) { 
		switch (formularioDisponivel) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default AidfAimdfDomain;