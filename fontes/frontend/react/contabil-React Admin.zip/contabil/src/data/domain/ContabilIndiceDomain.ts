class ContabilIndiceDomain {
	static getPeriodicidade(periodicidade: string) { 
		switch (periodicidade) { 
			case '': 
			case 'D': 
				return 'Diário'; 
			case 'M': 
				return 'Mensal'; 
			default: 
				return null; 
		} 
	} 

	static setPeriodicidade(periodicidade: string) { 
		switch (periodicidade) { 
			case 'Diário': 
				return 'D'; 
			case 'Mensal': 
				return 'M'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilIndiceDomain;