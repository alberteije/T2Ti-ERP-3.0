class ContabilContaDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'S': 
				return 'Sintética'; 
			case 'A': 
				return 'Analítica'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Sintética': 
				return 'S'; 
			case 'Analítica': 
				return 'A'; 
			default: 
				return null; 
		} 
	}

	static getSituacao(situacao: string) { 
		switch (situacao) { 
			case '': 
			case 'A': 
				return 'Ativa'; 
			case 'I': 
				return 'Inativa'; 
			default: 
				return null; 
		} 
	} 

	static setSituacao(situacao: string) { 
		switch (situacao) { 
			case 'Ativa': 
				return 'A'; 
			case 'Inativa': 
				return 'I'; 
			default: 
				return null; 
		} 
	}

	static getNatureza(natureza: string) { 
		switch (natureza) { 
			case '': 
			case 'C': 
				return 'Credora'; 
			case 'D': 
				return 'Devedora'; 
			default: 
				return null; 
		} 
	} 

	static setNatureza(natureza: string) { 
		switch (natureza) { 
			case 'Credora': 
				return 'C'; 
			case 'Devedora': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

	static getPatrimonioResultado(patrimonioResultado: string) { 
		switch (patrimonioResultado) { 
			case '': 
			case 'P': 
				return 'Patrimonio'; 
			case 'R': 
				return 'Resultado'; 
			default: 
				return null; 
		} 
	} 

	static setPatrimonioResultado(patrimonioResultado: string) { 
		switch (patrimonioResultado) { 
			case 'Patrimonio': 
				return 'P'; 
			case 'Resultado': 
				return 'R'; 
			default: 
				return null; 
		} 
	}

	static getLivroCaixa(livroCaixa: string) { 
		switch (livroCaixa) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setLivroCaixa(livroCaixa: string) { 
		switch (livroCaixa) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getDfc(dfc: string) { 
		switch (dfc) { 
			case '': 
			case '0': 
				return 'Não participa'; 
			case '1': 
				return 'Atividades Operacionais'; 
			case '2': 
				return 'Atividades de Financiamento'; 
			case '3': 
				return 'Atividades de Investimento'; 
			default: 
				return null; 
		} 
	} 

	static setDfc(dfc: string) { 
		switch (dfc) { 
			case 'Não participa': 
				return '0'; 
			case 'Atividades Operacionais': 
				return '1'; 
			case 'Atividades de Financiamento': 
				return '2'; 
			case 'Atividades de Investimento': 
				return '3'; 
			default: 
				return null; 
		} 
	}

}

export default ContabilContaDomain;