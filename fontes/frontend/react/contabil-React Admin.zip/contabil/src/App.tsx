import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import contabilLancamentoCabecalho from './page/contabilLancamentoCabecalho';
import contabilDreCabecalho from './page/contabilDreCabecalho';
import contabilLivro from './page/contabilLivro';
import contabilEncerramentoExeCab from './page/contabilEncerramentoExeCab';
import centroResultado from './page/centroResultado';
import rateioCentroResultadoCab from './page/rateioCentroResultadoCab';
import contabilIndice from './page/contabilIndice';
import aidfAimdf from './page/aidfAimdf';
import fap from './page/fap';
import registroCartorio from './page/registroCartorio';
import contabilParametro from './page/contabilParametro';
import planoContaRefSped from './page/planoContaRefSped';
import planoConta from './page/planoConta';
import contabilConta from './page/contabilConta';
import contabilHistorico from './page/contabilHistorico';
import contabilLancamentoPadrao from './page/contabilLancamentoPadrao';
import contabilLote from './page/contabilLote';
import contabilLancamentoOrcado from './page/contabilLancamentoOrcado';
import lancaCentroResultado from './page/lancaCentroResultado';
import encerraCentroResultado from './page/encerraCentroResultado';
import contabilContaRateio from './page/contabilContaRateio';
import contabilFechamento from './page/contabilFechamento';
import planoCentroResultado from './page/planoCentroResultado';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'contabil');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Contabilidade e Conciliação (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='contabil-lancamento-cabecalho' {...contabilLancamentoCabecalho} options={{ label: 'Lancamento Contábil' }} />
			<Resource name='contabil-dre-cabecalho' {...contabilDreCabecalho} options={{ label: 'DRE' }} />
			<Resource name='contabil-livro' {...contabilLivro} options={{ label: 'Livros' }} />
			<Resource name='contabil-encerramento-exe-cab' {...contabilEncerramentoExeCab} options={{ label: 'Encerramento do Exercício' }} />
			<Resource name='centro-resultado' {...centroResultado} options={{ label: 'Centro de Resultado' }} />
			<Resource name='rateio-centro-resultado-cab' {...rateioCentroResultadoCab} options={{ label: 'Rateio Centro Resultado' }} />
			<Resource name='contabil-indice' {...contabilIndice} options={{ label: 'Índices' }} />
			<Resource name='aidf-aimdf' {...aidfAimdf} options={{ label: 'AIDF/AIMDF' }} />
			<Resource name='fap' {...fap} options={{ label: 'FAP' }} />
			<Resource name='registro-cartorio' {...registroCartorio} options={{ label: 'Registro em Cartório' }} />
			<Resource name='contabil-parametro' {...contabilParametro} options={{ label: 'Parâmetros' }} />
			<Resource name='plano-conta-ref-sped' {...planoContaRefSped} options={{ label: 'Planos de Contas Sped' }} />
			<Resource name='plano-conta' {...planoConta} options={{ label: 'Plano de Contas' }} />
			<Resource name='contabil-conta' {...contabilConta} options={{ label: 'Conta Contábil' }} />
			<Resource name='contabil-historico' {...contabilHistorico} options={{ label: 'Históricos' }} />
			<Resource name='contabil-lancamento-padrao' {...contabilLancamentoPadrao} options={{ label: 'Lancamento Padrão' }} />
			<Resource name='contabil-lote' {...contabilLote} options={{ label: 'Lote Contábil' }} />
			<Resource name='contabil-lancamento-orcado' {...contabilLancamentoOrcado} options={{ label: 'Lançamento Orcado' }} />
			<Resource name='lanca-centro-resultado' {...lancaCentroResultado} options={{ label: 'Lançamento Centro Resultado' }} />
			<Resource name='encerra-centro-resultado' {...encerraCentroResultado} options={{ label: 'Encerra Centro Resultado' }} />
			<Resource name='contabil-conta-rateio' {...contabilContaRateio} options={{ label: 'Rateio Conta Contábil' }} />
			<Resource name='contabil-fechamento' {...contabilFechamento} options={{ label: 'Fechamento' }} />
			<Resource name='plano-centro-resultado' {...planoCentroResultado} options={{ label: 'Plano Centro Resultado' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;