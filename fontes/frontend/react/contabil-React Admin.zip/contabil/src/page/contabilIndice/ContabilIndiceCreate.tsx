/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContabilIndiceForm } from "./ContabilIndiceForm";
import { transformNestedData } from "../../infra/utils";

const ContabilIndiceCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContabilIndiceForm />
		</Create>
	);
};

export default ContabilIndiceCreate;