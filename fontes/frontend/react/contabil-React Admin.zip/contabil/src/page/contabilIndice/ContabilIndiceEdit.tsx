/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContabilIndiceForm } from "./ContabilIndiceForm";
import { transformNestedData } from "../../infra/utils";

const ContabilIndiceEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContabilIndiceForm />
		</Edit>
	);
};

export default ContabilIndiceEdit;