/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContabilIndiceValorTab } from './ContabilIndiceValorTab';

export const ContabilIndiceForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Índices">
				<ContabilIndiceTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Valores">
				<ContabilIndiceValorTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContabilIndiceTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};