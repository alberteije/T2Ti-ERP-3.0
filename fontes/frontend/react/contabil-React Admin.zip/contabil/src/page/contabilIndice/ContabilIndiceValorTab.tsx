/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ContabilIndiceValor {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContabilIndiceValor {
		const contabilIndiceValor = new ContabilIndiceValor();
		contabilIndiceValor.id = Date.now();
		contabilIndiceValor.statusCrud = "C";
		return contabilIndiceValor;
	}
}

export const ContabilIndiceValorTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContabilIndiceValor,
		setCurrentRecord: (record: ContabilIndiceValor) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataIndice', label: 'Data Indice' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Valores"
			recordContext="contabilIndice"
			fieldSource="contabilIndiceValorModelList"
			newObject={ ContabilIndiceValor.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};