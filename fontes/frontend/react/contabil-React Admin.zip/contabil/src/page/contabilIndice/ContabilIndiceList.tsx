/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import ContabilIndiceDomain from '../../data/domain/ContabilIndiceDomain';

const ContabilIndiceList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["indice","periodicidade","diarioAPartirDe"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilIndiceSmallScreenList : ContabilIndiceBigScreenList;

	return (
		<List
			title="Índices"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilIndiceSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.indice }
			secondaryText={ (record) => record.periodicidade }
			tertiaryText={ (record) => record.diarioAPartirDe }
		/>
	);
}

const ContabilIndiceBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="indice" label="Indice" />
			<FunctionField
				label="Periodicidade"
				render={record => ContabilIndiceDomain.getPeriodicidade(record.periodicidade)}
			/>
			<TextField source="diarioAPartirDe" label="Diario A Partir De" />
			<FunctionField
				source="mensalMesAno"
				label="Mensal Mes Ano"
				render={record => formatWithMask(record.mensalMesAno, '##/####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilIndiceList;
