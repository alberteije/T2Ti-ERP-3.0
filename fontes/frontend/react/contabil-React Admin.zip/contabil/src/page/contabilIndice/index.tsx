import ContabilIndiceIcon from "@mui/icons-material/Apps";
import ContabilIndiceList from "./ContabilIndiceList";
import ContabilIndiceCreate from "./ContabilIndiceCreate";
import ContabilIndiceEdit from "./ContabilIndiceEdit";

export default {
	list: ContabilIndiceList,
	create: ContabilIndiceCreate,
	edit: ContabilIndiceEdit,
	icon: ContabilIndiceIcon,
};
