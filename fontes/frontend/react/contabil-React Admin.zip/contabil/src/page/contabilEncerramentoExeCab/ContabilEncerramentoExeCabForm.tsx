/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContabilEncerramentoExeDetTab } from './ContabilEncerramentoExeDetTab';

export const ContabilEncerramentoExeCabForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Encerramento do Exercício">
				<ContabilEncerramentoExeCabTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<ContabilEncerramentoExeDetTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContabilEncerramentoExeCabTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};