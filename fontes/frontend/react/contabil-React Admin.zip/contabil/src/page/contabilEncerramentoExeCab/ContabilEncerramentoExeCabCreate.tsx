/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContabilEncerramentoExeCabForm } from "./ContabilEncerramentoExeCabForm";
import { transformNestedData } from "../../infra/utils";

const ContabilEncerramentoExeCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContabilEncerramentoExeCabForm />
		</Create>
	);
};

export default ContabilEncerramentoExeCabCreate;