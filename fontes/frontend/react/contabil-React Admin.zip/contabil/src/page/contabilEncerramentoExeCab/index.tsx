import ContabilEncerramentoExeCabIcon from "@mui/icons-material/Apps";
import ContabilEncerramentoExeCabList from "./ContabilEncerramentoExeCabList";
import ContabilEncerramentoExeCabCreate from "./ContabilEncerramentoExeCabCreate";
import ContabilEncerramentoExeCabEdit from "./ContabilEncerramentoExeCabEdit";

export default {
	list: ContabilEncerramentoExeCabList,
	create: ContabilEncerramentoExeCabCreate,
	edit: ContabilEncerramentoExeCabEdit,
	icon: ContabilEncerramentoExeCabIcon,
};
