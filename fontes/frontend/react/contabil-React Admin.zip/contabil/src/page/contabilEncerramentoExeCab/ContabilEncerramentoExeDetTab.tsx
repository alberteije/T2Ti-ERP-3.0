/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ContabilEncerramentoExeDet {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContabilEncerramentoExeDet {
		const contabilEncerramentoExeDet = new ContabilEncerramentoExeDet();
		contabilEncerramentoExeDet.id = Date.now();
		contabilEncerramentoExeDet.statusCrud = "C";
		return contabilEncerramentoExeDet;
	}
}

export const ContabilEncerramentoExeDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContabilEncerramentoExeDet,
		setCurrentRecord: (record: ContabilEncerramentoExeDet) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'contabilContaModel.id', label: 'Conta Contábil', reference: 'contabil-conta', fieldName: 'descricao' },
		{ source: 'saldoAnterior', label: 'Saldo Anterior' },
		{ source: 'valorDebito', label: 'Valor Debito' },
		{ source: 'valorCredito', label: 'Valor Credito' },
		{ source: 'saldo', label: 'Saldo' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="contabilEncerramentoExeCab"
			fieldSource="contabilEncerramentoExeDetModelList"
			newObject={ ContabilEncerramentoExeDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};