/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContabilEncerramentoExeCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataInicio","dataFim","dataInclusao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilEncerramentoExeCabSmallScreenList : ContabilEncerramentoExeCabBigScreenList;

	return (
		<List
			title="Encerramento do Exercício"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilEncerramentoExeCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataInicio }
			secondaryText={ (record) => record.dataFim }
			tertiaryText={ (record) => record.dataInclusao }
		/>
	);
}

const ContabilEncerramentoExeCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<TextField source="motivo" label="Motivo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilEncerramentoExeCabList;
