/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContabilEncerramentoExeCabForm } from "./ContabilEncerramentoExeCabForm";
import { transformNestedData } from "../../infra/utils";

const ContabilEncerramentoExeCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContabilEncerramentoExeCabForm />
		</Edit>
	);
};

export default ContabilEncerramentoExeCabEdit;