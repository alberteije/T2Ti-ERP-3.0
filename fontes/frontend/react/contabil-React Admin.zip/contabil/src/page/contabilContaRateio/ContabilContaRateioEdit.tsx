import {
	Edit,
} from "react-admin";
import { ContabilContaRateioForm } from "./ContabilContaRateioForm";

const ContabilContaRateioEdit = () => {
	return (
		<Edit>
			<ContabilContaRateioForm />
		</Edit>
	);
};

export default ContabilContaRateioEdit;