import ContabilContaRateioIcon from "@mui/icons-material/Apps";
import ContabilContaRateioList from "./ContabilContaRateioList";
import ContabilContaRateioCreate from "./ContabilContaRateioCreate";
import ContabilContaRateioEdit from "./ContabilContaRateioEdit";

export default {
	list: ContabilContaRateioList,
	create: ContabilContaRateioCreate,
	edit: ContabilContaRateioEdit,
	icon: ContabilContaRateioIcon,
};
