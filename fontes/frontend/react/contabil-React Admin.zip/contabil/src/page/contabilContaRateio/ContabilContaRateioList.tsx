/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContabilContaRateioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["centroResultadoModel.descricao","contabilContaModel.descricao","porcentoRateio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilContaRateioSmallScreenList : ContabilContaRateioBigScreenList;

	return (
		<List
			title="Rateio Conta Contábil"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilContaRateioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.centroResultadoModel.descricao }
			secondaryText={ (record) => record.contabilContaModel.descricao }
			tertiaryText={ (record) => record.porcentoRateio }
		/>
	);
}

const ContabilContaRateioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Centro Resultado" source="centroResultadoModel.id" reference="centro-resultado" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Contabil Conta" source="contabilContaModel.id" reference="contabil-conta" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<NumberField source="porcentoRateio" label="Porcento Rateio" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilContaRateioList;
