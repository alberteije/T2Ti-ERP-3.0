import {
	Create,
} from "react-admin";
import { ContabilContaRateioForm } from "./ContabilContaRateioForm";

const ContabilContaRateioCreate = () => {
	return (
		<Create>
			<ContabilContaRateioForm />
		</Create>
	);
};

export default ContabilContaRateioCreate;