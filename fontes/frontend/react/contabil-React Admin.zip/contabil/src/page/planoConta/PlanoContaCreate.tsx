import {
	Create,
} from "react-admin";
import { PlanoContaForm } from "./PlanoContaForm";

const PlanoContaCreate = () => {
	return (
		<Create>
			<PlanoContaForm />
		</Create>
	);
};

export default PlanoContaCreate;