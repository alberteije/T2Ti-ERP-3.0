import {
	Edit,
} from "react-admin";
import { PlanoContaForm } from "./PlanoContaForm";

const PlanoContaEdit = () => {
	return (
		<Edit>
			<PlanoContaForm />
		</Edit>
	);
};

export default PlanoContaEdit;