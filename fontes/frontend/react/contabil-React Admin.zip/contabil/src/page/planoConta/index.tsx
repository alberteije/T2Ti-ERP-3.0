import PlanoContaIcon from "@mui/icons-material/Apps";
import PlanoContaList from "./PlanoContaList";
import PlanoContaCreate from "./PlanoContaCreate";
import PlanoContaEdit from "./PlanoContaEdit";

export default {
	list: PlanoContaList,
	create: PlanoContaCreate,
	edit: PlanoContaEdit,
	icon: PlanoContaIcon,
};
