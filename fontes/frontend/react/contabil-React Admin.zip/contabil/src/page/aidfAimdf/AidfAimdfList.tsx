/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import AidfAimdfDomain from '../../data/domain/AidfAimdfDomain';

const AidfAimdfList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["numero","dataValidade","dataAutorizacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? AidfAimdfSmallScreenList : AidfAimdfBigScreenList;

	return (
		<List
			title="AIDF/AIMDF"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const AidfAimdfSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.numero }
			secondaryText={ (record) => record.dataValidade }
			tertiaryText={ (record) => record.dataAutorizacao }
		/>
	);
}

const AidfAimdfBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="numero" label="Numero" />
			<TextField source="dataValidade" label="Data Validade" />
			<TextField source="dataAutorizacao" label="Data Autorizacao" />
			<TextField source="numeroAutorizacao" label="Numero Autorizacao" />
			<FunctionField
				label="Formulario Disponivel"
				render={record => AidfAimdfDomain.getFormularioDisponivel(record.formularioDisponivel)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default AidfAimdfList;
