import {
	Edit,
} from "react-admin";
import { AidfAimdfForm } from "./AidfAimdfForm";

const AidfAimdfEdit = () => {
	return (
		<Edit>
			<AidfAimdfForm />
		</Edit>
	);
};

export default AidfAimdfEdit;