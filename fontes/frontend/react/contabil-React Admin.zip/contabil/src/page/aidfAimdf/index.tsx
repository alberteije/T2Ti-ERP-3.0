import AidfAimdfIcon from "@mui/icons-material/Apps";
import AidfAimdfList from "./AidfAimdfList";
import AidfAimdfCreate from "./AidfAimdfCreate";
import AidfAimdfEdit from "./AidfAimdfEdit";

export default {
	list: AidfAimdfList,
	create: AidfAimdfCreate,
	edit: AidfAimdfEdit,
	icon: AidfAimdfIcon,
};
