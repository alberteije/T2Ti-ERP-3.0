import {
	Create,
} from "react-admin";
import { AidfAimdfForm } from "./AidfAimdfForm";

const AidfAimdfCreate = () => {
	return (
		<Create>
			<AidfAimdfForm />
		</Create>
	);
};

export default AidfAimdfCreate;