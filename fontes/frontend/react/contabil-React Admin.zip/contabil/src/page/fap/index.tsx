import FapIcon from "@mui/icons-material/Apps";
import FapList from "./FapList";
import FapCreate from "./FapCreate";
import FapEdit from "./FapEdit";

export default {
	list: FapList,
	create: FapCreate,
	edit: FapEdit,
	icon: FapIcon,
};
