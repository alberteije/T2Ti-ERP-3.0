/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	NumberField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FapList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["fap","dataInicial","dataFinal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FapSmallScreenList : FapBigScreenList;

	return (
		<List
			title="FAP"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FapSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.fap }
			secondaryText={ (record) => record.dataInicial }
			tertiaryText={ (record) => record.dataFinal }
		/>
	);
}

const FapBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<NumberField source="fap" label="Fap" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataInicial" label="Data Inicial" />
			<TextField source="dataFinal" label="Data Final" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FapList;
