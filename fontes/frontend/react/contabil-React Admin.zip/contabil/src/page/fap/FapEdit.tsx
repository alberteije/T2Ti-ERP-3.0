import {
	Edit,
} from "react-admin";
import { FapForm } from "./FapForm";

const FapEdit = () => {
	return (
		<Edit>
			<FapForm />
		</Edit>
	);
};

export default FapEdit;