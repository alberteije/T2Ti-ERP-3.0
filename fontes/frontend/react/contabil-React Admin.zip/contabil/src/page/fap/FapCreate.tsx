import {
	Create,
} from "react-admin";
import { FapForm } from "./FapForm";

const FapCreate = () => {
	return (
		<Create>
			<FapForm />
		</Create>
	);
};

export default FapCreate;