import {
	Create,
} from "react-admin";
import { ContabilContaForm } from "./ContabilContaForm";

const ContabilContaCreate = () => {
	return (
		<Create>
			<ContabilContaForm />
		</Create>
	);
};

export default ContabilContaCreate;