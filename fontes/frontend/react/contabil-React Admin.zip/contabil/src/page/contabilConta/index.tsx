import ContabilContaIcon from "@mui/icons-material/Apps";
import ContabilContaList from "./ContabilContaList";
import ContabilContaCreate from "./ContabilContaCreate";
import ContabilContaEdit from "./ContabilContaEdit";

export default {
	list: ContabilContaList,
	create: ContabilContaCreate,
	edit: ContabilContaEdit,
	icon: ContabilContaIcon,
};
