import {
	Edit,
} from "react-admin";
import { ContabilContaForm } from "./ContabilContaForm";

const ContabilContaEdit = () => {
	return (
		<Edit>
			<ContabilContaForm />
		</Edit>
	);
};

export default ContabilContaEdit;