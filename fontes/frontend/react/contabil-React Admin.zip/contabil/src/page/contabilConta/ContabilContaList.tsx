/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilContaDomain from '../../data/domain/ContabilContaDomain';

const ContabilContaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["planoContaModel.nome","planoContaRefSpedModel.cod_cta_ref","idContabilConta"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilContaSmallScreenList : ContabilContaBigScreenList;

	return (
		<List
			title="Conta Contábil"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilContaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.planoContaModel.nome }
			secondaryText={ (record) => record.planoContaRefSpedModel.cod_cta_ref }
			tertiaryText={ (record) => record.idContabilConta }
		/>
	);
}

const ContabilContaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Plano Conta" source="planoContaModel.id" reference="plano-conta" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Plano Conta Ref Sped" source="planoContaRefSpedModel.id" reference="plano-conta-ref-sped" sortable={false}>
				<TextField source="cod_cta_ref" />
			</ReferenceField>
			<TextField source="idContabilConta" label="Id Contabil Conta" />
			<TextField source="classificacao" label="Classificacao" />
			<FunctionField
				label="Tipo"
				render={record => ContabilContaDomain.getTipo(record.tipo)}
			/>
			<TextField source="descricao" label="Descricao" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<FunctionField
				label="Situacao"
				render={record => ContabilContaDomain.getSituacao(record.situacao)}
			/>
			<FunctionField
				label="Natureza"
				render={record => ContabilContaDomain.getNatureza(record.natureza)}
			/>
			<FunctionField
				label="Patrimonio Resultado"
				render={record => ContabilContaDomain.getPatrimonioResultado(record.patrimonioResultado)}
			/>
			<FunctionField
				label="Livro Caixa"
				render={record => ContabilContaDomain.getLivroCaixa(record.livroCaixa)}
			/>
			<FunctionField
				label="Dfc"
				render={record => ContabilContaDomain.getDfc(record.dfc)}
			/>
			<TextField source="codigoEfd" label="Codigo Efd" />
			<TextField source="ordem" label="Ordem" />
			<TextField source="codigoReduzido" label="Codigo Reduzido" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilContaList;
