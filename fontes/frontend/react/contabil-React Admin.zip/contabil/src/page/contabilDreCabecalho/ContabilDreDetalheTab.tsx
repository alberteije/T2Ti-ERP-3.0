/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import ContabilDreDetalheDomain from '../../data/domain/ContabilDreDetalheDomain';

class ContabilDreDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContabilDreDetalhe {
		const contabilDreDetalhe = new ContabilDreDetalhe();
		contabilDreDetalhe.id = Date.now();
		contabilDreDetalhe.statusCrud = "C";
		return contabilDreDetalhe;
	}
}

export const ContabilDreDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContabilDreDetalhe,
		setCurrentRecord: (record: ContabilDreDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'classificacao', label: 'Classificacao' },
		{ source: 'descricao', label: 'Descricao' },
		{ source: 'formaCalculo', label: 'Forma Calculo', formatDomain: ContabilDreDetalheDomain.getFormaCalculo },
		{ source: 'sinal', label: 'Sinal', formatDomain: ContabilDreDetalheDomain.getSinal },
		{ source: 'natureza', label: 'Natureza', formatDomain: ContabilDreDetalheDomain.getNatureza },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="contabilDreCabecalho"
			fieldSource="contabilDreDetalheModelList"
			newObject={ ContabilDreDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};