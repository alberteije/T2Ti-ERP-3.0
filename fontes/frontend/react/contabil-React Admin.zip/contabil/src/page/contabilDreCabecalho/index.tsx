import ContabilDreCabecalhoIcon from "@mui/icons-material/Apps";
import ContabilDreCabecalhoList from "./ContabilDreCabecalhoList";
import ContabilDreCabecalhoCreate from "./ContabilDreCabecalhoCreate";
import ContabilDreCabecalhoEdit from "./ContabilDreCabecalhoEdit";

export default {
	list: ContabilDreCabecalhoList,
	create: ContabilDreCabecalhoCreate,
	edit: ContabilDreCabecalhoEdit,
	icon: ContabilDreCabecalhoIcon,
};
