/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContabilDreDetalheTab } from './ContabilDreDetalheTab';

export const ContabilDreCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="DRE">
				<ContabilDreCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<ContabilDreDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContabilDreCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};