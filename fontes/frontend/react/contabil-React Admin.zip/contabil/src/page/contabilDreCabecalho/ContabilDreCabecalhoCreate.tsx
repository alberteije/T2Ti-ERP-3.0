/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContabilDreCabecalhoForm } from "./ContabilDreCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const ContabilDreCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContabilDreCabecalhoForm />
		</Create>
	);
};

export default ContabilDreCabecalhoCreate;