/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContabilDreCabecalhoForm } from "./ContabilDreCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const ContabilDreCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContabilDreCabecalhoForm />
		</Edit>
	);
};

export default ContabilDreCabecalhoEdit;