/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import ContabilDreCabecalhoDomain from '../../data/domain/ContabilDreCabecalhoDomain';

const ContabilDreCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","padrao","periodoInicial"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilDreCabecalhoSmallScreenList : ContabilDreCabecalhoBigScreenList;

	return (
		<List
			title="DRE"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilDreCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.padrao }
			tertiaryText={ (record) => record.periodoInicial }
		/>
	);
}

const ContabilDreCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Padrao"
				render={record => ContabilDreCabecalhoDomain.getPadrao(record.padrao)}
			/>
			<FunctionField
				source="periodoInicial"
				label="Periodo Inicial"
				render={record => formatWithMask(record.periodoInicial, '##/####')}
			/>
			<FunctionField
				source="periodoFinal"
				label="Periodo Final"
				render={record => formatWithMask(record.periodoFinal, '##/####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilDreCabecalhoList;
