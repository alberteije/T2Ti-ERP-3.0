import ContabilLancamentoOrcadoIcon from "@mui/icons-material/Apps";
import ContabilLancamentoOrcadoList from "./ContabilLancamentoOrcadoList";
import ContabilLancamentoOrcadoCreate from "./ContabilLancamentoOrcadoCreate";
import ContabilLancamentoOrcadoEdit from "./ContabilLancamentoOrcadoEdit";

export default {
	list: ContabilLancamentoOrcadoList,
	create: ContabilLancamentoOrcadoCreate,
	edit: ContabilLancamentoOrcadoEdit,
	icon: ContabilLancamentoOrcadoIcon,
};
