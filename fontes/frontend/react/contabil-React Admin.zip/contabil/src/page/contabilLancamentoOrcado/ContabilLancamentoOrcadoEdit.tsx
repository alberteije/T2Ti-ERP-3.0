import {
	Edit,
} from "react-admin";
import { ContabilLancamentoOrcadoForm } from "./ContabilLancamentoOrcadoForm";

const ContabilLancamentoOrcadoEdit = () => {
	return (
		<Edit>
			<ContabilLancamentoOrcadoForm />
		</Edit>
	);
};

export default ContabilLancamentoOrcadoEdit;