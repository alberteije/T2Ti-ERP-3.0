import {
	Create,
} from "react-admin";
import { ContabilLancamentoOrcadoForm } from "./ContabilLancamentoOrcadoForm";

const ContabilLancamentoOrcadoCreate = () => {
	return (
		<Create>
			<ContabilLancamentoOrcadoForm />
		</Create>
	);
};

export default ContabilLancamentoOrcadoCreate;