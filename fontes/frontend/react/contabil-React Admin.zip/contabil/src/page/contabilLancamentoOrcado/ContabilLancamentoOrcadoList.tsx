/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContabilLancamentoOrcadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["contabilContaModel.descricao","ano","janeiro"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilLancamentoOrcadoSmallScreenList : ContabilLancamentoOrcadoBigScreenList;

	return (
		<List
			title="Lançamento Orcado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilLancamentoOrcadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.contabilContaModel.descricao }
			secondaryText={ (record) => record.ano }
			tertiaryText={ (record) => record.janeiro }
		/>
	);
}

const ContabilLancamentoOrcadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Contabil Conta" source="contabilContaModel.id" reference="contabil-conta" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="ano" label="Ano" />
			<NumberField source="janeiro" label="Janeiro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="fevereiro" label="Fevereiro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="marco" label="Marco" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="abril" label="Abril" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="maio" label="Maio" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="junho" label="Junho" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="julho" label="Julho" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="agosto" label="Agosto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="setembro" label="Setembro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="outubro" label="Outubro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="novembro" label="Novembro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="dezembro" label="Dezembro" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilLancamentoOrcadoList;
