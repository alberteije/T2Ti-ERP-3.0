/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContabilLancamentoCabecalhoForm } from "./ContabilLancamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const ContabilLancamentoCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContabilLancamentoCabecalhoForm />
		</Create>
	);
};

export default ContabilLancamentoCabecalhoCreate;