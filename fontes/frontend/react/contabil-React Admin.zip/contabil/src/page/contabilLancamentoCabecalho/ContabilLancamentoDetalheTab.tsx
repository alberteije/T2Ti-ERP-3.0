/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import ContabilLancamentoDetalheDomain from '../../data/domain/ContabilLancamentoDetalheDomain';

class ContabilLancamentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContabilLancamentoDetalhe {
		const contabilLancamentoDetalhe = new ContabilLancamentoDetalhe();
		contabilLancamentoDetalhe.id = Date.now();
		contabilLancamentoDetalhe.statusCrud = "C";
		return contabilLancamentoDetalhe;
	}
}

export const ContabilLancamentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContabilLancamentoDetalhe,
		setCurrentRecord: (record: ContabilLancamentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'contabilContaModel.id', label: 'Conta Contabil', reference: 'contabil-conta', fieldName: 'descricao' },
		{ source: 'contabilHistoricoModel.id', label: 'Historico', reference: 'contabil-historico', fieldName: 'descricao' },
		{ source: 'tipo', label: 'Tipo', formatDomain: ContabilLancamentoDetalheDomain.getTipo },
		{ source: 'valor', label: 'Valor' },
		{ source: 'historico', label: 'Historico' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="contabilLancamentoCabecalho"
			fieldSource="contabilLancamentoDetalheModelList"
			newObject={ ContabilLancamentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};