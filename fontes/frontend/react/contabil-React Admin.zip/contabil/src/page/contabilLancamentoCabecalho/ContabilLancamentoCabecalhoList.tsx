/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilLancamentoCabecalhoDomain from '../../data/domain/ContabilLancamentoCabecalhoDomain';

const ContabilLancamentoCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["contabilLoteModel.descricao","dataLancamento","dataInclusao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilLancamentoCabecalhoSmallScreenList : ContabilLancamentoCabecalhoBigScreenList;

	return (
		<List
			title="Lancamento Contábil"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilLancamentoCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.contabilLoteModel.descricao }
			secondaryText={ (record) => record.dataLancamento }
			tertiaryText={ (record) => record.dataInclusao }
		/>
	);
}

const ContabilLancamentoCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Contabil Lote" source="contabilLoteModel.id" reference="contabil-lote" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="dataLancamento" label="Data Lancamento" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<FunctionField
				label="Tipo"
				render={record => ContabilLancamentoCabecalhoDomain.getTipo(record.tipo)}
			/>
			<FunctionField
				label="Liberado"
				render={record => ContabilLancamentoCabecalhoDomain.getLiberado(record.liberado)}
			/>
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilLancamentoCabecalhoList;
