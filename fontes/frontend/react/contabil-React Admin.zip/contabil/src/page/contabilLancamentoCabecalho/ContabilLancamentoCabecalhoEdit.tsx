/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContabilLancamentoCabecalhoForm } from "./ContabilLancamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const ContabilLancamentoCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContabilLancamentoCabecalhoForm />
		</Edit>
	);
};

export default ContabilLancamentoCabecalhoEdit;