/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ContabilLancamentoDetalheTab } from './ContabilLancamentoDetalheTab';

export const ContabilLancamentoCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Lancamento Contábil">
				<ContabilLancamentoCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<ContabilLancamentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ContabilLancamentoCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};