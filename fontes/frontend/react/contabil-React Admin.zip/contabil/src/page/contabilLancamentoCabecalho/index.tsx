import ContabilLancamentoCabecalhoIcon from "@mui/icons-material/Apps";
import ContabilLancamentoCabecalhoList from "./ContabilLancamentoCabecalhoList";
import ContabilLancamentoCabecalhoCreate from "./ContabilLancamentoCabecalhoCreate";
import ContabilLancamentoCabecalhoEdit from "./ContabilLancamentoCabecalhoEdit";

export default {
	list: ContabilLancamentoCabecalhoList,
	create: ContabilLancamentoCabecalhoCreate,
	edit: ContabilLancamentoCabecalhoEdit,
	icon: ContabilLancamentoCabecalhoIcon,
};
