/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilFechamentoDomain from '../../data/domain/ContabilFechamentoDomain';

const ContabilFechamentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataInicio","dataFim","criterioLancamento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilFechamentoSmallScreenList : ContabilFechamentoBigScreenList;

	return (
		<List
			title="Fechamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilFechamentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataInicio }
			secondaryText={ (record) => record.dataFim }
			tertiaryText={ (record) => record.criterioLancamento }
		/>
	);
}

const ContabilFechamentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<FunctionField
				label="Criterio Lancamento"
				render={record => ContabilFechamentoDomain.getCriterioLancamento(record.criterioLancamento)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilFechamentoList;
