import {
	Create,
} from "react-admin";
import { ContabilFechamentoForm } from "./ContabilFechamentoForm";

const ContabilFechamentoCreate = () => {
	return (
		<Create>
			<ContabilFechamentoForm />
		</Create>
	);
};

export default ContabilFechamentoCreate;