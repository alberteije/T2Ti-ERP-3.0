import {
	Edit,
} from "react-admin";
import { ContabilFechamentoForm } from "./ContabilFechamentoForm";

const ContabilFechamentoEdit = () => {
	return (
		<Edit>
			<ContabilFechamentoForm />
		</Edit>
	);
};

export default ContabilFechamentoEdit;