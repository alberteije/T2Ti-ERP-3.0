import ContabilFechamentoIcon from "@mui/icons-material/Apps";
import ContabilFechamentoList from "./ContabilFechamentoList";
import ContabilFechamentoCreate from "./ContabilFechamentoCreate";
import ContabilFechamentoEdit from "./ContabilFechamentoEdit";

export default {
	list: ContabilFechamentoList,
	create: ContabilFechamentoCreate,
	edit: ContabilFechamentoEdit,
	icon: ContabilFechamentoIcon,
};
