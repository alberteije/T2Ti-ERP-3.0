/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilLoteDomain from '../../data/domain/ContabilLoteDomain';

const ContabilLoteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","dataInclusao","dataLiberacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilLoteSmallScreenList : ContabilLoteBigScreenList;

	return (
		<List
			title="Lote Contábil"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilLoteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.dataInclusao }
			tertiaryText={ (record) => record.dataLiberacao }
		/>
	);
}

const ContabilLoteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="descricao" label="Descricao" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<TextField source="dataLiberacao" label="Data Liberacao" />
			<FunctionField
				label="Liberado"
				render={record => ContabilLoteDomain.getLiberado(record.liberado)}
			/>
			<FunctionField
				label="Programado"
				render={record => ContabilLoteDomain.getProgramado(record.programado)}
			/>
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilLoteList;
