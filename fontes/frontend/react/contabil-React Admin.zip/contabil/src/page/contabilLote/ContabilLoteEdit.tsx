import {
	Edit,
} from "react-admin";
import { ContabilLoteForm } from "./ContabilLoteForm";

const ContabilLoteEdit = () => {
	return (
		<Edit>
			<ContabilLoteForm />
		</Edit>
	);
};

export default ContabilLoteEdit;