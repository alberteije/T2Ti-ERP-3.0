import {
	Create,
} from "react-admin";
import { ContabilLoteForm } from "./ContabilLoteForm";

const ContabilLoteCreate = () => {
	return (
		<Create>
			<ContabilLoteForm />
		</Create>
	);
};

export default ContabilLoteCreate;