import ContabilLoteIcon from "@mui/icons-material/Apps";
import ContabilLoteList from "./ContabilLoteList";
import ContabilLoteCreate from "./ContabilLoteCreate";
import ContabilLoteEdit from "./ContabilLoteEdit";

export default {
	list: ContabilLoteList,
	create: ContabilLoteCreate,
	edit: ContabilLoteEdit,
	icon: ContabilLoteIcon,
};
