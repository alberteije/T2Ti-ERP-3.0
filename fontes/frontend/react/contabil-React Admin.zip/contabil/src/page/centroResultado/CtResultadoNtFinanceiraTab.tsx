/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CtResultadoNtFinanceira {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CtResultadoNtFinanceira {
		const ctResultadoNtFinanceira = new CtResultadoNtFinanceira();
		ctResultadoNtFinanceira.id = Date.now();
		ctResultadoNtFinanceira.statusCrud = "C";
		return ctResultadoNtFinanceira;
	}
}

export const CtResultadoNtFinanceiraTab: React.FC = () => {

	const renderForm = (
		currentRecord: CtResultadoNtFinanceira,
		setCurrentRecord: (record: CtResultadoNtFinanceira) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finNaturezaFinanceiraModel.id', label: 'Natureza Financeira', reference: 'fin-natureza-financeira', fieldName: 'descricao' },
		{ source: 'percentualRateio', label: 'Percentual Rateio' },
	];

	return (
		<CrudChildTab
			title="Natureza Financeira Vinculada"
			recordContext="centroResultado"
			fieldSource="ctResultadoNtFinanceiraModelList"
			newObject={ CtResultadoNtFinanceira.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};