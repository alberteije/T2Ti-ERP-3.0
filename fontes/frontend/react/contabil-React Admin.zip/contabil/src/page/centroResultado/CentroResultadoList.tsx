/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CentroResultadoDomain from '../../data/domain/CentroResultadoDomain';

const CentroResultadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["planoCentroResultadoModel.nome","descricao","classificacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CentroResultadoSmallScreenList : CentroResultadoBigScreenList;

	return (
		<List
			title="Centro de Resultado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CentroResultadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.planoCentroResultadoModel.nome }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.classificacao }
		/>
	);
}

const CentroResultadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Plano Centro Resultado" source="planoCentroResultadoModel.id" reference="plano-centro-resultado" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="descricao" label="Descricao" />
			<TextField source="classificacao" label="Classificacao" />
			<FunctionField
				label="Sofre Rateiro"
				render={record => CentroResultadoDomain.getSofreRateiro(record.sofreRateiro)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CentroResultadoList;
