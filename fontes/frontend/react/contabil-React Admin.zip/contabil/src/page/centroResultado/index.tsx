import CentroResultadoIcon from "@mui/icons-material/Apps";
import CentroResultadoList from "./CentroResultadoList";
import CentroResultadoCreate from "./CentroResultadoCreate";
import CentroResultadoEdit from "./CentroResultadoEdit";

export default {
	list: CentroResultadoList,
	create: CentroResultadoCreate,
	edit: CentroResultadoEdit,
	icon: CentroResultadoIcon,
};
