/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CentroResultadoForm } from "./CentroResultadoForm";
import { transformNestedData } from "../../infra/utils";

const CentroResultadoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CentroResultadoForm />
		</Edit>
	);
};

export default CentroResultadoEdit;