/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { CtResultadoNtFinanceiraTab } from './CtResultadoNtFinanceiraTab';

export const CentroResultadoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Centro de Resultado">
				<CentroResultadoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Natureza Financeira Vinculada">
				<CtResultadoNtFinanceiraTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CentroResultadoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};