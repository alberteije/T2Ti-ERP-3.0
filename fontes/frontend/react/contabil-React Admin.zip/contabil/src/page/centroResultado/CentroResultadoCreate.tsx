/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CentroResultadoForm } from "./CentroResultadoForm";
import { transformNestedData } from "../../infra/utils";

const CentroResultadoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CentroResultadoForm />
		</Create>
	);
};

export default CentroResultadoCreate;