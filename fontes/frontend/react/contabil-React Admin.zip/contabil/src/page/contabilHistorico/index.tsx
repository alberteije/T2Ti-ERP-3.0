import ContabilHistoricoIcon from "@mui/icons-material/Apps";
import ContabilHistoricoList from "./ContabilHistoricoList";
import ContabilHistoricoCreate from "./ContabilHistoricoCreate";
import ContabilHistoricoEdit from "./ContabilHistoricoEdit";

export default {
	list: ContabilHistoricoList,
	create: ContabilHistoricoCreate,
	edit: ContabilHistoricoEdit,
	icon: ContabilHistoricoIcon,
};
