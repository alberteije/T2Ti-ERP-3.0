import {
	Edit,
} from "react-admin";
import { ContabilHistoricoForm } from "./ContabilHistoricoForm";

const ContabilHistoricoEdit = () => {
	return (
		<Edit>
			<ContabilHistoricoForm />
		</Edit>
	);
};

export default ContabilHistoricoEdit;