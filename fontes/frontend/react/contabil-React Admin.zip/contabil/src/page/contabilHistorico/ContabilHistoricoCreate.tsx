import {
	Create,
} from "react-admin";
import { ContabilHistoricoForm } from "./ContabilHistoricoForm";

const ContabilHistoricoCreate = () => {
	return (
		<Create>
			<ContabilHistoricoForm />
		</Create>
	);
};

export default ContabilHistoricoCreate;