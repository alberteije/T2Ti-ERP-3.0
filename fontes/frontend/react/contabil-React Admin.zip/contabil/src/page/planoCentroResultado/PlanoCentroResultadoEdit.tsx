import {
	Edit,
} from "react-admin";
import { PlanoCentroResultadoForm } from "./PlanoCentroResultadoForm";

const PlanoCentroResultadoEdit = () => {
	return (
		<Edit>
			<PlanoCentroResultadoForm />
		</Edit>
	);
};

export default PlanoCentroResultadoEdit;