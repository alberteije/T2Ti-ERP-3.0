import PlanoCentroResultadoIcon from "@mui/icons-material/Apps";
import PlanoCentroResultadoList from "./PlanoCentroResultadoList";
import PlanoCentroResultadoCreate from "./PlanoCentroResultadoCreate";
import PlanoCentroResultadoEdit from "./PlanoCentroResultadoEdit";

export default {
	list: PlanoCentroResultadoList,
	create: PlanoCentroResultadoCreate,
	edit: PlanoCentroResultadoEdit,
	icon: PlanoCentroResultadoIcon,
};
