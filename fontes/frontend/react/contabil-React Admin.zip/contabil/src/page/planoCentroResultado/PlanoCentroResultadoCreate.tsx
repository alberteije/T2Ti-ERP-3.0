import {
	Create,
} from "react-admin";
import { PlanoCentroResultadoForm } from "./PlanoCentroResultadoForm";

const PlanoCentroResultadoCreate = () => {
	return (
		<Create>
			<PlanoCentroResultadoForm />
		</Create>
	);
};

export default PlanoCentroResultadoCreate;