/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import LancaCentroResultadoDomain from '../../data/domain/LancaCentroResultadoDomain';

const LancaCentroResultadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["centroResultadoModel.descricao","valor","dataLancamento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? LancaCentroResultadoSmallScreenList : LancaCentroResultadoBigScreenList;

	return (
		<List
			title="Lançamento Centro Resultado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const LancaCentroResultadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.centroResultadoModel.descricao }
			secondaryText={ (record) => record.valor }
			tertiaryText={ (record) => record.dataLancamento }
		/>
	);
}

const LancaCentroResultadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Centro Resultado" source="centroResultadoModel.id" reference="centro-resultado" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataLancamento" label="Data Lancamento" />
			<TextField source="dataInclusao" label="Data Inclusao" />
			<FunctionField
				label="Origem De Rateio"
				render={record => LancaCentroResultadoDomain.getOrigemDeRateio(record.origemDeRateio)}
			/>
			<TextField source="historico" label="Historico" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default LancaCentroResultadoList;
