import LancaCentroResultadoIcon from "@mui/icons-material/Apps";
import LancaCentroResultadoList from "./LancaCentroResultadoList";
import LancaCentroResultadoCreate from "./LancaCentroResultadoCreate";
import LancaCentroResultadoEdit from "./LancaCentroResultadoEdit";

export default {
	list: LancaCentroResultadoList,
	create: LancaCentroResultadoCreate,
	edit: LancaCentroResultadoEdit,
	icon: LancaCentroResultadoIcon,
};
