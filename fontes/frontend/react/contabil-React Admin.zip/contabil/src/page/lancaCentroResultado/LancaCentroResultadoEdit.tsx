import {
	Edit,
} from "react-admin";
import { LancaCentroResultadoForm } from "./LancaCentroResultadoForm";

const LancaCentroResultadoEdit = () => {
	return (
		<Edit>
			<LancaCentroResultadoForm />
		</Edit>
	);
};

export default LancaCentroResultadoEdit;