import {
	Create,
} from "react-admin";
import { LancaCentroResultadoForm } from "./LancaCentroResultadoForm";

const LancaCentroResultadoCreate = () => {
	return (
		<Create>
			<LancaCentroResultadoForm />
		</Create>
	);
};

export default LancaCentroResultadoCreate;