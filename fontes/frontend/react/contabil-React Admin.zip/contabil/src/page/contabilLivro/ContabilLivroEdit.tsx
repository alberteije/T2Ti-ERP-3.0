/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContabilLivroForm } from "./ContabilLivroForm";
import { transformNestedData } from "../../infra/utils";

const ContabilLivroEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContabilLivroForm />
		</Edit>
	);
};

export default ContabilLivroEdit;