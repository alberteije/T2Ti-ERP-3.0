import ContabilLivroIcon from "@mui/icons-material/Apps";
import ContabilLivroList from "./ContabilLivroList";
import ContabilLivroCreate from "./ContabilLivroCreate";
import ContabilLivroEdit from "./ContabilLivroEdit";

export default {
	list: ContabilLivroList,
	create: ContabilLivroCreate,
	edit: ContabilLivroEdit,
	icon: ContabilLivroIcon,
};
