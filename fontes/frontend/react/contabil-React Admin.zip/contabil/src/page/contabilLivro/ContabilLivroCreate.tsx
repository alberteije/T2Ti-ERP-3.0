/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContabilLivroForm } from "./ContabilLivroForm";
import { transformNestedData } from "../../infra/utils";

const ContabilLivroCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContabilLivroForm />
		</Create>
	);
};

export default ContabilLivroCreate;