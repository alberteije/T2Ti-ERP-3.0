/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import ContabilLivroDomain from '../../data/domain/ContabilLivroDomain';

const ContabilLivroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["competencia","formaEscrituracao","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilLivroSmallScreenList : ContabilLivroBigScreenList;

	return (
		<List
			title="Livros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilLivroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.competencia }
			secondaryText={ (record) => record.formaEscrituracao }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const ContabilLivroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##:####')}
			/>
			<FunctionField
				label="Forma Escrituracao"
				render={record => ContabilLivroDomain.getFormaEscrituracao(record.formaEscrituracao)}
			/>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilLivroList;
