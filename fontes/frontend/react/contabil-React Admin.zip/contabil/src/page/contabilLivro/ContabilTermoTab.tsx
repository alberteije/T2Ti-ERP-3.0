/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import ContabilTermoDomain from '../../data/domain/ContabilTermoDomain';

class ContabilTermo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContabilTermo {
		const contabilTermo = new ContabilTermo();
		contabilTermo.id = Date.now();
		contabilTermo.statusCrud = "C";
		return contabilTermo;
	}
}

export const ContabilTermoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContabilTermo,
		setCurrentRecord: (record: ContabilTermo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'aberturaEncerramento', label: 'Abertura Encerramento', formatDomain: ContabilTermoDomain.getAberturaEncerramento },
		{ source: 'numero', label: 'Numero' },
		{ source: 'paginaInicial', label: 'Pagina Inicial' },
		{ source: 'paginaFinal', label: 'Pagina Final' },
		{ source: 'registrado', label: 'Registrado' },
		{ source: 'numeroRegistro', label: 'Numero Registro' },
		{ source: 'dataDespacho', label: 'Data Despacho' },
		{ source: 'dataAbertura', label: 'Data Abertura' },
		{ source: 'dataEncerramento', label: 'Data Encerramento' },
		{ source: 'escrituracaoInicio', label: 'Escrituracao Inicio' },
		{ source: 'escrituracaoFim', label: 'Escrituracao Fim' },
		{ source: 'texto', label: 'Texto' },
	];

	return (
		<CrudChildTab
			title="Termos"
			recordContext="contabilLivro"
			fieldSource="contabilTermoModelList"
			newObject={ ContabilTermo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};