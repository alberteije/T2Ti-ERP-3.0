import {
	Edit,
} from "react-admin";
import { ContabilParametroForm } from "./ContabilParametroForm";

const ContabilParametroEdit = () => {
	return (
		<Edit>
			<ContabilParametroForm />
		</Edit>
	);
};

export default ContabilParametroEdit;