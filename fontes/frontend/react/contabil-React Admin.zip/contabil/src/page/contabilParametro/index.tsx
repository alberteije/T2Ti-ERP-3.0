import ContabilParametroIcon from "@mui/icons-material/Apps";
import ContabilParametroList from "./ContabilParametroList";
import ContabilParametroCreate from "./ContabilParametroCreate";
import ContabilParametroEdit from "./ContabilParametroEdit";

export default {
	list: ContabilParametroList,
	create: ContabilParametroCreate,
	edit: ContabilParametroEdit,
	icon: ContabilParametroIcon,
};
