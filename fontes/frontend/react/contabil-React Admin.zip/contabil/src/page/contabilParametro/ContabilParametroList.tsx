/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContabilParametroDomain from '../../data/domain/ContabilParametroDomain';

const ContabilParametroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mascara","niveis","informarContaPor"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContabilParametroSmallScreenList : ContabilParametroBigScreenList;

	return (
		<List
			title="Parâmetros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContabilParametroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mascara }
			secondaryText={ (record) => record.niveis }
			tertiaryText={ (record) => record.informarContaPor }
		/>
	);
}

const ContabilParametroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="mascara" label="Mascara" />
			<TextField source="niveis" label="Niveis" />
			<FunctionField
				label="Informar Conta Por"
				render={record => ContabilParametroDomain.getInformarContaPor(record.informarContaPor)}
			/>
			<FunctionField
				label="Compartilha Plano Conta"
				render={record => ContabilParametroDomain.getCompartilhaPlanoConta(record.compartilhaPlanoConta)}
			/>
			<FunctionField
				label="Compartilha Historicos"
				render={record => ContabilParametroDomain.getCompartilhaHistoricos(record.compartilhaHistoricos)}
			/>
			<FunctionField
				label="Altera Lancamento Outro"
				render={record => ContabilParametroDomain.getAlteraLancamentoOutro(record.alteraLancamentoOutro)}
			/>
			<FunctionField
				label="Historico Obrigatorio"
				render={record => ContabilParametroDomain.getHistoricoObrigatorio(record.historicoObrigatorio)}
			/>
			<FunctionField
				label="Permite Lancamento Zerado"
				render={record => ContabilParametroDomain.getPermiteLancamentoZerado(record.permiteLancamentoZerado)}
			/>
			<FunctionField
				label="Gera Informativo Sped"
				render={record => ContabilParametroDomain.getGeraInformativoSped(record.geraInformativoSped)}
			/>
			<FunctionField
				label="Sped Forma Escrit Diario"
				render={record => ContabilParametroDomain.getSpedFormaEscritDiario(record.spedFormaEscritDiario)}
			/>
			<TextField source="spedNomeLivroDiario" label="Sped Nome Livro Diario" />
			<TextField source="assinaturaDireita" label="Assinatura Direita" />
			<TextField source="assinaturaEsquerda" label="Assinatura Esquerda" />
			<TextField source="contaAtivo" label="Conta Ativo" />
			<TextField source="contaPassivo" label="Conta Passivo" />
			<TextField source="contaPatrimonioLiquido" label="Conta Patrimonio Liquido" />
			<TextField source="contaDepreciacaoAcumulada" label="Conta Depreciacao Acumulada" />
			<TextField source="contaCapitalSocial" label="Conta Capital Social" />
			<TextField source="contaResultadoExercicio" label="Conta Resultado Exercicio" />
			<TextField source="contaPrejuizoAcumulado" label="Conta Prejuizo Acumulado" />
			<TextField source="contaLucroAcumulado" label="Conta Lucro Acumulado" />
			<TextField source="contaTituloPagar" label="Conta Titulo Pagar" />
			<TextField source="contaTituloReceber" label="Conta Titulo Receber" />
			<TextField source="contaJurosPassivo" label="Conta Juros Passivo" />
			<TextField source="contaJurosAtivo" label="Conta Juros Ativo" />
			<TextField source="contaDescontoObtido" label="Conta Desconto Obtido" />
			<TextField source="contaDescontoConcedido" label="Conta Desconto Concedido" />
			<TextField source="contaCmv" label="Conta Cmv" />
			<TextField source="contaVenda" label="Conta Venda" />
			<TextField source="contaVendaServico" label="Conta Venda Servico" />
			<TextField source="contaEstoque" label="Conta Estoque" />
			<TextField source="contaApuraResultado" label="Conta Apura Resultado" />
			<TextField source="contaJurosApropriar" label="Conta Juros Apropriar" />
			<TextField source="idHistPadraoResultado" label="Id Hist Padrao Resultado" />
			<TextField source="idHistPadraoLucro" label="Id Hist Padrao Lucro" />
			<TextField source="idHistPadraoPrejuizo" label="Id Hist Padrao Prejuizo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContabilParametroList;
