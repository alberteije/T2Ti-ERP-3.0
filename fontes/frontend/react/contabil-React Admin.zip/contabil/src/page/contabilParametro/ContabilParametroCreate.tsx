import {
	Create,
} from "react-admin";
import { ContabilParametroForm } from "./ContabilParametroForm";

const ContabilParametroCreate = () => {
	return (
		<Create>
			<ContabilParametroForm />
		</Create>
	);
};

export default ContabilParametroCreate;