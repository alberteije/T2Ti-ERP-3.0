import RegistroCartorioIcon from "@mui/icons-material/Apps";
import RegistroCartorioList from "./RegistroCartorioList";
import RegistroCartorioCreate from "./RegistroCartorioCreate";
import RegistroCartorioEdit from "./RegistroCartorioEdit";

export default {
	list: RegistroCartorioList,
	create: RegistroCartorioCreate,
	edit: RegistroCartorioEdit,
	icon: RegistroCartorioIcon,
};
