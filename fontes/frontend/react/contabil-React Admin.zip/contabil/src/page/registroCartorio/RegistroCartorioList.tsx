/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const RegistroCartorioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nomeCartorio","dataRegistro","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? RegistroCartorioSmallScreenList : RegistroCartorioBigScreenList;

	return (
		<List
			title="Registro em Cartório"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const RegistroCartorioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nomeCartorio }
			secondaryText={ (record) => record.dataRegistro }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const RegistroCartorioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nomeCartorio" label="Nome Cartorio" />
			<TextField source="dataRegistro" label="Data Registro" />
			<TextField source="numero" label="Numero" />
			<TextField source="folha" label="Folha" />
			<TextField source="livro" label="Livro" />
			<TextField source="nire" label="Nire" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default RegistroCartorioList;
