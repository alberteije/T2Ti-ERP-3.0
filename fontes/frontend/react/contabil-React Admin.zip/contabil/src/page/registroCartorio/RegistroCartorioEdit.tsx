import {
	Edit,
} from "react-admin";
import { RegistroCartorioForm } from "./RegistroCartorioForm";

const RegistroCartorioEdit = () => {
	return (
		<Edit>
			<RegistroCartorioForm />
		</Edit>
	);
};

export default RegistroCartorioEdit;