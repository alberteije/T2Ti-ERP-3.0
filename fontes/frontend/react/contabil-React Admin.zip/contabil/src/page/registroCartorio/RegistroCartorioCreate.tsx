import {
	Create,
} from "react-admin";
import { RegistroCartorioForm } from "./RegistroCartorioForm";

const RegistroCartorioCreate = () => {
	return (
		<Create>
			<RegistroCartorioForm />
		</Create>
	);
};

export default RegistroCartorioCreate;