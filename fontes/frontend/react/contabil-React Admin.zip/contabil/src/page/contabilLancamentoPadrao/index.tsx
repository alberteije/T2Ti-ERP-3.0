import ContabilLancamentoPadraoIcon from "@mui/icons-material/Apps";
import ContabilLancamentoPadraoList from "./ContabilLancamentoPadraoList";
import ContabilLancamentoPadraoCreate from "./ContabilLancamentoPadraoCreate";
import ContabilLancamentoPadraoEdit from "./ContabilLancamentoPadraoEdit";

export default {
	list: ContabilLancamentoPadraoList,
	create: ContabilLancamentoPadraoCreate,
	edit: ContabilLancamentoPadraoEdit,
	icon: ContabilLancamentoPadraoIcon,
};
