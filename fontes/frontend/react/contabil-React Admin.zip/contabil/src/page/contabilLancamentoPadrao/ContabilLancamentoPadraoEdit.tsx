import {
	Edit,
} from "react-admin";
import { ContabilLancamentoPadraoForm } from "./ContabilLancamentoPadraoForm";

const ContabilLancamentoPadraoEdit = () => {
	return (
		<Edit>
			<ContabilLancamentoPadraoForm />
		</Edit>
	);
};

export default ContabilLancamentoPadraoEdit;