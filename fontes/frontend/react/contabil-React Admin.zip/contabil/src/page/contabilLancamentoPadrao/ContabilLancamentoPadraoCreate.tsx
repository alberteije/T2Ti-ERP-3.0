import {
	Create,
} from "react-admin";
import { ContabilLancamentoPadraoForm } from "./ContabilLancamentoPadraoForm";

const ContabilLancamentoPadraoCreate = () => {
	return (
		<Create>
			<ContabilLancamentoPadraoForm />
		</Create>
	);
};

export default ContabilLancamentoPadraoCreate;