/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class RateioCentroResultadoDet {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): RateioCentroResultadoDet {
		const rateioCentroResultadoDet = new RateioCentroResultadoDet();
		rateioCentroResultadoDet.id = Date.now();
		rateioCentroResultadoDet.statusCrud = "C";
		return rateioCentroResultadoDet;
	}
}

export const RateioCentroResultadoDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: RateioCentroResultadoDet,
		setCurrentRecord: (record: RateioCentroResultadoDet) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'centroResultadoModel.id', label: 'Centro Resultado Destino', reference: 'centro-resultado', fieldName: 'descricao' },
		{ source: 'porcentoRateio', label: 'Porcento Rateio' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="rateioCentroResultadoCab"
			fieldSource="rateioCentroResultadoDetModelList"
			newObject={ RateioCentroResultadoDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};