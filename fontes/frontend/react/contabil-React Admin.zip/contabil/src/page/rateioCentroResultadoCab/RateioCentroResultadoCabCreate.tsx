/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { RateioCentroResultadoCabForm } from "./RateioCentroResultadoCabForm";
import { transformNestedData } from "../../infra/utils";

const RateioCentroResultadoCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<RateioCentroResultadoCabForm />
		</Create>
	);
};

export default RateioCentroResultadoCabCreate;