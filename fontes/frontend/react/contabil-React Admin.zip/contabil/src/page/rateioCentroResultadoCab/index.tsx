import RateioCentroResultadoCabIcon from "@mui/icons-material/Apps";
import RateioCentroResultadoCabList from "./RateioCentroResultadoCabList";
import RateioCentroResultadoCabCreate from "./RateioCentroResultadoCabCreate";
import RateioCentroResultadoCabEdit from "./RateioCentroResultadoCabEdit";

export default {
	list: RateioCentroResultadoCabList,
	create: RateioCentroResultadoCabCreate,
	edit: RateioCentroResultadoCabEdit,
	icon: RateioCentroResultadoCabIcon,
};
