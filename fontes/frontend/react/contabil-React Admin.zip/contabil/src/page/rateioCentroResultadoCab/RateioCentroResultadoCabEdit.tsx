/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { RateioCentroResultadoCabForm } from "./RateioCentroResultadoCabForm";
import { transformNestedData } from "../../infra/utils";

const RateioCentroResultadoCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<RateioCentroResultadoCabForm />
		</Edit>
	);
};

export default RateioCentroResultadoCabEdit;