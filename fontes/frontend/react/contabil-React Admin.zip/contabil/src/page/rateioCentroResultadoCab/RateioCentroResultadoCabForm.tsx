/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { RateioCentroResultadoDetTab } from './RateioCentroResultadoDetTab';

export const RateioCentroResultadoCabForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Rateio Centro Resultado">
				<RateioCentroResultadoCabTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<RateioCentroResultadoDetTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const RateioCentroResultadoCabTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};