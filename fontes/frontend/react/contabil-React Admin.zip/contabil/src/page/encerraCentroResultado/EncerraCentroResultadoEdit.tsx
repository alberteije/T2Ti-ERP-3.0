import {
	Edit,
} from "react-admin";
import { EncerraCentroResultadoForm } from "./EncerraCentroResultadoForm";

const EncerraCentroResultadoEdit = () => {
	return (
		<Edit>
			<EncerraCentroResultadoForm />
		</Edit>
	);
};

export default EncerraCentroResultadoEdit;