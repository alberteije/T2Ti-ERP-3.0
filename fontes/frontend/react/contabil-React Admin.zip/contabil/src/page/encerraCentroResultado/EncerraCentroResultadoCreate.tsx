import {
	Create,
} from "react-admin";
import { EncerraCentroResultadoForm } from "./EncerraCentroResultadoForm";

const EncerraCentroResultadoCreate = () => {
	return (
		<Create>
			<EncerraCentroResultadoForm />
		</Create>
	);
};

export default EncerraCentroResultadoCreate;