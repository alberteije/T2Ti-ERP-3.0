import EncerraCentroResultadoIcon from "@mui/icons-material/Apps";
import EncerraCentroResultadoList from "./EncerraCentroResultadoList";
import EncerraCentroResultadoCreate from "./EncerraCentroResultadoCreate";
import EncerraCentroResultadoEdit from "./EncerraCentroResultadoEdit";

export default {
	list: EncerraCentroResultadoList,
	create: EncerraCentroResultadoCreate,
	edit: EncerraCentroResultadoEdit,
	icon: EncerraCentroResultadoIcon,
};
