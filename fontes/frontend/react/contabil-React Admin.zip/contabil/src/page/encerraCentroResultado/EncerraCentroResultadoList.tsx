/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const EncerraCentroResultadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["centroResultadoModel.descricao","competencia","valorTotal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EncerraCentroResultadoSmallScreenList : EncerraCentroResultadoBigScreenList;

	return (
		<List
			title="Encerra Centro Resultado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EncerraCentroResultadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.centroResultadoModel.descricao }
			secondaryText={ (record) => record.competencia }
			tertiaryText={ (record) => record.valorTotal }
		/>
	);
}

const EncerraCentroResultadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Centro Resultado" source="centroResultadoModel.id" reference="centro-resultado" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##:####')}
			/>
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSubRateio" label="Valor Sub Rateio" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EncerraCentroResultadoList;
