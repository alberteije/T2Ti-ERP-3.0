import {
	Edit,
} from "react-admin";
import { PlanoContaRefSpedForm } from "./PlanoContaRefSpedForm";

const PlanoContaRefSpedEdit = () => {
	return (
		<Edit>
			<PlanoContaRefSpedForm />
		</Edit>
	);
};

export default PlanoContaRefSpedEdit;