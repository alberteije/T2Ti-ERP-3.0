import {
	Create,
} from "react-admin";
import { PlanoContaRefSpedForm } from "./PlanoContaRefSpedForm";

const PlanoContaRefSpedCreate = () => {
	return (
		<Create>
			<PlanoContaRefSpedForm />
		</Create>
	);
};

export default PlanoContaRefSpedCreate;