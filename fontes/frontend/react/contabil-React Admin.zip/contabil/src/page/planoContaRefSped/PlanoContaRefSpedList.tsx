/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PlanoContaRefSpedDomain from '../../data/domain/PlanoContaRefSpedDomain';

const PlanoContaRefSpedList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codCtaRef","inicioValidade","fimValidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PlanoContaRefSpedSmallScreenList : PlanoContaRefSpedBigScreenList;

	return (
		<List
			title="Planos de Contas Sped"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PlanoContaRefSpedSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codCtaRef }
			secondaryText={ (record) => record.inicioValidade }
			tertiaryText={ (record) => record.fimValidade }
		/>
	);
}

const PlanoContaRefSpedBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codCtaRef" label="Cod Cta Ref" />
			<TextField source="inicioValidade" label="Inicio Validade" />
			<TextField source="fimValidade" label="Fim Validade" />
			<FunctionField
				label="Tipo"
				render={record => PlanoContaRefSpedDomain.getTipo(record.tipo)}
			/>
			<TextField source="descricao" label="Descricao" />
			<TextField source="orientacoes" label="Orientacoes" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PlanoContaRefSpedList;
