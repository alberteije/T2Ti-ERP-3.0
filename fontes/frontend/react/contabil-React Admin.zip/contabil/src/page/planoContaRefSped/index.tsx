import PlanoContaRefSpedIcon from "@mui/icons-material/Apps";
import PlanoContaRefSpedList from "./PlanoContaRefSpedList";
import PlanoContaRefSpedCreate from "./PlanoContaRefSpedCreate";
import PlanoContaRefSpedEdit from "./PlanoContaRefSpedEdit";

export default {
	list: PlanoContaRefSpedList,
	create: PlanoContaRefSpedCreate,
	edit: PlanoContaRefSpedEdit,
	icon: PlanoContaRefSpedIcon,
};
