import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import contabilLancamentoCabecalho from '../page/contabilLancamentoCabecalho';
import contabilDreCabecalho from '../page/contabilDreCabecalho';
import contabilLivro from '../page/contabilLivro';
import contabilEncerramentoExeCab from '../page/contabilEncerramentoExeCab';
import centroResultado from '../page/centroResultado';
import rateioCentroResultadoCab from '../page/rateioCentroResultadoCab';
import contabilIndice from '../page/contabilIndice';
import aidfAimdf from '../page/aidfAimdf';
import fap from '../page/fap';
import registroCartorio from '../page/registroCartorio';
import contabilParametro from '../page/contabilParametro';
import planoContaRefSped from '../page/planoContaRefSped';
import planoConta from '../page/planoConta';
import contabilConta from '../page/contabilConta';
import contabilHistorico from '../page/contabilHistorico';
import contabilLancamentoPadrao from '../page/contabilLancamentoPadrao';
import contabilLote from '../page/contabilLote';
import contabilLancamentoOrcado from '../page/contabilLancamentoOrcado';
import lancaCentroResultado from '../page/lancaCentroResultado';
import encerraCentroResultado from '../page/encerraCentroResultado';
import contabilContaRateio from '../page/contabilContaRateio';
import contabilFechamento from '../page/contabilFechamento';
import planoCentroResultado from '../page/planoCentroResultado';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/aidf-aimdf'
					state={{ _scrollToTop: true }}
					primaryText='AIDF/AIMDF'
					leftIcon={<aidfAimdf.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/fap'
					state={{ _scrollToTop: true }}
					primaryText='FAP'
					leftIcon={<fap.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/registro-cartorio'
					state={{ _scrollToTop: true }}
					primaryText='Registro em Cartório'
					leftIcon={<registroCartorio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-parametro'
					state={{ _scrollToTop: true }}
					primaryText='Parâmetros'
					leftIcon={<contabilParametro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/plano-conta-ref-sped'
					state={{ _scrollToTop: true }}
					primaryText='Planos de Contas Sped'
					leftIcon={<planoContaRefSped.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/plano-conta'
					state={{ _scrollToTop: true }}
					primaryText='Plano de Contas'
					leftIcon={<planoConta.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-conta'
					state={{ _scrollToTop: true }}
					primaryText='Conta Contábil'
					leftIcon={<contabilConta.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-historico'
					state={{ _scrollToTop: true }}
					primaryText='Históricos'
					leftIcon={<contabilHistorico.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-lancamento-padrao'
					state={{ _scrollToTop: true }}
					primaryText='Lancamento Padrão'
					leftIcon={<contabilLancamentoPadrao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-lote'
					state={{ _scrollToTop: true }}
					primaryText='Lote Contábil'
					leftIcon={<contabilLote.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-lancamento-orcado'
					state={{ _scrollToTop: true }}
					primaryText='Lançamento Orcado'
					leftIcon={<contabilLancamentoOrcado.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/lanca-centro-resultado'
					state={{ _scrollToTop: true }}
					primaryText='Lançamento Centro Resultado'
					leftIcon={<lancaCentroResultado.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/encerra-centro-resultado'
					state={{ _scrollToTop: true }}
					primaryText='Encerra Centro Resultado'
					leftIcon={<encerraCentroResultado.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-conta-rateio'
					state={{ _scrollToTop: true }}
					primaryText='Rateio Conta Contábil'
					leftIcon={<contabilContaRateio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-fechamento'
					state={{ _scrollToTop: true }}
					primaryText='Fechamento'
					leftIcon={<contabilFechamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/plano-centro-resultado'
					state={{ _scrollToTop: true }}
					primaryText='Plano Centro Resultado'
					leftIcon={<planoCentroResultado.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/contabil-lancamento-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Lancamento Contábil'
					leftIcon={<contabilLancamentoCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-dre-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='DRE'
					leftIcon={<contabilDreCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-livro'
					state={{ _scrollToTop: true }}
					primaryText='Livros'
					leftIcon={<contabilLivro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-encerramento-exe-cab'
					state={{ _scrollToTop: true }}
					primaryText='Encerramento do Exercício'
					leftIcon={<contabilEncerramentoExeCab.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/centro-resultado'
					state={{ _scrollToTop: true }}
					primaryText='Centro de Resultado'
					leftIcon={<centroResultado.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/rateio-centro-resultado-cab'
					state={{ _scrollToTop: true }}
					primaryText='Rateio Centro Resultado'
					leftIcon={<rateioCentroResultadoCab.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/contabil-indice'
					state={{ _scrollToTop: true }}
					primaryText='Índices'
					leftIcon={<contabilIndice.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
