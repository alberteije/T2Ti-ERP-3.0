class FrotaMotoristaDomain {
	static getCnhCategoria(cnhCategoria: string) { 
		switch (cnhCategoria) { 
			case '': 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			case 'D': 
				return 'D'; 
			case 'E': 
				return 'E'; 
			default: 
				return null; 
		} 
	} 

	static setCnhCategoria(cnhCategoria: string) { 
		switch (cnhCategoria) { 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			case 'D': 
				return 'D'; 
			case 'E': 
				return 'E'; 
			default: 
				return null; 
		} 
	}

}

export default FrotaMotoristaDomain;