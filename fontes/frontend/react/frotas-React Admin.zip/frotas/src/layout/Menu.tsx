import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import frotaVeiculo from '../page/frotaVeiculo';
import frotaVeiculoTipo from '../page/frotaVeiculoTipo';
import frotaCombustivelTipo from '../page/frotaCombustivelTipo';
import frotaMotorista from '../page/frotaMotorista';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/frota-veiculo-tipo'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Veiculo'
					leftIcon={<frotaVeiculoTipo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/frota-combustivel-tipo'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Combustível'
					leftIcon={<frotaCombustivelTipo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/frota-motorista'
					state={{ _scrollToTop: true }}
					primaryText='Motorista'
					leftIcon={<frotaMotorista.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/frota-veiculo'
					state={{ _scrollToTop: true }}
					primaryText='Frota Veiculo'
					leftIcon={<frotaVeiculo.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
