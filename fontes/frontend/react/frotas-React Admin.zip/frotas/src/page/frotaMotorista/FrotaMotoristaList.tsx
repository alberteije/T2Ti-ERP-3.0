/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FrotaMotoristaDomain from '../../data/domain/FrotaMotoristaDomain';

const FrotaMotoristaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","nome","numeroCnh"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FrotaMotoristaSmallScreenList : FrotaMotoristaBigScreenList;

	return (
		<List
			title="Motorista"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FrotaMotoristaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.numeroCnh }
		/>
	);
}

const FrotaMotoristaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="numeroCnh" label="Numero Cnh" />
			<FunctionField
				label="Cnh Categoria"
				render={record => FrotaMotoristaDomain.getCnhCategoria(record.cnhCategoria)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FrotaMotoristaList;
