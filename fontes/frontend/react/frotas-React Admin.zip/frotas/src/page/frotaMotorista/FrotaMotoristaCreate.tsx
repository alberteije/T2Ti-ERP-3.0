import {
	Create,
} from "react-admin";
import { FrotaMotoristaForm } from "./FrotaMotoristaForm";

const FrotaMotoristaCreate = () => {
	return (
		<Create>
			<FrotaMotoristaForm />
		</Create>
	);
};

export default FrotaMotoristaCreate;