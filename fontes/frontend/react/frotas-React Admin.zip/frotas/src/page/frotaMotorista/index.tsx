import FrotaMotoristaIcon from "@mui/icons-material/Apps";
import FrotaMotoristaList from "./FrotaMotoristaList";
import FrotaMotoristaCreate from "./FrotaMotoristaCreate";
import FrotaMotoristaEdit from "./FrotaMotoristaEdit";

export default {
	list: FrotaMotoristaList,
	create: FrotaMotoristaCreate,
	edit: FrotaMotoristaEdit,
	icon: FrotaMotoristaIcon,
};
