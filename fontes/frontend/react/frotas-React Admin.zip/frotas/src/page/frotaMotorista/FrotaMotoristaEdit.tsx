import {
	Edit,
} from "react-admin";
import { FrotaMotoristaForm } from "./FrotaMotoristaForm";

const FrotaMotoristaEdit = () => {
	return (
		<Edit>
			<FrotaMotoristaForm />
		</Edit>
	);
};

export default FrotaMotoristaEdit;