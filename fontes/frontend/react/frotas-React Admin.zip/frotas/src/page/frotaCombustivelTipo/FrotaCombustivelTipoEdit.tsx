import {
	Edit,
} from "react-admin";
import { FrotaCombustivelTipoForm } from "./FrotaCombustivelTipoForm";

const FrotaCombustivelTipoEdit = () => {
	return (
		<Edit>
			<FrotaCombustivelTipoForm />
		</Edit>
	);
};

export default FrotaCombustivelTipoEdit;