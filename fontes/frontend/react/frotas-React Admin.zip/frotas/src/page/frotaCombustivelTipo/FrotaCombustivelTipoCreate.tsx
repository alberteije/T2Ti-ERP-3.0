import {
	Create,
} from "react-admin";
import { FrotaCombustivelTipoForm } from "./FrotaCombustivelTipoForm";

const FrotaCombustivelTipoCreate = () => {
	return (
		<Create>
			<FrotaCombustivelTipoForm />
		</Create>
	);
};

export default FrotaCombustivelTipoCreate;