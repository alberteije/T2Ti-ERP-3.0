import FrotaCombustivelTipoIcon from "@mui/icons-material/Apps";
import FrotaCombustivelTipoList from "./FrotaCombustivelTipoList";
import FrotaCombustivelTipoCreate from "./FrotaCombustivelTipoCreate";
import FrotaCombustivelTipoEdit from "./FrotaCombustivelTipoEdit";

export default {
	list: FrotaCombustivelTipoList,
	create: FrotaCombustivelTipoCreate,
	edit: FrotaCombustivelTipoEdit,
	icon: FrotaCombustivelTipoIcon,
};
