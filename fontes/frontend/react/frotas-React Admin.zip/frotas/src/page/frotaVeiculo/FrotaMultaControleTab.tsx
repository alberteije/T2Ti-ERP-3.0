/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaMultaControle {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaMultaControle {
		const frotaMultaControle = new FrotaMultaControle();
		frotaMultaControle.id = Date.now();
		frotaMultaControle.statusCrud = "C";
		return frotaMultaControle;
	}
}

export const FrotaMultaControleTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaMultaControle,
		setCurrentRecord: (record: FrotaMultaControle) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataMulta', label: 'Data Multa' },
		{ source: 'pontos', label: 'Pontos' },
		{ source: 'valor', label: 'Valor' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Multas"
			recordContext="frotaVeiculo"
			fieldSource="frotaMultaControleModelList"
			newObject={ FrotaMultaControle.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};