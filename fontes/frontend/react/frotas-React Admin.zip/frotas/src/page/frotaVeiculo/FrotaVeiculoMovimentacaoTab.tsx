/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaVeiculoMovimentacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaVeiculoMovimentacao {
		const frotaVeiculoMovimentacao = new FrotaVeiculoMovimentacao();
		frotaVeiculoMovimentacao.id = Date.now();
		frotaVeiculoMovimentacao.statusCrud = "C";
		return frotaVeiculoMovimentacao;
	}
}

export const FrotaVeiculoMovimentacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaVeiculoMovimentacao,
		setCurrentRecord: (record: FrotaVeiculoMovimentacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'frotaMotoristaModel.id', label: 'Motorista', reference: 'frota-motorista', fieldName: 'nome' },
		{ source: 'dataSaida', label: 'Data Saida' },
		{ source: 'horaSaida', label: 'Hora Saida', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'dataEntrada', label: 'Data Entrada' },
		{ source: 'horaEntrada', label: 'Hora Entrada', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Movimentação"
			recordContext="frotaVeiculo"
			fieldSource="frotaVeiculoMovimentacaoModelList"
			newObject={ FrotaVeiculoMovimentacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};