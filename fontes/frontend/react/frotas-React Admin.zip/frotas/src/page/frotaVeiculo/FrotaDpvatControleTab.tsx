/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaDpvatControle {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaDpvatControle {
		const frotaDpvatControle = new FrotaDpvatControle();
		frotaDpvatControle.id = Date.now();
		frotaDpvatControle.statusCrud = "C";
		return frotaDpvatControle;
	}
}

export const FrotaDpvatControleTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaDpvatControle,
		setCurrentRecord: (record: FrotaDpvatControle) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'ano', label: 'Ano' },
		{ source: 'parcela', label: 'Parcela' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'dataPagamento', label: 'Data Pagamento' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="DPVAT"
			recordContext="frotaVeiculo"
			fieldSource="frotaDpvatControleModelList"
			newObject={ FrotaDpvatControle.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};