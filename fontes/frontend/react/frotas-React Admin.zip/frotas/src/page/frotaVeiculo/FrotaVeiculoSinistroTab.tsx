/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaVeiculoSinistro {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaVeiculoSinistro {
		const frotaVeiculoSinistro = new FrotaVeiculoSinistro();
		frotaVeiculoSinistro.id = Date.now();
		frotaVeiculoSinistro.statusCrud = "C";
		return frotaVeiculoSinistro;
	}
}

export const FrotaVeiculoSinistroTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaVeiculoSinistro,
		setCurrentRecord: (record: FrotaVeiculoSinistro) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataSinistro', label: 'Data Sinistro' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Sinistros"
			recordContext="frotaVeiculo"
			fieldSource="frotaVeiculoSinistroModelList"
			newObject={ FrotaVeiculoSinistro.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};