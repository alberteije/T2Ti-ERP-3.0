import FrotaVeiculoIcon from "@mui/icons-material/Apps";
import FrotaVeiculoList from "./FrotaVeiculoList";
import FrotaVeiculoCreate from "./FrotaVeiculoCreate";
import FrotaVeiculoEdit from "./FrotaVeiculoEdit";

export default {
	list: FrotaVeiculoList,
	create: FrotaVeiculoCreate,
	edit: FrotaVeiculoEdit,
	icon: FrotaVeiculoIcon,
};
