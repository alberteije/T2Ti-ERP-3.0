/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaIpvaControle {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaIpvaControle {
		const frotaIpvaControle = new FrotaIpvaControle();
		frotaIpvaControle.id = Date.now();
		frotaIpvaControle.statusCrud = "C";
		return frotaIpvaControle;
	}
}

export const FrotaIpvaControleTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaIpvaControle,
		setCurrentRecord: (record: FrotaIpvaControle) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'ano', label: 'Ano' },
		{ source: 'parcela', label: 'Parcela' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'dataPagamento', label: 'Data Pagamento' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="IPVA"
			recordContext="frotaVeiculo"
			fieldSource="frotaIpvaControleModelList"
			newObject={ FrotaIpvaControle.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};