/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FrotaVeiculoForm } from "./FrotaVeiculoForm";
import { transformNestedData } from "../../infra/utils";

const FrotaVeiculoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FrotaVeiculoForm />
		</Create>
	);
};

export default FrotaVeiculoCreate;