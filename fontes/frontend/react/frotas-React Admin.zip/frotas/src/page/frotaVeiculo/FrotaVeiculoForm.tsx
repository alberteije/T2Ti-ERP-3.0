/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FrotaIpvaControleTab } from './FrotaIpvaControleTab';
import { FrotaDpvatControleTab } from './FrotaDpvatControleTab';
import { FrotaVeiculoSinistroTab } from './FrotaVeiculoSinistroTab';
import { FrotaVeiculoMovimentacaoTab } from './FrotaVeiculoMovimentacaoTab';
import { FrotaVeiculoPneuTab } from './FrotaVeiculoPneuTab';
import { FrotaVeiculoManutencaoTab } from './FrotaVeiculoManutencaoTab';
import { FrotaMultaControleTab } from './FrotaMultaControleTab';
import { FrotaCombustivelControleTab } from './FrotaCombustivelControleTab';

export const FrotaVeiculoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Frota Veiculo">
				<FrotaVeiculoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="IPVA">
				<FrotaIpvaControleTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="DPVAT">
				<FrotaDpvatControleTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Sinistros">
				<FrotaVeiculoSinistroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Movimentação">
				<FrotaVeiculoMovimentacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Pneus">
				<FrotaVeiculoPneuTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Manutenção">
				<FrotaVeiculoManutencaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Multas">
				<FrotaMultaControleTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Controle Combustível">
				<FrotaCombustivelControleTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FrotaVeiculoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};