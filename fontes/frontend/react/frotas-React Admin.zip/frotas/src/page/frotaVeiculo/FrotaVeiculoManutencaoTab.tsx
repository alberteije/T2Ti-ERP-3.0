/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FrotaVeiculoManutencaoDomain from '../../data/domain/FrotaVeiculoManutencaoDomain';

class FrotaVeiculoManutencao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaVeiculoManutencao {
		const frotaVeiculoManutencao = new FrotaVeiculoManutencao();
		frotaVeiculoManutencao.id = Date.now();
		frotaVeiculoManutencao.statusCrud = "C";
		return frotaVeiculoManutencao;
	}
}

export const FrotaVeiculoManutencaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaVeiculoManutencao,
		setCurrentRecord: (record: FrotaVeiculoManutencao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tipo', label: 'Tipo', formatDomain: FrotaVeiculoManutencaoDomain.getTipo },
		{ source: 'dataManutencao', label: 'Data Manutencao' },
		{ source: 'valorManutencao', label: 'Valor Manutencao' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Manutenção"
			recordContext="frotaVeiculo"
			fieldSource="frotaVeiculoManutencaoModelList"
			newObject={ FrotaVeiculoManutencao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};