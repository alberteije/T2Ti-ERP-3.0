/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FrotaVeiculoDomain from '../../data/domain/FrotaVeiculoDomain';

const FrotaVeiculoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["frotaVeiculoTipoModel.nome","frotaCombustivelTipoModel.nome","marca"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FrotaVeiculoSmallScreenList : FrotaVeiculoBigScreenList;

	return (
		<List
			title="Frota Veiculo"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FrotaVeiculoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.frotaVeiculoTipoModel.nome }
			secondaryText={ (record) => record.frotaCombustivelTipoModel.nome }
			tertiaryText={ (record) => record.marca }
		/>
	);
}

const FrotaVeiculoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Frota Veiculo Tipo" source="frotaVeiculoTipoModel.id" reference="frota-veiculo-tipo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Frota Combustivel Tipo" source="frotaCombustivelTipoModel.id" reference="frota-combustivel-tipo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="marca" label="Marca" />
			<TextField source="modelo" label="Modelo" />
			<TextField source="modeloAno" label="Modelo Ano" />
			<TextField source="placa" label="Placa" />
			<TextField source="codigoFipe" label="Codigo Fipe" />
			<TextField source="renavam" label="Renavam" />
			<FunctionField
				label="Ipva Mes Vencimento"
				render={record => FrotaVeiculoDomain.getIpvaMesVencimento(record.ipvaMesVencimento)}
			/>
			<FunctionField
				label="Dpvat Mes Vencimento"
				render={record => FrotaVeiculoDomain.getDpvatMesVencimento(record.dpvatMesVencimento)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FrotaVeiculoList;
