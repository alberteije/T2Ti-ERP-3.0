/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaVeiculoPneu {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaVeiculoPneu {
		const frotaVeiculoPneu = new FrotaVeiculoPneu();
		frotaVeiculoPneu.id = Date.now();
		frotaVeiculoPneu.statusCrud = "C";
		return frotaVeiculoPneu;
	}
}

export const FrotaVeiculoPneuTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaVeiculoPneu,
		setCurrentRecord: (record: FrotaVeiculoPneu) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataTroca', label: 'Data Troca' },
		{ source: 'valorTroca', label: 'Valor Troca' },
		{ source: 'posicaoPneu', label: 'Posicao Pneu' },
		{ source: 'marcaPneu', label: 'Marca Pneu' },
	];

	return (
		<CrudChildTab
			title="Pneus"
			recordContext="frotaVeiculo"
			fieldSource="frotaVeiculoPneuModelList"
			newObject={ FrotaVeiculoPneu.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};