/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FrotaCombustivelControle {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FrotaCombustivelControle {
		const frotaCombustivelControle = new FrotaCombustivelControle();
		frotaCombustivelControle.id = Date.now();
		frotaCombustivelControle.statusCrud = "C";
		return frotaCombustivelControle;
	}
}

export const FrotaCombustivelControleTab: React.FC = () => {

	const renderForm = (
		currentRecord: FrotaCombustivelControle,
		setCurrentRecord: (record: FrotaCombustivelControle) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataAbastecimento', label: 'Data Abastecimento' },
		{ source: 'horaAbastecimento', label: 'Hora Abastecimento', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'valorAbastecimento', label: 'Valor Abastecimento' },
	];

	return (
		<CrudChildTab
			title="Controle Combustível"
			recordContext="frotaVeiculo"
			fieldSource="frotaCombustivelControleModelList"
			newObject={ FrotaCombustivelControle.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};