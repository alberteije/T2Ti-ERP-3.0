/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FrotaVeiculoForm } from "./FrotaVeiculoForm";
import { transformNestedData } from "../../infra/utils";

const FrotaVeiculoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FrotaVeiculoForm />
		</Edit>
	);
};

export default FrotaVeiculoEdit;