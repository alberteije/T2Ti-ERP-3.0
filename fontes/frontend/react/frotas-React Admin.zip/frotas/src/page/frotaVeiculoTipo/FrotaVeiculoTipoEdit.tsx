import {
	Edit,
} from "react-admin";
import { FrotaVeiculoTipoForm } from "./FrotaVeiculoTipoForm";

const FrotaVeiculoTipoEdit = () => {
	return (
		<Edit>
			<FrotaVeiculoTipoForm />
		</Edit>
	);
};

export default FrotaVeiculoTipoEdit;