import {
	Create,
} from "react-admin";
import { FrotaVeiculoTipoForm } from "./FrotaVeiculoTipoForm";

const FrotaVeiculoTipoCreate = () => {
	return (
		<Create>
			<FrotaVeiculoTipoForm />
		</Create>
	);
};

export default FrotaVeiculoTipoCreate;