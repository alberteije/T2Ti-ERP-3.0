import FrotaVeiculoTipoIcon from "@mui/icons-material/Apps";
import FrotaVeiculoTipoList from "./FrotaVeiculoTipoList";
import FrotaVeiculoTipoCreate from "./FrotaVeiculoTipoCreate";
import FrotaVeiculoTipoEdit from "./FrotaVeiculoTipoEdit";

export default {
	list: FrotaVeiculoTipoList,
	create: FrotaVeiculoTipoCreate,
	edit: FrotaVeiculoTipoEdit,
	icon: FrotaVeiculoTipoIcon,
};
