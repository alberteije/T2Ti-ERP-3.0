/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PdvTipoPlanoForm } from "./PdvTipoPlanoForm";
import { transformNestedData } from "../../infra/utils";

const PdvTipoPlanoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PdvTipoPlanoForm />
		</Create>
	);
};

export default PdvTipoPlanoCreate;