import PdvTipoPlanoIcon from "@mui/icons-material/Apps";
import PdvTipoPlanoList from "./PdvTipoPlanoList";
import PdvTipoPlanoCreate from "./PdvTipoPlanoCreate";
import PdvTipoPlanoEdit from "./PdvTipoPlanoEdit";

export default {
	list: PdvTipoPlanoList,
	create: PdvTipoPlanoCreate,
	edit: PdvTipoPlanoEdit,
	icon: PdvTipoPlanoIcon,
};
