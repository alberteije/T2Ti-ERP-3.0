/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PdvPlanoPagamentoTab } from './PdvPlanoPagamentoTab';

export const PdvTipoPlanoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Pdv Tipo Plano">
				<PdvTipoPlanoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Pdv Plano Pagamento">
				<PdvPlanoPagamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PdvTipoPlanoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};