/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PdvTipoPlanoDomain from '../../data/domain/PdvTipoPlanoDomain';

const PdvTipoPlanoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["modulo","plano","moduloFiscal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PdvTipoPlanoSmallScreenList : PdvTipoPlanoBigScreenList;

	return (
		<List
			title="Pdv Tipo Plano"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PdvTipoPlanoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.modulo }
			secondaryText={ (record) => record.plano }
			tertiaryText={ (record) => record.moduloFiscal }
		/>
	);
}

const PdvTipoPlanoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Modulo"
				render={record => PdvTipoPlanoDomain.getModulo(record.modulo)}
			/>
			<FunctionField
				label="Plano"
				render={record => PdvTipoPlanoDomain.getPlano(record.plano)}
			/>
			<FunctionField
				label="Modulo Fiscal"
				render={record => PdvTipoPlanoDomain.getModuloFiscal(record.moduloFiscal)}
			/>
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PdvTipoPlanoList;
