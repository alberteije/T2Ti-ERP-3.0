/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PdvTipoPlanoForm } from "./PdvTipoPlanoForm";
import { transformNestedData } from "../../infra/utils";

const PdvTipoPlanoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PdvTipoPlanoForm />
		</Edit>
	);
};

export default PdvTipoPlanoEdit;