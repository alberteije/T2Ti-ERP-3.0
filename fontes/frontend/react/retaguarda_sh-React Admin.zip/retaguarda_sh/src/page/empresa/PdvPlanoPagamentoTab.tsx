/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import PdvPlanoPagamentoDomain from '../../data/domain/PdvPlanoPagamentoDomain';

class PdvPlanoPagamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PdvPlanoPagamento {
		const pdvPlanoPagamento = new PdvPlanoPagamento();
		pdvPlanoPagamento.id = Date.now();
		pdvPlanoPagamento.statusCrud = "C";
		return pdvPlanoPagamento;
	}
}

export const PdvPlanoPagamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PdvPlanoPagamento,
		setCurrentRecord: (record: PdvPlanoPagamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idEmpresa', label: 'Id Empresa' },
		{ source: 'idPdvTipoPlano', label: 'Id Pdv Tipo Plano' },
		{ source: 'dataSolicitacao', label: 'Data Solicitacao' },
		{ source: 'dataPagamento', label: 'Data Pagamento' },
		{ source: 'plano', label: 'Plano', formatDomain: PdvPlanoPagamentoDomain.getPlano },
		{ source: 'valor', label: 'Valor' },
		{ source: 'statusPagamento', label: 'Status Pagamento', formatDomain: PdvPlanoPagamentoDomain.getStatusPagamento },
		{ source: 'codigoTransacao', label: 'Codigo Transacao' },
		{ source: 'metodoPagamento', label: 'Metodo Pagamento', formatDomain: PdvPlanoPagamentoDomain.getMetodoPagamento },
		{ source: 'codigoTipoPagamento', label: 'Codigo Tipo Pagamento', formatDomain: PdvPlanoPagamentoDomain.getCodigoTipoPagamento },
		{ source: 'dataPlanoExpira', label: 'Data Plano Expira' },
		{ source: 'emailPagamento', label: 'Email Pagamento' },
	];

	return (
		<CrudChildTab
			title="Pdv Plano Pagamento"
			recordContext="empresa"
			fieldSource="pdvPlanoPagamentoModelList"
			newObject={ PdvPlanoPagamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};