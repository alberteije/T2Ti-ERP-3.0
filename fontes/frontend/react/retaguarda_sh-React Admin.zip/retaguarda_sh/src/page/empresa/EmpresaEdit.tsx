/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { EmpresaForm } from "./EmpresaForm";
import { transformNestedData } from "../../infra/utils";

const EmpresaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<EmpresaForm />
		</Edit>
	);
};

export default EmpresaEdit;