/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeConfiguracaoDomain from '../../data/domain/NfeConfiguracaoDomain';

class NfeConfiguracao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeConfiguracao {
		const nfeConfiguracao = new NfeConfiguracao();
		nfeConfiguracao.id = Date.now();
		nfeConfiguracao.statusCrud = "C";
		return nfeConfiguracao;
	}
}

export const NfeConfiguracaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeConfiguracao,
		setCurrentRecord: (record: NfeConfiguracao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idEmpresa', label: 'Id Empresa' },
		{ source: 'certificadoDigitalSerie', label: 'Certificado Digital Serie' },
		{ source: 'certificadoDigitalCaminho', label: 'Certificado Digital Caminho' },
		{ source: 'certificadoDigitalSenha', label: 'Certificado Digital Senha' },
		{ source: 'tipoEmissao', label: 'Tipo Emissao' },
		{ source: 'formatoImpressaoDanfe', label: 'Formato Impressao Danfe' },
		{ source: 'processoEmissao', label: 'Processo Emissao' },
		{ source: 'versaoProcessoEmissao', label: 'Versao Processo Emissao' },
		{ source: 'caminhoLogomarca', label: 'Caminho Logomarca' },
		{ source: 'salvarXml', label: 'Salvar Xml', formatDomain: NfeConfiguracaoDomain.getSalvarXml },
		{ source: 'caminhoSalvarXml', label: 'Caminho Salvar Xml' },
		{ source: 'caminhoSchemas', label: 'Caminho Schemas' },
		{ source: 'caminhoArquivoDanfe', label: 'Caminho Arquivo Danfe' },
		{ source: 'caminhoSalvarPdf', label: 'Caminho Salvar Pdf' },
		{ source: 'webserviceUf', label: 'Webservice Uf', formatDomain: NfeConfiguracaoDomain.getWebserviceUf },
		{ source: 'webserviceAmbiente', label: 'Webservice Ambiente' },
		{ source: 'webserviceProxyHost', label: 'Webservice Proxy Host' },
		{ source: 'webserviceProxyPorta', label: 'Webservice Proxy Porta' },
		{ source: 'webserviceProxyUsuario', label: 'Webservice Proxy Usuario' },
		{ source: 'webserviceProxySenha', label: 'Webservice Proxy Senha' },
		{ source: 'webserviceVisualizar', label: 'Webservice Visualizar', formatDomain: NfeConfiguracaoDomain.getWebserviceVisualizar },
		{ source: 'emailServidorSmtp', label: 'Email Servidor Smtp' },
		{ source: 'emailPorta', label: 'Email Porta' },
		{ source: 'emailUsuario', label: 'Email Usuario' },
		{ source: 'emailSenha', label: 'Email Senha' },
		{ source: 'emailAssunto', label: 'Email Assunto' },
		{ source: 'emailAutenticaSsl', label: 'Email Autentica Ssl', formatDomain: NfeConfiguracaoDomain.getEmailAutenticaSsl },
		{ source: 'emailTexto', label: 'Email Texto' },
		{ source: 'nfceIdCsc', label: 'Nfce Id Csc' },
		{ source: 'nfceCsc', label: 'Nfce Csc' },
		{ source: 'nfceModeloImpressao', label: 'Nfce Modelo Impressao', formatDomain: NfeConfiguracaoDomain.getNfceModeloImpressao },
		{ source: 'nfceImprimirItensUmaLinha', label: 'Nfce Imprimir Itens Uma Linha', formatDomain: NfeConfiguracaoDomain.getNfceImprimirItensUmaLinha },
		{ source: 'nfceImprimirDescontoPorItem', label: 'Nfce Imprimir Desconto Por Item', formatDomain: NfeConfiguracaoDomain.getNfceImprimirDescontoPorItem },
		{ source: 'nfceImprimirQrcodeLateral', label: 'Nfce Imprimir Qrcode Lateral', formatDomain: NfeConfiguracaoDomain.getNfceImprimirQrcodeLateral },
		{ source: 'nfceImprimirGtin', label: 'Nfce Imprimir Gtin', formatDomain: NfeConfiguracaoDomain.getNfceImprimirGtin },
		{ source: 'nfceImprimirNomeFantasia', label: 'Nfce Imprimir Nome Fantasia', formatDomain: NfeConfiguracaoDomain.getNfceImprimirNomeFantasia },
		{ source: 'nfceImpressaoTributos', label: 'Nfce Impressao Tributos', formatDomain: NfeConfiguracaoDomain.getNfceImpressaoTributos },
		{ source: 'nfceMargemSuperior', label: 'Nfce Margem Superior' },
		{ source: 'nfceMargemInferior', label: 'Nfce Margem Inferior' },
		{ source: 'nfceMargemDireita', label: 'Nfce Margem Direita' },
		{ source: 'nfceMargemEsquerda', label: 'Nfce Margem Esquerda' },
		{ source: 'nfceResolucaoImpressao', label: 'Nfce Resolucao Impressao' },
		{ source: 'nfceTamanhoFonteItem', label: 'Nfce Tamanho Fonte Item' },
		{ source: 'respTecCnpj', label: 'Resp Tec Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'respTecContato', label: 'Resp Tec Contato' },
		{ source: 'respTecEmail', label: 'Resp Tec Email' },
		{ source: 'respTecFone', label: 'Resp Tec Fone' },
		{ source: 'respTecIdCsrt', label: 'Resp Tec Id Csrt', formatDomain: NfeConfiguracaoDomain.getRespTecIdCsrt },
		{ source: 'respTecHashCsrt', label: 'Resp Tec Hash Csrt' },
	];

	return (
		<CrudChildTab
			title="Nfe Configuracao"
			recordContext="empresa"
			fieldSource="nfeConfiguracaoModelList"
			newObject={ NfeConfiguracao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};