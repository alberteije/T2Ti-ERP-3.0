/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class AcbrMonitorPorta {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): AcbrMonitorPorta {
		const acbrMonitorPorta = new AcbrMonitorPorta();
		acbrMonitorPorta.id = Date.now();
		acbrMonitorPorta.statusCrud = "C";
		return acbrMonitorPorta;
	}
}

export const AcbrMonitorPortaTab: React.FC = () => {

	const renderForm = (
		currentRecord: AcbrMonitorPorta,
		setCurrentRecord: (record: AcbrMonitorPorta) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idEmpresa', label: 'Id Empresa' },
	];

	return (
		<CrudChildTab
			title="Acbr Monitor Porta"
			recordContext="empresa"
			fieldSource="acbrMonitorPortaModelList"
			newObject={ AcbrMonitorPorta.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};