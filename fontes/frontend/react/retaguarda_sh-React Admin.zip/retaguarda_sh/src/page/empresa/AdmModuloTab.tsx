/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class AdmModulo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): AdmModulo {
		const admModulo = new AdmModulo();
		admModulo.id = Date.now();
		admModulo.statusCrud = "C";
		return admModulo;
	}
}

export const AdmModuloTab: React.FC = () => {

	const renderForm = (
		currentRecord: AdmModulo,
		setCurrentRecord: (record: AdmModulo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigo', label: 'Codigo' },
		{ source: 'bloco', label: 'Bloco' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'descricao', label: 'Descricao' },
		{ source: 'link', label: 'Link' },
	];

	return (
		<CrudChildTab
			title="Adm Modulo"
			recordContext="empresa"
			fieldSource="admModuloModelList"
			newObject={ AdmModulo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};