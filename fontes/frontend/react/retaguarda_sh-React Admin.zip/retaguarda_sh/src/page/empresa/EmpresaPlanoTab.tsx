/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class EmpresaPlano {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaPlano {
		const empresaPlano = new EmpresaPlano();
		empresaPlano.id = Date.now();
		empresaPlano.statusCrud = "C";
		return empresaPlano;
	}
}

export const EmpresaPlanoTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaPlano,
		setCurrentRecord: (record: EmpresaPlano) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'planModel.id', label: 'Id Erp Tipo Plano', reference: 'plan', fieldName: 'name' },
		{ source: 'dataInicio', label: 'Data Inicio' },
		{ source: 'dataFim', label: 'Data Fim' },
		{ source: 'valorPago', label: 'Valor Pago' },
		{ source: 'idPagamentoPlataforma', label: 'Id Pagamento Plataforma' },
		{ source: 'statusPagamentoPlataforma', label: 'Status Pagamento Plataforma' },
	];

	return (
		<CrudChildTab
			title="Empresa Plano"
			recordContext="empresa"
			fieldSource="empresaPlanoModelList"
			newObject={ EmpresaPlano.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};