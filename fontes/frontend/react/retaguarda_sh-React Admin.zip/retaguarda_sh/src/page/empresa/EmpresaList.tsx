/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import EmpresaDomain from '../../data/domain/EmpresaDomain';

const EmpresaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["razaoSocial","nomeFantasia","cnpj"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EmpresaSmallScreenList : EmpresaBigScreenList;

	return (
		<List
			title="Empresa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EmpresaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.razaoSocial }
			secondaryText={ (record) => record.nomeFantasia }
			tertiaryText={ (record) => record.cnpj }
		/>
	);
}

const EmpresaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="razaoSocial" label="Razao Social" />
			<TextField source="nomeFantasia" label="Nome Fantasia" />
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<TextField source="inscricaoEstadual" label="Inscricao Estadual" />
			<TextField source="inscricaoMunicipal" label="Inscricao Municipal" />
			<FunctionField
				label="Tipo Regime"
				render={record => EmpresaDomain.getTipoRegime(record.tipoRegime)}
			/>
			<FunctionField
				label="Crt"
				render={record => EmpresaDomain.getCrt(record.crt)}
			/>
			<TextField source="dataConstituicao" label="Data Constituicao" />
			<FunctionField
				label="Tipo"
				render={record => EmpresaDomain.getTipo(record.tipo)}
			/>
			<TextField source="email" label="Email" />
			<TextField source="logradouro" label="Logradouro" />
			<TextField source="numero" label="Numero" />
			<TextField source="complemento" label="Complemento" />
			<FunctionField
				source="cep"
				label="Cep"
				render={record => formatWithMask(record.cep, '#####-###')}
			/>
			<TextField source="bairro" label="Bairro" />
			<TextField source="cidade" label="Cidade" />
			<FunctionField
				label="Uf"
				render={record => EmpresaDomain.getUf(record.uf)}
			/>
			<TextField source="fone" label="Fone" />
			<TextField source="contato" label="Contato" />
			<TextField source="codigoIbgeCidade" label="Codigo Ibge Cidade" />
			<TextField source="codigoIbgeUf" label="Codigo Ibge Uf" />
			<TextField source="logotipo" label="Logotipo" />
			<FunctionField
				label="Registrado"
				render={record => EmpresaDomain.getRegistrado(record.registrado)}
			/>
			<TextField source="naturezaJuridica" label="Natureza Juridica" />
			<FunctionField
				label="Simei"
				render={record => EmpresaDomain.getSimei(record.simei)}
			/>
			<TextField source="emailPagamento" label="Email Pagamento" />
			<TextField source="dataRegistro" label="Data Registro" />
			<TextField source="horaRegistro" label="Hora Registro" />
			<TextField source="idPlataformaPagamento" label="Id Plataforma Pagamento" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EmpresaList;
