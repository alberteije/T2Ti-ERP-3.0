import {
	Create,
} from "react-admin";
import { ErpTipoPlanoForm } from "./ErpTipoPlanoForm";

const ErpTipoPlanoCreate = () => {
	return (
		<Create>
			<ErpTipoPlanoForm />
		</Create>
	);
};

export default ErpTipoPlanoCreate;