import {
	Edit,
} from "react-admin";
import { ErpTipoPlanoForm } from "./ErpTipoPlanoForm";

const ErpTipoPlanoEdit = () => {
	return (
		<Edit>
			<ErpTipoPlanoForm />
		</Edit>
	);
};

export default ErpTipoPlanoEdit;