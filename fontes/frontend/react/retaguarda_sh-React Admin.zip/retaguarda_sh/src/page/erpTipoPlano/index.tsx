import ErpTipoPlanoIcon from "@mui/icons-material/Apps";
import ErpTipoPlanoList from "./ErpTipoPlanoList";
import ErpTipoPlanoCreate from "./ErpTipoPlanoCreate";
import ErpTipoPlanoEdit from "./ErpTipoPlanoEdit";

export default {
	list: ErpTipoPlanoList,
	create: ErpTipoPlanoCreate,
	edit: ErpTipoPlanoEdit,
	icon: ErpTipoPlanoIcon,
};
