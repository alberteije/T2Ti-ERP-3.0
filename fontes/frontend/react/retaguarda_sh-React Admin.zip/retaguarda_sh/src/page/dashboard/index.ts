import DashboardComponent from './Dashboard';

export const Dashboard = DashboardComponent;