class AgendaCompromissoDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'P': 
				return 'Pessoal'; 
			case 'G': 
				return 'Gerencial'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Pessoal': 
				return 'P'; 
			case 'Gerencial': 
				return 'G'; 
			default: 
				return null; 
		} 
	}

}

export default AgendaCompromissoDomain;