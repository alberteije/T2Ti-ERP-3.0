/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const AgendaCategoriaCompromissoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","cor"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? AgendaCategoriaCompromissoSmallScreenList : AgendaCategoriaCompromissoBigScreenList;

	return (
		<List
			title="Categoria Compromisso"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const AgendaCategoriaCompromissoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.cor }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const AgendaCategoriaCompromissoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="cor" label="Cor" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default AgendaCategoriaCompromissoList;
