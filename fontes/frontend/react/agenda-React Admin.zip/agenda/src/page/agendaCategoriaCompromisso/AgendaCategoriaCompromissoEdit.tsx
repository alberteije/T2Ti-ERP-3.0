import {
	Edit,
} from "react-admin";
import { AgendaCategoriaCompromissoForm } from "./AgendaCategoriaCompromissoForm";

const AgendaCategoriaCompromissoEdit = () => {
	return (
		<Edit>
			<AgendaCategoriaCompromissoForm />
		</Edit>
	);
};

export default AgendaCategoriaCompromissoEdit;