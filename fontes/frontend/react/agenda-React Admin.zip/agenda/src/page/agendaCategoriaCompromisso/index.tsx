import AgendaCategoriaCompromissoIcon from "@mui/icons-material/Apps";
import AgendaCategoriaCompromissoList from "./AgendaCategoriaCompromissoList";
import AgendaCategoriaCompromissoCreate from "./AgendaCategoriaCompromissoCreate";
import AgendaCategoriaCompromissoEdit from "./AgendaCategoriaCompromissoEdit";

export default {
	list: AgendaCategoriaCompromissoList,
	create: AgendaCategoriaCompromissoCreate,
	edit: AgendaCategoriaCompromissoEdit,
	icon: AgendaCategoriaCompromissoIcon,
};
