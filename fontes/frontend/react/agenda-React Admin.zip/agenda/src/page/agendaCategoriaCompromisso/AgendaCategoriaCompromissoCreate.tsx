import {
	Create,
} from "react-admin";
import { AgendaCategoriaCompromissoForm } from "./AgendaCategoriaCompromissoForm";

const AgendaCategoriaCompromissoCreate = () => {
	return (
		<Create>
			<AgendaCategoriaCompromissoForm />
		</Create>
	);
};

export default AgendaCategoriaCompromissoCreate;