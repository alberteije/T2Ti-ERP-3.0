/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class RecadoDestinatario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): RecadoDestinatario {
		const recadoDestinatario = new RecadoDestinatario();
		recadoDestinatario.id = Date.now();
		recadoDestinatario.statusCrud = "C";
		return recadoDestinatario;
	}
}

export const RecadoDestinatarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: RecadoDestinatario,
		setCurrentRecord: (record: RecadoDestinatario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'viewPessoaColaboradorModel.id', label: 'Destinatário', reference: 'view-pessoa-colaborador', fieldName: 'nome' },
	];

	return (
		<CrudChildTab
			title="Destinatarios"
			recordContext="recadoRemetente"
			fieldSource="recadoDestinatarioModelList"
			newObject={ RecadoDestinatario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};