/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { RecadoRemetenteForm } from "./RecadoRemetenteForm";
import { transformNestedData } from "../../infra/utils";

const RecadoRemetenteCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<RecadoRemetenteForm />
		</Create>
	);
};

export default RecadoRemetenteCreate;