/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { RecadoDestinatarioTab } from './RecadoDestinatarioTab';

export const RecadoRemetenteForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Recado">
				<RecadoRemetenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Destinatarios">
				<RecadoDestinatarioTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const RecadoRemetenteTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};