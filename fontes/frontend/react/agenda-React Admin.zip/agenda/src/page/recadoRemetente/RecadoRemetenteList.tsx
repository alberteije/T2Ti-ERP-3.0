/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const RecadoRemetenteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataEnvio","horaEnvio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? RecadoRemetenteSmallScreenList : RecadoRemetenteBigScreenList;

	return (
		<List
			title="Recado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const RecadoRemetenteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataEnvio }
			tertiaryText={ (record) => record.horaEnvio }
		/>
	);
}

const RecadoRemetenteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataEnvio" label="Data Envio" />
			<FunctionField
				source="horaEnvio"
				label="Hora Envio"
				render={record => formatWithMask(record.horaEnvio, '##:##:##')}
			/>
			<TextField source="assunto" label="Assunto" />
			<TextField source="texto" label="Texto" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default RecadoRemetenteList;
