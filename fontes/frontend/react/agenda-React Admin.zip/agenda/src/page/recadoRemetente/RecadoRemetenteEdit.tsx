/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { RecadoRemetenteForm } from "./RecadoRemetenteForm";
import { transformNestedData } from "../../infra/utils";

const RecadoRemetenteEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<RecadoRemetenteForm />
		</Edit>
	);
};

export default RecadoRemetenteEdit;