import RecadoRemetenteIcon from "@mui/icons-material/Apps";
import RecadoRemetenteList from "./RecadoRemetenteList";
import RecadoRemetenteCreate from "./RecadoRemetenteCreate";
import RecadoRemetenteEdit from "./RecadoRemetenteEdit";

export default {
	list: RecadoRemetenteList,
	create: RecadoRemetenteCreate,
	edit: RecadoRemetenteEdit,
	icon: RecadoRemetenteIcon,
};
