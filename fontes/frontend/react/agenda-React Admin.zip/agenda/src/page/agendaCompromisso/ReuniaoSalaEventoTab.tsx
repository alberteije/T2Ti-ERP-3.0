/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ReuniaoSalaEvento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ReuniaoSalaEvento {
		const reuniaoSalaEvento = new ReuniaoSalaEvento();
		reuniaoSalaEvento.id = Date.now();
		reuniaoSalaEvento.statusCrud = "C";
		return reuniaoSalaEvento;
	}
}

export const ReuniaoSalaEventoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ReuniaoSalaEvento,
		setCurrentRecord: (record: ReuniaoSalaEvento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'reuniaoSalaModel.id', label: 'Sala', reference: 'reuniao-sala', fieldName: 'nome' },
		{ source: 'dataReserva', label: 'Data Reserva' },
	];

	return (
		<CrudChildTab
			title="Eventos"
			recordContext="agendaCompromisso"
			fieldSource="reuniaoSalaEventoModelList"
			newObject={ ReuniaoSalaEvento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};