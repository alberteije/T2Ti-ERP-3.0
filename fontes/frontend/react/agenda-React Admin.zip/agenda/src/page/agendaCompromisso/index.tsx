import AgendaCompromissoIcon from "@mui/icons-material/Apps";
import AgendaCompromissoList from "./AgendaCompromissoList";
import AgendaCompromissoCreate from "./AgendaCompromissoCreate";
import AgendaCompromissoEdit from "./AgendaCompromissoEdit";

export default {
	list: AgendaCompromissoList,
	create: AgendaCompromissoCreate,
	edit: AgendaCompromissoEdit,
	icon: AgendaCompromissoIcon,
};
