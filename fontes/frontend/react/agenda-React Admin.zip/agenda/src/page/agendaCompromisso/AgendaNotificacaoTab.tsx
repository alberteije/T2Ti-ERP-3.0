/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import AgendaNotificacaoDomain from '../../data/domain/AgendaNotificacaoDomain';

class AgendaNotificacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): AgendaNotificacao {
		const agendaNotificacao = new AgendaNotificacao();
		agendaNotificacao.id = Date.now();
		agendaNotificacao.statusCrud = "C";
		return agendaNotificacao;
	}
}

export const AgendaNotificacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: AgendaNotificacao,
		setCurrentRecord: (record: AgendaNotificacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataNotificacao', label: 'Data Notificacao' },
		{ source: 'hora', label: 'Hora', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'tipo', label: 'Tipo', formatDomain: AgendaNotificacaoDomain.getTipo },
	];

	return (
		<CrudChildTab
			title="Notificações"
			recordContext="agendaCompromisso"
			fieldSource="agendaNotificacaoModelList"
			newObject={ AgendaNotificacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};