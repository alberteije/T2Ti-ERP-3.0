/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import AgendaCompromissoDomain from '../../data/domain/AgendaCompromissoDomain';

const AgendaCompromissoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["agendaCategoriaCompromissoModel.nome","viewPessoaColaboradorModel.nome","dataCompromisso"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? AgendaCompromissoSmallScreenList : AgendaCompromissoBigScreenList;

	return (
		<List
			title="Compromissos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const AgendaCompromissoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.agendaCategoriaCompromissoModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.dataCompromisso }
		/>
	);
}

const AgendaCompromissoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Agenda Categoria Compromisso" source="agendaCategoriaCompromissoModel.id" reference="agenda-categoria-compromisso" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataCompromisso" label="Data Compromisso" />
			<TextField source="hora" label="Hora" />
			<TextField source="duracao" label="Duracao" />
			<FunctionField
				label="Tipo"
				render={record => AgendaCompromissoDomain.getTipo(record.tipo)}
			/>
			<TextField source="onde" label="Onde" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default AgendaCompromissoList;
