/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class AgendaCompromissoConvidado {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): AgendaCompromissoConvidado {
		const agendaCompromissoConvidado = new AgendaCompromissoConvidado();
		agendaCompromissoConvidado.id = Date.now();
		agendaCompromissoConvidado.statusCrud = "C";
		return agendaCompromissoConvidado;
	}
}

export const AgendaCompromissoConvidadoTab: React.FC = () => {

	const renderForm = (
		currentRecord: AgendaCompromissoConvidado,
		setCurrentRecord: (record: AgendaCompromissoConvidado) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'viewPessoaColaboradorModel.id', label: 'Colaborador', reference: 'view-pessoa-colaborador', fieldName: 'nome' },
	];

	return (
		<CrudChildTab
			title="Convidados"
			recordContext="agendaCompromisso"
			fieldSource="agendaCompromissoConvidadoModelList"
			newObject={ AgendaCompromissoConvidado.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};