/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { AgendaCompromissoForm } from "./AgendaCompromissoForm";
import { transformNestedData } from "../../infra/utils";

const AgendaCompromissoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<AgendaCompromissoForm />
		</Edit>
	);
};

export default AgendaCompromissoEdit;