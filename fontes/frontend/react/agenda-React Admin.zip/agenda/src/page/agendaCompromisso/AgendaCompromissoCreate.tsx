/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { AgendaCompromissoForm } from "./AgendaCompromissoForm";
import { transformNestedData } from "../../infra/utils";

const AgendaCompromissoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<AgendaCompromissoForm />
		</Create>
	);
};

export default AgendaCompromissoCreate;