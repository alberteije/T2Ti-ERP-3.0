import {
	Edit,
} from "react-admin";
import { ReuniaoSalaForm } from "./ReuniaoSalaForm";

const ReuniaoSalaEdit = () => {
	return (
		<Edit>
			<ReuniaoSalaForm />
		</Edit>
	);
};

export default ReuniaoSalaEdit;