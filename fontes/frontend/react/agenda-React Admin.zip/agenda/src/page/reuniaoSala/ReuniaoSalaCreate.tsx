import {
	Create,
} from "react-admin";
import { ReuniaoSalaForm } from "./ReuniaoSalaForm";

const ReuniaoSalaCreate = () => {
	return (
		<Create>
			<ReuniaoSalaForm />
		</Create>
	);
};

export default ReuniaoSalaCreate;