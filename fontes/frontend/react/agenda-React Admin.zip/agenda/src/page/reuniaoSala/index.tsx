import ReuniaoSalaIcon from "@mui/icons-material/Apps";
import ReuniaoSalaList from "./ReuniaoSalaList";
import ReuniaoSalaCreate from "./ReuniaoSalaCreate";
import ReuniaoSalaEdit from "./ReuniaoSalaEdit";

export default {
	list: ReuniaoSalaList,
	create: ReuniaoSalaCreate,
	edit: ReuniaoSalaEdit,
	icon: ReuniaoSalaIcon,
};
