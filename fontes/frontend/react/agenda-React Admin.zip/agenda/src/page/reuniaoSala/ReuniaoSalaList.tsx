/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ReuniaoSalaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["predio","nome","andar"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ReuniaoSalaSmallScreenList : ReuniaoSalaBigScreenList;

	return (
		<List
			title="Sala de Reunião"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ReuniaoSalaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.predio }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.andar }
		/>
	);
}

const ReuniaoSalaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="predio" label="Predio" />
			<TextField source="nome" label="Nome" />
			<TextField source="andar" label="Andar" />
			<TextField source="numero" label="Numero" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ReuniaoSalaList;
