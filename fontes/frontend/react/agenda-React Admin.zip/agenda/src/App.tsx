import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import agendaCompromisso from './page/agendaCompromisso';
import recadoRemetente from './page/recadoRemetente';
import agendaCategoriaCompromisso from './page/agendaCategoriaCompromisso';
import reuniaoSala from './page/reuniaoSala';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'agenda');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Agenda Corporativa (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='agenda-compromisso' {...agendaCompromisso} options={{ label: 'Compromissos' }} />
			<Resource name='recado-remetente' {...recadoRemetente} options={{ label: 'Recado' }} />
			<Resource name='agenda-categoria-compromisso' {...agendaCategoriaCompromisso} options={{ label: 'Categoria Compromisso' }} />
			<Resource name='reuniao-sala' {...reuniaoSala} options={{ label: 'Sala de Reunião' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;