import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import pontoEscala from '../page/pontoEscala';
import pontoBancoHoras from '../page/pontoBancoHoras';
import pontoAbono from '../page/pontoAbono';
import pontoParametro from '../page/pontoParametro';
import pontoHorario from '../page/pontoHorario';
import pontoRelogio from '../page/pontoRelogio';
import pontoClassificacaoJornada from '../page/pontoClassificacaoJornada';
import pontoHorarioAutorizado from '../page/pontoHorarioAutorizado';
import pontoFechamentoJornada from '../page/pontoFechamentoJornada';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/ponto-parametro'
					state={{ _scrollToTop: true }}
					primaryText='Parâmetros'
					leftIcon={<pontoParametro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-horario'
					state={{ _scrollToTop: true }}
					primaryText='Horários'
					leftIcon={<pontoHorario.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-relogio'
					state={{ _scrollToTop: true }}
					primaryText='Relógio de Ponto'
					leftIcon={<pontoRelogio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-classificacao-jornada'
					state={{ _scrollToTop: true }}
					primaryText='Classificação da Jornada'
					leftIcon={<pontoClassificacaoJornada.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-horario-autorizado'
					state={{ _scrollToTop: true }}
					primaryText='Horário Autorizado'
					leftIcon={<pontoHorarioAutorizado.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-fechamento-jornada'
					state={{ _scrollToTop: true }}
					primaryText='Fechamento da Jornada'
					leftIcon={<pontoFechamentoJornada.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/ponto-escala'
					state={{ _scrollToTop: true }}
					primaryText='Escalas'
					leftIcon={<pontoEscala.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-banco-horas'
					state={{ _scrollToTop: true }}
					primaryText='Banco de Horas'
					leftIcon={<pontoBancoHoras.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ponto-abono'
					state={{ _scrollToTop: true }}
					primaryText='Abonos'
					leftIcon={<pontoAbono.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
