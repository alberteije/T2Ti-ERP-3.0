import {
	Create,
} from "react-admin";
import { PontoHorarioAutorizadoForm } from "./PontoHorarioAutorizadoForm";

const PontoHorarioAutorizadoCreate = () => {
	return (
		<Create>
			<PontoHorarioAutorizadoForm />
		</Create>
	);
};

export default PontoHorarioAutorizadoCreate;