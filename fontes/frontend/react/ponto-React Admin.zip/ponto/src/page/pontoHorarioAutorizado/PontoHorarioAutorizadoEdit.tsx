import {
	Edit,
} from "react-admin";
import { PontoHorarioAutorizadoForm } from "./PontoHorarioAutorizadoForm";

const PontoHorarioAutorizadoEdit = () => {
	return (
		<Edit>
			<PontoHorarioAutorizadoForm />
		</Edit>
	);
};

export default PontoHorarioAutorizadoEdit;