/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import PontoHorarioAutorizadoDomain from '../../data/domain/PontoHorarioAutorizadoDomain';

const PontoHorarioAutorizadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataHorario","tipo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoHorarioAutorizadoSmallScreenList : PontoHorarioAutorizadoBigScreenList;

	return (
		<List
			title="Horário Autorizado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoHorarioAutorizadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataHorario }
			tertiaryText={ (record) => record.tipo }
		/>
	);
}

const PontoHorarioAutorizadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataHorario" label="Data Horario" />
			<FunctionField
				label="Tipo"
				render={record => PontoHorarioAutorizadoDomain.getTipo(record.tipo)}
			/>
			<FunctionField
				source="cargaHoraria"
				label="Carga Horaria"
				render={record => formatWithMask(record.cargaHoraria, '##:##:##')}
			/>
			<FunctionField
				source="entrada01"
				label="Entrada01"
				render={record => formatWithMask(record.entrada01, '##:##:##')}
			/>
			<FunctionField
				source="saida01"
				label="Saida01"
				render={record => formatWithMask(record.saida01, '##:##:##')}
			/>
			<FunctionField
				source="entrada02"
				label="Entrada02"
				render={record => formatWithMask(record.entrada02, '##:##:##')}
			/>
			<FunctionField
				source="saida02"
				label="Saida02"
				render={record => formatWithMask(record.saida02, '##:##:##')}
			/>
			<FunctionField
				source="entrada03"
				label="Entrada03"
				render={record => formatWithMask(record.entrada03, '##:##:##')}
			/>
			<FunctionField
				source="saida03"
				label="Saida03"
				render={record => formatWithMask(record.saida03, '##:##:##')}
			/>
			<FunctionField
				source="entrada04"
				label="Entrada04"
				render={record => formatWithMask(record.entrada04, '##:##:##')}
			/>
			<FunctionField
				source="saida04"
				label="Saida04"
				render={record => formatWithMask(record.saida04, '##:##:##')}
			/>
			<FunctionField
				source="entrada05"
				label="Entrada05"
				render={record => formatWithMask(record.entrada05, '##:##:##')}
			/>
			<FunctionField
				source="saida05"
				label="Saida05"
				render={record => formatWithMask(record.saida05, '##:##:##')}
			/>
			<FunctionField
				source="horaFechamentoDia"
				label="Hora Fechamento Dia"
				render={record => formatWithMask(record.horaFechamentoDia, '##:##:##')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoHorarioAutorizadoList;
