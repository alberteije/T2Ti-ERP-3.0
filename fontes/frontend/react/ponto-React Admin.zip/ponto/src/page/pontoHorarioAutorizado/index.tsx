import PontoHorarioAutorizadoIcon from "@mui/icons-material/Apps";
import PontoHorarioAutorizadoList from "./PontoHorarioAutorizadoList";
import PontoHorarioAutorizadoCreate from "./PontoHorarioAutorizadoCreate";
import PontoHorarioAutorizadoEdit from "./PontoHorarioAutorizadoEdit";

export default {
	list: PontoHorarioAutorizadoList,
	create: PontoHorarioAutorizadoCreate,
	edit: PontoHorarioAutorizadoEdit,
	icon: PontoHorarioAutorizadoIcon,
};
