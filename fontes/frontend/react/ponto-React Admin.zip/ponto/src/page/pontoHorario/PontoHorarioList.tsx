/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import PontoHorarioDomain from '../../data/domain/PontoHorarioDomain';

const PontoHorarioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["tipo","codigo","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoHorarioSmallScreenList : PontoHorarioBigScreenList;

	return (
		<List
			title="Horários"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoHorarioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.tipo }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.nome }
		/>
	);
}

const PontoHorarioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Tipo"
				render={record => PontoHorarioDomain.getTipo(record.tipo)}
			/>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Tipo Trabalho"
				render={record => PontoHorarioDomain.getTipoTrabalho(record.tipoTrabalho)}
			/>
			<FunctionField
				source="cargaHoraria"
				label="Carga Horaria"
				render={record => formatWithMask(record.cargaHoraria, '##:##:##')}
			/>
			<FunctionField
				source="entrada01"
				label="Entrada01"
				render={record => formatWithMask(record.entrada01, '##:##:##')}
			/>
			<FunctionField
				source="saida01"
				label="Saida01"
				render={record => formatWithMask(record.saida01, '##:##:##')}
			/>
			<FunctionField
				source="entrada02"
				label="Entrada02"
				render={record => formatWithMask(record.entrada02, '##:##:##')}
			/>
			<FunctionField
				source="saida02"
				label="Saida02"
				render={record => formatWithMask(record.saida02, '##:##:##')}
			/>
			<FunctionField
				source="entrada03"
				label="Entrada03"
				render={record => formatWithMask(record.entrada03, '##:##:##')}
			/>
			<FunctionField
				source="saida03"
				label="Saida03"
				render={record => formatWithMask(record.saida03, '##:##:##')}
			/>
			<FunctionField
				source="entrada04"
				label="Entrada04"
				render={record => formatWithMask(record.entrada04, '##:##:##')}
			/>
			<FunctionField
				source="saida04"
				label="Saida04"
				render={record => formatWithMask(record.saida04, '##:##:##')}
			/>
			<FunctionField
				source="entrada05"
				label="Entrada05"
				render={record => formatWithMask(record.entrada05, '##:##:##')}
			/>
			<FunctionField
				source="saida05"
				label="Saida05"
				render={record => formatWithMask(record.saida05, '##:##:##')}
			/>
			<FunctionField
				source="horaInicioJornada"
				label="Hora Inicio Jornada"
				render={record => formatWithMask(record.horaInicioJornada, '##:##:##')}
			/>
			<FunctionField
				source="horaFimJornada"
				label="Hora Fim Jornada"
				render={record => formatWithMask(record.horaFimJornada, '##:##:##')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoHorarioList;
