import PontoHorarioIcon from "@mui/icons-material/Apps";
import PontoHorarioList from "./PontoHorarioList";
import PontoHorarioCreate from "./PontoHorarioCreate";
import PontoHorarioEdit from "./PontoHorarioEdit";

export default {
	list: PontoHorarioList,
	create: PontoHorarioCreate,
	edit: PontoHorarioEdit,
	icon: PontoHorarioIcon,
};
