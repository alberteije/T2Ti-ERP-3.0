import {
	Edit,
} from "react-admin";
import { PontoHorarioForm } from "./PontoHorarioForm";

const PontoHorarioEdit = () => {
	return (
		<Edit>
			<PontoHorarioForm />
		</Edit>
	);
};

export default PontoHorarioEdit;