import {
	Create,
} from "react-admin";
import { PontoHorarioForm } from "./PontoHorarioForm";

const PontoHorarioCreate = () => {
	return (
		<Create>
			<PontoHorarioForm />
		</Create>
	);
};

export default PontoHorarioCreate;