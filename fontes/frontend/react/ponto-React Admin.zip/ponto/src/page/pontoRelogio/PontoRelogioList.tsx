/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PontoRelogioDomain from '../../data/domain/PontoRelogioDomain';

const PontoRelogioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["localizacao","marca","fabricante"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoRelogioSmallScreenList : PontoRelogioBigScreenList;

	return (
		<List
			title="Relógio de Ponto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoRelogioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.localizacao }
			secondaryText={ (record) => record.marca }
			tertiaryText={ (record) => record.fabricante }
		/>
	);
}

const PontoRelogioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="localizacao" label="Localizacao" />
			<TextField source="marca" label="Marca" />
			<TextField source="fabricante" label="Fabricante" />
			<TextField source="numeroSerie" label="Numero Serie" />
			<FunctionField
				label="Utilizacao"
				render={record => PontoRelogioDomain.getUtilizacao(record.utilizacao)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoRelogioList;
