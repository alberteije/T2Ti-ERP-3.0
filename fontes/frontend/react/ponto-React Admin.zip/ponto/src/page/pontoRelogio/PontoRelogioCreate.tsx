import {
	Create,
} from "react-admin";
import { PontoRelogioForm } from "./PontoRelogioForm";

const PontoRelogioCreate = () => {
	return (
		<Create>
			<PontoRelogioForm />
		</Create>
	);
};

export default PontoRelogioCreate;