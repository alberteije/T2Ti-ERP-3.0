import PontoRelogioIcon from "@mui/icons-material/Apps";
import PontoRelogioList from "./PontoRelogioList";
import PontoRelogioCreate from "./PontoRelogioCreate";
import PontoRelogioEdit from "./PontoRelogioEdit";

export default {
	list: PontoRelogioList,
	create: PontoRelogioCreate,
	edit: PontoRelogioEdit,
	icon: PontoRelogioIcon,
};
