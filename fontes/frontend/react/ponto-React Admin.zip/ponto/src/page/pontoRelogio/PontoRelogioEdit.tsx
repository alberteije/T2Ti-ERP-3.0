import {
	Edit,
} from "react-admin";
import { PontoRelogioForm } from "./PontoRelogioForm";

const PontoRelogioEdit = () => {
	return (
		<Edit>
			<PontoRelogioForm />
		</Edit>
	);
};

export default PontoRelogioEdit;