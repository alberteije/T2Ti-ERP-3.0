/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PontoAbonoForm } from "./PontoAbonoForm";
import { transformNestedData } from "../../infra/utils";

const PontoAbonoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PontoAbonoForm />
		</Create>
	);
};

export default PontoAbonoCreate;