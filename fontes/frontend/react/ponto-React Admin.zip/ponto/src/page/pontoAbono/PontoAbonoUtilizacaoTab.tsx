/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PontoAbonoUtilizacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PontoAbonoUtilizacao {
		const pontoAbonoUtilizacao = new PontoAbonoUtilizacao();
		pontoAbonoUtilizacao.id = Date.now();
		pontoAbonoUtilizacao.statusCrud = "C";
		return pontoAbonoUtilizacao;
	}
}

export const PontoAbonoUtilizacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PontoAbonoUtilizacao,
		setCurrentRecord: (record: PontoAbonoUtilizacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataUtilizacao', label: 'Data Utilizacao' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Utilização"
			recordContext="pontoAbono"
			fieldSource="pontoAbonoUtilizacaoModelList"
			newObject={ PontoAbonoUtilizacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};