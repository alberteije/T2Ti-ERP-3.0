/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PontoAbonoForm } from "./PontoAbonoForm";
import { transformNestedData } from "../../infra/utils";

const PontoAbonoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PontoAbonoForm />
		</Edit>
	);
};

export default PontoAbonoEdit;