import PontoAbonoIcon from "@mui/icons-material/Apps";
import PontoAbonoList from "./PontoAbonoList";
import PontoAbonoCreate from "./PontoAbonoCreate";
import PontoAbonoEdit from "./PontoAbonoEdit";

export default {
	list: PontoAbonoList,
	create: PontoAbonoCreate,
	edit: PontoAbonoEdit,
	icon: PontoAbonoIcon,
};
