/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PontoAbonoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","quantidade","utilizado"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoAbonoSmallScreenList : PontoAbonoBigScreenList;

	return (
		<List
			title="Abonos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoAbonoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.quantidade }
			tertiaryText={ (record) => record.utilizado }
		/>
	);
}

const PontoAbonoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="quantidade" label="Quantidade" />
			<TextField source="utilizado" label="Utilizado" />
			<TextField source="saldo" label="Saldo" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<TextField source="inicioUtilizacao" label="Inicio Utilizacao" />
			<TextField source="dataValidade" label="Data Validade" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoAbonoList;
