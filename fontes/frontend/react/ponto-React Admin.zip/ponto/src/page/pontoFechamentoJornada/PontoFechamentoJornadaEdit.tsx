import {
	Edit,
} from "react-admin";
import { PontoFechamentoJornadaForm } from "./PontoFechamentoJornadaForm";

const PontoFechamentoJornadaEdit = () => {
	return (
		<Edit>
			<PontoFechamentoJornadaForm />
		</Edit>
	);
};

export default PontoFechamentoJornadaEdit;