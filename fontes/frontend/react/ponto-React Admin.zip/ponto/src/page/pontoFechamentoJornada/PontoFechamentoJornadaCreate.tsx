import {
	Create,
} from "react-admin";
import { PontoFechamentoJornadaForm } from "./PontoFechamentoJornadaForm";

const PontoFechamentoJornadaCreate = () => {
	return (
		<Create>
			<PontoFechamentoJornadaForm />
		</Create>
	);
};

export default PontoFechamentoJornadaCreate;