import PontoFechamentoJornadaIcon from "@mui/icons-material/Apps";
import PontoFechamentoJornadaList from "./PontoFechamentoJornadaList";
import PontoFechamentoJornadaCreate from "./PontoFechamentoJornadaCreate";
import PontoFechamentoJornadaEdit from "./PontoFechamentoJornadaEdit";

export default {
	list: PontoFechamentoJornadaList,
	create: PontoFechamentoJornadaCreate,
	edit: PontoFechamentoJornadaEdit,
	icon: PontoFechamentoJornadaIcon,
};
