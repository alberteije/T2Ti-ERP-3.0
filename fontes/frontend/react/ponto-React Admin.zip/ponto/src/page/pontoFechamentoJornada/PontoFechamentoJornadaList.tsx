/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import PontoFechamentoJornadaDomain from '../../data/domain/PontoFechamentoJornadaDomain';

const PontoFechamentoJornadaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["pontoClassificacaoJornadaModel.nome","viewPessoaColaboradorModel.nome","dataFechamento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoFechamentoJornadaSmallScreenList : PontoFechamentoJornadaBigScreenList;

	return (
		<List
			title="Fechamento da Jornada"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoFechamentoJornadaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.pontoClassificacaoJornadaModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.dataFechamento }
		/>
	);
}

const PontoFechamentoJornadaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Ponto Classificacao Jornada" source="pontoClassificacaoJornadaModel.id" reference="ponto-classificacao-jornada" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataFechamento" label="Data Fechamento" />
			<FunctionField
				label="Dia Semana"
				render={record => PontoFechamentoJornadaDomain.getDiaSemana(record.diaSemana)}
			/>
			<TextField source="codigoHorario" label="Codigo Horario" />
			<FunctionField
				source="cargaHorariaEsperada"
				label="Carga Horaria Esperada"
				render={record => formatWithMask(record.cargaHorariaEsperada, '##:##:##')}
			/>
			<FunctionField
				source="cargaHorariaDiurna"
				label="Carga Horaria Diurna"
				render={record => formatWithMask(record.cargaHorariaDiurna, '##:##:##')}
			/>
			<FunctionField
				source="cargaHorariaNoturna"
				label="Carga Horaria Noturna"
				render={record => formatWithMask(record.cargaHorariaNoturna, '##:##:##')}
			/>
			<FunctionField
				source="cargaHorariaTotal"
				label="Carga Horaria Total"
				render={record => formatWithMask(record.cargaHorariaTotal, '##:##:##')}
			/>
			<FunctionField
				source="entrada01"
				label="Entrada01"
				render={record => formatWithMask(record.entrada01, '##:##:##')}
			/>
			<FunctionField
				source="saida01"
				label="Saida01"
				render={record => formatWithMask(record.saida01, '##:##:##')}
			/>
			<FunctionField
				source="entrada02"
				label="Entrada02"
				render={record => formatWithMask(record.entrada02, '##:##:##')}
			/>
			<FunctionField
				source="saida02"
				label="Saida02"
				render={record => formatWithMask(record.saida02, '##:##:##')}
			/>
			<FunctionField
				source="entrada03"
				label="Entrada03"
				render={record => formatWithMask(record.entrada03, '##:##:##')}
			/>
			<FunctionField
				source="saida03"
				label="Saida03"
				render={record => formatWithMask(record.saida03, '##:##:##')}
			/>
			<FunctionField
				source="entrada04"
				label="Entrada04"
				render={record => formatWithMask(record.entrada04, '##:##:##')}
			/>
			<FunctionField
				source="saida04"
				label="Saida04"
				render={record => formatWithMask(record.saida04, '##:##:##')}
			/>
			<FunctionField
				source="entrada05"
				label="Entrada05"
				render={record => formatWithMask(record.entrada05, '##:##:##')}
			/>
			<FunctionField
				source="saida05"
				label="Saida05"
				render={record => formatWithMask(record.saida05, '##:##:##')}
			/>
			<FunctionField
				source="horaInicioJornada"
				label="Hora Inicio Jornada"
				render={record => formatWithMask(record.horaInicioJornada, '##:##:##')}
			/>
			<FunctionField
				source="horaFimJornada"
				label="Hora Fim Jornada"
				render={record => formatWithMask(record.horaFimJornada, '##:##:##')}
			/>
			<FunctionField
				source="horaExtra01"
				label="Hora Extra01"
				render={record => formatWithMask(record.horaExtra01, '##:##:##')}
			/>
			<NumberField source="percentualHoraExtra01" label="Percentual Hora Extra01" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Modalidade Hora Extra01"
				render={record => PontoFechamentoJornadaDomain.getModalidadeHoraExtra01(record.modalidadeHoraExtra01)}
			/>
			<FunctionField
				source="horaExtra02"
				label="Hora Extra02"
				render={record => formatWithMask(record.horaExtra02, '##:##:##')}
			/>
			<NumberField source="percentualHoraExtra02" label="Percentual Hora Extra02" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Modalidade Hora Extra02"
				render={record => PontoFechamentoJornadaDomain.getModalidadeHoraExtra02(record.modalidadeHoraExtra02)}
			/>
			<FunctionField
				source="horaExtra03"
				label="Hora Extra03"
				render={record => formatWithMask(record.horaExtra03, '##:##:##')}
			/>
			<NumberField source="percentualHoraExtra03" label="Percentual Hora Extra03" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Modalidade Hora Extra03"
				render={record => PontoFechamentoJornadaDomain.getModalidadeHoraExtra03(record.modalidadeHoraExtra03)}
			/>
			<FunctionField
				source="horaExtra04"
				label="Hora Extra04"
				render={record => formatWithMask(record.horaExtra04, '##:##:##')}
			/>
			<NumberField source="percentualHoraExtra04" label="Percentual Hora Extra04" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Modalidade Hora Extra04"
				render={record => PontoFechamentoJornadaDomain.getModalidadeHoraExtra04(record.modalidadeHoraExtra04)}
			/>
			<FunctionField
				source="faltaAtraso"
				label="Falta Atraso"
				render={record => formatWithMask(record.faltaAtraso, '##:##:##')}
			/>
			<FunctionField
				label="Compensar"
				render={record => PontoFechamentoJornadaDomain.getCompensar(record.compensar)}
			/>
			<FunctionField
				source="bancoHoras"
				label="Banco Horas"
				render={record => formatWithMask(record.bancoHoras, '##:##:##')}
			/>
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoFechamentoJornadaList;
