import {
	Create,
} from "react-admin";
import { PontoClassificacaoJornadaForm } from "./PontoClassificacaoJornadaForm";

const PontoClassificacaoJornadaCreate = () => {
	return (
		<Create>
			<PontoClassificacaoJornadaForm />
		</Create>
	);
};

export default PontoClassificacaoJornadaCreate;