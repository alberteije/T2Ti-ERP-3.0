import PontoClassificacaoJornadaIcon from "@mui/icons-material/Apps";
import PontoClassificacaoJornadaList from "./PontoClassificacaoJornadaList";
import PontoClassificacaoJornadaCreate from "./PontoClassificacaoJornadaCreate";
import PontoClassificacaoJornadaEdit from "./PontoClassificacaoJornadaEdit";

export default {
	list: PontoClassificacaoJornadaList,
	create: PontoClassificacaoJornadaCreate,
	edit: PontoClassificacaoJornadaEdit,
	icon: PontoClassificacaoJornadaIcon,
};
