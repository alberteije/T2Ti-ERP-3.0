import {
	Edit,
} from "react-admin";
import { PontoClassificacaoJornadaForm } from "./PontoClassificacaoJornadaForm";

const PontoClassificacaoJornadaEdit = () => {
	return (
		<Edit>
			<PontoClassificacaoJornadaForm />
		</Edit>
	);
};

export default PontoClassificacaoJornadaEdit;