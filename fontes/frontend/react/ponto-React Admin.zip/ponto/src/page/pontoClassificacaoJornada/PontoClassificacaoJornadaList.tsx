/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PontoClassificacaoJornadaDomain from '../../data/domain/PontoClassificacaoJornadaDomain';

const PontoClassificacaoJornadaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoClassificacaoJornadaSmallScreenList : PontoClassificacaoJornadaBigScreenList;

	return (
		<List
			title="Classificação da Jornada"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoClassificacaoJornadaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const PontoClassificacaoJornadaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Padrao"
				render={record => PontoClassificacaoJornadaDomain.getPadrao(record.padrao)}
			/>
			<FunctionField
				label="Descontar Horas"
				render={record => PontoClassificacaoJornadaDomain.getDescontarHoras(record.descontarHoras)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoClassificacaoJornadaList;
