/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PontoEscalaForm } from "./PontoEscalaForm";
import { transformNestedData } from "../../infra/utils";

const PontoEscalaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PontoEscalaForm />
		</Edit>
	);
};

export default PontoEscalaEdit;