import PontoEscalaIcon from "@mui/icons-material/Apps";
import PontoEscalaList from "./PontoEscalaList";
import PontoEscalaCreate from "./PontoEscalaCreate";
import PontoEscalaEdit from "./PontoEscalaEdit";

export default {
	list: PontoEscalaList,
	create: PontoEscalaCreate,
	edit: PontoEscalaEdit,
	icon: PontoEscalaIcon,
};
