/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PontoEscalaForm } from "./PontoEscalaForm";
import { transformNestedData } from "../../infra/utils";

const PontoEscalaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PontoEscalaForm />
		</Create>
	);
};

export default PontoEscalaCreate;