/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const PontoEscalaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","descontoHoraDia","descontoDsr"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoEscalaSmallScreenList : PontoEscalaBigScreenList;

	return (
		<List
			title="Escalas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoEscalaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.descontoHoraDia }
			tertiaryText={ (record) => record.descontoDsr }
		/>
	);
}

const PontoEscalaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<FunctionField
				source="descontoHoraDia"
				label="Desconto Hora Dia"
				render={record => formatWithMask(record.descontoHoraDia, '##:##:##')}
			/>
			<FunctionField
				source="descontoDsr"
				label="Desconto Dsr"
				render={record => formatWithMask(record.descontoDsr, '##:##:##')}
			/>
			<TextField source="codigoHorarioDomingo" label="Codigo Horario Domingo" />
			<TextField source="codigoHorarioSegunda" label="Codigo Horario Segunda" />
			<TextField source="codigoHorarioTerca" label="Codigo Horario Terca" />
			<TextField source="codigoHorarioQuarta" label="Codigo Horario Quarta" />
			<TextField source="codigoHorarioQuinta" label="Codigo Horario Quinta" />
			<TextField source="codigoHorarioSexta" label="Codigo Horario Sexta" />
			<TextField source="codigoHorarioSabado" label="Codigo Horario Sabado" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoEscalaList;
