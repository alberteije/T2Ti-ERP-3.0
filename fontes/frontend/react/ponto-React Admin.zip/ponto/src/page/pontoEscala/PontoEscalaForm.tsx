/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PontoTurmaTab } from './PontoTurmaTab';

export const PontoEscalaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Escalas">
				<PontoEscalaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Turmas">
				<PontoTurmaTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PontoEscalaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};