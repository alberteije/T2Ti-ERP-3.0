/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PontoTurma {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PontoTurma {
		const pontoTurma = new PontoTurma();
		pontoTurma.id = Date.now();
		pontoTurma.statusCrud = "C";
		return pontoTurma;
	}
}

export const PontoTurmaTab: React.FC = () => {

	const renderForm = (
		currentRecord: PontoTurma,
		setCurrentRecord: (record: PontoTurma) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigo', label: 'Codigo' },
		{ source: 'nome', label: 'Nome' },
	];

	return (
		<CrudChildTab
			title="Turmas"
			recordContext="pontoEscala"
			fieldSource="pontoTurmaModelList"
			newObject={ PontoTurma.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};