/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PontoBancoHorasDomain from '../../data/domain/PontoBancoHorasDomain';

const PontoBancoHorasList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataTrabalho","quantidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoBancoHorasSmallScreenList : PontoBancoHorasBigScreenList;

	return (
		<List
			title="Banco de Horas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoBancoHorasSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataTrabalho }
			tertiaryText={ (record) => record.quantidade }
		/>
	);
}

const PontoBancoHorasBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataTrabalho" label="Data Trabalho" />
			<TextField source="quantidade" label="Quantidade" />
			<FunctionField
				label="Situacao"
				render={record => PontoBancoHorasDomain.getSituacao(record.situacao)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoBancoHorasList;
