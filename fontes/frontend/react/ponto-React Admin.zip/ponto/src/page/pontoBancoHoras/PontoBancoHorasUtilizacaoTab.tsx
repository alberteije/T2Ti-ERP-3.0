/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PontoBancoHorasUtilizacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PontoBancoHorasUtilizacao {
		const pontoBancoHorasUtilizacao = new PontoBancoHorasUtilizacao();
		pontoBancoHorasUtilizacao.id = Date.now();
		pontoBancoHorasUtilizacao.statusCrud = "C";
		return pontoBancoHorasUtilizacao;
	}
}

export const PontoBancoHorasUtilizacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PontoBancoHorasUtilizacao,
		setCurrentRecord: (record: PontoBancoHorasUtilizacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataUtilizacao', label: 'Data Utilizacao' },
		{ source: 'quantidadeUtilizada', label: 'Quantidade Utilizada', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Utilização"
			recordContext="pontoBancoHoras"
			fieldSource="pontoBancoHorasUtilizacaoModelList"
			newObject={ PontoBancoHorasUtilizacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};