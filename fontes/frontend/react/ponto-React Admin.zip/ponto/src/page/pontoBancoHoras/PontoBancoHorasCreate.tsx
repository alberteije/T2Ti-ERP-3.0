/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PontoBancoHorasForm } from "./PontoBancoHorasForm";
import { transformNestedData } from "../../infra/utils";

const PontoBancoHorasCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PontoBancoHorasForm />
		</Create>
	);
};

export default PontoBancoHorasCreate;