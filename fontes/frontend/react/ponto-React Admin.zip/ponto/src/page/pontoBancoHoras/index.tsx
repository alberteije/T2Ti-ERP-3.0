import PontoBancoHorasIcon from "@mui/icons-material/Apps";
import PontoBancoHorasList from "./PontoBancoHorasList";
import PontoBancoHorasCreate from "./PontoBancoHorasCreate";
import PontoBancoHorasEdit from "./PontoBancoHorasEdit";

export default {
	list: PontoBancoHorasList,
	create: PontoBancoHorasCreate,
	edit: PontoBancoHorasEdit,
	icon: PontoBancoHorasIcon,
};
