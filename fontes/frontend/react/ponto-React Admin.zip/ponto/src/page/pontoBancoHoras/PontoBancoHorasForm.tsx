/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PontoBancoHorasUtilizacaoTab } from './PontoBancoHorasUtilizacaoTab';

export const PontoBancoHorasForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Banco de Horas">
				<PontoBancoHorasTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Utilização">
				<PontoBancoHorasUtilizacaoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PontoBancoHorasTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};