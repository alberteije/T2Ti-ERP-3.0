import PontoParametroIcon from "@mui/icons-material/Apps";
import PontoParametroList from "./PontoParametroList";
import PontoParametroCreate from "./PontoParametroCreate";
import PontoParametroEdit from "./PontoParametroEdit";

export default {
	list: PontoParametroList,
	create: PontoParametroCreate,
	edit: PontoParametroEdit,
	icon: PontoParametroIcon,
};
