import {
	Edit,
} from "react-admin";
import { PontoParametroForm } from "./PontoParametroForm";

const PontoParametroEdit = () => {
	return (
		<Edit>
			<PontoParametroForm />
		</Edit>
	);
};

export default PontoParametroEdit;