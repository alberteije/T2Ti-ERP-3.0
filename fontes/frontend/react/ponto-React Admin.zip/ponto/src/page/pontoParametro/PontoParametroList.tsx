/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import PontoParametroDomain from '../../data/domain/PontoParametroDomain';

const PontoParametroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mesAno","diaInicialApuracao","horaNoturnaInicio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PontoParametroSmallScreenList : PontoParametroBigScreenList;

	return (
		<List
			title="Parâmetros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PontoParametroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mesAno }
			secondaryText={ (record) => record.diaInicialApuracao }
			tertiaryText={ (record) => record.horaNoturnaInicio }
		/>
	);
}

const PontoParametroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="mesAno"
				label="Mes Ano"
				render={record => formatWithMask(record.mesAno, '##/####')}
			/>
			<TextField source="diaInicialApuracao" label="Dia Inicial Apuracao" />
			<FunctionField
				source="horaNoturnaInicio"
				label="Hora Noturna Inicio"
				render={record => formatWithMask(record.horaNoturnaInicio, '##:##:##')}
			/>
			<FunctionField
				source="horaNoturnaFim"
				label="Hora Noturna Fim"
				render={record => formatWithMask(record.horaNoturnaFim, '##:##:##')}
			/>
			<FunctionField
				source="periodoMinimoInterjornada"
				label="Periodo Minimo Interjornada"
				render={record => formatWithMask(record.periodoMinimoInterjornada, '##:##:##')}
			/>
			<NumberField source="percentualHeDiurna" label="Percentual He Diurna" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualHeNoturna" label="Percentual He Noturna" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				source="duracaoHoraNoturna"
				label="Duracao Hora Noturna"
				render={record => formatWithMask(record.duracaoHoraNoturna, '##:##:##')}
			/>
			<FunctionField
				label="Tratamento Hora Mais"
				render={record => PontoParametroDomain.getTratamentoHoraMais(record.tratamentoHoraMais)}
			/>
			<FunctionField
				label="Tratamento Hora Menos"
				render={record => PontoParametroDomain.getTratamentoHoraMenos(record.tratamentoHoraMenos)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PontoParametroList;
