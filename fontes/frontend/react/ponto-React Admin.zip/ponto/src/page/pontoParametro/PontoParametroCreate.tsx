import {
	Create,
} from "react-admin";
import { PontoParametroForm } from "./PontoParametroForm";

const PontoParametroCreate = () => {
	return (
		<Create>
			<PontoParametroForm />
		</Create>
	);
};

export default PontoParametroCreate;