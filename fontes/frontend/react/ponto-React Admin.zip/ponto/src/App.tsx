import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import pontoEscala from './page/pontoEscala';
import pontoBancoHoras from './page/pontoBancoHoras';
import pontoAbono from './page/pontoAbono';
import pontoParametro from './page/pontoParametro';
import pontoHorario from './page/pontoHorario';
import pontoRelogio from './page/pontoRelogio';
import pontoClassificacaoJornada from './page/pontoClassificacaoJornada';
import pontoHorarioAutorizado from './page/pontoHorarioAutorizado';
import pontoFechamentoJornada from './page/pontoFechamentoJornada';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'ponto');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Ponto Eletrônico (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='ponto-escala' {...pontoEscala} options={{ label: 'Escalas' }} />
			<Resource name='ponto-banco-horas' {...pontoBancoHoras} options={{ label: 'Banco de Horas' }} />
			<Resource name='ponto-abono' {...pontoAbono} options={{ label: 'Abonos' }} />
			<Resource name='ponto-parametro' {...pontoParametro} options={{ label: 'Parâmetros' }} />
			<Resource name='ponto-horario' {...pontoHorario} options={{ label: 'Horários' }} />
			<Resource name='ponto-relogio' {...pontoRelogio} options={{ label: 'Relógio de Ponto' }} />
			<Resource name='ponto-classificacao-jornada' {...pontoClassificacaoJornada} options={{ label: 'Classificação da Jornada' }} />
			<Resource name='ponto-horario-autorizado' {...pontoHorarioAutorizado} options={{ label: 'Horário Autorizado' }} />
			<Resource name='ponto-fechamento-jornada' {...pontoFechamentoJornada} options={{ label: 'Fechamento da Jornada' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;