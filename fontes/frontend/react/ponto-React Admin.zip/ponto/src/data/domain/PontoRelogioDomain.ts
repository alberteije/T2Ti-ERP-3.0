class PontoRelogioDomain {
	static getUtilizacao(utilizacao: string) { 
		switch (utilizacao) { 
			case '': 
			case 'P': 
				return 'Ponto'; 
			case 'R': 
				return 'Refeitório'; 
			case 'C': 
				return 'Circulação'; 
			default: 
				return null; 
		} 
	} 

	static setUtilizacao(utilizacao: string) { 
		switch (utilizacao) { 
			case 'Ponto': 
				return 'P'; 
			case 'Refeitório': 
				return 'R'; 
			case 'Circulação': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

}

export default PontoRelogioDomain;