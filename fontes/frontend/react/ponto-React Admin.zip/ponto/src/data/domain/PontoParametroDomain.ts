class PontoParametroDomain {
	static getTratamentoHoraMais(tratamentoHoraMais: string) { 
		switch (tratamentoHoraMais) { 
			case '': 
			case 'E': 
				return 'Extra'; 
			case 'B': 
				return 'Banco Horas'; 
			default: 
				return null; 
		} 
	} 

	static setTratamentoHoraMais(tratamentoHoraMais: string) { 
		switch (tratamentoHoraMais) { 
			case 'Extra': 
				return 'E'; 
			case 'Banco Horas': 
				return 'B'; 
			default: 
				return null; 
		} 
	}

	static getTratamentoHoraMenos(tratamentoHoraMenos: string) { 
		switch (tratamentoHoraMenos) { 
			case '': 
			case 'F': 
				return 'Falta'; 
			case 'B': 
				return 'Banco Horas'; 
			default: 
				return null; 
		} 
	} 

	static setTratamentoHoraMenos(tratamentoHoraMenos: string) { 
		switch (tratamentoHoraMenos) { 
			case 'Falta': 
				return 'F'; 
			case 'Banco Horas': 
				return 'B'; 
			default: 
				return null; 
		} 
	}

}

export default PontoParametroDomain;