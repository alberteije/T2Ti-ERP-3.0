class PontoFechamentoJornadaDomain {
	static getDiaSemana(diaSemana: string) { 
		switch (diaSemana) { 
			case '': 
			case 'DOMINGO': 
				return 'DOMINGO'; 
			case 'SEGUNDA': 
				return 'SEGUNDA'; 
			case 'TERCA': 
				return 'TERCA'; 
			case 'QUARTA': 
				return 'QUARTA'; 
			case 'QUINTA': 
				return 'QUINTA'; 
			case 'SEXTA': 
				return 'SEXTA'; 
			case 'SABADO': 
				return 'SABADO'; 
			default: 
				return null; 
		} 
	} 

	static setDiaSemana(diaSemana: string) { 
		switch (diaSemana) { 
			case 'DOMINGO': 
				return 'DOMINGO'; 
			case 'SEGUNDA': 
				return 'SEGUNDA'; 
			case 'TERCA': 
				return 'TERCA'; 
			case 'QUARTA': 
				return 'QUARTA'; 
			case 'QUINTA': 
				return 'QUINTA'; 
			case 'SEXTA': 
				return 'SEXTA'; 
			case 'SABADO': 
				return 'SABADO'; 
			default: 
				return null; 
		} 
	}

	static getModalidadeHoraExtra01(modalidadeHoraExtra01: string) { 
		switch (modalidadeHoraExtra01) { 
			case '': 
			case 'D': 
				return 'Diurna'; 
			case 'N': 
				return 'Noturna'; 
			default: 
				return null; 
		} 
	} 

	static setModalidadeHoraExtra01(modalidadeHoraExtra01: string) { 
		switch (modalidadeHoraExtra01) { 
			case 'Diurna': 
				return 'D'; 
			case 'Noturna': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getModalidadeHoraExtra02(modalidadeHoraExtra02: string) { 
		switch (modalidadeHoraExtra02) { 
			case '': 
			case 'D': 
				return 'Diurna'; 
			case 'N': 
				return 'Noturna'; 
			default: 
				return null; 
		} 
	} 

	static setModalidadeHoraExtra02(modalidadeHoraExtra02: string) { 
		switch (modalidadeHoraExtra02) { 
			case 'Diurna': 
				return 'D'; 
			case 'Noturna': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getModalidadeHoraExtra03(modalidadeHoraExtra03: string) { 
		switch (modalidadeHoraExtra03) { 
			case '': 
			case 'D': 
				return 'Diurna'; 
			case 'N': 
				return 'Noturna'; 
			default: 
				return null; 
		} 
	} 

	static setModalidadeHoraExtra03(modalidadeHoraExtra03: string) { 
		switch (modalidadeHoraExtra03) { 
			case 'Diurna': 
				return 'D'; 
			case 'Noturna': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getModalidadeHoraExtra04(modalidadeHoraExtra04: string) { 
		switch (modalidadeHoraExtra04) { 
			case '': 
			case 'D': 
				return 'Diurna'; 
			case 'N': 
				return 'Noturna'; 
			default: 
				return null; 
		} 
	} 

	static setModalidadeHoraExtra04(modalidadeHoraExtra04: string) { 
		switch (modalidadeHoraExtra04) { 
			case 'Diurna': 
				return 'D'; 
			case 'Noturna': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getCompensar(compensar: string) { 
		switch (compensar) { 
			case '': 
			case '0': 
				return 'Horas a mais'; 
			case '1': 
				return 'Horas a menos'; 
			default: 
				return null; 
		} 
	} 

	static setCompensar(compensar: string) { 
		switch (compensar) { 
			case 'Horas a mais': 
				return '0'; 
			case 'Horas a menos': 
				return '1'; 
			default: 
				return null; 
		} 
	}

}

export default PontoFechamentoJornadaDomain;