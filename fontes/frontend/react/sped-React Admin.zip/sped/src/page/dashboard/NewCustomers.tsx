import { Avatar, Box, Button } from '@mui/material';
import CustomerIcon from '@mui/icons-material/PersonAdd';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useTranslate } from 'react-admin';
import { subDays } from 'date-fns';

import CardWithIcon from './CardWithIcon';
import { Customer } from './types';

const NewCustomers = () => {
	const translate = useTranslate();
	const [customers, setCustomers] = useState<Customer[]>([]);

	const aMonthAgo = subDays(new Date(), 30);
	aMonthAgo.setDate(aMonthAgo.getDate() - 30);
	aMonthAgo.setHours(0);
	aMonthAgo.setMinutes(0);
	aMonthAgo.setSeconds(0);
	aMonthAgo.setMilliseconds(0);

	// Carregar os dados dos clientes do arquivo JSON
	useEffect(() => {
		const fetchCustomers = async () => {
			try {
				const customersResponse = await fetch('/src/data/fake/customers.json');
				const customersData = await customersResponse.json();
				setCustomers(customersData);
			} catch (error) {
				console.error('Ohh no', error);
			}
		};

		fetchCustomers();
	}, [aMonthAgo]);

	const total = customers.length;

	return (
		<CardWithIcon
			to=""
			icon={CustomerIcon}
			title={translate('dashboard.orders.new_customers')}
			subtitle={total}
		>
			{customers.map((customer: Customer) => (
				<Box key={customer.id} display="flex" alignItems="center" mb={2}>
					<Avatar
						src='/vycanis.png'
						alt={`${customer.first_name} ${customer.last_name}`}
					/>
					<Box ml={2}>
						{customer.first_name} {customer.last_name}
					</Box>
				</Box>
			))}
			<Box flexGrow={1}>&nbsp;</Box>
			<Button
				sx={{ borderRadius: 0 }}
				component={Link}
				to=""
				size="small"
				color="primary"
			>
				<Box p={1} sx={{ color: 'primary.main' }}>
					{translate('dashboard.orders.all_customers')}
				</Box>
			</Button>
		</CardWithIcon>
	);
};

export default NewCustomers;