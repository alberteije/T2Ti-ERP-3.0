import {
	Create,
} from "react-admin";
import { EfdReinfForm } from "./EfdReinfForm";

const EfdReinfCreate = () => {
	return (
		<Create>
			<EfdReinfForm />
		</Create>
	);
};

export default EfdReinfCreate;