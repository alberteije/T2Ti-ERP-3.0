import {
	Edit,
} from "react-admin";
import { EfdReinfForm } from "./EfdReinfForm";

const EfdReinfEdit = () => {
	return (
		<Edit>
			<EfdReinfForm />
		</Edit>
	);
};

export default EfdReinfEdit;