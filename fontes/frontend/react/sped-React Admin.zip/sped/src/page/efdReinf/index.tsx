import EfdReinfIcon from "@mui/icons-material/Apps";
import EfdReinfList from "./EfdReinfList";
import EfdReinfCreate from "./EfdReinfCreate";
import EfdReinfEdit from "./EfdReinfEdit";

export default {
	list: EfdReinfList,
	create: EfdReinfCreate,
	edit: EfdReinfEdit,
	icon: EfdReinfIcon,
};
