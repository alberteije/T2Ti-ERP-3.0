import {
	Edit,
} from "react-admin";
import { SpedContabilForm } from "./SpedContabilForm";

const SpedContabilEdit = () => {
	return (
		<Edit>
			<SpedContabilForm />
		</Edit>
	);
};

export default SpedContabilEdit;