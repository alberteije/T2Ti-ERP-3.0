import SpedContabilIcon from "@mui/icons-material/Apps";
import SpedContabilList from "./SpedContabilList";
import SpedContabilCreate from "./SpedContabilCreate";
import SpedContabilEdit from "./SpedContabilEdit";

export default {
	list: SpedContabilList,
	create: SpedContabilCreate,
	edit: SpedContabilEdit,
	icon: SpedContabilIcon,
};
