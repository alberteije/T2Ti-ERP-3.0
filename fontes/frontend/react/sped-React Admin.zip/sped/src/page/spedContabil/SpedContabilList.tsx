/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import SpedContabilDomain from '../../data/domain/SpedContabilDomain';

const SpedContabilList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataEmissao","periodoInicial","periodoFinal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SpedContabilSmallScreenList : SpedContabilBigScreenList;

	return (
		<List
			title="Sped Contábil"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SpedContabilSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataEmissao }
			secondaryText={ (record) => record.periodoInicial }
			tertiaryText={ (record) => record.periodoFinal }
		/>
	);
}

const SpedContabilBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="periodoInicial" label="Periodo Inicial" />
			<TextField source="periodoFinal" label="Periodo Final" />
			<FunctionField
				label="Forma Escrituracao"
				render={record => SpedContabilDomain.getFormaEscrituracao(record.formaEscrituracao)}
			/>
			<TextField source="versaoLayout" label="Versao Layout" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SpedContabilList;
