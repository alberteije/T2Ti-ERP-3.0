import {
	Edit,
} from "react-admin";
import { SintegraForm } from "./SintegraForm";

const SintegraEdit = () => {
	return (
		<Edit>
			<SintegraForm />
		</Edit>
	);
};

export default SintegraEdit;