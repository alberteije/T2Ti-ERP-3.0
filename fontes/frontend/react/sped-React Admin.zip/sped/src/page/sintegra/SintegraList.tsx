/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import SintegraDomain from '../../data/domain/SintegraDomain';

const SintegraList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataEmissao","periodoInicial","periodoFinal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SintegraSmallScreenList : SintegraBigScreenList;

	return (
		<List
			title="Sintegra"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SintegraSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataEmissao }
			secondaryText={ (record) => record.periodoInicial }
			tertiaryText={ (record) => record.periodoFinal }
		/>
	);
}

const SintegraBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="periodoInicial" label="Periodo Inicial" />
			<TextField source="periodoFinal" label="Periodo Final" />
			<FunctionField
				label="Codigo Convenio"
				render={record => SintegraDomain.getCodigoConvenio(record.codigoConvenio)}
			/>
			<FunctionField
				label="Inventario"
				render={record => SintegraDomain.getInventario(record.inventario)}
			/>
			<TextField source="finalidadeArquivo" label="Finalidade Arquivo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SintegraList;
