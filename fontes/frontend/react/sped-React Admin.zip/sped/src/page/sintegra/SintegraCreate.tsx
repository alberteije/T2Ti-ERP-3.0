import {
	Create,
} from "react-admin";
import { SintegraForm } from "./SintegraForm";

const SintegraCreate = () => {
	return (
		<Create>
			<SintegraForm />
		</Create>
	);
};

export default SintegraCreate;