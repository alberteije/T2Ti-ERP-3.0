import SintegraIcon from "@mui/icons-material/Apps";
import SintegraList from "./SintegraList";
import SintegraCreate from "./SintegraCreate";
import SintegraEdit from "./SintegraEdit";

export default {
	list: SintegraList,
	create: SintegraCreate,
	edit: SintegraEdit,
	icon: SintegraIcon,
};
