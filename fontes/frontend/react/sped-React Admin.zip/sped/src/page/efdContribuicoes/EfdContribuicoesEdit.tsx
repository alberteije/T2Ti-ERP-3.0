import {
	Edit,
} from "react-admin";
import { EfdContribuicoesForm } from "./EfdContribuicoesForm";

const EfdContribuicoesEdit = () => {
	return (
		<Edit>
			<EfdContribuicoesForm />
		</Edit>
	);
};

export default EfdContribuicoesEdit;