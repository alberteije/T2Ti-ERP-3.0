import EfdContribuicoesIcon from "@mui/icons-material/Apps";
import EfdContribuicoesList from "./EfdContribuicoesList";
import EfdContribuicoesCreate from "./EfdContribuicoesCreate";
import EfdContribuicoesEdit from "./EfdContribuicoesEdit";

export default {
	list: EfdContribuicoesList,
	create: EfdContribuicoesCreate,
	edit: EfdContribuicoesEdit,
	icon: EfdContribuicoesIcon,
};
