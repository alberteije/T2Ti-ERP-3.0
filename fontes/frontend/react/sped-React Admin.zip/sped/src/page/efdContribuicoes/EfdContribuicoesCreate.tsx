import {
	Create,
} from "react-admin";
import { EfdContribuicoesForm } from "./EfdContribuicoesForm";

const EfdContribuicoesCreate = () => {
	return (
		<Create>
			<EfdContribuicoesForm />
		</Create>
	);
};

export default EfdContribuicoesCreate;