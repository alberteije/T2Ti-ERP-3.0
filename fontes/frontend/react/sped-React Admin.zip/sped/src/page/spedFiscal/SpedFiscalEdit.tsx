import {
	Edit,
} from "react-admin";
import { SpedFiscalForm } from "./SpedFiscalForm";

const SpedFiscalEdit = () => {
	return (
		<Edit>
			<SpedFiscalForm />
		</Edit>
	);
};

export default SpedFiscalEdit;