/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import SpedFiscalDomain from '../../data/domain/SpedFiscalDomain';

const SpedFiscalList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataEmissao","periodoInicial","periodoFinal"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SpedFiscalSmallScreenList : SpedFiscalBigScreenList;

	return (
		<List
			title="Sped Fiscal"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SpedFiscalSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataEmissao }
			secondaryText={ (record) => record.periodoInicial }
			tertiaryText={ (record) => record.periodoFinal }
		/>
	);
}

const SpedFiscalBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="periodoInicial" label="Periodo Inicial" />
			<TextField source="periodoFinal" label="Periodo Final" />
			<FunctionField
				label="Perfil Apresentacao"
				render={record => SpedFiscalDomain.getPerfilApresentacao(record.perfilApresentacao)}
			/>
			<TextField source="finalidadeArquivo" label="Finalidade Arquivo" />
			<TextField source="versaoLayout" label="Versao Layout" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SpedFiscalList;
