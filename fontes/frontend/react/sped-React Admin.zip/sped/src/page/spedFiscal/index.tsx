import SpedFiscalIcon from "@mui/icons-material/Apps";
import SpedFiscalList from "./SpedFiscalList";
import SpedFiscalCreate from "./SpedFiscalCreate";
import SpedFiscalEdit from "./SpedFiscalEdit";

export default {
	list: SpedFiscalList,
	create: SpedFiscalCreate,
	edit: SpedFiscalEdit,
	icon: SpedFiscalIcon,
};
