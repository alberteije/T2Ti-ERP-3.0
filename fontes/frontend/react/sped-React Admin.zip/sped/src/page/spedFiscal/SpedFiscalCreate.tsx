import {
	Create,
} from "react-admin";
import { SpedFiscalForm } from "./SpedFiscalForm";

const SpedFiscalCreate = () => {
	return (
		<Create>
			<SpedFiscalForm />
		</Create>
	);
};

export default SpedFiscalCreate;