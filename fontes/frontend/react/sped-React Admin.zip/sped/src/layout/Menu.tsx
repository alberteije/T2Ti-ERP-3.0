import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import spedContabil from '../page/spedContabil';
import spedFiscal from '../page/spedFiscal';
import sintegra from '../page/sintegra';
import efdContribuicoes from '../page/efdContribuicoes';
import efdReinf from '../page/efdReinf';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/sped-contabil'
					state={{ _scrollToTop: true }}
					primaryText='Sped Contábil'
					leftIcon={<spedContabil.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/sped-fiscal'
					state={{ _scrollToTop: true }}
					primaryText='Sped Fiscal'
					leftIcon={<spedFiscal.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/sintegra'
					state={{ _scrollToTop: true }}
					primaryText='Sintegra'
					leftIcon={<sintegra.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/efd-contribuicoes'
					state={{ _scrollToTop: true }}
					primaryText='EFD Contribuições'
					leftIcon={<efdContribuicoes.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/efd-reinf'
					state={{ _scrollToTop: true }}
					primaryText='EFD REINF'
					leftIcon={<efdReinf.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
			</SubMenu>
		</Box>
	);
};

export default Menu;
