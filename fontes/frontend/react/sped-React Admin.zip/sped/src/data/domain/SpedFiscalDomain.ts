class SpedFiscalDomain {
	static getPerfilApresentacao(perfilApresentacao: string) { 
		switch (perfilApresentacao) { 
			case '': 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	} 

	static setPerfilApresentacao(perfilApresentacao: string) { 
		switch (perfilApresentacao) { 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

}

export default SpedFiscalDomain;