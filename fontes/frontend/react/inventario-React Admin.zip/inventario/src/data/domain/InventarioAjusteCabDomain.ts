class InventarioAjusteCabDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'A': 
				return 'Aumentar'; 
			case 'D': 
				return 'Diminuir'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Aumentar': 
				return 'A'; 
			case 'Diminuir': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

}

export default InventarioAjusteCabDomain;