import {
	Avatar,
	Box,
	Button,
	List,
	ListItem,
	ListItemAvatar,
	ListItemButton,
	ListItemText,
} from '@mui/material';
import CommentIcon from '@mui/icons-material/Comment';
import { Link } from 'react-router-dom';
import { useTranslate } from 'react-admin';

import CardWithIcon from './CardWithIcon';
import { Customer, Review } from './types';
import { useEffect, useState } from 'react';

const PendingReviews = () => {
	const translate = useTranslate();

	const [reviews, setReviews] = useState<Review[]>([]);
	const [customers, setCustomers] = useState<Customer[]>([]);

	useEffect(() => {
		const fetchData = async () => {
			try {
				// Load reviews
				const reviewsResponse = await fetch('/src/data/fake/reviews.json');
				const reviewsData = await reviewsResponse.json();
				setReviews(reviewsData);

				// Load customers
				const customersResponse = await fetch('/src/data/fake/customers.json');
				const customersData = await customersResponse.json();
				setCustomers(customersData);
			} catch (error) {
				console.error('Ohh no', error);
			}
		};

		fetchData();
	}, []);

	const total = reviews.length;
	const isPending = false; 
	const isCustomerDataLoaded = true; 

	const display = isPending || !isCustomerDataLoaded ? 'none' : 'block';

	return (
		<CardWithIcon
			to=""
			icon={CommentIcon}
			title={translate('dashboard.orders.last_reviews')}
			subtitle={total}
		>
			<List sx={{ display }}>
				{reviews.map((record: Review) => {
					const customer = customers.find(
						(cust) => cust.id === record.customer_id
					);

					return (
						<ListItem key={record.id} disablePadding>
							<ListItemButton
								alignItems="flex-start"
								component={Link}
								to={``}
							>
								<ListItemAvatar>
									{customer && (
										<Avatar
											src='/vycanis.png'
											sx={{
												bgcolor: 'background.paper',
											}}
											alt={'demo'}
										/>
									)}
								</ListItemAvatar>

								<ListItemText
									secondary={record.comment}
									sx={{
										overflowY: 'hidden',
										height: '4em',
										display: '-webkit-box',
										WebkitLineClamp: 2,
										WebkitBoxOrient: 'vertical',
										paddingRight: 0,
									}}
								/>
							</ListItemButton>
						</ListItem>
					);
				})}
			</List>
			<Box flexGrow={1}>&nbsp;</Box>
			<Button
				sx={{ borderRadius: 0 }}
				component={Link}
				to=""
				size="small"
				color="primary"
			>
				<Box p={1} sx={{ color: 'primary.main' }}>
					{translate('dashboard.orders.all_reviews')}
				</Box>
			</Button>
		</CardWithIcon>
	);
};

export default PendingReviews;