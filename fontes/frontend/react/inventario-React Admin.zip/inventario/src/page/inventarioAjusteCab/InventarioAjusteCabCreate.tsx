/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { InventarioAjusteCabForm } from "./InventarioAjusteCabForm";
import { transformNestedData } from "../../infra/utils";

const InventarioAjusteCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<InventarioAjusteCabForm />
		</Create>
	);
};

export default InventarioAjusteCabCreate;