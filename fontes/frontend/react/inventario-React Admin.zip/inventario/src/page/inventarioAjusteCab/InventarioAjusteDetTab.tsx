/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class InventarioAjusteDet {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): InventarioAjusteDet {
		const inventarioAjusteDet = new InventarioAjusteDet();
		inventarioAjusteDet.id = Date.now();
		inventarioAjusteDet.statusCrud = "C";
		return inventarioAjusteDet;
	}
}

export const InventarioAjusteDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: InventarioAjusteDet,
		setCurrentRecord: (record: InventarioAjusteDet) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'valorOriginal', label: 'Valor Original' },
		{ source: 'valorReajuste', label: 'Valor Reajuste' },
	];

	return (
		<CrudChildTab
			title="Produtos"
			recordContext="inventarioAjusteCab"
			fieldSource="inventarioAjusteDetModelList"
			newObject={ InventarioAjusteDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};