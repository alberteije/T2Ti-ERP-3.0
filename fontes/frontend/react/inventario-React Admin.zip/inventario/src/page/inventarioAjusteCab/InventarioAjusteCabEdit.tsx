/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { InventarioAjusteCabForm } from "./InventarioAjusteCabForm";
import { transformNestedData } from "../../infra/utils";

const InventarioAjusteCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<InventarioAjusteCabForm />
		</Edit>
	);
};

export default InventarioAjusteCabEdit;