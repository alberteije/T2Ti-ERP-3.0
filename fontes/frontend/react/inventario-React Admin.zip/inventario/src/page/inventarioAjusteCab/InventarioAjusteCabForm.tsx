/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { InventarioAjusteDetTab } from './InventarioAjusteDetTab';

export const InventarioAjusteCabForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Ajustes de Preço">
				<InventarioAjusteCabTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Produtos">
				<InventarioAjusteDetTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const InventarioAjusteCabTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};