/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import InventarioAjusteCabDomain from '../../data/domain/InventarioAjusteCabDomain';

const InventarioAjusteCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataAjuste","tipo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? InventarioAjusteCabSmallScreenList : InventarioAjusteCabBigScreenList;

	return (
		<List
			title="Ajustes de Preço"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const InventarioAjusteCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataAjuste }
			tertiaryText={ (record) => record.tipo }
		/>
	);
}

const InventarioAjusteCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id View Pessoa Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataAjuste" label="Data Ajuste" />
			<FunctionField
				label="Tipo"
				render={record => InventarioAjusteCabDomain.getTipo(record.tipo)}
			/>
			<NumberField source="taxa" label="Taxa" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="justificativa" label="Justificativa" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default InventarioAjusteCabList;
