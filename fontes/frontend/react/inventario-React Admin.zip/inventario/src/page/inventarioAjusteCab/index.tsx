import InventarioAjusteCabIcon from "@mui/icons-material/Apps";
import InventarioAjusteCabList from "./InventarioAjusteCabList";
import InventarioAjusteCabCreate from "./InventarioAjusteCabCreate";
import InventarioAjusteCabEdit from "./InventarioAjusteCabEdit";

export default {
	list: InventarioAjusteCabList,
	create: InventarioAjusteCabCreate,
	edit: InventarioAjusteCabEdit,
	icon: InventarioAjusteCabIcon,
};
