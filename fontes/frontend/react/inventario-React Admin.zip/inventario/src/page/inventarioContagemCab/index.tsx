import InventarioContagemCabIcon from "@mui/icons-material/Apps";
import InventarioContagemCabList from "./InventarioContagemCabList";
import InventarioContagemCabCreate from "./InventarioContagemCabCreate";
import InventarioContagemCabEdit from "./InventarioContagemCabEdit";

export default {
	list: InventarioContagemCabList,
	create: InventarioContagemCabCreate,
	edit: InventarioContagemCabEdit,
	icon: InventarioContagemCabIcon,
};
