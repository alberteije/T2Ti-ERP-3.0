/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import InventarioContagemCabDomain from '../../data/domain/InventarioContagemCabDomain';

const InventarioContagemCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataContagem","estoqueAtualizado","tipo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? InventarioContagemCabSmallScreenList : InventarioContagemCabBigScreenList;

	return (
		<List
			title="Contagem de Produtos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const InventarioContagemCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataContagem }
			secondaryText={ (record) => record.estoqueAtualizado }
			tertiaryText={ (record) => record.tipo }
		/>
	);
}

const InventarioContagemCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataContagem" label="Data Contagem" />
			<FunctionField
				label="Estoque Atualizado"
				render={record => InventarioContagemCabDomain.getEstoqueAtualizado(record.estoqueAtualizado)}
			/>
			<FunctionField
				label="Tipo"
				render={record => InventarioContagemCabDomain.getTipo(record.tipo)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default InventarioContagemCabList;
