/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { InventarioContagemDetTab } from './InventarioContagemDetTab';

export const InventarioContagemCabForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Contagem de Produtos">
				<InventarioContagemCabTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Produtos">
				<InventarioContagemDetTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const InventarioContagemCabTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};