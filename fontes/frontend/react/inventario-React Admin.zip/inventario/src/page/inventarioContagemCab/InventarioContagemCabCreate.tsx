/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { InventarioContagemCabForm } from "./InventarioContagemCabForm";
import { transformNestedData } from "../../infra/utils";

const InventarioContagemCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<InventarioContagemCabForm />
		</Create>
	);
};

export default InventarioContagemCabCreate;