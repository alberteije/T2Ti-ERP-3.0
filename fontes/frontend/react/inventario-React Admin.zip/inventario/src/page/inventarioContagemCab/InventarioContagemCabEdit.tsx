/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { InventarioContagemCabForm } from "./InventarioContagemCabForm";
import { transformNestedData } from "../../infra/utils";

const InventarioContagemCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<InventarioContagemCabForm />
		</Edit>
	);
};

export default InventarioContagemCabEdit;