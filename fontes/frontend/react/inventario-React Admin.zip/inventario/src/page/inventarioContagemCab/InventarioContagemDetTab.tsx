/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import InventarioContagemDetDomain from '../../data/domain/InventarioContagemDetDomain';

class InventarioContagemDet {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): InventarioContagemDet {
		const inventarioContagemDet = new InventarioContagemDet();
		inventarioContagemDet.id = Date.now();
		inventarioContagemDet.statusCrud = "C";
		return inventarioContagemDet;
	}
}

export const InventarioContagemDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: InventarioContagemDet,
		setCurrentRecord: (record: InventarioContagemDet) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'contagem01', label: 'Contagem 01' },
		{ source: 'contagem02', label: 'Contagem 02' },
		{ source: 'contagem03', label: 'Contagem 03' },
		{ source: 'fechadoContagem', label: 'Fechado Contagem', formatDomain: InventarioContagemDetDomain.getFechadoContagem },
		{ source: 'quantidadeSistema', label: 'Quantidade Sistema' },
		{ source: 'acuracidade', label: 'Acuracidade' },
		{ source: 'divergencia', label: 'Divergencia' },
	];

	return (
		<CrudChildTab
			title="Produtos"
			recordContext="inventarioContagemCab"
			fieldSource="inventarioContagemDetModelList"
			newObject={ InventarioContagemDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};