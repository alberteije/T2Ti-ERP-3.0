import EstoqueSaborIcon from "@mui/icons-material/Apps";
import EstoqueSaborList from "./EstoqueSaborList";
import EstoqueSaborCreate from "./EstoqueSaborCreate";
import EstoqueSaborEdit from "./EstoqueSaborEdit";

export default {
	list: EstoqueSaborList,
	create: EstoqueSaborCreate,
	edit: EstoqueSaborEdit,
	icon: EstoqueSaborIcon,
};
