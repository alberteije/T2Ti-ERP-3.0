import {
	Edit,
} from "react-admin";
import { EstoqueSaborForm } from "./EstoqueSaborForm";

const EstoqueSaborEdit = () => {
	return (
		<Edit>
			<EstoqueSaborForm />
		</Edit>
	);
};

export default EstoqueSaborEdit;