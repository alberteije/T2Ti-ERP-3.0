import {
	Create,
} from "react-admin";
import { EstoqueSaborForm } from "./EstoqueSaborForm";

const EstoqueSaborCreate = () => {
	return (
		<Create>
			<EstoqueSaborForm />
		</Create>
	);
};

export default EstoqueSaborCreate;