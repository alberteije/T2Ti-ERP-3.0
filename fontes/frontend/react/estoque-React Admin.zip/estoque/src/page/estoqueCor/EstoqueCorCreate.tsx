import {
	Create,
} from "react-admin";
import { EstoqueCorForm } from "./EstoqueCorForm";

const EstoqueCorCreate = () => {
	return (
		<Create>
			<EstoqueCorForm />
		</Create>
	);
};

export default EstoqueCorCreate;