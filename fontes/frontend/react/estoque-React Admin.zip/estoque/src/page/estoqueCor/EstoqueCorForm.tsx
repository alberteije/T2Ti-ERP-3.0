/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const EstoqueCorForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[4]'
					validate={[maxLength(4, 'Max=4'), ]}
				/>
			</Box>
			<Box flex={9}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[50]'
					validate={[maxLength(50, 'Max=50'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);