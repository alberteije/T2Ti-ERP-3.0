import EstoqueCorIcon from "@mui/icons-material/Apps";
import EstoqueCorList from "./EstoqueCorList";
import EstoqueCorCreate from "./EstoqueCorCreate";
import EstoqueCorEdit from "./EstoqueCorEdit";

export default {
	list: EstoqueCorList,
	create: EstoqueCorCreate,
	edit: EstoqueCorEdit,
	icon: EstoqueCorIcon,
};
