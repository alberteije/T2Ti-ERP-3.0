import {
	Edit,
} from "react-admin";
import { EstoqueCorForm } from "./EstoqueCorForm";

const EstoqueCorEdit = () => {
	return (
		<Edit>
			<EstoqueCorForm />
		</Edit>
	);
};

export default EstoqueCorEdit;