import {
	Edit,
} from "react-admin";
import { EstoqueGradeForm } from "./EstoqueGradeForm";

const EstoqueGradeEdit = () => {
	return (
		<Edit>
			<EstoqueGradeForm />
		</Edit>
	);
};

export default EstoqueGradeEdit;