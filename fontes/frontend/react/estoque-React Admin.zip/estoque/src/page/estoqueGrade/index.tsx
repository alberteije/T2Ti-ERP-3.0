import EstoqueGradeIcon from "@mui/icons-material/Apps";
import EstoqueGradeList from "./EstoqueGradeList";
import EstoqueGradeCreate from "./EstoqueGradeCreate";
import EstoqueGradeEdit from "./EstoqueGradeEdit";

export default {
	list: EstoqueGradeList,
	create: EstoqueGradeCreate,
	edit: EstoqueGradeEdit,
	icon: EstoqueGradeIcon,
};
