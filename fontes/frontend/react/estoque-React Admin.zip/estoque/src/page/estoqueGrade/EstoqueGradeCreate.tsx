import {
	Create,
} from "react-admin";
import { EstoqueGradeForm } from "./EstoqueGradeForm";

const EstoqueGradeCreate = () => {
	return (
		<Create>
			<EstoqueGradeForm />
		</Create>
	);
};

export default EstoqueGradeCreate;