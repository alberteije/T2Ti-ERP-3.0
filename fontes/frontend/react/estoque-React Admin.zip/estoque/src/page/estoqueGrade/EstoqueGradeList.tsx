/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EstoqueGradeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["produtoModel.nome","estoqueMarcaModel.nome","estoqueSaborModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EstoqueGradeSmallScreenList : EstoqueGradeBigScreenList;

	return (
		<List
			title="Grade de Estoque"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EstoqueGradeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.produtoModel.nome }
			secondaryText={ (record) => record.estoqueMarcaModel.nome }
			tertiaryText={ (record) => record.estoqueSaborModel.nome }
		/>
	);
}

const EstoqueGradeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Produto" source="produtoModel.id" reference="produto" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Estoque Marca" source="estoqueMarcaModel.id" reference="estoque-marca" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Estoque Sabor" source="estoqueSaborModel.id" reference="estoque-sabor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Estoque Tamanho" source="estoqueTamanhoModel.id" reference="estoque-tamanho" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Estoque Cor" source="estoqueCorModel.id" reference="estoque-cor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<NumberField source="quantidade" label="Quantidade" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EstoqueGradeList;
