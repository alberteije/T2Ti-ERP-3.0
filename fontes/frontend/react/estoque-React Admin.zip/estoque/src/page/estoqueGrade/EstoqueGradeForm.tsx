/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const EstoqueGradeForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='estoqueMarcaModel.id' reference='estoque-marca' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Marca'
						optionText='nome'
						helperText='Informe os dados para o campo Marca'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='estoqueSaborModel.id' reference='estoque-sabor' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Sabor'
						optionText='nome'
						helperText='Informe os dados para o campo Sabor'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='estoqueTamanhoModel.id' reference='estoque-tamanho' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tamanho'
						optionText='nome'
						helperText='Informe os dados para o campo Tamanho'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='estoqueCorModel.id' reference='estoque-cor' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Cor'
						optionText='nome'
						helperText='Informe os dados para o campo Cor'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[50]'
					validate={[maxLength(50, 'Max=50'), ]}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='quantidade'
					label='Quantidade'
					helperText='Informe os dados para o campo Quantidade'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);