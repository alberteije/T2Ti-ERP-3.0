/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import EstoqueReajusteCabecalhoDomain from '../../data/domain/EstoqueReajusteCabecalhoDomain';

const EstoqueReajusteCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataReajuste","taxa"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EstoqueReajusteCabecalhoSmallScreenList : EstoqueReajusteCabecalhoBigScreenList;

	return (
		<List
			title="Reajuste de Preços"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EstoqueReajusteCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataReajuste }
			tertiaryText={ (record) => record.taxa }
		/>
	);
}

const EstoqueReajusteCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataReajuste" label="Data Reajuste" />
			<NumberField source="taxa" label="Taxa" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Tipo Reajuste"
				render={record => EstoqueReajusteCabecalhoDomain.getTipoReajuste(record.tipoReajuste)}
			/>
			<TextField source="justificativa" label="Justificativa" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EstoqueReajusteCabecalhoList;
