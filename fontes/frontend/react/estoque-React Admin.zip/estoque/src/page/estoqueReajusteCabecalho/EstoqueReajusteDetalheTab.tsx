/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class EstoqueReajusteDetalhe {
	constructor(
		public id = 0,
		public produtoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public valorOriginal = null,
		public valorReajuste = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EstoqueReajusteDetalhe {
		const estoqueReajusteDetalhe = new EstoqueReajusteDetalhe();
		estoqueReajusteDetalhe.id = Date.now();
		estoqueReajusteDetalhe.statusCrud = "C";
		return estoqueReajusteDetalhe;
	}
}

export const EstoqueReajusteDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: EstoqueReajusteDetalhe,
		setCurrentRecord: (record: EstoqueReajusteDetalhe) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								produtoModel: {
						  		...currentRecord.produtoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<NumberInput
					source='valorOriginal'
					label='Valor Original'
					helperText='Informe os dados para o campo Valor Original'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorOriginal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorOriginal ?? ''}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='valorReajuste'
					label='Valor Reajuste'
					helperText='Informe os dados para o campo Valor Reajuste'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorReajuste: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorReajuste ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'valorOriginal', label: 'Valor Original' },
		{ source: 'valorReajuste', label: 'Valor Reajuste' },
	];

	return (
		<CrudChildTab
			title="Itens do Reajuste"
			recordContext="estoqueReajusteCabecalho"
			fieldSource="estoqueReajusteDetalheModelList"
			newObject={ EstoqueReajusteDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};