/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { EstoqueReajusteCabecalhoForm } from "./EstoqueReajusteCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const EstoqueReajusteCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<EstoqueReajusteCabecalhoForm />
		</Create>
	);
};

export default EstoqueReajusteCabecalhoCreate;