/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	DateInput,
	NumberInput,
	SelectInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";
import { EstoqueReajusteDetalheTab } from './EstoqueReajusteDetalheTab';

export const EstoqueReajusteCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Reajuste de Preços">
				<EstoqueReajusteCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens do Reajuste">
				<EstoqueReajusteDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const EstoqueReajusteCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='viewPessoaColaboradorModel.id' reference='view-pessoa-colaborador' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Colaborador'
						optionText='nome'
						helperText='Informe os dados para o campo Colaborador'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<DateInput
					source='dataReajuste'
					label='Data Reajuste'
					helperText='Informe os dados para o campo Data Reajuste'
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='taxa'
					label='Taxa'
					helperText='Informe os dados para o campo Taxa'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='Tipo Reajuste'
					source='tipoReajuste'
					helperText='Informe os dados para o campo Tipo Reajuste'
					choices={ [{"id":"A","name":"Aumentar"},{"id":"D","name":"Diminuir"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='justificativa'
					label='Justificativa'
					helperText='Informe os dados para o campo Justificativa[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
	</>
	);
};