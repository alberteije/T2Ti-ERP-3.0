import EstoqueReajusteCabecalhoIcon from "@mui/icons-material/Apps";
import EstoqueReajusteCabecalhoList from "./EstoqueReajusteCabecalhoList";
import EstoqueReajusteCabecalhoCreate from "./EstoqueReajusteCabecalhoCreate";
import EstoqueReajusteCabecalhoEdit from "./EstoqueReajusteCabecalhoEdit";

export default {
	list: EstoqueReajusteCabecalhoList,
	create: EstoqueReajusteCabecalhoCreate,
	edit: EstoqueReajusteCabecalhoEdit,
	icon: EstoqueReajusteCabecalhoIcon,
};
