/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const EstoqueTamanhoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[4]'
					validate={[maxLength(4, 'Max=4'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[50]'
					validate={[maxLength(50, 'Max=50'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='altura'
					label='Altura'
					helperText='Informe os dados para o campo Altura'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='comprimento'
					label='Comprimento'
					helperText='Informe os dados para o campo Comprimento'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='largura'
					label='Largura'
					helperText='Informe os dados para o campo Largura'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);