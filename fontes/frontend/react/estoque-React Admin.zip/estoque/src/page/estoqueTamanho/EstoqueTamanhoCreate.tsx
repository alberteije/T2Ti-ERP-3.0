import {
	Create,
} from "react-admin";
import { EstoqueTamanhoForm } from "./EstoqueTamanhoForm";

const EstoqueTamanhoCreate = () => {
	return (
		<Create>
			<EstoqueTamanhoForm />
		</Create>
	);
};

export default EstoqueTamanhoCreate;