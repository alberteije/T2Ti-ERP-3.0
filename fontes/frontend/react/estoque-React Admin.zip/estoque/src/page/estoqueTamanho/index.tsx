import EstoqueTamanhoIcon from "@mui/icons-material/Apps";
import EstoqueTamanhoList from "./EstoqueTamanhoList";
import EstoqueTamanhoCreate from "./EstoqueTamanhoCreate";
import EstoqueTamanhoEdit from "./EstoqueTamanhoEdit";

export default {
	list: EstoqueTamanhoList,
	create: EstoqueTamanhoCreate,
	edit: EstoqueTamanhoEdit,
	icon: EstoqueTamanhoIcon,
};
