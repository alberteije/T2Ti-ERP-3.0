/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EstoqueTamanhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","altura"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EstoqueTamanhoSmallScreenList : EstoqueTamanhoBigScreenList;

	return (
		<List
			title="Tamanhos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EstoqueTamanhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.altura }
		/>
	);
}

const EstoqueTamanhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<NumberField source="altura" label="Altura" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="comprimento" label="Comprimento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="largura" label="Largura" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EstoqueTamanhoList;
