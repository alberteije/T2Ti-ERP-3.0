import {
	Edit,
} from "react-admin";
import { EstoqueTamanhoForm } from "./EstoqueTamanhoForm";

const EstoqueTamanhoEdit = () => {
	return (
		<Edit>
			<EstoqueTamanhoForm />
		</Edit>
	);
};

export default EstoqueTamanhoEdit;