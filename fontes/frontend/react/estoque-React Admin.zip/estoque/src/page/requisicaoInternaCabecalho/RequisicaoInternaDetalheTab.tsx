/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class RequisicaoInternaDetalhe {
	constructor(
		public id = 0,
		public produtoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public quantidade = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): RequisicaoInternaDetalhe {
		const requisicaoInternaDetalhe = new RequisicaoInternaDetalhe();
		requisicaoInternaDetalhe.id = Date.now();
		requisicaoInternaDetalhe.statusCrud = "C";
		return requisicaoInternaDetalhe;
	}
}

export const RequisicaoInternaDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: RequisicaoInternaDetalhe,
		setCurrentRecord: (record: RequisicaoInternaDetalhe) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={9}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								produtoModel: {
						  		...currentRecord.produtoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='quantidade'
					label='Quantidade'
					helperText='Informe os dados para o campo Quantidade'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									quantidade: e.target.value,
								});
							}} format={(_: any) => currentRecord.quantidade ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Itens Requisicao"
			recordContext="requisicaoInternaCabecalho"
			fieldSource="requisicaoInternaDetalheModelList"
			newObject={ RequisicaoInternaDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};