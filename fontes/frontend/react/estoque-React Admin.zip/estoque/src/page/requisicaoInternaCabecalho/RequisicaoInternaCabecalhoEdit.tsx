/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { RequisicaoInternaCabecalhoForm } from "./RequisicaoInternaCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const RequisicaoInternaCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<RequisicaoInternaCabecalhoForm />
		</Edit>
	);
};

export default RequisicaoInternaCabecalhoEdit;