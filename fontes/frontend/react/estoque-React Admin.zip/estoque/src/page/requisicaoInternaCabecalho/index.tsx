import RequisicaoInternaCabecalhoIcon from "@mui/icons-material/Apps";
import RequisicaoInternaCabecalhoList from "./RequisicaoInternaCabecalhoList";
import RequisicaoInternaCabecalhoCreate from "./RequisicaoInternaCabecalhoCreate";
import RequisicaoInternaCabecalhoEdit from "./RequisicaoInternaCabecalhoEdit";

export default {
	list: RequisicaoInternaCabecalhoList,
	create: RequisicaoInternaCabecalhoCreate,
	edit: RequisicaoInternaCabecalhoEdit,
	icon: RequisicaoInternaCabecalhoIcon,
};
