/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	DateInput,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { RequisicaoInternaDetalheTab } from './RequisicaoInternaDetalheTab';

export const RequisicaoInternaCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Requisicao Interna">
				<RequisicaoInternaCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens Requisicao">
				<RequisicaoInternaDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const RequisicaoInternaCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='viewPessoaColaboradorModel.id' reference='view-pessoa-colaborador' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Colaborador'
						optionText='nome'
						helperText='Informe os dados para o campo Colaborador'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<DateInput
					source='dataRequisicao'
					label='Data Requisicao'
					helperText='Informe os dados para o campo Data Requisicao'
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Situacao'
					source='situacao'
					helperText='Informe os dados para o campo Situacao'
					choices={ [{"id":"A","name":"Aberta"},{"id":"D","name":"Deferida"},{"id":"I","name":"Indeferida"}] }  
				/>
			</Box>
		</Box>
	</>
	);
};