import {
	Create,
} from "react-admin";
import { EstoqueMarcaForm } from "./EstoqueMarcaForm";

const EstoqueMarcaCreate = () => {
	return (
		<Create>
			<EstoqueMarcaForm />
		</Create>
	);
};

export default EstoqueMarcaCreate;