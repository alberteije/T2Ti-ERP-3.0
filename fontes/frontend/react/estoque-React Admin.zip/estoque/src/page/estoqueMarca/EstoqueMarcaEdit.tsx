import {
	Edit,
} from "react-admin";
import { EstoqueMarcaForm } from "./EstoqueMarcaForm";

const EstoqueMarcaEdit = () => {
	return (
		<Edit>
			<EstoqueMarcaForm />
		</Edit>
	);
};

export default EstoqueMarcaEdit;