import EstoqueMarcaIcon from "@mui/icons-material/Apps";
import EstoqueMarcaList from "./EstoqueMarcaList";
import EstoqueMarcaCreate from "./EstoqueMarcaCreate";
import EstoqueMarcaEdit from "./EstoqueMarcaEdit";

export default {
	list: EstoqueMarcaList,
	create: EstoqueMarcaCreate,
	edit: EstoqueMarcaEdit,
	icon: EstoqueMarcaIcon,
};
