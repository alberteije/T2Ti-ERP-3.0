import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import requisicaoInternaCabecalho from '../page/requisicaoInternaCabecalho';
import estoqueReajusteCabecalho from '../page/estoqueReajusteCabecalho';
import estoqueCor from '../page/estoqueCor';
import estoqueTamanho from '../page/estoqueTamanho';
import estoqueSabor from '../page/estoqueSabor';
import estoqueMarca from '../page/estoqueMarca';
import estoqueGrade from '../page/estoqueGrade';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/estoque-cor'
					state={{ _scrollToTop: true }}
					primaryText='Cores'
					leftIcon={<estoqueCor.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/estoque-tamanho'
					state={{ _scrollToTop: true }}
					primaryText='Tamanhos'
					leftIcon={<estoqueTamanho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/estoque-sabor'
					state={{ _scrollToTop: true }}
					primaryText='Sabores'
					leftIcon={<estoqueSabor.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/estoque-marca'
					state={{ _scrollToTop: true }}
					primaryText='Marcas'
					leftIcon={<estoqueMarca.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/estoque-grade'
					state={{ _scrollToTop: true }}
					primaryText='Grade de Estoque'
					leftIcon={<estoqueGrade.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/requisicao-interna-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Requisicao Interna'
					leftIcon={<requisicaoInternaCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/estoque-reajuste-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Reajuste de Preços'
					leftIcon={<estoqueReajusteCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
