class EstoqueReajusteCabecalhoDomain {
	static getTipoReajuste(tipoReajuste: string) { 
		switch (tipoReajuste) { 
			case '': 
			case 'A': 
				return 'Aumentar'; 
			case 'D': 
				return 'Diminuir'; 
			default: 
				return null; 
		} 
	} 

	static setTipoReajuste(tipoReajuste: string) { 
		switch (tipoReajuste) { 
			case 'Aumentar': 
				return 'A'; 
			case 'Diminuir': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

}

export default EstoqueReajusteCabecalhoDomain;