class RequisicaoInternaCabecalhoDomain {
	static getSituacao(situacao: string) { 
		switch (situacao) { 
			case '': 
			case 'A': 
				return 'Aberta'; 
			case 'D': 
				return 'Deferida'; 
			case 'I': 
				return 'Indeferida'; 
			default: 
				return null; 
		} 
	} 

	static setSituacao(situacao: string) { 
		switch (situacao) { 
			case 'Aberta': 
				return 'A'; 
			case 'Deferida': 
				return 'D'; 
			case 'Indeferida': 
				return 'I'; 
			default: 
				return null; 
		} 
	}

}

export default RequisicaoInternaCabecalhoDomain;