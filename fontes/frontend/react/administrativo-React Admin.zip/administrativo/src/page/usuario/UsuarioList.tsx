/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import UsuarioDomain from '../../data/domain/UsuarioDomain';

const UsuarioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["papelModel.nome","viewPessoaColaboradorModel.nome","login"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? UsuarioSmallScreenList : UsuarioBigScreenList;

	return (
		<List
			title="Usuário"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const UsuarioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.papelModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.login }
		/>
	);
}

const UsuarioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Papel" source="papelModel.id" reference="papel" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="login" label="Login" />
			<TextField source="senha" label="Senha" />
			<FunctionField
				label="Administrador"
				render={record => UsuarioDomain.getAdministrador(record.administrador)}
			/>
			<TextField source="dataCadastro" label="Data Cadastro" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default UsuarioList;
