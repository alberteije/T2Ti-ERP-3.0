import {
	Create,
} from "react-admin";
import { UsuarioForm } from "./UsuarioForm";

const UsuarioCreate = () => {
	return (
		<Create>
			<UsuarioForm />
		</Create>
	);
};

export default UsuarioCreate;