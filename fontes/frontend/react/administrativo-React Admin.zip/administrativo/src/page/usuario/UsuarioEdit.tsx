import {
	Edit,
} from "react-admin";
import { UsuarioForm } from "./UsuarioForm";

const UsuarioEdit = () => {
	return (
		<Edit>
			<UsuarioForm />
		</Edit>
	);
};

export default UsuarioEdit;