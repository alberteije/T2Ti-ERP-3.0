import PapelIcon from "@mui/icons-material/Apps";
import PapelList from "./PapelList";
import PapelCreate from "./PapelCreate";
import PapelEdit from "./PapelEdit";

export default {
	list: PapelList,
	create: PapelCreate,
	edit: PapelEdit,
	icon: PapelIcon,
};
