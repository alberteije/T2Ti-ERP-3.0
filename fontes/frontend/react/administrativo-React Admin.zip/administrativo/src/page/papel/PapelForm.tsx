/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PapelFuncaoTab } from './PapelFuncaoTab';

export const PapelForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Papel">
				<PapelTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Controle de Acesso">
				<PapelFuncaoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PapelTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};