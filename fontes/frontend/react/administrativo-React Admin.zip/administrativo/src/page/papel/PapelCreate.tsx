/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PapelForm } from "./PapelForm";
import { transformNestedData } from "../../infra/utils";

const PapelCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PapelForm />
		</Create>
	);
};

export default PapelCreate;