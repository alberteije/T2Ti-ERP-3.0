/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PapelList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PapelSmallScreenList : PapelBigScreenList;

	return (
		<List
			title="Papel"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PapelSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const PapelBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PapelList;
