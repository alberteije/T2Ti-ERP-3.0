/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import PapelFuncaoDomain from '../../data/domain/PapelFuncaoDomain';

class PapelFuncao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PapelFuncao {
		const papelFuncao = new PapelFuncao();
		papelFuncao.id = Date.now();
		papelFuncao.statusCrud = "C";
		return papelFuncao;
	}
}

export const PapelFuncaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PapelFuncao,
		setCurrentRecord: (record: PapelFuncao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'funcaoModel.id', label: 'Função', reference: 'funcao', fieldName: 'nome' },
		{ source: 'habilitado', label: 'Habilitado', formatDomain: PapelFuncaoDomain.getHabilitado },
		{ source: 'podeInserir', label: 'Pode Inserir', formatDomain: PapelFuncaoDomain.getPodeInserir },
		{ source: 'podeAlterar', label: 'Pode Alterar', formatDomain: PapelFuncaoDomain.getPodeAlterar },
		{ source: 'podeExcluir', label: 'Pode Excluir', formatDomain: PapelFuncaoDomain.getPodeExcluir },
	];

	return (
		<CrudChildTab
			title="Controle de Acesso"
			recordContext="papel"
			fieldSource="papelFuncaoModelList"
			newObject={ PapelFuncao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};