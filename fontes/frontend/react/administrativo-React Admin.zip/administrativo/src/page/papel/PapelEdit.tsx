/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PapelForm } from "./PapelForm";
import { transformNestedData } from "../../infra/utils";

const PapelEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PapelForm />
		</Edit>
	);
};

export default PapelEdit;