import {
	Create,
} from "react-admin";
import { AuditoriaForm } from "./AuditoriaForm";

const AuditoriaCreate = () => {
	return (
		<Create>
			<AuditoriaForm />
		</Create>
	);
};

export default AuditoriaCreate;