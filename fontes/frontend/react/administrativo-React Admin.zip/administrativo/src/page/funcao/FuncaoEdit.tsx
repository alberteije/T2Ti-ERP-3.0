import {
	Edit,
} from "react-admin";
import { FuncaoForm } from "./FuncaoForm";

const FuncaoEdit = () => {
	return (
		<Edit>
			<FuncaoForm />
		</Edit>
	);
};

export default FuncaoEdit;