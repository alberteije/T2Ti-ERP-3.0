import FuncaoIcon from "@mui/icons-material/Apps";
import FuncaoList from "./FuncaoList";
import FuncaoCreate from "./FuncaoCreate";
import FuncaoEdit from "./FuncaoEdit";

export default {
	list: FuncaoList,
	create: FuncaoCreate,
	edit: FuncaoEdit,
	icon: FuncaoIcon,
};
