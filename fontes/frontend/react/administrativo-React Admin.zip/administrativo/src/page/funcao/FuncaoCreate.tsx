import {
	Create,
} from "react-admin";
import { FuncaoForm } from "./FuncaoForm";

const FuncaoCreate = () => {
	return (
		<Create>
			<FuncaoForm />
		</Create>
	);
};

export default FuncaoCreate;