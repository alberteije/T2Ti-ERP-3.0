/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import EmpresaTelefoneDomain from '../../data/domain/EmpresaTelefoneDomain';

class EmpresaTelefone {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaTelefone {
		const empresaTelefone = new EmpresaTelefone();
		empresaTelefone.id = Date.now();
		empresaTelefone.statusCrud = "C";
		return empresaTelefone;
	}
}

export const EmpresaTelefoneTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaTelefone,
		setCurrentRecord: (record: EmpresaTelefone) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tipo', label: 'Tipo', formatDomain: EmpresaTelefoneDomain.getTipo },
		{ source: 'numero', label: 'Número', formatMask: formatWithMask, mask: '(##)#####-####' },
	];

	return (
		<CrudChildTab
			title="Telefones"
			recordContext="empresa"
			fieldSource="empresaTelefoneModelList"
			newObject={ EmpresaTelefone.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};