/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { EmpresaForm } from "./EmpresaForm";
import { transformNestedData } from "../../infra/utils";

const EmpresaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<EmpresaForm />
		</Create>
	);
};

export default EmpresaCreate;