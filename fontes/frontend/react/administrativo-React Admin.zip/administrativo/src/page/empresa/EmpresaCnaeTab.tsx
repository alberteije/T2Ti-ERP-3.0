/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import EmpresaCnaeDomain from '../../data/domain/EmpresaCnaeDomain';

class EmpresaCnae {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaCnae {
		const empresaCnae = new EmpresaCnae();
		empresaCnae.id = Date.now();
		empresaCnae.statusCrud = "C";
		return empresaCnae;
	}
}

export const EmpresaCnaeTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaCnae,
		setCurrentRecord: (record: EmpresaCnae) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnaeModel.id', label: 'CNAE', reference: 'cnae', fieldName: 'codigo' },
		{ source: 'principal', label: 'Principal', formatDomain: EmpresaCnaeDomain.getPrincipal },
		{ source: 'ramoAtividade', label: 'Ramo Atividade' },
		{ source: 'objetoSocial', label: 'Objeto Social' },
	];

	return (
		<CrudChildTab
			title="CNAEs"
			recordContext="empresa"
			fieldSource="empresaCnaeModelList"
			newObject={ EmpresaCnae.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};