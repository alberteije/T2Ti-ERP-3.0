/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { EmpresaContatoTab } from './EmpresaContatoTab';
import { EmpresaTelefoneTab } from './EmpresaTelefoneTab';
import { EmpresaCnaeTab } from './EmpresaCnaeTab';
import { EmpresaEnderecoTab } from './EmpresaEnderecoTab';

export const EmpresaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Empresa">
				<EmpresaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Contatos">
				<EmpresaContatoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Telefones">
				<EmpresaTelefoneTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="CNAEs">
				<EmpresaCnaeTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Endereços">
				<EmpresaEnderecoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const EmpresaTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};