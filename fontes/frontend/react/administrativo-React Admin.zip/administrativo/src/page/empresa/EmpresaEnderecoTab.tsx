/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import EmpresaEnderecoDomain from '../../data/domain/EmpresaEnderecoDomain';

class EmpresaEndereco {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaEndereco {
		const empresaEndereco = new EmpresaEndereco();
		empresaEndereco.id = Date.now();
		empresaEndereco.statusCrud = "C";
		return empresaEndereco;
	}
}

export const EmpresaEnderecoTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaEndereco,
		setCurrentRecord: (record: EmpresaEndereco) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'cidade', label: 'Cidade' },
		{ source: 'uf', label: 'UF', formatDomain: EmpresaEnderecoDomain.getUf },
		{ source: 'cep', label: 'CEP', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'municipioIbge', label: 'Municipio Ibge' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'principal', label: 'Principal', formatDomain: EmpresaEnderecoDomain.getPrincipal },
		{ source: 'entrega', label: 'Entrega', formatDomain: EmpresaEnderecoDomain.getEntrega },
		{ source: 'cobranca', label: 'Cobrança', formatDomain: EmpresaEnderecoDomain.getCobranca },
		{ source: 'correspondencia', label: 'Correspondência', formatDomain: EmpresaEnderecoDomain.getCorrespondencia },
	];

	return (
		<CrudChildTab
			title="Endereços"
			recordContext="empresa"
			fieldSource="empresaEnderecoModelList"
			newObject={ EmpresaEndereco.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};