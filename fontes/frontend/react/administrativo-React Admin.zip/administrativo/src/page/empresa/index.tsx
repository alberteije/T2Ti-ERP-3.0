import EmpresaIcon from "@mui/icons-material/Apps";
import EmpresaList from "./EmpresaList";
import EmpresaCreate from "./EmpresaCreate";
import EmpresaEdit from "./EmpresaEdit";

export default {
	list: EmpresaList,
	create: EmpresaCreate,
	edit: EmpresaEdit,
	icon: EmpresaIcon,
};
