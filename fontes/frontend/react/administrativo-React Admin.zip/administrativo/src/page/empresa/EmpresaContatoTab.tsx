/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class EmpresaContato {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaContato {
		const empresaContato = new EmpresaContato();
		empresaContato.id = Date.now();
		empresaContato.statusCrud = "C";
		return empresaContato;
	}
}

export const EmpresaContatoTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaContato,
		setCurrentRecord: (record: EmpresaContato) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'email', label: 'Email' },
		{ source: 'observacao', label: 'Observação' },
	];

	return (
		<CrudChildTab
			title="Contatos"
			recordContext="empresa"
			fieldSource="empresaContatoModelList"
			newObject={ EmpresaContato.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};