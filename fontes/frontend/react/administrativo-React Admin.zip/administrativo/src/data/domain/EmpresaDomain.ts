class EmpresaDomain {
	static getTipoRegime(tipoRegime: string) { 
		switch (tipoRegime) { 
			case '': 
			case '1': 
				return '1-Lucro Real'; 
			case '2': 
				return '2-Lucro Presumido'; 
			case '3': 
				return '3-Simples Nacional'; 
			default: 
				return null; 
		} 
	} 

	static setTipoRegime(tipoRegime: string) { 
		switch (tipoRegime) { 
			case '1-Lucro Real': 
				return '1'; 
			case '2-Lucro Presumido': 
				return '2'; 
			case '3-Simples Nacional': 
				return '3'; 
			default: 
				return null; 
		} 
	}

	static getCrt(crt: string) { 
		switch (crt) { 
			case '': 
			case '1': 
				return '1-Simples Nacional'; 
			case '2': 
				return '2-Simples Nacional - excesso de sublimite da receita bruta'; 
			case '3': 
				return '3-Regime Normal '; 
			default: 
				return null; 
		} 
	} 

	static setCrt(crt: string) { 
		switch (crt) { 
			case '1-Simples Nacional': 
				return '1'; 
			case '2-Simples Nacional - excesso de sublimite da receita bruta': 
				return '2'; 
			case '3-Regime Normal ': 
				return '3'; 
			default: 
				return null; 
		} 
	}

	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'M': 
				return 'Matriz'; 
			case 'F': 
				return 'Filial'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Matriz': 
				return 'M'; 
			case 'Filial': 
				return 'F'; 
			default: 
				return null; 
		} 
	}

}

export default EmpresaDomain;