import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import papel from '../page/papel';
import empresa from '../page/empresa';
import auditoria from '../page/auditoria';
import funcao from '../page/funcao';
import usuario from '../page/usuario';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/auditoria'
					state={{ _scrollToTop: true }}
					primaryText='Auditoria'
					leftIcon={<auditoria.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/funcao'
					state={{ _scrollToTop: true }}
					primaryText='Função'
					leftIcon={<funcao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/usuario'
					state={{ _scrollToTop: true }}
					primaryText='Usuário'
					leftIcon={<usuario.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/papel'
					state={{ _scrollToTop: true }}
					primaryText='Papel'
					leftIcon={<papel.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/empresa'
					state={{ _scrollToTop: true }}
					primaryText='Empresa'
					leftIcon={<empresa.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
