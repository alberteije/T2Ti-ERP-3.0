/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import BpeCompradorDomain from '../../data/domain/BpeCompradorDomain';

class BpeComprador {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpeComprador {
		const bpeComprador = new BpeComprador();
		bpeComprador.id = Date.now();
		bpeComprador.statusCrud = "C";
		return bpeComprador;
	}
}

export const BpeCompradorTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpeComprador,
		setCurrentRecord: (record: BpeComprador) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: BpeCompradorDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Bpe Comprador"
			recordContext="bpeCabecalho"
			fieldSource="bpeCompradorModelList"
			newObject={ BpeComprador.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};