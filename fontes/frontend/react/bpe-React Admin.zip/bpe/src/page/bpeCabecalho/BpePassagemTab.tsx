/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class BpePassagem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpePassagem {
		const bpePassagem = new BpePassagem();
		bpePassagem.id = Date.now();
		bpePassagem.statusCrud = "C";
		return bpePassagem;
	}
}

export const BpePassagemTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpePassagem,
		setCurrentRecord: (record: BpePassagem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'codigoLocalidadeOrigem', label: 'Codigo Localidade Origem' },
		{ source: 'descricaoLocalidadeOrigem', label: 'Descricao Localidade Origem' },
		{ source: 'codigoLocalidadeDestino', label: 'Codigo Localidade Destino' },
		{ source: 'descricaoLocalidadeDestino', label: 'Descricao Localidade Destino' },
		{ source: 'dataHoraEmbarque', label: 'Data Hora Embarque' },
		{ source: 'dataHoraValidade', label: 'Data Hora Validade' },
	];

	return (
		<CrudChildTab
			title="Bpe Passagem"
			recordContext="bpeCabecalho"
			fieldSource="bpePassagemModelList"
			newObject={ BpePassagem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};