import BpeCabecalhoIcon from "@mui/icons-material/Apps";
import BpeCabecalhoList from "./BpeCabecalhoList";
import BpeCabecalhoCreate from "./BpeCabecalhoCreate";
import BpeCabecalhoEdit from "./BpeCabecalhoEdit";

export default {
	list: BpeCabecalhoList,
	create: BpeCabecalhoCreate,
	edit: BpeCabecalhoEdit,
	icon: BpeCabecalhoIcon,
};
