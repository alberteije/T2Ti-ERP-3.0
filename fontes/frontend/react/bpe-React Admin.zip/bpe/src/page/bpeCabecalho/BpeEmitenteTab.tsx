/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import BpeEmitenteDomain from '../../data/domain/BpeEmitenteDomain';

class BpeEmitente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpeEmitente {
		const bpeEmitente = new BpeEmitente();
		bpeEmitente.id = Date.now();
		bpeEmitente.statusCrud = "C";
		return bpeEmitente;
	}
}

export const BpeEmitenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpeEmitente,
		setCurrentRecord: (record: BpeEmitente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'iest', label: 'Iest' },
		{ source: 'im', label: 'Im' },
		{ source: 'cnae', label: 'Cnae' },
		{ source: 'crt', label: 'Crt' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: BpeEmitenteDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'telefone', label: 'Telefone' },
	];

	return (
		<CrudChildTab
			title="Bpe Emitente"
			recordContext="bpeCabecalho"
			fieldSource="bpeEmitenteModelList"
			newObject={ BpeEmitente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};