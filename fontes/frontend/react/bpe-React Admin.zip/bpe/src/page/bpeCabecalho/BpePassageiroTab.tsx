/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import BpePassageiroDomain from '../../data/domain/BpePassageiroDomain';

class BpePassageiro {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpePassageiro {
		const bpePassageiro = new BpePassageiro();
		bpePassageiro.id = Date.now();
		bpePassageiro.statusCrud = "C";
		return bpePassageiro;
	}
}

export const BpePassageiroTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpePassageiro,
		setCurrentRecord: (record: BpePassageiro) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'tipoDocumentoIdentificacao', label: 'Tipo Documento Identificacao', formatDomain: BpePassageiroDomain.getTipoDocumentoIdentificacao },
		{ source: 'numeroDocumento', label: 'Numero Documento' },
		{ source: 'documentoOutrosDescricao', label: 'Documento Outros Descricao' },
		{ source: 'dataNascimento', label: 'Data Nascimento' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Bpe Passageiro"
			recordContext="bpeCabecalho"
			fieldSource="bpePassageiroModelList"
			newObject={ BpePassageiro.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};