/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { BpeCabecalhoForm } from "./BpeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const BpeCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<BpeCabecalhoForm />
		</Edit>
	);
};

export default BpeCabecalhoEdit;