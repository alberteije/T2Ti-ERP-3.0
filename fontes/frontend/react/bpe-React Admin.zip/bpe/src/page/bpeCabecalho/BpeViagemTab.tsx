/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import BpeViagemDomain from '../../data/domain/BpeViagemDomain';

class BpeViagem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpeViagem {
		const bpeViagem = new BpeViagem();
		bpeViagem.id = Date.now();
		bpeViagem.statusCrud = "C";
		return bpeViagem;
	}
}

export const BpeViagemTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpeViagem,
		setCurrentRecord: (record: BpeViagem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'codigoPercurso', label: 'Codigo Percurso' },
		{ source: 'descricaoPercurso', label: 'Descricao Percurso' },
		{ source: 'tipoViagem', label: 'Tipo Viagem', formatDomain: BpeViagemDomain.getTipoViagem },
		{ source: 'tipoServico', label: 'Tipo Servico', formatDomain: BpeViagemDomain.getTipoServico },
		{ source: 'tipoAcomodacao', label: 'Tipo Acomodacao', formatDomain: BpeViagemDomain.getTipoAcomodacao },
		{ source: 'tipoTrecho', label: 'Tipo Trecho', formatDomain: BpeViagemDomain.getTipoTrecho },
		{ source: 'dataHoraViagem', label: 'Data Hora Viagem' },
		{ source: 'dataHoraConexao', label: 'Data Hora Conexao' },
		{ source: 'prefixoLinha', label: 'Prefixo Linha' },
		{ source: 'poltrona', label: 'Poltrona', formatDomain: BpeViagemDomain.getPoltrona },
		{ source: 'plataforma', label: 'Plataforma' },
	];

	return (
		<CrudChildTab
			title="Bpe Viagem"
			recordContext="bpeCabecalho"
			fieldSource="bpeViagemModelList"
			newObject={ BpeViagem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};