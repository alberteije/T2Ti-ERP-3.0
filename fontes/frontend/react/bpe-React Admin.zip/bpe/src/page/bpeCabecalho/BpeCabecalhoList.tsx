/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import BpeCabecalhoDomain from '../../data/domain/BpeCabecalhoDomain';

const BpeCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["ufEmitente","ambiente","modelo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? BpeCabecalhoSmallScreenList : BpeCabecalhoBigScreenList;

	return (
		<List
			title="Bpe Cabecalho"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const BpeCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.ufEmitente }
			secondaryText={ (record) => record.ambiente }
			tertiaryText={ (record) => record.modelo }
		/>
	);
}

const BpeCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="ufEmitente" label="Uf Emitente" />
			<FunctionField
				label="Ambiente"
				render={record => BpeCabecalhoDomain.getAmbiente(record.ambiente)}
			/>
			<FunctionField
				label="Modelo"
				render={record => BpeCabecalhoDomain.getModelo(record.modelo)}
			/>
			<FunctionField
				label="Serie"
				render={record => BpeCabecalhoDomain.getSerie(record.serie)}
			/>
			<TextField source="numero" label="Numero" />
			<TextField source="codigoNumerico" label="Codigo Numerico" />
			<TextField source="chaveAcesso" label="Chave Acesso" />
			<FunctionField
				label="Digito Chave Acesso"
				render={record => BpeCabecalhoDomain.getDigitoChaveAcesso(record.digitoChaveAcesso)}
			/>
			<FunctionField
				label="Modal"
				render={record => BpeCabecalhoDomain.getModal(record.modal)}
			/>
			<TextField source="dataHoraEmissao" label="Data Hora Emissao" />
			<FunctionField
				label="Tipo Emissao"
				render={record => BpeCabecalhoDomain.getTipoEmissao(record.tipoEmissao)}
			/>
			<TextField source="versaoProcessoEmissao" label="Versao Processo Emissao" />
			<FunctionField
				label="Tipo Bpe"
				render={record => BpeCabecalhoDomain.getTipoBpe(record.tipoBpe)}
			/>
			<FunctionField
				label="Consumidor Presenca"
				render={record => BpeCabecalhoDomain.getConsumidorPresenca(record.consumidorPresenca)}
			/>
			<FunctionField
				label="Uf Inicio Viagem"
				render={record => BpeCabecalhoDomain.getUfInicioViagem(record.ufInicioViagem)}
			/>
			<TextField source="codigoMunicipioInicioViagem" label="Codigo Municipio Inicio Viagem" />
			<FunctionField
				label="Uf Fim Viagem"
				render={record => BpeCabecalhoDomain.getUfFimViagem(record.ufFimViagem)}
			/>
			<TextField source="codigoMunicipioFimViagem" label="Codigo Municipio Fim Viagem" />
			<NumberField source="valorBilhete" label="Valor Bilhete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPago" label="Valor Pago" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTroco" label="Valor Troco" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Tipo Desconto"
				render={record => BpeCabecalhoDomain.getTipoDesconto(record.tipoDesconto)}
			/>
			<TextField source="descontoDescricao" label="Desconto Descricao" />
			<TextField source="descontoConcedidoOutros" label="Desconto Concedido Outros" />
			<FunctionField
				label="Forma Pagamento"
				render={record => BpeCabecalhoDomain.getFormaPagamento(record.formaPagamento)}
			/>
			<TextField source="formaPagamentoOutros" label="Forma Pagamento Outros" />
			<TextField source="formaPagamentoDocumento" label="Forma Pagamento Documento" />
			<FunctionField
				label="Cst"
				render={record => BpeCabecalhoDomain.getCst(record.cst)}
			/>
			<NumberField source="baseCalculoIcms" label="Base Calculo Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaIcms" label="Aliquota Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcms" label="Valor Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualReducaoBcIcms" label="Percentual Reducao Bc Icms" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="informacoesAddFisco" label="Informacoes Add Fisco" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default BpeCabecalhoList;
