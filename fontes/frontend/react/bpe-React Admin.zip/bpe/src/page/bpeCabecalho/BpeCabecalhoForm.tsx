/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { BpeEmitenteTab } from './BpeEmitenteTab';
import { BpePassageiroTab } from './BpePassageiroTab';
import { BpeCompradorTab } from './BpeCompradorTab';
import { BpeViagemTab } from './BpeViagemTab';
import { BpeAgenciaTab } from './BpeAgenciaTab';
import { BpePassagemTab } from './BpePassagemTab';

export const BpeCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Bpe Cabecalho">
				<BpeCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Emitente">
				<BpeEmitenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Passageiro">
				<BpePassageiroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Comprador">
				<BpeCompradorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Viagem">
				<BpeViagemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Agencia">
				<BpeAgenciaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Bpe Passagem">
				<BpePassagemTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const BpeCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};