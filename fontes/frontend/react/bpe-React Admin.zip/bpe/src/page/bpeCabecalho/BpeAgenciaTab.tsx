/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import BpeAgenciaDomain from '../../data/domain/BpeAgenciaDomain';

class BpeAgencia {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): BpeAgencia {
		const bpeAgencia = new BpeAgencia();
		bpeAgencia.id = Date.now();
		bpeAgencia.statusCrud = "C";
		return bpeAgencia;
	}
}

export const BpeAgenciaTab: React.FC = () => {

	const renderForm = (
		currentRecord: BpeAgencia,
		setCurrentRecord: (record: BpeAgencia) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idBpeCabecalho', label: 'Id Bpe Cabecalho' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: BpeAgenciaDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Bpe Agencia"
			recordContext="bpeCabecalho"
			fieldSource="bpeAgenciaModelList"
			newObject={ BpeAgencia.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};