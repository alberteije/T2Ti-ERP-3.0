/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { BpeCabecalhoForm } from "./BpeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const BpeCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<BpeCabecalhoForm />
		</Create>
	);
};

export default BpeCabecalhoCreate;