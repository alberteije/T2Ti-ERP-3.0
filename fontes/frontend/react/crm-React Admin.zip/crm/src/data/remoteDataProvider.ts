/* eslint-disable @typescript-eslint/no-explicit-any */
import { fetchUtils } from 'react-admin';
import { handleFilter, FilterModel } from '../infra/filter';


// ========================================================================
// To create your own Provider:
// https://marmelab.com/react-admin/DataProviderWriting.html
// ========================================================================

const apiUrl = import.meta.env.VITE_VYCANIS_SERVER;
const httpClient = fetchUtils.fetchJson;

let cachedData: any = null; // Variable to store previously loaded data
let lastSort = {}; // Last applied sorting
let lastResource: any = null; // Last resource

interface Filter {
	q?: string; // passed by react-admin
	[field: string]: any; // used when working with lookups - ReferenceInput
}
let lastFilter: Filter = {};

const applySort = (data: any, sort: any) => {
	const { field, order } = sort;

	// Helper function to access nested properties
	const getNestedField = (obj: any, fieldPath: string) => {
		return fieldPath.split('.').reduce((value, key) => {
			return value ? value[key] : null;
		}, obj);
	};

	// Sorts the data locally based on the field (including nested) and order (ASC or DESC)
	return data.sort((a: any, b: any) => {
		const valueA = getNestedField(a, field);
		const valueB = getNestedField(b, field);

		if (valueA < valueB) {
			return order === 'ASC' ? -1 : 1;
		}
		if (valueA > valueB) {
			return order === 'ASC' ? 1 : -1;
		}
		return 0;
	});
};

export const dataProvider = {

	// get a list of records based on sort, filter, and pagination
	// In our case, it performs filtering on the server, but sorting and pagination are done on the client
	getList: async (resource: any, params: any) => {
		if (resource !== lastResource) {
			cachedData = null; // Limpa o cache ao mudar de recurso
		}
		lastResource = resource;

		const isFilterChanged = JSON.stringify(params.filter) !== JSON.stringify(lastFilter);
		const isSortChanged = JSON.stringify(params.sort) !== JSON.stringify(lastSort);
		const shouldFetchFromServer = !cachedData || isFilterChanged || isSortChanged;

		if (shouldFetchFromServer) {
			lastFilter = { ...params.filter };
			lastSort = { ...params.sort };

			const filterModel = new FilterModel();

			if (params.filter?.q && params.sort?.field) {
				filterModel.field = lastFilter.field ? lastFilter.field : params.sort?.field;
				filterModel.value = params.filter?.q;
				filterModel.condition = 'cont';
			}

			const filterUrl = handleFilter(filterModel);
			const url = `${apiUrl}/${resource}/${filterUrl}`;

			const { json, body } = await httpClient(url, { signal: params.signal });

			// Stores data in the cache
			cachedData = typeof json === "object" ? json : JSON.parse(body || "{}");

			// Applying sorting locally (on the client)
			cachedData = applySort(cachedData, params.sort);
		}

		// Performing pagination on the client side
		const { page, perPage } = params.pagination;
		const paginatedData = cachedData.slice((page - 1) * perPage, page * perPage);

		return {
			data: paginatedData,
			total: cachedData.length,
		};
	},

	// get a single record by id
	// Used to load item data on the detail screen
	getOne: async (resource: any, params: any) => {
		const url = `${apiUrl}/${resource}/${params.id}`
		const { json } = await httpClient(url);
		return { data: json };
	},

	// get a list of records based on an array of ids
	// Not used in this project
	getMany: async (resource: any, params: any) => {
		const filterUrl = handleFilter(params);
		const url = `${apiUrl}/${resource}/${filterUrl}`;
		const { json } = await httpClient(url);
		return { data: json };
	},

	// get the records referenced to another record, e.g. comments for a post
	// Not used in this project
	getManyReference: async (resource: any, params: any) => {
		const filterUrl = handleFilter(params);
		const url = `${apiUrl}/${resource}/${filterUrl}`;
		const { json, headers } = await httpClient(url);
		return {
			data: json,
			total: parseInt(headers.get('content-range')?.split('/')?.pop() || '0', 10),
		};
	},

	// create a record
	create: async (resource: any, params: any) => {
		const { json } = await httpClient(`${apiUrl}/${resource}`, {
			method: 'POST',
			body: JSON.stringify(params.data),
		});

		if (cachedData) {
			cachedData = [...cachedData, json];
		} else {
			cachedData = [json];
		}

		return { data: json };
	},

	// update a record based on a patch
	update: async (resource: any, params: any) => {
		const url = `${apiUrl}/${resource}`;
		const { json } = await httpClient(url, {
			method: 'PUT',
			body: JSON.stringify(params.data),
		});

		if (cachedData) {
			const updatedData = cachedData.map((item: any) =>
				item.id === json.id ? { ...item, ...json } : item
			);
			cachedData = updatedData;
		}

		return { data: json };
	},

	// update a list of records based on an array of ids and a common patch
	// Not used in this project
	updateMany: async (resource: any, params: any) => {
		const query = {
			filter: JSON.stringify({ id: params.filter }),
		};
		const url = `${apiUrl}/${resource}?${query}`;
		const { json } = await httpClient(url, {
			method: 'PUT',
			body: JSON.stringify(params.filter),
		});
		return { data: json };
	},

	// delete a record by id
	delete: async (resource: any, params: any) => {
		const url = `${apiUrl}/${resource}/${params.id}`;
		const { json } = await httpClient(url, {
			method: 'DELETE',
		});
		if (cachedData) {
			cachedData = cachedData.filter((item: any) => item.id !== params.id);
		}
		return { data: json };
	},

	// delete a list of records based on an array of ids
	// Not used in this project
	deleteMany: async (resource: any, params: any) => {
		const url = `${apiUrl}/${resource}/${params.id}`;
		const { json } = await httpClient(url, {
			method: 'DELETE',
		});
		return { data: json };
	},
};
