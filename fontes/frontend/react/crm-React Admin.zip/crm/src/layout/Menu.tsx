import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import crmSacCabecalho from '../page/crmSacCabecalho';
import crmBuscasCliente from '../page/crmBuscasCliente';
import crmCarteiraClientePerfil from '../page/crmCarteiraClientePerfil';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/crm-buscas-cliente'
					state={{ _scrollToTop: true }}
					primaryText='Crm Buscas Cliente'
					leftIcon={<crmBuscasCliente.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/crm-carteira-cliente-perfil'
					state={{ _scrollToTop: true }}
					primaryText='Crm Carteira Cliente Perfil'
					leftIcon={<crmCarteiraClientePerfil.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/crm-sac-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Crm Sac Cabecalho'
					leftIcon={<crmSacCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
