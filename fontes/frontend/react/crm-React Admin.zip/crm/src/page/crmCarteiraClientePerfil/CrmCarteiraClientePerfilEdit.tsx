import {
	Edit,
} from "react-admin";
import { CrmCarteiraClientePerfilForm } from "./CrmCarteiraClientePerfilForm";

const CrmCarteiraClientePerfilEdit = () => {
	return (
		<Edit>
			<CrmCarteiraClientePerfilForm />
		</Edit>
	);
};

export default CrmCarteiraClientePerfilEdit;