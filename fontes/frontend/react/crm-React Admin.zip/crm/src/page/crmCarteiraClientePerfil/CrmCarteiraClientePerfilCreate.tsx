import {
	Create,
} from "react-admin";
import { CrmCarteiraClientePerfilForm } from "./CrmCarteiraClientePerfilForm";

const CrmCarteiraClientePerfilCreate = () => {
	return (
		<Create>
			<CrmCarteiraClientePerfilForm />
		</Create>
	);
};

export default CrmCarteiraClientePerfilCreate;