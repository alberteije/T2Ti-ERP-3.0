import CrmCarteiraClientePerfilIcon from "@mui/icons-material/Apps";
import CrmCarteiraClientePerfilList from "./CrmCarteiraClientePerfilList";
import CrmCarteiraClientePerfilCreate from "./CrmCarteiraClientePerfilCreate";
import CrmCarteiraClientePerfilEdit from "./CrmCarteiraClientePerfilEdit";

export default {
	list: CrmCarteiraClientePerfilList,
	create: CrmCarteiraClientePerfilCreate,
	edit: CrmCarteiraClientePerfilEdit,
	icon: CrmCarteiraClientePerfilIcon,
};
