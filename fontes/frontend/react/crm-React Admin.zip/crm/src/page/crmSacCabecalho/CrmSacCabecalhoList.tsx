/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import CrmSacCabecalhoDomain from '../../data/domain/CrmSacCabecalhoDomain';

const CrmSacCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaClienteModel.nome","dataAbertura","horaAbertura"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CrmSacCabecalhoSmallScreenList : CrmSacCabecalhoBigScreenList;

	return (
		<List
			title="Crm Sac Cabecalho"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CrmSacCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaClienteModel.nome }
			secondaryText={ (record) => record.dataAbertura }
			tertiaryText={ (record) => record.horaAbertura }
		/>
	);
}

const CrmSacCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataAbertura" label="Data Abertura" />
			<FunctionField
				source="horaAbertura"
				label="Hora Abertura"
				render={record => formatWithMask(record.horaAbertura, '##:##:##')}
			/>
			<FunctionField
				label="Nivel Reclamacao"
				render={record => CrmSacCabecalhoDomain.getNivelReclamacao(record.nivelReclamacao)}
			/>
			<TextField source="numeroProtocolo" label="Numero Protocolo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CrmSacCabecalhoList;
