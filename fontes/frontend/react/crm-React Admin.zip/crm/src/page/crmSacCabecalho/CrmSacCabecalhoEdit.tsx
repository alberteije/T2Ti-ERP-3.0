/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CrmSacCabecalhoForm } from "./CrmSacCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const CrmSacCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CrmSacCabecalhoForm />
		</Edit>
	);
};

export default CrmSacCabecalhoEdit;