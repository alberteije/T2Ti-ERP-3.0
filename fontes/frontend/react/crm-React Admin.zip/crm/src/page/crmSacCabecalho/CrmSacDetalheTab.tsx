/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CrmSacDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CrmSacDetalhe {
		const crmSacDetalhe = new CrmSacDetalhe();
		crmSacDetalhe.id = Date.now();
		crmSacDetalhe.statusCrud = "C";
		return crmSacDetalhe;
	}
}

export const CrmSacDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: CrmSacDetalhe,
		setCurrentRecord: (record: CrmSacDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataRegistro', label: 'Data Registro' },
		{ source: 'horaRegistro', label: 'Hora Registro', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'historico', label: 'Historico' },
	];

	return (
		<CrudChildTab
			title="Crm Sac Detalhe"
			recordContext="crmSacCabecalho"
			fieldSource="crmSacDetalheModelList"
			newObject={ CrmSacDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};