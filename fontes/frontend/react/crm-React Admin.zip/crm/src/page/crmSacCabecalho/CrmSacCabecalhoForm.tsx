/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { CrmSacDetalheTab } from './CrmSacDetalheTab';

export const CrmSacCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Crm Sac Cabecalho">
				<CrmSacCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Crm Sac Detalhe">
				<CrmSacDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CrmSacCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};