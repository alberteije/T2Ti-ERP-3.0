import CrmSacCabecalhoIcon from "@mui/icons-material/Apps";
import CrmSacCabecalhoList from "./CrmSacCabecalhoList";
import CrmSacCabecalhoCreate from "./CrmSacCabecalhoCreate";
import CrmSacCabecalhoEdit from "./CrmSacCabecalhoEdit";

export default {
	list: CrmSacCabecalhoList,
	create: CrmSacCabecalhoCreate,
	edit: CrmSacCabecalhoEdit,
	icon: CrmSacCabecalhoIcon,
};
