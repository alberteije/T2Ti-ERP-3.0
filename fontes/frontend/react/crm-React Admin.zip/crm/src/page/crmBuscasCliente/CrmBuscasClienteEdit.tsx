import {
	Edit,
} from "react-admin";
import { CrmBuscasClienteForm } from "./CrmBuscasClienteForm";

const CrmBuscasClienteEdit = () => {
	return (
		<Edit>
			<CrmBuscasClienteForm />
		</Edit>
	);
};

export default CrmBuscasClienteEdit;