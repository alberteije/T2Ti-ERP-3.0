import CrmBuscasClienteIcon from "@mui/icons-material/Apps";
import CrmBuscasClienteList from "./CrmBuscasClienteList";
import CrmBuscasClienteCreate from "./CrmBuscasClienteCreate";
import CrmBuscasClienteEdit from "./CrmBuscasClienteEdit";

export default {
	list: CrmBuscasClienteList,
	create: CrmBuscasClienteCreate,
	edit: CrmBuscasClienteEdit,
	icon: CrmBuscasClienteIcon,
};
