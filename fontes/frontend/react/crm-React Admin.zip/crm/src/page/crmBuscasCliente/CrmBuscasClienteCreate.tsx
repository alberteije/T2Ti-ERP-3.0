import {
	Create,
} from "react-admin";
import { CrmBuscasClienteForm } from "./CrmBuscasClienteForm";

const CrmBuscasClienteCreate = () => {
	return (
		<Create>
			<CrmBuscasClienteForm />
		</Create>
	);
};

export default CrmBuscasClienteCreate;