/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const CrmBuscasClienteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaClienteModel.nome","dataBusca","horaBusca"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CrmBuscasClienteSmallScreenList : CrmBuscasClienteBigScreenList;

	return (
		<List
			title="Crm Buscas Cliente"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CrmBuscasClienteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaClienteModel.nome }
			secondaryText={ (record) => record.dataBusca }
			tertiaryText={ (record) => record.horaBusca }
		/>
	);
}

const CrmBuscasClienteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataBusca" label="Data Busca" />
			<FunctionField
				source="horaBusca"
				label="Hora Busca"
				render={record => formatWithMask(record.horaBusca, '##:##:##')}
			/>
			<TextField source="detalhes" label="Detalhes" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CrmBuscasClienteList;
