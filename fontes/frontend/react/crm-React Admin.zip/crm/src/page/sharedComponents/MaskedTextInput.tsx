/* eslint-disable @typescript-eslint/no-explicit-any */
import { TextInput } from 'react-admin';
import MaskedInput from 'react-text-mask';

// Function to convert a mask string into an array of strings/RegExp
const createMask = (maskPattern: string): (string | RegExp)[] => {
	return maskPattern.split('').map((char) => {
		if (char === '#') return /\d/; // Replaces '#' with a digit (RegExp)
		return char; // Keeps other literal characters
	});
};

// Generic parse function (removes non-alphanumeric characters by default)
const defaultParse = (value: string) => {
	if (!value) return value;
	return value.replace(/\D/g, ''); // Removes all non-numeric characters
};

// Wrapper to encapsulate the MaskedInput with the desired mask
const MaskedInputWrapper = (mask: string) => {
	const WrapperComponent = (props: any) => (
		<MaskedInput
			{...props}
			mask={createMask(mask)} // Converts the mask string to the correct format
			placeholderChar={'\u2000'}
			showMask
			ref={props.inputRef}
		/>
	);
	return WrapperComponent;
};

// Generic masked input component
export const MaskedTextInput = ({
	mask,
	parse = defaultParse, // Default parsing if none is provided
	source,
	onBlur, // onBlur handler added
	...props
}: {
	mask: string; // Mask as a string (e.g., "(##)#####-####")
	parse?: (value: string) => string; // Optional parsing function
	source: string;
	onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void; // Optional onBlur handler
	[key: string]: any; // Allows additional props
}) => {
	// Handle the onBlur event to apply any custom logic on blur
	const handleBlur = (event: React.FocusEvent<HTMLInputElement>) => {
		const parsedValue = parse(event.target.value);
		if (onBlur) {
			onBlur({
				...event,
				target: {
					...event.target,
					value: parsedValue,
				},
			});
		}
	};

	return (
		<TextInput
			{...props}
			source={source}
			onBlur={handleBlur} // Handles the blur event
			parse={parse}
			slotProps={{
				input: { inputComponent: MaskedInputWrapper(mask) }, // Passes the wrapper component with the mask
				inputLabel: { shrink: true },
			}}
		/>
	);
};
