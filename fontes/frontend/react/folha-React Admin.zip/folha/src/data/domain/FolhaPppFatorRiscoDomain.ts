class FolhaPppFatorRiscoDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'F': 
				return 'F=Físico'; 
			case 'Q': 
				return 'Q=Químico'; 
			case 'B': 
				return 'B=Biológico'; 
			case 'E': 
				return 'E=Ergonômico/Psicossocial'; 
			case 'M': 
				return 'M=Mecânico/de Acidente'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'F=Físico': 
				return 'F'; 
			case 'Q=Químico': 
				return 'Q'; 
			case 'B=Biológico': 
				return 'B'; 
			case 'E=Ergonômico/Psicossocial': 
				return 'E'; 
			case 'M=Mecânico/de Acidente': 
				return 'M'; 
			default: 
				return null; 
		} 
	}

	static getEpcEficaz(epcEficaz: string) { 
		switch (epcEficaz) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEpcEficaz(epcEficaz: string) { 
		switch (epcEficaz) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEpiEficaz(epiEficaz: string) { 
		switch (epiEficaz) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEpiEficaz(epiEficaz: string) { 
		switch (epiEficaz) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAtendimentoNr061(atendimentoNr061: string) { 
		switch (atendimentoNr061) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAtendimentoNr061(atendimentoNr061: string) { 
		switch (atendimentoNr061) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAtendimentoNr062(atendimentoNr062: string) { 
		switch (atendimentoNr062) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAtendimentoNr062(atendimentoNr062: string) { 
		switch (atendimentoNr062) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAtendimentoNr063(atendimentoNr063: string) { 
		switch (atendimentoNr063) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAtendimentoNr063(atendimentoNr063: string) { 
		switch (atendimentoNr063) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAtendimentoNr064(atendimentoNr064: string) { 
		switch (atendimentoNr064) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAtendimentoNr064(atendimentoNr064: string) { 
		switch (atendimentoNr064) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAtendimentoNr065(atendimentoNr065: string) { 
		switch (atendimentoNr065) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setAtendimentoNr065(atendimentoNr065: string) { 
		switch (atendimentoNr065) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FolhaPppFatorRiscoDomain;