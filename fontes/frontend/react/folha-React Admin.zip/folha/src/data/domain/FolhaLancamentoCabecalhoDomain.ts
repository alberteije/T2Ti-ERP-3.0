class FolhaLancamentoCabecalhoDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case '0': 
				return 'Folha Mensal'; 
			case '1': 
				return 'Rescisão'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Folha Mensal': 
				return '0'; 
			case 'Rescisão': 
				return '1'; 
			default: 
				return null; 
		} 
	}

}

export default FolhaLancamentoCabecalhoDomain;