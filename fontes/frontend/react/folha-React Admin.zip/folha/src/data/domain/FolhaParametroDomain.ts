class FolhaParametroDomain {
	static getContribuiPis(contribuiPis: string) { 
		switch (contribuiPis) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setContribuiPis(contribuiPis: string) { 
		switch (contribuiPis) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getDiscriminarDsr(discriminarDsr: string) { 
		switch (discriminarDsr) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setDiscriminarDsr(discriminarDsr: string) { 
		switch (discriminarDsr) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getCalculoProporcionalidade(calculoProporcionalidade: string) { 
		switch (calculoProporcionalidade) { 
			case '': 
			case '0': 
				return '30 Dias'; 
			case '1': 
				return 'Conforme dias do mês'; 
			default: 
				return null; 
		} 
	} 

	static setCalculoProporcionalidade(calculoProporcionalidade: string) { 
		switch (calculoProporcionalidade) { 
			case '30 Dias': 
				return '0'; 
			case 'Conforme dias do mês': 
				return '1'; 
			default: 
				return null; 
		} 
	}

	static getDescontarFaltas13(descontarFaltas13: string) { 
		switch (descontarFaltas13) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setDescontarFaltas13(descontarFaltas13: string) { 
		switch (descontarFaltas13) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPagarAdicionais13(pagarAdicionais13: string) { 
		switch (pagarAdicionais13) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPagarAdicionais13(pagarAdicionais13: string) { 
		switch (pagarAdicionais13) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPagarEstagiarios13(pagarEstagiarios13: string) { 
		switch (pagarEstagiarios13) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPagarEstagiarios13(pagarEstagiarios13: string) { 
		switch (pagarEstagiarios13) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasDescontarFaltas(feriasDescontarFaltas: string) { 
		switch (feriasDescontarFaltas) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasDescontarFaltas(feriasDescontarFaltas: string) { 
		switch (feriasDescontarFaltas) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasPagarAdicionais(feriasPagarAdicionais: string) { 
		switch (feriasPagarAdicionais) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasPagarAdicionais(feriasPagarAdicionais: string) { 
		switch (feriasPagarAdicionais) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasAdiantar13(feriasAdiantar13: string) { 
		switch (feriasAdiantar13) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasAdiantar13(feriasAdiantar13: string) { 
		switch (feriasAdiantar13) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasPagarEstagiarios(feriasPagarEstagiarios: string) { 
		switch (feriasPagarEstagiarios) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasPagarEstagiarios(feriasPagarEstagiarios: string) { 
		switch (feriasPagarEstagiarios) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasCalcJustaCausa(feriasCalcJustaCausa: string) { 
		switch (feriasCalcJustaCausa) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasCalcJustaCausa(feriasCalcJustaCausa: string) { 
		switch (feriasCalcJustaCausa) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getFeriasMovimentoMensal(feriasMovimentoMensal: string) { 
		switch (feriasMovimentoMensal) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setFeriasMovimentoMensal(feriasMovimentoMensal: string) { 
		switch (feriasMovimentoMensal) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FolhaParametroDomain;