class FolhaRescisaoDomain {
	static getComprovouNovoEmprego(comprovouNovoEmprego: string) { 
		switch (comprovouNovoEmprego) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setComprovouNovoEmprego(comprovouNovoEmprego: string) { 
		switch (comprovouNovoEmprego) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getDispensouEmpregado(dispensouEmpregado: string) { 
		switch (dispensouEmpregado) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setDispensouEmpregado(dispensouEmpregado: string) { 
		switch (dispensouEmpregado) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FolhaRescisaoDomain;