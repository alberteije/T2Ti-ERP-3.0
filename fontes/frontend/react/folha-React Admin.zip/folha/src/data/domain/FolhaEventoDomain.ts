class FolhaEventoDomain {
	static getBaseCalculo(baseCalculo: string) { 
		switch (baseCalculo) { 
			case '': 
			case '0': 
				return '1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual'; 
			case '1': 
				return '2=Salário mínimo: define que a base de cálculo deve ser calculada sobre o valor do salário mínimo'; 
			case '2': 
				return '3=Piso Salarial: define que a base de cálculo deve ser calculada sobre o valor do piso salarial definido no cadastro de sindicatos'; 
			case '3': 
				return '4=Líquido: define que a base de cálculo deve ser calculada sobre o líquido da folha'; 
			default: 
				return null; 
		} 
	} 

	static setBaseCalculo(baseCalculo: string) { 
		switch (baseCalculo) { 
			case '1=Salário contratual: define que a base de cálculo deve ser calculada sobre o valor do salário contratual': 
				return '0'; 
			case '2=Salário mínimo: define que a base de cálculo deve ser calculada sobre o valor do salário mínimo': 
				return '1'; 
			case '3=Piso Salarial: define que a base de cálculo deve ser calculada sobre o valor do piso salarial definido no cadastro de sindicatos': 
				return '2'; 
			case '4=Líquido: define que a base de cálculo deve ser calculada sobre o líquido da folha': 
				return '3'; 
			default: 
				return null; 
		} 
	}

	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'P': 
				return 'Provento'; 
			case 'D': 
				return 'Desconto'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Provento': 
				return 'P'; 
			case 'Desconto': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

	static getUnidade(unidade: string) { 
		switch (unidade) { 
			case '': 
			case 'V': 
				return 'Valor'; 
			case 'P': 
				return 'Percentual'; 
			default: 
				return null; 
		} 
	} 

	static setUnidade(unidade: string) { 
		switch (unidade) { 
			case 'Valor': 
				return 'V'; 
			case 'Percentual': 
				return 'P'; 
			default: 
				return null; 
		} 
	}

	static getRepercuteDsr(repercuteDsr: string) { 
		switch (repercuteDsr) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setRepercuteDsr(repercuteDsr: string) { 
		switch (repercuteDsr) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getRepercute13(repercute13: string) { 
		switch (repercute13) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setRepercute13(repercute13: string) { 
		switch (repercute13) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getRepercuteFerias(repercuteFerias: string) { 
		switch (repercuteFerias) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setRepercuteFerias(repercuteFerias: string) { 
		switch (repercuteFerias) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getRepercuteAviso(repercuteAviso: string) { 
		switch (repercuteAviso) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setRepercuteAviso(repercuteAviso: string) { 
		switch (repercuteAviso) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default FolhaEventoDomain;