import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import empresaTransporte from './page/empresaTransporte';
import folhaLancamentoCabecalho from './page/folhaLancamentoCabecalho';
import folhaInss from './page/folhaInss';
import folhaPpp from './page/folhaPpp';
import operadoraPlanoSaude from './page/operadoraPlanoSaude';
import folhaLancamentoComissao from './page/folhaLancamentoComissao';
import folhaParametro from './page/folhaParametro';
import guiasAcumuladas from './page/guiasAcumuladas';
import folhaFechamento from './page/folhaFechamento';
import feriasPeriodoAquisitivo from './page/feriasPeriodoAquisitivo';
import folhaTipoAfastamento from './page/folhaTipoAfastamento';
import folhaAfastamento from './page/folhaAfastamento';
import folhaPlanoSaude from './page/folhaPlanoSaude';
import folhaEvento from './page/folhaEvento';
import folhaRescisao from './page/folhaRescisao';
import folhaFeriasColetivas from './page/folhaFeriasColetivas';
import folhaValeTransporte from './page/folhaValeTransporte';
import folhaInssServico from './page/folhaInssServico';
import folhaHistoricoSalarial from './page/folhaHistoricoSalarial';
import feriados from './page/feriados';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'folha');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Folha de Pagamento (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='empresa-transporte' {...empresaTransporte} options={{ label: 'Empresa de Transporte' }} />
			<Resource name='folha-lancamento-cabecalho' {...folhaLancamentoCabecalho} options={{ label: 'Lançamento' }} />
			<Resource name='folha-inss' {...folhaInss} options={{ label: 'INSS' }} />
			<Resource name='folha-ppp' {...folhaPpp} options={{ label: 'PPP' }} />
			<Resource name='operadora-plano-saude' {...operadoraPlanoSaude} options={{ label: 'Operadora Plano de Saúde' }} />
			<Resource name='folha-lancamento-comissao' {...folhaLancamentoComissao} options={{ label: 'Comissões' }} />
			<Resource name='folha-parametro' {...folhaParametro} options={{ label: 'Parâmetros' }} />
			<Resource name='guias-acumuladas' {...guiasAcumuladas} options={{ label: 'Guias Acumuladas' }} />
			<Resource name='folha-fechamento' {...folhaFechamento} options={{ label: 'Fechamento da Folha' }} />
			<Resource name='ferias-periodo-aquisitivo' {...feriasPeriodoAquisitivo} options={{ label: 'Períodos Aquisitivos' }} />
			<Resource name='folha-tipo-afastamento' {...folhaTipoAfastamento} options={{ label: 'Tipo de Afastamento' }} />
			<Resource name='folha-afastamento' {...folhaAfastamento} options={{ label: 'Afastamentos' }} />
			<Resource name='folha-plano-saude' {...folhaPlanoSaude} options={{ label: 'Plano de Saúde' }} />
			<Resource name='folha-evento' {...folhaEvento} options={{ label: 'Eventos' }} />
			<Resource name='folha-rescisao' {...folhaRescisao} options={{ label: 'Rescisão' }} />
			<Resource name='folha-ferias-coletivas' {...folhaFeriasColetivas} options={{ label: 'Férias Coletivas' }} />
			<Resource name='folha-vale-transporte' {...folhaValeTransporte} options={{ label: 'Vale Transporte' }} />
			<Resource name='folha-inss-servico' {...folhaInssServico} options={{ label: 'Serviços' }} />
			<Resource name='folha-historico-salarial' {...folhaHistoricoSalarial} options={{ label: 'Histórico Salarial' }} />
			<Resource name='feriados' {...feriados} options={{ label: 'Feriados' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;