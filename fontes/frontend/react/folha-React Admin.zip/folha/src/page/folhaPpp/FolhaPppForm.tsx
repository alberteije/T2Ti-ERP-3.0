/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FolhaPppCatTab } from './FolhaPppCatTab';
import { FolhaPppAtividadeTab } from './FolhaPppAtividadeTab';
import { FolhaPppFatorRiscoTab } from './FolhaPppFatorRiscoTab';
import { FolhaPppExameMedicoTab } from './FolhaPppExameMedicoTab';

export const FolhaPppForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="PPP">
				<FolhaPppTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="CAT">
				<FolhaPppCatTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Atividade">
				<FolhaPppAtividadeTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Fator de Risco">
				<FolhaPppFatorRiscoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Exame Médico">
				<FolhaPppExameMedicoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FolhaPppTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};