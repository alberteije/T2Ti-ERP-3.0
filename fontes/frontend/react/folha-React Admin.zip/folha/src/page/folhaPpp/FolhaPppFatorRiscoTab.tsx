/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FolhaPppFatorRiscoDomain from '../../data/domain/FolhaPppFatorRiscoDomain';

class FolhaPppFatorRisco {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaPppFatorRisco {
		const folhaPppFatorRisco = new FolhaPppFatorRisco();
		folhaPppFatorRisco.id = Date.now();
		folhaPppFatorRisco.statusCrud = "C";
		return folhaPppFatorRisco;
	}
}

export const FolhaPppFatorRiscoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaPppFatorRisco,
		setCurrentRecord: (record: FolhaPppFatorRisco) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataInicio', label: 'Data Inicio' },
		{ source: 'dataFim', label: 'Data Fim' },
		{ source: 'tipo', label: 'Tipo', formatDomain: FolhaPppFatorRiscoDomain.getTipo },
		{ source: 'fatorRisco', label: 'Fator Risco' },
		{ source: 'intensidade', label: 'Intensidade' },
		{ source: 'tecnicaUtilizada', label: 'Tecnica Utilizada' },
		{ source: 'epcEficaz', label: 'EPC Eficaz', formatDomain: FolhaPppFatorRiscoDomain.getEpcEficaz },
		{ source: 'epiEficaz', label: 'EPI Eficaz', formatDomain: FolhaPppFatorRiscoDomain.getEpiEficaz },
		{ source: 'caEpi', label: 'CA EPI' },
		{ source: 'atendimentoNr061', label: 'Atendimento Nr 06 1', formatDomain: FolhaPppFatorRiscoDomain.getAtendimentoNr061 },
		{ source: 'atendimentoNr062', label: 'Atendimento Nr 06 2', formatDomain: FolhaPppFatorRiscoDomain.getAtendimentoNr062 },
		{ source: 'atendimentoNr063', label: 'Atendimento Nr 06 3', formatDomain: FolhaPppFatorRiscoDomain.getAtendimentoNr063 },
		{ source: 'atendimentoNr064', label: 'Atendimento Nr 06 4', formatDomain: FolhaPppFatorRiscoDomain.getAtendimentoNr064 },
		{ source: 'atendimentoNr065', label: 'Atendimento Nr 06 5', formatDomain: FolhaPppFatorRiscoDomain.getAtendimentoNr065 },
	];

	return (
		<CrudChildTab
			title="Fator de Risco"
			recordContext="folhaPpp"
			fieldSource="folhaPppFatorRiscoModelList"
			newObject={ FolhaPppFatorRisco.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};