/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import FolhaPppExameMedicoDomain from '../../data/domain/FolhaPppExameMedicoDomain';

class FolhaPppExameMedico {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaPppExameMedico {
		const folhaPppExameMedico = new FolhaPppExameMedico();
		folhaPppExameMedico.id = Date.now();
		folhaPppExameMedico.statusCrud = "C";
		return folhaPppExameMedico;
	}
}

export const FolhaPppExameMedicoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaPppExameMedico,
		setCurrentRecord: (record: FolhaPppExameMedico) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataUltimo', label: 'Data Ultimo' },
		{ source: 'tipo', label: 'Tipo', formatDomain: FolhaPppExameMedicoDomain.getTipo },
		{ source: 'exame', label: 'Exame', formatDomain: FolhaPppExameMedicoDomain.getExame },
		{ source: 'natureza', label: 'Natureza' },
		{ source: 'indicacaoResultados', label: 'Indicacao Resultados' },
	];

	return (
		<CrudChildTab
			title="Exame Médico"
			recordContext="folhaPpp"
			fieldSource="folhaPppExameMedicoModelList"
			newObject={ FolhaPppExameMedico.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};