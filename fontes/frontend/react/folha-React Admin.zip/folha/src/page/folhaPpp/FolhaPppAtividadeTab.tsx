/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FolhaPppAtividade {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaPppAtividade {
		const folhaPppAtividade = new FolhaPppAtividade();
		folhaPppAtividade.id = Date.now();
		folhaPppAtividade.statusCrud = "C";
		return folhaPppAtividade;
	}
}

export const FolhaPppAtividadeTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaPppAtividade,
		setCurrentRecord: (record: FolhaPppAtividade) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataInicio', label: 'Data Inicio' },
		{ source: 'dataFim', label: 'Data Fim' },
		{ source: 'descricao', label: 'Descricao' },
	];

	return (
		<CrudChildTab
			title="Atividade"
			recordContext="folhaPpp"
			fieldSource="folhaPppAtividadeModelList"
			newObject={ FolhaPppAtividade.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};