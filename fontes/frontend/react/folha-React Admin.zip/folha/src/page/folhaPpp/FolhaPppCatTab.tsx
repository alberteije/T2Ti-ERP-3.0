/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FolhaPppCat {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaPppCat {
		const folhaPppCat = new FolhaPppCat();
		folhaPppCat.id = Date.now();
		folhaPppCat.statusCrud = "C";
		return folhaPppCat;
	}
}

export const FolhaPppCatTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaPppCat,
		setCurrentRecord: (record: FolhaPppCat) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroCat', label: 'Numero CAT' },
		{ source: 'dataAfastamento', label: 'Data Afastamento' },
		{ source: 'dataRegistro', label: 'Data Registro' },
	];

	return (
		<CrudChildTab
			title="CAT"
			recordContext="folhaPpp"
			fieldSource="folhaPppCatModelList"
			newObject={ FolhaPppCat.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};