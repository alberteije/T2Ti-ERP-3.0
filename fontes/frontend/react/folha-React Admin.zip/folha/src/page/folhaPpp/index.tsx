import FolhaPppIcon from "@mui/icons-material/Apps";
import FolhaPppList from "./FolhaPppList";
import FolhaPppCreate from "./FolhaPppCreate";
import FolhaPppEdit from "./FolhaPppEdit";

export default {
	list: FolhaPppList,
	create: FolhaPppCreate,
	edit: FolhaPppEdit,
	icon: FolhaPppIcon,
};
