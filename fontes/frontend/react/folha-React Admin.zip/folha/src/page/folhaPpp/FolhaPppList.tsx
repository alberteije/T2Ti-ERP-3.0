/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FolhaPppList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","observacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaPppSmallScreenList : FolhaPppBigScreenList;

	return (
		<List
			title="PPP"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaPppSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.observacao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const FolhaPppBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaPppList;
