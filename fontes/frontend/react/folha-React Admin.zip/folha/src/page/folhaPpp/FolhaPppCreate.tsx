/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FolhaPppForm } from "./FolhaPppForm";
import { transformNestedData } from "../../infra/utils";

const FolhaPppCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FolhaPppForm />
		</Create>
	);
};

export default FolhaPppCreate;