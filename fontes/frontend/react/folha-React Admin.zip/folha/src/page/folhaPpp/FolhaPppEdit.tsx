/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FolhaPppForm } from "./FolhaPppForm";
import { transformNestedData } from "../../infra/utils";

const FolhaPppEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FolhaPppForm />
		</Edit>
	);
};

export default FolhaPppEdit;