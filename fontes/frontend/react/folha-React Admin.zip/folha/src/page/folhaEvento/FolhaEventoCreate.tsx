import {
	Create,
} from "react-admin";
import { FolhaEventoForm } from "./FolhaEventoForm";

const FolhaEventoCreate = () => {
	return (
		<Create>
			<FolhaEventoForm />
		</Create>
	);
};

export default FolhaEventoCreate;