import FolhaEventoIcon from "@mui/icons-material/Apps";
import FolhaEventoList from "./FolhaEventoList";
import FolhaEventoCreate from "./FolhaEventoCreate";
import FolhaEventoEdit from "./FolhaEventoEdit";

export default {
	list: FolhaEventoList,
	create: FolhaEventoCreate,
	edit: FolhaEventoEdit,
	icon: FolhaEventoIcon,
};
