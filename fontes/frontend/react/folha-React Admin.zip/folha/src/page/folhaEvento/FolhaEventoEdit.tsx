import {
	Edit,
} from "react-admin";
import { FolhaEventoForm } from "./FolhaEventoForm";

const FolhaEventoEdit = () => {
	return (
		<Edit>
			<FolhaEventoForm />
		</Edit>
	);
};

export default FolhaEventoEdit;