/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FolhaValeTransporteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","empresaTransporteItinerarioModel.nome","quantidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaValeTransporteSmallScreenList : FolhaValeTransporteBigScreenList;

	return (
		<List
			title="Vale Transporte"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaValeTransporteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.empresaTransporteItinerarioModel.nome }
			tertiaryText={ (record) => record.quantidade }
		/>
	);
}

const FolhaValeTransporteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Empresa Transp Itin" source="empresaTransporteItinerarioModel.id" reference="empresa-transporte-itinerario" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="quantidade" label="Quantidade" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaValeTransporteList;
