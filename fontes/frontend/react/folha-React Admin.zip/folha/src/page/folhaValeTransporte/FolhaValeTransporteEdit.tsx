import {
	Edit,
} from "react-admin";
import { FolhaValeTransporteForm } from "./FolhaValeTransporteForm";

const FolhaValeTransporteEdit = () => {
	return (
		<Edit>
			<FolhaValeTransporteForm />
		</Edit>
	);
};

export default FolhaValeTransporteEdit;