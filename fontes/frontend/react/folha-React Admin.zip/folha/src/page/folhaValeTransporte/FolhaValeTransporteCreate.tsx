import {
	Create,
} from "react-admin";
import { FolhaValeTransporteForm } from "./FolhaValeTransporteForm";

const FolhaValeTransporteCreate = () => {
	return (
		<Create>
			<FolhaValeTransporteForm />
		</Create>
	);
};

export default FolhaValeTransporteCreate;