import FolhaValeTransporteIcon from "@mui/icons-material/Apps";
import FolhaValeTransporteList from "./FolhaValeTransporteList";
import FolhaValeTransporteCreate from "./FolhaValeTransporteCreate";
import FolhaValeTransporteEdit from "./FolhaValeTransporteEdit";

export default {
	list: FolhaValeTransporteList,
	create: FolhaValeTransporteCreate,
	edit: FolhaValeTransporteEdit,
	icon: FolhaValeTransporteIcon,
};
