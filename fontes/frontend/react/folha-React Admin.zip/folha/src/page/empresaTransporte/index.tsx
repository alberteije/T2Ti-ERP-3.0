import EmpresaTransporteIcon from "@mui/icons-material/Apps";
import EmpresaTransporteList from "./EmpresaTransporteList";
import EmpresaTransporteCreate from "./EmpresaTransporteCreate";
import EmpresaTransporteEdit from "./EmpresaTransporteEdit";

export default {
	list: EmpresaTransporteList,
	create: EmpresaTransporteCreate,
	edit: EmpresaTransporteEdit,
	icon: EmpresaTransporteIcon,
};
