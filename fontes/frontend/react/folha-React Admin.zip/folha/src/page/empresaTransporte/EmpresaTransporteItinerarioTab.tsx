/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class EmpresaTransporteItinerario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EmpresaTransporteItinerario {
		const empresaTransporteItinerario = new EmpresaTransporteItinerario();
		empresaTransporteItinerario.id = Date.now();
		empresaTransporteItinerario.statusCrud = "C";
		return empresaTransporteItinerario;
	}
}

export const EmpresaTransporteItinerarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: EmpresaTransporteItinerario,
		setCurrentRecord: (record: EmpresaTransporteItinerario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'tarifa', label: 'Tarifa' },
		{ source: 'trajeto', label: 'Trajeto' },
	];

	return (
		<CrudChildTab
			title="Itinerario"
			recordContext="empresaTransporte"
			fieldSource="empresaTransporteItinerarioModelList"
			newObject={ EmpresaTransporteItinerario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};