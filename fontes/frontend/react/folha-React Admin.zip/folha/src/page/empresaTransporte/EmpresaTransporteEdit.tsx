/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { EmpresaTransporteForm } from "./EmpresaTransporteForm";
import { transformNestedData } from "../../infra/utils";

const EmpresaTransporteEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<EmpresaTransporteForm />
		</Edit>
	);
};

export default EmpresaTransporteEdit;