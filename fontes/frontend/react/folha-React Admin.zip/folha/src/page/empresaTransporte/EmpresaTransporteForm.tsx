/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { EmpresaTransporteItinerarioTab } from './EmpresaTransporteItinerarioTab';

export const EmpresaTransporteForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Empresa de Transporte">
				<EmpresaTransporteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itinerario">
				<EmpresaTransporteItinerarioTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const EmpresaTransporteTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};