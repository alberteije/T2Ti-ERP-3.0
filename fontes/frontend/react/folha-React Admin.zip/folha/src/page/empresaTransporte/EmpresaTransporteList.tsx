/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import EmpresaTransporteDomain from '../../data/domain/EmpresaTransporteDomain';

const EmpresaTransporteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","uf","classificacaoContabilConta"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EmpresaTransporteSmallScreenList : EmpresaTransporteBigScreenList;

	return (
		<List
			title="Empresa de Transporte"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EmpresaTransporteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.uf }
			tertiaryText={ (record) => record.classificacaoContabilConta }
		/>
	);
}

const EmpresaTransporteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Uf"
				render={record => EmpresaTransporteDomain.getUf(record.uf)}
			/>
			<TextField source="classificacaoContabilConta" label="Classificacao Contabil Conta" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EmpresaTransporteList;
