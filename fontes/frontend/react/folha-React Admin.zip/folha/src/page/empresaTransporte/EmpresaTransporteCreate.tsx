/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { EmpresaTransporteForm } from "./EmpresaTransporteForm";
import { transformNestedData } from "../../infra/utils";

const EmpresaTransporteCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<EmpresaTransporteForm />
		</Create>
	);
};

export default EmpresaTransporteCreate;