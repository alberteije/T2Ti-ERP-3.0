import {
	Edit,
} from "react-admin";
import { FolhaInssServicoForm } from "./FolhaInssServicoForm";

const FolhaInssServicoEdit = () => {
	return (
		<Edit>
			<FolhaInssServicoForm />
		</Edit>
	);
};

export default FolhaInssServicoEdit;