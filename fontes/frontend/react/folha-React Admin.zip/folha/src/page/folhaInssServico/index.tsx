import FolhaInssServicoIcon from "@mui/icons-material/Apps";
import FolhaInssServicoList from "./FolhaInssServicoList";
import FolhaInssServicoCreate from "./FolhaInssServicoCreate";
import FolhaInssServicoEdit from "./FolhaInssServicoEdit";

export default {
	list: FolhaInssServicoList,
	create: FolhaInssServicoCreate,
	edit: FolhaInssServicoEdit,
	icon: FolhaInssServicoIcon,
};
