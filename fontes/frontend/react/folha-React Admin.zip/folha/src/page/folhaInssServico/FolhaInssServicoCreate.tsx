import {
	Create,
} from "react-admin";
import { FolhaInssServicoForm } from "./FolhaInssServicoForm";

const FolhaInssServicoCreate = () => {
	return (
		<Create>
			<FolhaInssServicoForm />
		</Create>
	);
};

export default FolhaInssServicoCreate;