import FolhaInssIcon from "@mui/icons-material/Apps";
import FolhaInssList from "./FolhaInssList";
import FolhaInssCreate from "./FolhaInssCreate";
import FolhaInssEdit from "./FolhaInssEdit";

export default {
	list: FolhaInssList,
	create: FolhaInssCreate,
	edit: FolhaInssEdit,
	icon: FolhaInssIcon,
};
