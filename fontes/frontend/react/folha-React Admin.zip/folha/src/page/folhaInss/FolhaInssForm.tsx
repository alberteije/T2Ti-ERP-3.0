/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FolhaInssRetencaoTab } from './FolhaInssRetencaoTab';

export const FolhaInssForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="INSS">
				<FolhaInssTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Retenções">
				<FolhaInssRetencaoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FolhaInssTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};