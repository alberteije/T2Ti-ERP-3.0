/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FolhaInssRetencao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaInssRetencao {
		const folhaInssRetencao = new FolhaInssRetencao();
		folhaInssRetencao.id = Date.now();
		folhaInssRetencao.statusCrud = "C";
		return folhaInssRetencao;
	}
}

export const FolhaInssRetencaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaInssRetencao,
		setCurrentRecord: (record: FolhaInssRetencao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'folhaInssServicoModel.id', label: 'Serviço INSS', reference: 'folha-inss-servico', fieldName: 'nome' },
		{ source: 'valorMensal', label: 'Valor Mensal' },
		{ source: 'valor13', label: 'Valor 13' },
	];

	return (
		<CrudChildTab
			title="Retenções"
			recordContext="folhaInss"
			fieldSource="folhaInssRetencaoModelList"
			newObject={ FolhaInssRetencao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};