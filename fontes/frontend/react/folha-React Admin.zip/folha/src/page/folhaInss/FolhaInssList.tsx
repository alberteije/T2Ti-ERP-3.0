/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FolhaInssList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["competencia"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaInssSmallScreenList : FolhaInssBigScreenList;

	return (
		<List
			title="INSS"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaInssSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.competencia }
			secondaryText={ (record) => record._ }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const FolhaInssBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaInssList;
