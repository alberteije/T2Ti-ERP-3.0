/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FolhaInssForm } from "./FolhaInssForm";
import { transformNestedData } from "../../infra/utils";

const FolhaInssCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FolhaInssForm />
		</Create>
	);
};

export default FolhaInssCreate;