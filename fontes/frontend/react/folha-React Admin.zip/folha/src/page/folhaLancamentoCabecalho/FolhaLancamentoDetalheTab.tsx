/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class FolhaLancamentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): FolhaLancamentoDetalhe {
		const folhaLancamentoDetalhe = new FolhaLancamentoDetalhe();
		folhaLancamentoDetalhe.id = Date.now();
		folhaLancamentoDetalhe.statusCrud = "C";
		return folhaLancamentoDetalhe;
	}
}

export const FolhaLancamentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: FolhaLancamentoDetalhe,
		setCurrentRecord: (record: FolhaLancamentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'folhaEventoModel.id', label: 'Evento', reference: 'folha-evento', fieldName: 'nome' },
		{ source: 'origem', label: 'Origem' },
		{ source: 'provento', label: 'Provento' },
		{ source: 'desconto', label: 'Desconto' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="folhaLancamentoCabecalho"
			fieldSource="folhaLancamentoDetalheModelList"
			newObject={ FolhaLancamentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};