/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { FolhaLancamentoCabecalhoForm } from "./FolhaLancamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const FolhaLancamentoCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<FolhaLancamentoCabecalhoForm />
		</Create>
	);
};

export default FolhaLancamentoCabecalhoCreate;