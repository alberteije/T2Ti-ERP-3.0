/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { FolhaLancamentoCabecalhoForm } from "./FolhaLancamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const FolhaLancamentoCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<FolhaLancamentoCabecalhoForm />
		</Edit>
	);
};

export default FolhaLancamentoCabecalhoEdit;