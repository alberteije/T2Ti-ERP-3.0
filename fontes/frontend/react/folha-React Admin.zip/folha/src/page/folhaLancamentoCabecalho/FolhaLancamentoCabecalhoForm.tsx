/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { FolhaLancamentoDetalheTab } from './FolhaLancamentoDetalheTab';

export const FolhaLancamentoCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Lançamento">
				<FolhaLancamentoCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<FolhaLancamentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const FolhaLancamentoCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};