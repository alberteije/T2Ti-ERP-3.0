import FolhaLancamentoCabecalhoIcon from "@mui/icons-material/Apps";
import FolhaLancamentoCabecalhoList from "./FolhaLancamentoCabecalhoList";
import FolhaLancamentoCabecalhoCreate from "./FolhaLancamentoCabecalhoCreate";
import FolhaLancamentoCabecalhoEdit from "./FolhaLancamentoCabecalhoEdit";

export default {
	list: FolhaLancamentoCabecalhoList,
	create: FolhaLancamentoCabecalhoCreate,
	edit: FolhaLancamentoCabecalhoEdit,
	icon: FolhaLancamentoCabecalhoIcon,
};
