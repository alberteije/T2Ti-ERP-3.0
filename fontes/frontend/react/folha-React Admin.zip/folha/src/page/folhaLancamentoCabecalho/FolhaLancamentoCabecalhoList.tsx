/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FolhaLancamentoCabecalhoDomain from '../../data/domain/FolhaLancamentoCabecalhoDomain';

const FolhaLancamentoCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","competencia","tipo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaLancamentoCabecalhoSmallScreenList : FolhaLancamentoCabecalhoBigScreenList;

	return (
		<List
			title="Lançamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaLancamentoCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.competencia }
			tertiaryText={ (record) => record.tipo }
		/>
	);
}

const FolhaLancamentoCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="competencia" label="Competencia" />
			<FunctionField
				label="Tipo"
				render={record => FolhaLancamentoCabecalhoDomain.getTipo(record.tipo)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaLancamentoCabecalhoList;
