import {
	Edit,
} from "react-admin";
import { FolhaFechamentoForm } from "./FolhaFechamentoForm";

const FolhaFechamentoEdit = () => {
	return (
		<Edit>
			<FolhaFechamentoForm />
		</Edit>
	);
};

export default FolhaFechamentoEdit;