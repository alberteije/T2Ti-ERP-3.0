import {
	Create,
} from "react-admin";
import { FolhaFechamentoForm } from "./FolhaFechamentoForm";

const FolhaFechamentoCreate = () => {
	return (
		<Create>
			<FolhaFechamentoForm />
		</Create>
	);
};

export default FolhaFechamentoCreate;