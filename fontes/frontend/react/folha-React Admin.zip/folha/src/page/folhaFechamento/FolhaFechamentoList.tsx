/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FolhaFechamentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["fechamentoAtual","proximoFechamento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaFechamentoSmallScreenList : FolhaFechamentoBigScreenList;

	return (
		<List
			title="Fechamento da Folha"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaFechamentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.fechamentoAtual }
			secondaryText={ (record) => record.proximoFechamento }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const FolhaFechamentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="fechamentoAtual"
				label="Fechamento Atual"
				render={record => formatWithMask(record.fechamentoAtual, '##/####')}
			/>
			<FunctionField
				source="proximoFechamento"
				label="Proximo Fechamento"
				render={record => formatWithMask(record.proximoFechamento, '##/####')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaFechamentoList;
