import FolhaFechamentoIcon from "@mui/icons-material/Apps";
import FolhaFechamentoList from "./FolhaFechamentoList";
import FolhaFechamentoCreate from "./FolhaFechamentoCreate";
import FolhaFechamentoEdit from "./FolhaFechamentoEdit";

export default {
	list: FolhaFechamentoList,
	create: FolhaFechamentoCreate,
	edit: FolhaFechamentoEdit,
	icon: FolhaFechamentoIcon,
};
