import {
	Create,
} from "react-admin";
import { FolhaHistoricoSalarialForm } from "./FolhaHistoricoSalarialForm";

const FolhaHistoricoSalarialCreate = () => {
	return (
		<Create>
			<FolhaHistoricoSalarialForm />
		</Create>
	);
};

export default FolhaHistoricoSalarialCreate;