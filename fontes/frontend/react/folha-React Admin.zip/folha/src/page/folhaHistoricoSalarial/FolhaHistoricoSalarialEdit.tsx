import {
	Edit,
} from "react-admin";
import { FolhaHistoricoSalarialForm } from "./FolhaHistoricoSalarialForm";

const FolhaHistoricoSalarialEdit = () => {
	return (
		<Edit>
			<FolhaHistoricoSalarialForm />
		</Edit>
	);
};

export default FolhaHistoricoSalarialEdit;