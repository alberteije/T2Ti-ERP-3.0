/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const FolhaHistoricoSalarialList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","competencia","salarioAtual"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaHistoricoSalarialSmallScreenList : FolhaHistoricoSalarialBigScreenList;

	return (
		<List
			title="Histórico Salarial"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaHistoricoSalarialSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.competencia }
			tertiaryText={ (record) => record.salarioAtual }
		/>
	);
}

const FolhaHistoricoSalarialBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<NumberField source="salarioAtual" label="Salario Atual" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualAumento" label="Percentual Aumento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="salarioNovo" label="Salario Novo" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				source="validoAPartir"
				label="Valido A Partir"
				render={record => formatWithMask(record.validoAPartir, '##/####')}
			/>
			<TextField source="motivo" label="Motivo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaHistoricoSalarialList;
