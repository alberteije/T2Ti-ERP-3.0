import FolhaHistoricoSalarialIcon from "@mui/icons-material/Apps";
import FolhaHistoricoSalarialList from "./FolhaHistoricoSalarialList";
import FolhaHistoricoSalarialCreate from "./FolhaHistoricoSalarialCreate";
import FolhaHistoricoSalarialEdit from "./FolhaHistoricoSalarialEdit";

export default {
	list: FolhaHistoricoSalarialList,
	create: FolhaHistoricoSalarialCreate,
	edit: FolhaHistoricoSalarialEdit,
	icon: FolhaHistoricoSalarialIcon,
};
