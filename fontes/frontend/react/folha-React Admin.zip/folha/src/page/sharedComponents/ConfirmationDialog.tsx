import React from 'react';
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Button } from '@mui/material';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';

interface ConfirmationDialogProps {
	title: string;
	question: string;
	open: boolean; 
	onClose: (confirm: boolean) => void;
}

const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({ title, question, open, onClose }) => {
	const handleClose = (confirm: boolean) => {
		onClose(confirm);
	};

	return (
		<Dialog
			open={open} 
			onClose={() => handleClose(false)}
			aria-labelledby="confirmation-dialog-title"
			aria-describedby="confirmation-dialog-description"
		>
			<DialogTitle
				id="confirmation-dialog-title"
				sx={{ backgroundColor: '#e3f2fd', color: '#000', padding: '10px', display: 'flex', alignItems: 'center' }} 
			>
				<HelpOutlineIcon sx={{ marginRight: '8px', verticalAlign: 'middle' }} /> {}
				{title}
			</DialogTitle>
			<DialogContent>
				<DialogContentText
					id="confirmation-dialog-description"
					sx={{ padding: '20px' }}
				>
					{question}
				</DialogContentText>
			</DialogContent>
			<DialogActions>
				<Button onClick={() => handleClose(false)} color="primary">
					Cancelar
				</Button>
				<Button onClick={() => handleClose(true)} color="primary" autoFocus>
					Confirmar
				</Button>
			</DialogActions>
		</Dialog>
	);
};

export default ConfirmationDialog;
