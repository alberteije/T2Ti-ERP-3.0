import {
	Create,
} from "react-admin";
import { FolhaLancamentoComissaoForm } from "./FolhaLancamentoComissaoForm";

const FolhaLancamentoComissaoCreate = () => {
	return (
		<Create>
			<FolhaLancamentoComissaoForm />
		</Create>
	);
};

export default FolhaLancamentoComissaoCreate;