import FolhaLancamentoComissaoIcon from "@mui/icons-material/Apps";
import FolhaLancamentoComissaoList from "./FolhaLancamentoComissaoList";
import FolhaLancamentoComissaoCreate from "./FolhaLancamentoComissaoCreate";
import FolhaLancamentoComissaoEdit from "./FolhaLancamentoComissaoEdit";

export default {
	list: FolhaLancamentoComissaoList,
	create: FolhaLancamentoComissaoCreate,
	edit: FolhaLancamentoComissaoEdit,
	icon: FolhaLancamentoComissaoIcon,
};
