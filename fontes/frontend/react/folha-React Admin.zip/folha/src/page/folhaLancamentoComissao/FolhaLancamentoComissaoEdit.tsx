import {
	Edit,
} from "react-admin";
import { FolhaLancamentoComissaoForm } from "./FolhaLancamentoComissaoForm";

const FolhaLancamentoComissaoEdit = () => {
	return (
		<Edit>
			<FolhaLancamentoComissaoForm />
		</Edit>
	);
};

export default FolhaLancamentoComissaoEdit;