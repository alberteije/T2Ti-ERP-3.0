import {
	Edit,
} from "react-admin";
import { GuiasAcumuladasForm } from "./GuiasAcumuladasForm";

const GuiasAcumuladasEdit = () => {
	return (
		<Edit>
			<GuiasAcumuladasForm />
		</Edit>
	);
};

export default GuiasAcumuladasEdit;