/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	NumberField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import GuiasAcumuladasDomain from '../../data/domain/GuiasAcumuladasDomain';

const GuiasAcumuladasList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["gpsTipo","gpsCompetencia","gpsValorInss"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? GuiasAcumuladasSmallScreenList : GuiasAcumuladasBigScreenList;

	return (
		<List
			title="Guias Acumuladas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const GuiasAcumuladasSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.gpsTipo }
			secondaryText={ (record) => record.gpsCompetencia }
			tertiaryText={ (record) => record.gpsValorInss }
		/>
	);
}

const GuiasAcumuladasBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Gps Tipo"
				render={record => GuiasAcumuladasDomain.getGpsTipo(record.gpsTipo)}
			/>
			<FunctionField
				source="gpsCompetencia"
				label="Gps Competencia"
				render={record => formatWithMask(record.gpsCompetencia, '##/####')}
			/>
			<NumberField source="gpsValorInss" label="Gps Valor Inss" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="gpsValorOutrasEnt" label="Gps Valor Outras Ent" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="gpsDataPagamento" label="Gps Data Pagamento" />
			<FunctionField
				source="irrfCompetencia"
				label="Irrf Competencia"
				render={record => formatWithMask(record.irrfCompetencia, '##/####')}
			/>
			<TextField source="irrfCodigoRecolhimento" label="Irrf Codigo Recolhimento" />
			<NumberField source="irrfValorAcumulado" label="Irrf Valor Acumulado" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="irrfDataPagamento" label="Irrf Data Pagamento" />
			<FunctionField
				source="pisCompetencia"
				label="Pis Competencia"
				render={record => formatWithMask(record.pisCompetencia, '##/####')}
			/>
			<NumberField source="pisValorAcumulado" label="Pis Valor Acumulado" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="pisDataPagamento" label="Pis Data Pagamento" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default GuiasAcumuladasList;
