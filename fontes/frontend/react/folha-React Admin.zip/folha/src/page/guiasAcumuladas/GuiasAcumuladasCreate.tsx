import {
	Create,
} from "react-admin";
import { GuiasAcumuladasForm } from "./GuiasAcumuladasForm";

const GuiasAcumuladasCreate = () => {
	return (
		<Create>
			<GuiasAcumuladasForm />
		</Create>
	);
};

export default GuiasAcumuladasCreate;