import GuiasAcumuladasIcon from "@mui/icons-material/Apps";
import GuiasAcumuladasList from "./GuiasAcumuladasList";
import GuiasAcumuladasCreate from "./GuiasAcumuladasCreate";
import GuiasAcumuladasEdit from "./GuiasAcumuladasEdit";

export default {
	list: GuiasAcumuladasList,
	create: GuiasAcumuladasCreate,
	edit: GuiasAcumuladasEdit,
	icon: GuiasAcumuladasIcon,
};
