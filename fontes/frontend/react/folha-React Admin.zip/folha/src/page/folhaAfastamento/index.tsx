import FolhaAfastamentoIcon from "@mui/icons-material/Apps";
import FolhaAfastamentoList from "./FolhaAfastamentoList";
import FolhaAfastamentoCreate from "./FolhaAfastamentoCreate";
import FolhaAfastamentoEdit from "./FolhaAfastamentoEdit";

export default {
	list: FolhaAfastamentoList,
	create: FolhaAfastamentoCreate,
	edit: FolhaAfastamentoEdit,
	icon: FolhaAfastamentoIcon,
};
