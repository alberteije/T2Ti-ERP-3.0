/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FolhaAfastamentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","folhaTipoAfastamentoModel.nome","dataInicio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaAfastamentoSmallScreenList : FolhaAfastamentoBigScreenList;

	return (
		<List
			title="Afastamentos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaAfastamentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.folhaTipoAfastamentoModel.nome }
			tertiaryText={ (record) => record.dataInicio }
		/>
	);
}

const FolhaAfastamentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Folha Tipo Afastamento" source="folhaTipoAfastamentoModel.id" reference="folha-tipo-afastamento" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<TextField source="diasAfastado" label="Dias Afastado" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaAfastamentoList;
