import {
	Create,
} from "react-admin";
import { FolhaAfastamentoForm } from "./FolhaAfastamentoForm";

const FolhaAfastamentoCreate = () => {
	return (
		<Create>
			<FolhaAfastamentoForm />
		</Create>
	);
};

export default FolhaAfastamentoCreate;