import {
	Edit,
} from "react-admin";
import { FolhaAfastamentoForm } from "./FolhaAfastamentoForm";

const FolhaAfastamentoEdit = () => {
	return (
		<Edit>
			<FolhaAfastamentoForm />
		</Edit>
	);
};

export default FolhaAfastamentoEdit;