import FolhaFeriasColetivasIcon from "@mui/icons-material/Apps";
import FolhaFeriasColetivasList from "./FolhaFeriasColetivasList";
import FolhaFeriasColetivasCreate from "./FolhaFeriasColetivasCreate";
import FolhaFeriasColetivasEdit from "./FolhaFeriasColetivasEdit";

export default {
	list: FolhaFeriasColetivasList,
	create: FolhaFeriasColetivasCreate,
	edit: FolhaFeriasColetivasEdit,
	icon: FolhaFeriasColetivasIcon,
};
