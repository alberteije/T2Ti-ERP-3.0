import {
	Create,
} from "react-admin";
import { FolhaFeriasColetivasForm } from "./FolhaFeriasColetivasForm";

const FolhaFeriasColetivasCreate = () => {
	return (
		<Create>
			<FolhaFeriasColetivasForm />
		</Create>
	);
};

export default FolhaFeriasColetivasCreate;