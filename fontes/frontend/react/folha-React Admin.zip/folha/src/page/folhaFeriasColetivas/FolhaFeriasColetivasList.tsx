/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const FolhaFeriasColetivasList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataInicio","dataFim","diasGozo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaFeriasColetivasSmallScreenList : FolhaFeriasColetivasBigScreenList;

	return (
		<List
			title="Férias Coletivas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaFeriasColetivasSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataInicio }
			secondaryText={ (record) => record.dataFim }
			tertiaryText={ (record) => record.diasGozo }
		/>
	);
}

const FolhaFeriasColetivasBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<TextField source="diasGozo" label="Dias Gozo" />
			<TextField source="abonoPecuniarioInicio" label="Abono Pecuniario Inicio" />
			<TextField source="abonoPecuniarioFim" label="Abono Pecuniario Fim" />
			<TextField source="diasAbono" label="Dias Abono" />
			<TextField source="dataPagamento" label="Data Pagamento" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaFeriasColetivasList;
