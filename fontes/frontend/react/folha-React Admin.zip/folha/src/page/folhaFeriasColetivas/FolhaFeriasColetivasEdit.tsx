import {
	Edit,
} from "react-admin";
import { FolhaFeriasColetivasForm } from "./FolhaFeriasColetivasForm";

const FolhaFeriasColetivasEdit = () => {
	return (
		<Edit>
			<FolhaFeriasColetivasForm />
		</Edit>
	);
};

export default FolhaFeriasColetivasEdit;