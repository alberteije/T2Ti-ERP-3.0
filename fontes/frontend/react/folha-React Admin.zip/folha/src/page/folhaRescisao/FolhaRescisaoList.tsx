/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FolhaRescisaoDomain from '../../data/domain/FolhaRescisaoDomain';

const FolhaRescisaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataDemissao","dataPagamento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaRescisaoSmallScreenList : FolhaRescisaoBigScreenList;

	return (
		<List
			title="Rescisão"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaRescisaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataDemissao }
			tertiaryText={ (record) => record.dataPagamento }
		/>
	);
}

const FolhaRescisaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataDemissao" label="Data Demissao" />
			<TextField source="dataPagamento" label="Data Pagamento" />
			<TextField source="motivo" label="Motivo" />
			<TextField source="motivoEsocial" label="Motivo Esocial" />
			<TextField source="dataAvisoPrevio" label="Data Aviso Previo" />
			<TextField source="diasAvisoPrevio" label="Dias Aviso Previo" />
			<FunctionField
				label="Comprovou Novo Emprego"
				render={record => FolhaRescisaoDomain.getComprovouNovoEmprego(record.comprovouNovoEmprego)}
			/>
			<FunctionField
				label="Dispensou Empregado"
				render={record => FolhaRescisaoDomain.getDispensouEmpregado(record.dispensouEmpregado)}
			/>
			<NumberField source="pensaoAlimenticia" label="Pensao Alimenticia" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="pensaoAlimenticiaFgts" label="Pensao Alimenticia Fgts" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="fgtsValorRescisao" label="Fgts Valor Rescisao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="fgtsSaldoBanco" label="Fgts Saldo Banco" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="fgtsComplementoSaldo" label="Fgts Complemento Saldo" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="fgtsCodigoAfastamento" label="Fgts Codigo Afastamento" />
			<TextField source="fgtsCodigoSaque" label="Fgts Codigo Saque" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaRescisaoList;
