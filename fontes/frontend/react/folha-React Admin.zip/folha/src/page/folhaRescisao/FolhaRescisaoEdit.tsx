import {
	Edit,
} from "react-admin";
import { FolhaRescisaoForm } from "./FolhaRescisaoForm";

const FolhaRescisaoEdit = () => {
	return (
		<Edit>
			<FolhaRescisaoForm />
		</Edit>
	);
};

export default FolhaRescisaoEdit;