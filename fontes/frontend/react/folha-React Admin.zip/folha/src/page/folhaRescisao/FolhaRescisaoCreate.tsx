import {
	Create,
} from "react-admin";
import { FolhaRescisaoForm } from "./FolhaRescisaoForm";

const FolhaRescisaoCreate = () => {
	return (
		<Create>
			<FolhaRescisaoForm />
		</Create>
	);
};

export default FolhaRescisaoCreate;