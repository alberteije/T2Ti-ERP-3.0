import FolhaRescisaoIcon from "@mui/icons-material/Apps";
import FolhaRescisaoList from "./FolhaRescisaoList";
import FolhaRescisaoCreate from "./FolhaRescisaoCreate";
import FolhaRescisaoEdit from "./FolhaRescisaoEdit";

export default {
	list: FolhaRescisaoList,
	create: FolhaRescisaoCreate,
	edit: FolhaRescisaoEdit,
	icon: FolhaRescisaoIcon,
};
