import {
	Edit,
} from "react-admin";
import { FeriasPeriodoAquisitivoForm } from "./FeriasPeriodoAquisitivoForm";

const FeriasPeriodoAquisitivoEdit = () => {
	return (
		<Edit>
			<FeriasPeriodoAquisitivoForm />
		</Edit>
	);
};

export default FeriasPeriodoAquisitivoEdit;