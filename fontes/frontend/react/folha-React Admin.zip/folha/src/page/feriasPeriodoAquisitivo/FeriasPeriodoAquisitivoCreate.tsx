import {
	Create,
} from "react-admin";
import { FeriasPeriodoAquisitivoForm } from "./FeriasPeriodoAquisitivoForm";

const FeriasPeriodoAquisitivoCreate = () => {
	return (
		<Create>
			<FeriasPeriodoAquisitivoForm />
		</Create>
	);
};

export default FeriasPeriodoAquisitivoCreate;