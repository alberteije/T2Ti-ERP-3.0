/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FeriasPeriodoAquisitivoDomain from '../../data/domain/FeriasPeriodoAquisitivoDomain';

const FeriasPeriodoAquisitivoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaColaboradorModel.nome","dataInicio","dataFim"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FeriasPeriodoAquisitivoSmallScreenList : FeriasPeriodoAquisitivoBigScreenList;

	return (
		<List
			title="Períodos Aquisitivos"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FeriasPeriodoAquisitivoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			secondaryText={ (record) => record.dataInicio }
			tertiaryText={ (record) => record.dataFim }
		/>
	);
}

const FeriasPeriodoAquisitivoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<FunctionField
				label="Situacao"
				render={record => FeriasPeriodoAquisitivoDomain.getSituacao(record.situacao)}
			/>
			<TextField source="limiteParaGozo" label="Limite Para Gozo" />
			<FunctionField
				label="Descontar Faltas"
				render={record => FeriasPeriodoAquisitivoDomain.getDescontarFaltas(record.descontarFaltas)}
			/>
			<FunctionField
				label="Desconsiderar Afastamento"
				render={record => FeriasPeriodoAquisitivoDomain.getDesconsiderarAfastamento(record.desconsiderarAfastamento)}
			/>
			<TextField source="afastamentoPrevidencia" label="Afastamento Previdencia" />
			<TextField source="afastamentoSemRemun" label="Afastamento Sem Remun" />
			<TextField source="afastamentoComRemun" label="Afastamento Com Remun" />
			<TextField source="diasDireito" label="Dias Direito" />
			<TextField source="diasGozados" label="Dias Gozados" />
			<TextField source="diasFaltas" label="Dias Faltas" />
			<TextField source="diasRestantes" label="Dias Restantes" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FeriasPeriodoAquisitivoList;
