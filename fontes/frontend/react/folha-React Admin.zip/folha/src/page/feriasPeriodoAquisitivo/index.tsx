import FeriasPeriodoAquisitivoIcon from "@mui/icons-material/Apps";
import FeriasPeriodoAquisitivoList from "./FeriasPeriodoAquisitivoList";
import FeriasPeriodoAquisitivoCreate from "./FeriasPeriodoAquisitivoCreate";
import FeriasPeriodoAquisitivoEdit from "./FeriasPeriodoAquisitivoEdit";

export default {
	list: FeriasPeriodoAquisitivoList,
	create: FeriasPeriodoAquisitivoCreate,
	edit: FeriasPeriodoAquisitivoEdit,
	icon: FeriasPeriodoAquisitivoIcon,
};
