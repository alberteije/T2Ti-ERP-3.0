import {
	Create,
} from "react-admin";
import { FolhaTipoAfastamentoForm } from "./FolhaTipoAfastamentoForm";

const FolhaTipoAfastamentoCreate = () => {
	return (
		<Create>
			<FolhaTipoAfastamentoForm />
		</Create>
	);
};

export default FolhaTipoAfastamentoCreate;