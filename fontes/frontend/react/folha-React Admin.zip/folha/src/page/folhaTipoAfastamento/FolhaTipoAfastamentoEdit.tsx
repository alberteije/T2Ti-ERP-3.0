import {
	Edit,
} from "react-admin";
import { FolhaTipoAfastamentoForm } from "./FolhaTipoAfastamentoForm";

const FolhaTipoAfastamentoEdit = () => {
	return (
		<Edit>
			<FolhaTipoAfastamentoForm />
		</Edit>
	);
};

export default FolhaTipoAfastamentoEdit;