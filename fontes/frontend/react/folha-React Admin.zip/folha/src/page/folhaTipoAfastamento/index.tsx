import FolhaTipoAfastamentoIcon from "@mui/icons-material/Apps";
import FolhaTipoAfastamentoList from "./FolhaTipoAfastamentoList";
import FolhaTipoAfastamentoCreate from "./FolhaTipoAfastamentoCreate";
import FolhaTipoAfastamentoEdit from "./FolhaTipoAfastamentoEdit";

export default {
	list: FolhaTipoAfastamentoList,
	create: FolhaTipoAfastamentoCreate,
	edit: FolhaTipoAfastamentoEdit,
	icon: FolhaTipoAfastamentoIcon,
};
