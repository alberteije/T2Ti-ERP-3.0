/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const OperadoraPlanoSaudeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","registroAns","classificacaoContabilConta"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OperadoraPlanoSaudeSmallScreenList : OperadoraPlanoSaudeBigScreenList;

	return (
		<List
			title="Operadora Plano de Saúde"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OperadoraPlanoSaudeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.registroAns }
			tertiaryText={ (record) => record.classificacaoContabilConta }
		/>
	);
}

const OperadoraPlanoSaudeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="registroAns" label="Registro Ans" />
			<TextField source="classificacaoContabilConta" label="Classificacao Contabil Conta" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OperadoraPlanoSaudeList;
