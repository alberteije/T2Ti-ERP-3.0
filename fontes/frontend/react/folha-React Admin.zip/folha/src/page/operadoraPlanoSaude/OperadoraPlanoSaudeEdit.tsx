import {
	Edit,
} from "react-admin";
import { OperadoraPlanoSaudeForm } from "./OperadoraPlanoSaudeForm";

const OperadoraPlanoSaudeEdit = () => {
	return (
		<Edit>
			<OperadoraPlanoSaudeForm />
		</Edit>
	);
};

export default OperadoraPlanoSaudeEdit;