import {
	Create,
} from "react-admin";
import { OperadoraPlanoSaudeForm } from "./OperadoraPlanoSaudeForm";

const OperadoraPlanoSaudeCreate = () => {
	return (
		<Create>
			<OperadoraPlanoSaudeForm />
		</Create>
	);
};

export default OperadoraPlanoSaudeCreate;