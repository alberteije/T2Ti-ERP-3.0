import OperadoraPlanoSaudeIcon from "@mui/icons-material/Apps";
import OperadoraPlanoSaudeList from "./OperadoraPlanoSaudeList";
import OperadoraPlanoSaudeCreate from "./OperadoraPlanoSaudeCreate";
import OperadoraPlanoSaudeEdit from "./OperadoraPlanoSaudeEdit";

export default {
	list: OperadoraPlanoSaudeList,
	create: OperadoraPlanoSaudeCreate,
	edit: OperadoraPlanoSaudeEdit,
	icon: OperadoraPlanoSaudeIcon,
};
