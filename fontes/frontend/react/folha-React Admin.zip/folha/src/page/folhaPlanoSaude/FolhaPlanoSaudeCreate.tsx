import {
	Create,
} from "react-admin";
import { FolhaPlanoSaudeForm } from "./FolhaPlanoSaudeForm";

const FolhaPlanoSaudeCreate = () => {
	return (
		<Create>
			<FolhaPlanoSaudeForm />
		</Create>
	);
};

export default FolhaPlanoSaudeCreate;