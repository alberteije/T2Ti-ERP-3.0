import FolhaPlanoSaudeIcon from "@mui/icons-material/Apps";
import FolhaPlanoSaudeList from "./FolhaPlanoSaudeList";
import FolhaPlanoSaudeCreate from "./FolhaPlanoSaudeCreate";
import FolhaPlanoSaudeEdit from "./FolhaPlanoSaudeEdit";

export default {
	list: FolhaPlanoSaudeList,
	create: FolhaPlanoSaudeCreate,
	edit: FolhaPlanoSaudeEdit,
	icon: FolhaPlanoSaudeIcon,
};
