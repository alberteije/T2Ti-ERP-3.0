/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FolhaPlanoSaudeDomain from '../../data/domain/FolhaPlanoSaudeDomain';

const FolhaPlanoSaudeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["operadoraPlanoSaudeModel.nome","viewPessoaColaboradorModel.nome","dataInicio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaPlanoSaudeSmallScreenList : FolhaPlanoSaudeBigScreenList;

	return (
		<List
			title="Plano de Saúde"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaPlanoSaudeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.operadoraPlanoSaudeModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.dataInicio }
		/>
	);
}

const FolhaPlanoSaudeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Operadora Plano Saude" source="operadoraPlanoSaudeModel.id" reference="operadora-plano-saude" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataInicio" label="Data Inicio" />
			<FunctionField
				label="Beneficiario"
				render={record => FolhaPlanoSaudeDomain.getBeneficiario(record.beneficiario)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaPlanoSaudeList;
