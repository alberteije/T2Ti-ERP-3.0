import {
	Edit,
} from "react-admin";
import { FolhaPlanoSaudeForm } from "./FolhaPlanoSaudeForm";

const FolhaPlanoSaudeEdit = () => {
	return (
		<Edit>
			<FolhaPlanoSaudeForm />
		</Edit>
	);
};

export default FolhaPlanoSaudeEdit;