import FeriadosIcon from "@mui/icons-material/Apps";
import FeriadosList from "./FeriadosList";
import FeriadosCreate from "./FeriadosCreate";
import FeriadosEdit from "./FeriadosEdit";

export default {
	list: FeriadosList,
	create: FeriadosCreate,
	edit: FeriadosEdit,
	icon: FeriadosIcon,
};
