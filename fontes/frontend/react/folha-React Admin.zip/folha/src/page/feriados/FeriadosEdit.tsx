import {
	Edit,
} from "react-admin";
import { FeriadosForm } from "./FeriadosForm";

const FeriadosEdit = () => {
	return (
		<Edit>
			<FeriadosForm />
		</Edit>
	);
};

export default FeriadosEdit;