import {
	Create,
} from "react-admin";
import { FeriadosForm } from "./FeriadosForm";

const FeriadosCreate = () => {
	return (
		<Create>
			<FeriadosForm />
		</Create>
	);
};

export default FeriadosCreate;