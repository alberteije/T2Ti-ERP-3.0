/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import FeriadosDomain from '../../data/domain/FeriadosDomain';

const FeriadosList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["ano","nome","abrangencia"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FeriadosSmallScreenList : FeriadosBigScreenList;

	return (
		<List
			title="Feriados"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FeriadosSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.ano }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.abrangencia }
		/>
	);
}

const FeriadosBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="ano" label="Ano" />
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Abrangencia"
				render={record => FeriadosDomain.getAbrangencia(record.abrangencia)}
			/>
			<FunctionField
				label="Uf"
				render={record => FeriadosDomain.getUf(record.uf)}
			/>
			<TextField source="municipioIbge" label="Municipio Ibge" />
			<FunctionField
				label="Tipo"
				render={record => FeriadosDomain.getTipo(record.tipo)}
			/>
			<TextField source="dataFeriado" label="Data Feriado" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FeriadosList;
