import FolhaParametroIcon from "@mui/icons-material/Apps";
import FolhaParametroList from "./FolhaParametroList";
import FolhaParametroCreate from "./FolhaParametroCreate";
import FolhaParametroEdit from "./FolhaParametroEdit";

export default {
	list: FolhaParametroList,
	create: FolhaParametroCreate,
	edit: FolhaParametroEdit,
	icon: FolhaParametroIcon,
};
