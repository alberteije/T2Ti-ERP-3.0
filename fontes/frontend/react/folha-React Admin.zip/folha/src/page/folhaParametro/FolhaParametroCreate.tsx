import {
	Create,
} from "react-admin";
import { FolhaParametroForm } from "./FolhaParametroForm";

const FolhaParametroCreate = () => {
	return (
		<Create>
			<FolhaParametroForm />
		</Create>
	);
};

export default FolhaParametroCreate;