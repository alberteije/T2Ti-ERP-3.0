import {
	Edit,
} from "react-admin";
import { FolhaParametroForm } from "./FolhaParametroForm";

const FolhaParametroEdit = () => {
	return (
		<Edit>
			<FolhaParametroForm />
		</Edit>
	);
};

export default FolhaParametroEdit;