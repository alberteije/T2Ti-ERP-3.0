/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	NumberField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import FolhaParametroDomain from '../../data/domain/FolhaParametroDomain';

const FolhaParametroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["competencia","contribuiPis","aliquotaPis"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? FolhaParametroSmallScreenList : FolhaParametroBigScreenList;

	return (
		<List
			title="Parâmetros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const FolhaParametroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.competencia }
			secondaryText={ (record) => record.contribuiPis }
			tertiaryText={ (record) => record.aliquotaPis }
		/>
	);
}

const FolhaParametroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<FunctionField
				label="Contribui Pis"
				render={record => FolhaParametroDomain.getContribuiPis(record.contribuiPis)}
			/>
			<NumberField source="aliquotaPis" label="Aliquota Pis" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Discriminar Dsr"
				render={record => FolhaParametroDomain.getDiscriminarDsr(record.discriminarDsr)}
			/>
			<TextField source="diaPagamento" label="Dia Pagamento" />
			<FunctionField
				label="Calculo Proporcionalidade"
				render={record => FolhaParametroDomain.getCalculoProporcionalidade(record.calculoProporcionalidade)}
			/>
			<FunctionField
				label="Descontar Faltas 13"
				render={record => FolhaParametroDomain.getDescontarFaltas13(record.descontarFaltas13)}
			/>
			<FunctionField
				label="Pagar Adicionais 13"
				render={record => FolhaParametroDomain.getPagarAdicionais13(record.pagarAdicionais13)}
			/>
			<FunctionField
				label="Pagar Estagiarios 13"
				render={record => FolhaParametroDomain.getPagarEstagiarios13(record.pagarEstagiarios13)}
			/>
			<TextField source="mesAdiantamento13" label="Mes Adiantamento 13" />
			<NumberField source="percentualAdiantam13" label="Percentual Adiantam 13" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Ferias Descontar Faltas"
				render={record => FolhaParametroDomain.getFeriasDescontarFaltas(record.feriasDescontarFaltas)}
			/>
			<FunctionField
				label="Ferias Pagar Adicionais"
				render={record => FolhaParametroDomain.getFeriasPagarAdicionais(record.feriasPagarAdicionais)}
			/>
			<FunctionField
				label="Ferias Adiantar 13"
				render={record => FolhaParametroDomain.getFeriasAdiantar13(record.feriasAdiantar13)}
			/>
			<FunctionField
				label="Ferias Pagar Estagiarios"
				render={record => FolhaParametroDomain.getFeriasPagarEstagiarios(record.feriasPagarEstagiarios)}
			/>
			<FunctionField
				label="Ferias Calc Justa Causa"
				render={record => FolhaParametroDomain.getFeriasCalcJustaCausa(record.feriasCalcJustaCausa)}
			/>
			<FunctionField
				label="Ferias Movimento Mensal"
				render={record => FolhaParametroDomain.getFeriasMovimentoMensal(record.feriasMovimentoMensal)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default FolhaParametroList;
