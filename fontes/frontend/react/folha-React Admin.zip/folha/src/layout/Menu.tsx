import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import empresaTransporte from '../page/empresaTransporte';
import folhaLancamentoCabecalho from '../page/folhaLancamentoCabecalho';
import folhaInss from '../page/folhaInss';
import folhaPpp from '../page/folhaPpp';
import operadoraPlanoSaude from '../page/operadoraPlanoSaude';
import folhaLancamentoComissao from '../page/folhaLancamentoComissao';
import folhaParametro from '../page/folhaParametro';
import guiasAcumuladas from '../page/guiasAcumuladas';
import folhaFechamento from '../page/folhaFechamento';
import feriasPeriodoAquisitivo from '../page/feriasPeriodoAquisitivo';
import folhaTipoAfastamento from '../page/folhaTipoAfastamento';
import folhaAfastamento from '../page/folhaAfastamento';
import folhaPlanoSaude from '../page/folhaPlanoSaude';
import folhaEvento from '../page/folhaEvento';
import folhaRescisao from '../page/folhaRescisao';
import folhaFeriasColetivas from '../page/folhaFeriasColetivas';
import folhaValeTransporte from '../page/folhaValeTransporte';
import folhaInssServico from '../page/folhaInssServico';
import folhaHistoricoSalarial from '../page/folhaHistoricoSalarial';
import feriados from '../page/feriados';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/operadora-plano-saude'
					state={{ _scrollToTop: true }}
					primaryText='Operadora Plano de Saúde'
					leftIcon={<operadoraPlanoSaude.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-lancamento-comissao'
					state={{ _scrollToTop: true }}
					primaryText='Comissões'
					leftIcon={<folhaLancamentoComissao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-parametro'
					state={{ _scrollToTop: true }}
					primaryText='Parâmetros'
					leftIcon={<folhaParametro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/guias-acumuladas'
					state={{ _scrollToTop: true }}
					primaryText='Guias Acumuladas'
					leftIcon={<guiasAcumuladas.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-fechamento'
					state={{ _scrollToTop: true }}
					primaryText='Fechamento da Folha'
					leftIcon={<folhaFechamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ferias-periodo-aquisitivo'
					state={{ _scrollToTop: true }}
					primaryText='Períodos Aquisitivos'
					leftIcon={<feriasPeriodoAquisitivo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-tipo-afastamento'
					state={{ _scrollToTop: true }}
					primaryText='Tipo de Afastamento'
					leftIcon={<folhaTipoAfastamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-afastamento'
					state={{ _scrollToTop: true }}
					primaryText='Afastamentos'
					leftIcon={<folhaAfastamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-plano-saude'
					state={{ _scrollToTop: true }}
					primaryText='Plano de Saúde'
					leftIcon={<folhaPlanoSaude.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-evento'
					state={{ _scrollToTop: true }}
					primaryText='Eventos'
					leftIcon={<folhaEvento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-rescisao'
					state={{ _scrollToTop: true }}
					primaryText='Rescisão'
					leftIcon={<folhaRescisao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-ferias-coletivas'
					state={{ _scrollToTop: true }}
					primaryText='Férias Coletivas'
					leftIcon={<folhaFeriasColetivas.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-vale-transporte'
					state={{ _scrollToTop: true }}
					primaryText='Vale Transporte'
					leftIcon={<folhaValeTransporte.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-inss-servico'
					state={{ _scrollToTop: true }}
					primaryText='Serviços'
					leftIcon={<folhaInssServico.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-historico-salarial'
					state={{ _scrollToTop: true }}
					primaryText='Histórico Salarial'
					leftIcon={<folhaHistoricoSalarial.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/feriados'
					state={{ _scrollToTop: true }}
					primaryText='Feriados'
					leftIcon={<feriados.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/empresa-transporte'
					state={{ _scrollToTop: true }}
					primaryText='Empresa de Transporte'
					leftIcon={<empresaTransporte.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-lancamento-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Lançamento'
					leftIcon={<folhaLancamentoCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-inss'
					state={{ _scrollToTop: true }}
					primaryText='INSS'
					leftIcon={<folhaInss.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/folha-ppp'
					state={{ _scrollToTop: true }}
					primaryText='PPP'
					leftIcon={<folhaPpp.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
