/* eslint-disable @typescript-eslint/no-explicit-any */
export function formatWithMask(value: string, mask: string): string {
	let formatted = '';
	let valueIndex = 0;

	if (!value) {
		return "";
	}

	for (let i = 0; i < mask.length && valueIndex < value.length; i++) {
		if (mask[i] === '#') {
			formatted += value[valueIndex];
			valueIndex++;
		} else {
			formatted += mask[i]; // Caracteres fixos da máscara
		}
	}

	return formatted;
}

/// set IDs from lists to zero so it could be persisted properly at backend
export const transformNestedData = (data: any): any => {
	const processRecord = (record: any) => {
		if (record.id && record.id.toString().length === 13) {
			record.id = 0;
		}

		// child object (1:N)
		for (const key in record) {
			if (Array.isArray(record[key])) {
				record[key] = record[key].map(processRecord); // recursion
			}
		}

		return record;
	};

	return processRecord(data);
};
