class GedDocumentoDetalheDomain {
	static getPodeExcluir(podeExcluir: string) { 
		switch (podeExcluir) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setPodeExcluir(podeExcluir: string) { 
		switch (podeExcluir) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPodeAlterar(podeAlterar: string) { 
		switch (podeAlterar) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setPodeAlterar(podeAlterar: string) { 
		switch (podeAlterar) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getAssinado(assinado: string) { 
		switch (assinado) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setAssinado(assinado: string) { 
		switch (assinado) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default GedDocumentoDetalheDomain;