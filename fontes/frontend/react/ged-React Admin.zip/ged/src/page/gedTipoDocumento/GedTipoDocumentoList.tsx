/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const GedTipoDocumentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","tamanhoMaximo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? GedTipoDocumentoSmallScreenList : GedTipoDocumentoBigScreenList;

	return (
		<List
			title="Tipo Documento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const GedTipoDocumentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.tamanhoMaximo }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const GedTipoDocumentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<NumberField source="tamanhoMaximo" label="Tamanho Maximo" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default GedTipoDocumentoList;
