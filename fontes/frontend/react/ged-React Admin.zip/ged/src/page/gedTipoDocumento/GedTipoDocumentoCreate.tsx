import {
	Create,
} from "react-admin";
import { GedTipoDocumentoForm } from "./GedTipoDocumentoForm";

const GedTipoDocumentoCreate = () => {
	return (
		<Create>
			<GedTipoDocumentoForm />
		</Create>
	);
};

export default GedTipoDocumentoCreate;