import GedTipoDocumentoIcon from "@mui/icons-material/Apps";
import GedTipoDocumentoList from "./GedTipoDocumentoList";
import GedTipoDocumentoCreate from "./GedTipoDocumentoCreate";
import GedTipoDocumentoEdit from "./GedTipoDocumentoEdit";

export default {
	list: GedTipoDocumentoList,
	create: GedTipoDocumentoCreate,
	edit: GedTipoDocumentoEdit,
	icon: GedTipoDocumentoIcon,
};
