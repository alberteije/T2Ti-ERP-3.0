import {
	Edit,
} from "react-admin";
import { GedTipoDocumentoForm } from "./GedTipoDocumentoForm";

const GedTipoDocumentoEdit = () => {
	return (
		<Edit>
			<GedTipoDocumentoForm />
		</Edit>
	);
};

export default GedTipoDocumentoEdit;