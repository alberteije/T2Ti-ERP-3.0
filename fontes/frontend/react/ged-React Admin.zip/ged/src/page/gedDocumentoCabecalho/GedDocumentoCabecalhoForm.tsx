/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { GedDocumentoDetalheTab } from './GedDocumentoDetalheTab';

export const GedDocumentoCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Documento">
				<GedDocumentoCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Detalhes">
				<GedDocumentoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const GedDocumentoCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};