/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { GedDocumentoCabecalhoForm } from "./GedDocumentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const GedDocumentoCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<GedDocumentoCabecalhoForm />
		</Create>
	);
};

export default GedDocumentoCabecalhoCreate;