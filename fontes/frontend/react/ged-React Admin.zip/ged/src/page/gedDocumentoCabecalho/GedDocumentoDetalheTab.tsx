/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import GedDocumentoDetalheDomain from '../../data/domain/GedDocumentoDetalheDomain';

class GedDocumentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): GedDocumentoDetalhe {
		const gedDocumentoDetalhe = new GedDocumentoDetalhe();
		gedDocumentoDetalhe.id = Date.now();
		gedDocumentoDetalhe.statusCrud = "C";
		return gedDocumentoDetalhe;
	}
}

export const GedDocumentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: GedDocumentoDetalhe,
		setCurrentRecord: (record: GedDocumentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'gedTipoDocumentoModel.id', label: 'Tipo Documento', reference: 'ged-tipo-documento', fieldName: 'nome' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'descricao', label: 'Descricao' },
		{ source: 'palavrasChave', label: 'Palavras Chave' },
		{ source: 'podeExcluir', label: 'Pode Excluir', formatDomain: GedDocumentoDetalheDomain.getPodeExcluir },
		{ source: 'podeAlterar', label: 'Pode Alterar', formatDomain: GedDocumentoDetalheDomain.getPodeAlterar },
		{ source: 'assinado', label: 'Assinado', formatDomain: GedDocumentoDetalheDomain.getAssinado },
		{ source: 'dataFimVigencia', label: 'Data Fim Vigencia' },
		{ source: 'dataExclusao', label: 'Data Exclusao' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="gedDocumentoCabecalho"
			fieldSource="gedDocumentoDetalheModelList"
			newObject={ GedDocumentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};