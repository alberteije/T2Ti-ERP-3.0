/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { GedDocumentoCabecalhoForm } from "./GedDocumentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const GedDocumentoCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<GedDocumentoCabecalhoForm />
		</Edit>
	);
};

export default GedDocumentoCabecalhoEdit;