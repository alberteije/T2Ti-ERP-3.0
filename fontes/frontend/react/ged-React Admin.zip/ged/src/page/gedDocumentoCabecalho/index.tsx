import GedDocumentoCabecalhoIcon from "@mui/icons-material/Apps";
import GedDocumentoCabecalhoList from "./GedDocumentoCabecalhoList";
import GedDocumentoCabecalhoCreate from "./GedDocumentoCabecalhoCreate";
import GedDocumentoCabecalhoEdit from "./GedDocumentoCabecalhoEdit";

export default {
	list: GedDocumentoCabecalhoList,
	create: GedDocumentoCabecalhoCreate,
	edit: GedDocumentoCabecalhoEdit,
	icon: GedDocumentoCabecalhoIcon,
};
