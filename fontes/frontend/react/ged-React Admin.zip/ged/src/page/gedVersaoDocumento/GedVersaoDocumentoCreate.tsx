import {
	Create,
} from "react-admin";
import { GedVersaoDocumentoForm } from "./GedVersaoDocumentoForm";

const GedVersaoDocumentoCreate = () => {
	return (
		<Create>
			<GedVersaoDocumentoForm />
		</Create>
	);
};

export default GedVersaoDocumentoCreate;