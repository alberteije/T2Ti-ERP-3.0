import {
	Edit,
} from "react-admin";
import { GedVersaoDocumentoForm } from "./GedVersaoDocumentoForm";

const GedVersaoDocumentoEdit = () => {
	return (
		<Edit>
			<GedVersaoDocumentoForm />
		</Edit>
	);
};

export default GedVersaoDocumentoEdit;