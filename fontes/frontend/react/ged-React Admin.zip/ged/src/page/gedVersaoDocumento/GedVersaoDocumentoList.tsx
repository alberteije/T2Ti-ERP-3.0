/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import GedVersaoDocumentoDomain from '../../data/domain/GedVersaoDocumentoDomain';

const GedVersaoDocumentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["gedDocumentoDetalheModel.nome","viewPessoaColaboradorModel.nome","acao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? GedVersaoDocumentoSmallScreenList : GedVersaoDocumentoBigScreenList;

	return (
		<List
			title="Versionamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const GedVersaoDocumentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.gedDocumentoDetalheModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.acao }
		/>
	);
}

const GedVersaoDocumentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Ged Documento Detalhe" source="gedDocumentoDetalheModel.id" reference="ged-documento-detalhe" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				label="Acao"
				render={record => GedVersaoDocumentoDomain.getAcao(record.acao)}
			/>
			<TextField source="versao" label="Versao" />
			<TextField source="dataVersao" label="Data Versao" />
			<FunctionField
				source="horaVersao"
				label="Hora Versao"
				render={record => formatWithMask(record.horaVersao, '##:##:##')}
			/>
			<TextField source="hashArquivo" label="Hash Arquivo" />
			<TextField source="caminho" label="Caminho" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default GedVersaoDocumentoList;
