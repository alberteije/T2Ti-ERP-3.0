import GedVersaoDocumentoIcon from "@mui/icons-material/Apps";
import GedVersaoDocumentoList from "./GedVersaoDocumentoList";
import GedVersaoDocumentoCreate from "./GedVersaoDocumentoCreate";
import GedVersaoDocumentoEdit from "./GedVersaoDocumentoEdit";

export default {
	list: GedVersaoDocumentoList,
	create: GedVersaoDocumentoCreate,
	edit: GedVersaoDocumentoEdit,
	icon: GedVersaoDocumentoIcon,
};
