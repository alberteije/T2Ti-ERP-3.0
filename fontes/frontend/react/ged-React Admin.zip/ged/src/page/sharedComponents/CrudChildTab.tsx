/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from 'react';
import {
	Button,
	useRecordContext,
	useInput,
	ArrayField,
	Datagrid,
	Form,
	useTranslate,
	FunctionField,
	ReferenceField,
	TextField,
} from 'react-admin';
import {
	Box,
	Dialog,
	DialogContent,
	AppBar,
	Toolbar,
	IconButton,
	Typography,
	Tooltip,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import ConfirmationDialog from '../sharedComponents/ConfirmationDialog';
import CustomSnackbar from '../sharedComponents/CustomSnackbar';

interface CrudChildTabProps {
	title: string,
	recordContext: string;
	fieldSource: string;
	newObject: any;
	renderForm: (currentRecord: any, setCurrentRecord: (record: any) => void) => JSX.Element;
	fields: any
}

const CrudChildTab: React.FC<CrudChildTabProps> = ({
	title,
	fieldSource,
	newObject,
	renderForm,
	fields,
}) => {
	const translate = useTranslate();
	const record = useRecordContext();
	const [currentRecord, setCurrentRecord] = useState<any>(newObject);
	const { field } = useInput({
		source: fieldSource,
		defaultValue: record?.[fieldSource] || [],
	});
	const [openEditInsertModal, setOpenEditInsertModal] = useState(false);
	const [openConfirmationDialog, setOpenConfirmationDialog] = useState(false);
	const [openSnackbar, setOpenSnackbar] = useState(false);

	const handleSnackbarClose = () => {
		setOpenSnackbar(false);
	};

	const handleOpenConfirmationDialog = () => {
		setOpenConfirmationDialog(true);
	};

	const handleSetStatusCrudToR = () => {
		const updatedList = field.value.map((item: any) => {
			return { ...item, statusCrud: "R" };
		});
		field.onChange(updatedList);
	};

	const handleOpenEditInsertModal = (record: any) => {
		setCurrentRecord(record);
		setOpenEditInsertModal(true);
	};

	const handleCloseEditInsertModal = () => {
		setOpenEditInsertModal(false);
		handleSetStatusCrudToR();
		setCurrentRecord(newObject);
	};

	const handleSave = () => {
		if (currentRecord.statusCrud === 'C') {
			const newItem = { ...currentRecord, id: Date.now() };
			field.onChange([...field.value, newItem]);
		} else {
			const updatedList = field.value.map((item: any) => {
				if (item.id === currentRecord.id) {
					return { ...item, ...currentRecord, statusCrud: "R" };
				}
				return item;
			});
			field.onChange(updatedList);
		}
		setOpenEditInsertModal(false);
		setCurrentRecord(newObject);
	};

	const handleConfirmDelete = (confirm: boolean) => {
		setOpenConfirmationDialog(false);
		if (confirm) {
			handleDelete();
			setOpenSnackbar(true);
		} else {
			const updatedList = field.value.map((item: any) => {
				return { ...item, statusCrud: "R" };
			});
			field.onChange(updatedList);
		}
	};

	const handleDelete = () => {
		const newList = field.value.filter((item: any) => item.statusCrud !== 'D');
		field.onChange(newList);
	};

	return (
		<Box>
			<Button
				color="primary"
				startIcon={<AddIcon />}
				size="small"
				label={translate('ra.action.create')}
				onClick={() => handleOpenEditInsertModal(newObject)}
			/>

			<ArrayField
				source={fieldSource}
				record={{ [fieldSource]: field.value }}
			>
				<Datagrid bulkActionButtons={false} rowClick={false} >
					{fields.map((field: any) => {
						if (field.formatMask) {
							return (
								<FunctionField
									key={field.source}
									source={field.source}
									label={field.label}
									render={(record) => field.formatMask(record[field.source], field.mask)}
								/>
							);
						} else if (field.reference) {
							return (
								<ReferenceField key={field.source} source={field.source} label={field.label} reference={field.reference} sortable={false}>
									<TextField source={field.fieldName} />
								</ReferenceField>
							);
						} else if (field.formatDomain) {
							return (
								<FunctionField
									key={field.source}
									source={field.source}
									label={field.label}
									render={(record) => field.formatDomain(record[field.source])}
								/>
							);
						} else {
							return <TextField key={field.source} source={field.source} label={field.label} />;
						}
					})}
					<FunctionField
						render={(record) => {
							return (<>
								<Button
									label={translate('ra.action.edit')}
									onClick={(e) => {
										e.stopPropagation();
										record.statusCrud = "U";
										handleOpenEditInsertModal(record);
									}}
								/>
								<Button
									label={translate('ra.action.delete')}
									onClick={(e) => {
										e.stopPropagation();
										const newList = field.value.map((item: any) => {
											if (item.id === record.id) {
												return { ...item, statusCrud: 'D' };
											}
											return item;
										});
										field.onChange(newList);
										handleOpenConfirmationDialog();
									}}
								/>
							</>);
						}}
					/>
				</Datagrid>
			</ArrayField>

			<ConfirmationDialog
				title={translate('dialogs.confirm_delete_title')}
				question={translate('dialogs.confirm_delete_body')}
				open={openConfirmationDialog}
				onClose={handleConfirmDelete}
			/>

			<CustomSnackbar
				message={translate('dialogs.snackbar_delete_message')}
				open={openSnackbar}
				onClose={handleSnackbarClose}
			/>

			<Dialog
				open={openEditInsertModal}
				onClose={handleCloseEditInsertModal}
				fullWidth
				maxWidth="md"
			>
				<AppBar sx={{ position: 'relative' }}>
					<Toolbar>
						<Tooltip title={translate('ra.action.close')}>
							<IconButton
								edge="start"
								color="inherit"
								onClick={handleCloseEditInsertModal}
								aria-label="close"
							>
								<CloseIcon />
							</IconButton>
						</Tooltip>
						<Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
							{currentRecord.statusCrud === 'C'
								? `${title} - ${translate('general.adding')}`
								: `${title} - ${translate('general.editing')}`}
						</Typography>
						<Tooltip title={translate('ra.action.save')}>
							<IconButton
								edge="start"
								color="inherit"
								onClick={handleSave}
								aria-label="close"
							>
								<SaveIcon />
							</IconButton>
						</Tooltip>
					</Toolbar>
				</AppBar>
				<DialogContent>
					<Form defaultValues={currentRecord}>
						{renderForm(currentRecord, setCurrentRecord)}
					</Form>
				</DialogContent>
			</Dialog>
		</Box>
	);
};

export default CrudChildTab;