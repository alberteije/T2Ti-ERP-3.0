/* eslint-disable react/jsx-key */
import {
	TextInput,
	TopToolbar,
	CreateButton,
	ExportButton,
	SortButton,
	SelectColumnsButton,
} from "react-admin";

export const DefaultFilters = [
	<TextInput source="q" label="Search" alwaysOn />,
];

export const BigScreenActions = () => (
	<TopToolbar>
		<SelectColumnsButton />
		<CreateButton />
		<ExportButton />
	</TopToolbar>
);

export const SmallScreenActions = ({ fields }: { fields: string[] }) => (
	<TopToolbar>
		<SortButton fields={fields} />
		<ExportButton />
		<CreateButton sx={{ marginLeft: 2 }} />
	</TopToolbar>
);