import {
	Edit,
} from "react-admin";
import { OsEquipamentoForm } from "./OsEquipamentoForm";

const OsEquipamentoEdit = () => {
	return (
		<Edit>
			<OsEquipamentoForm />
		</Edit>
	);
};

export default OsEquipamentoEdit;