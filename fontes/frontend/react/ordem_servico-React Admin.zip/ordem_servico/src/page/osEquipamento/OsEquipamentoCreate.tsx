import {
	Create,
} from "react-admin";
import { OsEquipamentoForm } from "./OsEquipamentoForm";

const OsEquipamentoCreate = () => {
	return (
		<Create>
			<OsEquipamentoForm />
		</Create>
	);
};

export default OsEquipamentoCreate;