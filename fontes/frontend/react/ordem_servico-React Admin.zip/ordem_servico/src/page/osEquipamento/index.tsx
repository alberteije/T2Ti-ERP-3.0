import OsEquipamentoIcon from "@mui/icons-material/Apps";
import OsEquipamentoList from "./OsEquipamentoList";
import OsEquipamentoCreate from "./OsEquipamentoCreate";
import OsEquipamentoEdit from "./OsEquipamentoEdit";

export default {
	list: OsEquipamentoList,
	create: OsEquipamentoCreate,
	edit: OsEquipamentoEdit,
	icon: OsEquipamentoIcon,
};
