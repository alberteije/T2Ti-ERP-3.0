import OsStatusIcon from "@mui/icons-material/Apps";
import OsStatusList from "./OsStatusList";
import OsStatusCreate from "./OsStatusCreate";
import OsStatusEdit from "./OsStatusEdit";

export default {
	list: OsStatusList,
	create: OsStatusCreate,
	edit: OsStatusEdit,
	icon: OsStatusIcon,
};
