import {
	Edit,
} from "react-admin";
import { OsStatusForm } from "./OsStatusForm";

const OsStatusEdit = () => {
	return (
		<Edit>
			<OsStatusForm />
		</Edit>
	);
};

export default OsStatusEdit;