import {
	Create,
} from "react-admin";
import { OsStatusForm } from "./OsStatusForm";

const OsStatusCreate = () => {
	return (
		<Create>
			<OsStatusForm />
		</Create>
	);
};

export default OsStatusCreate;