import OsAberturaIcon from "@mui/icons-material/Apps";
import OsAberturaList from "./OsAberturaList";
import OsAberturaCreate from "./OsAberturaCreate";
import OsAberturaEdit from "./OsAberturaEdit";

export default {
	list: OsAberturaList,
	create: OsAberturaCreate,
	edit: OsAberturaEdit,
	icon: OsAberturaIcon,
};
