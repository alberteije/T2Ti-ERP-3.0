/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { OsAberturaForm } from "./OsAberturaForm";
import { transformNestedData } from "../../infra/utils";

const OsAberturaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<OsAberturaForm />
		</Create>
	);
};

export default OsAberturaCreate;