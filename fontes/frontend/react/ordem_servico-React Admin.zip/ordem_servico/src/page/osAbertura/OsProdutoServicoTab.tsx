/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import OsProdutoServicoDomain from '../../data/domain/OsProdutoServicoDomain';

class OsProdutoServico {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): OsProdutoServico {
		const osProdutoServico = new OsProdutoServico();
		osProdutoServico.id = Date.now();
		osProdutoServico.statusCrud = "C";
		return osProdutoServico;
	}
}

export const OsProdutoServicoTab: React.FC = () => {

	const renderForm = (
		currentRecord: OsProdutoServico,
		setCurrentRecord: (record: OsProdutoServico) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'tipo', label: 'Tipo', formatDomain: OsProdutoServicoDomain.getTipo },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'quantidade', label: 'Quantidade' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
	];

	return (
		<CrudChildTab
			title="Produto ou Serviço"
			recordContext="osAbertura"
			fieldSource="osProdutoServicoModelList"
			newObject={ OsProdutoServico.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};