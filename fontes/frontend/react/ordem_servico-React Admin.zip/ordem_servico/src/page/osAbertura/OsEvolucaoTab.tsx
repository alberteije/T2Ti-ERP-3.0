/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import OsEvolucaoDomain from '../../data/domain/OsEvolucaoDomain';

class OsEvolucao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): OsEvolucao {
		const osEvolucao = new OsEvolucao();
		osEvolucao.id = Date.now();
		osEvolucao.statusCrud = "C";
		return osEvolucao;
	}
}

export const OsEvolucaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: OsEvolucao,
		setCurrentRecord: (record: OsEvolucao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataRegistro', label: 'Data Registro' },
		{ source: 'horaRegistro', label: 'Hora Registro', formatMask: formatWithMask, mask: '##:##:##' },
		{ source: 'enviarEmail', label: 'Enviar Email', formatDomain: OsEvolucaoDomain.getEnviarEmail },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Evolução"
			recordContext="osAbertura"
			fieldSource="osEvolucaoModelList"
			newObject={ OsEvolucao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};