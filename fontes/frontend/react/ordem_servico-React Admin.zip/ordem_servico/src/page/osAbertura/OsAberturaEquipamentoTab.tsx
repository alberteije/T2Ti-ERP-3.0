/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import OsAberturaEquipamentoDomain from '../../data/domain/OsAberturaEquipamentoDomain';

class OsAberturaEquipamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): OsAberturaEquipamento {
		const osAberturaEquipamento = new OsAberturaEquipamento();
		osAberturaEquipamento.id = Date.now();
		osAberturaEquipamento.statusCrud = "C";
		return osAberturaEquipamento;
	}
}

export const OsAberturaEquipamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: OsAberturaEquipamento,
		setCurrentRecord: (record: OsAberturaEquipamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'osEquipamentoModel.id', label: 'Equipamento', reference: 'os-equipamento', fieldName: 'nome' },
		{ source: 'tipoCobertura', label: 'Tipo Cobertura', formatDomain: OsAberturaEquipamentoDomain.getTipoCobertura },
		{ source: 'numeroSerie', label: 'Numero Serie' },
	];

	return (
		<CrudChildTab
			title="Equipamentos"
			recordContext="osAbertura"
			fieldSource="osAberturaEquipamentoModelList"
			newObject={ OsAberturaEquipamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};