/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const OsAberturaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["osStatusModel.nome","viewPessoaColaboradorModel.nome","viewPessoaClienteModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? OsAberturaSmallScreenList : OsAberturaBigScreenList;

	return (
		<List
			title="Abertura OS"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const OsAberturaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.osStatusModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.viewPessoaClienteModel.nome }
		/>
	);
}

const OsAberturaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Os Status" source="osStatusModel.id" reference="os-status" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="horaInicio" label="Hora Inicio" />
			<TextField source="dataPrevisao" label="Data Previsao" />
			<FunctionField
				source="horaPrevisao"
				label="Hora Previsao"
				render={record => formatWithMask(record.horaPrevisao, '##:##:##')}
			/>
			<TextField source="dataFim" label="Data Fim" />
			<FunctionField
				source="horaFim"
				label="Hora Fim"
				render={record => formatWithMask(record.horaFim, '##:##:##')}
			/>
			<TextField source="nomeContato" label="Nome Contato" />
			<FunctionField
				source="foneContato"
				label="Fone Contato"
				render={record => formatWithMask(record.foneContato, '(##)#####-####')}
			/>
			<TextField source="observacaoCliente" label="Observacao Cliente" />
			<TextField source="observacaoAbertura" label="Observacao Abertura" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default OsAberturaList;
