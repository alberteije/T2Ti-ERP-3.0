class OsProdutoServicoDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'P': 
				return 'Produto'; 
			case 'S': 
				return 'Serviço'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Produto': 
				return 'P'; 
			case 'Serviço': 
				return 'S'; 
			default: 
				return null; 
		} 
	}

}

export default OsProdutoServicoDomain;