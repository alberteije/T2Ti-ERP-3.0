class OsAberturaEquipamentoDomain {
	static getTipoCobertura(tipoCobertura: string) { 
		switch (tipoCobertura) { 
			case '': 
			case 'N': 
				return 'Nenhum'; 
			case 'G': 
				return 'Garantia'; 
			case 'S': 
				return 'Seguro'; 
			case 'C': 
				return 'Contrato'; 
			default: 
				return null; 
		} 
	} 

	static setTipoCobertura(tipoCobertura: string) { 
		switch (tipoCobertura) { 
			case 'Nenhum': 
				return 'N'; 
			case 'Garantia': 
				return 'G'; 
			case 'Seguro': 
				return 'S'; 
			case 'Contrato': 
				return 'C'; 
			default: 
				return null; 
		} 
	}

}

export default OsAberturaEquipamentoDomain;