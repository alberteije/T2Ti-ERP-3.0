class OsEvolucaoDomain {
	static getEnviarEmail(enviarEmail: string) { 
		switch (enviarEmail) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setEnviarEmail(enviarEmail: string) { 
		switch (enviarEmail) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default OsEvolucaoDomain;