import {
	Edit,
} from "react-admin";
import { ComissaoPerfilForm } from "./ComissaoPerfilForm";

const ComissaoPerfilEdit = () => {
	return (
		<Edit>
			<ComissaoPerfilForm />
		</Edit>
	);
};

export default ComissaoPerfilEdit;