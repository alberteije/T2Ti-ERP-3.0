import ComissaoPerfilIcon from "@mui/icons-material/Apps";
import ComissaoPerfilList from "./ComissaoPerfilList";
import ComissaoPerfilCreate from "./ComissaoPerfilCreate";
import ComissaoPerfilEdit from "./ComissaoPerfilEdit";

export default {
	list: ComissaoPerfilList,
	create: ComissaoPerfilCreate,
	edit: ComissaoPerfilEdit,
	icon: ComissaoPerfilIcon,
};
