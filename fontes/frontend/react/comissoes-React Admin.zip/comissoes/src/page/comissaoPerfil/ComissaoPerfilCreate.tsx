import {
	Create,
} from "react-admin";
import { ComissaoPerfilForm } from "./ComissaoPerfilForm";

const ComissaoPerfilCreate = () => {
	return (
		<Create>
			<ComissaoPerfilForm />
		</Create>
	);
};

export default ComissaoPerfilCreate;