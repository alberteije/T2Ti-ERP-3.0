import {
	Create,
} from "react-admin";
import { ComissaoObjetivoForm } from "./ComissaoObjetivoForm";

const ComissaoObjetivoCreate = () => {
	return (
		<Create>
			<ComissaoObjetivoForm />
		</Create>
	);
};

export default ComissaoObjetivoCreate;