/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ComissaoObjetivoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["comissaoPerfilModel.nome","codigo","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ComissaoObjetivoSmallScreenList : ComissaoObjetivoBigScreenList;

	return (
		<List
			title="Objetivos e Metas"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ComissaoObjetivoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.comissaoPerfilModel.nome }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.nome }
		/>
	);
}

const ComissaoObjetivoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Comissao Perfil" source="comissaoPerfilModel.id" reference="comissao-perfil" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<NumberField source="taxaPagamento" label="Taxa Pagamento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPagamento" label="Valor Pagamento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorMeta" label="Valor Meta" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataFim" label="Data Fim" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ComissaoObjetivoList;
