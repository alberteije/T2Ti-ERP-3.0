import ComissaoObjetivoIcon from "@mui/icons-material/Apps";
import ComissaoObjetivoList from "./ComissaoObjetivoList";
import ComissaoObjetivoCreate from "./ComissaoObjetivoCreate";
import ComissaoObjetivoEdit from "./ComissaoObjetivoEdit";

export default {
	list: ComissaoObjetivoList,
	create: ComissaoObjetivoCreate,
	edit: ComissaoObjetivoEdit,
	icon: ComissaoObjetivoIcon,
};
