import {
	Edit,
} from "react-admin";
import { ComissaoObjetivoForm } from "./ComissaoObjetivoForm";

const ComissaoObjetivoEdit = () => {
	return (
		<Edit>
			<ComissaoObjetivoForm />
		</Edit>
	);
};

export default ComissaoObjetivoEdit;