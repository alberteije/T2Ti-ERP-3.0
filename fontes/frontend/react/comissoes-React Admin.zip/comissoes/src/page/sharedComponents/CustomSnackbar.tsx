import React from 'react';
import { Snackbar, Alert } from '@mui/material';

interface SnackbarProps {
  message: string;
  backgroundColor?: string;
  open: boolean;
  onClose: () => void;
}

const CustomSnackbar: React.FC<SnackbarProps> = ({ message, backgroundColor = '#323232', open, onClose }) => {
  return (
    <Snackbar
      open={open}
      autoHideDuration={6000}
      onClose={onClose}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }} 
    >
      <Alert
        onClose={onClose}
        severity="info"
        sx={{ backgroundColor: backgroundColor, color: '#fff' }} 
      >
        {message}
      </Alert>
    </Snackbar>
  );
};

export default CustomSnackbar;