/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { VendaOrcamentoCabecalhoForm } from "./VendaOrcamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const VendaOrcamentoCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<VendaOrcamentoCabecalhoForm />
		</Edit>
	);
};

export default VendaOrcamentoCabecalhoEdit;