/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { VendaOrcamentoCabecalhoForm } from "./VendaOrcamentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const VendaOrcamentoCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<VendaOrcamentoCabecalhoForm />
		</Create>
	);
};

export default VendaOrcamentoCabecalhoCreate;