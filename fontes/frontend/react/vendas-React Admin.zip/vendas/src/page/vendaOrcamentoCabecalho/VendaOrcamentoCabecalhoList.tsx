/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import VendaOrcamentoCabecalhoDomain from '../../data/domain/VendaOrcamentoCabecalhoDomain';

const VendaOrcamentoCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaVendedorModel.nome","viewPessoaClienteModel.nome","vendaCondicoesPagamentoModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? VendaOrcamentoCabecalhoSmallScreenList : VendaOrcamentoCabecalhoBigScreenList;

	return (
		<List
			title="Orçamento de Venda"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const VendaOrcamentoCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaVendedorModel.nome }
			secondaryText={ (record) => record.viewPessoaClienteModel.nome }
			tertiaryText={ (record) => record.vendaCondicoesPagamentoModel.nome }
		/>
	);
}

const VendaOrcamentoCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Vendedor" source="viewPessoaVendedorModel.id" reference="view-pessoa-vendedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Venda Condicoes Pagamento" source="vendaCondicoesPagamentoModel.id" reference="venda-condicoes-pagamento" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Transportadora" source="viewPessoaTransportadoraModel.id" reference="view-pessoa-transportadora" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<FunctionField
				label="Tipo Frete"
				render={record => VendaOrcamentoCabecalhoDomain.getTipoFrete(record.tipoFrete)}
			/>
			<TextField source="codigo" label="Codigo" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<TextField source="dataEntrega" label="Data Entrega" />
			<TextField source="dataValidade" label="Data Validade" />
			<NumberField source="valorSubtotal" label="Valor Subtotal" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorFrete" label="Valor Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaComissao" label="Taxa Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorComissao" label="Valor Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaDesconto" label="Taxa Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default VendaOrcamentoCabecalhoList;
