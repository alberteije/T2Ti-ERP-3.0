/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class VendaOrcamentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): VendaOrcamentoDetalhe {
		const vendaOrcamentoDetalhe = new VendaOrcamentoDetalhe();
		vendaOrcamentoDetalhe.id = Date.now();
		vendaOrcamentoDetalhe.statusCrud = "C";
		return vendaOrcamentoDetalhe;
	}
}

export const VendaOrcamentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: VendaOrcamentoDetalhe,
		setCurrentRecord: (record: VendaOrcamentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
	];

	return (
		<CrudChildTab
			title="Itens do Orçamento"
			recordContext="vendaOrcamentoCabecalho"
			fieldSource="vendaOrcamentoDetalheModelList"
			newObject={ VendaOrcamentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};