import VendaOrcamentoCabecalhoIcon from "@mui/icons-material/Apps";
import VendaOrcamentoCabecalhoList from "./VendaOrcamentoCabecalhoList";
import VendaOrcamentoCabecalhoCreate from "./VendaOrcamentoCabecalhoCreate";
import VendaOrcamentoCabecalhoEdit from "./VendaOrcamentoCabecalhoEdit";

export default {
	list: VendaOrcamentoCabecalhoList,
	create: VendaOrcamentoCabecalhoCreate,
	edit: VendaOrcamentoCabecalhoEdit,
	icon: VendaOrcamentoCabecalhoIcon,
};
