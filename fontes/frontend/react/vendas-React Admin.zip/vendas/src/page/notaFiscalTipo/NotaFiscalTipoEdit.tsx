import {
	Edit,
} from "react-admin";
import { NotaFiscalTipoForm } from "./NotaFiscalTipoForm";

const NotaFiscalTipoEdit = () => {
	return (
		<Edit>
			<NotaFiscalTipoForm />
		</Edit>
	);
};

export default NotaFiscalTipoEdit;