/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NotaFiscalTipoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["notaFiscalModeloModel.modelo","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NotaFiscalTipoSmallScreenList : NotaFiscalTipoBigScreenList;

	return (
		<List
			title="Tipo de Nota Fiscal"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NotaFiscalTipoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.notaFiscalModeloModel.modelo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const NotaFiscalTipoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nota Fiscal Modelo" source="notaFiscalModeloModel.id" reference="nota-fiscal-modelo" sortable={false}>
				<TextField source="modelo" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="serie" label="Serie" />
			<TextField source="serieScan" label="Serie Scan" />
			<TextField source="ultimoNumero" label="Ultimo Numero" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NotaFiscalTipoList;
