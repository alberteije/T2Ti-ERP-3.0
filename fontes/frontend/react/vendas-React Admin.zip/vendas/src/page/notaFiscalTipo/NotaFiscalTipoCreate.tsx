import {
	Create,
} from "react-admin";
import { NotaFiscalTipoForm } from "./NotaFiscalTipoForm";

const NotaFiscalTipoCreate = () => {
	return (
		<Create>
			<NotaFiscalTipoForm />
		</Create>
	);
};

export default NotaFiscalTipoCreate;