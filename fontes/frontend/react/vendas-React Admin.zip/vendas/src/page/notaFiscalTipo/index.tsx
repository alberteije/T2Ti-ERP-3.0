import NotaFiscalTipoIcon from "@mui/icons-material/Apps";
import NotaFiscalTipoList from "./NotaFiscalTipoList";
import NotaFiscalTipoCreate from "./NotaFiscalTipoCreate";
import NotaFiscalTipoEdit from "./NotaFiscalTipoEdit";

export default {
	list: NotaFiscalTipoList,
	create: NotaFiscalTipoCreate,
	edit: NotaFiscalTipoEdit,
	icon: NotaFiscalTipoIcon,
};
