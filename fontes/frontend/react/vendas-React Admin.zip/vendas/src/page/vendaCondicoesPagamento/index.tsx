import VendaCondicoesPagamentoIcon from "@mui/icons-material/Apps";
import VendaCondicoesPagamentoList from "./VendaCondicoesPagamentoList";
import VendaCondicoesPagamentoCreate from "./VendaCondicoesPagamentoCreate";
import VendaCondicoesPagamentoEdit from "./VendaCondicoesPagamentoEdit";

export default {
	list: VendaCondicoesPagamentoList,
	create: VendaCondicoesPagamentoCreate,
	edit: VendaCondicoesPagamentoEdit,
	icon: VendaCondicoesPagamentoIcon,
};
