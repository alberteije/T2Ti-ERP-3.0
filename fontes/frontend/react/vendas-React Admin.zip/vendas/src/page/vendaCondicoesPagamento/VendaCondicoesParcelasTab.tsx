/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class VendaCondicoesParcelas {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): VendaCondicoesParcelas {
		const vendaCondicoesParcelas = new VendaCondicoesParcelas();
		vendaCondicoesParcelas.id = Date.now();
		vendaCondicoesParcelas.statusCrud = "C";
		return vendaCondicoesParcelas;
	}
}

export const VendaCondicoesParcelasTab: React.FC = () => {

	const renderForm = (
		currentRecord: VendaCondicoesParcelas,
		setCurrentRecord: (record: VendaCondicoesParcelas) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'parcela', label: 'Parcela' },
		{ source: 'dias', label: 'Dias a Partir da Venda' },
		{ source: 'taxa', label: '% da Parcela' },
	];

	return (
		<CrudChildTab
			title="Parcelas"
			recordContext="vendaCondicoesPagamento"
			fieldSource="vendaCondicoesParcelasModelList"
			newObject={ VendaCondicoesParcelas.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};