/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import VendaCondicoesPagamentoDomain from '../../data/domain/VendaCondicoesPagamentoDomain';

const VendaCondicoesPagamentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","descricao","faturamentoMinimo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? VendaCondicoesPagamentoSmallScreenList : VendaCondicoesPagamentoBigScreenList;

	return (
		<List
			title="Condições de Pagamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const VendaCondicoesPagamentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.faturamentoMinimo }
		/>
	);
}

const VendaCondicoesPagamentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<NumberField source="faturamentoMinimo" label="Faturamento Minimo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="faturamentoMaximo" label="Faturamento Maximo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="indiceCorrecao" label="Indice Correcao" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="diasTolerancia" label="Dias Tolerancia" />
			<NumberField source="valorTolerancia" label="Valor Tolerancia" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="prazoMedio" label="Prazo Medio" />
			<FunctionField
				label="Vista Prazo"
				render={record => VendaCondicoesPagamentoDomain.getVistaPrazo(record.vistaPrazo)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default VendaCondicoesPagamentoList;
