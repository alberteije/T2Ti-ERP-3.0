/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { VendaCondicoesPagamentoForm } from "./VendaCondicoesPagamentoForm";
import { transformNestedData } from "../../infra/utils";

const VendaCondicoesPagamentoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<VendaCondicoesPagamentoForm />
		</Create>
	);
};

export default VendaCondicoesPagamentoCreate;