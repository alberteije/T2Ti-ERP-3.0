/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { VendaComissaoTab } from './VendaComissaoTab';
import { VendaDetalheTab } from './VendaDetalheTab';
import { VendaFreteTab } from './VendaFreteTab';

export const VendaCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Venda">
				<VendaCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Comissão">
				<VendaComissaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens da Venda">
				<VendaDetalheTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Frete">
				<VendaFreteTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const VendaCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};