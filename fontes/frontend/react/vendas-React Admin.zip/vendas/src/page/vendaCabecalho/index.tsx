import VendaCabecalhoIcon from "@mui/icons-material/Apps";
import VendaCabecalhoList from "./VendaCabecalhoList";
import VendaCabecalhoCreate from "./VendaCabecalhoCreate";
import VendaCabecalhoEdit from "./VendaCabecalhoEdit";

export default {
	list: VendaCabecalhoList,
	create: VendaCabecalhoCreate,
	edit: VendaCabecalhoEdit,
	icon: VendaCabecalhoIcon,
};
