/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class VendaDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): VendaDetalhe {
		const vendaDetalhe = new VendaDetalhe();
		vendaDetalhe.id = Date.now();
		vendaDetalhe.statusCrud = "C";
		return vendaDetalhe;
	}
}

export const VendaDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: VendaDetalhe,
		setCurrentRecord: (record: VendaDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
	];

	return (
		<CrudChildTab
			title="Itens da Venda"
			recordContext="vendaCabecalho"
			fieldSource="vendaDetalheModelList"
			newObject={ VendaDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};