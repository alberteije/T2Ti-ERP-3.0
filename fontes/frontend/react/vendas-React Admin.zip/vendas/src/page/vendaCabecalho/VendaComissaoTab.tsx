/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from "react-admin";
import { Box } from "@mui/material";

export const VendaComissaoTab = () => (
	<>
		</Box>
	</>
);