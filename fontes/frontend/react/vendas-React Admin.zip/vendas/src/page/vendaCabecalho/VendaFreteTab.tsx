/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import VendaFreteDomain from '../../data/domain/VendaFreteDomain';

class VendaFrete {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): VendaFrete {
		const vendaFrete = new VendaFrete();
		vendaFrete.id = Date.now();
		vendaFrete.statusCrud = "C";
		return vendaFrete;
	}
}

export const VendaFreteTab: React.FC = () => {

	const renderForm = (
		currentRecord: VendaFrete,
		setCurrentRecord: (record: VendaFrete) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'viewPessoaTransportadoraModel.id', label: 'Transportadora', reference: 'view-pessoa-transportadora', fieldName: 'nome' },
		{ source: 'responsavel', label: 'Responsavel', formatDomain: VendaFreteDomain.getResponsavel },
		{ source: 'conhecimento', label: 'Conhecimento' },
		{ source: 'placa', label: 'Placa' },
		{ source: 'ufPlaca', label: 'Uf Placa', formatDomain: VendaFreteDomain.getUfPlaca },
		{ source: 'seloFiscal', label: 'Selo Fiscal' },
		{ source: 'quantidadeVolume', label: 'Quantidade Volume' },
		{ source: 'marcaVolume', label: 'Marca Volume' },
		{ source: 'especieVolume', label: 'Especie Volume' },
		{ source: 'pesoBruto', label: 'Peso Bruto' },
		{ source: 'pesoLiquido', label: 'Peso Liquido' },
	];

	return (
		<CrudChildTab
			title="Frete"
			recordContext="vendaCabecalho"
			fieldSource="vendaFreteModelList"
			newObject={ VendaFrete.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};