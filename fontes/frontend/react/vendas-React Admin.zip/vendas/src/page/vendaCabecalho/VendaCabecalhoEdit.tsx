/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { VendaCabecalhoForm } from "./VendaCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const VendaCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<VendaCabecalhoForm />
		</Edit>
	);
};

export default VendaCabecalhoEdit;