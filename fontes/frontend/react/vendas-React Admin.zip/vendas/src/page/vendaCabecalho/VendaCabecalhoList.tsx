/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import VendaCabecalhoDomain from '../../data/domain/VendaCabecalhoDomain';

const VendaCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["vendaOrcamentoCabecalhoModel.codigo","notaFiscalTipoModel.nome","viewPessoaVendedorModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? VendaCabecalhoSmallScreenList : VendaCabecalhoBigScreenList;

	return (
		<List
			title="Venda"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const VendaCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.vendaOrcamentoCabecalhoModel.codigo }
			secondaryText={ (record) => record.notaFiscalTipoModel.nome }
			tertiaryText={ (record) => record.viewPessoaVendedorModel.nome }
		/>
	);
}

const VendaCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Venda Orcamento Cabecalho" source="vendaOrcamentoCabecalhoModel.id" reference="venda-orcamento-cabecalho" sortable={false}>
				<TextField source="codigo" />
			</ReferenceField>
			<ReferenceField label="Id Nota Fiscal Tipo" source="notaFiscalTipoModel.id" reference="nota-fiscal-tipo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Vendedor" source="viewPessoaVendedorModel.id" reference="view-pessoa-vendedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Venda Condicoes Pagamento" source="vendaCondicoesPagamentoModel.id" reference="venda-condicoes-pagamento" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Transportadora" source="viewPessoaTransportadoraModel.id" reference="view-pessoa-transportadora" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="localEntrega" label="Local Entrega" />
			<TextField source="localCobranca" label="Local Cobranca" />
			<FunctionField
				label="Tipo Frete"
				render={record => VendaCabecalhoDomain.getTipoFrete(record.tipoFrete)}
			/>
			<FunctionField
				label="Forma Pagamento"
				render={record => VendaCabecalhoDomain.getFormaPagamento(record.formaPagamento)}
			/>
			<TextField source="dataVenda" label="Data Venda" />
			<TextField source="dataSaida" label="Data Saida" />
			<FunctionField
				source="horaSaida"
				label="Hora Saida"
				render={record => formatWithMask(record.horaSaida, '##:##:##')}
			/>
			<TextField source="numeroFatura" label="Numero Fatura" />
			<NumberField source="valorFrete" label="Valor Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSeguro" label="Valor Seguro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSubtotal" label="Valor Subtotal" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaComissao" label="Taxa Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorComissao" label="Valor Comissao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaDesconto" label="Taxa Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Situacao"
				render={record => VendaCabecalhoDomain.getSituacao(record.situacao)}
			/>
			<TextField source="diaFixoParcela" label="Dia Fixo Parcela" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default VendaCabecalhoList;
