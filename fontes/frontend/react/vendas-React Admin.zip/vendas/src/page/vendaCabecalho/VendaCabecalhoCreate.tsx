/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { VendaCabecalhoForm } from "./VendaCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const VendaCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<VendaCabecalhoForm />
		</Create>
	);
};

export default VendaCabecalhoCreate;