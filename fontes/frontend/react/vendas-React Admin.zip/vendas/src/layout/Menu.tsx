import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import vendaCondicoesPagamento from '../page/vendaCondicoesPagamento';
import vendaOrcamentoCabecalho from '../page/vendaOrcamentoCabecalho';
import vendaCabecalho from '../page/vendaCabecalho';
import notaFiscalTipo from '../page/notaFiscalTipo';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/nota-fiscal-tipo'
					state={{ _scrollToTop: true }}
					primaryText='Tipo de Nota Fiscal'
					leftIcon={<notaFiscalTipo.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/venda-condicoes-pagamento'
					state={{ _scrollToTop: true }}
					primaryText='Condições de Pagamento'
					leftIcon={<vendaCondicoesPagamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/venda-orcamento-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Orçamento de Venda'
					leftIcon={<vendaOrcamentoCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/venda-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Venda'
					leftIcon={<vendaCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
