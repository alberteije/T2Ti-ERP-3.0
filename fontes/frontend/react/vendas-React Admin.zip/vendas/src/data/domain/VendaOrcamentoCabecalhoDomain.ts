class VendaOrcamentoCabecalhoDomain {
	static getTipoFrete(tipoFrete: string) { 
		switch (tipoFrete) { 
			case '': 
			case 'C': 
				return 'CIF'; 
			case 'F': 
				return 'FOB'; 
			default: 
				return null; 
		} 
	} 

	static setTipoFrete(tipoFrete: string) { 
		switch (tipoFrete) { 
			case 'CIF': 
				return 'C'; 
			case 'FOB': 
				return 'F'; 
			default: 
				return null; 
		} 
	}

}

export default VendaOrcamentoCabecalhoDomain;