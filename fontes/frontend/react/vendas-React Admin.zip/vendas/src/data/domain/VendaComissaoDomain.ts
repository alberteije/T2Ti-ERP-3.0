class VendaComissaoDomain {
	static getTipoContabil(tipoContabil: string) { 
		switch (tipoContabil) { 
			case '': 
			case 'C': 
				return 'Crédito'; 
			case 'D': 
				return 'Débido'; 
			default: 
				return null; 
		} 
	} 

	static setTipoContabil(tipoContabil: string) { 
		switch (tipoContabil) { 
			case 'Crédito': 
				return 'C'; 
			case 'Débido': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

	static getSituacao(situacao: string) { 
		switch (situacao) { 
			case '': 
			case 'A': 
				return 'Aberto'; 
			case 'Q': 
				return 'Quitado'; 
			default: 
				return null; 
		} 
	} 

	static setSituacao(situacao: string) { 
		switch (situacao) { 
			case 'Aberto': 
				return 'A'; 
			case 'Quitado': 
				return 'Q'; 
			default: 
				return null; 
		} 
	}

}

export default VendaComissaoDomain;