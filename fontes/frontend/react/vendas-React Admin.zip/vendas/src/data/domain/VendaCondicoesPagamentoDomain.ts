class VendaCondicoesPagamentoDomain {
	static getVistaPrazo(vistaPrazo: string) { 
		switch (vistaPrazo) { 
			case '': 
			case '0': 
				return 'A Vista'; 
			case '1': 
				return 'A Prazo'; 
			default: 
				return null; 
		} 
	} 

	static setVistaPrazo(vistaPrazo: string) { 
		switch (vistaPrazo) { 
			case 'A Vista': 
				return '0'; 
			case 'A Prazo': 
				return '1'; 
			default: 
				return null; 
		} 
	}

}

export default VendaCondicoesPagamentoDomain;