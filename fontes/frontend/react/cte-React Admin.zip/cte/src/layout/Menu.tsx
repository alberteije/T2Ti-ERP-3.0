import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import cteCabecalho from '../page/cteCabecalho';
import cteInformacaoNfTransporte from '../page/cteInformacaoNfTransporte';
import cteInfNfTransporteLacre from '../page/cteInfNfTransporteLacre';
import cteInformacaoNfCarga from '../page/cteInformacaoNfCarga';
import cteInfNfCargaLacre from '../page/cteInfNfCargaLacre';
import cteDocumentoAnteriorId from '../page/cteDocumentoAnteriorId';
import cteRodoviarioOcc from '../page/cteRodoviarioOcc';
import cteRodoviarioPedagio from '../page/cteRodoviarioPedagio';
import cteRodoviarioVeiculo from '../page/cteRodoviarioVeiculo';
import cteRodoviarioLacre from '../page/cteRodoviarioLacre';
import cteRodoviarioMotorista from '../page/cteRodoviarioMotorista';
import cteAquaviarioBalsa from '../page/cteAquaviarioBalsa';
import cteFerroviarioFerrovia from '../page/cteFerroviarioFerrovia';
import cteFerroviarioVagao from '../page/cteFerroviarioVagao';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/cte-informacao-nf-transporte'
					state={{ _scrollToTop: true }}
					primaryText='Cte Informacao Nf Transporte'
					leftIcon={<cteInformacaoNfTransporte.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-inf-nf-transporte-lacre'
					state={{ _scrollToTop: true }}
					primaryText='Cte Inf Nf Transporte Lacre'
					leftIcon={<cteInfNfTransporteLacre.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-informacao-nf-carga'
					state={{ _scrollToTop: true }}
					primaryText='Cte Informacao Nf Carga'
					leftIcon={<cteInformacaoNfCarga.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-inf-nf-carga-lacre'
					state={{ _scrollToTop: true }}
					primaryText='Cte Inf Nf Carga Lacre'
					leftIcon={<cteInfNfCargaLacre.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-documento-anterior-id'
					state={{ _scrollToTop: true }}
					primaryText='Cte Documento Anterior Id'
					leftIcon={<cteDocumentoAnteriorId.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-rodoviario-occ'
					state={{ _scrollToTop: true }}
					primaryText='Cte Rodoviario Occ'
					leftIcon={<cteRodoviarioOcc.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-rodoviario-pedagio'
					state={{ _scrollToTop: true }}
					primaryText='Cte Rodoviario Pedagio'
					leftIcon={<cteRodoviarioPedagio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-rodoviario-veiculo'
					state={{ _scrollToTop: true }}
					primaryText='Cte Rodoviario Veiculo'
					leftIcon={<cteRodoviarioVeiculo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-rodoviario-lacre'
					state={{ _scrollToTop: true }}
					primaryText='Cte Rodoviario Lacre'
					leftIcon={<cteRodoviarioLacre.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-rodoviario-motorista'
					state={{ _scrollToTop: true }}
					primaryText='Cte Rodoviario Motorista'
					leftIcon={<cteRodoviarioMotorista.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-aquaviario-balsa'
					state={{ _scrollToTop: true }}
					primaryText='Cte Aquaviario Balsa'
					leftIcon={<cteAquaviarioBalsa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-ferroviario-ferrovia'
					state={{ _scrollToTop: true }}
					primaryText='Cte Ferroviario Ferrovia'
					leftIcon={<cteFerroviarioFerrovia.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cte-ferroviario-vagao'
					state={{ _scrollToTop: true }}
					primaryText='Cte Ferroviario Vagao'
					leftIcon={<cteFerroviarioVagao.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/cte-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='CT-e'
					leftIcon={<cteCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
