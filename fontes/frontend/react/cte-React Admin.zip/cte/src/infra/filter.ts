/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-useless-escape */

// take as a basis the following scheme to create the filter conditions (filter conditions)
// https://github.com/nestjsx/crud/wiki/Requests

export class FilterModel {
	field?: string;
	value?: string;
	initialDate?: string;
	finalDate?: string;
	condition?: string;
	where?: string;
}

export const handleFilter = (filterModel: FilterModel): string => {
	let stringFilter = '';

	if (filterModel && filterModel.condition) {
		if (filterModel.condition === 'cont') {
			stringFilter = `?filter=${filterModel.field}||\$cont||${filterModel.value}`;
		} else if (filterModel.condition === 'eq') {
			stringFilter = `?filter=${filterModel.field}||\$eq||${filterModel.value}`;
		} else if (filterModel.condition === 'between') {
			stringFilter = `?filter=${filterModel.field}||\$between||${filterModel.initialDate},${filterModel.finalDate}`;
		} else if (filterModel.condition === 'where') {
			stringFilter = filterModel.where || '';
		}
	}

	return stringFilter;
};