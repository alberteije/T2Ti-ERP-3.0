import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import cteCabecalho from './page/cteCabecalho';
import cteInformacaoNfTransporte from './page/cteInformacaoNfTransporte';
import cteInfNfTransporteLacre from './page/cteInfNfTransporteLacre';
import cteInformacaoNfCarga from './page/cteInformacaoNfCarga';
import cteInfNfCargaLacre from './page/cteInfNfCargaLacre';
import cteDocumentoAnteriorId from './page/cteDocumentoAnteriorId';
import cteRodoviarioOcc from './page/cteRodoviarioOcc';
import cteRodoviarioPedagio from './page/cteRodoviarioPedagio';
import cteRodoviarioVeiculo from './page/cteRodoviarioVeiculo';
import cteRodoviarioLacre from './page/cteRodoviarioLacre';
import cteRodoviarioMotorista from './page/cteRodoviarioMotorista';
import cteAquaviarioBalsa from './page/cteAquaviarioBalsa';
import cteFerroviarioFerrovia from './page/cteFerroviarioFerrovia';
import cteFerroviarioVagao from './page/cteFerroviarioVagao';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'cte');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - CTe (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='cte-cabecalho' {...cteCabecalho} options={{ label: 'CT-e' }} />
			<Resource name='cte-informacao-nf-transporte' {...cteInformacaoNfTransporte} options={{ label: 'Cte Informacao Nf Transporte' }} />
			<Resource name='cte-inf-nf-transporte-lacre' {...cteInfNfTransporteLacre} options={{ label: 'Cte Inf Nf Transporte Lacre' }} />
			<Resource name='cte-informacao-nf-carga' {...cteInformacaoNfCarga} options={{ label: 'Cte Informacao Nf Carga' }} />
			<Resource name='cte-inf-nf-carga-lacre' {...cteInfNfCargaLacre} options={{ label: 'Cte Inf Nf Carga Lacre' }} />
			<Resource name='cte-documento-anterior-id' {...cteDocumentoAnteriorId} options={{ label: 'Cte Documento Anterior Id' }} />
			<Resource name='cte-rodoviario-occ' {...cteRodoviarioOcc} options={{ label: 'Cte Rodoviario Occ' }} />
			<Resource name='cte-rodoviario-pedagio' {...cteRodoviarioPedagio} options={{ label: 'Cte Rodoviario Pedagio' }} />
			<Resource name='cte-rodoviario-veiculo' {...cteRodoviarioVeiculo} options={{ label: 'Cte Rodoviario Veiculo' }} />
			<Resource name='cte-rodoviario-lacre' {...cteRodoviarioLacre} options={{ label: 'Cte Rodoviario Lacre' }} />
			<Resource name='cte-rodoviario-motorista' {...cteRodoviarioMotorista} options={{ label: 'Cte Rodoviario Motorista' }} />
			<Resource name='cte-aquaviario-balsa' {...cteAquaviarioBalsa} options={{ label: 'Cte Aquaviario Balsa' }} />
			<Resource name='cte-ferroviario-ferrovia' {...cteFerroviarioFerrovia} options={{ label: 'Cte Ferroviario Ferrovia' }} />
			<Resource name='cte-ferroviario-vagao' {...cteFerroviarioVagao} options={{ label: 'Cte Ferroviario Vagao' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;