class CteMultimodalDomain {
	static getIndicadorNegociavel(indicadorNegociavel: string) { 
		switch (indicadorNegociavel) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setIndicadorNegociavel(indicadorNegociavel: string) { 
		switch (indicadorNegociavel) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default CteMultimodalDomain;