class CteAereoDomain {
	static getTarifaClasse(tarifaClasse: string) { 
		switch (tarifaClasse) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTarifaClasse(tarifaClasse: string) { 
		switch (tarifaClasse) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getCargaInformacaoManuseio(cargaInformacaoManuseio: string) { 
		switch (cargaInformacaoManuseio) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setCargaInformacaoManuseio(cargaInformacaoManuseio: string) { 
		switch (cargaInformacaoManuseio) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getCargaEspecial(cargaEspecial: string) { 
		switch (cargaEspecial) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setCargaEspecial(cargaEspecial: string) { 
		switch (cargaEspecial) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default CteAereoDomain;