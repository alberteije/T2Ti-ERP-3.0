class CteInformacaoNfOutrosDomain {
	static getCodigoModelo(codigoModelo: string) { 
		switch (codigoModelo) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setCodigoModelo(codigoModelo: string) { 
		switch (codigoModelo) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getSerie(serie: string) { 
		switch (serie) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setSerie(serie: string) { 
		switch (serie) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getOutroTipoDocOrig(outroTipoDocOrig: string) { 
		switch (outroTipoDocOrig) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setOutroTipoDocOrig(outroTipoDocOrig: string) { 
		switch (outroTipoDocOrig) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default CteInformacaoNfOutrosDomain;