class CteFerroviarioDomain {
	static getTipoTrafego(tipoTrafego: string) { 
		switch (tipoTrafego) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoTrafego(tipoTrafego: string) { 
		switch (tipoTrafego) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getResponsavelFaturamento(responsavelFaturamento: string) { 
		switch (responsavelFaturamento) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setResponsavelFaturamento(responsavelFaturamento: string) { 
		switch (responsavelFaturamento) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getFerroviaEmitenteCte(ferroviaEmitenteCte: string) { 
		switch (ferroviaEmitenteCte) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setFerroviaEmitenteCte(ferroviaEmitenteCte: string) { 
		switch (ferroviaEmitenteCte) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default CteFerroviarioDomain;