/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteRecebedorDomain from '../../data/domain/CteRecebedorDomain';

class CteRecebedor {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteRecebedor {
		const cteRecebedor = new CteRecebedor();
		cteRecebedor.id = Date.now();
		cteRecebedor.statusCrud = "C";
		return cteRecebedor;
	}
}

export const CteRecebedorTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteRecebedor,
		setCurrentRecord: (record: CteRecebedor) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteRecebedorDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Recebedor"
			recordContext="cteCabecalho"
			fieldSource="cteRecebedorModelList"
			newObject={ CteRecebedor.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};