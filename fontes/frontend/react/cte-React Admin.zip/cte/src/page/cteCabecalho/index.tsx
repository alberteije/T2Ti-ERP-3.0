import CteCabecalhoIcon from "@mui/icons-material/Apps";
import CteCabecalhoList from "./CteCabecalhoList";
import CteCabecalhoCreate from "./CteCabecalhoCreate";
import CteCabecalhoEdit from "./CteCabecalhoEdit";

export default {
	list: CteCabecalhoList,
	create: CteCabecalhoCreate,
	edit: CteCabecalhoEdit,
	icon: CteCabecalhoIcon,
};
