/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteFatura {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteFatura {
		const cteFatura = new CteFatura();
		cteFatura.id = Date.now();
		cteFatura.statusCrud = "C";
		return cteFatura;
	}
}

export const CteFaturaTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteFatura,
		setCurrentRecord: (record: CteFatura) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numero', label: 'Numero' },
		{ source: 'valorOriginal', label: 'Valor Original' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorLiquido', label: 'Valor Liquido' },
	];

	return (
		<CrudChildTab
			title="Fatura"
			recordContext="cteCabecalho"
			fieldSource="cteFaturaModelList"
			newObject={ CteFatura.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};