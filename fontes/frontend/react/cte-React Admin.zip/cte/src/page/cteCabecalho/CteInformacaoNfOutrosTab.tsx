/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteInformacaoNfOutrosDomain from '../../data/domain/CteInformacaoNfOutrosDomain';

class CteInformacaoNfOutros {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteInformacaoNfOutros {
		const cteInformacaoNfOutros = new CteInformacaoNfOutros();
		cteInformacaoNfOutros.id = Date.now();
		cteInformacaoNfOutros.statusCrud = "C";
		return cteInformacaoNfOutros;
	}
}

export const CteInformacaoNfOutrosTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteInformacaoNfOutros,
		setCurrentRecord: (record: CteInformacaoNfOutros) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroRomaneio', label: 'Numero Romaneio' },
		{ source: 'numeroPedido', label: 'Numero Pedido' },
		{ source: 'chaveAcessoNfe', label: 'Chave Acesso Nfe' },
		{ source: 'codigoModelo', label: 'Codigo Modelo', formatDomain: CteInformacaoNfOutrosDomain.getCodigoModelo },
		{ source: 'serie', label: 'Serie', formatDomain: CteInformacaoNfOutrosDomain.getSerie },
		{ source: 'numero', label: 'Numero' },
		{ source: 'dataEmissao', label: 'Data Emissao' },
		{ source: 'ufEmitente', label: 'Uf Emitente' },
		{ source: 'baseCalculoIcms', label: 'Base Calculo Icms' },
		{ source: 'valorIcms', label: 'Valor Icms' },
		{ source: 'baseCalculoIcmsSt', label: 'Base Calculo Icms St' },
		{ source: 'valorIcmsSt', label: 'Valor Icms St' },
		{ source: 'valorTotalProdutos', label: 'Valor Total Produtos' },
		{ source: 'valorTotal', label: 'Valor Total' },
		{ source: 'cfopPredominante', label: 'Cfop Predominante' },
		{ source: 'pesoTotalKg', label: 'Peso Total Kg' },
		{ source: 'pinSuframa', label: 'Pin Suframa' },
		{ source: 'dataPrevistaEntrega', label: 'Data Prevista Entrega' },
		{ source: 'outroTipoDocOrig', label: 'Outro Tipo Doc Orig', formatDomain: CteInformacaoNfOutrosDomain.getOutroTipoDocOrig },
		{ source: 'outroDescricao', label: 'Outro Descricao' },
		{ source: 'outroValorDocumento', label: 'Outro Valor Documento' },
	];

	return (
		<CrudChildTab
			title="NF Outros"
			recordContext="cteCabecalho"
			fieldSource="cteInformacaoNfOutrosModelList"
			newObject={ CteInformacaoNfOutros.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};