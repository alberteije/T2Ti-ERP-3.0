/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteSeguroDomain from '../../data/domain/CteSeguroDomain';

class CteSeguro {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteSeguro {
		const cteSeguro = new CteSeguro();
		cteSeguro.id = Date.now();
		cteSeguro.statusCrud = "C";
		return cteSeguro;
	}
}

export const CteSeguroTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteSeguro,
		setCurrentRecord: (record: CteSeguro) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'responsavel', label: 'Responsavel', formatDomain: CteSeguroDomain.getResponsavel },
		{ source: 'seguradora', label: 'Seguradora' },
		{ source: 'apolice', label: 'Apolice' },
		{ source: 'averbacao', label: 'Averbacao' },
		{ source: 'valorCarga', label: 'Valor Carga' },
	];

	return (
		<CrudChildTab
			title="Seguro"
			recordContext="cteCabecalho"
			fieldSource="cteSeguroModelList"
			newObject={ CteSeguro.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};