/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CteCabecalhoForm } from "./CteCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const CteCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CteCabecalhoForm />
		</Edit>
	);
};

export default CteCabecalhoEdit;