/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CteCabecalhoForm } from "./CteCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const CteCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CteCabecalhoForm />
		</Create>
	);
};

export default CteCabecalhoCreate;