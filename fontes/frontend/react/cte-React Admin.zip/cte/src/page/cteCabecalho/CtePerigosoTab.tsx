/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CtePerigoso {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CtePerigoso {
		const ctePerigoso = new CtePerigoso();
		ctePerigoso.id = Date.now();
		ctePerigoso.statusCrud = "C";
		return ctePerigoso;
	}
}

export const CtePerigosoTab: React.FC = () => {

	const renderForm = (
		currentRecord: CtePerigoso,
		setCurrentRecord: (record: CtePerigoso) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroOnu', label: 'Numero Onu' },
		{ source: 'nomeApropriado', label: 'Nome Apropriado' },
		{ source: 'classeRisco', label: 'Classe Risco' },
		{ source: 'grupoEmbalagem', label: 'Grupo Embalagem' },
		{ source: 'quantidadeTotalProduto', label: 'Quantidade Total Produto' },
		{ source: 'quantidadeTipoVolume', label: 'Quantidade Tipo Volume' },
		{ source: 'pontoFulgor', label: 'Ponto Fulgor' },
	];

	return (
		<CrudChildTab
			title="Perigoso"
			recordContext="cteCabecalho"
			fieldSource="ctePerigosoModelList"
			newObject={ CtePerigoso.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};