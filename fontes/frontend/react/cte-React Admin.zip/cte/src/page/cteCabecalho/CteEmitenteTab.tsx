/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteEmitenteDomain from '../../data/domain/CteEmitenteDomain';

class CteEmitente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteEmitente {
		const cteEmitente = new CteEmitente();
		cteEmitente.id = Date.now();
		cteEmitente.statusCrud = "C";
		return cteEmitente;
	}
}

export const CteEmitenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteEmitente,
		setCurrentRecord: (record: CteEmitente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteEmitenteDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'telefone', label: 'Telefone' },
	];

	return (
		<CrudChildTab
			title="Emitente"
			recordContext="cteCabecalho"
			fieldSource="cteEmitenteModelList"
			newObject={ CteEmitente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};