/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CtePassagem {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CtePassagem {
		const ctePassagem = new CtePassagem();
		ctePassagem.id = Date.now();
		ctePassagem.statusCrud = "C";
		return ctePassagem;
	}
}

export const CtePassagemTab: React.FC = () => {

	const renderForm = (
		currentRecord: CtePassagem,
		setCurrentRecord: (record: CtePassagem) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'siglaPassagem', label: 'Sigla Passagem' },
		{ source: 'siglaDestino', label: 'Sigla Destino' },
		{ source: 'rota', label: 'Rota' },
	];

	return (
		<CrudChildTab
			title="Passagem"
			recordContext="cteCabecalho"
			fieldSource="ctePassagemModelList"
			newObject={ CtePassagem.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};