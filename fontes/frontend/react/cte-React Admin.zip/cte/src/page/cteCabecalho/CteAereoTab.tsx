/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteAereoDomain from '../../data/domain/CteAereoDomain';

class CteAereo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteAereo {
		const cteAereo = new CteAereo();
		cteAereo.id = Date.now();
		cteAereo.statusCrud = "C";
		return cteAereo;
	}
}

export const CteAereoTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteAereo,
		setCurrentRecord: (record: CteAereo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroMinuta', label: 'Numero Minuta' },
		{ source: 'numeroConhecimento', label: 'Numero Conhecimento' },
		{ source: 'dataPrevistaEntrega', label: 'Data Prevista Entrega' },
		{ source: 'idEmissor', label: 'Id Emissor' },
		{ source: 'idInternaTomador', label: 'Id Interna Tomador' },
		{ source: 'tarifaClasse', label: 'Tarifa Classe', formatDomain: CteAereoDomain.getTarifaClasse },
		{ source: 'tarifaCodigo', label: 'Tarifa Codigo' },
		{ source: 'tarifaValor', label: 'Tarifa Valor' },
		{ source: 'cargaDimensao', label: 'Carga Dimensao' },
		{ source: 'cargaInformacaoManuseio', label: 'Carga Informacao Manuseio', formatDomain: CteAereoDomain.getCargaInformacaoManuseio },
		{ source: 'cargaEspecial', label: 'Carga Especial', formatDomain: CteAereoDomain.getCargaEspecial },
	];

	return (
		<CrudChildTab
			title="Aéreo"
			recordContext="cteCabecalho"
			fieldSource="cteAereoModelList"
			newObject={ CteAereo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};