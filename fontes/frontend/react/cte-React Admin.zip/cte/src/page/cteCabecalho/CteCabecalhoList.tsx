/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteCabecalhoDomain from '../../data/domain/CteCabecalhoDomain';

const CteCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["naturezaOperacao","chaveAcesso","digitoChaveAcesso"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteCabecalhoSmallScreenList : CteCabecalhoBigScreenList;

	return (
		<List
			title="CT-e"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.naturezaOperacao }
			secondaryText={ (record) => record.chaveAcesso }
			tertiaryText={ (record) => record.digitoChaveAcesso }
		/>
	);
}

const CteCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="naturezaOperacao" label="Natureza Operacao" />
			<TextField source="chaveAcesso" label="Chave Acesso" />
			<TextField source="digitoChaveAcesso" label="Digito Chave Acesso" />
			<TextField source="codigoNumerico" label="Codigo Numerico" />
			<TextField source="serie" label="Serie" />
			<TextField source="numero" label="Numero" />
			<TextField source="dataHoraEmissao" label="Data Hora Emissao" />
			<FunctionField
				label="Uf Emitente"
				render={record => CteCabecalhoDomain.getUfEmitente(record.ufEmitente)}
			/>
			<TextField source="cfop" label="Cfop" />
			<FunctionField
				label="Forma Pagamento"
				render={record => CteCabecalhoDomain.getFormaPagamento(record.formaPagamento)}
			/>
			<FunctionField
				label="Modelo"
				render={record => CteCabecalhoDomain.getModelo(record.modelo)}
			/>
			<FunctionField
				label="Formato Impressao Dacte"
				render={record => CteCabecalhoDomain.getFormatoImpressaoDacte(record.formatoImpressaoDacte)}
			/>
			<FunctionField
				label="Tipo Emissao"
				render={record => CteCabecalhoDomain.getTipoEmissao(record.tipoEmissao)}
			/>
			<FunctionField
				label="Ambiente"
				render={record => CteCabecalhoDomain.getAmbiente(record.ambiente)}
			/>
			<FunctionField
				label="Tipo Cte"
				render={record => CteCabecalhoDomain.getTipoCte(record.tipoCte)}
			/>
			<FunctionField
				label="Processo Emissao"
				render={record => CteCabecalhoDomain.getProcessoEmissao(record.processoEmissao)}
			/>
			<TextField source="versaoProcessoEmissao" label="Versao Processo Emissao" />
			<TextField source="chaveReferenciado" label="Chave Referenciado" />
			<TextField source="codigoMunicipioEnvio" label="Codigo Municipio Envio" />
			<TextField source="nomeMunicipioEnvio" label="Nome Municipio Envio" />
			<FunctionField
				label="Uf Envio"
				render={record => CteCabecalhoDomain.getUfEnvio(record.ufEnvio)}
			/>
			<FunctionField
				label="Modal"
				render={record => CteCabecalhoDomain.getModal(record.modal)}
			/>
			<FunctionField
				label="Tipo Servico"
				render={record => CteCabecalhoDomain.getTipoServico(record.tipoServico)}
			/>
			<TextField source="codigoMunicipioIniPrestacao" label="Codigo Municipio Ini Prestacao" />
			<TextField source="nomeMunicipioIniPrestacao" label="Nome Municipio Ini Prestacao" />
			<FunctionField
				label="Uf Ini Prestacao"
				render={record => CteCabecalhoDomain.getUfIniPrestacao(record.ufIniPrestacao)}
			/>
			<TextField source="codigoMunicipioFimPrestacao" label="Codigo Municipio Fim Prestacao" />
			<TextField source="nomeMunicipioFimPrestacao" label="Nome Municipio Fim Prestacao" />
			<FunctionField
				label="Uf Fim Prestacao"
				render={record => CteCabecalhoDomain.getUfFimPrestacao(record.ufFimPrestacao)}
			/>
			<FunctionField
				label="Retira"
				render={record => CteCabecalhoDomain.getRetira(record.retira)}
			/>
			<TextField source="retiraDetalhe" label="Retira Detalhe" />
			<FunctionField
				label="Tomador"
				render={record => CteCabecalhoDomain.getTomador(record.tomador)}
			/>
			<TextField source="dataEntradaContingencia" label="Data Entrada Contingencia" />
			<TextField source="justificativaContingencia" label="Justificativa Contingencia" />
			<TextField source="caracAdicionalTransporte" label="Carac Adicional Transporte" />
			<TextField source="caracAdicionalServico" label="Carac Adicional Servico" />
			<TextField source="funcionarioEmissor" label="Funcionario Emissor" />
			<TextField source="fluxoOrigem" label="Fluxo Origem" />
			<FunctionField
				label="Entrega Tipo Periodo"
				render={record => CteCabecalhoDomain.getEntregaTipoPeriodo(record.entregaTipoPeriodo)}
			/>
			<TextField source="entregaDataProgramada" label="Entrega Data Programada" />
			<TextField source="entregaDataInicial" label="Entrega Data Inicial" />
			<TextField source="entregaDataFinal" label="Entrega Data Final" />
			<FunctionField
				label="Entrega Tipo Hora"
				render={record => CteCabecalhoDomain.getEntregaTipoHora(record.entregaTipoHora)}
			/>
			<TextField source="entregaHoraProgramada" label="Entrega Hora Programada" />
			<TextField source="entregaHoraInicial" label="Entrega Hora Inicial" />
			<TextField source="entregaHoraFinal" label="Entrega Hora Final" />
			<TextField source="municipioOrigemCalculo" label="Municipio Origem Calculo" />
			<TextField source="municipioDestinoCalculo" label="Municipio Destino Calculo" />
			<TextField source="observacoesGerais" label="Observacoes Gerais" />
			<NumberField source="valorTotalServico" label="Valor Total Servico" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorReceber" label="Valor Receber" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="cst" label="Cst" />
			<NumberField source="baseCalculoIcms" label="Base Calculo Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaIcms" label="Aliquota Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcms" label="Valor Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualReducaoBcIcms" label="Percentual Reducao Bc Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcIcmsStRetido" label="Valor Bc Icms St Retido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsStRetido" label="Valor Icms St Retido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaIcmsStRetido" label="Aliquota Icms St Retido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCreditoPresumidoIcms" label="Valor Credito Presumido Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualBcIcmsOutraUf" label="Percentual Bc Icms Outra Uf" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBcIcmsOutraUf" label="Valor Bc Icms Outra Uf" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaIcmsOutraUf" label="Aliquota Icms Outra Uf" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsOutraUf" label="Valor Icms Outra Uf" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Simples Nacional Indicador"
				render={record => CteCabecalhoDomain.getSimplesNacionalIndicador(record.simplesNacionalIndicador)}
			/>
			<NumberField source="simplesNacionalTotal" label="Simples Nacional Total" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="informacoesAddFisco" label="Informacoes Add Fisco" />
			<NumberField source="valorTotalCarga" label="Valor Total Carga" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="produtoPredominante" label="Produto Predominante" />
			<TextField source="cargaOutrasCaracteristicas" label="Carga Outras Caracteristicas" />
			<TextField source="modalVersaoLayout" label="Modal Versao Layout" />
			<TextField source="chaveCteSubstituido" label="Chave Cte Substituido" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteCabecalhoList;
