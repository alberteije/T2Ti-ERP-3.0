/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteLocalEntregaDomain from '../../data/domain/CteLocalEntregaDomain';

class CteLocalEntrega {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteLocalEntrega {
		const cteLocalEntrega = new CteLocalEntrega();
		cteLocalEntrega.id = Date.now();
		cteLocalEntrega.statusCrud = "C";
		return cteLocalEntrega;
	}
}

export const CteLocalEntregaTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteLocalEntrega,
		setCurrentRecord: (record: CteLocalEntrega) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteLocalEntregaDomain.getUf },
	];

	return (
		<CrudChildTab
			title="Local Entrega"
			recordContext="cteCabecalho"
			fieldSource="cteLocalEntregaModelList"
			newObject={ CteLocalEntrega.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};