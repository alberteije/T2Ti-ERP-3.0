/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteExpedidorDomain from '../../data/domain/CteExpedidorDomain';

class CteExpedidor {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteExpedidor {
		const cteExpedidor = new CteExpedidor();
		cteExpedidor.id = Date.now();
		cteExpedidor.statusCrud = "C";
		return cteExpedidor;
	}
}

export const CteExpedidorTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteExpedidor,
		setCurrentRecord: (record: CteExpedidor) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteExpedidorDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Expedidor"
			recordContext="cteCabecalho"
			fieldSource="cteExpedidorModelList"
			newObject={ CteExpedidor.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};