/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteRodoviarioDomain from '../../data/domain/CteRodoviarioDomain';

class CteRodoviario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteRodoviario {
		const cteRodoviario = new CteRodoviario();
		cteRodoviario.id = Date.now();
		cteRodoviario.statusCrud = "C";
		return cteRodoviario;
	}
}

export const CteRodoviarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteRodoviario,
		setCurrentRecord: (record: CteRodoviario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'rntrc', label: 'Rntrc' },
		{ source: 'dataPrevistaEntrega', label: 'Data Prevista Entrega' },
		{ source: 'indicadorLotacao', label: 'Indicador Lotacao', formatDomain: CteRodoviarioDomain.getIndicadorLotacao },
		{ source: 'ciot', label: 'Ciot' },
	];

	return (
		<CrudChildTab
			title="Rodoviário"
			recordContext="cteCabecalho"
			fieldSource="cteRodoviarioModelList"
			newObject={ CteRodoviario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};