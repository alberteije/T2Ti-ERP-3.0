/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteDutoviario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteDutoviario {
		const cteDutoviario = new CteDutoviario();
		cteDutoviario.id = Date.now();
		cteDutoviario.statusCrud = "C";
		return cteDutoviario;
	}
}

export const CteDutoviarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteDutoviario,
		setCurrentRecord: (record: CteDutoviario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'valorTarifa', label: 'Valor Tarifa' },
		{ source: 'dataInicio', label: 'Data Inicio' },
		{ source: 'dataFim', label: 'Data Fim' },
	];

	return (
		<CrudChildTab
			title="Dutoviário"
			recordContext="cteCabecalho"
			fieldSource="cteDutoviarioModelList"
			newObject={ CteDutoviario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};