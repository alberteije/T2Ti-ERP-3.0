/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteMultimodalDomain from '../../data/domain/CteMultimodalDomain';

class CteMultimodal {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteMultimodal {
		const cteMultimodal = new CteMultimodal();
		cteMultimodal.id = Date.now();
		cteMultimodal.statusCrud = "C";
		return cteMultimodal;
	}
}

export const CteMultimodalTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteMultimodal,
		setCurrentRecord: (record: CteMultimodal) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cotm', label: 'Cotm' },
		{ source: 'indicadorNegociavel', label: 'Indicador Negociavel', formatDomain: CteMultimodalDomain.getIndicadorNegociavel },
	];

	return (
		<CrudChildTab
			title="Multimodal"
			recordContext="cteCabecalho"
			fieldSource="cteMultimodalModelList"
			newObject={ CteMultimodal.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};