/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteVeiculoNovo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteVeiculoNovo {
		const cteVeiculoNovo = new CteVeiculoNovo();
		cteVeiculoNovo.id = Date.now();
		cteVeiculoNovo.statusCrud = "C";
		return cteVeiculoNovo;
	}
}

export const CteVeiculoNovoTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteVeiculoNovo,
		setCurrentRecord: (record: CteVeiculoNovo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'chassi', label: 'Chassi' },
		{ source: 'cor', label: 'Cor' },
		{ source: 'descricaoCor', label: 'Descricao Cor' },
		{ source: 'codigoMarcaModelo', label: 'Codigo Marca Modelo' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorFrete', label: 'Valor Frete' },
	];

	return (
		<CrudChildTab
			title="Veículo Novo"
			recordContext="cteCabecalho"
			fieldSource="cteVeiculoNovoModelList"
			newObject={ CteVeiculoNovo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};