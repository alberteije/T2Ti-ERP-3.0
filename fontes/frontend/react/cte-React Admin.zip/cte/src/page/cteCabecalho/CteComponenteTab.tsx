/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteComponente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteComponente {
		const cteComponente = new CteComponente();
		cteComponente.id = Date.now();
		cteComponente.statusCrud = "C";
		return cteComponente;
	}
}

export const CteComponenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteComponente,
		setCurrentRecord: (record: CteComponente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Componente"
			recordContext="cteCabecalho"
			fieldSource="cteComponenteModelList"
			newObject={ CteComponente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};