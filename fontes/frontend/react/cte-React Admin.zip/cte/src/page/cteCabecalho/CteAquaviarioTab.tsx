/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteAquaviario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteAquaviario {
		const cteAquaviario = new CteAquaviario();
		cteAquaviario.id = Date.now();
		cteAquaviario.statusCrud = "C";
		return cteAquaviario;
	}
}

export const CteAquaviarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteAquaviario,
		setCurrentRecord: (record: CteAquaviario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'valorPrestacao', label: 'Valor Prestacao' },
		{ source: 'afrmm', label: 'Afrmm' },
		{ source: 'numeroBooking', label: 'Numero Booking' },
		{ source: 'numeroControle', label: 'Numero Controle' },
		{ source: 'idNavio', label: 'Id Navio' },
	];

	return (
		<CrudChildTab
			title="Aquaviário"
			recordContext="cteCabecalho"
			fieldSource="cteAquaviarioModelList"
			newObject={ CteAquaviario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};