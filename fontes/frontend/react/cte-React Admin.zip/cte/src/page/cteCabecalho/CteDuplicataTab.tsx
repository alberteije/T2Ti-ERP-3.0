/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CteDuplicata {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteDuplicata {
		const cteDuplicata = new CteDuplicata();
		cteDuplicata.id = Date.now();
		cteDuplicata.statusCrud = "C";
		return cteDuplicata;
	}
}

export const CteDuplicataTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteDuplicata,
		setCurrentRecord: (record: CteDuplicata) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numero', label: 'Numero' },
		{ source: 'dataVencimento', label: 'Data Vencimento' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Duplicata"
			recordContext="cteCabecalho"
			fieldSource="cteDuplicataModelList"
			newObject={ CteDuplicata.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};