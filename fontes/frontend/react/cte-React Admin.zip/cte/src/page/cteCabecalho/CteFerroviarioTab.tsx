/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteFerroviarioDomain from '../../data/domain/CteFerroviarioDomain';

class CteFerroviario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteFerroviario {
		const cteFerroviario = new CteFerroviario();
		cteFerroviario.id = Date.now();
		cteFerroviario.statusCrud = "C";
		return cteFerroviario;
	}
}

export const CteFerroviarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteFerroviario,
		setCurrentRecord: (record: CteFerroviario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tipoTrafego', label: 'Tipo Trafego', formatDomain: CteFerroviarioDomain.getTipoTrafego },
		{ source: 'responsavelFaturamento', label: 'Responsavel Faturamento', formatDomain: CteFerroviarioDomain.getResponsavelFaturamento },
		{ source: 'ferroviaEmitenteCte', label: 'Ferrovia Emitente Cte', formatDomain: CteFerroviarioDomain.getFerroviaEmitenteCte },
		{ source: 'fluxo', label: 'Fluxo' },
		{ source: 'idTrem', label: 'Id Trem' },
		{ source: 'valorFrete', label: 'Valor Frete' },
	];

	return (
		<CrudChildTab
			title="Ferroviário"
			recordContext="cteCabecalho"
			fieldSource="cteFerroviarioModelList"
			newObject={ CteFerroviario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};