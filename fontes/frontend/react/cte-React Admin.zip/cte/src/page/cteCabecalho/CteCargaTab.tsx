/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteCargaDomain from '../../data/domain/CteCargaDomain';

class CteCarga {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteCarga {
		const cteCarga = new CteCarga();
		cteCarga.id = Date.now();
		cteCarga.statusCrud = "C";
		return cteCarga;
	}
}

export const CteCargaTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteCarga,
		setCurrentRecord: (record: CteCarga) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoUnidadeMedida', label: 'Codigo Unidade Medida', formatDomain: CteCargaDomain.getCodigoUnidadeMedida },
		{ source: 'tipoMedida', label: 'Tipo Medida' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Carga"
			recordContext="cteCabecalho"
			fieldSource="cteCargaModelList"
			newObject={ CteCarga.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};