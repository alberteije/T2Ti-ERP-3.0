/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import CteRemetenteDomain from '../../data/domain/CteRemetenteDomain';

class CteRemetente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CteRemetente {
		const cteRemetente = new CteRemetente();
		cteRemetente.id = Date.now();
		cteRemetente.statusCrud = "C";
		return cteRemetente;
	}
}

export const CteRemetenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: CteRemetente,
		setCurrentRecord: (record: CteRemetente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: CteRemetenteDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Remetente"
			recordContext="cteCabecalho"
			fieldSource="cteRemetenteModelList"
			newObject={ CteRemetente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};