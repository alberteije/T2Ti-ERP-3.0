/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { CteEmitenteTab } from './CteEmitenteTab';
import { CteLocalColetaTab } from './CteLocalColetaTab';
import { CteTomadorTab } from './CteTomadorTab';
import { CtePassagemTab } from './CtePassagemTab';
import { CteRemetenteTab } from './CteRemetenteTab';
import { CteExpedidorTab } from './CteExpedidorTab';
import { CteRecebedorTab } from './CteRecebedorTab';
import { CteDestinatarioTab } from './CteDestinatarioTab';
import { CteLocalEntregaTab } from './CteLocalEntregaTab';
import { CteComponenteTab } from './CteComponenteTab';
import { CteCargaTab } from './CteCargaTab';
import { CteInformacaoNfOutrosTab } from './CteInformacaoNfOutrosTab';
import { CteSeguroTab } from './CteSeguroTab';
import { CtePerigosoTab } from './CtePerigosoTab';
import { CteVeiculoNovoTab } from './CteVeiculoNovoTab';
import { CteFaturaTab } from './CteFaturaTab';
import { CteDuplicataTab } from './CteDuplicataTab';
import { CteRodoviarioTab } from './CteRodoviarioTab';
import { CteAereoTab } from './CteAereoTab';
import { CteAquaviarioTab } from './CteAquaviarioTab';
import { CteFerroviarioTab } from './CteFerroviarioTab';
import { CteDutoviarioTab } from './CteDutoviarioTab';
import { CteMultimodalTab } from './CteMultimodalTab';

export const CteCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="CT-e">
				<CteCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Emitente">
				<CteEmitenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Local Coleta">
				<CteLocalColetaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Tomador">
				<CteTomadorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Passagem">
				<CtePassagemTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Remetente">
				<CteRemetenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Expedidor">
				<CteExpedidorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Recebedor">
				<CteRecebedorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Destinatário">
				<CteDestinatarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Local Entrega">
				<CteLocalEntregaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Componente">
				<CteComponenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Carga">
				<CteCargaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="NF Outros">
				<CteInformacaoNfOutrosTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Seguro">
				<CteSeguroTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Perigoso">
				<CtePerigosoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Veículo Novo">
				<CteVeiculoNovoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Fatura">
				<CteFaturaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Duplicata">
				<CteDuplicataTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Rodoviário">
				<CteRodoviarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Aéreo">
				<CteAereoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Aquaviário">
				<CteAquaviarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Ferroviário">
				<CteFerroviarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Dutoviário">
				<CteDutoviarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Multimodal">
				<CteMultimodalTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CteCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};