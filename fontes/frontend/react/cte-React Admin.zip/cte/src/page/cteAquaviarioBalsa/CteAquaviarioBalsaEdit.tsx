import {
	Edit,
} from "react-admin";
import { CteAquaviarioBalsaForm } from "./CteAquaviarioBalsaForm";

const CteAquaviarioBalsaEdit = () => {
	return (
		<Edit>
			<CteAquaviarioBalsaForm />
		</Edit>
	);
};

export default CteAquaviarioBalsaEdit;