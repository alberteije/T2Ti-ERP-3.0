import {
	Create,
} from "react-admin";
import { CteAquaviarioBalsaForm } from "./CteAquaviarioBalsaForm";

const CteAquaviarioBalsaCreate = () => {
	return (
		<Create>
			<CteAquaviarioBalsaForm />
		</Create>
	);
};

export default CteAquaviarioBalsaCreate;