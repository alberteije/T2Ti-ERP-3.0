import CteAquaviarioBalsaIcon from "@mui/icons-material/Apps";
import CteAquaviarioBalsaList from "./CteAquaviarioBalsaList";
import CteAquaviarioBalsaCreate from "./CteAquaviarioBalsaCreate";
import CteAquaviarioBalsaEdit from "./CteAquaviarioBalsaEdit";

export default {
	list: CteAquaviarioBalsaList,
	create: CteAquaviarioBalsaCreate,
	edit: CteAquaviarioBalsaEdit,
	icon: CteAquaviarioBalsaIcon,
};
