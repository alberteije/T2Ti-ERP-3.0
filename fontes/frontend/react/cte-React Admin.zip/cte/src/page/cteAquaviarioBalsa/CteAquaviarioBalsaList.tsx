/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteAquaviarioBalsaDomain from '../../data/domain/CteAquaviarioBalsaDomain';

const CteAquaviarioBalsaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteAquaviarioModel.numeroControle","idBalsa","numeroViagem"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteAquaviarioBalsaSmallScreenList : CteAquaviarioBalsaBigScreenList;

	return (
		<List
			title="Cte Aquaviario Balsa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteAquaviarioBalsaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteAquaviarioModel.numeroControle }
			secondaryText={ (record) => record.idBalsa }
			tertiaryText={ (record) => record.numeroViagem }
		/>
	);
}

const CteAquaviarioBalsaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Aquaviario" source="cteAquaviarioModel.id" reference="cte-aquaviario" sortable={false}>
				<TextField source="numeroControle" />
			</ReferenceField>
			<TextField source="idBalsa" label="Id Balsa" />
			<TextField source="numeroViagem" label="Numero Viagem" />
			<FunctionField
				label="Direcao"
				render={record => CteAquaviarioBalsaDomain.getDirecao(record.direcao)}
			/>
			<TextField source="portoEmbarque" label="Porto Embarque" />
			<TextField source="portoTransbordo" label="Porto Transbordo" />
			<TextField source="portoDestino" label="Porto Destino" />
			<FunctionField
				label="Tipo Navegacao"
				render={record => CteAquaviarioBalsaDomain.getTipoNavegacao(record.tipoNavegacao)}
			/>
			<TextField source="irin" label="Irin" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteAquaviarioBalsaList;
