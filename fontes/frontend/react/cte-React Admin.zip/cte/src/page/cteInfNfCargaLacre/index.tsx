import CteInfNfCargaLacreIcon from "@mui/icons-material/Apps";
import CteInfNfCargaLacreList from "./CteInfNfCargaLacreList";
import CteInfNfCargaLacreCreate from "./CteInfNfCargaLacreCreate";
import CteInfNfCargaLacreEdit from "./CteInfNfCargaLacreEdit";

export default {
	list: CteInfNfCargaLacreList,
	create: CteInfNfCargaLacreCreate,
	edit: CteInfNfCargaLacreEdit,
	icon: CteInfNfCargaLacreIcon,
};
