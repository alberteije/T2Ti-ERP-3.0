import {
	Edit,
} from "react-admin";
import { CteInfNfCargaLacreForm } from "./CteInfNfCargaLacreForm";

const CteInfNfCargaLacreEdit = () => {
	return (
		<Edit>
			<CteInfNfCargaLacreForm />
		</Edit>
	);
};

export default CteInfNfCargaLacreEdit;