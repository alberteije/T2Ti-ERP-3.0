import {
	Create,
} from "react-admin";
import { CteInfNfCargaLacreForm } from "./CteInfNfCargaLacreForm";

const CteInfNfCargaLacreCreate = () => {
	return (
		<Create>
			<CteInfNfCargaLacreForm />
		</Create>
	);
};

export default CteInfNfCargaLacreCreate;