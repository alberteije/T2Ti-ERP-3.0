/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CteInfNfCargaLacreList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteInformacaoNfCargaModel.tipoUnidadeCarga","numero","quantidadeRateada"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteInfNfCargaLacreSmallScreenList : CteInfNfCargaLacreBigScreenList;

	return (
		<List
			title="Cte Inf Nf Carga Lacre"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteInfNfCargaLacreSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteInformacaoNfCargaModel.tipoUnidadeCarga }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record.quantidadeRateada }
		/>
	);
}

const CteInfNfCargaLacreBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Informacao Nf Carga" source="cteInformacaoNfCargaModel.id" reference="cte-informacao-nf-carga" sortable={false}>
				<TextField source="tipoUnidadeCarga" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<NumberField source="quantidadeRateada" label="Quantidade Rateada" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteInfNfCargaLacreList;
