import CteRodoviarioOccIcon from "@mui/icons-material/Apps";
import CteRodoviarioOccList from "./CteRodoviarioOccList";
import CteRodoviarioOccCreate from "./CteRodoviarioOccCreate";
import CteRodoviarioOccEdit from "./CteRodoviarioOccEdit";

export default {
	list: CteRodoviarioOccList,
	create: CteRodoviarioOccCreate,
	edit: CteRodoviarioOccEdit,
	icon: CteRodoviarioOccIcon,
};
