/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import CteRodoviarioOccDomain from '../../data/domain/CteRodoviarioOccDomain';

const CteRodoviarioOccList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteRodoviarioModel.rntrc","serie","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteRodoviarioOccSmallScreenList : CteRodoviarioOccBigScreenList;

	return (
		<List
			title="Cte Rodoviario Occ"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteRodoviarioOccSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteRodoviarioModel.rntrc }
			secondaryText={ (record) => record.serie }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const CteRodoviarioOccBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Rodoviario" source="cteRodoviarioModel.id" reference="cte-rodoviario" sortable={false}>
				<TextField source="rntrc" />
			</ReferenceField>
			<FunctionField
				label="Serie"
				render={record => CteRodoviarioOccDomain.getSerie(record.serie)}
			/>
			<TextField source="numero" label="Numero" />
			<TextField source="dataEmissao" label="Data Emissao" />
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<TextField source="codigoInterno" label="Codigo Interno" />
			<TextField source="ie" label="Ie" />
			<FunctionField
				label="Uf"
				render={record => CteRodoviarioOccDomain.getUf(record.uf)}
			/>
			<TextField source="telefone" label="Telefone" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteRodoviarioOccList;
