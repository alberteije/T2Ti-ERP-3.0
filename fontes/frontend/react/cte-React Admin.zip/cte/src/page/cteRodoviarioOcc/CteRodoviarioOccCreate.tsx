import {
	Create,
} from "react-admin";
import { CteRodoviarioOccForm } from "./CteRodoviarioOccForm";

const CteRodoviarioOccCreate = () => {
	return (
		<Create>
			<CteRodoviarioOccForm />
		</Create>
	);
};

export default CteRodoviarioOccCreate;