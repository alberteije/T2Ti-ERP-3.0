import {
	Edit,
} from "react-admin";
import { CteRodoviarioOccForm } from "./CteRodoviarioOccForm";

const CteRodoviarioOccEdit = () => {
	return (
		<Edit>
			<CteRodoviarioOccForm />
		</Edit>
	);
};

export default CteRodoviarioOccEdit;