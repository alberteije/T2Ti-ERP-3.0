/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteDocumentoAnteriorIdDomain from '../../data/domain/CteDocumentoAnteriorIdDomain';

const CteDocumentoAnteriorIdList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteDocumentoAnteriorModel.cnpj","tipo","serie"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteDocumentoAnteriorIdSmallScreenList : CteDocumentoAnteriorIdBigScreenList;

	return (
		<List
			title="Cte Documento Anterior Id"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteDocumentoAnteriorIdSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteDocumentoAnteriorModel.cnpj }
			secondaryText={ (record) => record.tipo }
			tertiaryText={ (record) => record.serie }
		/>
	);
}

const CteDocumentoAnteriorIdBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Documento Anterior" source="cteDocumentoAnteriorModel.id" reference="cte-documento-anterior" sortable={false}>
				<TextField source="cnpj" />
			</ReferenceField>
			<FunctionField
				label="Tipo"
				render={record => CteDocumentoAnteriorIdDomain.getTipo(record.tipo)}
			/>
			<FunctionField
				label="Serie"
				render={record => CteDocumentoAnteriorIdDomain.getSerie(record.serie)}
			/>
			<FunctionField
				label="Subserie"
				render={record => CteDocumentoAnteriorIdDomain.getSubserie(record.subserie)}
			/>
			<TextField source="numero" label="Numero" />
			<TextField source="dataEmissao" label="Data Emissao" />
			<TextField source="chaveCte" label="Chave Cte" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteDocumentoAnteriorIdList;
