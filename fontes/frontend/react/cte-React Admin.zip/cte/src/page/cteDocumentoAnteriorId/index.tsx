import CteDocumentoAnteriorIdIcon from "@mui/icons-material/Apps";
import CteDocumentoAnteriorIdList from "./CteDocumentoAnteriorIdList";
import CteDocumentoAnteriorIdCreate from "./CteDocumentoAnteriorIdCreate";
import CteDocumentoAnteriorIdEdit from "./CteDocumentoAnteriorIdEdit";

export default {
	list: CteDocumentoAnteriorIdList,
	create: CteDocumentoAnteriorIdCreate,
	edit: CteDocumentoAnteriorIdEdit,
	icon: CteDocumentoAnteriorIdIcon,
};
