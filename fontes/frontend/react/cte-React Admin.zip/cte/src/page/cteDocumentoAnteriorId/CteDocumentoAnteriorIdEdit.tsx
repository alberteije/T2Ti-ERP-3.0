import {
	Edit,
} from "react-admin";
import { CteDocumentoAnteriorIdForm } from "./CteDocumentoAnteriorIdForm";

const CteDocumentoAnteriorIdEdit = () => {
	return (
		<Edit>
			<CteDocumentoAnteriorIdForm />
		</Edit>
	);
};

export default CteDocumentoAnteriorIdEdit;