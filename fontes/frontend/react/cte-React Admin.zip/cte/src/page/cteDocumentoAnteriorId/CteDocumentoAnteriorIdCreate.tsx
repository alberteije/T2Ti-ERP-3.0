import {
	Create,
} from "react-admin";
import { CteDocumentoAnteriorIdForm } from "./CteDocumentoAnteriorIdForm";

const CteDocumentoAnteriorIdCreate = () => {
	return (
		<Create>
			<CteDocumentoAnteriorIdForm />
		</Create>
	);
};

export default CteDocumentoAnteriorIdCreate;