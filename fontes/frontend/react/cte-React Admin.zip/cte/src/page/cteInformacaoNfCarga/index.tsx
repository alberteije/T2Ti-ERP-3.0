import CteInformacaoNfCargaIcon from "@mui/icons-material/Apps";
import CteInformacaoNfCargaList from "./CteInformacaoNfCargaList";
import CteInformacaoNfCargaCreate from "./CteInformacaoNfCargaCreate";
import CteInformacaoNfCargaEdit from "./CteInformacaoNfCargaEdit";

export default {
	list: CteInformacaoNfCargaList,
	create: CteInformacaoNfCargaCreate,
	edit: CteInformacaoNfCargaEdit,
	icon: CteInformacaoNfCargaIcon,
};
