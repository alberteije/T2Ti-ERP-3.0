/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteInformacaoNfCargaDomain from '../../data/domain/CteInformacaoNfCargaDomain';

const CteInformacaoNfCargaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteInformacaoNfOutrosModel.numero","tipoUnidadeCarga","idUnidadeCarga"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteInformacaoNfCargaSmallScreenList : CteInformacaoNfCargaBigScreenList;

	return (
		<List
			title="Cte Informacao Nf Carga"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteInformacaoNfCargaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteInformacaoNfOutrosModel.numero }
			secondaryText={ (record) => record.tipoUnidadeCarga }
			tertiaryText={ (record) => record.idUnidadeCarga }
		/>
	);
}

const CteInformacaoNfCargaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Informacao Nf" source="cteInformacaoNfOutrosModel.id" reference="cte-informacao-nf-outros" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<FunctionField
				label="Tipo Unidade Carga"
				render={record => CteInformacaoNfCargaDomain.getTipoUnidadeCarga(record.tipoUnidadeCarga)}
			/>
			<TextField source="idUnidadeCarga" label="Id Unidade Carga" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteInformacaoNfCargaList;
