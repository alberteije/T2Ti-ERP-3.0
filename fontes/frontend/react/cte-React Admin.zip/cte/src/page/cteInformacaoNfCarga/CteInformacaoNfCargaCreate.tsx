import {
	Create,
} from "react-admin";
import { CteInformacaoNfCargaForm } from "./CteInformacaoNfCargaForm";

const CteInformacaoNfCargaCreate = () => {
	return (
		<Create>
			<CteInformacaoNfCargaForm />
		</Create>
	);
};

export default CteInformacaoNfCargaCreate;