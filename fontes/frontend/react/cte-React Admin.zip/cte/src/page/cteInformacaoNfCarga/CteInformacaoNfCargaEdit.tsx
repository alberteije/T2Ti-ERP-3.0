import {
	Edit,
} from "react-admin";
import { CteInformacaoNfCargaForm } from "./CteInformacaoNfCargaForm";

const CteInformacaoNfCargaEdit = () => {
	return (
		<Edit>
			<CteInformacaoNfCargaForm />
		</Edit>
	);
};

export default CteInformacaoNfCargaEdit;