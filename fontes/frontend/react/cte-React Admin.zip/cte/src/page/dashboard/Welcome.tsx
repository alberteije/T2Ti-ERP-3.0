import { Box, Card, CardActions, Button, Typography } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import CodeIcon from '@mui/icons-material/Code';
import { useTranslate } from 'react-admin';

import vycanisLogo from '/vycanis.png';

const Welcome = () => {
	const translate = useTranslate();
	return (
		<Card
			sx={{
				background: theme =>
					`linear-gradient(45deg, ${theme.palette.secondary.dark} 0%, ${theme.palette.secondary.light} 50%, ${theme.palette.primary.dark} 100%)`,
				color: theme => theme.palette.primary.contrastText,
				padding: '20px',
				marginTop: 2,
				marginBottom: '1em',
			}}
		>
			<Box display="flex">
				<Box flex="1">
					<Typography variant="h5" component="h2" gutterBottom>
						{translate('dashboard.welcome.title')}
					</Typography>
					<Box maxWidth="40em">
						<Typography variant="body1" component="p" gutterBottom>
							{translate('dashboard.welcome.subtitle')}
						</Typography>
					</Box>
					<CardActions
						sx={{
							padding: { xs: 0, xl: null },
							flexWrap: { xs: 'wrap', xl: null },
							'& a': {
								marginTop: { xs: '1em', xl: null },
								marginLeft: { xs: '0!important', xl: null },
								marginRight: { xs: '1em', xl: null },
							},
						}}
					>
						<Button
							variant="contained"
							href="https://vycanis.top/"
							startIcon={<HomeIcon />}
						>
							{translate('dashboard.welcome.vycanis_button')}
						</Button>
						<Button
							variant="contained"
							href="https://marmelab.com/react-admin"
							startIcon={<CodeIcon />}
						>
							{translate('dashboard.welcome.ra_button')}
						</Button>
					</CardActions>
				</Box>
				<Box
					display={{ xs: 'none', sm: 'none', md: 'block' }}
					sx={{
						backgroundImage: `url(${vycanisLogo})`,
						backgroundPosition: 'center',
						backgroundSize: 'cover', 
						backgroundRepeat: 'no-repeat', 
						marginLeft: 'auto',
					}}
					width="14em"
					height="9em"
					overflow="hidden"
				/>
			</Box>
		</Card>
	);
};

export default Welcome;
