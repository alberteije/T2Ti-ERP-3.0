/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteInformacaoNfTransporteDomain from '../../data/domain/CteInformacaoNfTransporteDomain';

const CteInformacaoNfTransporteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteInformacaoNfOutrosModel.numero","tipoUnidadeTransporte","idUnidadeTransporte"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteInformacaoNfTransporteSmallScreenList : CteInformacaoNfTransporteBigScreenList;

	return (
		<List
			title="Cte Informacao Nf Transporte"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteInformacaoNfTransporteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteInformacaoNfOutrosModel.numero }
			secondaryText={ (record) => record.tipoUnidadeTransporte }
			tertiaryText={ (record) => record.idUnidadeTransporte }
		/>
	);
}

const CteInformacaoNfTransporteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Informacao Nf" source="cteInformacaoNfOutrosModel.id" reference="cte-informacao-nf-outros" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<FunctionField
				label="Tipo Unidade Transporte"
				render={record => CteInformacaoNfTransporteDomain.getTipoUnidadeTransporte(record.tipoUnidadeTransporte)}
			/>
			<TextField source="idUnidadeTransporte" label="Id Unidade Transporte" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteInformacaoNfTransporteList;
