import {
	Edit,
} from "react-admin";
import { CteInformacaoNfTransporteForm } from "./CteInformacaoNfTransporteForm";

const CteInformacaoNfTransporteEdit = () => {
	return (
		<Edit>
			<CteInformacaoNfTransporteForm />
		</Edit>
	);
};

export default CteInformacaoNfTransporteEdit;