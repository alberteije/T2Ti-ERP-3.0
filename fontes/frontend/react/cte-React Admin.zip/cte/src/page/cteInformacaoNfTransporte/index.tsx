import CteInformacaoNfTransporteIcon from "@mui/icons-material/Apps";
import CteInformacaoNfTransporteList from "./CteInformacaoNfTransporteList";
import CteInformacaoNfTransporteCreate from "./CteInformacaoNfTransporteCreate";
import CteInformacaoNfTransporteEdit from "./CteInformacaoNfTransporteEdit";

export default {
	list: CteInformacaoNfTransporteList,
	create: CteInformacaoNfTransporteCreate,
	edit: CteInformacaoNfTransporteEdit,
	icon: CteInformacaoNfTransporteIcon,
};
