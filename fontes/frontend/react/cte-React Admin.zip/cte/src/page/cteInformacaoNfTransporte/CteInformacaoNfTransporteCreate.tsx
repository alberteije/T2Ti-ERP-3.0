import {
	Create,
} from "react-admin";
import { CteInformacaoNfTransporteForm } from "./CteInformacaoNfTransporteForm";

const CteInformacaoNfTransporteCreate = () => {
	return (
		<Create>
			<CteInformacaoNfTransporteForm />
		</Create>
	);
};

export default CteInformacaoNfTransporteCreate;