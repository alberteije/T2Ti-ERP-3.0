import {
	Create,
} from "react-admin";
import { CteRodoviarioPedagioForm } from "./CteRodoviarioPedagioForm";

const CteRodoviarioPedagioCreate = () => {
	return (
		<Create>
			<CteRodoviarioPedagioForm />
		</Create>
	);
};

export default CteRodoviarioPedagioCreate;