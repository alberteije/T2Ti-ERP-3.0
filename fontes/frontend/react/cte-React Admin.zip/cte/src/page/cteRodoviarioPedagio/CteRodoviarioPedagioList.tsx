/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const CteRodoviarioPedagioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteRodoviarioModel.rntrc","cnpjFornecedor","comprovanteCompra"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteRodoviarioPedagioSmallScreenList : CteRodoviarioPedagioBigScreenList;

	return (
		<List
			title="Cte Rodoviario Pedagio"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteRodoviarioPedagioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteRodoviarioModel.rntrc }
			secondaryText={ (record) => record.cnpjFornecedor }
			tertiaryText={ (record) => record.comprovanteCompra }
		/>
	);
}

const CteRodoviarioPedagioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Rodoviario" source="cteRodoviarioModel.id" reference="cte-rodoviario" sortable={false}>
				<TextField source="rntrc" />
			</ReferenceField>
			<FunctionField
				source="cnpjFornecedor"
				label="Cnpj Fornecedor"
				render={record => formatWithMask(record.cnpjFornecedor, '##.###.###/####-##')}
			/>
			<TextField source="comprovanteCompra" label="Comprovante Compra" />
			<FunctionField
				source="cnpjResponsavel"
				label="Cnpj Responsavel"
				render={record => formatWithMask(record.cnpjResponsavel, '##.###.###/####-##')}
			/>
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteRodoviarioPedagioList;
