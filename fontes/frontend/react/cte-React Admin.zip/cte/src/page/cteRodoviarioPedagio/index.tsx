import CteRodoviarioPedagioIcon from "@mui/icons-material/Apps";
import CteRodoviarioPedagioList from "./CteRodoviarioPedagioList";
import CteRodoviarioPedagioCreate from "./CteRodoviarioPedagioCreate";
import CteRodoviarioPedagioEdit from "./CteRodoviarioPedagioEdit";

export default {
	list: CteRodoviarioPedagioList,
	create: CteRodoviarioPedagioCreate,
	edit: CteRodoviarioPedagioEdit,
	icon: CteRodoviarioPedagioIcon,
};
