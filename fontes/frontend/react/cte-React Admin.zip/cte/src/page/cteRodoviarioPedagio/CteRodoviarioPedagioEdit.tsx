import {
	Edit,
} from "react-admin";
import { CteRodoviarioPedagioForm } from "./CteRodoviarioPedagioForm";

const CteRodoviarioPedagioEdit = () => {
	return (
		<Edit>
			<CteRodoviarioPedagioForm />
		</Edit>
	);
};

export default CteRodoviarioPedagioEdit;