import {
	Create,
} from "react-admin";
import { CteRodoviarioLacreForm } from "./CteRodoviarioLacreForm";

const CteRodoviarioLacreCreate = () => {
	return (
		<Create>
			<CteRodoviarioLacreForm />
		</Create>
	);
};

export default CteRodoviarioLacreCreate;