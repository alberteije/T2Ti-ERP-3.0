/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CteRodoviarioLacreList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteRodoviarioModel.rntrc","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteRodoviarioLacreSmallScreenList : CteRodoviarioLacreBigScreenList;

	return (
		<List
			title="Cte Rodoviario Lacre"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteRodoviarioLacreSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteRodoviarioModel.rntrc }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const CteRodoviarioLacreBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Rodoviario" source="cteRodoviarioModel.id" reference="cte-rodoviario" sortable={false}>
				<TextField source="rntrc" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteRodoviarioLacreList;
