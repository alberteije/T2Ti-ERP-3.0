import {
	Edit,
} from "react-admin";
import { CteRodoviarioLacreForm } from "./CteRodoviarioLacreForm";

const CteRodoviarioLacreEdit = () => {
	return (
		<Edit>
			<CteRodoviarioLacreForm />
		</Edit>
	);
};

export default CteRodoviarioLacreEdit;