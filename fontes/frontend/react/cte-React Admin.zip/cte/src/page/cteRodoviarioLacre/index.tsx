import CteRodoviarioLacreIcon from "@mui/icons-material/Apps";
import CteRodoviarioLacreList from "./CteRodoviarioLacreList";
import CteRodoviarioLacreCreate from "./CteRodoviarioLacreCreate";
import CteRodoviarioLacreEdit from "./CteRodoviarioLacreEdit";

export default {
	list: CteRodoviarioLacreList,
	create: CteRodoviarioLacreCreate,
	edit: CteRodoviarioLacreEdit,
	icon: CteRodoviarioLacreIcon,
};
