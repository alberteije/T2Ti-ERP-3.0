import {
	Edit,
} from "react-admin";
import { CteRodoviarioVeiculoForm } from "./CteRodoviarioVeiculoForm";

const CteRodoviarioVeiculoEdit = () => {
	return (
		<Edit>
			<CteRodoviarioVeiculoForm />
		</Edit>
	);
};

export default CteRodoviarioVeiculoEdit;