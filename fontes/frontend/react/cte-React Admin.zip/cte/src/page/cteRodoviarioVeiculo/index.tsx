import CteRodoviarioVeiculoIcon from "@mui/icons-material/Apps";
import CteRodoviarioVeiculoList from "./CteRodoviarioVeiculoList";
import CteRodoviarioVeiculoCreate from "./CteRodoviarioVeiculoCreate";
import CteRodoviarioVeiculoEdit from "./CteRodoviarioVeiculoEdit";

export default {
	list: CteRodoviarioVeiculoList,
	create: CteRodoviarioVeiculoCreate,
	edit: CteRodoviarioVeiculoEdit,
	icon: CteRodoviarioVeiculoIcon,
};
