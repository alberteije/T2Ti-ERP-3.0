import {
	Create,
} from "react-admin";
import { CteRodoviarioVeiculoForm } from "./CteRodoviarioVeiculoForm";

const CteRodoviarioVeiculoCreate = () => {
	return (
		<Create>
			<CteRodoviarioVeiculoForm />
		</Create>
	);
};

export default CteRodoviarioVeiculoCreate;