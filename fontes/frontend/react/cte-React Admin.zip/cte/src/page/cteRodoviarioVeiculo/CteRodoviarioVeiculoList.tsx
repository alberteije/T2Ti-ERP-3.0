/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import CteRodoviarioVeiculoDomain from '../../data/domain/CteRodoviarioVeiculoDomain';

const CteRodoviarioVeiculoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteRodoviarioModel.rntrc","codigoInterno","renavam"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteRodoviarioVeiculoSmallScreenList : CteRodoviarioVeiculoBigScreenList;

	return (
		<List
			title="Cte Rodoviario Veiculo"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteRodoviarioVeiculoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteRodoviarioModel.rntrc }
			secondaryText={ (record) => record.codigoInterno }
			tertiaryText={ (record) => record.renavam }
		/>
	);
}

const CteRodoviarioVeiculoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Rodoviario" source="cteRodoviarioModel.id" reference="cte-rodoviario" sortable={false}>
				<TextField source="rntrc" />
			</ReferenceField>
			<TextField source="codigoInterno" label="Codigo Interno" />
			<TextField source="renavam" label="Renavam" />
			<TextField source="placa" label="Placa" />
			<TextField source="tara" label="Tara" />
			<TextField source="capacidadeKg" label="Capacidade Kg" />
			<TextField source="capacidadeM3" label="Capacidade M3" />
			<FunctionField
				label="Tipo Propriedade"
				render={record => CteRodoviarioVeiculoDomain.getTipoPropriedade(record.tipoPropriedade)}
			/>
			<FunctionField
				label="Tipo Veiculo"
				render={record => CteRodoviarioVeiculoDomain.getTipoVeiculo(record.tipoVeiculo)}
			/>
			<FunctionField
				label="Tipo Rodado"
				render={record => CteRodoviarioVeiculoDomain.getTipoRodado(record.tipoRodado)}
			/>
			<FunctionField
				label="Tipo Carroceria"
				render={record => CteRodoviarioVeiculoDomain.getTipoCarroceria(record.tipoCarroceria)}
			/>
			<FunctionField
				label="Uf"
				render={record => CteRodoviarioVeiculoDomain.getUf(record.uf)}
			/>
			<FunctionField
				source="proprietarioCpf"
				label="Proprietario Cpf"
				render={record => formatWithMask(record.proprietarioCpf, '###.###.###-##')}
			/>
			<FunctionField
				source="proprietarioCnpj"
				label="Proprietario Cnpj"
				render={record => formatWithMask(record.proprietarioCnpj, '##.###.###/####-##')}
			/>
			<TextField source="proprietarioRntrc" label="Proprietario Rntrc" />
			<TextField source="proprietarioNome" label="Proprietario Nome" />
			<TextField source="proprietarioIe" label="Proprietario Ie" />
			<FunctionField
				label="Proprietario Uf"
				render={record => CteRodoviarioVeiculoDomain.getProprietarioUf(record.proprietarioUf)}
			/>
			<FunctionField
				label="Proprietario Tipo"
				render={record => CteRodoviarioVeiculoDomain.getProprietarioTipo(record.proprietarioTipo)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteRodoviarioVeiculoList;
