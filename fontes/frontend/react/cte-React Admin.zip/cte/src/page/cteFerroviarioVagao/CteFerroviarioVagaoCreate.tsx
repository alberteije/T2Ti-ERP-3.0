import {
	Create,
} from "react-admin";
import { CteFerroviarioVagaoForm } from "./CteFerroviarioVagaoForm";

const CteFerroviarioVagaoCreate = () => {
	return (
		<Create>
			<CteFerroviarioVagaoForm />
		</Create>
	);
};

export default CteFerroviarioVagaoCreate;