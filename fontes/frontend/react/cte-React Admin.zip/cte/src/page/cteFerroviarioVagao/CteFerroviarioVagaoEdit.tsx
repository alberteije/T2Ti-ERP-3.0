import {
	Edit,
} from "react-admin";
import { CteFerroviarioVagaoForm } from "./CteFerroviarioVagaoForm";

const CteFerroviarioVagaoEdit = () => {
	return (
		<Edit>
			<CteFerroviarioVagaoForm />
		</Edit>
	);
};

export default CteFerroviarioVagaoEdit;