/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CteFerroviarioVagaoDomain from '../../data/domain/CteFerroviarioVagaoDomain';

const CteFerroviarioVagaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteFerroviarioModel.fluxo","numeroVagao","capacidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteFerroviarioVagaoSmallScreenList : CteFerroviarioVagaoBigScreenList;

	return (
		<List
			title="Cte Ferroviario Vagao"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteFerroviarioVagaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteFerroviarioModel.fluxo }
			secondaryText={ (record) => record.numeroVagao }
			tertiaryText={ (record) => record.capacidade }
		/>
	);
}

const CteFerroviarioVagaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Ferroviario" source="cteFerroviarioModel.id" reference="cte-ferroviario" sortable={false}>
				<TextField source="fluxo" />
			</ReferenceField>
			<TextField source="numeroVagao" label="Numero Vagao" />
			<NumberField source="capacidade" label="Capacidade" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Tipo Vagao"
				render={record => CteFerroviarioVagaoDomain.getTipoVagao(record.tipoVagao)}
			/>
			<NumberField source="pesoReal" label="Peso Real" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="pesoBc" label="Peso Bc" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteFerroviarioVagaoList;
