import CteFerroviarioVagaoIcon from "@mui/icons-material/Apps";
import CteFerroviarioVagaoList from "./CteFerroviarioVagaoList";
import CteFerroviarioVagaoCreate from "./CteFerroviarioVagaoCreate";
import CteFerroviarioVagaoEdit from "./CteFerroviarioVagaoEdit";

export default {
	list: CteFerroviarioVagaoList,
	create: CteFerroviarioVagaoCreate,
	edit: CteFerroviarioVagaoEdit,
	icon: CteFerroviarioVagaoIcon,
};
