import {
	Create,
} from "react-admin";
import { CteInfNfTransporteLacreForm } from "./CteInfNfTransporteLacreForm";

const CteInfNfTransporteLacreCreate = () => {
	return (
		<Create>
			<CteInfNfTransporteLacreForm />
		</Create>
	);
};

export default CteInfNfTransporteLacreCreate;