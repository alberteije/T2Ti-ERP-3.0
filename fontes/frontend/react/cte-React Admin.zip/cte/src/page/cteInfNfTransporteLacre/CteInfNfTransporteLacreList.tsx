/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CteInfNfTransporteLacreList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteInformacaoNfTransporteModel.tipoUnidadeTransporte","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteInfNfTransporteLacreSmallScreenList : CteInfNfTransporteLacreBigScreenList;

	return (
		<List
			title="Cte Inf Nf Transporte Lacre"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteInfNfTransporteLacreSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteInformacaoNfTransporteModel.tipoUnidadeTransporte }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const CteInfNfTransporteLacreBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Informacao Nf Transporte" source="cteInformacaoNfTransporteModel.id" reference="cte-informacao-nf-transporte" sortable={false}>
				<TextField source="tipoUnidadeTransporte" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteInfNfTransporteLacreList;
