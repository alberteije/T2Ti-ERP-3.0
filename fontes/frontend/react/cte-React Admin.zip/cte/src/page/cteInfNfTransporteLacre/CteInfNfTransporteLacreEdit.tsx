import {
	Edit,
} from "react-admin";
import { CteInfNfTransporteLacreForm } from "./CteInfNfTransporteLacreForm";

const CteInfNfTransporteLacreEdit = () => {
	return (
		<Edit>
			<CteInfNfTransporteLacreForm />
		</Edit>
	);
};

export default CteInfNfTransporteLacreEdit;