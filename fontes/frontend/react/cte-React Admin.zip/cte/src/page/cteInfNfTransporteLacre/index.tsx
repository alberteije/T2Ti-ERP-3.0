import CteInfNfTransporteLacreIcon from "@mui/icons-material/Apps";
import CteInfNfTransporteLacreList from "./CteInfNfTransporteLacreList";
import CteInfNfTransporteLacreCreate from "./CteInfNfTransporteLacreCreate";
import CteInfNfTransporteLacreEdit from "./CteInfNfTransporteLacreEdit";

export default {
	list: CteInfNfTransporteLacreList,
	create: CteInfNfTransporteLacreCreate,
	edit: CteInfNfTransporteLacreEdit,
	icon: CteInfNfTransporteLacreIcon,
};
