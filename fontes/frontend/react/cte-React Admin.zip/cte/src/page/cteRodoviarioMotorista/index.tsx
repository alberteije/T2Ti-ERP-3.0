import CteRodoviarioMotoristaIcon from "@mui/icons-material/Apps";
import CteRodoviarioMotoristaList from "./CteRodoviarioMotoristaList";
import CteRodoviarioMotoristaCreate from "./CteRodoviarioMotoristaCreate";
import CteRodoviarioMotoristaEdit from "./CteRodoviarioMotoristaEdit";

export default {
	list: CteRodoviarioMotoristaList,
	create: CteRodoviarioMotoristaCreate,
	edit: CteRodoviarioMotoristaEdit,
	icon: CteRodoviarioMotoristaIcon,
};
