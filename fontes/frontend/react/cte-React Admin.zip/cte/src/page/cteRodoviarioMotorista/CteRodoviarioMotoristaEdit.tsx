import {
	Edit,
} from "react-admin";
import { CteRodoviarioMotoristaForm } from "./CteRodoviarioMotoristaForm";

const CteRodoviarioMotoristaEdit = () => {
	return (
		<Edit>
			<CteRodoviarioMotoristaForm />
		</Edit>
	);
};

export default CteRodoviarioMotoristaEdit;