import {
	Create,
} from "react-admin";
import { CteRodoviarioMotoristaForm } from "./CteRodoviarioMotoristaForm";

const CteRodoviarioMotoristaCreate = () => {
	return (
		<Create>
			<CteRodoviarioMotoristaForm />
		</Create>
	);
};

export default CteRodoviarioMotoristaCreate;