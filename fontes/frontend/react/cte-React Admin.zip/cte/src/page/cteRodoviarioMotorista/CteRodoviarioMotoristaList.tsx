/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const CteRodoviarioMotoristaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteRodoviarioModel.rntrc","nome","cpf"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteRodoviarioMotoristaSmallScreenList : CteRodoviarioMotoristaBigScreenList;

	return (
		<List
			title="Cte Rodoviario Motorista"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteRodoviarioMotoristaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteRodoviarioModel.rntrc }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.cpf }
		/>
	);
}

const CteRodoviarioMotoristaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Rodoviario" source="cteRodoviarioModel.id" reference="cte-rodoviario" sortable={false}>
				<TextField source="rntrc" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<FunctionField
				source="cpf"
				label="Cpf"
				render={record => formatWithMask(record.cpf, '###.###.###-##')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteRodoviarioMotoristaList;
