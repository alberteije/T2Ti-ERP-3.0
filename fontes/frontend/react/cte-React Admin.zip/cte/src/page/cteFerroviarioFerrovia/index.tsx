import CteFerroviarioFerroviaIcon from "@mui/icons-material/Apps";
import CteFerroviarioFerroviaList from "./CteFerroviarioFerroviaList";
import CteFerroviarioFerroviaCreate from "./CteFerroviarioFerroviaCreate";
import CteFerroviarioFerroviaEdit from "./CteFerroviarioFerroviaEdit";

export default {
	list: CteFerroviarioFerroviaList,
	create: CteFerroviarioFerroviaCreate,
	edit: CteFerroviarioFerroviaEdit,
	icon: CteFerroviarioFerroviaIcon,
};
