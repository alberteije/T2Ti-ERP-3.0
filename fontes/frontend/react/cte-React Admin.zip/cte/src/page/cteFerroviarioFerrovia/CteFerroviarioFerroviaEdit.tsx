import {
	Edit,
} from "react-admin";
import { CteFerroviarioFerroviaForm } from "./CteFerroviarioFerroviaForm";

const CteFerroviarioFerroviaEdit = () => {
	return (
		<Edit>
			<CteFerroviarioFerroviaForm />
		</Edit>
	);
};

export default CteFerroviarioFerroviaEdit;