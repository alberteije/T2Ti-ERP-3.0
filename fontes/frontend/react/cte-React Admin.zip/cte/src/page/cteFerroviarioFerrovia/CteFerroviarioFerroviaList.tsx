/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import CteFerroviarioFerroviaDomain from '../../data/domain/CteFerroviarioFerroviaDomain';

const CteFerroviarioFerroviaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cteFerroviarioModel.fluxo","cnpj","codigoInterno"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CteFerroviarioFerroviaSmallScreenList : CteFerroviarioFerroviaBigScreenList;

	return (
		<List
			title="Cte Ferroviario Ferrovia"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CteFerroviarioFerroviaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cteFerroviarioModel.fluxo }
			secondaryText={ (record) => record.cnpj }
			tertiaryText={ (record) => record.codigoInterno }
		/>
	);
}

const CteFerroviarioFerroviaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cte Ferroviario" source="cteFerroviarioModel.id" reference="cte-ferroviario" sortable={false}>
				<TextField source="fluxo" />
			</ReferenceField>
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<TextField source="codigoInterno" label="Codigo Interno" />
			<TextField source="ie" label="Ie" />
			<TextField source="nome" label="Nome" />
			<TextField source="logradouro" label="Logradouro" />
			<TextField source="numero" label="Numero" />
			<TextField source="complemento" label="Complemento" />
			<TextField source="bairro" label="Bairro" />
			<TextField source="codigoMunicipio" label="Codigo Municipio" />
			<TextField source="nomeMunicipio" label="Nome Municipio" />
			<FunctionField
				label="Uf"
				render={record => CteFerroviarioFerroviaDomain.getUf(record.uf)}
			/>
			<FunctionField
				source="cep"
				label="Cep"
				render={record => formatWithMask(record.cep, '#####-###')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CteFerroviarioFerroviaList;
