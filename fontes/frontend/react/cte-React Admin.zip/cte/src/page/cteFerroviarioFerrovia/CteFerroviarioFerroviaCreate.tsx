import {
	Create,
} from "react-admin";
import { CteFerroviarioFerroviaForm } from "./CteFerroviarioFerroviaForm";

const CteFerroviarioFerroviaCreate = () => {
	return (
		<Create>
			<CteFerroviarioFerroviaForm />
		</Create>
	);
};

export default CteFerroviarioFerroviaCreate;