class PessoaDomain {
	static getTipo(tipo: string) { 
		switch (tipo) { 
			case '': 
			case 'F': 
				return 'Física'; 
			case 'J': 
				return 'Jurídica'; 
			default: 
				return null; 
		} 
	} 

	static setTipo(tipo: string) { 
		switch (tipo) { 
			case 'Física': 
				return 'F'; 
			case 'Jurídica': 
				return 'J'; 
			default: 
				return null; 
		} 
	}

	static getEhCliente(ehCliente: string) { 
		switch (ehCliente) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhCliente(ehCliente: string) { 
		switch (ehCliente) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEhFornecedor(ehFornecedor: string) { 
		switch (ehFornecedor) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhFornecedor(ehFornecedor: string) { 
		switch (ehFornecedor) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEhTransportadora(ehTransportadora: string) { 
		switch (ehTransportadora) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhTransportadora(ehTransportadora: string) { 
		switch (ehTransportadora) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEhColaborador(ehColaborador: string) { 
		switch (ehColaborador) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhColaborador(ehColaborador: string) { 
		switch (ehColaborador) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getEhContador(ehContador: string) { 
		switch (ehContador) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setEhContador(ehContador: string) { 
		switch (ehContador) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default PessoaDomain;