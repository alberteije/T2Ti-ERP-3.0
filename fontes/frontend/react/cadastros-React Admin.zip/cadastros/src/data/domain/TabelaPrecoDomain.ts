class TabelaPrecoDomain {
	static getPrincipal(principal: string) { 
		switch (principal) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPrincipal(principal: string) { 
		switch (principal) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default TabelaPrecoDomain;