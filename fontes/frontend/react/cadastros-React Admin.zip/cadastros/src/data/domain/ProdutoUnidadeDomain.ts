class ProdutoUnidadeDomain {
	static getPodeFracionar(podeFracionar: string) { 
		switch (podeFracionar) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPodeFracionar(podeFracionar: string) { 
		switch (podeFracionar) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default ProdutoUnidadeDomain;