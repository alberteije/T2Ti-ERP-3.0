class ColaboradorRelacionamentoDomain {
	static getSalarioFamilia(salarioFamilia: string) { 
		switch (salarioFamilia) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setSalarioFamilia(salarioFamilia: string) { 
		switch (salarioFamilia) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default ColaboradorRelacionamentoDomain;