class BancoDomain {
	static getParticipaCompe(participaCompe: string) { 
		switch (participaCompe) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setParticipaCompe(participaCompe: string) { 
		switch (participaCompe) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default BancoDomain;