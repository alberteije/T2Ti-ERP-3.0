class PapelFuncaoDomain {
	static getHabilitado(habilitado: string) { 
		switch (habilitado) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setHabilitado(habilitado: string) { 
		switch (habilitado) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPodeInserir(podeInserir: string) { 
		switch (podeInserir) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPodeInserir(podeInserir: string) { 
		switch (podeInserir) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPodeAlterar(podeAlterar: string) { 
		switch (podeAlterar) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPodeAlterar(podeAlterar: string) { 
		switch (podeAlterar) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

	static getPodeExcluir(podeExcluir: string) { 
		switch (podeExcluir) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setPodeExcluir(podeExcluir: string) { 
		switch (podeExcluir) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default PapelFuncaoDomain;