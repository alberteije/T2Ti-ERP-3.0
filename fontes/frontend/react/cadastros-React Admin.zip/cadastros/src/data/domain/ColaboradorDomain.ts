class ColaboradorDomain {
	static getCtpsUf(ctpsUf: string) { 
		switch (ctpsUf) { 
			case '': 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AM': 
				return 'AM'; 
			case 'AP': 
				return 'AP'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MG': 
				return 'MG'; 
			case 'MS': 
				return 'MS'; 
			case 'MT': 
				return 'MT'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'PR': 
				return 'PR'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'RS': 
				return 'RS'; 
			case 'SC': 
				return 'SC'; 
			case 'SE': 
				return 'SE'; 
			case 'SP': 
				return 'SP'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	} 

	static setCtpsUf(ctpsUf: string) { 
		switch (ctpsUf) { 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AM': 
				return 'AM'; 
			case 'AP': 
				return 'AP'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MG': 
				return 'MG'; 
			case 'MS': 
				return 'MS'; 
			case 'MT': 
				return 'MT'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'PR': 
				return 'PR'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'RS': 
				return 'RS'; 
			case 'SC': 
				return 'SC'; 
			case 'SE': 
				return 'SE'; 
			case 'SP': 
				return 'SP'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	}

}

export default ColaboradorDomain;