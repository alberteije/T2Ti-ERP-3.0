import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import pessoa from '../page/pessoa';
import colaborador from '../page/colaborador';
import estadoCivil from '../page/estadoCivil';
import cargo from '../page/cargo';
import setor from '../page/setor';
import colaboradorSituacao from '../page/colaboradorSituacao';
import tipoAdmissao from '../page/tipoAdmissao';
import colaboradorTipo from '../page/colaboradorTipo';
import produtoGrupo from '../page/produtoGrupo';
import produtoSubgrupo from '../page/produtoSubgrupo';
import produtoMarca from '../page/produtoMarca';
import produtoUnidade from '../page/produtoUnidade';
import produto from '../page/produto';
import banco from '../page/banco';
import bancoAgencia from '../page/bancoAgencia';
import bancoContaCaixa from '../page/bancoContaCaixa';
import cep from '../page/cep';
import uf from '../page/uf';
import municipio from '../page/municipio';
import ncm from '../page/ncm';
import cfop from '../page/cfop';
import cstIcms from '../page/cstIcms';
import cstIpi from '../page/cstIpi';
import cstCofins from '../page/cstCofins';
import cstPis from '../page/cstPis';
import csosn from '../page/csosn';
import cnae from '../page/cnae';
import pais from '../page/pais';
import nivelFormacao from '../page/nivelFormacao';
import tabelaPreco from '../page/tabelaPreco';
import tipoRelacionamento from '../page/tipoRelacionamento';
import sindicato from '../page/sindicato';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/estado-civil'
					state={{ _scrollToTop: true }}
					primaryText='Estado Civil'
					leftIcon={<estadoCivil.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cargo'
					state={{ _scrollToTop: true }}
					primaryText='Cargo'
					leftIcon={<cargo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/setor'
					state={{ _scrollToTop: true }}
					primaryText='Setor'
					leftIcon={<setor.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/colaborador-situacao'
					state={{ _scrollToTop: true }}
					primaryText='Situação Colaborador'
					leftIcon={<colaboradorSituacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tipo-admissao'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Admissão'
					leftIcon={<tipoAdmissao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/colaborador-tipo'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Colaborador'
					leftIcon={<colaboradorTipo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/produto-grupo'
					state={{ _scrollToTop: true }}
					primaryText='Grupo Produto'
					leftIcon={<produtoGrupo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/produto-subgrupo'
					state={{ _scrollToTop: true }}
					primaryText='Subgrupo Produto'
					leftIcon={<produtoSubgrupo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/produto-marca'
					state={{ _scrollToTop: true }}
					primaryText='Marca Produto'
					leftIcon={<produtoMarca.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/produto-unidade'
					state={{ _scrollToTop: true }}
					primaryText='Unidade Produto'
					leftIcon={<produtoUnidade.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/produto'
					state={{ _scrollToTop: true }}
					primaryText='Produto'
					leftIcon={<produto.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/banco'
					state={{ _scrollToTop: true }}
					primaryText='Banco'
					leftIcon={<banco.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/banco-agencia'
					state={{ _scrollToTop: true }}
					primaryText='Agência'
					leftIcon={<bancoAgencia.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/banco-conta-caixa'
					state={{ _scrollToTop: true }}
					primaryText='Conta/Caixa'
					leftIcon={<bancoContaCaixa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cep'
					state={{ _scrollToTop: true }}
					primaryText='CEP'
					leftIcon={<cep.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/uf'
					state={{ _scrollToTop: true }}
					primaryText='UF'
					leftIcon={<uf.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/municipio'
					state={{ _scrollToTop: true }}
					primaryText='Município'
					leftIcon={<municipio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/ncm'
					state={{ _scrollToTop: true }}
					primaryText='NCM'
					leftIcon={<ncm.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cfop'
					state={{ _scrollToTop: true }}
					primaryText='CFOP'
					leftIcon={<cfop.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cst-icms'
					state={{ _scrollToTop: true }}
					primaryText='CST ICMS'
					leftIcon={<cstIcms.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cst-ipi'
					state={{ _scrollToTop: true }}
					primaryText='CST IPI'
					leftIcon={<cstIpi.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cst-cofins'
					state={{ _scrollToTop: true }}
					primaryText='CST COFINS'
					leftIcon={<cstCofins.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cst-pis'
					state={{ _scrollToTop: true }}
					primaryText='CST PIS'
					leftIcon={<cstPis.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/csosn'
					state={{ _scrollToTop: true }}
					primaryText='CSOSN'
					leftIcon={<csosn.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/cnae'
					state={{ _scrollToTop: true }}
					primaryText='CNAE'
					leftIcon={<cnae.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/pais'
					state={{ _scrollToTop: true }}
					primaryText='País'
					leftIcon={<pais.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nivel-formacao'
					state={{ _scrollToTop: true }}
					primaryText='Nível Formação'
					leftIcon={<nivelFormacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tabela-preco'
					state={{ _scrollToTop: true }}
					primaryText='Tabelas de Preço'
					leftIcon={<tabelaPreco.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/tipo-relacionamento'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Relacionamento'
					leftIcon={<tipoRelacionamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/sindicato'
					state={{ _scrollToTop: true }}
					primaryText='Sindicato'
					leftIcon={<sindicato.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/pessoa'
					state={{ _scrollToTop: true }}
					primaryText='Pessoa'
					leftIcon={<pessoa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/colaborador'
					state={{ _scrollToTop: true }}
					primaryText='Colaborador'
					leftIcon={<colaborador.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
