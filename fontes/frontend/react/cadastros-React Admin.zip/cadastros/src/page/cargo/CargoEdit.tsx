import {
	Edit,
} from "react-admin";
import { CargoForm } from "./CargoForm";

const CargoEdit = () => {
	return (
		<Edit>
			<CargoForm />
		</Edit>
	);
};

export default CargoEdit;