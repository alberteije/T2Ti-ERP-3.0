/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const CargoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='salario'
					label='Salario'
					helperText='Informe os dados para o campo Salario'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='cbo1994'
					label='Cbo 1994'
					helperText='Informe os dados para o campo Cbo 1994[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='cbo2002'
					label='Cbo 2002'
					helperText='Informe os dados para o campo Cbo 2002[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);