import {
	Create,
} from "react-admin";
import { CargoForm } from "./CargoForm";

const CargoCreate = () => {
	return (
		<Create>
			<CargoForm />
		</Create>
	);
};

export default CargoCreate;