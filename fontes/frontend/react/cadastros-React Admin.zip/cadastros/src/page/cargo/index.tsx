import CargoIcon from "@mui/icons-material/Apps";
import CargoList from "./CargoList";
import CargoCreate from "./CargoCreate";
import CargoEdit from "./CargoEdit";

export default {
	list: CargoList,
	create: CargoCreate,
	edit: CargoEdit,
	icon: CargoIcon,
};
