/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CargoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","descricao","salario"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CargoSmallScreenList : CargoBigScreenList;

	return (
		<List
			title="Cargo"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CargoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.salario }
		/>
	);
}

const CargoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<NumberField source="salario" label="Salario" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="cbo1994" label="Cbo 1994" />
			<TextField source="cbo2002" label="Cbo 2002" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CargoList;
