import {
	Create,
} from "react-admin";
import { PaisForm } from "./PaisForm";

const PaisCreate = () => {
	return (
		<Create>
			<PaisForm />
		</Create>
	);
};

export default PaisCreate;