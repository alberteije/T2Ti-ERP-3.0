/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const PaisForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nomePtbr'
					label='Nome Português'
					helperText='Informe os dados para o campo Nome Português[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nomeEn'
					label='Nome Inglês'
					helperText='Informe os dados para o campo Nome Inglês[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='sigla2'
					label='Sigla 2 Caracteres'
					helperText='Informe os dados para o campo Sigla 2 Caracteres[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='sigla3'
					label='Sigla 3 Caracteres'
					helperText='Informe os dados para o campo Sigla 3 Caracteres[3]'
					validate={[maxLength(3, 'Max=3'), ]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='codigoBacen'
					label='Codigo Bacen'
					helperText='Informe os dados para o campo Codigo Bacen'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);