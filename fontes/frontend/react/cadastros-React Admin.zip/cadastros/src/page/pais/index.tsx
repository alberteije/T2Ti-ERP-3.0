import PaisIcon from "@mui/icons-material/Apps";
import PaisList from "./PaisList";
import PaisCreate from "./PaisCreate";
import PaisEdit from "./PaisEdit";

export default {
	list: PaisList,
	create: PaisCreate,
	edit: PaisEdit,
	icon: PaisIcon,
};
