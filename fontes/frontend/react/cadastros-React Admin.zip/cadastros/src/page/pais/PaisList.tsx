/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PaisList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nomePtbr","nomeEn","codigo"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PaisSmallScreenList : PaisBigScreenList;

	return (
		<List
			title="País"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PaisSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nomePtbr }
			secondaryText={ (record) => record.nomeEn }
			tertiaryText={ (record) => record.codigo }
		/>
	);
}

const PaisBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nomePtbr" label="Nome Ptbr" />
			<TextField source="nomeEn" label="Nome En" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="sigla2" label="Sigla2" />
			<TextField source="sigla3" label="Sigla3" />
			<TextField source="codigoBacen" label="Codigo Bacen" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PaisList;
