import {
	Edit,
} from "react-admin";
import { PaisForm } from "./PaisForm";

const PaisEdit = () => {
	return (
		<Edit>
			<PaisForm />
		</Edit>
	);
};

export default PaisEdit;