import {
	Edit,
} from "react-admin";
import { TipoAdmissaoForm } from "./TipoAdmissaoForm";

const TipoAdmissaoEdit = () => {
	return (
		<Edit>
			<TipoAdmissaoForm />
		</Edit>
	);
};

export default TipoAdmissaoEdit;