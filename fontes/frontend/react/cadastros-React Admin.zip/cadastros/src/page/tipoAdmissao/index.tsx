import TipoAdmissaoIcon from "@mui/icons-material/Apps";
import TipoAdmissaoList from "./TipoAdmissaoList";
import TipoAdmissaoCreate from "./TipoAdmissaoCreate";
import TipoAdmissaoEdit from "./TipoAdmissaoEdit";

export default {
	list: TipoAdmissaoList,
	create: TipoAdmissaoCreate,
	edit: TipoAdmissaoEdit,
	icon: TipoAdmissaoIcon,
};
