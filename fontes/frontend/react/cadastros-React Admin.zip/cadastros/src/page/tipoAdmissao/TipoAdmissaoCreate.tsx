import {
	Create,
} from "react-admin";
import { TipoAdmissaoForm } from "./TipoAdmissaoForm";

const TipoAdmissaoCreate = () => {
	return (
		<Create>
			<TipoAdmissaoForm />
		</Create>
	);
};

export default TipoAdmissaoCreate;