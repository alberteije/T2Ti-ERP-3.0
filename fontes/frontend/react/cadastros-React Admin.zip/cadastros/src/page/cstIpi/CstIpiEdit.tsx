import {
	Edit,
} from "react-admin";
import { CstIpiForm } from "./CstIpiForm";

const CstIpiEdit = () => {
	return (
		<Edit>
			<CstIpiForm />
		</Edit>
	);
};

export default CstIpiEdit;