import {
	Create,
} from "react-admin";
import { CstIpiForm } from "./CstIpiForm";

const CstIpiCreate = () => {
	return (
		<Create>
			<CstIpiForm />
		</Create>
	);
};

export default CstIpiCreate;