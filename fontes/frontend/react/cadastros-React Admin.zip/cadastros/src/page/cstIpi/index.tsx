import CstIpiIcon from "@mui/icons-material/Apps";
import CstIpiList from "./CstIpiList";
import CstIpiCreate from "./CstIpiCreate";
import CstIpiEdit from "./CstIpiEdit";

export default {
	list: CstIpiList,
	create: CstIpiCreate,
	edit: CstIpiEdit,
	icon: CstIpiIcon,
};
