/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import PessoaDomain from '../../data/domain/PessoaDomain';

const PessoaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","tipo","site"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PessoaSmallScreenList : PessoaBigScreenList;

	return (
		<List
			title="Pessoa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PessoaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.tipo }
			tertiaryText={ (record) => record.site }
		/>
	);
}

const PessoaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Tipo"
				render={record => PessoaDomain.getTipo(record.tipo)}
			/>
			<TextField source="site" label="Site" />
			<TextField source="email" label="Email" />
			<FunctionField
				label="Eh Cliente"
				render={record => PessoaDomain.getEhCliente(record.ehCliente)}
			/>
			<FunctionField
				label="Eh Fornecedor"
				render={record => PessoaDomain.getEhFornecedor(record.ehFornecedor)}
			/>
			<FunctionField
				label="Eh Transportadora"
				render={record => PessoaDomain.getEhTransportadora(record.ehTransportadora)}
			/>
			<FunctionField
				label="Eh Colaborador"
				render={record => PessoaDomain.getEhColaborador(record.ehColaborador)}
			/>
			<FunctionField
				label="Eh Contador"
				render={record => PessoaDomain.getEhContador(record.ehContador)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PessoaList;
