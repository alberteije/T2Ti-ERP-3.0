import PessoaIcon from "@mui/icons-material/Apps";
import PessoaList from "./PessoaList";
import PessoaCreate from "./PessoaCreate";
import PessoaEdit from "./PessoaEdit";

export default {
	list: PessoaList,
	create: PessoaCreate,
	edit: PessoaEdit,
	icon: PessoaIcon,
};
