/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	SelectInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'
import { formatWithMask } from '../../infra/utils';
import PessoaTelefoneDomain from '../../data/domain/PessoaTelefoneDomain';

class PessoaTelefone {
	constructor(
		public id = 0,
		public tipo = '',
		public numero = '',
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PessoaTelefone {
		const pessoaTelefone = new PessoaTelefone();
		pessoaTelefone.id = Date.now();
		pessoaTelefone.statusCrud = "C";
		return pessoaTelefone;
	}
}

export const PessoaTelefoneTab: React.FC = () => {

	const renderForm = (
		currentRecord: PessoaTelefone,
		setCurrentRecord: (record: PessoaTelefone) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Tipo'
					source='tipo'
					helperText='Informe os dados para o campo Tipo'
					choices={ [{"id":"0","name":"Fixo"},{"id":"1","name":"Celular"},{"id":"2","name":"Whatsapp"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							tipo: e.target.value,
						});
					}} format={(_: any) => currentRecord.tipo ?? ''}
				/>
			</Box>
			<Box flex={6}>
				<MaskedTextInput
					mask='(##)#####-####'
					source='numero'
					label='Numero'
					helperText='Informe os dados para o campo Numero'
					validate={[]}
					onBlur={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							numero: e.target.value,
						});
					}}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'tipo', label: 'Tipo', formatDomain: PessoaTelefoneDomain.getTipo },
		{ source: 'numero', label: 'Numero', formatMask: formatWithMask, mask: '(##)#####-####' },
	];

	return (
		<CrudChildTab
			title="Telefones"
			recordContext="pessoa"
			fieldSource="pessoaTelefoneModelList"
			newObject={ PessoaTelefone.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};