/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	DateInput,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'

export const PessoaFisicaTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='pessoaFisicaModel.nivelFormacaoModel.id' reference='nivel-formacao' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Nivel Formacao'
						optionText='nome'
						helperText='Informe os dados para o campo Nivel Formacao'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='pessoaFisicaModel.estadoCivilModel.id' reference='estado-civil' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Estado Civil'
						optionText='nome'
						helperText='Informe os dados para o campo Estado Civil'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<MaskedTextInput
					mask='###.###.###-##'
					source='pessoaFisicaModel.cpf'
					label='CPF'
					helperText='Informe os dados para o campo CPF'
					validate={[]}
				/>
			</Box>
			<Box flex={5}>
				<TextInput
					source='pessoaFisicaModel.rg'
					label='RG'
					helperText='Informe os dados para o campo RG[20]'
					validate={[maxLength(20, 'Max=20'), ]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='pessoaFisicaModel.orgaoRg'
					label='Orgao RG'
					helperText='Informe os dados para o campo Orgao RG[20]'
					validate={[maxLength(20, 'Max=20'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<DateInput
					source='pessoaFisicaModel.dataEmissaoRg'
					label='Data Emissao RG'
					helperText='Informe os dados para o campo Data Emissao RG'
				/>
			</Box>
			<Box flex={6}>
				<DateInput
					source='pessoaFisicaModel.dataNascimento'
					label='Data Nascimento'
					helperText='Informe os dados para o campo Data Nascimento'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Sexo'
					source='pessoaFisicaModel.sexo'
					helperText='Informe os dados para o campo Sexo'
					choices={ [{"id":"0","name":"Masculino"},{"id":"1","name":"Feminino"},{"id":"2","name":"Outro"}] }  
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Raça'
					source='pessoaFisicaModel.raca'
					helperText='Informe os dados para o campo Raça'
					choices={ [{"id":"0","name":"Branco"},{"id":"1","name":"Moreno"},{"id":"2","name":"Negro"},{"id":"3","name":"Pardo"},{"id":"4","name":"Amarelo"},{"id":"5","name":"Indígena"},{"id":"6","name":"Outro"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='pessoaFisicaModel.nacionalidade'
					label='Nacionalidade'
					helperText='Informe os dados para o campo Nacionalidade[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='pessoaFisicaModel.naturalidade'
					label='Naturalidade'
					helperText='Informe os dados para o campo Naturalidade[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='pessoaFisicaModel.nomePai'
					label='Nome Pai'
					helperText='Informe os dados para o campo Nome Pai[200]'
					validate={[maxLength(200, 'Max=200'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='pessoaFisicaModel.nomeMae'
					label='Nome Mae'
					helperText='Informe os dados para o campo Nome Mae[200]'
					validate={[maxLength(200, 'Max=200'), ]}
				/>
			</Box>
		</Box>
	</>
);