/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PessoaForm } from "./PessoaForm";
import { transformNestedData } from "../../infra/utils";

const PessoaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PessoaForm />
		</Create>
	);
};

export default PessoaCreate;