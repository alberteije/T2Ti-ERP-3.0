/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	TextInput,
	maxLength,
	SelectInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'
import { formatWithMask } from '../../infra/utils';
import PessoaEnderecoDomain from '../../data/domain/PessoaEnderecoDomain';

class PessoaEndereco {
	constructor(
		public id = 0,
		public logradouro = '',
		public numero = '',
		public complemento = '',
		public bairro = '',
		public cidade = '',
		public uf = '',
		public cep = '',
		public municipioIbge = null,
		public principal = '',
		public entrega = '',
		public cobranca = '',
		public correspondencia = '',
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PessoaEndereco {
		const pessoaEndereco = new PessoaEndereco();
		pessoaEndereco.id = Date.now();
		pessoaEndereco.statusCrud = "C";
		return pessoaEndereco;
	}
}

export const PessoaEnderecoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PessoaEndereco,
		setCurrentRecord: (record: PessoaEndereco) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={9}>
				<TextInput
					source='logradouro'
					label='Logradouro'
					helperText='Informe os dados para o campo Logradouro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									logradouro: e.target.value,
								});
							}} format={(_: any) => currentRecord.logradouro ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='numero'
					label='Numero'
					helperText='Informe os dados para o campo Numero[10]'
					validate={[maxLength(10, 'Max=10'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									numero: e.target.value,
								});
							}} format={(_: any) => currentRecord.numero ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='complemento'
					label='Complemento'
					helperText='Informe os dados para o campo Complemento[100]'
					validate={[maxLength(100, 'Max=100'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									complemento: e.target.value,
								});
							}} format={(_: any) => currentRecord.complemento ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={5}>
				<TextInput
					source='bairro'
					label='Bairro'
					helperText='Informe os dados para o campo Bairro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									bairro: e.target.value,
								});
							}} format={(_: any) => currentRecord.bairro ?? ''}
				/>
			</Box>
			<Box flex={5}>
				<TextInput
					source='cidade'
					label='Cidade'
					helperText='Informe os dados para o campo Cidade[100]'
					validate={[maxLength(100, 'Max=100'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									cidade: e.target.value,
								});
							}} format={(_: any) => currentRecord.cidade ?? ''}
				/>
			</Box>
			<Box flex={2}>
				<SelectInput
					label='UF'
					source='uf'
					helperText='Informe os dados para o campo UF'
					choices={ [{"id":"AC","name":"AC"},{"id":"AL","name":"AL"},{"id":"AM","name":"AM"},{"id":"AP","name":"AP"},{"id":"BA","name":"BA"},{"id":"CE","name":"CE"},{"id":"DF","name":"DF"},{"id":"ES","name":"ES"},{"id":"GO","name":"GO"},{"id":"MA","name":"MA"},{"id":"MG","name":"MG"},{"id":"MS","name":"MS"},{"id":"MT","name":"MT"},{"id":"PA","name":"PA"},{"id":"PB","name":"PB"},{"id":"PE","name":"PE"},{"id":"PI","name":"PI"},{"id":"PR","name":"PR"},{"id":"RJ","name":"RJ"},{"id":"RN","name":"RN"},{"id":"RO","name":"RO"},{"id":"RR","name":"RR"},{"id":"RS","name":"RS"},{"id":"SC","name":"SC"},{"id":"SE","name":"SE"},{"id":"SP","name":"SP"},{"id":"TO","name":"TO"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							uf: e.target.value,
						});
					}} format={(_: any) => currentRecord.uf ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<MaskedTextInput
					mask='#####-###'
					source='cep'
					label='CEP'
					helperText='Informe os dados para o campo CEP'
					validate={[]}
					onBlur={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							cep: e.target.value,
						});
					}}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='municipioIbge'
					label='Municipio IBGE'
					helperText='Informe os dados para o campo Municipio IBGE'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									municipioIbge: e.target.value,
								});
							}} format={(_: any) => currentRecord.municipioIbge ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<SelectInput
					label='Principal'
					source='principal'
					helperText='Informe os dados para o campo Principal'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							principal: e.target.value,
						});
					}} format={(_: any) => currentRecord.principal ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Entrega'
					source='entrega'
					helperText='Informe os dados para o campo Entrega'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							entrega: e.target.value,
						});
					}} format={(_: any) => currentRecord.entrega ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Cobranca'
					source='cobranca'
					helperText='Informe os dados para o campo Cobranca'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							cobranca: e.target.value,
						});
					}} format={(_: any) => currentRecord.cobranca ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Correspondencia'
					source='correspondencia'
					helperText='Informe os dados para o campo Correspondencia'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							correspondencia: e.target.value,
						});
					}} format={(_: any) => currentRecord.correspondencia ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'cidade', label: 'Cidade' },
		{ source: 'uf', label: 'UF', formatDomain: PessoaEnderecoDomain.getUf },
		{ source: 'cep', label: 'CEP', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'municipioIbge', label: 'Municipio IBGE' },
		{ source: 'principal', label: 'Principal', formatDomain: PessoaEnderecoDomain.getPrincipal },
		{ source: 'entrega', label: 'Entrega', formatDomain: PessoaEnderecoDomain.getEntrega },
		{ source: 'cobranca', label: 'Cobranca', formatDomain: PessoaEnderecoDomain.getCobranca },
		{ source: 'correspondencia', label: 'Correspondencia', formatDomain: PessoaEnderecoDomain.getCorrespondencia },
	];

	return (
		<CrudChildTab
			title="Endereços"
			recordContext="pessoa"
			fieldSource="pessoaEnderecoModelList"
			newObject={ PessoaEndereco.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};