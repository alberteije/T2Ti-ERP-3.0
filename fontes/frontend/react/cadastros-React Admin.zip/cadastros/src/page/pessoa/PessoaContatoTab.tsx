/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	TextInput,
	maxLength,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PessoaContato {
	constructor(
		public id = 0,
		public nome = '',
		public email = '',
		public observacao = '',
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PessoaContato {
		const pessoaContato = new PessoaContato();
		pessoaContato.id = Date.now();
		pessoaContato.statusCrud = "C";
		return pessoaContato;
	}
}

export const PessoaContatoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PessoaContato,
		setCurrentRecord: (record: PessoaContato) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[150]'
					validate={[maxLength(150, 'Max=150'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									nome: e.target.value,
								});
							}} format={(_: any) => currentRecord.nome ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='email'
					label='Email'
					helperText='Informe os dados para o campo Email[250]'
					validate={[maxLength(250, 'Max=250'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									email: e.target.value,
								});
							}} format={(_: any) => currentRecord.email ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									observacao: e.target.value,
								});
							}} format={(_: any) => currentRecord.observacao ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'email', label: 'Email' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Contatos"
			recordContext="pessoa"
			fieldSource="pessoaContatoModelList"
			newObject={ PessoaContato.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};