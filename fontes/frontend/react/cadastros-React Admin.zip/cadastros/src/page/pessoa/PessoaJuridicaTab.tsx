/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	TextInput,
	maxLength,
	DateInput,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'

export const PessoaJuridicaTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<MaskedTextInput
					mask='##.###.###/####-##'
					source='pessoaJuridicaModel.cnpj'
					label='CNPJ'
					helperText='Informe os dados para o campo CNPJ'
					validate={[]}
				/>
			</Box>
			<Box flex={8}>
				<TextInput
					source='pessoaJuridicaModel.nomeFantasia'
					label='Nome Fantasia'
					helperText='Informe os dados para o campo Nome Fantasia[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='pessoaJuridicaModel.inscricaoEstadual'
					label='Inscricao Estadual'
					helperText='Informe os dados para o campo Inscricao Estadual[45]'
					validate={[maxLength(45, 'Max=45'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='pessoaJuridicaModel.inscricaoMunicipal'
					label='Inscricao Municipal'
					helperText='Informe os dados para o campo Inscricao Municipal[45]'
					validate={[maxLength(45, 'Max=45'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<DateInput
					source='pessoaJuridicaModel.dataConstituicao'
					label='Data Constituicao'
					helperText='Informe os dados para o campo Data Constituicao'
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='Tipo Regime'
					source='pessoaJuridicaModel.tipoRegime'
					helperText='Informe os dados para o campo Tipo Regime'
					choices={ [{"id":"1","name":"1-Lucro Real"},{"id":"2","name":"2-Lucro Presumido"},{"id":"3","name":"3-Simples Nacional"}] }  
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='CRT'
					source='pessoaJuridicaModel.crt'
					helperText='Informe os dados para o campo CRT'
					choices={ [{"id":"1","name":"1-Simples Nacional"},{"id":"2","name":"2-Simples Nacional-Excesso"},{"id":"3","name":"3-Regime Normal"}] }  
				/>
			</Box>
		</Box>
	</>
);