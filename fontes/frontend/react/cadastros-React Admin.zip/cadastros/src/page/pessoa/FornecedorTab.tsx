/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	DateInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const FornecedorTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<DateInput
					source='fornecedorModel.desde'
					label='Desde'
					helperText='Informe os dados para o campo Desde'
				/>
			</Box>
			<Box flex={6}>
				<DateInput
					source='fornecedorModel.dataCadastro'
					label='Data Cadastro'
					helperText='Informe os dados para o campo Data Cadastro'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='fornecedorModel.observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</>
);