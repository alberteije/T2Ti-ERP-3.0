/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	DateInput,
	NumberInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const ClienteTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={8}>
				<ReferenceInput source='clienteModel.tabelaPrecoModel.id' reference='tabela-preco' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tabela Preco'
						optionText='nome'
						helperText='Informe os dados para o campo Tabela Preco'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={4}>
				<DateInput
					source='clienteModel.desde'
					label='Desde'
					helperText='Informe os dados para o campo Desde'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<DateInput
					source='clienteModel.dataCadastro'
					label='Data Cadastro'
					helperText='Informe os dados para o campo Data Cadastro'
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='clienteModel.taxaDesconto'
					label='Taxa Desconto'
					helperText='Informe os dados para o campo Taxa Desconto'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='clienteModel.limiteCredito'
					label='Limite Credito'
					helperText='Informe os dados para o campo Limite Credito'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='clienteModel.observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</>
);