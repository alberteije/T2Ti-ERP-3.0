/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	TextInput,
	maxLength,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";

export const ContadorTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={8}>
				<TextInput
					source='contadorModel.crcInscricao'
					label='Inscricao CRC'
					helperText='Informe os dados para o campo Inscricao CRC[15]'
					validate={[maxLength(15, 'Max=15'), ]}
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='UF CRC'
					source='contadorModel.crcUf'
					helperText='Informe os dados para o campo UF CRC'
					choices={ [{"id":"AC","name":"AC"},{"id":"AL","name":"AL"},{"id":"AM","name":"AM"},{"id":"AP","name":"AP"},{"id":"BA","name":"BA"},{"id":"CE","name":"CE"},{"id":"DF","name":"DF"},{"id":"ES","name":"ES"},{"id":"GO","name":"GO"},{"id":"MA","name":"MA"},{"id":"MG","name":"MG"},{"id":"MS","name":"MS"},{"id":"MT","name":"MT"},{"id":"PA","name":"PA"},{"id":"PB","name":"PB"},{"id":"PE","name":"PE"},{"id":"PI","name":"PI"},{"id":"PR","name":"PR"},{"id":"RJ","name":"RJ"},{"id":"RN","name":"RN"},{"id":"RO","name":"RO"},{"id":"RR","name":"RR"},{"id":"RS","name":"RS"},{"id":"SC","name":"SC"},{"id":"SE","name":"SE"},{"id":"SP","name":"SP"},{"id":"TO","name":"TO"}] }  
				/>
			</Box>
		</Box>
	</>
);