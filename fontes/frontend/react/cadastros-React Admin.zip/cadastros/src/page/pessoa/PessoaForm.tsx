/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	TextInput,
	maxLength,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { PessoaJuridicaTab } from './PessoaJuridicaTab';
import { FornecedorTab } from './FornecedorTab';
import { ClienteTab } from './ClienteTab';
import { PessoaFisicaTab } from './PessoaFisicaTab';
import { TransportadoraTab } from './TransportadoraTab';
import { ContadorTab } from './ContadorTab';
import { PessoaContatoTab } from './PessoaContatoTab';
import { PessoaTelefoneTab } from './PessoaTelefoneTab';
import { PessoaEnderecoTab } from './PessoaEnderecoTab';

export const PessoaForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Pessoa">
				<PessoaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Pessoa Jurídica">
				<PessoaJuridicaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Fornecedor">
				<FornecedorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Cliente">
				<ClienteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Pessoa Física">
				<PessoaFisicaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Transportadora">
				<TransportadoraTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Contador">
				<ContadorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Contatos">
				<PessoaContatoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Telefones">
				<PessoaTelefoneTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Endereços">
				<PessoaEnderecoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PessoaTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={9}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[150]'
					validate={[maxLength(150, 'Max=150'), ]}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Tipo'
					source='tipo'
					helperText='Informe os dados para o campo Tipo'
					choices={ [{"id":"F","name":"Física"},{"id":"J","name":"Jurídica"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='site'
					label='Site'
					helperText='Informe os dados para o campo Site[250]'
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='email'
					label='Email'
					helperText='Informe os dados para o campo Email[250]'
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={2}>
				<SelectInput
					label='É Cliente'
					source='ehCliente'
					helperText='Informe os dados para o campo Eh Cliente'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
			<Box flex={2}>
				<SelectInput
					label='É Fornecedor'
					source='ehFornecedor'
					helperText='Informe os dados para o campo Eh Fornecedor'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
			<Box flex={2}>
				<SelectInput
					label='É Transportadora'
					source='ehTransportadora'
					helperText='Informe os dados para o campo Eh Transportadora'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='É Colaborador'
					source='ehColaborador'
					helperText='Informe os dados para o campo Eh Colaborador'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='É Contador'
					source='ehContador'
					helperText='Informe os dados para o campo Eh Contador'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
		</Box>
	</>
	);
};