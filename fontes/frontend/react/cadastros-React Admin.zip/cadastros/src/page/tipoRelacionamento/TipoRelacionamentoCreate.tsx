import {
	Create,
} from "react-admin";
import { TipoRelacionamentoForm } from "./TipoRelacionamentoForm";

const TipoRelacionamentoCreate = () => {
	return (
		<Create>
			<TipoRelacionamentoForm />
		</Create>
	);
};

export default TipoRelacionamentoCreate;