import {
	Edit,
} from "react-admin";
import { TipoRelacionamentoForm } from "./TipoRelacionamentoForm";

const TipoRelacionamentoEdit = () => {
	return (
		<Edit>
			<TipoRelacionamentoForm />
		</Edit>
	);
};

export default TipoRelacionamentoEdit;