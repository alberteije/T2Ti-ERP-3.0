import TipoRelacionamentoIcon from "@mui/icons-material/Apps";
import TipoRelacionamentoList from "./TipoRelacionamentoList";
import TipoRelacionamentoCreate from "./TipoRelacionamentoCreate";
import TipoRelacionamentoEdit from "./TipoRelacionamentoEdit";

export default {
	list: TipoRelacionamentoList,
	create: TipoRelacionamentoCreate,
	edit: TipoRelacionamentoEdit,
	icon: TipoRelacionamentoIcon,
};
