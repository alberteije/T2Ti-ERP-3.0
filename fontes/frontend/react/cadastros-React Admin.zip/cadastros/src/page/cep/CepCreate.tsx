import {
	Create,
} from "react-admin";
import { CepForm } from "./CepForm";

const CepCreate = () => {
	return (
		<Create>
			<CepForm />
		</Create>
	);
};

export default CepCreate;