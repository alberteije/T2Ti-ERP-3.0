/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	SelectInput,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const CepForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='numero'
					label='Numero'
					helperText='Informe os dados para o campo Numero[8]'
					validate={[maxLength(8, 'Max=8'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='logradouro'
					label='Logradouro'
					helperText='Informe os dados para o campo Logradouro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='complemento'
					label='Complemento'
					helperText='Informe os dados para o campo Complemento[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='bairro'
					label='Bairro'
					helperText='Informe os dados para o campo Bairro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='municipio'
					label='Municipio'
					helperText='Informe os dados para o campo Municipio[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Uf'
					source='uf'
					helperText='Informe os dados para o campo Uf'
					choices={ [{"id":"0","name":"AC"},{"id":"1","name":"AL"},{"id":"2","name":"AM"},{"id":"3","name":"AP"},{"id":"4","name":"BA"},{"id":"5","name":"CE"},{"id":"6","name":"DF"},{"id":"7","name":"ES"},{"id":"8","name":"GO"},{"id":"9","name":"MA"},{"id":"10","name":"MG"},{"id":"11","name":"MS"},{"id":"12","name":"MT"},{"id":"13","name":"PA"},{"id":"14","name":"PB"},{"id":"15","name":"PE"},{"id":"16","name":"PI"},{"id":"17","name":"PR"},{"id":"18","name":"RJ"},{"id":"19","name":"RN"},{"id":"20","name":"RO"},{"id":"21","name":"RR"},{"id":"22","name":"RS"},{"id":"23","name":"SC"},{"id":"24","name":"SE"},{"id":"25","name":"SP"},{"id":"26","name":"TO"}] }  
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='codigoIbgeMunicipio'
					label='Codigo IBGE Municipio'
					helperText='Informe os dados para o campo Codigo IBGE Municipio'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);