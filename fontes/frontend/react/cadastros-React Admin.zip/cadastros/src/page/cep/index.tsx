import CepIcon from "@mui/icons-material/Apps";
import CepList from "./CepList";
import CepCreate from "./CepCreate";
import CepEdit from "./CepEdit";

export default {
	list: CepList,
	create: CepCreate,
	edit: CepEdit,
	icon: CepIcon,
};
