/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CepDomain from '../../data/domain/CepDomain';

const CepList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["numero","logradouro","complemento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CepSmallScreenList : CepBigScreenList;

	return (
		<List
			title="CEP"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CepSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.numero }
			secondaryText={ (record) => record.logradouro }
			tertiaryText={ (record) => record.complemento }
		/>
	);
}

const CepBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="numero" label="Numero" />
			<TextField source="logradouro" label="Logradouro" />
			<TextField source="complemento" label="Complemento" />
			<TextField source="bairro" label="Bairro" />
			<TextField source="municipio" label="Municipio" />
			<FunctionField
				label="Uf"
				render={record => CepDomain.getUf(record.uf)}
			/>
			<TextField source="codigoIbgeMunicipio" label="Codigo Ibge Municipio" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CepList;
