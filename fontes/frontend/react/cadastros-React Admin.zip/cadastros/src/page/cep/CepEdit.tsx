import {
	Edit,
} from "react-admin";
import { CepForm } from "./CepForm";

const CepEdit = () => {
	return (
		<Edit>
			<CepForm />
		</Edit>
	);
};

export default CepEdit;