/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ProdutoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["produtoSubgrupoModel.nome","produtoMarcaModel.nome","produtoUnidadeModel.sigla"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ProdutoSmallScreenList : ProdutoBigScreenList;

	return (
		<List
			title="Produto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ProdutoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.produtoSubgrupoModel.nome }
			secondaryText={ (record) => record.produtoMarcaModel.nome }
			tertiaryText={ (record) => record.produtoUnidadeModel.sigla }
		/>
	);
}

const ProdutoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Produto Subgrupo" source="produtoSubgrupoModel.id" reference="produto-subgrupo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Produto Marca" source="produtoMarcaModel.id" reference="produto-marca" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Produto Unidade" source="produtoUnidadeModel.id" reference="produto-unidade" sortable={false}>
				<TextField source="sigla" />
			</ReferenceField>
			<ReferenceField label="Id Tribut Icms Custom Cab" source="tributIcmsCustomCabModel.id" reference="tribut-icms-custom-cab" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Tribut Grupo Tributario" source="tributGrupoTributarioModel.id" reference="tribut-grupo-tributario" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="gtin" label="Gtin" />
			<TextField source="codigoInterno" label="Codigo Interno" />
			<NumberField source="valorCompra" label="Valor Compra" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorVenda" label="Valor Venda" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="codigoNcm" label="Codigo Ncm" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<NumberField source="estoqueMinimo" label="Estoque Minimo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="estoqueMaximo" label="Estoque Maximo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="quantidadeEstoque" label="Quantidade Estoque" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ProdutoList;
