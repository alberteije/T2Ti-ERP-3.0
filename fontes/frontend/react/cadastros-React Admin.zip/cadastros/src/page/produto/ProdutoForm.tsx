/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	NumberInput,
	DateInput,
} from "react-admin";
import { Box } from "@mui/material";

export const ProdutoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<ReferenceInput source='produtoSubgrupoModel.id' reference='produto-subgrupo' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Subgrupo'
						optionText='nome'
						helperText='Informe os dados para o campo Subgrupo'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={4}>
				<ReferenceInput source='produtoMarcaModel.id' reference='produto-marca' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Marca'
						optionText='nome'
						helperText='Informe os dados para o campo Marca'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={4}>
				<ReferenceInput source='produtoUnidadeModel.id' reference='produto-unidade' filter={{'field': 'sigla'}}>
					<AutocompleteInput
						label='Unidade'
						optionText='sigla'
						helperText='Informe os dados para o campo Unidade'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='tributIcmsCustomCabModel.id' reference='tribut-icms-custom-cab' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Tributação Customizada'
						optionText='descricao'
						helperText='Informe os dados para o campo Tributação Customizada'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='tributGrupoTributarioModel.id' reference='tribut-grupo-tributario' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Grupo Tributário'
						optionText='descricao'
						helperText='Lookup for Grupo Tributário'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<TextInput
					source='gtin'
					label='GTIN'
					helperText='Informe os dados para o campo GTIN[14]'
					validate={[maxLength(14, 'Max=14'), ]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='codigoInterno'
					label='Codigo Interno'
					helperText='Informe os dados para o campo Codigo Interno[50]'
					validate={[maxLength(50, 'Max=50'), ]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorCompra'
					label='Valor Compra'
					helperText='Informe os dados para o campo Valor Compra'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorVenda'
					label='Valor Venda'
					helperText='Informe os dados para o campo Valor Venda'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='codigoNcm'
					label='Codigo Ncm'
					helperText='Informe os dados para o campo Codigo Ncm[8]'
					validate={[maxLength(8, 'Max=8'), ]}
				/>
			</Box>
			<Box flex={6}>
				<DateInput
					source='dataCadastro'
					label='Data Cadastro'
					helperText='Informe os dados para o campo Data Cadastro'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='estoqueMinimo'
					label='Estoque Minimo'
					helperText='Informe os dados para o campo Estoque Minimo'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='estoqueMaximo'
					label='Estoque Maximo'
					helperText='Informe os dados para o campo Estoque Maximo'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='quantidadeEstoque'
					label='Quantidade Estoque'
					helperText='Informe os dados para o campo Quantidade Estoque'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);