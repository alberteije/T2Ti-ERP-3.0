import {
	Create,
} from "react-admin";
import { ProdutoForm } from "./ProdutoForm";

const ProdutoCreate = () => {
	return (
		<Create>
			<ProdutoForm />
		</Create>
	);
};

export default ProdutoCreate;