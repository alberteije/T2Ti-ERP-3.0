import ProdutoIcon from "@mui/icons-material/Apps";
import ProdutoList from "./ProdutoList";
import ProdutoCreate from "./ProdutoCreate";
import ProdutoEdit from "./ProdutoEdit";

export default {
	list: ProdutoList,
	create: ProdutoCreate,
	edit: ProdutoEdit,
	icon: ProdutoIcon,
};
