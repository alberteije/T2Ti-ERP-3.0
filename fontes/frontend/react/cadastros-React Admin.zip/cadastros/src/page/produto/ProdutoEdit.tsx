import {
	Edit,
} from "react-admin";
import { ProdutoForm } from "./ProdutoForm";

const ProdutoEdit = () => {
	return (
		<Edit>
			<ProdutoForm />
		</Edit>
	);
};

export default ProdutoEdit;