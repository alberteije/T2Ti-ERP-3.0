import UfIcon from "@mui/icons-material/Apps";
import UfList from "./UfList";
import UfCreate from "./UfCreate";
import UfEdit from "./UfEdit";

export default {
	list: UfList,
	create: UfCreate,
	edit: UfEdit,
	icon: UfIcon,
};
