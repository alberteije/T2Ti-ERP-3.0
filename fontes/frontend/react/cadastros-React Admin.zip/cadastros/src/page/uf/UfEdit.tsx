import {
	Edit,
} from "react-admin";
import { UfForm } from "./UfForm";

const UfEdit = () => {
	return (
		<Edit>
			<UfForm />
		</Edit>
	);
};

export default UfEdit;