/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const UfList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","sigla","codigoIbge"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? UfSmallScreenList : UfBigScreenList;

	return (
		<List
			title="UF"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const UfSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.sigla }
			tertiaryText={ (record) => record.codigoIbge }
		/>
	);
}

const UfBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<TextField source="sigla" label="Sigla" />
			<TextField source="codigoIbge" label="Codigo Ibge" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default UfList;
