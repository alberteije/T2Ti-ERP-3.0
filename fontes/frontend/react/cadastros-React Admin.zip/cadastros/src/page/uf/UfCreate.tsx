import {
	Create,
} from "react-admin";
import { UfForm } from "./UfForm";

const UfCreate = () => {
	return (
		<Create>
			<UfForm />
		</Create>
	);
};

export default UfCreate;