/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import BancoDomain from '../../data/domain/BancoDomain';

const BancoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","nome","url"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? BancoSmallScreenList : BancoBigScreenList;

	return (
		<List
			title="Banco"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const BancoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.url }
		/>
	);
}

const BancoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="nome" label="Nome" />
			<TextField source="url" label="Url" />
			<TextField source="ispb" label="Ispb" />
			<FunctionField
				label="Participa Compe"
				render={record => BancoDomain.getParticipaCompe(record.participaCompe)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default BancoList;
