import {
	Create,
} from "react-admin";
import { BancoForm } from "./BancoForm";

const BancoCreate = () => {
	return (
		<Create>
			<BancoForm />
		</Create>
	);
};

export default BancoCreate;