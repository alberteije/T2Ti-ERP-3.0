import {
	Edit,
} from "react-admin";
import { BancoForm } from "./BancoForm";

const BancoEdit = () => {
	return (
		<Edit>
			<BancoForm />
		</Edit>
	);
};

export default BancoEdit;