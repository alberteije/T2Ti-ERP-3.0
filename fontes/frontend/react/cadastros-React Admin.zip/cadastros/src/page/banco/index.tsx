import BancoIcon from "@mui/icons-material/Apps";
import BancoList from "./BancoList";
import BancoCreate from "./BancoCreate";
import BancoEdit from "./BancoEdit";

export default {
	list: BancoList,
	create: BancoCreate,
	edit: BancoEdit,
	icon: BancoIcon,
};
