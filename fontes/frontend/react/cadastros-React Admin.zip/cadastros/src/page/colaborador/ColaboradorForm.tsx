/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	DateInput,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { VendedorTab } from './VendedorTab';
import { ColaboradorRelacionamentoTab } from './ColaboradorRelacionamentoTab';

export const ColaboradorForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Colaborador">
				<ColaboradorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Vendedor">
				<VendedorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Relacionamentos">
				<ColaboradorRelacionamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ColaboradorTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='pessoaModel.id' reference='pessoa' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Pessoa'
						optionText='nome'
						helperText='Informe os dados para o campo Pessoa'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='cargoModel.id' reference='cargo' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Cargo'
						optionText='nome'
						helperText='Informe os dados para o campo Cargo'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='setorModel.id' reference='setor' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Setor'
						optionText='nome'
						helperText='Informe os dados para o campo Setor'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='colaboradorSituacaoModel.id' reference='colaborador-situacao' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Situação'
						optionText='nome'
						helperText='Informe os dados para o campo Situacao'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='tipoAdmissaoModel.id' reference='tipo-admissao' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tipo Admissao'
						optionText='nome'
						helperText='Informe os dados para o campo Tipo Admissao'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='colaboradorTipoModel.id' reference='colaborador-tipo' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tipo Colaborador'
						optionText='nome'
						helperText='Informe os dados para o campo Tipo Colaborador'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='sindicatoModel.id' reference='sindicato' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Sindicato'
						optionText='nome'
						helperText='Informe os dados para o campo Sindicato'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<TextInput
					source='matricula'
					label='Matricula'
					helperText='Informe os dados para o campo Matricula[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={3}>
				<DateInput
					source='dataCadastro'
					label='Data Cadastro'
					helperText='Informe os dados para o campo Data Cadastro'
				/>
			</Box>
			<Box flex={3}>
				<DateInput
					source='dataAdmissao'
					label='Data Admissao'
					helperText='Informe os dados para o campo Data Admissao'
				/>
			</Box>
			<Box flex={3}>
				<DateInput
					source='dataDemissao'
					label='Data Demissao'
					helperText='Informe os dados para o campo Data Demissao'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<TextInput
					source='ctpsNumero'
					label='Ctps Numero'
					helperText='Informe os dados para o campo Ctps Numero[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='ctpsSerie'
					label='Ctps Serie'
					helperText='Informe os dados para o campo Ctps Serie[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={3}>
				<DateInput
					source='ctpsDataExpedicao'
					label='Ctps Data Expedicao'
					helperText='Informe os dados para o campo Ctps Data Expedicao'
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Ctps Uf'
					source='ctpsUf'
					helperText='Informe os dados para o campo Ctps Uf'
					choices={ [{"id":"AC","name":"AC"},{"id":"AL","name":"AL"},{"id":"AM","name":"AM"},{"id":"AP","name":"AP"},{"id":"BA","name":"BA"},{"id":"CE","name":"CE"},{"id":"DF","name":"DF"},{"id":"ES","name":"ES"},{"id":"GO","name":"GO"},{"id":"MA","name":"MA"},{"id":"MG","name":"MG"},{"id":"MS","name":"MS"},{"id":"MT","name":"MT"},{"id":"PA","name":"PA"},{"id":"PB","name":"PB"},{"id":"PE","name":"PE"},{"id":"PI","name":"PI"},{"id":"PR","name":"PR"},{"id":"RJ","name":"RJ"},{"id":"RN","name":"RN"},{"id":"RO","name":"RO"},{"id":"RR","name":"RR"},{"id":"RS","name":"RS"},{"id":"SC","name":"SC"},{"id":"SE","name":"SE"},{"id":"SP","name":"SP"},{"id":"TO","name":"TO"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</>
	);
};