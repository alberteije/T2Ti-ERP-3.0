/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const VendedorTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='vendedorModel.comissaoPerfilModel.id' reference='comissao-perfil' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Perfil Comissão'
						optionText='nome'
						helperText='Informe os dados para o campo Perfil Comissão'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<NumberInput
					source='vendedorModel.comissao'
					label='Comissao'
					helperText='Informe os dados para o campo Comissao'
					validate={[]}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='vendedorModel.metaVenda'
					label='Meta Venda'
					helperText='Informe os dados para o campo Meta Venda'
					validate={[]}
				/>
			</Box>
		</Box>
	</>
);