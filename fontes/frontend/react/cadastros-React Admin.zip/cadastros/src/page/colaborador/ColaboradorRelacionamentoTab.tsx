/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	DateInput,
	SelectInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'
import { formatWithMask } from '../../infra/utils';
import ColaboradorRelacionamentoDomain from '../../data/domain/ColaboradorRelacionamentoDomain';

class ColaboradorRelacionamento {
	constructor(
		public id = 0,
		public tipoRelacionamentoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public nome = '',
		public dataNascimento = null,
		public cpf = '',
		public registroMatricula = '',
		public registroCartorio = '',
		public registroCartorioNumero = '',
		public registroNumeroLivro = '',
		public registroNumeroFolha = '',
		public dataEntregaDocumento = null,
		public salarioFamilia = '',
		public salarioFamiliaIdadeLimite = null,
		public salarioFamiliaDataFim = null,
		public impostoRendaIdadeLimite = null,
		public impostoRendaDataFim = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ColaboradorRelacionamento {
		const colaboradorRelacionamento = new ColaboradorRelacionamento();
		colaboradorRelacionamento.id = Date.now();
		colaboradorRelacionamento.statusCrud = "C";
		return colaboradorRelacionamento;
	}
}

export const ColaboradorRelacionamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ColaboradorRelacionamento,
		setCurrentRecord: (record: ColaboradorRelacionamento) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='tipoRelacionamentoModel.id' reference='tipo-relacionamento' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tipo Relacionamento'
						optionText='nome'
						helperText='Importar Tipo Relacionamento'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								tipoRelacionamentoModel: {
						  		...currentRecord.tipoRelacionamentoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									nome: e.target.value,
								});
							}} format={(_: any) => currentRecord.nome ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<DateInput
					source='dataNascimento'
					label='Data Nascimento'
					helperText='Informe os dados para o campo Data Nascimento'
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							dataNascimento: e.target.value,
						});
					}} format={(_: any) => currentRecord.dataNascimento ?? ''}
				/>
			</Box>
			<Box flex={6}>
				<MaskedTextInput
					mask='###.###.###-##'
					source='cpf'
					label='CPF'
					helperText='Informe os dados para o campo Cpf'
					validate={[]}
					onBlur={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							cpf: e.target.value,
						});
					}}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<TextInput
					source='registroMatricula'
					label='Registro Matricula'
					helperText='Informe os dados para o campo Registro Matricula[50]'
					validate={[maxLength(50, 'Max=50'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									registroMatricula: e.target.value,
								});
							}} format={(_: any) => currentRecord.registroMatricula ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='registroCartorio'
					label='Registro Cartorio'
					helperText='Informe os dados para o campo Registro Cartorio[50]'
					validate={[maxLength(50, 'Max=50'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									registroCartorio: e.target.value,
								});
							}} format={(_: any) => currentRecord.registroCartorio ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='registroCartorioNumero'
					label='Registro Cartorio Numero'
					helperText='Informe os dados para o campo Registro Cartorio Numero[50]'
					validate={[maxLength(50, 'Max=50'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									registroCartorioNumero: e.target.value,
								});
							}} format={(_: any) => currentRecord.registroCartorioNumero ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<TextInput
					source='registroNumeroLivro'
					label='Registro Numero Livro'
					helperText='Informe os dados para o campo Registro Numero Livro[10]'
					validate={[maxLength(10, 'Max=10'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									registroNumeroLivro: e.target.value,
								});
							}} format={(_: any) => currentRecord.registroNumeroLivro ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='registroNumeroFolha'
					label='Registro Numero Folha'
					helperText='Informe os dados para o campo Registro Numero Folha[10]'
					validate={[maxLength(10, 'Max=10'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									registroNumeroFolha: e.target.value,
								});
							}} format={(_: any) => currentRecord.registroNumeroFolha ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<DateInput
					source='dataEntregaDocumento'
					label='Data Entrega Documento'
					helperText='Informe os dados para o campo Data Entrega Documento'
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							dataEntregaDocumento: e.target.value,
						});
					}} format={(_: any) => currentRecord.dataEntregaDocumento ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Salario Familia'
					source='salarioFamilia'
					helperText='Informe os dados para o campo Salario Familia'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							salarioFamilia: e.target.value,
						});
					}} format={(_: any) => currentRecord.salarioFamilia ?? ''}
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='salarioFamiliaIdadeLimite'
					label='Salario Familia Idade Limite'
					helperText='Informe os dados para o campo Salario Familia Idade Limite'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									salarioFamiliaIdadeLimite: e.target.value,
								});
							}} format={(_: any) => currentRecord.salarioFamiliaIdadeLimite ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<DateInput
					source='salarioFamiliaDataFim'
					label='Salario Familia Data Fim'
					helperText='Informe os dados para o campo Salario Familia Data Fim'
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							salarioFamiliaDataFim: e.target.value,
						});
					}} format={(_: any) => currentRecord.salarioFamiliaDataFim ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='impostoRendaIdadeLimite'
					label='Imposto Renda Idade Limite'
					helperText='Informe os dados para o campo Imposto Renda Idade Limite'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									impostoRendaIdadeLimite: e.target.value,
								});
							}} format={(_: any) => currentRecord.impostoRendaIdadeLimite ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='impostoRendaDataFim'
					label='Imposto Renda Data Fim'
					helperText='Informe os dados para o campo Imposto Renda Data Fim'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									impostoRendaDataFim: e.target.value,
								});
							}} format={(_: any) => currentRecord.impostoRendaDataFim ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'tipoRelacionamentoModel.id', label: 'Tipo Relacionamento', reference: 'tipo-relacionamento', fieldName: 'nome' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'dataNascimento', label: 'Data Nascimento' },
		{ source: 'cpf', label: 'CPF', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'registroMatricula', label: 'Registro Matricula' },
		{ source: 'registroCartorio', label: 'Registro Cartorio' },
		{ source: 'registroCartorioNumero', label: 'Registro Cartorio Numero' },
		{ source: 'registroNumeroLivro', label: 'Registro Numero Livro' },
		{ source: 'registroNumeroFolha', label: 'Registro Numero Folha' },
		{ source: 'dataEntregaDocumento', label: 'Data Entrega Documento' },
		{ source: 'salarioFamilia', label: 'Salario Familia', formatDomain: ColaboradorRelacionamentoDomain.getSalarioFamilia },
		{ source: 'salarioFamiliaIdadeLimite', label: 'Salario Familia Idade Limite' },
		{ source: 'salarioFamiliaDataFim', label: 'Salario Familia Data Fim' },
		{ source: 'impostoRendaIdadeLimite', label: 'Imposto Renda Idade Limite' },
		{ source: 'impostoRendaDataFim', label: 'Imposto Renda Data Fim' },
	];

	return (
		<CrudChildTab
			title="Relacionamentos"
			recordContext="colaborador"
			fieldSource="colaboradorRelacionamentoModelList"
			newObject={ ColaboradorRelacionamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};