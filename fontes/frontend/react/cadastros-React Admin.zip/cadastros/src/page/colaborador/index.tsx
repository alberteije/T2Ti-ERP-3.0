import ColaboradorIcon from "@mui/icons-material/Apps";
import ColaboradorList from "./ColaboradorList";
import ColaboradorCreate from "./ColaboradorCreate";
import ColaboradorEdit from "./ColaboradorEdit";

export default {
	list: ColaboradorList,
	create: ColaboradorCreate,
	edit: ColaboradorEdit,
	icon: ColaboradorIcon,
};
