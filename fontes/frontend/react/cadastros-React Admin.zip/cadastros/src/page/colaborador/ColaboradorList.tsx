/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ColaboradorDomain from '../../data/domain/ColaboradorDomain';

const ColaboradorList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["pessoaModel.nome","cargoModel.nome","setorModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ColaboradorSmallScreenList : ColaboradorBigScreenList;

	return (
		<List
			title="Colaborador"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ColaboradorSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.pessoaModel.nome }
			secondaryText={ (record) => record.cargoModel.nome }
			tertiaryText={ (record) => record.setorModel.nome }
		/>
	);
}

const ColaboradorBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Pessoa" source="pessoaModel.id" reference="pessoa" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Cargo" source="cargoModel.id" reference="cargo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Setor" source="setorModel.id" reference="setor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador Situacao" source="colaboradorSituacaoModel.id" reference="colaborador-situacao" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Tipo Admissao" source="tipoAdmissaoModel.id" reference="tipo-admissao" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador Tipo" source="colaboradorTipoModel.id" reference="colaborador-tipo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Sindicato" source="sindicatoModel.id" reference="sindicato" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="matricula" label="Matricula" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<TextField source="dataAdmissao" label="Data Admissao" />
			<TextField source="dataDemissao" label="Data Demissao" />
			<TextField source="ctpsNumero" label="Ctps Numero" />
			<TextField source="ctpsSerie" label="Ctps Serie" />
			<TextField source="ctpsDataExpedicao" label="Ctps Data Expedicao" />
			<FunctionField
				label="Ctps Uf"
				render={record => ColaboradorDomain.getCtpsUf(record.ctpsUf)}
			/>
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ColaboradorList;
