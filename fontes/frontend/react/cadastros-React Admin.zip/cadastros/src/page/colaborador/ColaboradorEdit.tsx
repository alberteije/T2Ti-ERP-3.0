/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ColaboradorForm } from "./ColaboradorForm";
import { transformNestedData } from "../../infra/utils";

const ColaboradorEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ColaboradorForm />
		</Edit>
	);
};

export default ColaboradorEdit;