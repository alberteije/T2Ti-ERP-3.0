/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ColaboradorForm } from "./ColaboradorForm";
import { transformNestedData } from "../../infra/utils";

const ColaboradorCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ColaboradorForm />
		</Create>
	);
};

export default ColaboradorCreate;