import {
	Create,
} from "react-admin";
import { CstPisForm } from "./CstPisForm";

const CstPisCreate = () => {
	return (
		<Create>
			<CstPisForm />
		</Create>
	);
};

export default CstPisCreate;