/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const CstPisForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[250]'
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);