import {
	Edit,
} from "react-admin";
import { CstPisForm } from "./CstPisForm";

const CstPisEdit = () => {
	return (
		<Edit>
			<CstPisForm />
		</Edit>
	);
};

export default CstPisEdit;