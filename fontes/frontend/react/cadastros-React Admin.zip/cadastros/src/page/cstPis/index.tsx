import CstPisIcon from "@mui/icons-material/Apps";
import CstPisList from "./CstPisList";
import CstPisCreate from "./CstPisCreate";
import CstPisEdit from "./CstPisEdit";

export default {
	list: CstPisList,
	create: CstPisCreate,
	edit: CstPisEdit,
	icon: CstPisIcon,
};
