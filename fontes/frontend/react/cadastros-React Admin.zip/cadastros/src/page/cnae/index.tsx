import CnaeIcon from "@mui/icons-material/Apps";
import CnaeList from "./CnaeList";
import CnaeCreate from "./CnaeCreate";
import CnaeEdit from "./CnaeEdit";

export default {
	list: CnaeList,
	create: CnaeCreate,
	edit: CnaeEdit,
	icon: CnaeIcon,
};
