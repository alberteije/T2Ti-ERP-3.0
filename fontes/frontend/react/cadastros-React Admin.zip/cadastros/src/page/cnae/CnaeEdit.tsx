import {
	Edit,
} from "react-admin";
import { CnaeForm } from "./CnaeForm";

const CnaeEdit = () => {
	return (
		<Edit>
			<CnaeForm />
		</Edit>
	);
};

export default CnaeEdit;