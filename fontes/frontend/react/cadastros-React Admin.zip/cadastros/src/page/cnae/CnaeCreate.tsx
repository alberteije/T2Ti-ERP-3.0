import {
	Create,
} from "react-admin";
import { CnaeForm } from "./CnaeForm";

const CnaeCreate = () => {
	return (
		<Create>
			<CnaeForm />
		</Create>
	);
};

export default CnaeCreate;