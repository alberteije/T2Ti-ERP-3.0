/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CnaeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","denominacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CnaeSmallScreenList : CnaeBigScreenList;

	return (
		<List
			title="CNAE"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CnaeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.denominacao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const CnaeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="denominacao" label="Denominacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CnaeList;
