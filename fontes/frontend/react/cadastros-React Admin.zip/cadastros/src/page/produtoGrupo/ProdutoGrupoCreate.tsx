import {
	Create,
} from "react-admin";
import { ProdutoGrupoForm } from "./ProdutoGrupoForm";

const ProdutoGrupoCreate = () => {
	return (
		<Create>
			<ProdutoGrupoForm />
		</Create>
	);
};

export default ProdutoGrupoCreate;