import {
	Edit,
} from "react-admin";
import { ProdutoGrupoForm } from "./ProdutoGrupoForm";

const ProdutoGrupoEdit = () => {
	return (
		<Edit>
			<ProdutoGrupoForm />
		</Edit>
	);
};

export default ProdutoGrupoEdit;