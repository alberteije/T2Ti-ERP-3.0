import ProdutoGrupoIcon from "@mui/icons-material/Apps";
import ProdutoGrupoList from "./ProdutoGrupoList";
import ProdutoGrupoCreate from "./ProdutoGrupoCreate";
import ProdutoGrupoEdit from "./ProdutoGrupoEdit";

export default {
	list: ProdutoGrupoList,
	create: ProdutoGrupoCreate,
	edit: ProdutoGrupoEdit,
	icon: ProdutoGrupoIcon,
};
