/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import BancoContaCaixaDomain from '../../data/domain/BancoContaCaixaDomain';

const BancoContaCaixaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["bancoAgenciaModel.nome","numero","digito"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? BancoContaCaixaSmallScreenList : BancoContaCaixaBigScreenList;

	return (
		<List
			title="Conta/Caixa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const BancoContaCaixaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.bancoAgenciaModel.nome }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record.digito }
		/>
	);
}

const BancoContaCaixaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Banco Agencia" source="bancoAgenciaModel.id" reference="banco-agencia" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<TextField source="digito" label="Digito" />
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Tipo"
				render={record => BancoContaCaixaDomain.getTipo(record.tipo)}
			/>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default BancoContaCaixaList;
