import {
	Create,
} from "react-admin";
import { BancoContaCaixaForm } from "./BancoContaCaixaForm";

const BancoContaCaixaCreate = () => {
	return (
		<Create>
			<BancoContaCaixaForm />
		</Create>
	);
};

export default BancoContaCaixaCreate;