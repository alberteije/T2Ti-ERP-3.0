import BancoContaCaixaIcon from "@mui/icons-material/Apps";
import BancoContaCaixaList from "./BancoContaCaixaList";
import BancoContaCaixaCreate from "./BancoContaCaixaCreate";
import BancoContaCaixaEdit from "./BancoContaCaixaEdit";

export default {
	list: BancoContaCaixaList,
	create: BancoContaCaixaCreate,
	edit: BancoContaCaixaEdit,
	icon: BancoContaCaixaIcon,
};
