/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	required,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";

export const BancoContaCaixaForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='bancoAgenciaModel.id' reference='banco-agencia' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Agencia'
						optionText='nome'
						helperText='Informe os dados para o campo Agencia'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={2}>
				<TextInput
					source='numero'
					label='Numero'
					helperText='Informe os dados para o campo Numero[20]'
					validate={[maxLength(20, 'Max=20'), ]}
				/>
			</Box>
			<Box flex={1}>
				<TextInput
					source='digito'
					label='Digito'
					helperText='Informe os dados para o campo Digito[1]'
					validate={[maxLength(1, 'Max=1'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), required(), ]}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Tipo'
					source='tipo'
					helperText='Informe os dados para o campo Tipo'
					choices={ [{"id":"0","name":"Corrente"},{"id":"1","name":"Poupança"},{"id":"2","name":"Investimento"},{"id":"3","name":"Caixa Interno"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);