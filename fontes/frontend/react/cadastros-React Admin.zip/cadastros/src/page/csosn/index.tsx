import CsosnIcon from "@mui/icons-material/Apps";
import CsosnList from "./CsosnList";
import CsosnCreate from "./CsosnCreate";
import CsosnEdit from "./CsosnEdit";

export default {
	list: CsosnList,
	create: CsosnCreate,
	edit: CsosnEdit,
	icon: CsosnIcon,
};
