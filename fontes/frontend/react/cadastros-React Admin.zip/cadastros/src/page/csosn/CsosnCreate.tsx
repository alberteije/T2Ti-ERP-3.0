import {
	Create,
} from "react-admin";
import { CsosnForm } from "./CsosnForm";

const CsosnCreate = () => {
	return (
		<Create>
			<CsosnForm />
		</Create>
	);
};

export default CsosnCreate;