import {
	Edit,
} from "react-admin";
import { CsosnForm } from "./CsosnForm";

const CsosnEdit = () => {
	return (
		<Edit>
			<CsosnForm />
		</Edit>
	);
};

export default CsosnEdit;