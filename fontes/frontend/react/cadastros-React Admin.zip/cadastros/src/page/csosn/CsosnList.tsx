/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CsosnList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","descricao","observacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CsosnSmallScreenList : CsosnBigScreenList;

	return (
		<List
			title="CSOSN"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CsosnSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.observacao }
		/>
	);
}

const CsosnBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CsosnList;
