import {
	Edit,
} from "react-admin";
import { EstadoCivilForm } from "./EstadoCivilForm";

const EstadoCivilEdit = () => {
	return (
		<Edit>
			<EstadoCivilForm />
		</Edit>
	);
};

export default EstadoCivilEdit;