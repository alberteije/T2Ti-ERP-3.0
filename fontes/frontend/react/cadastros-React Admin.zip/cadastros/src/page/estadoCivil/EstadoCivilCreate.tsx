import {
	Create,
} from "react-admin";
import { EstadoCivilForm } from "./EstadoCivilForm";

const EstadoCivilCreate = () => {
	return (
		<Create>
			<EstadoCivilForm />
		</Create>
	);
};

export default EstadoCivilCreate;