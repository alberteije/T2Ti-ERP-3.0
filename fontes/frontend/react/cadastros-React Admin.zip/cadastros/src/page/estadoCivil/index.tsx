import EstadoCivilIcon from "@mui/icons-material/Apps";
import EstadoCivilList from "./EstadoCivilList";
import EstadoCivilCreate from "./EstadoCivilCreate";
import EstadoCivilEdit from "./EstadoCivilEdit";

export default {
	list: EstadoCivilList,
	create: EstadoCivilCreate,
	edit: EstadoCivilEdit,
	icon: EstadoCivilIcon,
};
