/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'

export const BancoAgenciaForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='bancoModel.id' reference='banco' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Banco'
						optionText='nome'
						helperText='Informe os dados para o campo Banco'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={7}>
				<TextInput
					source='numero'
					label='Numero'
					helperText='Informe os dados para o campo Numero[20]'
					validate={[maxLength(20, 'Max=20'), ]}
				/>
			</Box>
			<Box flex={1}>
				<TextInput
					source='digito'
					label='Digito'
					helperText='Informe os dados para o campo Digito[1]'
					validate={[maxLength(1, 'Max=1'), ]}
				/>
			</Box>
			<Box flex={4}>
				<MaskedTextInput
					mask='(##)#####-####'
					source='telefone'
					label='Telefone'
					helperText='Informe os dados para o campo Telefone'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='contato'
					label='Contato'
					helperText='Informe os dados para o campo Contato[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='gerente'
					label='Gerente'
					helperText='Informe os dados para o campo Gerente[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observacao'
					helperText='Informe os dados para o campo Observacao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);