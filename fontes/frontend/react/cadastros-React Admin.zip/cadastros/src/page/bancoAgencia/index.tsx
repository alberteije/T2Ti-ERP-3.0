import BancoAgenciaIcon from "@mui/icons-material/Apps";
import BancoAgenciaList from "./BancoAgenciaList";
import BancoAgenciaCreate from "./BancoAgenciaCreate";
import BancoAgenciaEdit from "./BancoAgenciaEdit";

export default {
	list: BancoAgenciaList,
	create: BancoAgenciaCreate,
	edit: BancoAgenciaEdit,
	icon: BancoAgenciaIcon,
};
