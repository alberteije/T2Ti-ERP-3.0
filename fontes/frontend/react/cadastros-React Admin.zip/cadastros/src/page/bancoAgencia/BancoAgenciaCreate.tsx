import {
	Create,
} from "react-admin";
import { BancoAgenciaForm } from "./BancoAgenciaForm";

const BancoAgenciaCreate = () => {
	return (
		<Create>
			<BancoAgenciaForm />
		</Create>
	);
};

export default BancoAgenciaCreate;