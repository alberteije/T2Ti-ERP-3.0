import {
	Edit,
} from "react-admin";
import { BancoAgenciaForm } from "./BancoAgenciaForm";

const BancoAgenciaEdit = () => {
	return (
		<Edit>
			<BancoAgenciaForm />
		</Edit>
	);
};

export default BancoAgenciaEdit;