import CfopIcon from "@mui/icons-material/Apps";
import CfopList from "./CfopList";
import CfopCreate from "./CfopCreate";
import CfopEdit from "./CfopEdit";

export default {
	list: CfopList,
	create: CfopCreate,
	edit: CfopEdit,
	icon: CfopIcon,
};
