import {
	Create,
} from "react-admin";
import { CfopForm } from "./CfopForm";

const CfopCreate = () => {
	return (
		<Create>
			<CfopForm />
		</Create>
	);
};

export default CfopCreate;