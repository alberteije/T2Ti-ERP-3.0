import {
	Edit,
} from "react-admin";
import { CfopForm } from "./CfopForm";

const CfopEdit = () => {
	return (
		<Edit>
			<CfopForm />
		</Edit>
	);
};

export default CfopEdit;