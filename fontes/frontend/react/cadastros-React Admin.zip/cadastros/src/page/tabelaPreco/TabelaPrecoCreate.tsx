import {
	Create,
} from "react-admin";
import { TabelaPrecoForm } from "./TabelaPrecoForm";

const TabelaPrecoCreate = () => {
	return (
		<Create>
			<TabelaPrecoForm />
		</Create>
	);
};

export default TabelaPrecoCreate;