/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	SelectInput,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const TabelaPrecoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Principal'
					source='principal'
					helperText='Informe os dados para o campo Principal'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
			<Box flex={6}>
				<NumberInput
					source='coeficiente'
					label='Coeficiente'
					helperText='Informe os dados para o campo Coeficiente'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);