import {
	Edit,
} from "react-admin";
import { TabelaPrecoForm } from "./TabelaPrecoForm";

const TabelaPrecoEdit = () => {
	return (
		<Edit>
			<TabelaPrecoForm />
		</Edit>
	);
};

export default TabelaPrecoEdit;