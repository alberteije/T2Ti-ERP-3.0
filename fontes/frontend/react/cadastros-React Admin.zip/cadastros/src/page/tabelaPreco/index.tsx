import TabelaPrecoIcon from "@mui/icons-material/Apps";
import TabelaPrecoList from "./TabelaPrecoList";
import TabelaPrecoCreate from "./TabelaPrecoCreate";
import TabelaPrecoEdit from "./TabelaPrecoEdit";

export default {
	list: TabelaPrecoList,
	create: TabelaPrecoCreate,
	edit: TabelaPrecoEdit,
	icon: TabelaPrecoIcon,
};
