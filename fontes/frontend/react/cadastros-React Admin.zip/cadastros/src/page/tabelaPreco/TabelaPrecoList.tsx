/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import TabelaPrecoDomain from '../../data/domain/TabelaPrecoDomain';

const TabelaPrecoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","principal","coeficiente"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TabelaPrecoSmallScreenList : TabelaPrecoBigScreenList;

	return (
		<List
			title="Tabelas de Preço"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TabelaPrecoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.principal }
			tertiaryText={ (record) => record.coeficiente }
		/>
	);
}

const TabelaPrecoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<FunctionField
				label="Principal"
				render={record => TabelaPrecoDomain.getPrincipal(record.principal)}
			/>
			<NumberField source="coeficiente" label="Coeficiente" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TabelaPrecoList;
