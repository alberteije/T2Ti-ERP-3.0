import {
	Edit,
} from "react-admin";
import { ProdutoMarcaForm } from "./ProdutoMarcaForm";

const ProdutoMarcaEdit = () => {
	return (
		<Edit>
			<ProdutoMarcaForm />
		</Edit>
	);
};

export default ProdutoMarcaEdit;