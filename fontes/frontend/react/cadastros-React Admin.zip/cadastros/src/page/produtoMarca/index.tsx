import ProdutoMarcaIcon from "@mui/icons-material/Apps";
import ProdutoMarcaList from "./ProdutoMarcaList";
import ProdutoMarcaCreate from "./ProdutoMarcaCreate";
import ProdutoMarcaEdit from "./ProdutoMarcaEdit";

export default {
	list: ProdutoMarcaList,
	create: ProdutoMarcaCreate,
	edit: ProdutoMarcaEdit,
	icon: ProdutoMarcaIcon,
};
