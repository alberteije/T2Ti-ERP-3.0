import {
	Create,
} from "react-admin";
import { ProdutoMarcaForm } from "./ProdutoMarcaForm";

const ProdutoMarcaCreate = () => {
	return (
		<Create>
			<ProdutoMarcaForm />
		</Create>
	);
};

export default ProdutoMarcaCreate;