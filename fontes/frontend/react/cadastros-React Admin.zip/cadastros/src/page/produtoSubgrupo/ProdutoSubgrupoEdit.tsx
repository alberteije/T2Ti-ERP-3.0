import {
	Edit,
} from "react-admin";
import { ProdutoSubgrupoForm } from "./ProdutoSubgrupoForm";

const ProdutoSubgrupoEdit = () => {
	return (
		<Edit>
			<ProdutoSubgrupoForm />
		</Edit>
	);
};

export default ProdutoSubgrupoEdit;