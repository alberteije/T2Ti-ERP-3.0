import {
	Create,
} from "react-admin";
import { ProdutoSubgrupoForm } from "./ProdutoSubgrupoForm";

const ProdutoSubgrupoCreate = () => {
	return (
		<Create>
			<ProdutoSubgrupoForm />
		</Create>
	);
};

export default ProdutoSubgrupoCreate;