import ProdutoSubgrupoIcon from "@mui/icons-material/Apps";
import ProdutoSubgrupoList from "./ProdutoSubgrupoList";
import ProdutoSubgrupoCreate from "./ProdutoSubgrupoCreate";
import ProdutoSubgrupoEdit from "./ProdutoSubgrupoEdit";

export default {
	list: ProdutoSubgrupoList,
	create: ProdutoSubgrupoCreate,
	edit: ProdutoSubgrupoEdit,
	icon: ProdutoSubgrupoIcon,
};
