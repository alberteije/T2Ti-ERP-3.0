/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ProdutoSubgrupoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["produtoGrupoModel.nome","nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ProdutoSubgrupoSmallScreenList : ProdutoSubgrupoBigScreenList;

	return (
		<List
			title="Subgrupo Produto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ProdutoSubgrupoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.produtoGrupoModel.nome }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const ProdutoSubgrupoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Produto Grupo" source="produtoGrupoModel.id" reference="produto-grupo" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ProdutoSubgrupoList;
