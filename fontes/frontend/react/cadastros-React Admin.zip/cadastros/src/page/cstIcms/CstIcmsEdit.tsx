import {
	Edit,
} from "react-admin";
import { CstIcmsForm } from "./CstIcmsForm";

const CstIcmsEdit = () => {
	return (
		<Edit>
			<CstIcmsForm />
		</Edit>
	);
};

export default CstIcmsEdit;