import CstIcmsIcon from "@mui/icons-material/Apps";
import CstIcmsList from "./CstIcmsList";
import CstIcmsCreate from "./CstIcmsCreate";
import CstIcmsEdit from "./CstIcmsEdit";

export default {
	list: CstIcmsList,
	create: CstIcmsCreate,
	edit: CstIcmsEdit,
	icon: CstIcmsIcon,
};
