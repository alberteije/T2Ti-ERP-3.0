import {
	Create,
} from "react-admin";
import { CstIcmsForm } from "./CstIcmsForm";

const CstIcmsCreate = () => {
	return (
		<Create>
			<CstIcmsForm />
		</Create>
	);
};

export default CstIcmsCreate;