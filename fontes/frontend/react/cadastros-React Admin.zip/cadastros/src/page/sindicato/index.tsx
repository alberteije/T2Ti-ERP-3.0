import SindicatoIcon from "@mui/icons-material/Apps";
import SindicatoList from "./SindicatoList";
import SindicatoCreate from "./SindicatoCreate";
import SindicatoEdit from "./SindicatoEdit";

export default {
	list: SindicatoList,
	create: SindicatoCreate,
	edit: SindicatoEdit,
	icon: SindicatoIcon,
};
