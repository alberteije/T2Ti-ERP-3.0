/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import SindicatoDomain from '../../data/domain/SindicatoDomain';

const SindicatoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","codigoBanco","codigoAgencia"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? SindicatoSmallScreenList : SindicatoBigScreenList;

	return (
		<List
			title="Sindicato"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const SindicatoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.codigoBanco }
			tertiaryText={ (record) => record.codigoAgencia }
		/>
	);
}

const SindicatoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="nome" label="Nome" />
			<TextField source="codigoBanco" label="Codigo Banco" />
			<TextField source="codigoAgencia" label="Codigo Agencia" />
			<TextField source="contaBanco" label="Conta Banco" />
			<TextField source="codigoCedente" label="Codigo Cedente" />
			<TextField source="logradouro" label="Logradouro" />
			<TextField source="numero" label="Numero" />
			<TextField source="bairro" label="Bairro" />
			<TextField source="municipioIbge" label="Municipio Ibge" />
			<FunctionField
				label="Uf"
				render={record => SindicatoDomain.getUf(record.uf)}
			/>
			<FunctionField
				source="fone1"
				label="Fone1"
				render={record => formatWithMask(record.fone1, '(##)#####-####')}
			/>
			<FunctionField
				source="fone2"
				label="Fone2"
				render={record => formatWithMask(record.fone2, '(##)#####-####')}
			/>
			<TextField source="email" label="Email" />
			<FunctionField
				label="Tipo Sindicato"
				render={record => SindicatoDomain.getTipoSindicato(record.tipoSindicato)}
			/>
			<TextField source="dataBase" label="Data Base" />
			<NumberField source="pisoSalarial" label="Piso Salarial" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<TextField source="classificacaoContabilConta" label="Classificacao Contabil Conta" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default SindicatoList;
