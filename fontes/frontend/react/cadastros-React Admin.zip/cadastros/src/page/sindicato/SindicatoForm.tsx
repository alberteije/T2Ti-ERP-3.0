/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	NumberInput,
	SelectInput,
	DateInput,
} from "react-admin";
import { Box } from "@mui/material";
import { MaskedTextInput } from '../sharedComponents/MaskedTextInput'

export const SindicatoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Fill with the Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='codigoBanco'
					label='Codigo Banco'
					helperText='Fill with the Codigo Banco'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='codigoAgencia'
					label='Codigo Agencia'
					helperText='Fill with the Codigo Agencia'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='contaBanco'
					label='Conta Banco'
					helperText='Fill with the Conta Banco[20]'
					validate={[maxLength(20, 'Max=20'), ]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='codigoCedente'
					label='Codigo Cedente'
					helperText='Fill with the Codigo Cedente[30]'
					validate={[maxLength(30, 'Max=30'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='logradouro'
					label='Logradouro'
					helperText='Fill with the Logradouro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={2}>
				<TextInput
					source='numero'
					label='Numero'
					helperText='Fill with the Numero[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='bairro'
					label='Bairro'
					helperText='Fill with the Bairro[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='municipioIbge'
					label='Municipio IBGE'
					helperText='Fill with the Municipio Ibge'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='UF'
					source='uf'
					helperText='Fill with the Uf'
					choices={ [{"id":"0","name":"AC"},{"id":"1","name":"AL"},{"id":"2","name":"AP"},{"id":"3","name":"AM"},{"id":"4","name":"BA"},{"id":"5","name":"CE"},{"id":"6","name":"DF"},{"id":"7","name":"ES"},{"id":"8","name":"GO"},{"id":"9","name":"MA"},{"id":"10","name":"MT"},{"id":"11","name":"MS"},{"id":"12","name":"MG"},{"id":"13","name":"PA"},{"id":"14","name":"PB"},{"id":"15","name":"PR"},{"id":"16","name":"PE"},{"id":"17","name":"PI"},{"id":"18","name":"RJ"},{"id":"19","name":"RN"},{"id":"20","name":"RS"},{"id":"21","name":"RO"},{"id":"22","name":"RR"},{"id":"23","name":"SC"},{"id":"24","name":"SP"},{"id":"25","name":"SE"},{"id":"26","name":"TO"}] }  
				/>
			</Box>
			<Box flex={3}>
				<MaskedTextInput
					mask='(##)#####-####'
					source='fone1'
					label='Fone 1'
					helperText='Fill with the Fone 1'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<MaskedTextInput
					mask='(##)#####-####'
					source='fone2'
					label='Fone 2'
					helperText='Fill with the Fone 2'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='email'
					label='Email'
					helperText='Fill with the Email[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<SelectInput
					label='Tipo Sindicato'
					source='tipoSindicato'
					helperText='Fill with the Tipo Sindicato'
					choices={ [{"id":"P","name":"Patronal"},{"id":"E","name":"Empregados"}] }  
				/>
			</Box>
			<Box flex={4}>
				<DateInput
					source='dataBase'
					label='Data Base'
					helperText='Fill with the Data Base'
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='pisoSalarial'
					label='Piso Salarial'
					helperText='Fill with the Piso Salarial'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<MaskedTextInput
					mask='##.###.###/####-##'
					source='cnpj'
					label='CNP'
					helperText='Fill with the Cnpj'
					validate={[]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='classificacaoContabilConta'
					label='Conta Contábil'
					helperText='Fill with the Classificacao Contabil Conta[30]'
					validate={[maxLength(30, 'Max=30'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);