import {
	Edit,
} from "react-admin";
import { SindicatoForm } from "./SindicatoForm";

const SindicatoEdit = () => {
	return (
		<Edit>
			<SindicatoForm />
		</Edit>
	);
};

export default SindicatoEdit;