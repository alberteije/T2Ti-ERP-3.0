import {
	Create,
} from "react-admin";
import { SindicatoForm } from "./SindicatoForm";

const SindicatoCreate = () => {
	return (
		<Create>
			<SindicatoForm />
		</Create>
	);
};

export default SindicatoCreate;