import {
	Create,
} from "react-admin";
import { MunicipioForm } from "./MunicipioForm";

const MunicipioCreate = () => {
	return (
		<Create>
			<MunicipioForm />
		</Create>
	);
};

export default MunicipioCreate;