/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const MunicipioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["ufModel.sigla","nome","codigoIbge"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MunicipioSmallScreenList : MunicipioBigScreenList;

	return (
		<List
			title="Município"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MunicipioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.ufModel.sigla }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.codigoIbge }
		/>
	);
}

const MunicipioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Uf" source="ufModel.id" reference="uf" sortable={false}>
				<TextField source="sigla" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<TextField source="codigoIbge" label="Codigo Ibge" />
			<TextField source="codigoReceitaFederal" label="Codigo Receita Federal" />
			<TextField source="codigoEstadual" label="Codigo Estadual" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MunicipioList;
