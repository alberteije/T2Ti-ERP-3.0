import {
	Edit,
} from "react-admin";
import { MunicipioForm } from "./MunicipioForm";

const MunicipioEdit = () => {
	return (
		<Edit>
			<MunicipioForm />
		</Edit>
	);
};

export default MunicipioEdit;