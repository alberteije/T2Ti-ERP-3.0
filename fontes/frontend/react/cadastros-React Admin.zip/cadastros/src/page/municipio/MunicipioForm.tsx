/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const MunicipioForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<ReferenceInput source='ufModel.id' reference='uf' filter={{'field': 'sigla'}}>
					<AutocompleteInput
						label='UF'
						optionText='sigla'
						helperText='Informe os dados para o campo UF'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={9}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='codigoIbge'
					label='Codigo IBGE'
					helperText='Informe os dados para o campo Codigo IBGE'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='codigoReceitaFederal'
					label='Codigo Receita Federal'
					helperText='Informe os dados para o campo Codigo Receita Federal'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='codigoEstadual'
					label='Codigo Estadual'
					helperText='Informe os dados para o campo Codigo Estadual'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);