import MunicipioIcon from "@mui/icons-material/Apps";
import MunicipioList from "./MunicipioList";
import MunicipioCreate from "./MunicipioCreate";
import MunicipioEdit from "./MunicipioEdit";

export default {
	list: MunicipioList,
	create: MunicipioCreate,
	edit: MunicipioEdit,
	icon: MunicipioIcon,
};
