import ProdutoUnidadeIcon from "@mui/icons-material/Apps";
import ProdutoUnidadeList from "./ProdutoUnidadeList";
import ProdutoUnidadeCreate from "./ProdutoUnidadeCreate";
import ProdutoUnidadeEdit from "./ProdutoUnidadeEdit";

export default {
	list: ProdutoUnidadeList,
	create: ProdutoUnidadeCreate,
	edit: ProdutoUnidadeEdit,
	icon: ProdutoUnidadeIcon,
};
