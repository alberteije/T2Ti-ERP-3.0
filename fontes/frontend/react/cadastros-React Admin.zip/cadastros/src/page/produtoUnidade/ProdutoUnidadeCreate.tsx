import {
	Create,
} from "react-admin";
import { ProdutoUnidadeForm } from "./ProdutoUnidadeForm";

const ProdutoUnidadeCreate = () => {
	return (
		<Create>
			<ProdutoUnidadeForm />
		</Create>
	);
};

export default ProdutoUnidadeCreate;