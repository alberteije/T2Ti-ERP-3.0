/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";

export const ProdutoUnidadeForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='sigla'
					label='Sigla'
					helperText='Informe os dados para o campo Sigla[10]'
					validate={[maxLength(10, 'Max=10'), ]}
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Pode Fracionar'
					source='podeFracionar'
					helperText='Informe os dados para o campo Pode Fracionar'
					choices={ [{"id":"S","name":"Sim"},{"id":"N","name":"Não"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[250]'
					multiline
					validate={[maxLength(250, 'Max=250'), ]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);