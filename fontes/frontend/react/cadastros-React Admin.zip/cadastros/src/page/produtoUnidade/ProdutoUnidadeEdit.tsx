import {
	Edit,
} from "react-admin";
import { ProdutoUnidadeForm } from "./ProdutoUnidadeForm";

const ProdutoUnidadeEdit = () => {
	return (
		<Edit>
			<ProdutoUnidadeForm />
		</Edit>
	);
};

export default ProdutoUnidadeEdit;