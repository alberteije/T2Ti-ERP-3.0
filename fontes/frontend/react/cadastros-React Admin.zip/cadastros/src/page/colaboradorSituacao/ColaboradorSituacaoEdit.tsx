import {
	Edit,
} from "react-admin";
import { ColaboradorSituacaoForm } from "./ColaboradorSituacaoForm";

const ColaboradorSituacaoEdit = () => {
	return (
		<Edit>
			<ColaboradorSituacaoForm />
		</Edit>
	);
};

export default ColaboradorSituacaoEdit;