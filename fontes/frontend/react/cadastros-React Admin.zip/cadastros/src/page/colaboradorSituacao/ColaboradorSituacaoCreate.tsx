import {
	Create,
} from "react-admin";
import { ColaboradorSituacaoForm } from "./ColaboradorSituacaoForm";

const ColaboradorSituacaoCreate = () => {
	return (
		<Create>
			<ColaboradorSituacaoForm />
		</Create>
	);
};

export default ColaboradorSituacaoCreate;