import ColaboradorSituacaoIcon from "@mui/icons-material/Apps";
import ColaboradorSituacaoList from "./ColaboradorSituacaoList";
import ColaboradorSituacaoCreate from "./ColaboradorSituacaoCreate";
import ColaboradorSituacaoEdit from "./ColaboradorSituacaoEdit";

export default {
	list: ColaboradorSituacaoList,
	create: ColaboradorSituacaoCreate,
	edit: ColaboradorSituacaoEdit,
	icon: ColaboradorSituacaoIcon,
};
