import {
	Create,
} from "react-admin";
import { ColaboradorTipoForm } from "./ColaboradorTipoForm";

const ColaboradorTipoCreate = () => {
	return (
		<Create>
			<ColaboradorTipoForm />
		</Create>
	);
};

export default ColaboradorTipoCreate;