import ColaboradorTipoIcon from "@mui/icons-material/Apps";
import ColaboradorTipoList from "./ColaboradorTipoList";
import ColaboradorTipoCreate from "./ColaboradorTipoCreate";
import ColaboradorTipoEdit from "./ColaboradorTipoEdit";

export default {
	list: ColaboradorTipoList,
	create: ColaboradorTipoCreate,
	edit: ColaboradorTipoEdit,
	icon: ColaboradorTipoIcon,
};
