import {
	Edit,
} from "react-admin";
import { ColaboradorTipoForm } from "./ColaboradorTipoForm";

const ColaboradorTipoEdit = () => {
	return (
		<Edit>
			<ColaboradorTipoForm />
		</Edit>
	);
};

export default ColaboradorTipoEdit;