import {
	Create,
} from "react-admin";
import { NivelFormacaoForm } from "./NivelFormacaoForm";

const NivelFormacaoCreate = () => {
	return (
		<Create>
			<NivelFormacaoForm />
		</Create>
	);
};

export default NivelFormacaoCreate;