import {
	Edit,
} from "react-admin";
import { NivelFormacaoForm } from "./NivelFormacaoForm";

const NivelFormacaoEdit = () => {
	return (
		<Edit>
			<NivelFormacaoForm />
		</Edit>
	);
};

export default NivelFormacaoEdit;