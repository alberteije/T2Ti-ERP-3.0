import NivelFormacaoIcon from "@mui/icons-material/Apps";
import NivelFormacaoList from "./NivelFormacaoList";
import NivelFormacaoCreate from "./NivelFormacaoCreate";
import NivelFormacaoEdit from "./NivelFormacaoEdit";

export default {
	list: NivelFormacaoList,
	create: NivelFormacaoCreate,
	edit: NivelFormacaoEdit,
	icon: NivelFormacaoIcon,
};
