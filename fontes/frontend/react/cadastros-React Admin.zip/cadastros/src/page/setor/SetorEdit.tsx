import {
	Edit,
} from "react-admin";
import { SetorForm } from "./SetorForm";

const SetorEdit = () => {
	return (
		<Edit>
			<SetorForm />
		</Edit>
	);
};

export default SetorEdit;