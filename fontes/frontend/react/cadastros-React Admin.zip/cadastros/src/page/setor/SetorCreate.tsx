import {
	Create,
} from "react-admin";
import { SetorForm } from "./SetorForm";

const SetorCreate = () => {
	return (
		<Create>
			<SetorForm />
		</Create>
	);
};

export default SetorCreate;