import SetorIcon from "@mui/icons-material/Apps";
import SetorList from "./SetorList";
import SetorCreate from "./SetorCreate";
import SetorEdit from "./SetorEdit";

export default {
	list: SetorList,
	create: SetorCreate,
	edit: SetorEdit,
	icon: SetorIcon,
};
