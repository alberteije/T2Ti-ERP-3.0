import {
	Edit,
} from "react-admin";
import { NcmForm } from "./NcmForm";

const NcmEdit = () => {
	return (
		<Edit>
			<NcmForm />
		</Edit>
	);
};

export default NcmEdit;