import {
	Create,
} from "react-admin";
import { NcmForm } from "./NcmForm";

const NcmCreate = () => {
	return (
		<Create>
			<NcmForm />
		</Create>
	);
};

export default NcmCreate;