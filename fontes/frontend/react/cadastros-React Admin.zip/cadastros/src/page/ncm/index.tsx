import NcmIcon from "@mui/icons-material/Apps";
import NcmList from "./NcmList";
import NcmCreate from "./NcmCreate";
import NcmEdit from "./NcmEdit";

export default {
	list: NcmList,
	create: NcmCreate,
	edit: NcmEdit,
	icon: NcmIcon,
};
