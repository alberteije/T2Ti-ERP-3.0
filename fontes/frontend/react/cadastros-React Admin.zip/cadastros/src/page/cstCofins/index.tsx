import CstCofinsIcon from "@mui/icons-material/Apps";
import CstCofinsList from "./CstCofinsList";
import CstCofinsCreate from "./CstCofinsCreate";
import CstCofinsEdit from "./CstCofinsEdit";

export default {
	list: CstCofinsList,
	create: CstCofinsCreate,
	edit: CstCofinsEdit,
	icon: CstCofinsIcon,
};
