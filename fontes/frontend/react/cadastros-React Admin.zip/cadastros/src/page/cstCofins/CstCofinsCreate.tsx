import {
	Create,
} from "react-admin";
import { CstCofinsForm } from "./CstCofinsForm";

const CstCofinsCreate = () => {
	return (
		<Create>
			<CstCofinsForm />
		</Create>
	);
};

export default CstCofinsCreate;