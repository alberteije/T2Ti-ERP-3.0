import {
	Edit,
} from "react-admin";
import { CstCofinsForm } from "./CstCofinsForm";

const CstCofinsEdit = () => {
	return (
		<Edit>
			<CstCofinsForm />
		</Edit>
	);
};

export default CstCofinsEdit;