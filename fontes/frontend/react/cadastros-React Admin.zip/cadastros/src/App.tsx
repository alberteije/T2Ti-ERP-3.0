import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import pessoa from './page/pessoa';
import colaborador from './page/colaborador';
import estadoCivil from './page/estadoCivil';
import cargo from './page/cargo';
import setor from './page/setor';
import colaboradorSituacao from './page/colaboradorSituacao';
import tipoAdmissao from './page/tipoAdmissao';
import colaboradorTipo from './page/colaboradorTipo';
import produtoGrupo from './page/produtoGrupo';
import produtoSubgrupo from './page/produtoSubgrupo';
import produtoMarca from './page/produtoMarca';
import produtoUnidade from './page/produtoUnidade';
import produto from './page/produto';
import banco from './page/banco';
import bancoAgencia from './page/bancoAgencia';
import bancoContaCaixa from './page/bancoContaCaixa';
import cep from './page/cep';
import uf from './page/uf';
import municipio from './page/municipio';
import ncm from './page/ncm';
import cfop from './page/cfop';
import cstIcms from './page/cstIcms';
import cstIpi from './page/cstIpi';
import cstCofins from './page/cstCofins';
import cstPis from './page/cstPis';
import csosn from './page/csosn';
import cnae from './page/cnae';
import pais from './page/pais';
import nivelFormacao from './page/nivelFormacao';
import tabelaPreco from './page/tabelaPreco';
import tipoRelacionamento from './page/tipoRelacionamento';
import sindicato from './page/sindicato';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'cadastros');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Cadastros (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='pessoa' {...pessoa} options={{ label: 'Pessoa' }} />
			<Resource name='colaborador' {...colaborador} options={{ label: 'Colaborador' }} />
			<Resource name='estado-civil' {...estadoCivil} options={{ label: 'Estado Civil' }} />
			<Resource name='cargo' {...cargo} options={{ label: 'Cargo' }} />
			<Resource name='setor' {...setor} options={{ label: 'Setor' }} />
			<Resource name='colaborador-situacao' {...colaboradorSituacao} options={{ label: 'Situação Colaborador' }} />
			<Resource name='tipo-admissao' {...tipoAdmissao} options={{ label: 'Tipo Admissão' }} />
			<Resource name='colaborador-tipo' {...colaboradorTipo} options={{ label: 'Tipo Colaborador' }} />
			<Resource name='produto-grupo' {...produtoGrupo} options={{ label: 'Grupo Produto' }} />
			<Resource name='produto-subgrupo' {...produtoSubgrupo} options={{ label: 'Subgrupo Produto' }} />
			<Resource name='produto-marca' {...produtoMarca} options={{ label: 'Marca Produto' }} />
			<Resource name='produto-unidade' {...produtoUnidade} options={{ label: 'Unidade Produto' }} />
			<Resource name='produto' {...produto} options={{ label: 'Produto' }} />
			<Resource name='banco' {...banco} options={{ label: 'Banco' }} />
			<Resource name='banco-agencia' {...bancoAgencia} options={{ label: 'Agência' }} />
			<Resource name='banco-conta-caixa' {...bancoContaCaixa} options={{ label: 'Conta/Caixa' }} />
			<Resource name='cep' {...cep} options={{ label: 'CEP' }} />
			<Resource name='uf' {...uf} options={{ label: 'UF' }} />
			<Resource name='municipio' {...municipio} options={{ label: 'Município' }} />
			<Resource name='ncm' {...ncm} options={{ label: 'NCM' }} />
			<Resource name='cfop' {...cfop} options={{ label: 'CFOP' }} />
			<Resource name='cst-icms' {...cstIcms} options={{ label: 'CST ICMS' }} />
			<Resource name='cst-ipi' {...cstIpi} options={{ label: 'CST IPI' }} />
			<Resource name='cst-cofins' {...cstCofins} options={{ label: 'CST COFINS' }} />
			<Resource name='cst-pis' {...cstPis} options={{ label: 'CST PIS' }} />
			<Resource name='csosn' {...csosn} options={{ label: 'CSOSN' }} />
			<Resource name='cnae' {...cnae} options={{ label: 'CNAE' }} />
			<Resource name='pais' {...pais} options={{ label: 'País' }} />
			<Resource name='nivel-formacao' {...nivelFormacao} options={{ label: 'Nível Formação' }} />
			<Resource name='tabela-preco' {...tabelaPreco} options={{ label: 'Tabelas de Preço' }} />
			<Resource name='tipo-relacionamento' {...tipoRelacionamento} options={{ label: 'Tipo Relacionamento' }} />
			<Resource name='sindicato' {...sindicato} options={{ label: 'Sindicato' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;