/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	DateInput,
	NumberInput,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";
import { CompraPedidoDetalheTab } from './CompraPedidoDetalheTab';

export const CompraPedidoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Pedido">
				<CompraPedidoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens Pedido">
				<CompraPedidoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CompraPedidoTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<ReferenceInput source='compraTipoPedidoModel.id' reference='compra-tipo-pedido' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tipo Pedido'
						optionText='nome'
						helperText='Informe os dados para o campo Tipo Pedido'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={6}>
				<ReferenceInput source='viewPessoaColaboradorModel.id' reference='view-pessoa-colaborador' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Colaborador'
						optionText='nome'
						helperText='Informe os dados para o campo Colaborador'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={8}>
				<ReferenceInput source='viewPessoaFornecedorModel.id' reference='view-pessoa-fornecedor' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Fornecedor'
						optionText='nome'
						helperText='Informe os dados para o campo Fornecedor'  
					/>
				</ReferenceInput>
			</Box>
			<Box flex={4}>
				<TextInput
					source='codigoCotacao'
					label='Codigo Cotacao'
					helperText='Informe os dados para o campo Codigo Cotacao[32]'
					validate={[maxLength(32, 'Max=32'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<DateInput
					source='dataPedido'
					label='Data Pedido'
					helperText='Informe os dados para o campo Data Pedido'
				/>
			</Box>
			<Box flex={4}>
				<DateInput
					source='dataPrevistaEntrega'
					label='Data Prevista Entrega'
					helperText='Informe os dados para o campo Data Prevista Entrega'
				/>
			</Box>
			<Box flex={4}>
				<DateInput
					source='dataPrevisaoPagamento'
					label='Data Previsao Pagamento'
					helperText='Informe os dados para o campo Data Previsao Pagamento'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<TextInput
					source='localEntrega'
					label='Local Entrega'
					helperText='Informe os dados para o campo Local Entrega[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={6}>
				<TextInput
					source='localCobranca'
					label='Local Cobranca'
					helperText='Informe os dados para o campo Local Cobranca[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='contato'
					label='Contato'
					helperText='Informe os dados para o campo Contato[50]'
					validate={[maxLength(50, 'Max=50'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='valorSubtotal'
					label='Valor Subtotal'
					helperText='Informe os dados para o campo Valor Subtotal'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='taxaDesconto'
					label='Taxa Desconto'
					helperText='Informe os dados para o campo Taxa Desconto'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorDesconto'
					label='Valor Desconto'
					helperText='Informe os dados para o campo Valor Desconto'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorTotal'
					label='Valor Total'
					helperText='Informe os dados para o campo Valor Total'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Tipo Frete'
					source='tipoFrete'
					helperText='Informe os dados para o campo Tipo Frete'
					choices={ [{"id":"C","name":"CIF"},{"id":"F","name":"FOB"}] }  
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Forma Pagamento'
					source='formaPagamento'
					helperText='Informe os dados para o campo Forma Pagamento'
					choices={ [{"id":"V","name":"Vista"},{"id":"P","name":"Prazo"},{"id":"O","name":"Outros"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='baseCalculoIcms'
					label='Base Calculo Icms'
					helperText='Informe os dados para o campo Base Calculo Icms'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorIcms'
					label='Valor Icms'
					helperText='Informe os dados para o campo Valor Icms'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='baseCalculoIcmsSt'
					label='Base Calculo Icms St'
					helperText='Informe os dados para o campo Base Calculo Icms St'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorIcmsSt'
					label='Valor Icms St'
					helperText='Informe os dados para o campo Valor Icms St'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='valorTotalProdutos'
					label='Valor Total Produtos'
					helperText='Informe os dados para o campo Valor Total Produtos'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorFrete'
					label='Valor Frete'
					helperText='Informe os dados para o campo Valor Frete'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorSeguro'
					label='Valor Seguro'
					helperText='Informe os dados para o campo Valor Seguro'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='valorOutrasDespesas'
					label='Valor Outras Despesas'
					helperText='Informe os dados para o campo Valor Outras Despesas'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorIpi'
					label='Valor Ipi'
					helperText='Informe os dados para o campo Valor Ipi'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorTotalNf'
					label='Valor Total Nf'
					helperText='Informe os dados para o campo Valor Total Nf'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='quantidadeParcelas'
					label='Quantidade Parcelas'
					helperText='Informe os dados para o campo Quantidade Parcelas'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='diaPrimeiroVencimento'
					label='Dia Primeiro Vencimento'
					helperText='Informe os dados para o campo Dia Primeiro Vencimento[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='intervaloEntreParcelas'
					label='Intervalo Entre Parcelas'
					helperText='Informe os dados para o campo Intervalo Entre Parcelas'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<TextInput
					source='diaFixoParcela'
					label='Dia Fixo Parcela'
					helperText='Informe os dados para o campo Dia Fixo Parcela[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
		</Box>
	</>
	);
};