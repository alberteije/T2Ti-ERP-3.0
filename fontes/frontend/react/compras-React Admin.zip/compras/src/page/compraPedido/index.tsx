import CompraPedidoIcon from "@mui/icons-material/Apps";
import CompraPedidoList from "./CompraPedidoList";
import CompraPedidoCreate from "./CompraPedidoCreate";
import CompraPedidoEdit from "./CompraPedidoEdit";

export default {
	list: CompraPedidoList,
	create: CompraPedidoCreate,
	edit: CompraPedidoEdit,
	icon: CompraPedidoIcon,
};
