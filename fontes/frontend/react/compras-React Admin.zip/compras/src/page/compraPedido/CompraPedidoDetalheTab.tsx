/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
	TextInput,
	maxLength,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CompraPedidoDetalhe {
	constructor(
		public id = 0,
		public produtoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public quantidade = null,
		public valorUnitario = null,
		public valorSubtotal = null,
		public taxaDesconto = null,
		public valorDesconto = null,
		public valorTotal = null,
		public cst = '',
		public csosn = '',
		public cfop = null,
		public baseCalculoIcms = null,
		public valorIcms = null,
		public valorIpi = null,
		public aliquotaIcms = null,
		public aliquotaIpi = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CompraPedidoDetalhe {
		const compraPedidoDetalhe = new CompraPedidoDetalhe();
		compraPedidoDetalhe.id = Date.now();
		compraPedidoDetalhe.statusCrud = "C";
		return compraPedidoDetalhe;
	}
}

export const CompraPedidoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: CompraPedidoDetalhe,
		setCurrentRecord: (record: CompraPedidoDetalhe) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								produtoModel: {
						  		...currentRecord.produtoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='quantidade'
					label='Quantidade'
					helperText='Informe os dados para o campo Quantidade'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									quantidade: e.target.value,
								});
							}} format={(_: any) => currentRecord.quantidade ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorUnitario'
					label='Valor Unitario'
					helperText='Informe os dados para o campo Valor Unitario'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorUnitario: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorUnitario ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorSubtotal'
					label='Valor Subtotal'
					helperText='Informe os dados para o campo Valor Subtotal'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorSubtotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorSubtotal ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='taxaDesconto'
					label='Taxa Desconto'
					helperText='Informe os dados para o campo Taxa Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									taxaDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.taxaDesconto ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorDesconto'
					label='Valor Desconto'
					helperText='Informe os dados para o campo Valor Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorDesconto ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorTotal'
					label='Valor Total'
					helperText='Informe os dados para o campo Valor Total'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorTotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorTotal ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<TextInput
					source='cst'
					label='Cst'
					helperText='Informe os dados para o campo Cst[2]'
					validate={[maxLength(2, 'Max=2'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									cst: e.target.value,
								});
							}} format={(_: any) => currentRecord.cst ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='csosn'
					label='Csosn'
					helperText='Informe os dados para o campo Csosn[3]'
					validate={[maxLength(3, 'Max=3'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									csosn: e.target.value,
								});
							}} format={(_: any) => currentRecord.csosn ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='cfop'
					label='Cfop'
					helperText='Informe os dados para o campo Cfop'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									cfop: e.target.value,
								});
							}} format={(_: any) => currentRecord.cfop ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='baseCalculoIcms'
					label='Base Calculo Icms'
					helperText='Informe os dados para o campo Base Calculo Icms'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									baseCalculoIcms: e.target.value,
								});
							}} format={(_: any) => currentRecord.baseCalculoIcms ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorIcms'
					label='Valor Icms'
					helperText='Informe os dados para o campo Valor Icms'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorIcms: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorIcms ?? ''}
				/>
			</Box>
			<Box flex={2}>
				<NumberInput
					source='valorIpi'
					label='Valor Ipi'
					helperText='Informe os dados para o campo Valor Ipi'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorIpi: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorIpi ?? ''}
				/>
			</Box>
			<Box flex={2}>
				<NumberInput
					source='aliquotaIcms'
					label='Aliquota Icms'
					helperText='Informe os dados para o campo Aliquota Icms'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquotaIcms: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquotaIcms ?? ''}
				/>
			</Box>
			<Box flex={2}>
				<NumberInput
					source='aliquotaIpi'
					label='Aliquota Ipi'
					helperText='Informe os dados para o campo Aliquota Ipi'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquotaIpi: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquotaIpi ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
		{ source: 'valorUnitario', label: 'Valor Unitario' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
		{ source: 'cst', label: 'Cst' },
		{ source: 'csosn', label: 'Csosn' },
		{ source: 'cfop', label: 'Cfop' },
		{ source: 'baseCalculoIcms', label: 'Base Calculo Icms' },
		{ source: 'valorIcms', label: 'Valor Icms' },
		{ source: 'valorIpi', label: 'Valor Ipi' },
		{ source: 'aliquotaIcms', label: 'Aliquota Icms' },
		{ source: 'aliquotaIpi', label: 'Aliquota Ipi' },
	];

	return (
		<CrudChildTab
			title="Itens Pedido"
			recordContext="compraPedido"
			fieldSource="compraPedidoDetalheModelList"
			newObject={ CompraPedidoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};