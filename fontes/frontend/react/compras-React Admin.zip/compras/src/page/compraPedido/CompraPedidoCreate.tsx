/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CompraPedidoForm } from "./CompraPedidoForm";
import { transformNestedData } from "../../infra/utils";

const CompraPedidoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CompraPedidoForm />
		</Create>
	);
};

export default CompraPedidoCreate;