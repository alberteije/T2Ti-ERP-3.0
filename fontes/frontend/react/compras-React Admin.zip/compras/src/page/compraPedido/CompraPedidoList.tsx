/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	NumberField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import CompraPedidoDomain from '../../data/domain/CompraPedidoDomain';

const CompraPedidoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["compraTipoPedidoModel.nome","viewPessoaColaboradorModel.nome","viewPessoaFornecedorModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CompraPedidoSmallScreenList : CompraPedidoBigScreenList;

	return (
		<List
			title="Pedido"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CompraPedidoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.compraTipoPedidoModel.nome }
			secondaryText={ (record) => record.viewPessoaColaboradorModel.nome }
			tertiaryText={ (record) => record.viewPessoaFornecedorModel.nome }
		/>
	);
}

const CompraPedidoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Compra Tipo Pedido" source="compraTipoPedidoModel.id" reference="compra-tipo-pedido" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fornecedor" source="viewPessoaFornecedorModel.id" reference="view-pessoa-fornecedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigoCotacao" label="Codigo Cotacao" />
			<TextField source="dataPedido" label="Data Pedido" />
			<TextField source="dataPrevistaEntrega" label="Data Prevista Entrega" />
			<TextField source="dataPrevisaoPagamento" label="Data Previsao Pagamento" />
			<TextField source="localEntrega" label="Local Entrega" />
			<TextField source="localCobranca" label="Local Cobranca" />
			<TextField source="contato" label="Contato" />
			<NumberField source="valorSubtotal" label="Valor Subtotal" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="taxaDesconto" label="Taxa Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Tipo Frete"
				render={record => CompraPedidoDomain.getTipoFrete(record.tipoFrete)}
			/>
			<FunctionField
				label="Forma Pagamento"
				render={record => CompraPedidoDomain.getFormaPagamento(record.formaPagamento)}
			/>
			<NumberField source="baseCalculoIcms" label="Base Calculo Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcms" label="Valor Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="baseCalculoIcmsSt" label="Base Calculo Icms St" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsSt" label="Valor Icms St" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalProdutos" label="Valor Total Produtos" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorFrete" label="Valor Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSeguro" label="Valor Seguro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorOutrasDespesas" label="Valor Outras Despesas" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIpi" label="Valor Ipi" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalNf" label="Valor Total Nf" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="quantidadeParcelas" label="Quantidade Parcelas" />
			<TextField source="diaPrimeiroVencimento" label="Dia Primeiro Vencimento" />
			<TextField source="intervaloEntreParcelas" label="Intervalo Entre Parcelas" />
			<TextField source="diaFixoParcela" label="Dia Fixo Parcela" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CompraPedidoList;
