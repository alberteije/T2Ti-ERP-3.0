/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CompraRequisicaoDetalhe {
	constructor(
		public id = 0,
		public produtoModel: { id: any, nome: any } = { id: 0, nome: '' },
		public quantidade = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CompraRequisicaoDetalhe {
		const compraRequisicaoDetalhe = new CompraRequisicaoDetalhe();
		compraRequisicaoDetalhe.id = Date.now();
		compraRequisicaoDetalhe.statusCrud = "C";
		return compraRequisicaoDetalhe;
	}
}

export const CompraRequisicaoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: CompraRequisicaoDetalhe,
		setCurrentRecord: (record: CompraRequisicaoDetalhe) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={10}>
				<ReferenceInput source='produtoModel.id' reference='produto' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Produto'
						optionText='nome'
						helperText='Informe os dados para o campo Produto'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								produtoModel: {
						  		...currentRecord.produtoModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
			<Box flex={2}>
				<NumberInput
					source='quantidade'
					label='Quantidade'
					helperText='Informe os dados para o campo Quantidade'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									quantidade: e.target.value,
								});
							}} format={(_: any) => currentRecord.quantidade ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Itens Requisição"
			recordContext="compraRequisicao"
			fieldSource="compraRequisicaoDetalheModelList"
			newObject={ CompraRequisicaoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};