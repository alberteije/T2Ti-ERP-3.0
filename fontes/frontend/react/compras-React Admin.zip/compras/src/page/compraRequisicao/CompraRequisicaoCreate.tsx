/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CompraRequisicaoForm } from "./CompraRequisicaoForm";
import { transformNestedData } from "../../infra/utils";

const CompraRequisicaoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CompraRequisicaoForm />
		</Create>
	);
};

export default CompraRequisicaoCreate;