/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CompraRequisicaoForm } from "./CompraRequisicaoForm";
import { transformNestedData } from "../../infra/utils";

const CompraRequisicaoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CompraRequisicaoForm />
		</Edit>
	);
};

export default CompraRequisicaoEdit;