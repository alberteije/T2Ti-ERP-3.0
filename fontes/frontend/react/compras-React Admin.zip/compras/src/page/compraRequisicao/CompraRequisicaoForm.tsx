/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	DateInput,
} from "react-admin";
import { Box } from "@mui/material";
import { CompraRequisicaoDetalheTab } from './CompraRequisicaoDetalheTab';

export const CompraRequisicaoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Requisição">
				<CompraRequisicaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens Requisição">
				<CompraRequisicaoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CompraRequisicaoTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='compraTipoRequisicaoModel.id' reference='compra-tipo-requisicao' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Tipo Requisicao'
						optionText='nome'
						helperText='Informe os dados para o campo Tipo Requisicao'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='viewPessoaColaboradorModel.id' reference='view-pessoa-colaborador' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Colaborador'
						optionText='nome'
						helperText='Informe os dados para o campo Colaborador'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={9}>
				<TextInput
					source='descricao'
					label='Descrição'
					helperText='Informe os dados para o campo Descricao[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={3}>
				<DateInput
					source='dataRequisicao'
					label='Data Requisição'
					helperText='Informe os dados para o campo Data Requisicao'
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observação'
					helperText='Informe os dados para o campo Observacao'
					multiline
					validate={[]}
				/>
			</Box>
		</Box>
	</>
	);
};