import CompraRequisicaoIcon from "@mui/icons-material/Apps";
import CompraRequisicaoList from "./CompraRequisicaoList";
import CompraRequisicaoCreate from "./CompraRequisicaoCreate";
import CompraRequisicaoEdit from "./CompraRequisicaoEdit";

export default {
	list: CompraRequisicaoList,
	create: CompraRequisicaoCreate,
	edit: CompraRequisicaoEdit,
	icon: CompraRequisicaoIcon,
};
