import {
	Create,
} from "react-admin";
import { CompraTipoRequisicaoForm } from "./CompraTipoRequisicaoForm";

const CompraTipoRequisicaoCreate = () => {
	return (
		<Create>
			<CompraTipoRequisicaoForm />
		</Create>
	);
};

export default CompraTipoRequisicaoCreate;