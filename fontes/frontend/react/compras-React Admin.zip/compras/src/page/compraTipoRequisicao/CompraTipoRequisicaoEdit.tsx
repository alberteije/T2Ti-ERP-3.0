import {
	Edit,
} from "react-admin";
import { CompraTipoRequisicaoForm } from "./CompraTipoRequisicaoForm";

const CompraTipoRequisicaoEdit = () => {
	return (
		<Edit>
			<CompraTipoRequisicaoForm />
		</Edit>
	);
};

export default CompraTipoRequisicaoEdit;