import CompraTipoRequisicaoIcon from "@mui/icons-material/Apps";
import CompraTipoRequisicaoList from "./CompraTipoRequisicaoList";
import CompraTipoRequisicaoCreate from "./CompraTipoRequisicaoCreate";
import CompraTipoRequisicaoEdit from "./CompraTipoRequisicaoEdit";

export default {
	list: CompraTipoRequisicaoList,
	create: CompraTipoRequisicaoCreate,
	edit: CompraTipoRequisicaoEdit,
	icon: CompraTipoRequisicaoIcon,
};
