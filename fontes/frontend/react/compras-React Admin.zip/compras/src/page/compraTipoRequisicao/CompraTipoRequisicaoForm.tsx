/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";

export const CompraTipoRequisicaoForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[2]'
					validate={[maxLength(2, 'Max=2'), ]}
				/>
			</Box>
			<Box flex={8}>
				<TextInput
					source='nome'
					label='Nome'
					helperText='Informe os dados para o campo Nome[30]'
					validate={[maxLength(30, 'Max=30'), ]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao'
					multiline
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);