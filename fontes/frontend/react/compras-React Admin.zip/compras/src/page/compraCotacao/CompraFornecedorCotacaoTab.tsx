/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ReferenceInput,
	AutocompleteInput,
	TextInput,
	maxLength,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class CompraFornecedorCotacao {
	constructor(
		public id = 0,
		public viewPessoaFornecedorModel: { id: any, nome: any } = { id: 0, nome: '' },
		public codigo = '',
		public prazoEntrega = '',
		public vendaCondicoesPagamento = '',
		public valorSubtotal = null,
		public taxaDesconto = null,
		public valorDesconto = null,
		public valorTotal = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): CompraFornecedorCotacao {
		const compraFornecedorCotacao = new CompraFornecedorCotacao();
		compraFornecedorCotacao.id = Date.now();
		compraFornecedorCotacao.statusCrud = "C";
		return compraFornecedorCotacao;
	}
}

export const CompraFornecedorCotacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: CompraFornecedorCotacao,
		setCurrentRecord: (record: CompraFornecedorCotacao) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='viewPessoaFornecedorModel.id' reference='view-pessoa-fornecedor' filter={{'field': 'nome'}}>
					<AutocompleteInput
						label='Fornecedor'
						optionText='nome'
						helperText='Informe os dados para o campo Fornecedor'  
						onChange={(value: any) => {
							setCurrentRecord({
								...currentRecord,
								viewPessoaFornecedorModel: {
						  		...currentRecord.viewPessoaFornecedorModel,
						  		id: value,
						  	},
							});
						}}
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<TextInput
					source='codigo'
					label='Codigo'
					helperText='Informe os dados para o campo Codigo[32]'
					validate={[maxLength(32, 'Max=32'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									codigo: e.target.value,
								});
							}} format={(_: any) => currentRecord.codigo ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='prazoEntrega'
					label='Prazo Entrega'
					helperText='Informe os dados para o campo Prazo Entrega[50]'
					validate={[maxLength(50, 'Max=50'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									prazoEntrega: e.target.value,
								});
							}} format={(_: any) => currentRecord.prazoEntrega ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<TextInput
					source='vendaCondicoesPagamento'
					label='Venda Condicoes Pagamento'
					helperText='Informe os dados para o campo Venda Condicoes Pagamento[50]'
					validate={[maxLength(50, 'Max=50'), ]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									vendaCondicoesPagamento: e.target.value,
								});
							}} format={(_: any) => currentRecord.vendaCondicoesPagamento ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='valorSubtotal'
					label='Valor Subtotal'
					helperText='Informe os dados para o campo Valor Subtotal'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorSubtotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorSubtotal ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='taxaDesconto'
					label='Taxa Desconto'
					helperText='Informe os dados para o campo Taxa Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									taxaDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.taxaDesconto ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorDesconto'
					label='Valor Desconto'
					helperText='Informe os dados para o campo Valor Desconto'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorDesconto: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorDesconto ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorTotal'
					label='Valor Total'
					helperText='Informe os dados para o campo Valor Total'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorTotal: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorTotal ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'viewPessoaFornecedorModel.id', label: 'Fornecedor', reference: 'view-pessoa-fornecedor', fieldName: 'nome' },
		{ source: 'codigo', label: 'Codigo' },
		{ source: 'prazoEntrega', label: 'Prazo Entrega' },
		{ source: 'vendaCondicoesPagamento', label: 'Venda Condicoes Pagamento' },
		{ source: 'valorSubtotal', label: 'Valor Subtotal' },
		{ source: 'taxaDesconto', label: 'Taxa Desconto' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorTotal', label: 'Valor Total' },
	];

	return (
		<CrudChildTab
			title="Fornecedores"
			recordContext="compraCotacao"
			fieldSource="compraFornecedorCotacaoModelList"
			newObject={ CompraFornecedorCotacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};