/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { CompraCotacaoForm } from "./CompraCotacaoForm";
import { transformNestedData } from "../../infra/utils";

const CompraCotacaoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<CompraCotacaoForm />
		</Create>
	);
};

export default CompraCotacaoCreate;