/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const CompraCotacaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["compraRequisicaoModel.descricao","dataCotacao","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? CompraCotacaoSmallScreenList : CompraCotacaoBigScreenList;

	return (
		<List
			title="Cotação"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const CompraCotacaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.compraRequisicaoModel.descricao }
			secondaryText={ (record) => record.dataCotacao }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const CompraCotacaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Compra Requisicao" source="compraRequisicaoModel.id" reference="compra-requisicao" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<TextField source="dataCotacao" label="Data Cotacao" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default CompraCotacaoList;
