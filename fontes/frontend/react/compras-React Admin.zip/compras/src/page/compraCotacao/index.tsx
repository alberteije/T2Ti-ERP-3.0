import CompraCotacaoIcon from "@mui/icons-material/Apps";
import CompraCotacaoList from "./CompraCotacaoList";
import CompraCotacaoCreate from "./CompraCotacaoCreate";
import CompraCotacaoEdit from "./CompraCotacaoEdit";

export default {
	list: CompraCotacaoList,
	create: CompraCotacaoCreate,
	edit: CompraCotacaoEdit,
	icon: CompraCotacaoIcon,
};
