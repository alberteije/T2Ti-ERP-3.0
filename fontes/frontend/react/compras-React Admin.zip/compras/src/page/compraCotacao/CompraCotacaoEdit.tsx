/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { CompraCotacaoForm } from "./CompraCotacaoForm";
import { transformNestedData } from "../../infra/utils";

const CompraCotacaoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<CompraCotacaoForm />
		</Edit>
	);
};

export default CompraCotacaoEdit;