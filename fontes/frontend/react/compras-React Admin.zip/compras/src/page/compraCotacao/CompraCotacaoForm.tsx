/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
	DateInput,
	TextInput,
	maxLength,
} from "react-admin";
import { Box } from "@mui/material";
import { CompraFornecedorCotacaoTab } from './CompraFornecedorCotacaoTab';
import { CompraCotacaoDetalheTab } from './CompraCotacaoDetalheTab';

export const CompraCotacaoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Cotação">
				<CompraCotacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Fornecedores">
				<CompraFornecedorCotacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens Cotação">
				<CompraCotacaoDetalheTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const CompraCotacaoTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='compraRequisicaoModel.id' reference='compra-requisicao' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Requisicao'
						optionText='descricao'
						helperText='Informe os dados para o campo Requisicao'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<DateInput
					source='dataCotacao'
					label='Data Cotacao'
					helperText='Informe os dados para o campo Data Cotacao'
				/>
			</Box>
			<Box flex={9}>
				<TextInput
					source='descricao'
					label='Descricao'
					helperText='Informe os dados para o campo Descricao[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
		</Box>
	</>
	);
};