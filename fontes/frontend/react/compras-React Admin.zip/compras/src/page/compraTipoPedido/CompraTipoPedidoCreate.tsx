import {
	Create,
} from "react-admin";
import { CompraTipoPedidoForm } from "./CompraTipoPedidoForm";

const CompraTipoPedidoCreate = () => {
	return (
		<Create>
			<CompraTipoPedidoForm />
		</Create>
	);
};

export default CompraTipoPedidoCreate;