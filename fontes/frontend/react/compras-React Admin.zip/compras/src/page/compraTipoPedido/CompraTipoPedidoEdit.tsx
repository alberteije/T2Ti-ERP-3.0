import {
	Edit,
} from "react-admin";
import { CompraTipoPedidoForm } from "./CompraTipoPedidoForm";

const CompraTipoPedidoEdit = () => {
	return (
		<Edit>
			<CompraTipoPedidoForm />
		</Edit>
	);
};

export default CompraTipoPedidoEdit;