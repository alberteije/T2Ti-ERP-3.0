import CompraTipoPedidoIcon from "@mui/icons-material/Apps";
import CompraTipoPedidoList from "./CompraTipoPedidoList";
import CompraTipoPedidoCreate from "./CompraTipoPedidoCreate";
import CompraTipoPedidoEdit from "./CompraTipoPedidoEdit";

export default {
	list: CompraTipoPedidoList,
	create: CompraTipoPedidoCreate,
	edit: CompraTipoPedidoEdit,
	icon: CompraTipoPedidoIcon,
};
