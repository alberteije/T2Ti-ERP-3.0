class CompraPedidoDomain {
	static getTipoFrete(tipoFrete: string) { 
		switch (tipoFrete) { 
			case '': 
			case 'C': 
				return 'CIF'; 
			case 'F': 
				return 'FOB'; 
			default: 
				return null; 
		} 
	} 

	static setTipoFrete(tipoFrete: string) { 
		switch (tipoFrete) { 
			case 'CIF': 
				return 'C'; 
			case 'FOB': 
				return 'F'; 
			default: 
				return null; 
		} 
	}

	static getFormaPagamento(formaPagamento: string) { 
		switch (formaPagamento) { 
			case '': 
			case 'V': 
				return 'Vista'; 
			case 'P': 
				return 'Prazo'; 
			case 'O': 
				return 'Outros'; 
			default: 
				return null; 
		} 
	} 

	static setFormaPagamento(formaPagamento: string) { 
		switch (formaPagamento) { 
			case 'Vista': 
				return 'V'; 
			case 'Prazo': 
				return 'P'; 
			case 'Outros': 
				return 'O'; 
			default: 
				return null; 
		} 
	}

}

export default CompraPedidoDomain;