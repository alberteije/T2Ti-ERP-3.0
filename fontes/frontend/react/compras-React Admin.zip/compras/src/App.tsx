import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import compraRequisicao from './page/compraRequisicao';
import compraCotacao from './page/compraCotacao';
import compraPedido from './page/compraPedido';
import compraTipoRequisicao from './page/compraTipoRequisicao';
import compraTipoPedido from './page/compraTipoPedido';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'compras');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - Compras (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='compra-requisicao' {...compraRequisicao} options={{ label: 'Requisição' }} />
			<Resource name='compra-cotacao' {...compraCotacao} options={{ label: 'Cotação' }} />
			<Resource name='compra-pedido' {...compraPedido} options={{ label: 'Pedido' }} />
			<Resource name='compra-tipo-requisicao' {...compraTipoRequisicao} options={{ label: 'Tipo Requisição' }} />
			<Resource name='compra-tipo-pedido' {...compraTipoPedido} options={{ label: 'Tipo Pedido' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;