import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import compraRequisicao from '../page/compraRequisicao';
import compraCotacao from '../page/compraCotacao';
import compraPedido from '../page/compraPedido';
import compraTipoRequisicao from '../page/compraTipoRequisicao';
import compraTipoPedido from '../page/compraTipoPedido';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/compra-tipo-requisicao'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Requisição'
					leftIcon={<compraTipoRequisicao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/compra-tipo-pedido'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Pedido'
					leftIcon={<compraTipoPedido.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/compra-requisicao'
					state={{ _scrollToTop: true }}
					primaryText='Requisição'
					leftIcon={<compraRequisicao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/compra-cotacao'
					state={{ _scrollToTop: true }}
					primaryText='Cotação'
					leftIcon={<compraCotacao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/compra-pedido'
					state={{ _scrollToTop: true }}
					primaryText='Pedido'
					leftIcon={<compraPedido.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
