import ContratoTemplateIcon from "@mui/icons-material/Apps";
import ContratoTemplateList from "./ContratoTemplateList";
import ContratoTemplateCreate from "./ContratoTemplateCreate";
import ContratoTemplateEdit from "./ContratoTemplateEdit";

export default {
	list: ContratoTemplateList,
	create: ContratoTemplateCreate,
	edit: ContratoTemplateEdit,
	icon: ContratoTemplateIcon,
};
