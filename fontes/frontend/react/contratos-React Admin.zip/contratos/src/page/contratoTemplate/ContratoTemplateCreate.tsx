import {
	Create,
} from "react-admin";
import { ContratoTemplateForm } from "./ContratoTemplateForm";

const ContratoTemplateCreate = () => {
	return (
		<Create>
			<ContratoTemplateForm />
		</Create>
	);
};

export default ContratoTemplateCreate;