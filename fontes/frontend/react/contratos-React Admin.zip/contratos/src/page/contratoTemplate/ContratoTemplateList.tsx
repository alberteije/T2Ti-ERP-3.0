/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContratoTemplateList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContratoTemplateSmallScreenList : ContratoTemplateBigScreenList;

	return (
		<List
			title="Template"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContratoTemplateSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const ContratoTemplateBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContratoTemplateList;
