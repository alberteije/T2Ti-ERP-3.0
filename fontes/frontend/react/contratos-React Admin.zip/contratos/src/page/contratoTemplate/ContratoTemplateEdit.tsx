import {
	Edit,
} from "react-admin";
import { ContratoTemplateForm } from "./ContratoTemplateForm";

const ContratoTemplateEdit = () => {
	return (
		<Edit>
			<ContratoTemplateForm />
		</Edit>
	);
};

export default ContratoTemplateEdit;