import {
	Create,
} from "react-admin";
import { TipoContratoForm } from "./TipoContratoForm";

const TipoContratoCreate = () => {
	return (
		<Create>
			<TipoContratoForm />
		</Create>
	);
};

export default TipoContratoCreate;