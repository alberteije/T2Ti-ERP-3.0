import {
	Edit,
} from "react-admin";
import { TipoContratoForm } from "./TipoContratoForm";

const TipoContratoEdit = () => {
	return (
		<Edit>
			<TipoContratoForm />
		</Edit>
	);
};

export default TipoContratoEdit;