import TipoContratoIcon from "@mui/icons-material/Apps";
import TipoContratoList from "./TipoContratoList";
import TipoContratoCreate from "./TipoContratoCreate";
import TipoContratoEdit from "./TipoContratoEdit";

export default {
	list: TipoContratoList,
	create: TipoContratoCreate,
	edit: TipoContratoEdit,
	icon: TipoContratoIcon,
};
