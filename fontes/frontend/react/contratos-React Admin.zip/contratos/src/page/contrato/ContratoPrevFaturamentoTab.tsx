/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ContratoPrevFaturamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContratoPrevFaturamento {
		const contratoPrevFaturamento = new ContratoPrevFaturamento();
		contratoPrevFaturamento.id = Date.now();
		contratoPrevFaturamento.statusCrud = "C";
		return contratoPrevFaturamento;
	}
}

export const ContratoPrevFaturamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContratoPrevFaturamento,
		setCurrentRecord: (record: ContratoPrevFaturamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataPrevista', label: 'Data Prevista' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Previsão de Faturamento"
			recordContext="contrato"
			fieldSource="contratoPrevFaturamentoModelList"
			newObject={ ContratoPrevFaturamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};