/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ContratoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["contratoSolicitacaoServicoModel.descricao","tipoContratoModel.nome","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContratoSmallScreenList : ContratoBigScreenList;

	return (
		<List
			title="Contrato"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContratoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.contratoSolicitacaoServicoModel.descricao }
			secondaryText={ (record) => record.tipoContratoModel.nome }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const ContratoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Solicitacao Servico" source="contratoSolicitacaoServicoModel.id" reference="contrato-solicitacao-servico" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Tipo Contrato" source="tipoContratoModel.id" reference="tipo-contrato" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<TextField source="nome" label="Nome" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="dataCadastro" label="Data Cadastro" />
			<TextField source="dataInicioVigencia" label="Data Inicio Vigencia" />
			<TextField source="dataFimVigencia" label="Data Fim Vigencia" />
			<TextField source="diaFaturamento" label="Dia Faturamento" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="quantidadeParcelas" label="Quantidade Parcelas" />
			<TextField source="intervaloEntreParcelas" label="Intervalo Entre Parcelas" />
			<TextField source="classificacaoContabilConta" label="Classificacao Contabil Conta" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContratoList;
