/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ContratoForm } from "./ContratoForm";
import { transformNestedData } from "../../infra/utils";

const ContratoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ContratoForm />
		</Create>
	);
};

export default ContratoCreate;