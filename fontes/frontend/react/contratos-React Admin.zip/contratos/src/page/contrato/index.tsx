import ContratoIcon from "@mui/icons-material/Apps";
import ContratoList from "./ContratoList";
import ContratoCreate from "./ContratoCreate";
import ContratoEdit from "./ContratoEdit";

export default {
	list: ContratoList,
	create: ContratoCreate,
	edit: ContratoEdit,
	icon: ContratoIcon,
};
