/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ContratoForm } from "./ContratoForm";
import { transformNestedData } from "../../infra/utils";

const ContratoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ContratoForm />
		</Edit>
	);
};

export default ContratoEdit;