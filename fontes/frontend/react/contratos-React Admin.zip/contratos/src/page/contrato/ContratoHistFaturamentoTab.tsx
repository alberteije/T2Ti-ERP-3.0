/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ContratoHistFaturamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContratoHistFaturamento {
		const contratoHistFaturamento = new ContratoHistFaturamento();
		contratoHistFaturamento.id = Date.now();
		contratoHistFaturamento.statusCrud = "C";
		return contratoHistFaturamento;
	}
}

export const ContratoHistFaturamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContratoHistFaturamento,
		setCurrentRecord: (record: ContratoHistFaturamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'dataFatura', label: 'Data Fatura' },
		{ source: 'valor', label: 'Valor' },
	];

	return (
		<CrudChildTab
			title="Histórico de Faturamento"
			recordContext="contrato"
			fieldSource="contratoHistFaturamentoModelList"
			newObject={ ContratoHistFaturamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};