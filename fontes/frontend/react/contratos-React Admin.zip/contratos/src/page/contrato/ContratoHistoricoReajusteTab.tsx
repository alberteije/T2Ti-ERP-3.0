/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ContratoHistoricoReajuste {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ContratoHistoricoReajuste {
		const contratoHistoricoReajuste = new ContratoHistoricoReajuste();
		contratoHistoricoReajuste.id = Date.now();
		contratoHistoricoReajuste.statusCrud = "C";
		return contratoHistoricoReajuste;
	}
}

export const ContratoHistoricoReajusteTab: React.FC = () => {

	const renderForm = (
		currentRecord: ContratoHistoricoReajuste,
		setCurrentRecord: (record: ContratoHistoricoReajuste) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'indice', label: 'Indice' },
		{ source: 'valorAnterior', label: 'Valor Anterior' },
		{ source: 'valorAtual', label: 'Valor Atual' },
		{ source: 'dataReajuste', label: 'Data Reajuste' },
		{ source: 'observacao', label: 'Observacao' },
	];

	return (
		<CrudChildTab
			title="Histórico de Reajustes"
			recordContext="contrato"
			fieldSource="contratoHistoricoReajusteModelList"
			newObject={ ContratoHistoricoReajuste.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};