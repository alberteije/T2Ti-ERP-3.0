import ContratoSolicitacaoServicoIcon from "@mui/icons-material/Apps";
import ContratoSolicitacaoServicoList from "./ContratoSolicitacaoServicoList";
import ContratoSolicitacaoServicoCreate from "./ContratoSolicitacaoServicoCreate";
import ContratoSolicitacaoServicoEdit from "./ContratoSolicitacaoServicoEdit";

export default {
	list: ContratoSolicitacaoServicoList,
	create: ContratoSolicitacaoServicoCreate,
	edit: ContratoSolicitacaoServicoEdit,
	icon: ContratoSolicitacaoServicoIcon,
};
