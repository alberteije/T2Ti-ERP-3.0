import {
	Edit,
} from "react-admin";
import { ContratoSolicitacaoServicoForm } from "./ContratoSolicitacaoServicoForm";

const ContratoSolicitacaoServicoEdit = () => {
	return (
		<Edit>
			<ContratoSolicitacaoServicoForm />
		</Edit>
	);
};

export default ContratoSolicitacaoServicoEdit;