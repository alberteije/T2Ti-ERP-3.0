import {
	Create,
} from "react-admin";
import { ContratoSolicitacaoServicoForm } from "./ContratoSolicitacaoServicoForm";

const ContratoSolicitacaoServicoCreate = () => {
	return (
		<Create>
			<ContratoSolicitacaoServicoForm />
		</Create>
	);
};

export default ContratoSolicitacaoServicoCreate;