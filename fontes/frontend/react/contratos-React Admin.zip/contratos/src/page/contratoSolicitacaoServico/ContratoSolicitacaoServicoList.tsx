/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import ContratoSolicitacaoServicoDomain from '../../data/domain/ContratoSolicitacaoServicoDomain';

const ContratoSolicitacaoServicoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["contratoTipoServicoModel.nome","setorModel.nome","viewPessoaColaboradorModel.nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ContratoSolicitacaoServicoSmallScreenList : ContratoSolicitacaoServicoBigScreenList;

	return (
		<List
			title="Solicitação de Serviço"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ContratoSolicitacaoServicoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.contratoTipoServicoModel.nome }
			secondaryText={ (record) => record.setorModel.nome }
			tertiaryText={ (record) => record.viewPessoaColaboradorModel.nome }
		/>
	);
}

const ContratoSolicitacaoServicoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Contrato Tipo Servico" source="contratoTipoServicoModel.id" reference="contrato-tipo-servico" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Setor" source="setorModel.id" reference="setor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fornecedor" source="viewPessoaFornecedorModel.id" reference="view-pessoa-fornecedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="dataSolicitacao" label="Data Solicitacao" />
			<TextField source="dataDesejadaInicio" label="Data Desejada Inicio" />
			<FunctionField
				label="Urgente"
				render={record => ContratoSolicitacaoServicoDomain.getUrgente(record.urgente)}
			/>
			<FunctionField
				label="Status Solicitacao"
				render={record => ContratoSolicitacaoServicoDomain.getStatusSolicitacao(record.statusSolicitacao)}
			/>
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ContratoSolicitacaoServicoList;
