import {
	Edit,
} from "react-admin";
import { ContratoTipoServicoForm } from "./ContratoTipoServicoForm";

const ContratoTipoServicoEdit = () => {
	return (
		<Edit>
			<ContratoTipoServicoForm />
		</Edit>
	);
};

export default ContratoTipoServicoEdit;