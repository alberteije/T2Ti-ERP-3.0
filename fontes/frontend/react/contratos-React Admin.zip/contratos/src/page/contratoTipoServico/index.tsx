import ContratoTipoServicoIcon from "@mui/icons-material/Apps";
import ContratoTipoServicoList from "./ContratoTipoServicoList";
import ContratoTipoServicoCreate from "./ContratoTipoServicoCreate";
import ContratoTipoServicoEdit from "./ContratoTipoServicoEdit";

export default {
	list: ContratoTipoServicoList,
	create: ContratoTipoServicoCreate,
	edit: ContratoTipoServicoEdit,
	icon: ContratoTipoServicoIcon,
};
