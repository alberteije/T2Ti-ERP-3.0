import {
	Create,
} from "react-admin";
import { ContratoTipoServicoForm } from "./ContratoTipoServicoForm";

const ContratoTipoServicoCreate = () => {
	return (
		<Create>
			<ContratoTipoServicoForm />
		</Create>
	);
};

export default ContratoTipoServicoCreate;