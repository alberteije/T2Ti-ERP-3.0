import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import mdfeCabecalho from '../page/mdfeCabecalho';
import mdfeInformacaoCte from '../page/mdfeInformacaoCte';
import mdfeInformacaoNfe from '../page/mdfeInformacaoNfe';
import mdfeRodoviarioMotorista from '../page/mdfeRodoviarioMotorista';
import mdfeRodoviarioVeiculo from '../page/mdfeRodoviarioVeiculo';
import mdfeRodoviarioPedagio from '../page/mdfeRodoviarioPedagio';
import mdfeRodoviarioCiot from '../page/mdfeRodoviarioCiot';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/mdfe-informacao-cte'
					state={{ _scrollToTop: true }}
					primaryText='Informacão CTE'
					leftIcon={<mdfeInformacaoCte.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/mdfe-informacao-nfe'
					state={{ _scrollToTop: true }}
					primaryText='Informacao NFe'
					leftIcon={<mdfeInformacaoNfe.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/mdfe-rodoviario-motorista'
					state={{ _scrollToTop: true }}
					primaryText='Rodoviario Motorista'
					leftIcon={<mdfeRodoviarioMotorista.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/mdfe-rodoviario-veiculo'
					state={{ _scrollToTop: true }}
					primaryText='Rodoviario Veiculo'
					leftIcon={<mdfeRodoviarioVeiculo.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/mdfe-rodoviario-pedagio'
					state={{ _scrollToTop: true }}
					primaryText='Rodoviario Pedagio'
					leftIcon={<mdfeRodoviarioPedagio.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/mdfe-rodoviario-ciot'
					state={{ _scrollToTop: true }}
					primaryText='Rodoviario CIOT'
					leftIcon={<mdfeRodoviarioCiot.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/mdfe-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='MDFe'
					leftIcon={<mdfeCabecalho.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
