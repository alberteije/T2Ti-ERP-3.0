/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class MdfeInformacaoSeguro {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeInformacaoSeguro {
		const mdfeInformacaoSeguro = new MdfeInformacaoSeguro();
		mdfeInformacaoSeguro.id = Date.now();
		mdfeInformacaoSeguro.statusCrud = "C";
		return mdfeInformacaoSeguro;
	}
}

export const MdfeInformacaoSeguroTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeInformacaoSeguro,
		setCurrentRecord: (record: MdfeInformacaoSeguro) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'responsavel', label: 'Responsavel' },
		{ source: 'cnpjCpf', label: 'CNPJ/CPF', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'seguradora', label: 'Seguradora' },
		{ source: 'cnpjSeguradora', label: 'CNPJ Seguradora', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'apolice', label: 'Apolice' },
		{ source: 'averbacao', label: 'Averbacao' },
	];

	return (
		<CrudChildTab
			title="Informação Seguro"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeInformacaoSeguroModelList"
			newObject={ MdfeInformacaoSeguro.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};