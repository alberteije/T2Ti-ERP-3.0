/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class MdfeMunicipioDescarrega {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeMunicipioDescarrega {
		const mdfeMunicipioDescarrega = new MdfeMunicipioDescarrega();
		mdfeMunicipioDescarrega.id = Date.now();
		mdfeMunicipioDescarrega.statusCrud = "C";
		return mdfeMunicipioDescarrega;
	}
}

export const MdfeMunicipioDescarregaTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeMunicipioDescarrega,
		setCurrentRecord: (record: MdfeMunicipioDescarrega) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
	];

	return (
		<CrudChildTab
			title="Município Descarrega"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeMunicipioDescarregaModelList"
			newObject={ MdfeMunicipioDescarrega.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};