/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import MdfeCabecalhoDomain from '../../data/domain/MdfeCabecalhoDomain';

const MdfeCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["uf","tipoAmbiente","tipoEmitente"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeCabecalhoSmallScreenList : MdfeCabecalhoBigScreenList;

	return (
		<List
			title="MDFe"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.uf }
			secondaryText={ (record) => record.tipoAmbiente }
			tertiaryText={ (record) => record.tipoEmitente }
		/>
	);
}

const MdfeCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Uf"
				render={record => MdfeCabecalhoDomain.getUf(record.uf)}
			/>
			<FunctionField
				label="Tipo Ambiente"
				render={record => MdfeCabecalhoDomain.getTipoAmbiente(record.tipoAmbiente)}
			/>
			<FunctionField
				label="Tipo Emitente"
				render={record => MdfeCabecalhoDomain.getTipoEmitente(record.tipoEmitente)}
			/>
			<FunctionField
				label="Tipo Transportadora"
				render={record => MdfeCabecalhoDomain.getTipoTransportadora(record.tipoTransportadora)}
			/>
			<FunctionField
				label="Modelo"
				render={record => MdfeCabecalhoDomain.getModelo(record.modelo)}
			/>
			<TextField source="serie" label="Serie" />
			<TextField source="numeroMdfe" label="Numero Mdfe" />
			<TextField source="codigoNumerico" label="Codigo Numerico" />
			<TextField source="chaveAcesso" label="Chave Acesso" />
			<TextField source="digitoVerificador" label="Digito Verificador" />
			<FunctionField
				label="Modal"
				render={record => MdfeCabecalhoDomain.getModal(record.modal)}
			/>
			<TextField source="dataHoraEmissao" label="Data Hora Emissao" />
			<FunctionField
				label="Tipo Emissao"
				render={record => MdfeCabecalhoDomain.getTipoEmissao(record.tipoEmissao)}
			/>
			<FunctionField
				label="Processo Emissao"
				render={record => MdfeCabecalhoDomain.getProcessoEmissao(record.processoEmissao)}
			/>
			<TextField source="versaoProcessoEmissao" label="Versao Processo Emissao" />
			<FunctionField
				label="Uf Inicio"
				render={record => MdfeCabecalhoDomain.getUfInicio(record.ufInicio)}
			/>
			<FunctionField
				label="Uf Fim"
				render={record => MdfeCabecalhoDomain.getUfFim(record.ufFim)}
			/>
			<TextField source="dataHoraPrevisaoViagem" label="Data Hora Previsao Viagem" />
			<TextField source="quantidadeTotalCte" label="Quantidade Total Cte" />
			<TextField source="quantidadeTotalNfe" label="Quantidade Total Nfe" />
			<TextField source="quantidadeTotalMdfe" label="Quantidade Total Mdfe" />
			<FunctionField
				label="Codigo Unidade Medida"
				render={record => MdfeCabecalhoDomain.getCodigoUnidadeMedida(record.codigoUnidadeMedida)}
			/>
			<NumberField source="pesoBrutoCarga" label="Peso Bruto Carga" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCarga" label="Valor Carga" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="numeroProtocolo" label="Numero Protocolo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeCabecalhoList;
