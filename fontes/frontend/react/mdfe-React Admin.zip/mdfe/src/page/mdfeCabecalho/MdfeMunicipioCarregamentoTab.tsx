/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class MdfeMunicipioCarregamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeMunicipioCarregamento {
		const mdfeMunicipioCarregamento = new MdfeMunicipioCarregamento();
		mdfeMunicipioCarregamento.id = Date.now();
		mdfeMunicipioCarregamento.statusCrud = "C";
		return mdfeMunicipioCarregamento;
	}
}

export const MdfeMunicipioCarregamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeMunicipioCarregamento,
		setCurrentRecord: (record: MdfeMunicipioCarregamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
	];

	return (
		<CrudChildTab
			title="Município Carregamento"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeMunicipioCarregamentoModelList"
			newObject={ MdfeMunicipioCarregamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};