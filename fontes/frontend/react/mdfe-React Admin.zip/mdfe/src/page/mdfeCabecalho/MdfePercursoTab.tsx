/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import MdfePercursoDomain from '../../data/domain/MdfePercursoDomain';

class MdfePercurso {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfePercurso {
		const mdfePercurso = new MdfePercurso();
		mdfePercurso.id = Date.now();
		mdfePercurso.statusCrud = "C";
		return mdfePercurso;
	}
}

export const MdfePercursoTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfePercurso,
		setCurrentRecord: (record: MdfePercurso) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'ufPercurso', label: 'Uf Percurso', formatDomain: MdfePercursoDomain.getUfPercurso },
		{ source: 'dataInicioViagem', label: 'Data Inicio Viagem' },
	];

	return (
		<CrudChildTab
			title="Percurso"
			recordContext="mdfeCabecalho"
			fieldSource="mdfePercursoModelList"
			newObject={ MdfePercurso.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};