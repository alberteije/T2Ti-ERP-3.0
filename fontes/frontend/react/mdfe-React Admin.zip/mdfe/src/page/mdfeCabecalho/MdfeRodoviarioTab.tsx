/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class MdfeRodoviario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeRodoviario {
		const mdfeRodoviario = new MdfeRodoviario();
		mdfeRodoviario.id = Date.now();
		mdfeRodoviario.statusCrud = "C";
		return mdfeRodoviario;
	}
}

export const MdfeRodoviarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeRodoviario,
		setCurrentRecord: (record: MdfeRodoviario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'rntrc', label: 'RNTRC' },
		{ source: 'codigoAgendamento', label: 'Codigo Agendamento' },
	];

	return (
		<CrudChildTab
			title="Rodoviário"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeRodoviarioModelList"
			newObject={ MdfeRodoviario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};