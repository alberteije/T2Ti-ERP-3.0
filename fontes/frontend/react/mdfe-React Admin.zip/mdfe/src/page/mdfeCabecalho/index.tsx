import MdfeCabecalhoIcon from "@mui/icons-material/Apps";
import MdfeCabecalhoList from "./MdfeCabecalhoList";
import MdfeCabecalhoCreate from "./MdfeCabecalhoCreate";
import MdfeCabecalhoEdit from "./MdfeCabecalhoEdit";

export default {
	list: MdfeCabecalhoList,
	create: MdfeCabecalhoCreate,
	edit: MdfeCabecalhoEdit,
	icon: MdfeCabecalhoIcon,
};
