/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { MdfeLacreTab } from './MdfeLacreTab';
import { MdfeMunicipioDescarregaTab } from './MdfeMunicipioDescarregaTab';
import { MdfeEmitenteTab } from './MdfeEmitenteTab';
import { MdfePercursoTab } from './MdfePercursoTab';
import { MdfeMunicipioCarregamentoTab } from './MdfeMunicipioCarregamentoTab';
import { MdfeRodoviarioTab } from './MdfeRodoviarioTab';
import { MdfeInformacaoSeguroTab } from './MdfeInformacaoSeguroTab';

export const MdfeCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="MDFe">
				<MdfeCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Lacre">
				<MdfeLacreTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Município Descarrega">
				<MdfeMunicipioDescarregaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Emitente">
				<MdfeEmitenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Percurso">
				<MdfePercursoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Município Carregamento">
				<MdfeMunicipioCarregamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Rodoviário">
				<MdfeRodoviarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Informação Seguro">
				<MdfeInformacaoSeguroTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const MdfeCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};