/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { MdfeCabecalhoForm } from "./MdfeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const MdfeCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<MdfeCabecalhoForm />
		</Create>
	);
};

export default MdfeCabecalhoCreate;