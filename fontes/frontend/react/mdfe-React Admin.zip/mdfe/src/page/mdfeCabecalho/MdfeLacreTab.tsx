/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class MdfeLacre {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeLacre {
		const mdfeLacre = new MdfeLacre();
		mdfeLacre.id = Date.now();
		mdfeLacre.statusCrud = "C";
		return mdfeLacre;
	}
}

export const MdfeLacreTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeLacre,
		setCurrentRecord: (record: MdfeLacre) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroLacre', label: 'Numero Lacre' },
	];

	return (
		<CrudChildTab
			title="Lacre"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeLacreModelList"
			newObject={ MdfeLacre.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};