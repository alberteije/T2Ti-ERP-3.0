/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import MdfeEmitenteDomain from '../../data/domain/MdfeEmitenteDomain';

class MdfeEmitente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): MdfeEmitente {
		const mdfeEmitente = new MdfeEmitente();
		mdfeEmitente.id = Date.now();
		mdfeEmitente.statusCrud = "C";
		return mdfeEmitente;
	}
}

export const MdfeEmitenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: MdfeEmitente,
		setCurrentRecord: (record: MdfeEmitente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'ie', label: 'Ie' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'uf', label: 'Uf', formatDomain: MdfeEmitenteDomain.getUf },
		{ source: 'telefone', label: 'Telefone', formatMask: formatWithMask, mask: '(##)#####-####' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Emitente"
			recordContext="mdfeCabecalho"
			fieldSource="mdfeEmitenteModelList"
			newObject={ MdfeEmitente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};