/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import MdfeRodoviarioVeiculoDomain from '../../data/domain/MdfeRodoviarioVeiculoDomain';

const MdfeRodoviarioVeiculoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeRodoviarioModel.codigoAgendamento","codigoInterno","placa"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeRodoviarioVeiculoSmallScreenList : MdfeRodoviarioVeiculoBigScreenList;

	return (
		<List
			title="Rodoviario Veiculo"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeRodoviarioVeiculoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeRodoviarioModel.codigoAgendamento }
			secondaryText={ (record) => record.codigoInterno }
			tertiaryText={ (record) => record.placa }
		/>
	);
}

const MdfeRodoviarioVeiculoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Rodoviario" source="mdfeRodoviarioModel.id" reference="mdfe-rodoviario" sortable={false}>
				<TextField source="codigoAgendamento" />
			</ReferenceField>
			<TextField source="codigoInterno" label="Codigo Interno" />
			<TextField source="placa" label="Placa" />
			<TextField source="renavam" label="Renavam" />
			<TextField source="tara" label="Tara" />
			<TextField source="capacidadeKg" label="Capacidade Kg" />
			<TextField source="capacidadeM3" label="Capacidade M3" />
			<FunctionField
				label="Tipo Rodado"
				render={record => MdfeRodoviarioVeiculoDomain.getTipoRodado(record.tipoRodado)}
			/>
			<FunctionField
				label="Tipo Carroceria"
				render={record => MdfeRodoviarioVeiculoDomain.getTipoCarroceria(record.tipoCarroceria)}
			/>
			<FunctionField
				label="Uf Licenciamento"
				render={record => MdfeRodoviarioVeiculoDomain.getUfLicenciamento(record.ufLicenciamento)}
			/>
			<FunctionField
				source="proprietarioCpf"
				label="Proprietario Cpf"
				render={record => formatWithMask(record.proprietarioCpf, '###.###.###-##')}
			/>
			<FunctionField
				source="proprietarioCnpj"
				label="Proprietario Cnpj"
				render={record => formatWithMask(record.proprietarioCnpj, '##.###.###/####-##')}
			/>
			<TextField source="proprietarioRntrc" label="Proprietario Rntrc" />
			<TextField source="proprietarioNome" label="Proprietario Nome" />
			<TextField source="proprietarioIe" label="Proprietario Ie" />
			<TextField source="proprietarioTipo" label="Proprietario Tipo" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeRodoviarioVeiculoList;
