import {
	Create,
} from "react-admin";
import { MdfeRodoviarioVeiculoForm } from "./MdfeRodoviarioVeiculoForm";

const MdfeRodoviarioVeiculoCreate = () => {
	return (
		<Create>
			<MdfeRodoviarioVeiculoForm />
		</Create>
	);
};

export default MdfeRodoviarioVeiculoCreate;