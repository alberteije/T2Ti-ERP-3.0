import MdfeRodoviarioVeiculoIcon from "@mui/icons-material/Apps";
import MdfeRodoviarioVeiculoList from "./MdfeRodoviarioVeiculoList";
import MdfeRodoviarioVeiculoCreate from "./MdfeRodoviarioVeiculoCreate";
import MdfeRodoviarioVeiculoEdit from "./MdfeRodoviarioVeiculoEdit";

export default {
	list: MdfeRodoviarioVeiculoList,
	create: MdfeRodoviarioVeiculoCreate,
	edit: MdfeRodoviarioVeiculoEdit,
	icon: MdfeRodoviarioVeiculoIcon,
};
