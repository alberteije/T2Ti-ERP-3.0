import {
	Edit,
} from "react-admin";
import { MdfeRodoviarioVeiculoForm } from "./MdfeRodoviarioVeiculoForm";

const MdfeRodoviarioVeiculoEdit = () => {
	return (
		<Edit>
			<MdfeRodoviarioVeiculoForm />
		</Edit>
	);
};

export default MdfeRodoviarioVeiculoEdit;