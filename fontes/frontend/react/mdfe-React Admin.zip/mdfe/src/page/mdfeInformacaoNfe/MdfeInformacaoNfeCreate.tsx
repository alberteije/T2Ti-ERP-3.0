import {
	Create,
} from "react-admin";
import { MdfeInformacaoNfeForm } from "./MdfeInformacaoNfeForm";

const MdfeInformacaoNfeCreate = () => {
	return (
		<Create>
			<MdfeInformacaoNfeForm />
		</Create>
	);
};

export default MdfeInformacaoNfeCreate;