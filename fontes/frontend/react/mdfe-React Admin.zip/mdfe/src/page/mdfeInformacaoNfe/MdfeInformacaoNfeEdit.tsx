import {
	Edit,
} from "react-admin";
import { MdfeInformacaoNfeForm } from "./MdfeInformacaoNfeForm";

const MdfeInformacaoNfeEdit = () => {
	return (
		<Edit>
			<MdfeInformacaoNfeForm />
		</Edit>
	);
};

export default MdfeInformacaoNfeEdit;