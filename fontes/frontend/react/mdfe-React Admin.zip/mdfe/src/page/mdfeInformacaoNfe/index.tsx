import MdfeInformacaoNfeIcon from "@mui/icons-material/Apps";
import MdfeInformacaoNfeList from "./MdfeInformacaoNfeList";
import MdfeInformacaoNfeCreate from "./MdfeInformacaoNfeCreate";
import MdfeInformacaoNfeEdit from "./MdfeInformacaoNfeEdit";

export default {
	list: MdfeInformacaoNfeList,
	create: MdfeInformacaoNfeCreate,
	edit: MdfeInformacaoNfeEdit,
	icon: MdfeInformacaoNfeIcon,
};
