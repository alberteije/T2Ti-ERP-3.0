import {
	Create,
} from "react-admin";
import { MdfeRodoviarioPedagioForm } from "./MdfeRodoviarioPedagioForm";

const MdfeRodoviarioPedagioCreate = () => {
	return (
		<Create>
			<MdfeRodoviarioPedagioForm />
		</Create>
	);
};

export default MdfeRodoviarioPedagioCreate;