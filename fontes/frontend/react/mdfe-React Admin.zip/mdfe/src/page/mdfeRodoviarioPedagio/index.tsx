import MdfeRodoviarioPedagioIcon from "@mui/icons-material/Apps";
import MdfeRodoviarioPedagioList from "./MdfeRodoviarioPedagioList";
import MdfeRodoviarioPedagioCreate from "./MdfeRodoviarioPedagioCreate";
import MdfeRodoviarioPedagioEdit from "./MdfeRodoviarioPedagioEdit";

export default {
	list: MdfeRodoviarioPedagioList,
	create: MdfeRodoviarioPedagioCreate,
	edit: MdfeRodoviarioPedagioEdit,
	icon: MdfeRodoviarioPedagioIcon,
};
