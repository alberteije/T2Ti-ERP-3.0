/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const MdfeRodoviarioPedagioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeRodoviarioModel.codigoAgendamento","cnpjFornecedor","cnpjResponsavel"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeRodoviarioPedagioSmallScreenList : MdfeRodoviarioPedagioBigScreenList;

	return (
		<List
			title="Rodoviario Pedagio"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeRodoviarioPedagioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeRodoviarioModel.codigoAgendamento }
			secondaryText={ (record) => record.cnpjFornecedor }
			tertiaryText={ (record) => record.cnpjResponsavel }
		/>
	);
}

const MdfeRodoviarioPedagioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Rodoviario" source="mdfeRodoviarioModel.id" reference="mdfe-rodoviario" sortable={false}>
				<TextField source="codigoAgendamento" />
			</ReferenceField>
			<FunctionField
				source="cnpjFornecedor"
				label="Cnpj Fornecedor"
				render={record => formatWithMask(record.cnpjFornecedor, '##.###.###/####-##')}
			/>
			<FunctionField
				source="cnpjResponsavel"
				label="Cnpj Responsavel"
				render={record => formatWithMask(record.cnpjResponsavel, '##.###.###/####-##')}
			/>
			<FunctionField
				source="cpfResponsavel"
				label="Cpf Responsavel"
				render={record => formatWithMask(record.cpfResponsavel, '###.###.###-##')}
			/>
			<TextField source="numeroComprovante" label="Numero Comprovante" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeRodoviarioPedagioList;
