import {
	Edit,
} from "react-admin";
import { MdfeRodoviarioPedagioForm } from "./MdfeRodoviarioPedagioForm";

const MdfeRodoviarioPedagioEdit = () => {
	return (
		<Edit>
			<MdfeRodoviarioPedagioForm />
		</Edit>
	);
};

export default MdfeRodoviarioPedagioEdit;