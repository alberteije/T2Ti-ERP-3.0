import MdfeRodoviarioCiotIcon from "@mui/icons-material/Apps";
import MdfeRodoviarioCiotList from "./MdfeRodoviarioCiotList";
import MdfeRodoviarioCiotCreate from "./MdfeRodoviarioCiotCreate";
import MdfeRodoviarioCiotEdit from "./MdfeRodoviarioCiotEdit";

export default {
	list: MdfeRodoviarioCiotList,
	create: MdfeRodoviarioCiotCreate,
	edit: MdfeRodoviarioCiotEdit,
	icon: MdfeRodoviarioCiotIcon,
};
