import {
	Create,
} from "react-admin";
import { MdfeRodoviarioCiotForm } from "./MdfeRodoviarioCiotForm";

const MdfeRodoviarioCiotCreate = () => {
	return (
		<Create>
			<MdfeRodoviarioCiotForm />
		</Create>
	);
};

export default MdfeRodoviarioCiotCreate;