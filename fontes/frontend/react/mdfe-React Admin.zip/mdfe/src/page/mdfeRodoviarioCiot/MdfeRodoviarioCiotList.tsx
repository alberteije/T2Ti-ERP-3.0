/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const MdfeRodoviarioCiotList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeRodoviarioModel.codigoAgendamento","ciot","cpf"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeRodoviarioCiotSmallScreenList : MdfeRodoviarioCiotBigScreenList;

	return (
		<List
			title="Rodoviario CIOT"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeRodoviarioCiotSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeRodoviarioModel.codigoAgendamento }
			secondaryText={ (record) => record.ciot }
			tertiaryText={ (record) => record.cpf }
		/>
	);
}

const MdfeRodoviarioCiotBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Rodoviario" source="mdfeRodoviarioModel.id" reference="mdfe-rodoviario" sortable={false}>
				<TextField source="codigoAgendamento" />
			</ReferenceField>
			<TextField source="ciot" label="Ciot" />
			<FunctionField
				source="cpf"
				label="Cpf"
				render={record => formatWithMask(record.cpf, '###.###.###-##')}
			/>
			<FunctionField
				source="cnpj"
				label="Cnpj"
				render={record => formatWithMask(record.cnpj, '##.###.###/####-##')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeRodoviarioCiotList;
