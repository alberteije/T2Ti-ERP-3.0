import {
	Edit,
} from "react-admin";
import { MdfeRodoviarioCiotForm } from "./MdfeRodoviarioCiotForm";

const MdfeRodoviarioCiotEdit = () => {
	return (
		<Edit>
			<MdfeRodoviarioCiotForm />
		</Edit>
	);
};

export default MdfeRodoviarioCiotEdit;