import MdfeInformacaoCteIcon from "@mui/icons-material/Apps";
import MdfeInformacaoCteList from "./MdfeInformacaoCteList";
import MdfeInformacaoCteCreate from "./MdfeInformacaoCteCreate";
import MdfeInformacaoCteEdit from "./MdfeInformacaoCteEdit";

export default {
	list: MdfeInformacaoCteList,
	create: MdfeInformacaoCteCreate,
	edit: MdfeInformacaoCteEdit,
	icon: MdfeInformacaoCteIcon,
};
