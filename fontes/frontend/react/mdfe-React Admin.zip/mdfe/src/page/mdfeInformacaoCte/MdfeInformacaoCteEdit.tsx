import {
	Edit,
} from "react-admin";
import { MdfeInformacaoCteForm } from "./MdfeInformacaoCteForm";

const MdfeInformacaoCteEdit = () => {
	return (
		<Edit>
			<MdfeInformacaoCteForm />
		</Edit>
	);
};

export default MdfeInformacaoCteEdit;