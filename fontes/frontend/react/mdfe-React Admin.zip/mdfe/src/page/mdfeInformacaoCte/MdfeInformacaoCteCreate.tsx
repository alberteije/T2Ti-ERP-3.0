import {
	Create,
} from "react-admin";
import { MdfeInformacaoCteForm } from "./MdfeInformacaoCteForm";

const MdfeInformacaoCteCreate = () => {
	return (
		<Create>
			<MdfeInformacaoCteForm />
		</Create>
	);
};

export default MdfeInformacaoCteCreate;