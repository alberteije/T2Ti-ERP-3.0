/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const MdfeInformacaoCteList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeMunicipioDescarregaModel.nomeMunicipio","chaveCte","segundoCodigoBarra"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeInformacaoCteSmallScreenList : MdfeInformacaoCteBigScreenList;

	return (
		<List
			title="Informacão CTE"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeInformacaoCteSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeMunicipioDescarregaModel.nomeMunicipio }
			secondaryText={ (record) => record.chaveCte }
			tertiaryText={ (record) => record.segundoCodigoBarra }
		/>
	);
}

const MdfeInformacaoCteBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Municipio Descarrega" source="mdfeMunicipioDescarregaModel.id" reference="mdfe-municipio-descarrega" sortable={false}>
				<TextField source="nomeMunicipio" />
			</ReferenceField>
			<TextField source="chaveCte" label="Chave Cte" />
			<TextField source="segundoCodigoBarra" label="Segundo Codigo Barra" />
			<TextField source="indicadorReentrega" label="Indicador Reentrega" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeInformacaoCteList;
