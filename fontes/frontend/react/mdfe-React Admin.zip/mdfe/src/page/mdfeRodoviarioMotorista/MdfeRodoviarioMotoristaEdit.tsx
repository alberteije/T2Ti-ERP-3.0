import {
	Edit,
} from "react-admin";
import { MdfeRodoviarioMotoristaForm } from "./MdfeRodoviarioMotoristaForm";

const MdfeRodoviarioMotoristaEdit = () => {
	return (
		<Edit>
			<MdfeRodoviarioMotoristaForm />
		</Edit>
	);
};

export default MdfeRodoviarioMotoristaEdit;