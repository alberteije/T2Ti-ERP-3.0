/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const MdfeRodoviarioMotoristaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["mdfeRodoviarioModel.codigoAgendamento","nome","cpf"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? MdfeRodoviarioMotoristaSmallScreenList : MdfeRodoviarioMotoristaBigScreenList;

	return (
		<List
			title="Rodoviario Motorista"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const MdfeRodoviarioMotoristaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.mdfeRodoviarioModel.codigoAgendamento }
			secondaryText={ (record) => record.nome }
			tertiaryText={ (record) => record.cpf }
		/>
	);
}

const MdfeRodoviarioMotoristaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Mdfe Rodoviario" source="mdfeRodoviarioModel.id" reference="mdfe-rodoviario" sortable={false}>
				<TextField source="codigoAgendamento" />
			</ReferenceField>
			<TextField source="nome" label="Nome" />
			<FunctionField
				source="cpf"
				label="Cpf"
				render={record => formatWithMask(record.cpf, '###.###.###-##')}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default MdfeRodoviarioMotoristaList;
