import {
	Create,
} from "react-admin";
import { MdfeRodoviarioMotoristaForm } from "./MdfeRodoviarioMotoristaForm";

const MdfeRodoviarioMotoristaCreate = () => {
	return (
		<Create>
			<MdfeRodoviarioMotoristaForm />
		</Create>
	);
};

export default MdfeRodoviarioMotoristaCreate;