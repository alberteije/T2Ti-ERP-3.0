import MdfeRodoviarioMotoristaIcon from "@mui/icons-material/Apps";
import MdfeRodoviarioMotoristaList from "./MdfeRodoviarioMotoristaList";
import MdfeRodoviarioMotoristaCreate from "./MdfeRodoviarioMotoristaCreate";
import MdfeRodoviarioMotoristaEdit from "./MdfeRodoviarioMotoristaEdit";

export default {
	list: MdfeRodoviarioMotoristaList,
	create: MdfeRodoviarioMotoristaCreate,
	edit: MdfeRodoviarioMotoristaEdit,
	icon: MdfeRodoviarioMotoristaIcon,
};
