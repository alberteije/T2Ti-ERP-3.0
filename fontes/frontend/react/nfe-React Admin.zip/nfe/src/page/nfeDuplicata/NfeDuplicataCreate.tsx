import {
	Create,
} from "react-admin";
import { NfeDuplicataForm } from "./NfeDuplicataForm";

const NfeDuplicataCreate = () => {
	return (
		<Create>
			<NfeDuplicataForm />
		</Create>
	);
};

export default NfeDuplicataCreate;