import NfeDuplicataIcon from "@mui/icons-material/Apps";
import NfeDuplicataList from "./NfeDuplicataList";
import NfeDuplicataCreate from "./NfeDuplicataCreate";
import NfeDuplicataEdit from "./NfeDuplicataEdit";

export default {
	list: NfeDuplicataList,
	create: NfeDuplicataCreate,
	edit: NfeDuplicataEdit,
	icon: NfeDuplicataIcon,
};
