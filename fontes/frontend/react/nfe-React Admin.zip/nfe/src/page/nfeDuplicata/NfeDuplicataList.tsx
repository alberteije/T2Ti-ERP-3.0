/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeDuplicataList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeFaturaModel.numero","numero","dataVencimento"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeDuplicataSmallScreenList : NfeDuplicataBigScreenList;

	return (
		<List
			title="Duplicata"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeDuplicataSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeFaturaModel.numero }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record.dataVencimento }
		/>
	);
}

const NfeDuplicataBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Fatura" source="nfeFaturaModel.id" reference="nfe-fatura" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<TextField source="dataVencimento" label="Data Vencimento" />
			<NumberField source="valor" label="Valor" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeDuplicataList;
