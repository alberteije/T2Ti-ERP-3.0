import {
	Edit,
} from "react-admin";
import { NfeDuplicataForm } from "./NfeDuplicataForm";

const NfeDuplicataEdit = () => {
	return (
		<Edit>
			<NfeDuplicataForm />
		</Edit>
	);
};

export default NfeDuplicataEdit;