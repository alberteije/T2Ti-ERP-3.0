import NfeTransporteVolumeIcon from "@mui/icons-material/Apps";
import NfeTransporteVolumeList from "./NfeTransporteVolumeList";
import NfeTransporteVolumeCreate from "./NfeTransporteVolumeCreate";
import NfeTransporteVolumeEdit from "./NfeTransporteVolumeEdit";

export default {
	list: NfeTransporteVolumeList,
	create: NfeTransporteVolumeCreate,
	edit: NfeTransporteVolumeEdit,
	icon: NfeTransporteVolumeIcon,
};
