/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeTransporteVolumeList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeTransporteModel.cnpj","quantidade","especie"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeTransporteVolumeSmallScreenList : NfeTransporteVolumeBigScreenList;

	return (
		<List
			title="Nfe Transporte Volume"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeTransporteVolumeSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeTransporteModel.cnpj }
			secondaryText={ (record) => record.quantidade }
			tertiaryText={ (record) => record.especie }
		/>
	);
}

const NfeTransporteVolumeBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Transporte" source="nfeTransporteModel.id" reference="nfe-transporte" sortable={false}>
				<TextField source="cnpj" />
			</ReferenceField>
			<TextField source="quantidade" label="Quantidade" />
			<TextField source="especie" label="Especie" />
			<TextField source="marca" label="Marca" />
			<TextField source="numeracao" label="Numeracao" />
			<NumberField source="pesoLiquido" label="Peso Liquido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="pesoBruto" label="Peso Bruto" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeTransporteVolumeList;
