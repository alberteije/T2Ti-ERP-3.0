import {
	Edit,
} from "react-admin";
import { NfeTransporteVolumeForm } from "./NfeTransporteVolumeForm";

const NfeTransporteVolumeEdit = () => {
	return (
		<Edit>
			<NfeTransporteVolumeForm />
		</Edit>
	);
};

export default NfeTransporteVolumeEdit;