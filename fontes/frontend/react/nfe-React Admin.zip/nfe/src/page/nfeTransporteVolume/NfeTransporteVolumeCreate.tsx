import {
	Create,
} from "react-admin";
import { NfeTransporteVolumeForm } from "./NfeTransporteVolumeForm";

const NfeTransporteVolumeCreate = () => {
	return (
		<Create>
			<NfeTransporteVolumeForm />
		</Create>
	);
};

export default NfeTransporteVolumeCreate;