import NfeTransporteReboqueIcon from "@mui/icons-material/Apps";
import NfeTransporteReboqueList from "./NfeTransporteReboqueList";
import NfeTransporteReboqueCreate from "./NfeTransporteReboqueCreate";
import NfeTransporteReboqueEdit from "./NfeTransporteReboqueEdit";

export default {
	list: NfeTransporteReboqueList,
	create: NfeTransporteReboqueCreate,
	edit: NfeTransporteReboqueEdit,
	icon: NfeTransporteReboqueIcon,
};
