import {
	Edit,
} from "react-admin";
import { NfeTransporteReboqueForm } from "./NfeTransporteReboqueForm";

const NfeTransporteReboqueEdit = () => {
	return (
		<Edit>
			<NfeTransporteReboqueForm />
		</Edit>
	);
};

export default NfeTransporteReboqueEdit;