import {
	Create,
} from "react-admin";
import { NfeTransporteReboqueForm } from "./NfeTransporteReboqueForm";

const NfeTransporteReboqueCreate = () => {
	return (
		<Create>
			<NfeTransporteReboqueForm />
		</Create>
	);
};

export default NfeTransporteReboqueCreate;