/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import NfeTransporteReboqueDomain from '../../data/domain/NfeTransporteReboqueDomain';

const NfeTransporteReboqueList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeTransporteModel.cnpj","placa","uf"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeTransporteReboqueSmallScreenList : NfeTransporteReboqueBigScreenList;

	return (
		<List
			title="Nfe Transporte Reboque"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeTransporteReboqueSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeTransporteModel.cnpj }
			secondaryText={ (record) => record.placa }
			tertiaryText={ (record) => record.uf }
		/>
	);
}

const NfeTransporteReboqueBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Transporte" source="nfeTransporteModel.id" reference="nfe-transporte" sortable={false}>
				<TextField source="cnpj" />
			</ReferenceField>
			<TextField source="placa" label="Placa" />
			<FunctionField
				label="Uf"
				render={record => NfeTransporteReboqueDomain.getUf(record.uf)}
			/>
			<TextField source="rntc" label="Rntc" />
			<TextField source="vagao" label="Vagao" />
			<TextField source="balsa" label="Balsa" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeTransporteReboqueList;
