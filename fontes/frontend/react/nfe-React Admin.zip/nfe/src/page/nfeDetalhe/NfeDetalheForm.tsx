/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { NfeDetEspecificoVeiculoTab } from './NfeDetEspecificoVeiculoTab';
import { NfeDetEspecificoMedicamentoTab } from './NfeDetEspecificoMedicamentoTab';
import { NfeDetEspecificoArmamentoTab } from './NfeDetEspecificoArmamentoTab';
import { NfeDetEspecificoCombustivelTab } from './NfeDetEspecificoCombustivelTab';
import { NfeDeclaracaoImportacaoTab } from './NfeDeclaracaoImportacaoTab';
import { NfeDetalheImpostoIcmsTab } from './NfeDetalheImpostoIcmsTab';
import { NfeDetalheImpostoIpiTab } from './NfeDetalheImpostoIpiTab';
import { NfeDetalheImpostoIiTab } from './NfeDetalheImpostoIiTab';
import { NfeDetalheImpostoPisTab } from './NfeDetalheImpostoPisTab';
import { NfeDetalheImpostoCofinsTab } from './NfeDetalheImpostoCofinsTab';
import { NfeDetalheImpostoIssqnTab } from './NfeDetalheImpostoIssqnTab';
import { NfeExportacaoTab } from './NfeExportacaoTab';
import { NfeItemRastreadoTab } from './NfeItemRastreadoTab';
import { NfeDetalheImpostoPisStTab } from './NfeDetalheImpostoPisStTab';
import { NfeDetalheImpostoIcmsUfdestTab } from './NfeDetalheImpostoIcmsUfdestTab';
import { NfeDetalheImpostoCofinsStTab } from './NfeDetalheImpostoCofinsStTab';

export const NfeDetalheForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Itens da Nota">
				<NfeDetalheTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Veículo">
				<NfeDetEspecificoVeiculoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Medicamento">
				<NfeDetEspecificoMedicamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Armamento">
				<NfeDetEspecificoArmamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Combustível">
				<NfeDetEspecificoCombustivelTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Declaração Importação">
				<NfeDeclaracaoImportacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="ICMS">
				<NfeDetalheImpostoIcmsTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="IPI">
				<NfeDetalheImpostoIpiTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Imposto Importação">
				<NfeDetalheImpostoIiTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="PIS">
				<NfeDetalheImpostoPisTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="COFINS">
				<NfeDetalheImpostoCofinsTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="ISSQN">
				<NfeDetalheImpostoIssqnTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Exportacao">
				<NfeExportacaoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Item Rastreado">
				<NfeItemRastreadoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="PIS ST">
				<NfeDetalheImpostoPisStTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="ICMS UF Destinatário">
				<NfeDetalheImpostoIcmsUfdestTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="COFINS ST">
				<NfeDetalheImpostoCofinsStTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const NfeDetalheTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};