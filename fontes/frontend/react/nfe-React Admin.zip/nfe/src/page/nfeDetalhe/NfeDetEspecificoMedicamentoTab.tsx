/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeDetEspecificoMedicamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetEspecificoMedicamento {
		const nfeDetEspecificoMedicamento = new NfeDetEspecificoMedicamento();
		nfeDetEspecificoMedicamento.id = Date.now();
		nfeDetEspecificoMedicamento.statusCrud = "C";
		return nfeDetEspecificoMedicamento;
	}
}

export const NfeDetEspecificoMedicamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetEspecificoMedicamento,
		setCurrentRecord: (record: NfeDetEspecificoMedicamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoAnvisa', label: 'Codigo Anvisa' },
		{ source: 'motivoIsencao', label: 'Motivo Isencao' },
		{ source: 'precoMaximoConsumidor', label: 'Preco Maximo Consumidor' },
	];

	return (
		<CrudChildTab
			title="Medicamento"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetEspecificoMedicamentoModelList"
			newObject={ NfeDetEspecificoMedicamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};