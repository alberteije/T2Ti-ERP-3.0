/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeDetalheImpostoPisSt {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoPisSt {
		const nfeDetalheImpostoPisSt = new NfeDetalheImpostoPisSt();
		nfeDetalheImpostoPisSt.id = Date.now();
		nfeDetalheImpostoPisSt.statusCrud = "C";
		return nfeDetalheImpostoPisSt;
	}
}

export const NfeDetalheImpostoPisStTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoPisSt,
		setCurrentRecord: (record: NfeDetalheImpostoPisSt) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'valorBaseCalculoPisSt', label: 'Valor Base Calculo Pis St' },
		{ source: 'aliquotaPisStPercentual', label: 'Aliquota Pis St Percentual' },
		{ source: 'quantidadeVendidaPisSt', label: 'Quantidade Vendida Pis St' },
		{ source: 'aliquotaPisStReais', label: 'Aliquota Pis St Reais' },
		{ source: 'valorPisSt', label: 'Valor Pis St' },
	];

	return (
		<CrudChildTab
			title="PIS ST"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoPisStModelList"
			newObject={ NfeDetalheImpostoPisSt.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};