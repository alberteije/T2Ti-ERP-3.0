/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetalheImpostoCofinsDomain from '../../data/domain/NfeDetalheImpostoCofinsDomain';

class NfeDetalheImpostoCofins {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoCofins {
		const nfeDetalheImpostoCofins = new NfeDetalheImpostoCofins();
		nfeDetalheImpostoCofins.id = Date.now();
		nfeDetalheImpostoCofins.statusCrud = "C";
		return nfeDetalheImpostoCofins;
	}
}

export const NfeDetalheImpostoCofinsTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoCofins,
		setCurrentRecord: (record: NfeDetalheImpostoCofins) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cstCofins', label: 'Cst Cofins', formatDomain: NfeDetalheImpostoCofinsDomain.getCstCofins },
		{ source: 'baseCalculoCofins', label: 'Base Calculo Cofins' },
		{ source: 'aliquotaCofinsPercentual', label: 'Aliquota Cofins Percentual' },
		{ source: 'quantidadeVendida', label: 'Quantidade Vendida' },
		{ source: 'aliquotaCofinsReais', label: 'Aliquota Cofins Reais' },
		{ source: 'valorCofins', label: 'Valor Cofins' },
	];

	return (
		<CrudChildTab
			title="COFINS"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoCofinsModelList"
			newObject={ NfeDetalheImpostoCofins.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};