/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeExportacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeExportacao {
		const nfeExportacao = new NfeExportacao();
		nfeExportacao.id = Date.now();
		nfeExportacao.statusCrud = "C";
		return nfeExportacao;
	}
}

export const NfeExportacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeExportacao,
		setCurrentRecord: (record: NfeExportacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'drawback', label: 'Drawback' },
		{ source: 'numeroRegistro', label: 'Numero Registro' },
		{ source: 'chaveAcesso', label: 'Chave Acesso' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Exportacao"
			recordContext="nfeDetalhe"
			fieldSource="nfeExportacaoModelList"
			newObject={ NfeExportacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};