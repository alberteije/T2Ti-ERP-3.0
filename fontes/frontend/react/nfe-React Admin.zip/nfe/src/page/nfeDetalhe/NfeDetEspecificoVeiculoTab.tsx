/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetEspecificoVeiculoDomain from '../../data/domain/NfeDetEspecificoVeiculoDomain';

class NfeDetEspecificoVeiculo {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetEspecificoVeiculo {
		const nfeDetEspecificoVeiculo = new NfeDetEspecificoVeiculo();
		nfeDetEspecificoVeiculo.id = Date.now();
		nfeDetEspecificoVeiculo.statusCrud = "C";
		return nfeDetEspecificoVeiculo;
	}
}

export const NfeDetEspecificoVeiculoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetEspecificoVeiculo,
		setCurrentRecord: (record: NfeDetEspecificoVeiculo) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tipoOperacao', label: 'Tipo Operacao', formatDomain: NfeDetEspecificoVeiculoDomain.getTipoOperacao },
		{ source: 'chassi', label: 'Chassi' },
		{ source: 'cor', label: 'Cor' },
		{ source: 'descricaoCor', label: 'Descricao Cor' },
		{ source: 'potenciaMotor', label: 'Potencia Motor' },
		{ source: 'cilindradas', label: 'Cilindradas' },
		{ source: 'pesoLiquido', label: 'Peso Liquido' },
		{ source: 'pesoBruto', label: 'Peso Bruto' },
		{ source: 'numeroSerie', label: 'Numero Serie' },
		{ source: 'tipoCombustivel', label: 'Tipo Combustivel', formatDomain: NfeDetEspecificoVeiculoDomain.getTipoCombustivel },
		{ source: 'numeroMotor', label: 'Numero Motor' },
		{ source: 'capacidadeMaximaTracao', label: 'Capacidade Maxima Tracao' },
		{ source: 'distanciaEixos', label: 'Distancia Eixos' },
		{ source: 'anoModelo', label: 'Ano Modelo', formatDomain: NfeDetEspecificoVeiculoDomain.getAnoModelo },
		{ source: 'anoFabricacao', label: 'Ano Fabricacao', formatDomain: NfeDetEspecificoVeiculoDomain.getAnoFabricacao },
		{ source: 'tipoPintura', label: 'Tipo Pintura', formatDomain: NfeDetEspecificoVeiculoDomain.getTipoPintura },
		{ source: 'tipoVeiculo', label: 'Tipo Veiculo', formatDomain: NfeDetEspecificoVeiculoDomain.getTipoVeiculo },
		{ source: 'especieVeiculo', label: 'Especie Veiculo', formatDomain: NfeDetEspecificoVeiculoDomain.getEspecieVeiculo },
		{ source: 'condicaoVin', label: 'Condicao Vin', formatDomain: NfeDetEspecificoVeiculoDomain.getCondicaoVin },
		{ source: 'condicaoVeiculo', label: 'Condicao Veiculo', formatDomain: NfeDetEspecificoVeiculoDomain.getCondicaoVeiculo },
		{ source: 'codigoMarcaModelo', label: 'Codigo Marca Modelo' },
		{ source: 'codigoCorDenatran', label: 'Codigo Cor Denatran', formatDomain: NfeDetEspecificoVeiculoDomain.getCodigoCorDenatran },
		{ source: 'lotacaoMaxima', label: 'Lotacao Maxima' },
		{ source: 'restricao', label: 'Restricao', formatDomain: NfeDetEspecificoVeiculoDomain.getRestricao },
	];

	return (
		<CrudChildTab
			title="Veículo"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetEspecificoVeiculoModelList"
			newObject={ NfeDetEspecificoVeiculo.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};