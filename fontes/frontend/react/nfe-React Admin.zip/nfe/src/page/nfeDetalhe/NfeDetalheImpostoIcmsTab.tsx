/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetalheImpostoIcmsDomain from '../../data/domain/NfeDetalheImpostoIcmsDomain';

class NfeDetalheImpostoIcms {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoIcms {
		const nfeDetalheImpostoIcms = new NfeDetalheImpostoIcms();
		nfeDetalheImpostoIcms.id = Date.now();
		nfeDetalheImpostoIcms.statusCrud = "C";
		return nfeDetalheImpostoIcms;
	}
}

export const NfeDetalheImpostoIcmsTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoIcms,
		setCurrentRecord: (record: NfeDetalheImpostoIcms) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'origemMercadoria', label: 'Origem Mercadoria', formatDomain: NfeDetalheImpostoIcmsDomain.getOrigemMercadoria },
		{ source: 'cstIcms', label: 'Cst Icms', formatDomain: NfeDetalheImpostoIcmsDomain.getCstIcms },
		{ source: 'csosn', label: 'Csosn', formatDomain: NfeDetalheImpostoIcmsDomain.getCsosn },
		{ source: 'modalidadeBcIcms', label: 'Modalidade Bc Icms', formatDomain: NfeDetalheImpostoIcmsDomain.getModalidadeBcIcms },
		{ source: 'percentualReducaoBcIcms', label: 'Percentual Reducao Bc Icms' },
		{ source: 'valorBcIcms', label: 'Valor Bc Icms' },
		{ source: 'aliquotaIcms', label: 'Aliquota Icms' },
		{ source: 'valorIcmsOperacao', label: 'Valor Icms Operacao' },
		{ source: 'percentualDiferimento', label: 'Percentual Diferimento' },
		{ source: 'valorIcmsDiferido', label: 'Valor Icms Diferido' },
		{ source: 'valorIcms', label: 'Valor Icms' },
		{ source: 'baseCalculoFcp', label: 'Base Calculo Fcp' },
		{ source: 'percentualFcp', label: 'Percentual Fcp' },
		{ source: 'valorFcp', label: 'Valor Fcp' },
		{ source: 'modalidadeBcIcmsSt', label: 'Modalidade Bc Icms St', formatDomain: NfeDetalheImpostoIcmsDomain.getModalidadeBcIcmsSt },
		{ source: 'percentualMvaIcmsSt', label: 'Percentual Mva Icms St' },
		{ source: 'percentualReducaoBcIcmsSt', label: 'Percentual Reducao Bc Icms St' },
		{ source: 'valorBaseCalculoIcmsSt', label: 'Valor Base Calculo Icms St' },
		{ source: 'aliquotaIcmsSt', label: 'Aliquota Icms St' },
		{ source: 'valorIcmsSt', label: 'Valor Icms St' },
		{ source: 'baseCalculoFcpSt', label: 'Base Calculo Fcp St' },
		{ source: 'percentualFcpSt', label: 'Percentual Fcp St' },
		{ source: 'valorFcpSt', label: 'Valor Fcp St' },
		{ source: 'ufSt', label: 'Uf St', formatDomain: NfeDetalheImpostoIcmsDomain.getUfSt },
		{ source: 'percentualBcOperacaoPropria', label: 'Percentual Bc Operacao Propria' },
		{ source: 'valorBcIcmsStRetido', label: 'Valor Bc Icms St Retido' },
		{ source: 'aliquotaSuportadaConsumidor', label: 'Aliquota Suportada Consumidor' },
		{ source: 'valorIcmsSubstituto', label: 'Valor Icms Substituto' },
		{ source: 'valorIcmsStRetido', label: 'Valor Icms St Retido' },
		{ source: 'baseCalculoFcpStRetido', label: 'Base Calculo Fcp St Retido' },
		{ source: 'percentualFcpStRetido', label: 'Percentual Fcp St Retido' },
		{ source: 'valorFcpStRetido', label: 'Valor Fcp St Retido' },
		{ source: 'motivoDesoneracaoIcms', label: 'Motivo Desoneracao Icms', formatDomain: NfeDetalheImpostoIcmsDomain.getMotivoDesoneracaoIcms },
		{ source: 'valorIcmsDesonerado', label: 'Valor Icms Desonerado' },
		{ source: 'aliquotaCreditoIcmsSn', label: 'Aliquota Credito Icms Sn' },
		{ source: 'valorCreditoIcmsSn', label: 'Valor Credito Icms Sn' },
		{ source: 'valorBcIcmsStDestino', label: 'Valor Bc Icms St Destino' },
		{ source: 'valorIcmsStDestino', label: 'Valor Icms St Destino' },
		{ source: 'percentualReducaoBcEfetivo', label: 'Percentual Reducao Bc Efetivo' },
		{ source: 'valorBcEfetivo', label: 'Valor Bc Efetivo' },
		{ source: 'aliquotaIcmsEfetivo', label: 'Aliquota Icms Efetivo' },
		{ source: 'valorIcmsEfetivo', label: 'Valor Icms Efetivo' },
	];

	return (
		<CrudChildTab
			title="ICMS"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoIcmsModelList"
			newObject={ NfeDetalheImpostoIcms.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};