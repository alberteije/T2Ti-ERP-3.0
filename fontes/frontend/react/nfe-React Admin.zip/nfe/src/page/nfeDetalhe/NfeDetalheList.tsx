/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import NfeDetalheDomain from '../../data/domain/NfeDetalheDomain';

const NfeDetalheList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeCabecalhoModel.numero","produtoModel.nome","numeroItem"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeDetalheSmallScreenList : NfeDetalheBigScreenList;

	return (
		<List
			title="Itens da Nota"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeDetalheSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeCabecalhoModel.numero }
			secondaryText={ (record) => record.produtoModel.nome }
			tertiaryText={ (record) => record.numeroItem }
		/>
	);
}

const NfeDetalheBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Cabecalho" source="nfeCabecalhoModel.id" reference="nfe-cabecalho" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<ReferenceField label="Id Produto" source="produtoModel.id" reference="produto" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="numeroItem" label="Numero Item" />
			<TextField source="codigoProduto" label="Codigo Produto" />
			<TextField source="gtin" label="Gtin" />
			<TextField source="nomeProduto" label="Nome Produto" />
			<TextField source="ncm" label="Ncm" />
			<TextField source="nve" label="Nve" />
			<TextField source="cest" label="Cest" />
			<FunctionField
				label="Indicador Escala Relevante"
				render={record => NfeDetalheDomain.getIndicadorEscalaRelevante(record.indicadorEscalaRelevante)}
			/>
			<FunctionField
				source="cnpjFabricante"
				label="Cnpj Fabricante"
				render={record => formatWithMask(record.cnpjFabricante, '##.###.###/####-##')}
			/>
			<TextField source="codigoBeneficioFiscal" label="Codigo Beneficio Fiscal" />
			<TextField source="exTipi" label="Ex Tipi" />
			<TextField source="cfop" label="Cfop" />
			<TextField source="unidadeComercial" label="Unidade Comercial" />
			<NumberField source="quantidadeComercial" label="Quantidade Comercial" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="numeroPedidoCompra" label="Numero Pedido Compra" />
			<TextField source="itemPedidoCompra" label="Item Pedido Compra" />
			<TextField source="numeroFci" label="Numero Fci" />
			<TextField source="numeroRecopi" label="Numero Recopi" />
			<NumberField source="valorUnitarioComercial" label="Valor Unitario Comercial" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorBrutoProduto" label="Valor Bruto Produto" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="gtinUnidadeTributavel" label="Gtin Unidade Tributavel" />
			<TextField source="unidadeTributavel" label="Unidade Tributavel" />
			<NumberField source="quantidadeTributavel" label="Quantidade Tributavel" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorUnitarioTributavel" label="Valor Unitario Tributavel" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorFrete" label="Valor Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSeguro" label="Valor Seguro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorOutrasDespesas" label="Valor Outras Despesas" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Entra Total"
				render={record => NfeDetalheDomain.getEntraTotal(record.entraTotal)}
			/>
			<NumberField source="valorTotalTributos" label="Valor Total Tributos" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="percentualDevolvido" label="Percentual Devolvido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIpiDevolvido" label="Valor Ipi Devolvido" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="informacoesAdicionais" label="Informacoes Adicionais" />
			<NumberField source="valorSubtotal" label="Valor Subtotal" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeDetalheList;
