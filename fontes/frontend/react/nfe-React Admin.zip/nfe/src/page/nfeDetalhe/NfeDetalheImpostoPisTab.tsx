/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetalheImpostoPisDomain from '../../data/domain/NfeDetalheImpostoPisDomain';

class NfeDetalheImpostoPis {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoPis {
		const nfeDetalheImpostoPis = new NfeDetalheImpostoPis();
		nfeDetalheImpostoPis.id = Date.now();
		nfeDetalheImpostoPis.statusCrud = "C";
		return nfeDetalheImpostoPis;
	}
}

export const NfeDetalheImpostoPisTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoPis,
		setCurrentRecord: (record: NfeDetalheImpostoPis) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cstPis', label: 'Cst Pis', formatDomain: NfeDetalheImpostoPisDomain.getCstPis },
		{ source: 'valorBaseCalculoPis', label: 'Valor Base Calculo Pis' },
		{ source: 'aliquotaPisPercentual', label: 'Aliquota Pis Percentual' },
		{ source: 'valorPis', label: 'Valor Pis' },
		{ source: 'quantidadeVendida', label: 'Quantidade Vendida' },
		{ source: 'aliquotaPisReais', label: 'Aliquota Pis Reais' },
	];

	return (
		<CrudChildTab
			title="PIS"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoPisModelList"
			newObject={ NfeDetalheImpostoPis.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};