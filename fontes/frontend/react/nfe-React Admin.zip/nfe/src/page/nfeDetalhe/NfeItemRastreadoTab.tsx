/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeItemRastreado {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeItemRastreado {
		const nfeItemRastreado = new NfeItemRastreado();
		nfeItemRastreado.id = Date.now();
		nfeItemRastreado.statusCrud = "C";
		return nfeItemRastreado;
	}
}

export const NfeItemRastreadoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeItemRastreado,
		setCurrentRecord: (record: NfeItemRastreado) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroLote', label: 'Numero Lote' },
		{ source: 'quantidadeItens', label: 'Quantidade Itens' },
		{ source: 'dataFabricacao', label: 'Data Fabricacao' },
		{ source: 'dataValidade', label: 'Data Validade' },
		{ source: 'codigoAgregacao', label: 'Codigo Agregacao' },
	];

	return (
		<CrudChildTab
			title="Item Rastreado"
			recordContext="nfeDetalhe"
			fieldSource="nfeItemRastreadoModelList"
			newObject={ NfeItemRastreado.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};