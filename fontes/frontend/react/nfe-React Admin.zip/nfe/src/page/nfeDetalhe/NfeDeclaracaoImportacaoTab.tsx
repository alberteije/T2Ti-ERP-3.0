/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDeclaracaoImportacaoDomain from '../../data/domain/NfeDeclaracaoImportacaoDomain';

class NfeDeclaracaoImportacao {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDeclaracaoImportacao {
		const nfeDeclaracaoImportacao = new NfeDeclaracaoImportacao();
		nfeDeclaracaoImportacao.id = Date.now();
		nfeDeclaracaoImportacao.statusCrud = "C";
		return nfeDeclaracaoImportacao;
	}
}

export const NfeDeclaracaoImportacaoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDeclaracaoImportacao,
		setCurrentRecord: (record: NfeDeclaracaoImportacao) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numeroDocumento', label: 'Numero Documento' },
		{ source: 'dataRegistro', label: 'Data Registro' },
		{ source: 'localDesembaraco', label: 'Local Desembaraco' },
		{ source: 'ufDesembaraco', label: 'Uf Desembaraco', formatDomain: NfeDeclaracaoImportacaoDomain.getUfDesembaraco },
		{ source: 'dataDesembaraco', label: 'Data Desembaraco' },
		{ source: 'viaTransporte', label: 'Via Transporte', formatDomain: NfeDeclaracaoImportacaoDomain.getViaTransporte },
		{ source: 'valorAfrmm', label: 'Valor Afrmm' },
		{ source: 'formaIntermediacao', label: 'Forma Intermediacao', formatDomain: NfeDeclaracaoImportacaoDomain.getFormaIntermediacao },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'ufTerceiro', label: 'Uf Terceiro', formatDomain: NfeDeclaracaoImportacaoDomain.getUfTerceiro },
		{ source: 'codigoExportador', label: 'Codigo Exportador' },
	];

	return (
		<CrudChildTab
			title="Declaração Importação"
			recordContext="nfeDetalhe"
			fieldSource="nfeDeclaracaoImportacaoModelList"
			newObject={ NfeDeclaracaoImportacao.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};