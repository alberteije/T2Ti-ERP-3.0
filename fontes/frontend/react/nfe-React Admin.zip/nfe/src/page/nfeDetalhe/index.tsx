import NfeDetalheIcon from "@mui/icons-material/Apps";
import NfeDetalheList from "./NfeDetalheList";
import NfeDetalheCreate from "./NfeDetalheCreate";
import NfeDetalheEdit from "./NfeDetalheEdit";

export default {
	list: NfeDetalheList,
	create: NfeDetalheCreate,
	edit: NfeDetalheEdit,
	icon: NfeDetalheIcon,
};
