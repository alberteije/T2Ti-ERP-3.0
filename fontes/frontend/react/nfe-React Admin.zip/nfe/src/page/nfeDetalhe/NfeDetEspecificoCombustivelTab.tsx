/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetEspecificoCombustivelDomain from '../../data/domain/NfeDetEspecificoCombustivelDomain';

class NfeDetEspecificoCombustivel {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetEspecificoCombustivel {
		const nfeDetEspecificoCombustivel = new NfeDetEspecificoCombustivel();
		nfeDetEspecificoCombustivel.id = Date.now();
		nfeDetEspecificoCombustivel.statusCrud = "C";
		return nfeDetEspecificoCombustivel;
	}
}

export const NfeDetEspecificoCombustivelTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetEspecificoCombustivel,
		setCurrentRecord: (record: NfeDetEspecificoCombustivel) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoAnp', label: 'Codigo Anp' },
		{ source: 'descricaoAnp', label: 'Descricao Anp' },
		{ source: 'percentualGlp', label: 'Percentual Glp' },
		{ source: 'percentualGasNacional', label: 'Percentual Gas Nacional' },
		{ source: 'percentualGasImportado', label: 'Percentual Gas Importado' },
		{ source: 'valorPartida', label: 'Valor Partida' },
		{ source: 'codif', label: 'Codif' },
		{ source: 'quantidadeTempAmbiente', label: 'Quantidade Temp Ambiente' },
		{ source: 'ufConsumo', label: 'Uf Consumo', formatDomain: NfeDetEspecificoCombustivelDomain.getUfConsumo },
		{ source: 'cideBaseCalculo', label: 'Cide Base Calculo' },
		{ source: 'cideAliquota', label: 'Cide Aliquota' },
		{ source: 'cideValor', label: 'Cide Valor' },
		{ source: 'encerranteBico', label: 'Encerrante Bico' },
		{ source: 'encerranteBomba', label: 'Encerrante Bomba' },
		{ source: 'encerranteTanque', label: 'Encerrante Tanque' },
		{ source: 'encerranteValorInicio', label: 'Encerrante Valor Inicio' },
		{ source: 'encerranteValorFim', label: 'Encerrante Valor Fim' },
	];

	return (
		<CrudChildTab
			title="Combustível"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetEspecificoCombustivelModelList"
			newObject={ NfeDetEspecificoCombustivel.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};