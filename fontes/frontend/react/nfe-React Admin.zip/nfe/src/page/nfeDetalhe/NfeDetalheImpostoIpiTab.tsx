/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetalheImpostoIpiDomain from '../../data/domain/NfeDetalheImpostoIpiDomain';

class NfeDetalheImpostoIpi {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoIpi {
		const nfeDetalheImpostoIpi = new NfeDetalheImpostoIpi();
		nfeDetalheImpostoIpi.id = Date.now();
		nfeDetalheImpostoIpi.statusCrud = "C";
		return nfeDetalheImpostoIpi;
	}
}

export const NfeDetalheImpostoIpiTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoIpi,
		setCurrentRecord: (record: NfeDetalheImpostoIpi) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpjProdutor', label: 'Cnpj Produtor', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'codigoSeloIpi', label: 'Codigo Selo Ipi' },
		{ source: 'quantidadeSeloIpi', label: 'Quantidade Selo Ipi' },
		{ source: 'enquadramentoLegalIpi', label: 'Enquadramento Legal Ipi', formatDomain: NfeDetalheImpostoIpiDomain.getEnquadramentoLegalIpi },
		{ source: 'cstIpi', label: 'Cst Ipi', formatDomain: NfeDetalheImpostoIpiDomain.getCstIpi },
		{ source: 'valorBaseCalculoIpi', label: 'Valor Base Calculo Ipi' },
		{ source: 'quantidadeUnidadeTributavel', label: 'Quantidade Unidade Tributavel' },
		{ source: 'valorUnidadeTributavel', label: 'Valor Unidade Tributavel' },
		{ source: 'aliquotaIpi', label: 'Aliquota Ipi' },
		{ source: 'valorIpi', label: 'Valor Ipi' },
	];

	return (
		<CrudChildTab
			title="IPI"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoIpiModelList"
			newObject={ NfeDetalheImpostoIpi.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};