/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeDetalheImpostoIi {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoIi {
		const nfeDetalheImpostoIi = new NfeDetalheImpostoIi();
		nfeDetalheImpostoIi.id = Date.now();
		nfeDetalheImpostoIi.statusCrud = "C";
		return nfeDetalheImpostoIi;
	}
}

export const NfeDetalheImpostoIiTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoIi,
		setCurrentRecord: (record: NfeDetalheImpostoIi) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'valorBcIi', label: 'Valor Bc Ii' },
		{ source: 'valorDespesasAduaneiras', label: 'Valor Despesas Aduaneiras' },
		{ source: 'valorImpostoImportacao', label: 'Valor Imposto Importacao' },
		{ source: 'valorIof', label: 'Valor Iof' },
	];

	return (
		<CrudChildTab
			title="Imposto Importação"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoIiModelList"
			newObject={ NfeDetalheImpostoIi.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};