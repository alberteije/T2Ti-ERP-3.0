/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeDetalheImpostoCofinsSt {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoCofinsSt {
		const nfeDetalheImpostoCofinsSt = new NfeDetalheImpostoCofinsSt();
		nfeDetalheImpostoCofinsSt.id = Date.now();
		nfeDetalheImpostoCofinsSt.statusCrud = "C";
		return nfeDetalheImpostoCofinsSt;
	}
}

export const NfeDetalheImpostoCofinsStTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoCofinsSt,
		setCurrentRecord: (record: NfeDetalheImpostoCofinsSt) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'baseCalculoCofinsSt', label: 'Base Calculo Cofins St' },
		{ source: 'aliquotaCofinsStPercentual', label: 'Aliquota Cofins St Percentual' },
		{ source: 'quantidadeVendidaCofinsSt', label: 'Quantidade Vendida Cofins St' },
		{ source: 'aliquotaCofinsStReais', label: 'Aliquota Cofins St Reais' },
		{ source: 'valorCofinsSt', label: 'Valor Cofins St' },
	];

	return (
		<CrudChildTab
			title="COFINS ST"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoCofinsStModelList"
			newObject={ NfeDetalheImpostoCofinsSt.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};