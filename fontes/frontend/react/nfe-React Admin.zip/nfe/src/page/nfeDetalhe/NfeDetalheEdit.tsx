/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { NfeDetalheForm } from "./NfeDetalheForm";
import { transformNestedData } from "../../infra/utils";

const NfeDetalheEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<NfeDetalheForm />
		</Edit>
	);
};

export default NfeDetalheEdit;