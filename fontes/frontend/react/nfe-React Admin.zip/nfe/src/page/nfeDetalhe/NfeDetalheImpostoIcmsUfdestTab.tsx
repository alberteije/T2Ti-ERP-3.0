/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeDetalheImpostoIcmsUfdest {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoIcmsUfdest {
		const nfeDetalheImpostoIcmsUfdest = new NfeDetalheImpostoIcmsUfdest();
		nfeDetalheImpostoIcmsUfdest.id = Date.now();
		nfeDetalheImpostoIcmsUfdest.statusCrud = "C";
		return nfeDetalheImpostoIcmsUfdest;
	}
}

export const NfeDetalheImpostoIcmsUfdestTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoIcmsUfdest,
		setCurrentRecord: (record: NfeDetalheImpostoIcmsUfdest) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'valorBcIcmsUfDestino', label: 'Valor Bc Icms Uf Destino' },
		{ source: 'valorBcFcpUfDestino', label: 'Valor Bc Fcp Uf Destino' },
		{ source: 'percentualFcpUfDestino', label: 'Percentual Fcp Uf Destino' },
		{ source: 'aliquotaInternaUfDestino', label: 'Aliquota Interna Uf Destino' },
		{ source: 'aliquotaInteresdatualUfEnvolvidas', label: 'Aliquota Interesdatual Uf Envolvidas' },
		{ source: 'percentualProvisorioPartilhaIcms', label: 'Percentual Provisorio Partilha Icms' },
		{ source: 'valorIcmsFcpUfDestino', label: 'Valor Icms Fcp Uf Destino' },
		{ source: 'valorInterestadualUfDestino', label: 'Valor Interestadual Uf Destino' },
		{ source: 'valorInterestadualUfRemetente', label: 'Valor Interestadual Uf Remetente' },
	];

	return (
		<CrudChildTab
			title="ICMS UF Destinatário"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoIcmsUfdestModelList"
			newObject={ NfeDetalheImpostoIcmsUfdest.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};