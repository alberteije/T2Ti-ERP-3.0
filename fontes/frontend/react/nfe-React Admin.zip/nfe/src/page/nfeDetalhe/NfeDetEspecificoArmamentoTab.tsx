/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetEspecificoArmamentoDomain from '../../data/domain/NfeDetEspecificoArmamentoDomain';

class NfeDetEspecificoArmamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetEspecificoArmamento {
		const nfeDetEspecificoArmamento = new NfeDetEspecificoArmamento();
		nfeDetEspecificoArmamento.id = Date.now();
		nfeDetEspecificoArmamento.statusCrud = "C";
		return nfeDetEspecificoArmamento;
	}
}

export const NfeDetEspecificoArmamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetEspecificoArmamento,
		setCurrentRecord: (record: NfeDetEspecificoArmamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tipoArma', label: 'Tipo Arma', formatDomain: NfeDetEspecificoArmamentoDomain.getTipoArma },
		{ source: 'numeroSerieArma', label: 'Numero Serie Arma' },
		{ source: 'numeroSerieCano', label: 'Numero Serie Cano' },
		{ source: 'descricao', label: 'Descricao' },
	];

	return (
		<CrudChildTab
			title="Armamento"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetEspecificoArmamentoModelList"
			newObject={ NfeDetEspecificoArmamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};