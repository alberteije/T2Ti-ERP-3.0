/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDetalheImpostoIssqnDomain from '../../data/domain/NfeDetalheImpostoIssqnDomain';

class NfeDetalheImpostoIssqn {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDetalheImpostoIssqn {
		const nfeDetalheImpostoIssqn = new NfeDetalheImpostoIssqn();
		nfeDetalheImpostoIssqn.id = Date.now();
		nfeDetalheImpostoIssqn.statusCrud = "C";
		return nfeDetalheImpostoIssqn;
	}
}

export const NfeDetalheImpostoIssqnTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDetalheImpostoIssqn,
		setCurrentRecord: (record: NfeDetalheImpostoIssqn) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'baseCalculoIssqn', label: 'Base Calculo Issqn' },
		{ source: 'aliquotaIssqn', label: 'Aliquota Issqn' },
		{ source: 'valorIssqn', label: 'Valor Issqn' },
		{ source: 'municipioIssqn', label: 'Municipio Issqn' },
		{ source: 'itemListaServicos', label: 'Item Lista Servicos' },
		{ source: 'valorDeducao', label: 'Valor Deducao' },
		{ source: 'valorOutrasRetencoes', label: 'Valor Outras Retencoes' },
		{ source: 'valorDescontoIncondicionado', label: 'Valor Desconto Incondicionado' },
		{ source: 'valorDescontoCondicionado', label: 'Valor Desconto Condicionado' },
		{ source: 'valorRetencaoIss', label: 'Valor Retencao Iss' },
		{ source: 'indicadorExigibilidadeIss', label: 'Indicador Exigibilidade Iss', formatDomain: NfeDetalheImpostoIssqnDomain.getIndicadorExigibilidadeIss },
		{ source: 'codigoServico', label: 'Codigo Servico' },
		{ source: 'municipioIncidencia', label: 'Municipio Incidencia' },
		{ source: 'paisSevicoPrestado', label: 'Pais Sevico Prestado' },
		{ source: 'numeroProcesso', label: 'Numero Processo' },
		{ source: 'indicadorIncentivoFiscal', label: 'Indicador Incentivo Fiscal', formatDomain: NfeDetalheImpostoIssqnDomain.getIndicadorIncentivoFiscal },
	];

	return (
		<CrudChildTab
			title="ISSQN"
			recordContext="nfeDetalhe"
			fieldSource="nfeDetalheImpostoIssqnModelList"
			newObject={ NfeDetalheImpostoIssqn.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};