/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { NfeDetalheForm } from "./NfeDetalheForm";
import { transformNestedData } from "../../infra/utils";

const NfeDetalheCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<NfeDetalheForm />
		</Create>
	);
};

export default NfeDetalheCreate;