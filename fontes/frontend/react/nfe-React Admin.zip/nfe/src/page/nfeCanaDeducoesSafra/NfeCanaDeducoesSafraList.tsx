/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeCanaDeducoesSafraList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeCanaModel.safra","decricao","valorDeducao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeCanaDeducoesSafraSmallScreenList : NfeCanaDeducoesSafraBigScreenList;

	return (
		<List
			title="Nfe Cana Deducoes Safra"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeCanaDeducoesSafraSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeCanaModel.safra }
			secondaryText={ (record) => record.decricao }
			tertiaryText={ (record) => record.valorDeducao }
		/>
	);
}

const NfeCanaDeducoesSafraBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Cana" source="nfeCanaModel.id" reference="nfe-cana" sortable={false}>
				<TextField source="safra" />
			</ReferenceField>
			<TextField source="decricao" label="Decricao" />
			<NumberField source="valorDeducao" label="Valor Deducao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorFornecimento" label="Valor Fornecimento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalDeducao" label="Valor Total Deducao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorLiquidoFornecimento" label="Valor Liquido Fornecimento" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeCanaDeducoesSafraList;
