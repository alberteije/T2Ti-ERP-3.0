import {
	Edit,
} from "react-admin";
import { NfeCanaDeducoesSafraForm } from "./NfeCanaDeducoesSafraForm";

const NfeCanaDeducoesSafraEdit = () => {
	return (
		<Edit>
			<NfeCanaDeducoesSafraForm />
		</Edit>
	);
};

export default NfeCanaDeducoesSafraEdit;