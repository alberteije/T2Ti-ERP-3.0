import NfeCanaDeducoesSafraIcon from "@mui/icons-material/Apps";
import NfeCanaDeducoesSafraList from "./NfeCanaDeducoesSafraList";
import NfeCanaDeducoesSafraCreate from "./NfeCanaDeducoesSafraCreate";
import NfeCanaDeducoesSafraEdit from "./NfeCanaDeducoesSafraEdit";

export default {
	list: NfeCanaDeducoesSafraList,
	create: NfeCanaDeducoesSafraCreate,
	edit: NfeCanaDeducoesSafraEdit,
	icon: NfeCanaDeducoesSafraIcon,
};
