import {
	Create,
} from "react-admin";
import { NfeCanaDeducoesSafraForm } from "./NfeCanaDeducoesSafraForm";

const NfeCanaDeducoesSafraCreate = () => {
	return (
		<Create>
			<NfeCanaDeducoesSafraForm />
		</Create>
	);
};

export default NfeCanaDeducoesSafraCreate;