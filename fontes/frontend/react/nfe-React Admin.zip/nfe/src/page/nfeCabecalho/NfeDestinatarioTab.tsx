/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeDestinatarioDomain from '../../data/domain/NfeDestinatarioDomain';

class NfeDestinatario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeDestinatario {
		const nfeDestinatario = new NfeDestinatario();
		nfeDestinatario.id = Date.now();
		nfeDestinatario.statusCrud = "C";
		return nfeDestinatario;
	}
}

export const NfeDestinatarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeDestinatario,
		setCurrentRecord: (record: NfeDestinatario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'estrangeiroIdentificacao', label: 'Estrangeiro Identificacao' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: NfeDestinatarioDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'indicadorIe', label: 'Indicador Ie', formatDomain: NfeDestinatarioDomain.getIndicadorIe },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
		{ source: 'suframa', label: 'Suframa' },
		{ source: 'inscricaoMunicipal', label: 'Inscricao Municipal' },
		{ source: 'email', label: 'Email' },
	];

	return (
		<CrudChildTab
			title="Destinatário"
			recordContext="nfeCabecalho"
			fieldSource="nfeDestinatarioModelList"
			newObject={ NfeDestinatario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};