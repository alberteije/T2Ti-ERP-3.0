/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeCteReferenciado {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeCteReferenciado {
		const nfeCteReferenciado = new NfeCteReferenciado();
		nfeCteReferenciado.id = Date.now();
		nfeCteReferenciado.statusCrud = "C";
		return nfeCteReferenciado;
	}
}

export const NfeCteReferenciadoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeCteReferenciado,
		setCurrentRecord: (record: NfeCteReferenciado) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'chaveAcesso', label: 'Chave Acesso' },
	];

	return (
		<CrudChildTab
			title="CTe Referenciado"
			recordContext="nfeCabecalho"
			fieldSource="nfeCteReferenciadoModelList"
			newObject={ NfeCteReferenciado.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};