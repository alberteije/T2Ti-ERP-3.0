/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { NfeReferenciadaTab } from './NfeReferenciadaTab';
import { NfeEmitenteTab } from './NfeEmitenteTab';
import { NfeDestinatarioTab } from './NfeDestinatarioTab';
import { NfeLocalRetiradaTab } from './NfeLocalRetiradaTab';
import { NfeLocalEntregaTab } from './NfeLocalEntregaTab';
import { NfeTransporteTab } from './NfeTransporteTab';
import { NfeFaturaTab } from './NfeFaturaTab';
import { NfeCanaTab } from './NfeCanaTab';
import { NfeProdRuralReferenciadaTab } from './NfeProdRuralReferenciadaTab';
import { NfeNfReferenciadaTab } from './NfeNfReferenciadaTab';
import { NfeProcessoReferenciadoTab } from './NfeProcessoReferenciadoTab';
import { NfeAcessoXmlTab } from './NfeAcessoXmlTab';
import { NfeInformacaoPagamentoTab } from './NfeInformacaoPagamentoTab';
import { NfeResponsavelTecnicoTab } from './NfeResponsavelTecnicoTab';
import { NfeCteReferenciadoTab } from './NfeCteReferenciadoTab';
import { NfeCupomFiscalReferenciadoTab } from './NfeCupomFiscalReferenciadoTab';

export const NfeCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="NF-e">
				<NfeCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="NFe Referenciada">
				<NfeReferenciadaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Emitente">
				<NfeEmitenteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Destinatário">
				<NfeDestinatarioTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Local Retirada">
				<NfeLocalRetiradaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Local Entrega">
				<NfeLocalEntregaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Transporte">
				<NfeTransporteTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Fatura">
				<NfeFaturaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Cana">
				<NfeCanaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="NFe Produtor Rural">
				<NfeProdRuralReferenciadaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="NF Referenciada">
				<NfeNfReferenciadaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Processo Referenciado">
				<NfeProcessoReferenciadoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Acesso XML">
				<NfeAcessoXmlTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Informação Pagamento">
				<NfeInformacaoPagamentoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Responsável Técnico">
				<NfeResponsavelTecnicoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="CTe Referenciado">
				<NfeCteReferenciadoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="CF Referenciado">
				<NfeCupomFiscalReferenciadoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const NfeCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};