/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeCupomFiscalReferenciadoDomain from '../../data/domain/NfeCupomFiscalReferenciadoDomain';

class NfeCupomFiscalReferenciado {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeCupomFiscalReferenciado {
		const nfeCupomFiscalReferenciado = new NfeCupomFiscalReferenciado();
		nfeCupomFiscalReferenciado.id = Date.now();
		nfeCupomFiscalReferenciado.statusCrud = "C";
		return nfeCupomFiscalReferenciado;
	}
}

export const NfeCupomFiscalReferenciadoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeCupomFiscalReferenciado,
		setCurrentRecord: (record: NfeCupomFiscalReferenciado) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'modeloDocumentoFiscal', label: 'Modelo Documento Fiscal', formatDomain: NfeCupomFiscalReferenciadoDomain.getModeloDocumentoFiscal },
		{ source: 'numeroOrdemEcf', label: 'Numero Ordem Ecf' },
		{ source: 'coo', label: 'Coo' },
		{ source: 'dataEmissaoCupom', label: 'Data Emissao Cupom' },
		{ source: 'numeroCaixa', label: 'Numero Caixa' },
		{ source: 'numeroSerieEcf', label: 'Numero Serie Ecf' },
	];

	return (
		<CrudChildTab
			title="CF Referenciado"
			recordContext="nfeCabecalho"
			fieldSource="nfeCupomFiscalReferenciadoModelList"
			newObject={ NfeCupomFiscalReferenciado.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};