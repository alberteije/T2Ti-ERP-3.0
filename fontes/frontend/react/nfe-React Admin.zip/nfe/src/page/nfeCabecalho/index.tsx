import NfeCabecalhoIcon from "@mui/icons-material/Apps";
import NfeCabecalhoList from "./NfeCabecalhoList";
import NfeCabecalhoCreate from "./NfeCabecalhoCreate";
import NfeCabecalhoEdit from "./NfeCabecalhoEdit";

export default {
	list: NfeCabecalhoList,
	create: NfeCabecalhoCreate,
	edit: NfeCabecalhoEdit,
	icon: NfeCabecalhoIcon,
};
