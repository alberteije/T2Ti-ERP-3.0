/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeCana {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeCana {
		const nfeCana = new NfeCana();
		nfeCana.id = Date.now();
		nfeCana.statusCrud = "C";
		return nfeCana;
	}
}

export const NfeCanaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeCana,
		setCurrentRecord: (record: NfeCana) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'safra', label: 'Safra' },
		{ source: 'mesAnoReferencia', label: 'Mes Ano Referencia' },
	];

	return (
		<CrudChildTab
			title="Cana"
			recordContext="nfeCabecalho"
			fieldSource="nfeCanaModelList"
			newObject={ NfeCana.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};