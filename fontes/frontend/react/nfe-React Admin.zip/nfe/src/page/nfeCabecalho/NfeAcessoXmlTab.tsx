/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeAcessoXml {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeAcessoXml {
		const nfeAcessoXml = new NfeAcessoXml();
		nfeAcessoXml.id = Date.now();
		nfeAcessoXml.statusCrud = "C";
		return nfeAcessoXml;
	}
}

export const NfeAcessoXmlTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeAcessoXml,
		setCurrentRecord: (record: NfeAcessoXml) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
	];

	return (
		<CrudChildTab
			title="Acesso XML"
			recordContext="nfeCabecalho"
			fieldSource="nfeAcessoXmlModelList"
			newObject={ NfeAcessoXml.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};