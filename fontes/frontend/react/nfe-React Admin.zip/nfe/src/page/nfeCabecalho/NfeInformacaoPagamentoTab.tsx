/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeInformacaoPagamentoDomain from '../../data/domain/NfeInformacaoPagamentoDomain';

class NfeInformacaoPagamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeInformacaoPagamento {
		const nfeInformacaoPagamento = new NfeInformacaoPagamento();
		nfeInformacaoPagamento.id = Date.now();
		nfeInformacaoPagamento.statusCrud = "C";
		return nfeInformacaoPagamento;
	}
}

export const NfeInformacaoPagamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeInformacaoPagamento,
		setCurrentRecord: (record: NfeInformacaoPagamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'indicadorPagamento', label: 'Indicador Pagamento', formatDomain: NfeInformacaoPagamentoDomain.getIndicadorPagamento },
		{ source: 'meioPagamento', label: 'Meio Pagamento', formatDomain: NfeInformacaoPagamentoDomain.getMeioPagamento },
		{ source: 'valor', label: 'Valor' },
		{ source: 'tipoIntegracao', label: 'Tipo Integracao', formatDomain: NfeInformacaoPagamentoDomain.getTipoIntegracao },
		{ source: 'cnpjOperadoraCartao', label: 'Cnpj Operadora Cartao', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'bandeira', label: 'Bandeira', formatDomain: NfeInformacaoPagamentoDomain.getBandeira },
		{ source: 'numeroAutorizacao', label: 'Numero Autorizacao' },
		{ source: 'troco', label: 'Troco' },
	];

	return (
		<CrudChildTab
			title="Informação Pagamento"
			recordContext="nfeCabecalho"
			fieldSource="nfeInformacaoPagamentoModelList"
			newObject={ NfeInformacaoPagamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};