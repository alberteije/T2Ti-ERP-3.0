/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeFatura {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeFatura {
		const nfeFatura = new NfeFatura();
		nfeFatura.id = Date.now();
		nfeFatura.statusCrud = "C";
		return nfeFatura;
	}
}

export const NfeFaturaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeFatura,
		setCurrentRecord: (record: NfeFatura) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'numero', label: 'Numero' },
		{ source: 'valorOriginal', label: 'Valor Original' },
		{ source: 'valorDesconto', label: 'Valor Desconto' },
		{ source: 'valorLiquido', label: 'Valor Liquido' },
	];

	return (
		<CrudChildTab
			title="Fatura"
			recordContext="nfeCabecalho"
			fieldSource="nfeFaturaModelList"
			newObject={ NfeFatura.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};