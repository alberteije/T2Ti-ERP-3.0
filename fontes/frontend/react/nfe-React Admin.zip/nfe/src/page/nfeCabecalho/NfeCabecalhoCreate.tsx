/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { NfeCabecalhoForm } from "./NfeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const NfeCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<NfeCabecalhoForm />
		</Create>
	);
};

export default NfeCabecalhoCreate;