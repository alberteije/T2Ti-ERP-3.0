/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfeReferenciada {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeReferenciada {
		const nfeReferenciada = new NfeReferenciada();
		nfeReferenciada.id = Date.now();
		nfeReferenciada.statusCrud = "C";
		return nfeReferenciada;
	}
}

export const NfeReferenciadaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeReferenciada,
		setCurrentRecord: (record: NfeReferenciada) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'chaveAcesso', label: 'Chave Acesso' },
	];

	return (
		<CrudChildTab
			title="NFe Referenciada"
			recordContext="nfeCabecalho"
			fieldSource="nfeReferenciadaModelList"
			newObject={ NfeReferenciada.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};