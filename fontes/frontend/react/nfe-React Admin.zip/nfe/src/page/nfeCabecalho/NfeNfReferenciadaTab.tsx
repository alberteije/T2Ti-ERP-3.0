/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeNfReferenciadaDomain from '../../data/domain/NfeNfReferenciadaDomain';

class NfeNfReferenciada {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeNfReferenciada {
		const nfeNfReferenciada = new NfeNfReferenciada();
		nfeNfReferenciada.id = Date.now();
		nfeNfReferenciada.statusCrud = "C";
		return nfeNfReferenciada;
	}
}

export const NfeNfReferenciadaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeNfReferenciada,
		setCurrentRecord: (record: NfeNfReferenciada) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoUf', label: 'Codigo Uf' },
		{ source: 'anoMes', label: 'Ano Mes' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'modelo', label: 'Modelo', formatDomain: NfeNfReferenciadaDomain.getModelo },
		{ source: 'serie', label: 'Serie', formatDomain: NfeNfReferenciadaDomain.getSerie },
		{ source: 'numeroNf', label: 'Numero Nf' },
	];

	return (
		<CrudChildTab
			title="NF Referenciada"
			recordContext="nfeCabecalho"
			fieldSource="nfeNfReferenciadaModelList"
			newObject={ NfeNfReferenciada.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};