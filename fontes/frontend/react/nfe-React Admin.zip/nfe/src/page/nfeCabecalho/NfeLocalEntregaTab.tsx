/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeLocalEntregaDomain from '../../data/domain/NfeLocalEntregaDomain';

class NfeLocalEntrega {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeLocalEntrega {
		const nfeLocalEntrega = new NfeLocalEntrega();
		nfeLocalEntrega.id = Date.now();
		nfeLocalEntrega.statusCrud = "C";
		return nfeLocalEntrega;
	}
}

export const NfeLocalEntregaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeLocalEntrega,
		setCurrentRecord: (record: NfeLocalEntrega) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nomeRecebedor', label: 'Nome Recebedor' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: NfeLocalEntregaDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'email', label: 'Email' },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
	];

	return (
		<CrudChildTab
			title="Local Entrega"
			recordContext="nfeCabecalho"
			fieldSource="nfeLocalEntregaModelList"
			newObject={ NfeLocalEntrega.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};