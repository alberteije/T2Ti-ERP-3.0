/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
	NumberField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import NfeCabecalhoDomain from '../../data/domain/NfeCabecalhoDomain';

const NfeCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["ufEmitente","codigoNumerico","naturezaOperacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeCabecalhoSmallScreenList : NfeCabecalhoBigScreenList;

	return (
		<List
			title="NF-e"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.ufEmitente }
			secondaryText={ (record) => record.codigoNumerico }
			tertiaryText={ (record) => record.naturezaOperacao }
		/>
	);
}

const NfeCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Uf Emitente"
				render={record => NfeCabecalhoDomain.getUfEmitente(record.ufEmitente)}
			/>
			<TextField source="codigoNumerico" label="Codigo Numerico" />
			<TextField source="naturezaOperacao" label="Natureza Operacao" />
			<FunctionField
				label="Codigo Modelo"
				render={record => NfeCabecalhoDomain.getCodigoModelo(record.codigoModelo)}
			/>
			<TextField source="serie" label="Serie" />
			<TextField source="numero" label="Numero" />
			<TextField source="dataHoraEmissao" label="Data Hora Emissao" />
			<TextField source="dataHoraEntradaSaida" label="Data Hora Entrada Saida" />
			<FunctionField
				label="Tipo Operacao"
				render={record => NfeCabecalhoDomain.getTipoOperacao(record.tipoOperacao)}
			/>
			<FunctionField
				label="Local Destino"
				render={record => NfeCabecalhoDomain.getLocalDestino(record.localDestino)}
			/>
			<TextField source="codigoMunicipio" label="Codigo Municipio" />
			<FunctionField
				label="Formato Impressao Danfe"
				render={record => NfeCabecalhoDomain.getFormatoImpressaoDanfe(record.formatoImpressaoDanfe)}
			/>
			<FunctionField
				label="Tipo Emissao"
				render={record => NfeCabecalhoDomain.getTipoEmissao(record.tipoEmissao)}
			/>
			<TextField source="chaveAcesso" label="Chave Acesso" />
			<TextField source="digitoChaveAcesso" label="Digito Chave Acesso" />
			<FunctionField
				label="Ambiente"
				render={record => NfeCabecalhoDomain.getAmbiente(record.ambiente)}
			/>
			<FunctionField
				label="Finalidade Emissao"
				render={record => NfeCabecalhoDomain.getFinalidadeEmissao(record.finalidadeEmissao)}
			/>
			<FunctionField
				label="Consumidor Operacao"
				render={record => NfeCabecalhoDomain.getConsumidorOperacao(record.consumidorOperacao)}
			/>
			<FunctionField
				label="Consumidor Presenca"
				render={record => NfeCabecalhoDomain.getConsumidorPresenca(record.consumidorPresenca)}
			/>
			<FunctionField
				label="Processo Emissao"
				render={record => NfeCabecalhoDomain.getProcessoEmissao(record.processoEmissao)}
			/>
			<TextField source="versaoProcessoEmissao" label="Versao Processo Emissao" />
			<TextField source="dataEntradaContingencia" label="Data Entrada Contingencia" />
			<TextField source="justificativaContingencia" label="Justificativa Contingencia" />
			<NumberField source="baseCalculoIcms" label="Base Calculo Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcms" label="Valor Icms" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsDesonerado" label="Valor Icms Desonerado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="totalIcmsFcpUfDestino" label="Total Icms Fcp Uf Destino" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="totalIcmsInterestadualUfDestino" label="Total Icms Interestadual Uf Destino" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="totalIcmsInterestadualUfRemetente" label="Total Icms Interestadual Uf Remetente" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalFcp" label="Valor Total Fcp" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="baseCalculoIcmsSt" label="Base Calculo Icms St" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIcmsSt" label="Valor Icms St" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalFcpSt" label="Valor Total Fcp St" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalFcpStRetido" label="Valor Total Fcp St Retido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalProdutos" label="Valor Total Produtos" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorFrete" label="Valor Frete" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorSeguro" label="Valor Seguro" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorImpostoImportacao" label="Valor Imposto Importacao" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIpi" label="Valor Ipi" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIpiDevolvido" label="Valor Ipi Devolvido" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPis" label="Valor Pis" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCofins" label="Valor Cofins" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorDespesasAcessorias" label="Valor Despesas Acessorias" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotal" label="Valor Total" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorTotalTributos" label="Valor Total Tributos" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorServicos" label="Valor Servicos" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="baseCalculoIssqn" label="Base Calculo Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorIssqn" label="Valor Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPisIssqn" label="Valor Pis Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorCofinsIssqn" label="Valor Cofins Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="dataPrestacaoServico" label="Data Prestacao Servico" />
			<NumberField source="valorDeducaoIssqn" label="Valor Deducao Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="outrasRetencoesIssqn" label="Outras Retencoes Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="descontoIncondicionadoIssqn" label="Desconto Incondicionado Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="descontoCondicionadoIssqn" label="Desconto Condicionado Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="totalRetencaoIssqn" label="Total Retencao Issqn" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Regime Especial Tributacao"
				render={record => NfeCabecalhoDomain.getRegimeEspecialTributacao(record.regimeEspecialTributacao)}
			/>
			<NumberField source="valorRetidoPis" label="Valor Retido Pis" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorRetidoCofins" label="Valor Retido Cofins" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorRetidoCsll" label="Valor Retido Csll" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="baseCalculoIrrf" label="Base Calculo Irrf" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorRetidoIrrf" label="Valor Retido Irrf" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="baseCalculoPrevidencia" label="Base Calculo Previdencia" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorRetidoPrevidencia" label="Valor Retido Previdencia" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="informacoesAddFisco" label="Informacoes Add Fisco" />
			<TextField source="informacoesAddContribuinte" label="Informacoes Add Contribuinte" />
			<FunctionField
				label="Comex Uf Embarque"
				render={record => NfeCabecalhoDomain.getComexUfEmbarque(record.comexUfEmbarque)}
			/>
			<TextField source="comexLocalEmbarque" label="Comex Local Embarque" />
			<TextField source="comexLocalDespacho" label="Comex Local Despacho" />
			<TextField source="compraNotaEmpenho" label="Compra Nota Empenho" />
			<TextField source="compraPedido" label="Compra Pedido" />
			<TextField source="compraContrato" label="Compra Contrato" />
			<TextField source="qrcode" label="Qrcode" />
			<TextField source="urlChave" label="Url Chave" />
			<FunctionField
				label="Status Nota"
				render={record => NfeCabecalhoDomain.getStatusNota(record.statusNota)}
			/>
			<ReferenceField label="Id Venda Cabecalho" source="vendaCabecalhoModel.id" reference="venda-cabecalho" sortable={false}>
				<TextField source="id" />
			</ReferenceField>
			<ReferenceField label="Id Tribut Operacao Fiscal" source="tributOperacaoFiscalModel.id" reference="tribut-operacao-fiscal" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Colaborador" source="viewPessoaColaboradorModel.id" reference="view-pessoa-colaborador" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Fornecedor" source="viewPessoaFornecedorModel.id" reference="view-pessoa-fornecedor" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeCabecalhoList;
