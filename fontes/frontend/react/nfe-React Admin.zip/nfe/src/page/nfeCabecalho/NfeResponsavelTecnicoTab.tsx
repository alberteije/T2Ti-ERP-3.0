/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeResponsavelTecnicoDomain from '../../data/domain/NfeResponsavelTecnicoDomain';

class NfeResponsavelTecnico {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeResponsavelTecnico {
		const nfeResponsavelTecnico = new NfeResponsavelTecnico();
		nfeResponsavelTecnico.id = Date.now();
		nfeResponsavelTecnico.statusCrud = "C";
		return nfeResponsavelTecnico;
	}
}

export const NfeResponsavelTecnicoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeResponsavelTecnico,
		setCurrentRecord: (record: NfeResponsavelTecnico) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'contato', label: 'Contato' },
		{ source: 'email', label: 'Email' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'identificadorCsrt', label: 'Identificador Csrt', formatDomain: NfeResponsavelTecnicoDomain.getIdentificadorCsrt },
		{ source: 'hashCsrt', label: 'Hash Csrt' },
	];

	return (
		<CrudChildTab
			title="Responsável Técnico"
			recordContext="nfeCabecalho"
			fieldSource="nfeResponsavelTecnicoModelList"
			newObject={ NfeResponsavelTecnico.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};