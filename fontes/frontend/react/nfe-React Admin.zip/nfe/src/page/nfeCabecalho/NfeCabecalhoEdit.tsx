/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { NfeCabecalhoForm } from "./NfeCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const NfeCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<NfeCabecalhoForm />
		</Edit>
	);
};

export default NfeCabecalhoEdit;