/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeEmitenteDomain from '../../data/domain/NfeEmitenteDomain';

class NfeEmitente {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeEmitente {
		const nfeEmitente = new NfeEmitente();
		nfeEmitente.id = Date.now();
		nfeEmitente.statusCrud = "C";
		return nfeEmitente;
	}
}

export const NfeEmitenteTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeEmitente,
		setCurrentRecord: (record: NfeEmitente) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'fantasia', label: 'Fantasia' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: NfeEmitenteDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
		{ source: 'inscricaoEstadualSt', label: 'Inscricao Estadual St' },
		{ source: 'inscricaoMunicipal', label: 'Inscricao Municipal' },
		{ source: 'cnae', label: 'Cnae' },
		{ source: 'crt', label: 'Crt', formatDomain: NfeEmitenteDomain.getCrt },
	];

	return (
		<CrudChildTab
			title="Emitente"
			recordContext="nfeCabecalho"
			fieldSource="nfeEmitenteModelList"
			newObject={ NfeEmitente.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};