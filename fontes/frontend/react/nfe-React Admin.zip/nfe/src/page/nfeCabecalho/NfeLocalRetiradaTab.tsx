/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeLocalRetiradaDomain from '../../data/domain/NfeLocalRetiradaDomain';

class NfeLocalRetirada {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeLocalRetirada {
		const nfeLocalRetirada = new NfeLocalRetirada();
		nfeLocalRetirada.id = Date.now();
		nfeLocalRetirada.statusCrud = "C";
		return nfeLocalRetirada;
	}
}

export const NfeLocalRetiradaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeLocalRetirada,
		setCurrentRecord: (record: NfeLocalRetirada) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nomeExpedidor', label: 'Nome Expedidor' },
		{ source: 'logradouro', label: 'Logradouro' },
		{ source: 'numero', label: 'Numero' },
		{ source: 'complemento', label: 'Complemento' },
		{ source: 'bairro', label: 'Bairro' },
		{ source: 'codigoMunicipio', label: 'Codigo Municipio' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: NfeLocalRetiradaDomain.getUf },
		{ source: 'cep', label: 'Cep', formatMask: formatWithMask, mask: '#####-###' },
		{ source: 'codigoPais', label: 'Codigo Pais' },
		{ source: 'nomePais', label: 'Nome Pais' },
		{ source: 'telefone', label: 'Telefone' },
		{ source: 'email', label: 'Email' },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
	];

	return (
		<CrudChildTab
			title="Local Retirada"
			recordContext="nfeCabecalho"
			fieldSource="nfeLocalRetiradaModelList"
			newObject={ NfeLocalRetirada.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};