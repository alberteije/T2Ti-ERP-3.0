/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeProdRuralReferenciadaDomain from '../../data/domain/NfeProdRuralReferenciadaDomain';

class NfeProdRuralReferenciada {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeProdRuralReferenciada {
		const nfeProdRuralReferenciada = new NfeProdRuralReferenciada();
		nfeProdRuralReferenciada.id = Date.now();
		nfeProdRuralReferenciada.statusCrud = "C";
		return nfeProdRuralReferenciada;
	}
}

export const NfeProdRuralReferenciadaTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeProdRuralReferenciada,
		setCurrentRecord: (record: NfeProdRuralReferenciada) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'codigoUf', label: 'Codigo Uf' },
		{ source: 'anoMes', label: 'Ano Mes' },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
		{ source: 'modelo', label: 'Modelo', formatDomain: NfeProdRuralReferenciadaDomain.getModelo },
		{ source: 'serie', label: 'Serie', formatDomain: NfeProdRuralReferenciadaDomain.getSerie },
		{ source: 'numeroNf', label: 'Numero Nf' },
	];

	return (
		<CrudChildTab
			title="NFe Produtor Rural"
			recordContext="nfeCabecalho"
			fieldSource="nfeProdRuralReferenciadaModelList"
			newObject={ NfeProdRuralReferenciada.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};