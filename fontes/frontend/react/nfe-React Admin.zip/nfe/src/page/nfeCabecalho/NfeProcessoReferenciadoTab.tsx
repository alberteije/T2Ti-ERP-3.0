/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeProcessoReferenciadoDomain from '../../data/domain/NfeProcessoReferenciadoDomain';

class NfeProcessoReferenciado {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeProcessoReferenciado {
		const nfeProcessoReferenciado = new NfeProcessoReferenciado();
		nfeProcessoReferenciado.id = Date.now();
		nfeProcessoReferenciado.statusCrud = "C";
		return nfeProcessoReferenciado;
	}
}

export const NfeProcessoReferenciadoTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeProcessoReferenciado,
		setCurrentRecord: (record: NfeProcessoReferenciado) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'identificador', label: 'Identificador' },
		{ source: 'origem', label: 'Origem', formatDomain: NfeProcessoReferenciadoDomain.getOrigem },
	];

	return (
		<CrudChildTab
			title="Processo Referenciado"
			recordContext="nfeCabecalho"
			fieldSource="nfeProcessoReferenciadoModelList"
			newObject={ NfeProcessoReferenciado.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};