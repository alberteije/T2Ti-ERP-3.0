/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfeTransporteDomain from '../../data/domain/NfeTransporteDomain';

class NfeTransporte {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfeTransporte {
		const nfeTransporte = new NfeTransporte();
		nfeTransporte.id = Date.now();
		nfeTransporte.statusCrud = "C";
		return nfeTransporte;
	}
}

export const NfeTransporteTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfeTransporte,
		setCurrentRecord: (record: NfeTransporte) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'idTransportadora', label: 'Id Transportadora' },
		{ source: 'modalidadeFrete', label: 'Modalidade Frete', formatDomain: NfeTransporteDomain.getModalidadeFrete },
		{ source: 'cnpj', label: 'Cnpj', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'cpf', label: 'Cpf', formatMask: formatWithMask, mask: '###.###.###-##' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'inscricaoEstadual', label: 'Inscricao Estadual' },
		{ source: 'endereco', label: 'Endereco' },
		{ source: 'nomeMunicipio', label: 'Nome Municipio' },
		{ source: 'uf', label: 'Uf', formatDomain: NfeTransporteDomain.getUf },
		{ source: 'valorServico', label: 'Valor Servico' },
		{ source: 'valorBcRetencaoIcms', label: 'Valor Bc Retencao Icms' },
		{ source: 'aliquotaRetencaoIcms', label: 'Aliquota Retencao Icms' },
		{ source: 'valorIcmsRetido', label: 'Valor Icms Retido' },
		{ source: 'cfop', label: 'Cfop' },
		{ source: 'municipio', label: 'Municipio' },
		{ source: 'placaVeiculo', label: 'Placa Veiculo' },
		{ source: 'ufVeiculo', label: 'Uf Veiculo', formatDomain: NfeTransporteDomain.getUfVeiculo },
		{ source: 'rntcVeiculo', label: 'Rntc Veiculo' },
	];

	return (
		<CrudChildTab
			title="Transporte"
			recordContext="nfeCabecalho"
			fieldSource="nfeTransporteModelList"
			newObject={ NfeTransporte.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};