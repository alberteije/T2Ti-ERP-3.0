import {
	Create,
} from "react-admin";
import { NfeNumeroInutilizadoForm } from "./NfeNumeroInutilizadoForm";

const NfeNumeroInutilizadoCreate = () => {
	return (
		<Create>
			<NfeNumeroInutilizadoForm />
		</Create>
	);
};

export default NfeNumeroInutilizadoCreate;