import NfeNumeroInutilizadoIcon from "@mui/icons-material/Apps";
import NfeNumeroInutilizadoList from "./NfeNumeroInutilizadoList";
import NfeNumeroInutilizadoCreate from "./NfeNumeroInutilizadoCreate";
import NfeNumeroInutilizadoEdit from "./NfeNumeroInutilizadoEdit";

export default {
	list: NfeNumeroInutilizadoList,
	create: NfeNumeroInutilizadoCreate,
	edit: NfeNumeroInutilizadoEdit,
	icon: NfeNumeroInutilizadoIcon,
};
