import {
	Edit,
} from "react-admin";
import { NfeNumeroInutilizadoForm } from "./NfeNumeroInutilizadoForm";

const NfeNumeroInutilizadoEdit = () => {
	return (
		<Edit>
			<NfeNumeroInutilizadoForm />
		</Edit>
	);
};

export default NfeNumeroInutilizadoEdit;