/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeNumeroInutilizadoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["serie","numero","dataInutilizacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeNumeroInutilizadoSmallScreenList : NfeNumeroInutilizadoBigScreenList;

	return (
		<List
			title="Números Inutilizados"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeNumeroInutilizadoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.serie }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record.dataInutilizacao }
		/>
	);
}

const NfeNumeroInutilizadoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="serie" label="Serie" />
			<TextField source="numero" label="Numero" />
			<TextField source="dataInutilizacao" label="Data Inutilizacao" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeNumeroInutilizadoList;
