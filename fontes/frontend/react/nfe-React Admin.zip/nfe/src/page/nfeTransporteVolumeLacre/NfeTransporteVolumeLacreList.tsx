/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeTransporteVolumeLacreList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeTransporteVolumeModel.numeracao","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeTransporteVolumeLacreSmallScreenList : NfeTransporteVolumeLacreBigScreenList;

	return (
		<List
			title="Nfe Transporte Volume Lacre"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeTransporteVolumeLacreSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeTransporteVolumeModel.numeracao }
			secondaryText={ (record) => record.numero }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const NfeTransporteVolumeLacreBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Transporte Volume" source="nfeTransporteVolumeModel.id" reference="nfe-transporte-volume" sortable={false}>
				<TextField source="numeracao" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeTransporteVolumeLacreList;
