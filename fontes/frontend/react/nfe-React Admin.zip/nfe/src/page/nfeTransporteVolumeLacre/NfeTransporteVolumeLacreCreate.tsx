import {
	Create,
} from "react-admin";
import { NfeTransporteVolumeLacreForm } from "./NfeTransporteVolumeLacreForm";

const NfeTransporteVolumeLacreCreate = () => {
	return (
		<Create>
			<NfeTransporteVolumeLacreForm />
		</Create>
	);
};

export default NfeTransporteVolumeLacreCreate;