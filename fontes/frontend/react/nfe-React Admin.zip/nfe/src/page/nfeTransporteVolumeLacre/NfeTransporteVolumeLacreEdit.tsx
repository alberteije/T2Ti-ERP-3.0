import {
	Edit,
} from "react-admin";
import { NfeTransporteVolumeLacreForm } from "./NfeTransporteVolumeLacreForm";

const NfeTransporteVolumeLacreEdit = () => {
	return (
		<Edit>
			<NfeTransporteVolumeLacreForm />
		</Edit>
	);
};

export default NfeTransporteVolumeLacreEdit;