import NfeTransporteVolumeLacreIcon from "@mui/icons-material/Apps";
import NfeTransporteVolumeLacreList from "./NfeTransporteVolumeLacreList";
import NfeTransporteVolumeLacreCreate from "./NfeTransporteVolumeLacreCreate";
import NfeTransporteVolumeLacreEdit from "./NfeTransporteVolumeLacreEdit";

export default {
	list: NfeTransporteVolumeLacreList,
	create: NfeTransporteVolumeLacreCreate,
	edit: NfeTransporteVolumeLacreEdit,
	icon: NfeTransporteVolumeLacreIcon,
};
