import {
	Edit,
} from "react-admin";
import { NfeImportacaoDetalheForm } from "./NfeImportacaoDetalheForm";

const NfeImportacaoDetalheEdit = () => {
	return (
		<Edit>
			<NfeImportacaoDetalheForm />
		</Edit>
	);
};

export default NfeImportacaoDetalheEdit;