import {
	Create,
} from "react-admin";
import { NfeImportacaoDetalheForm } from "./NfeImportacaoDetalheForm";

const NfeImportacaoDetalheCreate = () => {
	return (
		<Create>
			<NfeImportacaoDetalheForm />
		</Create>
	);
};

export default NfeImportacaoDetalheCreate;