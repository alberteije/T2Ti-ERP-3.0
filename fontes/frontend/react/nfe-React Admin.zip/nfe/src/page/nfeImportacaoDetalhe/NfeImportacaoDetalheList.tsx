/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const NfeImportacaoDetalheList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeDeclaracaoImportacaoModel.numeroDocumento","numeroAdicao","numeroSequencial"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeImportacaoDetalheSmallScreenList : NfeImportacaoDetalheBigScreenList;

	return (
		<List
			title="Importação Detalhe"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeImportacaoDetalheSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeDeclaracaoImportacaoModel.numeroDocumento }
			secondaryText={ (record) => record.numeroAdicao }
			tertiaryText={ (record) => record.numeroSequencial }
		/>
	);
}

const NfeImportacaoDetalheBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Declaracao Importacao" source="nfeDeclaracaoImportacaoModel.id" reference="nfe-declaracao-importacao" sortable={false}>
				<TextField source="numeroDocumento" />
			</ReferenceField>
			<TextField source="numeroAdicao" label="Numero Adicao" />
			<TextField source="numeroSequencial" label="Numero Sequencial" />
			<TextField source="codigoFabricanteEstrangeiro" label="Codigo Fabricante Estrangeiro" />
			<NumberField source="valorDesconto" label="Valor Desconto" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="drawback" label="Drawback" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeImportacaoDetalheList;
