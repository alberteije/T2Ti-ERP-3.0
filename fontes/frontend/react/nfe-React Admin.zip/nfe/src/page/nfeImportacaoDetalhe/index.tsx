import NfeImportacaoDetalheIcon from "@mui/icons-material/Apps";
import NfeImportacaoDetalheList from "./NfeImportacaoDetalheList";
import NfeImportacaoDetalheCreate from "./NfeImportacaoDetalheCreate";
import NfeImportacaoDetalheEdit from "./NfeImportacaoDetalheEdit";

export default {
	list: NfeImportacaoDetalheList,
	create: NfeImportacaoDetalheCreate,
	edit: NfeImportacaoDetalheEdit,
	icon: NfeImportacaoDetalheIcon,
};
