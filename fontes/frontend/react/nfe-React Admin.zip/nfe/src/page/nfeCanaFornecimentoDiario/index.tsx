import NfeCanaFornecimentoDiarioIcon from "@mui/icons-material/Apps";
import NfeCanaFornecimentoDiarioList from "./NfeCanaFornecimentoDiarioList";
import NfeCanaFornecimentoDiarioCreate from "./NfeCanaFornecimentoDiarioCreate";
import NfeCanaFornecimentoDiarioEdit from "./NfeCanaFornecimentoDiarioEdit";

export default {
	list: NfeCanaFornecimentoDiarioList,
	create: NfeCanaFornecimentoDiarioCreate,
	edit: NfeCanaFornecimentoDiarioEdit,
	icon: NfeCanaFornecimentoDiarioIcon,
};
