import {
	Edit,
} from "react-admin";
import { NfeCanaFornecimentoDiarioForm } from "./NfeCanaFornecimentoDiarioForm";

const NfeCanaFornecimentoDiarioEdit = () => {
	return (
		<Edit>
			<NfeCanaFornecimentoDiarioForm />
		</Edit>
	);
};

export default NfeCanaFornecimentoDiarioEdit;