/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import NfeCanaFornecimentoDiarioDomain from '../../data/domain/NfeCanaFornecimentoDiarioDomain';

const NfeCanaFornecimentoDiarioList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nfeCanaModel.safra","dia","quantidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeCanaFornecimentoDiarioSmallScreenList : NfeCanaFornecimentoDiarioBigScreenList;

	return (
		<List
			title="Nfe Cana Fornecimento Diario"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeCanaFornecimentoDiarioSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nfeCanaModel.safra }
			secondaryText={ (record) => record.dia }
			tertiaryText={ (record) => record.quantidade }
		/>
	);
}

const NfeCanaFornecimentoDiarioBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Nfe Cana" source="nfeCanaModel.id" reference="nfe-cana" sortable={false}>
				<TextField source="safra" />
			</ReferenceField>
			<FunctionField
				label="Dia"
				render={record => NfeCanaFornecimentoDiarioDomain.getDia(record.dia)}
			/>
			<NumberField source="quantidade" label="Quantidade" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="quantidadeTotalMes" label="Quantidade Total Mes" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="quantidadeTotalAnterior" label="Quantidade Total Anterior" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="quantidadeTotalGeral" label="Quantidade Total Geral" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeCanaFornecimentoDiarioList;
