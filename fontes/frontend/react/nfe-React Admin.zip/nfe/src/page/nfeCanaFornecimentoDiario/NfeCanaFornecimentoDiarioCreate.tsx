import {
	Create,
} from "react-admin";
import { NfeCanaFornecimentoDiarioForm } from "./NfeCanaFornecimentoDiarioForm";

const NfeCanaFornecimentoDiarioCreate = () => {
	return (
		<Create>
			<NfeCanaFornecimentoDiarioForm />
		</Create>
	);
};

export default NfeCanaFornecimentoDiarioCreate;