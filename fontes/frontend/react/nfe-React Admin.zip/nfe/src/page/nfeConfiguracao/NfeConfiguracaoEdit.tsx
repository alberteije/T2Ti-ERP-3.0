import {
	Edit,
} from "react-admin";
import { NfeConfiguracaoForm } from "./NfeConfiguracaoForm";

const NfeConfiguracaoEdit = () => {
	return (
		<Edit>
			<NfeConfiguracaoForm />
		</Edit>
	);
};

export default NfeConfiguracaoEdit;