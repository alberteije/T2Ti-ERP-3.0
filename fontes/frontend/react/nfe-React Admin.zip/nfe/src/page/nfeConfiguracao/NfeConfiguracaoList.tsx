/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import NfeConfiguracaoDomain from '../../data/domain/NfeConfiguracaoDomain';

const NfeConfiguracaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["certificadoDigitalSerie","certificadoDigitalCaminho","certificadoDigitalSenha"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfeConfiguracaoSmallScreenList : NfeConfiguracaoBigScreenList;

	return (
		<List
			title="Configurações da NF-e"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfeConfiguracaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.certificadoDigitalSerie }
			secondaryText={ (record) => record.certificadoDigitalCaminho }
			tertiaryText={ (record) => record.certificadoDigitalSenha }
		/>
	);
}

const NfeConfiguracaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="certificadoDigitalSerie" label="Certificado Digital Serie" />
			<TextField source="certificadoDigitalCaminho" label="Certificado Digital Caminho" />
			<TextField source="certificadoDigitalSenha" label="Certificado Digital Senha" />
			<TextField source="tipoEmissao" label="Tipo Emissao" />
			<TextField source="formatoImpressaoDanfe" label="Formato Impressao Danfe" />
			<TextField source="processoEmissao" label="Processo Emissao" />
			<TextField source="versaoProcessoEmissao" label="Versao Processo Emissao" />
			<TextField source="caminhoLogomarca" label="Caminho Logomarca" />
			<FunctionField
				label="Salvar Xml"
				render={record => NfeConfiguracaoDomain.getSalvarXml(record.salvarXml)}
			/>
			<TextField source="caminhoSalvarXml" label="Caminho Salvar Xml" />
			<TextField source="caminhoSchemas" label="Caminho Schemas" />
			<TextField source="caminhoArquivoDanfe" label="Caminho Arquivo Danfe" />
			<TextField source="caminhoSalvarPdf" label="Caminho Salvar Pdf" />
			<FunctionField
				label="Webservice Uf"
				render={record => NfeConfiguracaoDomain.getWebserviceUf(record.webserviceUf)}
			/>
			<TextField source="webserviceAmbiente" label="Webservice Ambiente" />
			<TextField source="webserviceProxyHost" label="Webservice Proxy Host" />
			<TextField source="webserviceProxyPorta" label="Webservice Proxy Porta" />
			<TextField source="webserviceProxyUsuario" label="Webservice Proxy Usuario" />
			<TextField source="webserviceProxySenha" label="Webservice Proxy Senha" />
			<FunctionField
				label="Webservice Visualizar"
				render={record => NfeConfiguracaoDomain.getWebserviceVisualizar(record.webserviceVisualizar)}
			/>
			<TextField source="emailServidorSmtp" label="Email Servidor Smtp" />
			<TextField source="emailPorta" label="Email Porta" />
			<TextField source="emailUsuario" label="Email Usuario" />
			<TextField source="emailSenha" label="Email Senha" />
			<TextField source="emailAssunto" label="Email Assunto" />
			<FunctionField
				label="Email Autentica Ssl"
				render={record => NfeConfiguracaoDomain.getEmailAutenticaSsl(record.emailAutenticaSsl)}
			/>
			<TextField source="emailTexto" label="Email Texto" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfeConfiguracaoList;
