import NfeConfiguracaoIcon from "@mui/icons-material/Apps";
import NfeConfiguracaoList from "./NfeConfiguracaoList";
import NfeConfiguracaoCreate from "./NfeConfiguracaoCreate";
import NfeConfiguracaoEdit from "./NfeConfiguracaoEdit";

export default {
	list: NfeConfiguracaoList,
	create: NfeConfiguracaoCreate,
	edit: NfeConfiguracaoEdit,
	icon: NfeConfiguracaoIcon,
};
