import {
	Create,
} from "react-admin";
import { NfeConfiguracaoForm } from "./NfeConfiguracaoForm";

const NfeConfiguracaoCreate = () => {
	return (
		<Create>
			<NfeConfiguracaoForm />
		</Create>
	);
};

export default NfeConfiguracaoCreate;