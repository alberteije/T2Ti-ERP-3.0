class NfeDetalheImpostoIpiDomain {
	static getEnquadramentoLegalIpi(enquadramentoLegalIpi: string) { 
		switch (enquadramentoLegalIpi) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setEnquadramentoLegalIpi(enquadramentoLegalIpi: string) { 
		switch (enquadramentoLegalIpi) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getCstIpi(cstIpi: string) { 
		switch (cstIpi) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setCstIpi(cstIpi: string) { 
		switch (cstIpi) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default NfeDetalheImpostoIpiDomain;