class NfeDetalheImpostoIssqnDomain {
	static getIndicadorExigibilidadeIss(indicadorExigibilidadeIss: string) { 
		switch (indicadorExigibilidadeIss) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setIndicadorExigibilidadeIss(indicadorExigibilidadeIss: string) { 
		switch (indicadorExigibilidadeIss) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getIndicadorIncentivoFiscal(indicadorIncentivoFiscal: string) { 
		switch (indicadorIncentivoFiscal) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setIndicadorIncentivoFiscal(indicadorIncentivoFiscal: string) { 
		switch (indicadorIncentivoFiscal) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}

export default NfeDetalheImpostoIssqnDomain;