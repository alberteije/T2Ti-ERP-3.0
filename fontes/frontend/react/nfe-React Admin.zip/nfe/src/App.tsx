import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import nfeCabecalho from './page/nfeCabecalho';
import nfeDetalhe from './page/nfeDetalhe';
import nfeDuplicata from './page/nfeDuplicata';
import nfeImportacaoDetalhe from './page/nfeImportacaoDetalhe';
import nfeCanaFornecimentoDiario from './page/nfeCanaFornecimentoDiario';
import nfeCanaDeducoesSafra from './page/nfeCanaDeducoesSafra';
import nfeTransporteReboque from './page/nfeTransporteReboque';
import nfeTransporteVolume from './page/nfeTransporteVolume';
import nfeTransporteVolumeLacre from './page/nfeTransporteVolumeLacre';
import nfeConfiguracao from './page/nfeConfiguracao';
import nfeNumeroInutilizado from './page/nfeNumeroInutilizado';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'nfe');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - NFe (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='nfe-cabecalho' {...nfeCabecalho} options={{ label: 'NF-e' }} />
			<Resource name='nfe-detalhe' {...nfeDetalhe} options={{ label: 'Itens da Nota' }} />
			<Resource name='nfe-duplicata' {...nfeDuplicata} options={{ label: 'Duplicata' }} />
			<Resource name='nfe-importacao-detalhe' {...nfeImportacaoDetalhe} options={{ label: 'Importação Detalhe' }} />
			<Resource name='nfe-cana-fornecimento-diario' {...nfeCanaFornecimentoDiario} options={{ label: 'Nfe Cana Fornecimento Diario' }} />
			<Resource name='nfe-cana-deducoes-safra' {...nfeCanaDeducoesSafra} options={{ label: 'Nfe Cana Deducoes Safra' }} />
			<Resource name='nfe-transporte-reboque' {...nfeTransporteReboque} options={{ label: 'Nfe Transporte Reboque' }} />
			<Resource name='nfe-transporte-volume' {...nfeTransporteVolume} options={{ label: 'Nfe Transporte Volume' }} />
			<Resource name='nfe-transporte-volume-lacre' {...nfeTransporteVolumeLacre} options={{ label: 'Nfe Transporte Volume Lacre' }} />
			<Resource name='nfe-configuracao' {...nfeConfiguracao} options={{ label: 'Configurações da NF-e' }} />
			<Resource name='nfe-numero-inutilizado' {...nfeNumeroInutilizado} options={{ label: 'Números Inutilizados' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;