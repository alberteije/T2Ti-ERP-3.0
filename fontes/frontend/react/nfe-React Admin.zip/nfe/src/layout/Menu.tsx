import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import nfeCabecalho from '../page/nfeCabecalho';
import nfeDetalhe from '../page/nfeDetalhe';
import nfeDuplicata from '../page/nfeDuplicata';
import nfeImportacaoDetalhe from '../page/nfeImportacaoDetalhe';
import nfeCanaFornecimentoDiario from '../page/nfeCanaFornecimentoDiario';
import nfeCanaDeducoesSafra from '../page/nfeCanaDeducoesSafra';
import nfeTransporteReboque from '../page/nfeTransporteReboque';
import nfeTransporteVolume from '../page/nfeTransporteVolume';
import nfeTransporteVolumeLacre from '../page/nfeTransporteVolumeLacre';
import nfeConfiguracao from '../page/nfeConfiguracao';
import nfeNumeroInutilizado from '../page/nfeNumeroInutilizado';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/nfe-duplicata'
					state={{ _scrollToTop: true }}
					primaryText='Duplicata'
					leftIcon={<nfeDuplicata.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-importacao-detalhe'
					state={{ _scrollToTop: true }}
					primaryText='Importação Detalhe'
					leftIcon={<nfeImportacaoDetalhe.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-cana-fornecimento-diario'
					state={{ _scrollToTop: true }}
					primaryText='Nfe Cana Fornecimento Diario'
					leftIcon={<nfeCanaFornecimentoDiario.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-cana-deducoes-safra'
					state={{ _scrollToTop: true }}
					primaryText='Nfe Cana Deducoes Safra'
					leftIcon={<nfeCanaDeducoesSafra.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-transporte-reboque'
					state={{ _scrollToTop: true }}
					primaryText='Nfe Transporte Reboque'
					leftIcon={<nfeTransporteReboque.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-transporte-volume'
					state={{ _scrollToTop: true }}
					primaryText='Nfe Transporte Volume'
					leftIcon={<nfeTransporteVolume.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-transporte-volume-lacre'
					state={{ _scrollToTop: true }}
					primaryText='Nfe Transporte Volume Lacre'
					leftIcon={<nfeTransporteVolumeLacre.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-configuracao'
					state={{ _scrollToTop: true }}
					primaryText='Configurações da NF-e'
					leftIcon={<nfeConfiguracao.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-numero-inutilizado'
					state={{ _scrollToTop: true }}
					primaryText='Números Inutilizados'
					leftIcon={<nfeNumeroInutilizado.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/nfe-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='NF-e'
					leftIcon={<nfeCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/nfe-detalhe'
					state={{ _scrollToTop: true }}
					primaryText='Itens da Nota'
					leftIcon={<nfeDetalhe.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
