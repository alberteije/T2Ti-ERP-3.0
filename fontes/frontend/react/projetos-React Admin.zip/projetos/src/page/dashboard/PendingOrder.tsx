import {
	ListItem,
	ListItemSecondaryAction,
	ListItemAvatar,
	ListItemText,
	Avatar,
	Box,
	ListItemButton,
} from '@mui/material';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useTranslate } from 'react-admin';

import { Customer, Order } from './types';

interface Props {
	order: Order;
}

export const PendingOrder = (props: Props) => {
	const { order } = props;
	const translate = useTranslate();
	const [customer, setCustomer] = useState<Customer | null>(null);
	const [loading, setLoading] = useState(true);

	// Carregar o cliente do arquivo JSON local
	useEffect(() => {
		const fetchCustomer = async () => {
			try {
				const response = await fetch('/src/data/fake/customers.json');
				const data = await response.json();
				// Encontrar o cliente correto baseado no customer_id
				const foundCustomer = data.find(
					(customer: Customer) => customer.id === order.customer_id
				);
				setCustomer(foundCustomer || null);
				setLoading(false);
			} catch (error) {
				console.error('Erro ao carregar os clientes', error);
				setLoading(false);
			}
		};

		fetchCustomer();
	}, [order.customer_id]);

	return (
		<ListItem disablePadding>
			<ListItemButton component={Link} to={``}>
				<ListItemAvatar>
					{loading ? (
						<Avatar />
					) : (
						<Avatar
							src={`${customer?.avatar ? `${customer.avatar}?size=32x32` : '/vycanis.png'}`}
							sx={{ bgcolor: 'background.paper' }}
							alt={'demo'}
						/>
					)}
				</ListItemAvatar>
				<ListItemText
					primary={new Date(order.date).toLocaleString('en-GB')}
					secondary={translate('dashboard.orders.items', {
						smart_count: order.basket.length,
						nb_items: order.basket.length,
						customer_name: customer
							? `${customer.first_name} ${customer.last_name}`
							: '',
					})}
				/>
				<ListItemSecondaryAction>
					<Box
						component="span"
						sx={{
							marginRight: '1em',
							color: 'text.primary',
						}}
					>
						$ {order.total}
					</Box>
				</ListItemSecondaryAction>
			</ListItemButton>
		</ListItem>
	);
};
