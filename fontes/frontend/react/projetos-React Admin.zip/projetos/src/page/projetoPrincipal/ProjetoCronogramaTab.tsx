/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ProjetoCronograma {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ProjetoCronograma {
		const projetoCronograma = new ProjetoCronograma();
		projetoCronograma.id = Date.now();
		projetoCronograma.statusCrud = "C";
		return projetoCronograma;
	}
}

export const ProjetoCronogramaTab: React.FC = () => {

	const renderForm = (
		currentRecord: ProjetoCronograma,
		setCurrentRecord: (record: ProjetoCronograma) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tarefa', label: 'Tarefa' },
		{ source: 'dataTarefa', label: 'Data Tarefa' },
		{ source: 'descricao', label: 'Descricao' },
	];

	return (
		<CrudChildTab
			title="Cronograma"
			recordContext="projetoPrincipal"
			fieldSource="projetoCronogramaModelList"
			newObject={ ProjetoCronograma.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};