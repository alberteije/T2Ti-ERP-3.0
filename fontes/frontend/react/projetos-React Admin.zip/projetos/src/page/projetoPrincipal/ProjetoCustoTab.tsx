/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ProjetoCusto {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ProjetoCusto {
		const projetoCusto = new ProjetoCusto();
		projetoCusto.id = Date.now();
		projetoCusto.statusCrud = "C";
		return projetoCusto;
	}
}

export const ProjetoCustoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ProjetoCusto,
		setCurrentRecord: (record: ProjetoCusto) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'finNaturezaFinanceiraModel.id', label: 'Natureza Financeira', reference: 'fin-natureza-financeira', fieldName: 'descricao' },
		{ source: 'nome', label: 'Nome' },
		{ source: 'valorMensal', label: 'Valor Mensal' },
		{ source: 'valorTotal', label: 'Valor Total' },
		{ source: 'justificativa', label: 'Justificativa' },
	];

	return (
		<CrudChildTab
			title="Custos"
			recordContext="projetoPrincipal"
			fieldSource="projetoCustoModelList"
			newObject={ ProjetoCusto.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};