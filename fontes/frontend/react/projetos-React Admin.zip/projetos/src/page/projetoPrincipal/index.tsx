import ProjetoPrincipalIcon from "@mui/icons-material/Apps";
import ProjetoPrincipalList from "./ProjetoPrincipalList";
import ProjetoPrincipalCreate from "./ProjetoPrincipalCreate";
import ProjetoPrincipalEdit from "./ProjetoPrincipalEdit";

export default {
	list: ProjetoPrincipalList,
	create: ProjetoPrincipalCreate,
	edit: ProjetoPrincipalEdit,
	icon: ProjetoPrincipalIcon,
};
