/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { ProjetoCronogramaTab } from './ProjetoCronogramaTab';
import { ProjetoRiscoTab } from './ProjetoRiscoTab';
import { ProjetoCustoTab } from './ProjetoCustoTab';
import { ProjetoStakeholdersTab } from './ProjetoStakeholdersTab';

export const ProjetoPrincipalForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Projeto">
				<ProjetoPrincipalTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Cronograma">
				<ProjetoCronogramaTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Riscos">
				<ProjetoRiscoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Custos">
				<ProjetoCustoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Stakeholders">
				<ProjetoStakeholdersTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const ProjetoPrincipalTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};