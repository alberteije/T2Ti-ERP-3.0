/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ProjetoRisco {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ProjetoRisco {
		const projetoRisco = new ProjetoRisco();
		projetoRisco.id = Date.now();
		projetoRisco.statusCrud = "C";
		return projetoRisco;
	}
}

export const ProjetoRiscoTab: React.FC = () => {

	const renderForm = (
		currentRecord: ProjetoRisco,
		setCurrentRecord: (record: ProjetoRisco) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nome', label: 'Nome' },
		{ source: 'probabilidade', label: 'Probabilidade' },
		{ source: 'impacto', label: 'Impacto' },
		{ source: 'descricao', label: 'Descricao' },
	];

	return (
		<CrudChildTab
			title="Riscos"
			recordContext="projetoPrincipal"
			fieldSource="projetoRiscoModelList"
			newObject={ ProjetoRisco.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};