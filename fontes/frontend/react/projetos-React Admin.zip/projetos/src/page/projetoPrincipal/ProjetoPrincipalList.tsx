/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const ProjetoPrincipalList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","dataInicio","dataPrevisaoFim"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? ProjetoPrincipalSmallScreenList : ProjetoPrincipalBigScreenList;

	return (
		<List
			title="Projeto"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const ProjetoPrincipalSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.dataInicio }
			tertiaryText={ (record) => record.dataPrevisaoFim }
		/>
	);
}

const ProjetoPrincipalBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataPrevisaoFim" label="Data Previsao Fim" />
			<TextField source="dataFim" label="Data Fim" />
			<NumberField source="valorOrcamento" label="Valor Orcamento" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="linkQuadroKanban" label="Link Quadro Kanban" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default ProjetoPrincipalList;
