/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class ProjetoStakeholders {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): ProjetoStakeholders {
		const projetoStakeholders = new ProjetoStakeholders();
		projetoStakeholders.id = Date.now();
		projetoStakeholders.statusCrud = "C";
		return projetoStakeholders;
	}
}

export const ProjetoStakeholdersTab: React.FC = () => {

	const renderForm = (
		currentRecord: ProjetoStakeholders,
		setCurrentRecord: (record: ProjetoStakeholders) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'viewPessoaColaboradorModel.id', label: 'Colaborador', reference: 'view-pessoa-colaborador', fieldName: 'nome' },
	];

	return (
		<CrudChildTab
			title="Stakeholders"
			recordContext="projetoPrincipal"
			fieldSource="projetoStakeholdersModelList"
			newObject={ ProjetoStakeholders.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};