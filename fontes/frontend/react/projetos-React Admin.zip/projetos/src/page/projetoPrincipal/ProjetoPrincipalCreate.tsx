/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { ProjetoPrincipalForm } from "./ProjetoPrincipalForm";
import { transformNestedData } from "../../infra/utils";

const ProjetoPrincipalCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<ProjetoPrincipalForm />
		</Create>
	);
};

export default ProjetoPrincipalCreate;