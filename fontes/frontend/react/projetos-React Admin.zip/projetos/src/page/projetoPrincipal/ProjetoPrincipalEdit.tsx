/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { ProjetoPrincipalForm } from "./ProjetoPrincipalForm";
import { transformNestedData } from "../../infra/utils";

const ProjetoPrincipalEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<ProjetoPrincipalForm />
		</Edit>
	);
};

export default ProjetoPrincipalEdit;