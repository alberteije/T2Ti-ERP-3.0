class NfseDetalheDomain {
	static getIssRetido(issRetido: string) { 
		switch (issRetido) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setIssRetido(issRetido: string) { 
		switch (issRetido) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default NfseDetalheDomain;