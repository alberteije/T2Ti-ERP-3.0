import {
	Edit,
} from "react-admin";
import { NfseListaServicoForm } from "./NfseListaServicoForm";

const NfseListaServicoEdit = () => {
	return (
		<Edit>
			<NfseListaServicoForm />
		</Edit>
	);
};

export default NfseListaServicoEdit;