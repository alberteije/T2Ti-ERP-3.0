import {
	Create,
} from "react-admin";
import { NfseListaServicoForm } from "./NfseListaServicoForm";

const NfseListaServicoCreate = () => {
	return (
		<Create>
			<NfseListaServicoForm />
		</Create>
	);
};

export default NfseListaServicoCreate;