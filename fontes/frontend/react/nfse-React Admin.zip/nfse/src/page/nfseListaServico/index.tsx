import NfseListaServicoIcon from "@mui/icons-material/Apps";
import NfseListaServicoList from "./NfseListaServicoList";
import NfseListaServicoCreate from "./NfseListaServicoCreate";
import NfseListaServicoEdit from "./NfseListaServicoEdit";

export default {
	list: NfseListaServicoList,
	create: NfseListaServicoCreate,
	edit: NfseListaServicoEdit,
	icon: NfseListaServicoIcon,
};
