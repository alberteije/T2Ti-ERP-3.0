/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class NfseIntermediario {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfseIntermediario {
		const nfseIntermediario = new NfseIntermediario();
		nfseIntermediario.id = Date.now();
		nfseIntermediario.statusCrud = "C";
		return nfseIntermediario;
	}
}

export const NfseIntermediarioTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfseIntermediario,
		setCurrentRecord: (record: NfseIntermediario) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'cnpj', label: 'CNPJ', formatMask: formatWithMask, mask: '##.###.###/####-##' },
		{ source: 'inscricaoMunicipal', label: 'Inscricao Municipal' },
		{ source: 'razao', label: 'Razão' },
	];

	return (
		<CrudChildTab
			title="Intermediários"
			recordContext="nfseCabecalho"
			fieldSource="nfseIntermediarioModelList"
			newObject={ NfseIntermediario.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};