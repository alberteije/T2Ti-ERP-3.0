/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { NfseCabecalhoForm } from "./NfseCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const NfseCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<NfseCabecalhoForm />
		</Edit>
	);
};

export default NfseCabecalhoEdit;