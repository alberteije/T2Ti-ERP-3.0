/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { NfseDetalheTab } from './NfseDetalheTab';
import { NfseIntermediarioTab } from './NfseIntermediarioTab';

export const NfseCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="NFS-e">
				<NfseCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens da NFS-e">
				<NfseDetalheTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Intermediários">
				<NfseIntermediarioTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const NfseCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};