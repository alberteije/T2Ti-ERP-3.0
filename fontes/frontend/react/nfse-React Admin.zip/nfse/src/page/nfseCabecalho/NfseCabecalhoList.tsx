/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import NfseCabecalhoDomain from '../../data/domain/NfseCabecalhoDomain';

const NfseCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["viewPessoaClienteModel.nome","osAberturaModel.numero","numero"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? NfseCabecalhoSmallScreenList : NfseCabecalhoBigScreenList;

	return (
		<List
			title="NFS-e"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const NfseCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.viewPessoaClienteModel.nome }
			secondaryText={ (record) => record.osAberturaModel.numero }
			tertiaryText={ (record) => record.numero }
		/>
	);
}

const NfseCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Cliente" source="viewPessoaClienteModel.id" reference="view-pessoa-cliente" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<ReferenceField label="Id Os Abertura" source="osAberturaModel.id" reference="os-abertura" sortable={false}>
				<TextField source="numero" />
			</ReferenceField>
			<TextField source="numero" label="Numero" />
			<TextField source="codigoVerificacao" label="Codigo Verificacao" />
			<TextField source="dataHoraEmissao" label="Data Hora Emissao" />
			<FunctionField
				source="competencia"
				label="Competencia"
				render={record => formatWithMask(record.competencia, '##/####')}
			/>
			<TextField source="numeroSubstituida" label="Numero Substituida" />
			<FunctionField
				label="Natureza Operacao"
				render={record => NfseCabecalhoDomain.getNaturezaOperacao(record.naturezaOperacao)}
			/>
			<FunctionField
				label="Regime Especial Tributacao"
				render={record => NfseCabecalhoDomain.getRegimeEspecialTributacao(record.regimeEspecialTributacao)}
			/>
			<FunctionField
				label="Optante Simples Nacional"
				render={record => NfseCabecalhoDomain.getOptanteSimplesNacional(record.optanteSimplesNacional)}
			/>
			<FunctionField
				label="Incentivador Cultural"
				render={record => NfseCabecalhoDomain.getIncentivadorCultural(record.incentivadorCultural)}
			/>
			<TextField source="numeroRps" label="Numero Rps" />
			<TextField source="serieRps" label="Serie Rps" />
			<FunctionField
				label="Tipo Rps"
				render={record => NfseCabecalhoDomain.getTipoRps(record.tipoRps)}
			/>
			<TextField source="dataEmissaoRps" label="Data Emissao Rps" />
			<TextField source="outrasInformacoes" label="Outras Informacoes" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default NfseCabecalhoList;
