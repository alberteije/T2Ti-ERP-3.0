/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { NfseCabecalhoForm } from "./NfseCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const NfseCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<NfseCabecalhoForm />
		</Create>
	);
};

export default NfseCabecalhoCreate;