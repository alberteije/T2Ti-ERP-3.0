/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import NfseDetalheDomain from '../../data/domain/NfseDetalheDomain';

class NfseDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): NfseDetalhe {
		const nfseDetalhe = new NfseDetalhe();
		nfseDetalhe.id = Date.now();
		nfseDetalhe.statusCrud = "C";
		return nfseDetalhe;
	}
}

export const NfseDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: NfseDetalhe,
		setCurrentRecord: (record: NfseDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'nfseListaServicoModel.id', label: 'Lista Serviço', reference: 'nfse-lista-servico', fieldName: 'descricao' },
		{ source: 'codigoCnae', label: 'Codigo Cnae' },
		{ source: 'codigoTributacaoMunicipio', label: 'Codigo Tributacao Municipio' },
		{ source: 'valorServicos', label: 'Valor Servicos' },
		{ source: 'valorDeducoes', label: 'Valor Deducoes' },
		{ source: 'valorPis', label: 'Valor Pis' },
		{ source: 'valorCofins', label: 'Valor Cofins' },
		{ source: 'valorInss', label: 'Valor Inss' },
		{ source: 'valorIr', label: 'Valor Ir' },
		{ source: 'valorCsll', label: 'Valor Csll' },
		{ source: 'valorBaseCalculo', label: 'Valor Base Calculo' },
		{ source: 'aliquota', label: 'Aliquota' },
		{ source: 'valorIss', label: 'Valor Iss' },
		{ source: 'valorLiquido', label: 'Valor Liquido' },
		{ source: 'outrasRetencoes', label: 'Outras Retencoes' },
		{ source: 'valorCredito', label: 'Valor Credito' },
		{ source: 'issRetido', label: 'Iss Retido', formatDomain: NfseDetalheDomain.getIssRetido },
		{ source: 'valorIssRetido', label: 'Valor Iss Retido' },
		{ source: 'valorDescontoCondicionado', label: 'Valor Desconto Condicionado' },
		{ source: 'valorDescontoIncondicionado', label: 'Valor Desconto Incondicionado' },
		{ source: 'municipioPrestacao', label: 'Municipio Prestacao' },
		{ source: 'discriminacao', label: 'Discriminacao' },
	];

	return (
		<CrudChildTab
			title="Itens da NFS-e"
			recordContext="nfseCabecalho"
			fieldSource="nfseDetalheModelList"
			newObject={ NfseDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};