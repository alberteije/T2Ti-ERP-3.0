import NfseCabecalhoIcon from "@mui/icons-material/Apps";
import NfseCabecalhoList from "./NfseCabecalhoList";
import NfseCabecalhoCreate from "./NfseCabecalhoCreate";
import NfseCabecalhoEdit from "./NfseCabecalhoEdit";

export default {
	list: NfseCabecalhoList,
	create: NfseCabecalhoCreate,
	edit: NfseCabecalhoEdit,
	icon: NfseCabecalhoIcon,
};
