import TributOperacaoFiscalIcon from "@mui/icons-material/Apps";
import TributOperacaoFiscalList from "./TributOperacaoFiscalList";
import TributOperacaoFiscalCreate from "./TributOperacaoFiscalCreate";
import TributOperacaoFiscalEdit from "./TributOperacaoFiscalEdit";

export default {
	list: TributOperacaoFiscalList,
	create: TributOperacaoFiscalCreate,
	edit: TributOperacaoFiscalEdit,
	icon: TributOperacaoFiscalIcon,
};
