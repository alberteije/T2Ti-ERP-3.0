import {
	Edit,
} from "react-admin";
import { TributOperacaoFiscalForm } from "./TributOperacaoFiscalForm";

const TributOperacaoFiscalEdit = () => {
	return (
		<Edit>
			<TributOperacaoFiscalForm />
		</Edit>
	);
};

export default TributOperacaoFiscalEdit;