import {
	Create,
} from "react-admin";
import { TributOperacaoFiscalForm } from "./TributOperacaoFiscalForm";

const TributOperacaoFiscalCreate = () => {
	return (
		<Create>
			<TributOperacaoFiscalForm />
		</Create>
	);
};

export default TributOperacaoFiscalCreate;