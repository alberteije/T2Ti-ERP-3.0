/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const TributOperacaoFiscalList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["cfop","descricao","descricaoNaNf"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TributOperacaoFiscalSmallScreenList : TributOperacaoFiscalBigScreenList;

	return (
		<List
			title="Operação Fiscal"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TributOperacaoFiscalSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.cfop }
			secondaryText={ (record) => record.descricao }
			tertiaryText={ (record) => record.descricaoNaNf }
		/>
	);
}

const TributOperacaoFiscalBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="cfop" label="Cfop" />
			<TextField source="descricao" label="Descricao" />
			<TextField source="descricaoNaNf" label="Descricao Na Nf" />
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TributOperacaoFiscalList;
