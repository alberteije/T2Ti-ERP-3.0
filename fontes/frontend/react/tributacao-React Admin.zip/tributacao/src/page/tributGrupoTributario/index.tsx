import TributGrupoTributarioIcon from "@mui/icons-material/Apps";
import TributGrupoTributarioList from "./TributGrupoTributarioList";
import TributGrupoTributarioCreate from "./TributGrupoTributarioCreate";
import TributGrupoTributarioEdit from "./TributGrupoTributarioEdit";

export default {
	list: TributGrupoTributarioList,
	create: TributGrupoTributarioCreate,
	edit: TributGrupoTributarioEdit,
	icon: TributGrupoTributarioIcon,
};
