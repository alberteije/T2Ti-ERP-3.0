import {
	Create,
} from "react-admin";
import { TributGrupoTributarioForm } from "./TributGrupoTributarioForm";

const TributGrupoTributarioCreate = () => {
	return (
		<Create>
			<TributGrupoTributarioForm />
		</Create>
	);
};

export default TributGrupoTributarioCreate;