import {
	Edit,
} from "react-admin";
import { TributGrupoTributarioForm } from "./TributGrupoTributarioForm";

const TributGrupoTributarioEdit = () => {
	return (
		<Edit>
			<TributGrupoTributarioForm />
		</Edit>
	);
};

export default TributGrupoTributarioEdit;