/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	TextInput,
	maxLength,
	SelectInput,
} from "react-admin";
import { Box } from "@mui/material";

export const TributGrupoTributarioForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={9}>
				<TextInput
					source='descricao'
					label='Descrição'
					helperText='Informe os dados para o campo Descricao[100]'
					validate={[maxLength(100, 'Max=100'), ]}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Origem Mercadoria'
					source='origemMercadoria'
					helperText='Informe os dados para o campo Origem Mercadoria'
					choices={ [{"id":"0","name":"0=Nacional"},{"id":"1","name":"1=Estrangeira - Importação Direta"},{"id":"2","name":"2=Estrangeira - Adquirida no Mercado Interno"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<TextInput
					source='observacao'
					label='Observação'
					helperText='Informe os dados para o campo Observacao'
					multiline
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);