/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { TributIcmsCustomCabForm } from "./TributIcmsCustomCabForm";
import { transformNestedData } from "../../infra/utils";

const TributIcmsCustomCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<TributIcmsCustomCabForm />
		</Create>
	);
};

export default TributIcmsCustomCabCreate;