/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { TributIcmsCustomCabForm } from "./TributIcmsCustomCabForm";
import { transformNestedData } from "../../infra/utils";

const TributIcmsCustomCabEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<TributIcmsCustomCabForm />
		</Edit>
	);
};

export default TributIcmsCustomCabEdit;