/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	SelectInput,
	NumberInput,
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import TributIcmsCustomDetDomain from '../../data/domain/TributIcmsCustomDetDomain';

class TributIcmsCustomDet {
	constructor(
		public id = 0,
		public ufDestino = '',
		public cst = '',
		public csosn = '',
		public modalidadeBc = '',
		public cfop = null,
		public aliquota = null,
		public valorPauta = null,
		public valorPrecoMaximo = null,
		public mva = null,
		public porcentoBc = null,
		public modalidadeBcSt = '',
		public aliquotaInternaSt = null,
		public aliquotaInterestadualSt = null,
		public porcentoBcSt = null,
		public aliquotaIcmsSt = null,
		public valorPautaSt = null,
		public valorPrecoMaximoSt = null,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): TributIcmsCustomDet {
		const tributIcmsCustomDet = new TributIcmsCustomDet();
		tributIcmsCustomDet.id = Date.now();
		tributIcmsCustomDet.statusCrud = "C";
		return tributIcmsCustomDet;
	}
}

export const TributIcmsCustomDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: TributIcmsCustomDet,
		setCurrentRecord: (record: TributIcmsCustomDet) => void,
	) => (
		<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<SelectInput
					label='Uf Destino'
					source='ufDestino'
					helperText='Informe os dados para o campo Uf Destino'
					choices={ [{"id":"AC","name":"AC"},{"id":"AL","name":"AL"},{"id":"AP","name":"AP"},{"id":"AM","name":"AM"},{"id":"BA","name":"BA"},{"id":"CE","name":"CE"},{"id":"DF","name":"DF"},{"id":"ES","name":"ES"},{"id":"GO","name":"GO"},{"id":"MA","name":"MA"},{"id":"MT","name":"MT"},{"id":"MS","name":"MS"},{"id":"MG","name":"MG"},{"id":"PA","name":"PA"},{"id":"PB","name":"PB"},{"id":"PR","name":"PR"},{"id":"PE","name":"PE"},{"id":"PI","name":"PI"},{"id":"RJ","name":"RJ"},{"id":"RN","name":"RN"},{"id":"RS","name":"RS"},{"id":"RO","name":"RO"},{"id":"RR","name":"RR"},{"id":"SC","name":"SC"},{"id":"SP","name":"SP"},{"id":"SE","name":"SE"},{"id":"TO","name":"TO"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							ufDestino: e.target.value,
						});
					}} format={(_: any) => currentRecord.ufDestino ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='CST'
					source='cst'
					helperText='Informe os dados para o campo Cst'
					choices={ [{"id":"00","name":"00"},{"id":"10","name":"10"},{"id":"20","name":"20"},{"id":"30","name":"30"},{"id":"40","name":"40"},{"id":"41","name":"41"},{"id":"50","name":"50"},{"id":"51","name":"51"},{"id":"60","name":"60"},{"id":"70","name":"70"},{"id":"90","name":"90"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							cst: e.target.value,
						});
					}} format={(_: any) => currentRecord.cst ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='CSOSN'
					source='csosn'
					helperText='Informe os dados para o campo Csosn'
					choices={ [{"id":"101","name":"101"},{"id":"102","name":"102"},{"id":"103","name":"103"},{"id":"201","name":"201"},{"id":"202","name":"202"},{"id":"203","name":"203"},{"id":"300","name":"300"},{"id":"400","name":"400"},{"id":"500","name":"500"},{"id":"900","name":"900"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							csosn: e.target.value,
						});
					}} format={(_: any) => currentRecord.csosn ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<SelectInput
					label='Modalidade BC'
					source='modalidadeBc'
					helperText='Informe os dados para o campo Modalidade Bc'
					choices={ [{"id":"0","name":"0-Margem Valor Agregado"},{"id":"1","name":"1-Valor Pauta"},{"id":"2","name":"2-Valor Preço Máximo"},{"id":"3","name":"3-Valor da Operação"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							modalidadeBc: e.target.value,
						});
					}} format={(_: any) => currentRecord.modalidadeBc ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='cfop'
					label='CFOP'
					helperText='Informe os dados para o campo Cfop'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									cfop: e.target.value,
								});
							}} format={(_: any) => currentRecord.cfop ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='aliquota'
					label='Alíquota'
					helperText='Informe os dados para o campo Aliquota'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquota: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquota ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorPauta'
					label='Valor Pauta'
					helperText='Informe os dados para o campo Valor Pauta'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorPauta: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorPauta ?? ''}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='valorPrecoMaximo'
					label='Valor Preço Máximo'
					helperText='Informe os dados para o campo Valor Preco Maximo'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorPrecoMaximo: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorPrecoMaximo ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='mva'
					label='MVA'
					helperText='Informe os dados para o campo Mva'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									mva: e.target.value,
								});
							}} format={(_: any) => currentRecord.mva ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='porcentoBc'
					label='Porcento BC'
					helperText='Informe os dados para o campo Porcento Bc'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									porcentoBc: e.target.value,
								});
							}} format={(_: any) => currentRecord.porcentoBc ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='Modalidade BC ST'
					source='modalidadeBcSt'
					helperText='Informe os dados para o campo Modalidade Bc St'
					choices={ [{"id":"0","name":"0-Valor Preço Máximo"},{"id":"1","name":"1-Valor Lista Negativa"},{"id":"2","name":"2-Valor Lista Positiva"},{"id":"3","name":"3-Valor Lista Neutra"},{"id":"4","name":"4-Margem Valor Agregado"},{"id":"5","name":"5-Valor Pauta"}] }  
					onChange={(e: any) => {
						setCurrentRecord({
							...currentRecord,
							modalidadeBcSt: e.target.value,
						});
					}} format={(_: any) => currentRecord.modalidadeBcSt ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='aliquotaInternaSt'
					label='Alíquota Interna ST'
					helperText='Informe os dados para o campo Aliquota Interna St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquotaInternaSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquotaInternaSt ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='aliquotaInterestadualSt'
					label='Alíquota Interestadual ST'
					helperText='Informe os dados para o campo Aliquota Interestadual St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquotaInterestadualSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquotaInterestadualSt ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='porcentoBcSt'
					label='Porcento BC ST'
					helperText='Informe os dados para o campo Porcento Bc St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									porcentoBcSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.porcentoBcSt ?? ''}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='aliquotaIcmsSt'
					label='Alíquota ICMS ST'
					helperText='Informe os dados para o campo Aliquota Icms St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									aliquotaIcmsSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.aliquotaIcmsSt ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorPautaSt'
					label='Valor Pauta ST'
					helperText='Informe os dados para o campo Valor Pauta St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorPautaSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorPautaSt ?? ''}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorPrecoMaximoSt'
					label='Valor Preço Máximo ST'
					helperText='Informe os dados para o campo Valor Preco Maximo St'
					validate={[]}
					onChange={(e: any) => {
								setCurrentRecord({
									...currentRecord,
									valorPrecoMaximoSt: e.target.value,
								});
							}} format={(_: any) => currentRecord.valorPrecoMaximoSt ?? ''}
				/>
			</Box>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'id', label: 'Id' },
		{ source: 'ufDestino', label: 'Uf Destino', formatDomain: TributIcmsCustomDetDomain.getUfDestino },
		{ source: 'cst', label: 'CST', formatDomain: TributIcmsCustomDetDomain.getCst },
		{ source: 'csosn', label: 'CSOSN', formatDomain: TributIcmsCustomDetDomain.getCsosn },
		{ source: 'modalidadeBc', label: 'Modalidade BC', formatDomain: TributIcmsCustomDetDomain.getModalidadeBc },
		{ source: 'cfop', label: 'CFOP' },
		{ source: 'aliquota', label: 'Alíquota' },
		{ source: 'valorPauta', label: 'Valor Pauta' },
		{ source: 'valorPrecoMaximo', label: 'Valor Preço Máximo' },
		{ source: 'mva', label: 'MVA' },
		{ source: 'porcentoBc', label: 'Porcento BC' },
		{ source: 'modalidadeBcSt', label: 'Modalidade BC ST', formatDomain: TributIcmsCustomDetDomain.getModalidadeBcSt },
		{ source: 'aliquotaInternaSt', label: 'Alíquota Interna ST' },
		{ source: 'aliquotaInterestadualSt', label: 'Alíquota Interestadual ST' },
		{ source: 'porcentoBcSt', label: 'Porcento BC ST' },
		{ source: 'aliquotaIcmsSt', label: 'Alíquota ICMS ST' },
		{ source: 'valorPautaSt', label: 'Valor Pauta ST' },
		{ source: 'valorPrecoMaximoSt', label: 'Valor Preço Máximo ST' },
	];

	return (
		<CrudChildTab
			title="Detalhes"
			recordContext="tributIcmsCustomCab"
			fieldSource="tributIcmsCustomDetModelList"
			newObject={ TributIcmsCustomDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};