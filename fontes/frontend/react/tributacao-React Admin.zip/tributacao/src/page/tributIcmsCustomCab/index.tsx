import TributIcmsCustomCabIcon from "@mui/icons-material/Apps";
import TributIcmsCustomCabList from "./TributIcmsCustomCabList";
import TributIcmsCustomCabCreate from "./TributIcmsCustomCabCreate";
import TributIcmsCustomCabEdit from "./TributIcmsCustomCabEdit";

export default {
	list: TributIcmsCustomCabList,
	create: TributIcmsCustomCabCreate,
	edit: TributIcmsCustomCabEdit,
	icon: TributIcmsCustomCabIcon,
};
