/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import TributIcmsCustomCabDomain from '../../data/domain/TributIcmsCustomCabDomain';

const TributIcmsCustomCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["descricao","origemMercadoria"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TributIcmsCustomCabSmallScreenList : TributIcmsCustomCabBigScreenList;

	return (
		<List
			title="ICMS Customizado"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TributIcmsCustomCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.descricao }
			secondaryText={ (record) => record.origemMercadoria }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const TributIcmsCustomCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<TextField source="descricao" label="Descricao" />
			<FunctionField
				label="Origem Mercadoria"
				render={record => TributIcmsCustomCabDomain.getOrigemMercadoria(record.origemMercadoria)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TributIcmsCustomCabList;
