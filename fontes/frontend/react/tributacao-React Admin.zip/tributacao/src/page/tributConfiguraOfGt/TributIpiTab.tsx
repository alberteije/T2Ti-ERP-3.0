/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	SelectInput,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const TributIpiTab = () => (
	<>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<SelectInput
					label='CST'
					source='tributIpiModel.cstIpi'
					helperText='Informe os dados para o campo Cst Ipi'
					choices={ [{"id":"00","name":"00"},{"id":"10","name":"10"},{"id":"20","name":"20"},{"id":"30","name":"30"},{"id":"40","name":"40"},{"id":"41","name":"41"},{"id":"50","name":"50"},{"id":"51","name":"51"},{"id":"60","name":"60"},{"id":"70","name":"70"},{"id":"90","name":"90"}] }  
				/>
			</Box>
			<Box flex={4}>
				<SelectInput
					label='Modalidade Base Cálculo'
					source='tributIpiModel.modalidadeBaseCalculo'
					helperText='Informe os dados para o campo Modalidade Base Calculo'
					choices={ [{"id":"0","name":"0-Percentual"},{"id":"1","name":"1-Unidade"}] }  
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='tributIpiModel.porcentoBaseCalculo'
					label='Porcento Base Cálculo'
					helperText='Informe os dados para o campo Porcento Base Calculo'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={3}>
				<NumberInput
					source='tributIpiModel.aliquotaPorcento'
					label='Alíquota Porcento'
					helperText='Informe os dados para o campo Aliquota Porcento'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributIpiModel.aliquotaUnidade'
					label='Alíquota Unidade'
					helperText='Informe os dados para o campo Aliquota Unidade'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributIpiModel.valorPrecoMaximo'
					label='Valor Preço Máximo'
					helperText='Informe os dados para o campo Valor Preco Maximo'
					validate={[]}
				/>
			</Box>
			<Box flex={3}>
				<NumberInput
					source='tributIpiModel.valorPautaFiscal'
					label='Valor Pauta Fiscal'
					helperText='Informe os dados para o campo Valor Pauta Fiscal'
					validate={[]}
				/>
			</Box>
		</Box>
	</>
);