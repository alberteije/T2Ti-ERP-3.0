/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const TributConfiguraOfGtList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["tributGrupoTributarioModel.descricao","tributOperacaoFiscalModel.descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TributConfiguraOfGtSmallScreenList : TributConfiguraOfGtBigScreenList;

	return (
		<List
			title="Configura Tributação"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TributConfiguraOfGtSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.tributGrupoTributarioModel.descricao }
			secondaryText={ (record) => record.tributOperacaoFiscalModel.descricao }
			tertiaryText={ (record) => record._ }
		/>
	);
}

const TributConfiguraOfGtBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Tribut Grupo Tributario" source="tributGrupoTributarioModel.id" reference="tribut-grupo-tributario" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<ReferenceField label="Id Tribut Operacao Fiscal" source="tributOperacaoFiscalModel.id" reference="tribut-operacao-fiscal" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TributConfiguraOfGtList;
