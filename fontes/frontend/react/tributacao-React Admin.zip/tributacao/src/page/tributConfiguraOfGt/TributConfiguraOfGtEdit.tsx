/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { TributConfiguraOfGtForm } from "./TributConfiguraOfGtForm";
import { transformNestedData } from "../../infra/utils";

const TributConfiguraOfGtEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<TributConfiguraOfGtForm />
		</Edit>
	);
};

export default TributConfiguraOfGtEdit;