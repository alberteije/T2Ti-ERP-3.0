import TributConfiguraOfGtIcon from "@mui/icons-material/Apps";
import TributConfiguraOfGtList from "./TributConfiguraOfGtList";
import TributConfiguraOfGtCreate from "./TributConfiguraOfGtCreate";
import TributConfiguraOfGtEdit from "./TributConfiguraOfGtEdit";

export default {
	list: TributConfiguraOfGtList,
	create: TributConfiguraOfGtCreate,
	edit: TributConfiguraOfGtEdit,
	icon: TributConfiguraOfGtIcon,
};
