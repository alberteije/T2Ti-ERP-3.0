/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
	ReferenceInput,
	AutocompleteInput,
} from "react-admin";
import { Box } from "@mui/material";
import { TributIpiTab } from './TributIpiTab';
import { TributCofinsTab } from './TributCofinsTab';
import { TributPisTab } from './TributPisTab';
import { TributIcmsUfTab } from './TributIcmsUfTab';

export const TributConfiguraOfGtForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Configura Tributação">
				<TributConfiguraOfGtTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="IPI">
				<TributIpiTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="COFINS">
				<TributCofinsTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="PIS">
				<TributPisTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="ICMS">
				<TributIcmsUfTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const TributConfiguraOfGtTab = () => {
	return (
	<>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='tributGrupoTributarioModel.id' reference='tribut-grupo-tributario' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Grupo Tributário'
						optionText='descricao'
						helperText='Informe os dados para o campo Grupo Tributario'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='tributOperacaoFiscalModel.id' reference='tribut-operacao-fiscal' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Operação Fiscal'
						optionText='descricao'
						helperText='Informe os dados para o campo Id Tribut Operacao Fiscal'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
	</>
	);
};