/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { TributConfiguraOfGtForm } from "./TributConfiguraOfGtForm";
import { transformNestedData } from "../../infra/utils";

const TributConfiguraOfGtCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<TributConfiguraOfGtForm />
		</Create>
	);
};

export default TributConfiguraOfGtCreate;