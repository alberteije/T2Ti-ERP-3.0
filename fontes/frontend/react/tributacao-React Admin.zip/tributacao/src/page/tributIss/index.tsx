import TributIssIcon from "@mui/icons-material/Apps";
import TributIssList from "./TributIssList";
import TributIssCreate from "./TributIssCreate";
import TributIssEdit from "./TributIssEdit";

export default {
	list: TributIssList,
	create: TributIssCreate,
	edit: TributIssEdit,
	icon: TributIssIcon,
};
