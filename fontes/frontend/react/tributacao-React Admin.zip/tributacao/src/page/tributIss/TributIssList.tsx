/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	ReferenceField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import TributIssDomain from '../../data/domain/TributIssDomain';

const TributIssList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["tributOperacaoFiscalModel.descricao","modalidadeBaseCalculo","codigoTributacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? TributIssSmallScreenList : TributIssBigScreenList;

	return (
		<List
			title="ISS"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const TributIssSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.tributOperacaoFiscalModel.descricao }
			secondaryText={ (record) => record.modalidadeBaseCalculo }
			tertiaryText={ (record) => record.codigoTributacao }
		/>
	);
}

const TributIssBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="id" label="Id" />
			<ReferenceField label="Id Tribut Operacao Fiscal" source="tributOperacaoFiscalModel.id" reference="tribut-operacao-fiscal" sortable={false}>
				<TextField source="descricao" />
			</ReferenceField>
			<FunctionField
				label="Modalidade Base Calculo"
				render={record => TributIssDomain.getModalidadeBaseCalculo(record.modalidadeBaseCalculo)}
			/>
			<FunctionField
				label="Codigo Tributacao"
				render={record => TributIssDomain.getCodigoTributacao(record.codigoTributacao)}
			/>
			<TextField source="itemListaServico" label="Item Lista Servico" />
			<NumberField source="porcentoBaseCalculo" label="Porcento Base Calculo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaPorcento" label="Aliquota Porcento" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="aliquotaUnidade" label="Aliquota Unidade" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPrecoMaximo" label="Valor Preco Maximo" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="valorPautaFiscal" label="Valor Pauta Fiscal" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default TributIssList;
