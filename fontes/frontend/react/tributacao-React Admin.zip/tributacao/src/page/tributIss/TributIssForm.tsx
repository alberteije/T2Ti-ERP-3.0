/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	SimpleForm,
	ReferenceInput,
	AutocompleteInput,
	SelectInput,
	NumberInput,
} from "react-admin";
import { Box } from "@mui/material";

export const TributIssForm = () => (
	<SimpleForm>
		<ListButton />
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={12}>
				<ReferenceInput source='tributOperacaoFiscalModel.id' reference='tribut-operacao-fiscal' filter={{'field': 'descricao'}}>
					<AutocompleteInput
						label='Operação Fiscal'
						optionText='descricao'
						helperText='Informe os dados para o campo Id Tribut Operacao Fiscal'  
					/>
				</ReferenceInput>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={6}>
				<SelectInput
					label='Modalidade Base Cálculo'
					source='modalidadeBaseCalculo'
					helperText='Informe os dados para o campo Modalidade Base Calculo'
					choices={ [{"id":"0","name":"0-Valor Operação"},{"id":"9","name":"9-Outros"}] }  
				/>
			</Box>
			<Box flex={6}>
				<SelectInput
					label='Código Tributação'
					source='codigoTributacao'
					helperText='Informe os dados para o campo Codigo Tributacao'
					choices={ [{"id":"N","name":"Normal"},{"id":"R","name":"Retida"},{"id":"S","name":"Substituta"},{"id":"I","name":"Isenta"}] }  
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='itemListaServico'
					label='Item Lista Servico'
					helperText='Informe os dados para o campo Item Lista Servico'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='porcentoBaseCalculo'
					label='Porcento Base Cálculo'
					helperText='Informe os dados para o campo Porcento Base Calculo'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='aliquotaPorcento'
					label='Alíquota Porcento'
					helperText='Informe os dados para o campo Aliquota Porcento'
					validate={[]}
				/>
			</Box>
		</Box>
		<Box display={{ xs: 'block', sm: 'flex', width: '100%' }} gap='0.9em'>
			<Box flex={4}>
				<NumberInput
					source='aliquotaUnidade'
					label='Alíquota Unidade'
					helperText='Informe os dados para o campo Aliquota Unidade'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorPrecoMaximo'
					label='Valor Preço Máximo'
					helperText='Informe os dados para o campo Valor Preco Maximo'
					validate={[]}
				/>
			</Box>
			<Box flex={4}>
				<NumberInput
					source='valorPautaFiscal'
					label='Valor Pauta Fiscal'
					helperText='Informe os dados para o campo Valor Pauta Fiscal'
					validate={[]}
				/>
			</Box>
		</Box>
	</SimpleForm>
);