import {
	Edit,
} from "react-admin";
import { TributIssForm } from "./TributIssForm";

const TributIssEdit = () => {
	return (
		<Edit>
			<TributIssForm />
		</Edit>
	);
};

export default TributIssEdit;