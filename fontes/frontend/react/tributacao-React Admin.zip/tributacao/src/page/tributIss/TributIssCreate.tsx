import {
	Create,
} from "react-admin";
import { TributIssForm } from "./TributIssForm";

const TributIssCreate = () => {
	return (
		<Create>
			<TributIssForm />
		</Create>
	);
};

export default TributIssCreate;