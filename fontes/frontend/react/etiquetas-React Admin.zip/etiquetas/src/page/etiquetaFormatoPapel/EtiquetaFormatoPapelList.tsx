/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EtiquetaFormatoPapelList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["nome","altura","largura"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EtiquetaFormatoPapelSmallScreenList : EtiquetaFormatoPapelBigScreenList;

	return (
		<List
			title="Formato do Papel"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EtiquetaFormatoPapelSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.nome }
			secondaryText={ (record) => record.altura }
			tertiaryText={ (record) => record.largura }
		/>
	);
}

const EtiquetaFormatoPapelBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="nome" label="Nome" />
			<TextField source="altura" label="Altura" />
			<TextField source="largura" label="Largura" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EtiquetaFormatoPapelList;
