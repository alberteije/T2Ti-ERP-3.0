import {
	Edit,
} from "react-admin";
import { EtiquetaFormatoPapelForm } from "./EtiquetaFormatoPapelForm";

const EtiquetaFormatoPapelEdit = () => {
	return (
		<Edit>
			<EtiquetaFormatoPapelForm />
		</Edit>
	);
};

export default EtiquetaFormatoPapelEdit;