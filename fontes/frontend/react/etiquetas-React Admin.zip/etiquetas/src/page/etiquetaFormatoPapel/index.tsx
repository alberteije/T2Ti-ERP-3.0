import EtiquetaFormatoPapelIcon from "@mui/icons-material/Apps";
import EtiquetaFormatoPapelList from "./EtiquetaFormatoPapelList";
import EtiquetaFormatoPapelCreate from "./EtiquetaFormatoPapelCreate";
import EtiquetaFormatoPapelEdit from "./EtiquetaFormatoPapelEdit";

export default {
	list: EtiquetaFormatoPapelList,
	create: EtiquetaFormatoPapelCreate,
	edit: EtiquetaFormatoPapelEdit,
	icon: EtiquetaFormatoPapelIcon,
};
