import {
	Create,
} from "react-admin";
import { EtiquetaFormatoPapelForm } from "./EtiquetaFormatoPapelForm";

const EtiquetaFormatoPapelCreate = () => {
	return (
		<Create>
			<EtiquetaFormatoPapelForm />
		</Create>
	);
};

export default EtiquetaFormatoPapelCreate;