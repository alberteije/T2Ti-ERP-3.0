/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { EtiquetaLayoutForm } from "./EtiquetaLayoutForm";
import { transformNestedData } from "../../infra/utils";

const EtiquetaLayoutEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<EtiquetaLayoutForm />
		</Edit>
	);
};

export default EtiquetaLayoutEdit;