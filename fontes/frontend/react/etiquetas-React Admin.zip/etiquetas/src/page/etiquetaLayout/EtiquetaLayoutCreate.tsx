/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { EtiquetaLayoutForm } from "./EtiquetaLayoutForm";
import { transformNestedData } from "../../infra/utils";

const EtiquetaLayoutCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<EtiquetaLayoutForm />
		</Create>
	);
};

export default EtiquetaLayoutCreate;