import EtiquetaLayoutIcon from "@mui/icons-material/Apps";
import EtiquetaLayoutList from "./EtiquetaLayoutList";
import EtiquetaLayoutCreate from "./EtiquetaLayoutCreate";
import EtiquetaLayoutEdit from "./EtiquetaLayoutEdit";

export default {
	list: EtiquetaLayoutList,
	create: EtiquetaLayoutCreate,
	edit: EtiquetaLayoutEdit,
	icon: EtiquetaLayoutIcon,
};
