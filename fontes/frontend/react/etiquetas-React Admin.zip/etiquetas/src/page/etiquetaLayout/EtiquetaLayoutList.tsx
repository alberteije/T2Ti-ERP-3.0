/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EtiquetaLayoutList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["etiquetaFormatoPapelModel.nome","codigoFabricante","quantidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EtiquetaLayoutSmallScreenList : EtiquetaLayoutBigScreenList;

	return (
		<List
			title="Layout"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EtiquetaLayoutSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.etiquetaFormatoPapelModel.nome }
			secondaryText={ (record) => record.codigoFabricante }
			tertiaryText={ (record) => record.quantidade }
		/>
	);
}

const EtiquetaLayoutBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Formato Papel" source="etiquetaFormatoPapelModel.id" reference="etiqueta-formato-papel" sortable={false}>
				<TextField source="nome" />
			</ReferenceField>
			<TextField source="codigoFabricante" label="Codigo Fabricante" />
			<TextField source="quantidade" label="Quantidade" />
			<TextField source="quantidadeHorizontal" label="Quantidade Horizontal" />
			<TextField source="quantidadeVertical" label="Quantidade Vertical" />
			<TextField source="margemSuperior" label="Margem Superior" />
			<TextField source="margemInferior" label="Margem Inferior" />
			<TextField source="margemEsquerda" label="Margem Esquerda" />
			<TextField source="margemDireita" label="Margem Direita" />
			<TextField source="espacamentoHorizontal" label="Espacamento Horizontal" />
			<TextField source="espacamentoVertical" label="Espacamento Vertical" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EtiquetaLayoutList;
