/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import EtiquetaTemplateDomain from '../../data/domain/EtiquetaTemplateDomain';

class EtiquetaTemplate {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): EtiquetaTemplate {
		const etiquetaTemplate = new EtiquetaTemplate();
		etiquetaTemplate.id = Date.now();
		etiquetaTemplate.statusCrud = "C";
		return etiquetaTemplate;
	}
}

export const EtiquetaTemplateTab: React.FC = () => {

	const renderForm = (
		currentRecord: EtiquetaTemplate,
		setCurrentRecord: (record: EtiquetaTemplate) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'tabela', label: 'Tabela' },
		{ source: 'campo', label: 'Campo' },
		{ source: 'formato', label: 'Formato', formatDomain: EtiquetaTemplateDomain.getFormato },
		{ source: 'quantidadeRepeticoes', label: 'Quantidade Repeticoes' },
		{ source: 'filtro', label: 'Filtro' },
	];

	return (
		<CrudChildTab
			title="Templates"
			recordContext="etiquetaLayout"
			fieldSource="etiquetaTemplateModelList"
			newObject={ EtiquetaTemplate.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};