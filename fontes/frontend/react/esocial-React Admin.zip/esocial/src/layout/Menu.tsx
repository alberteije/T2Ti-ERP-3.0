import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import esocialNaturezaJuridica from '../page/esocialNaturezaJuridica';
import esocialRubrica from '../page/esocialRubrica';
import esocialTipoAfastamento from '../page/esocialTipoAfastamento';
import esocialMotivoDesligamento from '../page/esocialMotivoDesligamento';
import esocialClassificacaoTribut from '../page/esocialClassificacaoTribut';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/esocial-natureza-juridica'
					state={{ _scrollToTop: true }}
					primaryText='Natureza Jurídica'
					leftIcon={<esocialNaturezaJuridica.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/esocial-rubrica'
					state={{ _scrollToTop: true }}
					primaryText='Rubrica'
					leftIcon={<esocialRubrica.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/esocial-tipo-afastamento'
					state={{ _scrollToTop: true }}
					primaryText='Tipo Afastamento'
					leftIcon={<esocialTipoAfastamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/esocial-motivo-desligamento'
					state={{ _scrollToTop: true }}
					primaryText='Motivo Desligamento'
					leftIcon={<esocialMotivoDesligamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/esocial-classificacao-tribut'
					state={{ _scrollToTop: true }}
					primaryText='Classificação Tributária'
					leftIcon={<esocialClassificacaoTribut.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
			</SubMenu>
		</Box>
	);
};

export default Menu;
