/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const EsocialNaturezaJuridicaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["grupo","codigo","descricao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? EsocialNaturezaJuridicaSmallScreenList : EsocialNaturezaJuridicaBigScreenList;

	return (
		<List
			title="Natureza Jurídica"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const EsocialNaturezaJuridicaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.grupo }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.descricao }
		/>
	);
}

const EsocialNaturezaJuridicaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="grupo" label="Grupo" />
			<TextField source="codigo" label="Codigo" />
			<TextField source="descricao" label="Descricao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default EsocialNaturezaJuridicaList;
