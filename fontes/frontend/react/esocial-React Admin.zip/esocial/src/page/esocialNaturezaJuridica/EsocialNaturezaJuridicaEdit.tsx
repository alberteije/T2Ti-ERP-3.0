import {
	Edit,
} from "react-admin";
import { EsocialNaturezaJuridicaForm } from "./EsocialNaturezaJuridicaForm";

const EsocialNaturezaJuridicaEdit = () => {
	return (
		<Edit>
			<EsocialNaturezaJuridicaForm />
		</Edit>
	);
};

export default EsocialNaturezaJuridicaEdit;