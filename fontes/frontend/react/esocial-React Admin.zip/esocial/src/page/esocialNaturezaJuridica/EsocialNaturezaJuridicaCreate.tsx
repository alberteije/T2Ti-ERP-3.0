import {
	Create,
} from "react-admin";
import { EsocialNaturezaJuridicaForm } from "./EsocialNaturezaJuridicaForm";

const EsocialNaturezaJuridicaCreate = () => {
	return (
		<Create>
			<EsocialNaturezaJuridicaForm />
		</Create>
	);
};

export default EsocialNaturezaJuridicaCreate;