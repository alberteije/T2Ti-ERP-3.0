import EsocialNaturezaJuridicaIcon from "@mui/icons-material/Apps";
import EsocialNaturezaJuridicaList from "./EsocialNaturezaJuridicaList";
import EsocialNaturezaJuridicaCreate from "./EsocialNaturezaJuridicaCreate";
import EsocialNaturezaJuridicaEdit from "./EsocialNaturezaJuridicaEdit";

export default {
	list: EsocialNaturezaJuridicaList,
	create: EsocialNaturezaJuridicaCreate,
	edit: EsocialNaturezaJuridicaEdit,
	icon: EsocialNaturezaJuridicaIcon,
};
