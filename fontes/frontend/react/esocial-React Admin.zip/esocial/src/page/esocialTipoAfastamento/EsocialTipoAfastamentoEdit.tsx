import {
	Edit,
} from "react-admin";
import { EsocialTipoAfastamentoForm } from "./EsocialTipoAfastamentoForm";

const EsocialTipoAfastamentoEdit = () => {
	return (
		<Edit>
			<EsocialTipoAfastamentoForm />
		</Edit>
	);
};

export default EsocialTipoAfastamentoEdit;