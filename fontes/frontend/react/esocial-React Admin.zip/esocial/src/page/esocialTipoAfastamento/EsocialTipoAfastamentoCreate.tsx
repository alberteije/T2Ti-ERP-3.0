import {
	Create,
} from "react-admin";
import { EsocialTipoAfastamentoForm } from "./EsocialTipoAfastamentoForm";

const EsocialTipoAfastamentoCreate = () => {
	return (
		<Create>
			<EsocialTipoAfastamentoForm />
		</Create>
	);
};

export default EsocialTipoAfastamentoCreate;