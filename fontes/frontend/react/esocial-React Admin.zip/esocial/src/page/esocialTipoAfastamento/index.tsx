import EsocialTipoAfastamentoIcon from "@mui/icons-material/Apps";
import EsocialTipoAfastamentoList from "./EsocialTipoAfastamentoList";
import EsocialTipoAfastamentoCreate from "./EsocialTipoAfastamentoCreate";
import EsocialTipoAfastamentoEdit from "./EsocialTipoAfastamentoEdit";

export default {
	list: EsocialTipoAfastamentoList,
	create: EsocialTipoAfastamentoCreate,
	edit: EsocialTipoAfastamentoEdit,
	icon: EsocialTipoAfastamentoIcon,
};
