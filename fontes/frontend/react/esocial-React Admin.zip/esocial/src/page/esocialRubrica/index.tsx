import EsocialRubricaIcon from "@mui/icons-material/Apps";
import EsocialRubricaList from "./EsocialRubricaList";
import EsocialRubricaCreate from "./EsocialRubricaCreate";
import EsocialRubricaEdit from "./EsocialRubricaEdit";

export default {
	list: EsocialRubricaList,
	create: EsocialRubricaCreate,
	edit: EsocialRubricaEdit,
	icon: EsocialRubricaIcon,
};
