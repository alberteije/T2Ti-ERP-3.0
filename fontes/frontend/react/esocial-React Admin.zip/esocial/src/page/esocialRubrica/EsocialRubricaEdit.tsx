import {
	Edit,
} from "react-admin";
import { EsocialRubricaForm } from "./EsocialRubricaForm";

const EsocialRubricaEdit = () => {
	return (
		<Edit>
			<EsocialRubricaForm />
		</Edit>
	);
};

export default EsocialRubricaEdit;