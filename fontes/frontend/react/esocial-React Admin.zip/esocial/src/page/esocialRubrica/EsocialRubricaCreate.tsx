import {
	Create,
} from "react-admin";
import { EsocialRubricaForm } from "./EsocialRubricaForm";

const EsocialRubricaCreate = () => {
	return (
		<Create>
			<EsocialRubricaForm />
		</Create>
	);
};

export default EsocialRubricaCreate;