import {
	Edit,
} from "react-admin";
import { EsocialMotivoDesligamentoForm } from "./EsocialMotivoDesligamentoForm";

const EsocialMotivoDesligamentoEdit = () => {
	return (
		<Edit>
			<EsocialMotivoDesligamentoForm />
		</Edit>
	);
};

export default EsocialMotivoDesligamentoEdit;