import {
	Create,
} from "react-admin";
import { EsocialMotivoDesligamentoForm } from "./EsocialMotivoDesligamentoForm";

const EsocialMotivoDesligamentoCreate = () => {
	return (
		<Create>
			<EsocialMotivoDesligamentoForm />
		</Create>
	);
};

export default EsocialMotivoDesligamentoCreate;