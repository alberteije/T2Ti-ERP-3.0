import EsocialMotivoDesligamentoIcon from "@mui/icons-material/Apps";
import EsocialMotivoDesligamentoList from "./EsocialMotivoDesligamentoList";
import EsocialMotivoDesligamentoCreate from "./EsocialMotivoDesligamentoCreate";
import EsocialMotivoDesligamentoEdit from "./EsocialMotivoDesligamentoEdit";

export default {
	list: EsocialMotivoDesligamentoList,
	create: EsocialMotivoDesligamentoCreate,
	edit: EsocialMotivoDesligamentoEdit,
	icon: EsocialMotivoDesligamentoIcon,
};
