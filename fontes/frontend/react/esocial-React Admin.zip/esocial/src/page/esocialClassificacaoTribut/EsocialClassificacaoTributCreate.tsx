import {
	Create,
} from "react-admin";
import { EsocialClassificacaoTributForm } from "./EsocialClassificacaoTributForm";

const EsocialClassificacaoTributCreate = () => {
	return (
		<Create>
			<EsocialClassificacaoTributForm />
		</Create>
	);
};

export default EsocialClassificacaoTributCreate;