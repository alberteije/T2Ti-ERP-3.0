import {
	Edit,
} from "react-admin";
import { EsocialClassificacaoTributForm } from "./EsocialClassificacaoTributForm";

const EsocialClassificacaoTributEdit = () => {
	return (
		<Edit>
			<EsocialClassificacaoTributForm />
		</Edit>
	);
};

export default EsocialClassificacaoTributEdit;