import EsocialClassificacaoTributIcon from "@mui/icons-material/Apps";
import EsocialClassificacaoTributList from "./EsocialClassificacaoTributList";
import EsocialClassificacaoTributCreate from "./EsocialClassificacaoTributCreate";
import EsocialClassificacaoTributEdit from "./EsocialClassificacaoTributEdit";

export default {
	list: EsocialClassificacaoTributList,
	create: EsocialClassificacaoTributCreate,
	edit: EsocialClassificacaoTributEdit,
	icon: EsocialClassificacaoTributIcon,
};
