import WmsRecebimentoCabecalhoIcon from "@mui/icons-material/Apps";
import WmsRecebimentoCabecalhoList from "./WmsRecebimentoCabecalhoList";
import WmsRecebimentoCabecalhoCreate from "./WmsRecebimentoCabecalhoCreate";
import WmsRecebimentoCabecalhoEdit from "./WmsRecebimentoCabecalhoEdit";

export default {
	list: WmsRecebimentoCabecalhoList,
	create: WmsRecebimentoCabecalhoCreate,
	edit: WmsRecebimentoCabecalhoEdit,
	icon: WmsRecebimentoCabecalhoIcon,
};
