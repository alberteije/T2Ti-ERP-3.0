/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { WmsRecebimentoCabecalhoForm } from "./WmsRecebimentoCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const WmsRecebimentoCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<WmsRecebimentoCabecalhoForm />
		</Edit>
	);
};

export default WmsRecebimentoCabecalhoEdit;