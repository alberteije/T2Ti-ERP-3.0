/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';
import WmsRecebimentoCabecalhoDomain from '../../data/domain/WmsRecebimentoCabecalhoDomain';

const WmsRecebimentoCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["wmsAgendamentoModel.local_operacao","dataRecebimento","horaInicio"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsRecebimentoCabecalhoSmallScreenList : WmsRecebimentoCabecalhoBigScreenList;

	return (
		<List
			title="Recebimento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsRecebimentoCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.wmsAgendamentoModel.local_operacao }
			secondaryText={ (record) => record.dataRecebimento }
			tertiaryText={ (record) => record.horaInicio }
		/>
	);
}

const WmsRecebimentoCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Wms Agendamento" source="wmsAgendamentoModel.id" reference="wms-agendamento" sortable={false}>
				<TextField source="local_operacao" />
			</ReferenceField>
			<TextField source="dataRecebimento" label="Data Recebimento" />
			<FunctionField
				source="horaInicio"
				label="Hora Inicio"
				render={record => formatWithMask(record.horaInicio, '##:##:##')}
			/>
			<FunctionField
				source="horaFim"
				label="Hora Fim"
				render={record => formatWithMask(record.horaFim, '##:##:##')}
			/>
			<TextField source="volumeRecebido" label="Volume Recebido" />
			<NumberField source="pesoRecebido" label="Peso Recebido" options={{
				minimumFractionDigits: 2
			}} />
			<FunctionField
				label="Inconsistencia"
				render={record => WmsRecebimentoCabecalhoDomain.getInconsistencia(record.inconsistencia)}
			/>
			<TextField source="observacao" label="Observacao" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsRecebimentoCabecalhoList;
