/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';
import WmsRecebimentoDetalheDomain from '../../data/domain/WmsRecebimentoDetalheDomain';

class WmsRecebimentoDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): WmsRecebimentoDetalhe {
		const wmsRecebimentoDetalhe = new WmsRecebimentoDetalhe();
		wmsRecebimentoDetalhe.id = Date.now();
		wmsRecebimentoDetalhe.statusCrud = "C";
		return wmsRecebimentoDetalhe;
	}
}

export const WmsRecebimentoDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: WmsRecebimentoDetalhe,
		setCurrentRecord: (record: WmsRecebimentoDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidadeVolume', label: 'Quantidade Volume' },
		{ source: 'quantidadeItemPorVolume', label: 'Quantidade Item Por Volume' },
		{ source: 'quantidadeRecebida', label: 'Quantidade Recebida' },
		{ source: 'destino', label: 'Destino', formatDomain: WmsRecebimentoDetalheDomain.getDestino },
	];

	return (
		<CrudChildTab
			title="Itens"
			recordContext="wmsRecebimentoCabecalho"
			fieldSource="wmsRecebimentoDetalheModelList"
			newObject={ WmsRecebimentoDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};