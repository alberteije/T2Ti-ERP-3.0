/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class WmsArmazenamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): WmsArmazenamento {
		const wmsArmazenamento = new WmsArmazenamento();
		wmsArmazenamento.id = Date.now();
		wmsArmazenamento.statusCrud = "C";
		return wmsArmazenamento;
	}
}

export const WmsArmazenamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: WmsArmazenamento,
		setCurrentRecord: (record: WmsArmazenamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'wmsRecebimentoDetalheModel.id', label: 'Item Recebimento', reference: 'wms-recebimento-detalhe', fieldName: 'id' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Armazenamento"
			recordContext="wmsCaixa"
			fieldSource="wmsArmazenamentoModelList"
			newObject={ WmsArmazenamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};