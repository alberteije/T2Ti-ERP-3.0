/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { WmsCaixaForm } from "./WmsCaixaForm";
import { transformNestedData } from "../../infra/utils";

const WmsCaixaCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<WmsCaixaForm />
		</Create>
	);
};

export default WmsCaixaCreate;