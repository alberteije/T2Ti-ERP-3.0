/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { WmsCaixaForm } from "./WmsCaixaForm";
import { transformNestedData } from "../../infra/utils";

const WmsCaixaEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<WmsCaixaForm />
		</Edit>
	);
};

export default WmsCaixaEdit;