/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const WmsCaixaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["wmsEstanteModel.codigo","codigo","altura"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsCaixaSmallScreenList : WmsCaixaBigScreenList;

	return (
		<List
			title="Caixa"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsCaixaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.wmsEstanteModel.codigo }
			secondaryText={ (record) => record.codigo }
			tertiaryText={ (record) => record.altura }
		/>
	);
}

const WmsCaixaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Wms Estante" source="wmsEstanteModel.id" reference="wms-estante" sortable={false}>
				<TextField source="codigo" />
			</ReferenceField>
			<TextField source="codigo" label="Codigo" />
			<TextField source="altura" label="Altura" />
			<TextField source="largura" label="Largura" />
			<TextField source="profundidade" label="Profundidade" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsCaixaList;
