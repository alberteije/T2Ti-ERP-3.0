import WmsCaixaIcon from "@mui/icons-material/Apps";
import WmsCaixaList from "./WmsCaixaList";
import WmsCaixaCreate from "./WmsCaixaCreate";
import WmsCaixaEdit from "./WmsCaixaEdit";

export default {
	list: WmsCaixaList,
	create: WmsCaixaCreate,
	edit: WmsCaixaEdit,
	icon: WmsCaixaIcon,
};
