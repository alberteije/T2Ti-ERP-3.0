import {
	Edit,
} from "react-admin";
import { WmsAgendamentoForm } from "./WmsAgendamentoForm";

const WmsAgendamentoEdit = () => {
	return (
		<Edit>
			<WmsAgendamentoForm />
		</Edit>
	);
};

export default WmsAgendamentoEdit;