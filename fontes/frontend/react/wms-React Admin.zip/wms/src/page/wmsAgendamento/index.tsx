import WmsAgendamentoIcon from "@mui/icons-material/Apps";
import WmsAgendamentoList from "./WmsAgendamentoList";
import WmsAgendamentoCreate from "./WmsAgendamentoCreate";
import WmsAgendamentoEdit from "./WmsAgendamentoEdit";

export default {
	list: WmsAgendamentoList,
	create: WmsAgendamentoCreate,
	edit: WmsAgendamentoEdit,
	icon: WmsAgendamentoIcon,
};
