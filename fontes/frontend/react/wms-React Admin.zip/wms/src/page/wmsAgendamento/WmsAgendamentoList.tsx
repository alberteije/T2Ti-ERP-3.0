/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import { formatWithMask } from '../../infra/utils';

const WmsAgendamentoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataOperacao","horaOperacao","localOperacao"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsAgendamentoSmallScreenList : WmsAgendamentoBigScreenList;

	return (
		<List
			title="Agendamento"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsAgendamentoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataOperacao }
			secondaryText={ (record) => record.horaOperacao }
			tertiaryText={ (record) => record.localOperacao }
		/>
	);
}

const WmsAgendamentoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataOperacao" label="Data Operacao" />
			<FunctionField
				source="horaOperacao"
				label="Hora Operacao"
				render={record => formatWithMask(record.horaOperacao, '##:##:##')}
			/>
			<TextField source="localOperacao" label="Local Operacao" />
			<TextField source="quantidadeVolume" label="Quantidade Volume" />
			<NumberField source="pesoTotalVolume" label="Peso Total Volume" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="quantidadePessoa" label="Quantidade Pessoa" />
			<TextField source="quantidadeHora" label="Quantidade Hora" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsAgendamentoList;
