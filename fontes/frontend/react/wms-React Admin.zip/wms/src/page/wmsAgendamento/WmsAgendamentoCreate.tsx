import {
	Create,
} from "react-admin";
import { WmsAgendamentoForm } from "./WmsAgendamentoForm";

const WmsAgendamentoCreate = () => {
	return (
		<Create>
			<WmsAgendamentoForm />
		</Create>
	);
};

export default WmsAgendamentoCreate;