/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const WmsExpedicaoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["wmsOrdemSeparacaoDetModel.id","wmsArmazenamentoModel.id","quantidade"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsExpedicaoSmallScreenList : WmsExpedicaoBigScreenList;

	return (
		<List
			title="Expedição"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsExpedicaoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.wmsOrdemSeparacaoDetModel.id }
			secondaryText={ (record) => record.wmsArmazenamentoModel.id }
			tertiaryText={ (record) => record.quantidade }
		/>
	);
}

const WmsExpedicaoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Wms Ordem Separacao Det" source="wmsOrdemSeparacaoDetModel.id" reference="wms-ordem-separacao-det" sortable={false}>
				<TextField source="id" />
			</ReferenceField>
			<ReferenceField label="Id Wms Armazenamento" source="wmsArmazenamentoModel.id" reference="wms-armazenamento" sortable={false}>
				<TextField source="id" />
			</ReferenceField>
			<TextField source="quantidade" label="Quantidade" />
			<TextField source="dataSaida" label="Data Saida" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsExpedicaoList;
