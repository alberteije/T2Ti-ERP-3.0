import {
	Create,
} from "react-admin";
import { WmsExpedicaoForm } from "./WmsExpedicaoForm";

const WmsExpedicaoCreate = () => {
	return (
		<Create>
			<WmsExpedicaoForm />
		</Create>
	);
};

export default WmsExpedicaoCreate;