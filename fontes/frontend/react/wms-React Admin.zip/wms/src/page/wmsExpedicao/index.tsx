import WmsExpedicaoIcon from "@mui/icons-material/Apps";
import WmsExpedicaoList from "./WmsExpedicaoList";
import WmsExpedicaoCreate from "./WmsExpedicaoCreate";
import WmsExpedicaoEdit from "./WmsExpedicaoEdit";

export default {
	list: WmsExpedicaoList,
	create: WmsExpedicaoCreate,
	edit: WmsExpedicaoEdit,
	icon: WmsExpedicaoIcon,
};
