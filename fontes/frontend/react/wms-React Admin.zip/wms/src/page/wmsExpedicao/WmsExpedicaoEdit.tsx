import {
	Edit,
} from "react-admin";
import { WmsExpedicaoForm } from "./WmsExpedicaoForm";

const WmsExpedicaoEdit = () => {
	return (
		<Edit>
			<WmsExpedicaoForm />
		</Edit>
	);
};

export default WmsExpedicaoEdit;