import WmsEstanteIcon from "@mui/icons-material/Apps";
import WmsEstanteList from "./WmsEstanteList";
import WmsEstanteCreate from "./WmsEstanteCreate";
import WmsEstanteEdit from "./WmsEstanteEdit";

export default {
	list: WmsEstanteList,
	create: WmsEstanteCreate,
	edit: WmsEstanteEdit,
	icon: WmsEstanteIcon,
};
