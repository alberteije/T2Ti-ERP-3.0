import {
	Edit,
} from "react-admin";
import { WmsEstanteForm } from "./WmsEstanteForm";

const WmsEstanteEdit = () => {
	return (
		<Edit>
			<WmsEstanteForm />
		</Edit>
	);
};

export default WmsEstanteEdit;