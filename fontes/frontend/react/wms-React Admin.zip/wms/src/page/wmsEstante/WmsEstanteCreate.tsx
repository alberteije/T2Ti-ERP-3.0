import {
	Create,
} from "react-admin";
import { WmsEstanteForm } from "./WmsEstanteForm";

const WmsEstanteCreate = () => {
	return (
		<Create>
			<WmsEstanteForm />
		</Create>
	);
};

export default WmsEstanteCreate;