import {
	Edit,
} from "react-admin";
import { WmsRuaForm } from "./WmsRuaForm";

const WmsRuaEdit = () => {
	return (
		<Edit>
			<WmsRuaForm />
		</Edit>
	);
};

export default WmsRuaEdit;