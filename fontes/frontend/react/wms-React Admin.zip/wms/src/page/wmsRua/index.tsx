import WmsRuaIcon from "@mui/icons-material/Apps";
import WmsRuaList from "./WmsRuaList";
import WmsRuaCreate from "./WmsRuaCreate";
import WmsRuaEdit from "./WmsRuaEdit";

export default {
	list: WmsRuaList,
	create: WmsRuaCreate,
	edit: WmsRuaEdit,
	icon: WmsRuaIcon,
};
