/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const WmsRuaList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["codigo","quantidadeEstante","nome"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsRuaSmallScreenList : WmsRuaBigScreenList;

	return (
		<List
			title="Rua"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsRuaSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.codigo }
			secondaryText={ (record) => record.quantidadeEstante }
			tertiaryText={ (record) => record.nome }
		/>
	);
}

const WmsRuaBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="codigo" label="Codigo" />
			<TextField source="quantidadeEstante" label="Quantidade Estante" />
			<TextField source="nome" label="Nome" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsRuaList;
