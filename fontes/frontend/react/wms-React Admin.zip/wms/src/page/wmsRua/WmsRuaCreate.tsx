import {
	Create,
} from "react-admin";
import { WmsRuaForm } from "./WmsRuaForm";

const WmsRuaCreate = () => {
	return (
		<Create>
			<WmsRuaForm />
		</Create>
	);
};

export default WmsRuaCreate;