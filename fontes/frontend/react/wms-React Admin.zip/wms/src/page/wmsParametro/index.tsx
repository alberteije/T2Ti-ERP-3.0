import WmsParametroIcon from "@mui/icons-material/Apps";
import WmsParametroList from "./WmsParametroList";
import WmsParametroCreate from "./WmsParametroCreate";
import WmsParametroEdit from "./WmsParametroEdit";

export default {
	list: WmsParametroList,
	create: WmsParametroCreate,
	edit: WmsParametroEdit,
	icon: WmsParametroIcon,
};
