/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	FunctionField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import WmsParametroDomain from '../../data/domain/WmsParametroDomain';

const WmsParametroList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["horaPorVolume","pessoaPorVolume","horaPorPeso"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsParametroSmallScreenList : WmsParametroBigScreenList;

	return (
		<List
			title="Parâmetros"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsParametroSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.horaPorVolume }
			secondaryText={ (record) => record.pessoaPorVolume }
			tertiaryText={ (record) => record.horaPorPeso }
		/>
	);
}

const WmsParametroBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="horaPorVolume" label="Hora Por Volume" />
			<TextField source="pessoaPorVolume" label="Pessoa Por Volume" />
			<TextField source="horaPorPeso" label="Hora Por Peso" />
			<TextField source="pessoaPorPeso" label="Pessoa Por Peso" />
			<FunctionField
				label="Item Diferente Caixa"
				render={record => WmsParametroDomain.getItemDiferenteCaixa(record.itemDiferenteCaixa)}
			/>
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsParametroList;
