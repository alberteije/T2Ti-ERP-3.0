import {
	Create,
} from "react-admin";
import { WmsParametroForm } from "./WmsParametroForm";

const WmsParametroCreate = () => {
	return (
		<Create>
			<WmsParametroForm />
		</Create>
	);
};

export default WmsParametroCreate;