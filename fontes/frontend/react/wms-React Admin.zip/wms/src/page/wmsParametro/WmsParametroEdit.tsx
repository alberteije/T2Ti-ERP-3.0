import {
	Edit,
} from "react-admin";
import { WmsParametroForm } from "./WmsParametroForm";

const WmsParametroEdit = () => {
	return (
		<Edit>
			<WmsParametroForm />
		</Edit>
	);
};

export default WmsParametroEdit;