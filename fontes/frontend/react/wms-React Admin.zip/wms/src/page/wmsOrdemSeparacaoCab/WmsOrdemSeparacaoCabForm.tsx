/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { WmsOrdemSeparacaoDetTab } from './WmsOrdemSeparacaoDetTab';

export const WmsOrdemSeparacaoCabForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Ordem Separação">
				<WmsOrdemSeparacaoCabTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens">
				<WmsOrdemSeparacaoDetTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const WmsOrdemSeparacaoCabTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};