/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class WmsOrdemSeparacaoDet {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): WmsOrdemSeparacaoDet {
		const wmsOrdemSeparacaoDet = new WmsOrdemSeparacaoDet();
		wmsOrdemSeparacaoDet.id = Date.now();
		wmsOrdemSeparacaoDet.statusCrud = "C";
		return wmsOrdemSeparacaoDet;
	}
}

export const WmsOrdemSeparacaoDetTab: React.FC = () => {

	const renderForm = (
		currentRecord: WmsOrdemSeparacaoDet,
		setCurrentRecord: (record: WmsOrdemSeparacaoDet) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidade', label: 'Quantidade' },
	];

	return (
		<CrudChildTab
			title="Itens"
			recordContext="wmsOrdemSeparacaoCab"
			fieldSource="wmsOrdemSeparacaoDetModelList"
			newObject={ WmsOrdemSeparacaoDet.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};