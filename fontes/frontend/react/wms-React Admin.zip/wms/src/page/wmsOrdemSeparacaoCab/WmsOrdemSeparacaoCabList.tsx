/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	FunctionField,
	TextField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";
import WmsOrdemSeparacaoCabDomain from '../../data/domain/WmsOrdemSeparacaoCabDomain';

const WmsOrdemSeparacaoCabList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["origem","dataSolicitacao","dataLimite"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? WmsOrdemSeparacaoCabSmallScreenList : WmsOrdemSeparacaoCabBigScreenList;

	return (
		<List
			title="Ordem Separação"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const WmsOrdemSeparacaoCabSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.origem }
			secondaryText={ (record) => record.dataSolicitacao }
			tertiaryText={ (record) => record.dataLimite }
		/>
	);
}

const WmsOrdemSeparacaoCabBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<FunctionField
				label="Origem"
				render={record => WmsOrdemSeparacaoCabDomain.getOrigem(record.origem)}
			/>
			<TextField source="dataSolicitacao" label="Data Solicitacao" />
			<TextField source="dataLimite" label="Data Limite" />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default WmsOrdemSeparacaoCabList;
