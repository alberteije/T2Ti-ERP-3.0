/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { WmsOrdemSeparacaoCabForm } from "./WmsOrdemSeparacaoCabForm";
import { transformNestedData } from "../../infra/utils";

const WmsOrdemSeparacaoCabCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<WmsOrdemSeparacaoCabForm />
		</Create>
	);
};

export default WmsOrdemSeparacaoCabCreate;