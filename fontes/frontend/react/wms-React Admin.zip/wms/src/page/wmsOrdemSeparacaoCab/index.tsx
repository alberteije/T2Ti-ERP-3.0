import WmsOrdemSeparacaoCabIcon from "@mui/icons-material/Apps";
import WmsOrdemSeparacaoCabList from "./WmsOrdemSeparacaoCabList";
import WmsOrdemSeparacaoCabCreate from "./WmsOrdemSeparacaoCabCreate";
import WmsOrdemSeparacaoCabEdit from "./WmsOrdemSeparacaoCabEdit";

export default {
	list: WmsOrdemSeparacaoCabList,
	create: WmsOrdemSeparacaoCabCreate,
	edit: WmsOrdemSeparacaoCabEdit,
	icon: WmsOrdemSeparacaoCabIcon,
};
