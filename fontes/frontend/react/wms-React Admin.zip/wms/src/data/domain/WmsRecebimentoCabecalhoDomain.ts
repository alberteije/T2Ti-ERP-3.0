class WmsRecebimentoCabecalhoDomain {
	static getInconsistencia(inconsistencia: string) { 
		switch (inconsistencia) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setInconsistencia(inconsistencia: string) { 
		switch (inconsistencia) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default WmsRecebimentoCabecalhoDomain;