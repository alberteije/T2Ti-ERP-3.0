class WmsParametroDomain {
	static getItemDiferenteCaixa(itemDiferenteCaixa: string) { 
		switch (itemDiferenteCaixa) { 
			case '': 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	} 

	static setItemDiferenteCaixa(itemDiferenteCaixa: string) { 
		switch (itemDiferenteCaixa) { 
			case 'S': 
				return 'S'; 
			case 'N': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}

export default WmsParametroDomain;