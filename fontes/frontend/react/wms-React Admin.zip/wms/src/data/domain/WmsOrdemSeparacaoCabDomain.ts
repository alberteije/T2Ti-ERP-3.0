class WmsOrdemSeparacaoCabDomain {
	static getOrigem(origem: string) { 
		switch (origem) { 
			case '': 
			case 'P': 
				return 'Produção'; 
			case 'M': 
				return 'Matriz'; 
			case 'F': 
				return 'Filial'; 
			default: 
				return null; 
		} 
	} 

	static setOrigem(origem: string) { 
		switch (origem) { 
			case 'Produção': 
				return 'P'; 
			case 'Matriz': 
				return 'M'; 
			case 'Filial': 
				return 'F'; 
			default: 
				return null; 
		} 
	}

}

export default WmsOrdemSeparacaoCabDomain;