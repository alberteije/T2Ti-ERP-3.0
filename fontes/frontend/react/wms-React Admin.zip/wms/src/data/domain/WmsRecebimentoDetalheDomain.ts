class WmsRecebimentoDetalheDomain {
	static getDestino(destino: string) { 
		switch (destino) { 
			case '': 
			case 'A': 
				return 'Armazenamento'; 
			case 'E': 
				return 'Expedição'; 
			case 'P': 
				return 'Produção'; 
			default: 
				return null; 
		} 
	} 

	static setDestino(destino: string) { 
		switch (destino) { 
			case 'Armazenamento': 
				return 'A'; 
			case 'Expedição': 
				return 'E'; 
			case 'Produção': 
				return 'P'; 
			default: 
				return null; 
		} 
	}

}

export default WmsRecebimentoDetalheDomain;