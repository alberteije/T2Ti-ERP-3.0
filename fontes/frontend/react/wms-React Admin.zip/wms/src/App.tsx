import polyglotI18nProvider from 'ra-i18n-polyglot';
import {
	Admin,
	Resource,
	useStore,
	localStorageStore,
	StoreContextProvider,
} from "react-admin";
import englishMessages from './translations/en';
import { Layout, Login } from './layout';
import { authProvider } from './authProvider';
import { dataProvider } from './data/remoteDataProvider';
import { ThemeName, themes } from './themes/themes';
import { Dashboard } from './page/dashboard';
import wmsRecebimentoCabecalho from './page/wmsRecebimentoCabecalho';
import wmsCaixa from './page/wmsCaixa';
import wmsOrdemSeparacaoCab from './page/wmsOrdemSeparacaoCab';
import wmsAgendamento from './page/wmsAgendamento';
import wmsParametro from './page/wmsParametro';
import wmsRua from './page/wmsRua';
import wmsEstante from './page/wmsEstante';
import wmsExpedicao from './page/wmsExpedicao';

const i18nProvider = polyglotI18nProvider(
	locale => {
		if (locale === 'pt-br') {
			return import('./translations/pt-br').then(messages => messages.default);
		}

		// Always fallback on english
		return englishMessages;
	},
	'en',
	[
		{ locale: 'en', name: 'English' },
		{ locale: 'pt-br', name: 'Português Brasil' },
	]
);

const store = localStorageStore(undefined, 'wms');

const App = () => {
	const [themeName] = useStore<ThemeName>('themeName', 'soft');
	const lightTheme = themes.find(theme => theme.name === themeName)?.light;
	const darkTheme = themes.find(theme => theme.name === themeName)?.dark;

	return (
		<Admin
			title="T2Ti ERP 3.0 - WMS (com.t2ti)"
			dataProvider={dataProvider}
			store={store}
			authProvider={authProvider}
			dashboard={Dashboard}
			loginPage={Login}
			layout={Layout}
			i18nProvider={i18nProvider}
			disableTelemetry
			lightTheme={lightTheme}
			darkTheme={darkTheme}
			defaultTheme="light"
		>

			<Resource name='wms-recebimento-cabecalho' {...wmsRecebimentoCabecalho} options={{ label: 'Recebimento' }} />
			<Resource name='wms-caixa' {...wmsCaixa} options={{ label: 'Caixa' }} />
			<Resource name='wms-ordem-separacao-cab' {...wmsOrdemSeparacaoCab} options={{ label: 'Ordem Separação' }} />
			<Resource name='wms-agendamento' {...wmsAgendamento} options={{ label: 'Agendamento' }} />
			<Resource name='wms-parametro' {...wmsParametro} options={{ label: 'Parâmetros' }} />
			<Resource name='wms-rua' {...wmsRua} options={{ label: 'Rua' }} />
			<Resource name='wms-estante' {...wmsEstante} options={{ label: 'Estante' }} />
			<Resource name='wms-expedicao' {...wmsExpedicao} options={{ label: 'Expedição' }} />
		</Admin>
	);
};

const AppWrapper = () => (
	<StoreContextProvider value={store}>
		<App />
	</StoreContextProvider>
);

export default AppWrapper;