import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import wmsRecebimentoCabecalho from '../page/wmsRecebimentoCabecalho';
import wmsCaixa from '../page/wmsCaixa';
import wmsOrdemSeparacaoCab from '../page/wmsOrdemSeparacaoCab';
import wmsAgendamento from '../page/wmsAgendamento';
import wmsParametro from '../page/wmsParametro';
import wmsRua from '../page/wmsRua';
import wmsEstante from '../page/wmsEstante';
import wmsExpedicao from '../page/wmsExpedicao';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/wms-agendamento'
					state={{ _scrollToTop: true }}
					primaryText='Agendamento'
					leftIcon={<wmsAgendamento.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-parametro'
					state={{ _scrollToTop: true }}
					primaryText='Parâmetros'
					leftIcon={<wmsParametro.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-rua'
					state={{ _scrollToTop: true }}
					primaryText='Rua'
					leftIcon={<wmsRua.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-estante'
					state={{ _scrollToTop: true }}
					primaryText='Estante'
					leftIcon={<wmsEstante.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-expedicao'
					state={{ _scrollToTop: true }}
					primaryText='Expedição'
					leftIcon={<wmsExpedicao.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/wms-recebimento-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Recebimento'
					leftIcon={<wmsRecebimentoCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-caixa'
					state={{ _scrollToTop: true }}
					primaryText='Caixa'
					leftIcon={<wmsCaixa.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/wms-ordem-separacao-cab'
					state={{ _scrollToTop: true }}
					primaryText='Ordem Separação'
					leftIcon={<wmsOrdemSeparacaoCab.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
