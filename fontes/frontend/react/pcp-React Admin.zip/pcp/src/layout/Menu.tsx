import { useState } from 'react';
import { Box } from '@mui/material';
import ChevronRight from '@mui/icons-material/ChevronRight'

import {
	DashboardMenuItem,
	MenuItemLink,
	MenuProps,
	useSidebarState,
} from 'react-admin';
import SubMenu from './SubMenu';

import pcpOpCabecalho from '../page/pcpOpCabecalho';
import pcpServico from '../page/pcpServico';
import pcpInstrucao from '../page/pcpInstrucao';

type MenuName = 'menuSimple' | 'menuMasterDetail';

const Menu = ({ dense = false }: MenuProps) => {
	const [state, setState] = useState({
		menuSimple: true,
		menuMasterDetail: true,
	});
	const [open] = useSidebarState();

	const handleToggle = (menu: MenuName) => {
		setState(state => ({ ...state, [menu]: !state[menu] }));
	};
	return (
		<Box
			sx={{
				width: open ? 300 : 50,
				marginTop: 1,
				marginBottom: 1,
				transition: theme =>
					theme.transitions.create('width', {
						easing: theme.transitions.easing.sharp,
						duration: theme.transitions.duration.leavingScreen,
					}),
			}}
		>
			<DashboardMenuItem />
			<SubMenu
				handleToggle={() => handleToggle('menuSimple')}
				isOpen={state.menuSimple}
				name='menu.single_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/pcp-instrucao'
					state={{ _scrollToTop: true }}
					primaryText='Instruções'
					leftIcon={<pcpInstrucao.icon />}
					dense={dense}
				/>

			</SubMenu>
			<SubMenu
				handleToggle={() => handleToggle('menuMasterDetail')}
				isOpen={state.menuMasterDetail}
				name='menu.master_page'
				icon=<ChevronRight />
				dense={dense}
			>
				<MenuItemLink
					to='/pcp-op-cabecalho'
					state={{ _scrollToTop: true }}
					primaryText='Ordem de Produção'
					leftIcon={<pcpOpCabecalho.icon />}
					dense={dense}
				/>

				<MenuItemLink
					to='/pcp-servico'
					state={{ _scrollToTop: true }}
					primaryText='Serviços'
					leftIcon={<pcpServico.icon />}
					dense={dense}
				/>

			</SubMenu>
		</Box>
	);
};

export default Menu;
