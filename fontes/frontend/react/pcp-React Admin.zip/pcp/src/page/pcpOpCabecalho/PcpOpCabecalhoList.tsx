/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PcpOpCabecalhoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["dataInicio","dataPrevisaoEntrega","dataTermino"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PcpOpCabecalhoSmallScreenList : PcpOpCabecalhoBigScreenList;

	return (
		<List
			title="Ordem de Produção"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PcpOpCabecalhoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.dataInicio }
			secondaryText={ (record) => record.dataPrevisaoEntrega }
			tertiaryText={ (record) => record.dataTermino }
		/>
	);
}

const PcpOpCabecalhoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<TextField source="dataInicio" label="Data Inicio" />
			<TextField source="dataPrevisaoEntrega" label="Data Previsao Entrega" />
			<TextField source="dataTermino" label="Data Termino" />
			<NumberField source="custoTotalPrevisto" label="Custo Total Previsto" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="custoTotalRealizado" label="Custo Total Realizado" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="porcentoVenda" label="Porcento Venda" options={{
				minimumFractionDigits: 2
			}} />
			<NumberField source="porcentoEstoque" label="Porcento Estoque" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PcpOpCabecalhoList;
