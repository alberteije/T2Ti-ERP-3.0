/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PcpOpCabecalhoForm } from "./PcpOpCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const PcpOpCabecalhoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PcpOpCabecalhoForm />
		</Edit>
	);
};

export default PcpOpCabecalhoEdit;