/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PcpOpCabecalhoForm } from "./PcpOpCabecalhoForm";
import { transformNestedData } from "../../infra/utils";

const PcpOpCabecalhoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PcpOpCabecalhoForm />
		</Create>
	);
};

export default PcpOpCabecalhoCreate;