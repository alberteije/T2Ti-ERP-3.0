import PcpOpCabecalhoIcon from "@mui/icons-material/Apps";
import PcpOpCabecalhoList from "./PcpOpCabecalhoList";
import PcpOpCabecalhoCreate from "./PcpOpCabecalhoCreate";
import PcpOpCabecalhoEdit from "./PcpOpCabecalhoEdit";

export default {
	list: PcpOpCabecalhoList,
	create: PcpOpCabecalhoCreate,
	edit: PcpOpCabecalhoEdit,
	icon: PcpOpCabecalhoIcon,
};
