/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PcpOpDetalheTab } from './PcpOpDetalheTab';
import { PcpInstrucaoOpTab } from './PcpInstrucaoOpTab';

export const PcpOpCabecalhoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Ordem de Produção">
				<PcpOpCabecalhoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Itens">
				<PcpOpDetalheTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Instruções">
				<PcpInstrucaoOpTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PcpOpCabecalhoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};