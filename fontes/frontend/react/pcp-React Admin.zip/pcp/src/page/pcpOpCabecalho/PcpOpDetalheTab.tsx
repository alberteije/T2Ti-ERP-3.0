/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PcpOpDetalhe {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PcpOpDetalhe {
		const pcpOpDetalhe = new PcpOpDetalhe();
		pcpOpDetalhe.id = Date.now();
		pcpOpDetalhe.statusCrud = "C";
		return pcpOpDetalhe;
	}
}

export const PcpOpDetalheTab: React.FC = () => {

	const renderForm = (
		currentRecord: PcpOpDetalhe,
		setCurrentRecord: (record: PcpOpDetalhe) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'produtoModel.id', label: 'Produto', reference: 'produto', fieldName: 'nome' },
		{ source: 'quantidadeProduzir', label: 'Quantidade Produzir' },
		{ source: 'quantidadeProduzida', label: 'Quantidade Produzida' },
		{ source: 'quantidadeEntregue', label: 'Quantidade Entregue' },
		{ source: 'custoPrevisto', label: 'Custo Previsto' },
		{ source: 'custoRealizado', label: 'Custo Realizado' },
	];

	return (
		<CrudChildTab
			title="Itens"
			recordContext="pcpOpCabecalho"
			fieldSource="pcpOpDetalheModelList"
			newObject={ PcpOpDetalhe.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};