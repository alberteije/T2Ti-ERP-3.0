/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PcpInstrucaoOp {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PcpInstrucaoOp {
		const pcpInstrucaoOp = new PcpInstrucaoOp();
		pcpInstrucaoOp.id = Date.now();
		pcpInstrucaoOp.statusCrud = "C";
		return pcpInstrucaoOp;
	}
}

export const PcpInstrucaoOpTab: React.FC = () => {

	const renderForm = (
		currentRecord: PcpInstrucaoOp,
		setCurrentRecord: (record: PcpInstrucaoOp) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'pcpInstrucaoModel.id', label: 'Instrucao', reference: 'pcp-instrucao', fieldName: 'descricao' },
	];

	return (
		<CrudChildTab
			title="Instruções"
			recordContext="pcpOpCabecalho"
			fieldSource="pcpInstrucaoOpModelList"
			newObject={ PcpInstrucaoOp.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};