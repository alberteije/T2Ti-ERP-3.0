/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PcpServicoColaborador {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PcpServicoColaborador {
		const pcpServicoColaborador = new PcpServicoColaborador();
		pcpServicoColaborador.id = Date.now();
		pcpServicoColaborador.statusCrud = "C";
		return pcpServicoColaborador;
	}
}

export const PcpServicoColaboradorTab: React.FC = () => {

	const renderForm = (
		currentRecord: PcpServicoColaborador,
		setCurrentRecord: (record: PcpServicoColaborador) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'viewPessoaColaboradorModel.id', label: 'Colaborador', reference: 'view-pessoa-colaborador', fieldName: 'nome' },
	];

	return (
		<CrudChildTab
			title="Colaboradores"
			recordContext="pcpServico"
			fieldSource="pcpServicoColaboradorModelList"
			newObject={ PcpServicoColaborador.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};