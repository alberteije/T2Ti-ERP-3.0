/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Edit,
} from "react-admin";
import { PcpServicoForm } from "./PcpServicoForm";
import { transformNestedData } from "../../infra/utils";

const PcpServicoEdit = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Edit transform={transform}>
			<PcpServicoForm />
		</Edit>
	);
};

export default PcpServicoEdit;