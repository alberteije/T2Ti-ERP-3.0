import PcpServicoIcon from "@mui/icons-material/Apps";
import PcpServicoList from "./PcpServicoList";
import PcpServicoCreate from "./PcpServicoCreate";
import PcpServicoEdit from "./PcpServicoEdit";

export default {
	list: PcpServicoList,
	create: PcpServicoCreate,
	edit: PcpServicoEdit,
	icon: PcpServicoIcon,
};
