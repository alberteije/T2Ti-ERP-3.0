/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {
} from 'react-admin';
import { Box } from '@mui/material';
import CrudChildTab from '../sharedComponents/CrudChildTab';

class PcpServicoEquipamento {
	constructor(
		public id = 0,
		public statusCrud = '', // CRUD
	) { }

	static newObject(): PcpServicoEquipamento {
		const pcpServicoEquipamento = new PcpServicoEquipamento();
		pcpServicoEquipamento.id = Date.now();
		pcpServicoEquipamento.statusCrud = "C";
		return pcpServicoEquipamento;
	}
}

export const PcpServicoEquipamentoTab: React.FC = () => {

	const renderForm = (
		currentRecord: PcpServicoEquipamento,
		setCurrentRecord: (record: PcpServicoEquipamento) => void,
	) => (
		<>
		</Box>
		</>
	);

	const gridFields = [
		{ source: 'patrimBemModel.id', label: 'Equipamento', reference: 'patrim-bem', fieldName: 'nome' },
	];

	return (
		<CrudChildTab
			title="Equipamentos"
			recordContext="pcpServico"
			fieldSource="pcpServicoEquipamentoModelList"
			newObject={ PcpServicoEquipamento.newObject() }
			renderForm={renderForm}
			fields={gridFields}
		/>
	);
};