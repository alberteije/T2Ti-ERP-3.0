/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	Create,
} from "react-admin";
import { PcpServicoForm } from "./PcpServicoForm";
import { transformNestedData } from "../../infra/utils";

const PcpServicoCreate = () => {
	const transform = (data: any) => transformNestedData(data);

	return (
		<Create transform={transform}>
			<PcpServicoForm />
		</Create>
	);
};

export default PcpServicoCreate;