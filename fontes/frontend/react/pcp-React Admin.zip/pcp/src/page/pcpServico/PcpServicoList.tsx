/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react/jsx-key */
import { useMediaQuery, Theme } from "@mui/material";
import {
	DatagridConfigurable,
	DeleteButton,
	List,
	SimpleList,
	ReferenceField,
	TextField,
	NumberField,
} from "react-admin";
import { BigScreenActions, DefaultFilters, SmallScreenActions } from "../sharedComponents/commonPageList";

const PcpServicoList = () => {
	const isSmall = useMediaQuery<Theme>((theme) => theme.breakpoints.down("sm"));

	const ScreenActions = isSmall
		? <SmallScreenActions fields={ ["pcpOpDetalheModel.id","inicioRealizado","terminoRealizado"] } />
		: <BigScreenActions />;
	const ScreenList = isSmall ? PcpServicoSmallScreenList : PcpServicoBigScreenList;

	return (
		<List
			title="Serviços"
			filters={DefaultFilters}
			actions={ScreenActions}
		>
			<ScreenList />
		</List>
	);
};

const PcpServicoSmallScreenList = () => {
	return (
		<SimpleList
			primaryText={ (record) => record.pcpOpDetalheModel.id }
			secondaryText={ (record) => record.inicioRealizado }
			tertiaryText={ (record) => record.terminoRealizado }
		/>
	);
}

const PcpServicoBigScreenList = () => {
	return (
		<DatagridConfigurable bulkActionButtons={false}>
			<ReferenceField label="Id Pcp Op Detalhe" source="pcpOpDetalheModel.id" reference="pcp-op-detalhe" sortable={false}>
				<TextField source="id" />
			</ReferenceField>
			<TextField source="inicioRealizado" label="Inicio Realizado" />
			<TextField source="terminoRealizado" label="Termino Realizado" />
			<TextField source="horasRealizado" label="Horas Realizado" />
			<TextField source="minutosRealizado" label="Minutos Realizado" />
			<TextField source="segundosRealizado" label="Segundos Realizado" />
			<NumberField source="custoRealizado" label="Custo Realizado" options={{
				minimumFractionDigits: 2
			}} />
			<TextField source="inicioPrevisto" label="Inicio Previsto" />
			<TextField source="terminoPrevisto" label="Termino Previsto" />
			<TextField source="horasPrevisto" label="Horas Previsto" />
			<TextField source="minutosPrevisto" label="Minutos Previsto" />
			<TextField source="segundosPrevisto" label="Segundos Previsto" />
			<NumberField source="custoPrevisto" label="Custo Previsto" options={{
				minimumFractionDigits: 2
			}} />
			<DeleteButton />
		</DatagridConfigurable>
	);
}

export default PcpServicoList;
