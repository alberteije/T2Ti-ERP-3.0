/* eslint-disable @typescript-eslint/no-explicit-any */
import {
	ListButton,
	TabbedForm,
	TabbedFormTabs,
} from "react-admin";
import { Box } from "@mui/material";
import { PcpServicoColaboradorTab } from './PcpServicoColaboradorTab';
import { PcpServicoEquipamentoTab } from './PcpServicoEquipamentoTab';

export const PcpServicoForm = () => {
	return (
		<TabbedForm syncWithLocation={false} tabs={<TabbedFormTabs variant="scrollable" scrollButtons="auto" />}>
			<TabbedForm.Tab label="Serviços">
				<PcpServicoTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Colaboradores">
				<PcpServicoColaboradorTab />
			</TabbedForm.Tab>
			<TabbedForm.Tab label="Equipamentos">
				<PcpServicoEquipamentoTab />
			</TabbedForm.Tab>
		</TabbedForm>
	);
};

const PcpServicoTab = () => {
	return (
	<>
		<ListButton />
		</Box>
	</>
	);
};