import {
	Create,
} from "react-admin";
import { PcpInstrucaoForm } from "./PcpInstrucaoForm";

const PcpInstrucaoCreate = () => {
	return (
		<Create>
			<PcpInstrucaoForm />
		</Create>
	);
};

export default PcpInstrucaoCreate;