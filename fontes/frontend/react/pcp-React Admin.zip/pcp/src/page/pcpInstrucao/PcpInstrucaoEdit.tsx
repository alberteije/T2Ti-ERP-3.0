import {
	Edit,
} from "react-admin";
import { PcpInstrucaoForm } from "./PcpInstrucaoForm";

const PcpInstrucaoEdit = () => {
	return (
		<Edit>
			<PcpInstrucaoForm />
		</Edit>
	);
};

export default PcpInstrucaoEdit;