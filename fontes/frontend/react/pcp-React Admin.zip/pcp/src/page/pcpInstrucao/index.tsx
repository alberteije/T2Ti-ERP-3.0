import PcpInstrucaoIcon from "@mui/icons-material/Apps";
import PcpInstrucaoList from "./PcpInstrucaoList";
import PcpInstrucaoCreate from "./PcpInstrucaoCreate";
import PcpInstrucaoEdit from "./PcpInstrucaoEdit";

export default {
	list: PcpInstrucaoList,
	create: PcpInstrucaoCreate,
	edit: PcpInstrucaoEdit,
	icon: PcpInstrucaoIcon,
};
